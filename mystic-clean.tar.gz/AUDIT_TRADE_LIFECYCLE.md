# Mystic Trade Lifecycle Audit

**Date:** 2026-03-02  
**Scope:** BUY entry gate, SELL exit paths, HOLD logic, duplicate cooldowns, shadow exits  
**Constraints:** Read-only audit. No new code, hooks, or refactors. Report only.

---

## 1. BUY Entry Gate Path

### 1.1 Primary Path: AI Signal → Portfolio Engine → BUY

| Step | File | Line | Function | Role |
|------|------|------|----------|------|
| 1 | `portfolio_engine_integration.py` | 566–617 | `_signal_consumption_loop` | SCAN `ai_signal:*`, `ai_decision:*`, `ai_signal_hot:*` |
| 2 | `portfolio_engine_integration.py` | 452, 865 | `add_buy_candidate` | Add symbol to engine's buy candidate queue |
| 3 | `portfolio_engine.py` | 5780 | `add_buy_candidate` | Store candidate in `_buy_candidates` |
| 4 | `portfolio_engine.py` | (bar cadence) | `process_bar_decisions` | Rank & select symbol for execution |
| 5 | `portfolio_engine.py` | 3557, 5734 | `execute_buy_from_signal` | Bridge to `execute_buy_fifo` |
| 6 | `portfolio_engine.py` | 3683 | `execute_buy_fifo` | **SOLE EXECUTION POINT FOR BUYS** |

### 1.2 `allow_new_entry()` Call Sites

`allow_new_entry()` is the trade_state gate. It is invoked at:

| File | Line | Context |
|------|------|---------|
| `portfolio_engine.py` | 3855 | Inside `execute_buy_fifo`, via `_ts_allow_entry()` |
| `paper_trading_endpoints.py` | 408 | Gate 2 in `/process-pending-signals` flow |
| `ai_paper_autobuy_service.py` | 696 | In `_process_ai_decision` BUY path (before calling portfolio integration) |

**Count:** One gate per attempted entry on the main paths.

### 1.3 Gates Inside `execute_buy_fifo` (Order)

| Order | Gate | File:Line | Blocks On |
|-------|------|-----------|-----------|
| 1 | Kill switch | 3721 | PAUSE_ALL, PAUSE_BUYS |
| 2 | Quarantine | 3734 | `quarantine:{symbol}` Redis |
| 3 | Regime guards | 3770 | Bad regime (spread, volume, ATR) |
| 4 | Exchange sizing | 3786 | `_normalize_order_amount` reject |
| 5 | Already in position | 3806 | `open_positions` |
| 6 | Profitability | 3827 | `expected_move_pct <= required_edge_pct` |
| 7 | `_can_open_position` | 3844 | Cash, discipline, max positions |
| 8 | **TRADE_STATE** | 3855 | `_ts_allow_entry()` → `allow_new_entry()` |
| 9 | Cash invariant | 3866 | `total_cost > _available_balance` |

No other early-return blockers run in parallel with trade_state. Legacy cooldowns (`_check_sell_cooldown`, `_check_scratch_cooldown`) are **DEAD** (raise `RuntimeError`).

### 1.4 Paper Trading Endpoints (FIXED 2026-03-02)

| File | Line | Behavior |
|------|------|----------|
| `paper_trading_endpoints.py` | 414 | `engine.execute_buy_from_signal(...)` via portfolio engine |
| `paper_trading_endpoints.py` | 655–668 | `place_paper_order` routes BUY/SELL through `execute_buy_from_signal` / `execute_sell_from_signal` |

**Status:** Paper trading now uses the same pipeline as live. No direct `place_order` calls. Endpoint-level cooldown gates removed; engine gates are the sole authority.

---

## 2. SELL Exit Paths (Live + Paper)

### 2.1 Enumeration

| # | Path | File | Function | Line | Routes To | notify_exit/on_exit | assert_exit_cooldown |
|---|------|------|----------|------|-----------|---------------------|----------------------|
| 1 | Portfolio engine FIFO | `portfolio_engine.py` | `execute_sell_fifo` | 4090 | N/A (sole executor) | `_ts_on_exit` 4814 | Postcondition 4823 |
| 2 | Exit executor (live) | `exit_executor.py` | `_tick` | 149 | `autosell_service.execute_autosell` | `notify_exit` 173 | 174 |
| 3 | Autosell (live) | `autosell_service.py` | `execute_autosell` | 348 | `execution.execute_sell_order` | `notify_exit` 364 | 365 |
| 4 | Automated paper selling | `automated_paper_selling_service.py` | `_execute_sell` | 188 | `paper_service.place_order(SELL)` | `notify_exit` 204 | 205 |

### 2.2 Call Chains

**Path 1 — Portfolio engine**

- `execute_sell_from_signal` → `execute_sell_fifo`
- `execute_sell_fifo` calls `_paper_service.place_order(SELL)` or `_live_service.place_order(SELL)`
- After fill: `_ts_on_exit()` → `assert_exit_cooldown()`

**Path 2 — Exit executor**

- Reads `exit:*` keys from Redis
- Calls `autosell_service.execute_autosell()`
- Autosell calls `execution.execute_sell_order()`
- After `res.get("success")`: `notify_exit()` + `assert_exit_cooldown()`

**Path 3 — Autosell (standalone)**

- `execute_autosell()` calls `execution.execute_sell_order()`
- After `res.get("success")`: `notify_exit()` + `assert_exit_cooldown()`

**Path 4 — Automated paper selling**

- `_execute_sell()` calls `paper_service.place_order(SELL)`
- After successful fill: `notify_exit()` + `assert_exit_cooldown()`

All four paths either route through `execute_sell_fifo` (Path 1) or call `notify_exit` and `assert_exit_cooldown` after a confirmed fill (Paths 2–4).

### 2.3 Other SELL-Related Paths (No Direct Order)

| File | Line | Role |
|------|------|------|
| `ai_paper_autobuy_service.py` | 2607 | `_execute_sell` delegates to `engine.execute_sell_from_signal` → Path 1 |
| `portfolio_engine_integration.py` | 484, 815 | `execute_sell_from_signal` → Path 1 |
| `trading_execution_service.py` | 251 | `execute_trade` — in-memory simulation only; guard comment at 310–320 |

---

## 3. HOLD Logic / No-Trade Conditions

### 3.1 Top 20 Hold/Reject Reasons (By Source)

| Reason | File:Line | Gate/Stage |
|--------|-----------|------------|
| KILL_SWITCH | `portfolio_engine.py:3721` | `_check_kill_switch_buy` |
| QUARANTINE | `portfolio_engine.py:3734` | `_is_symbol_quarantined` |
| REGIME_GUARD | `portfolio_engine.py:3770` | `_check_regime_guards` |
| EXCHANGE_CONSTRAINT | `portfolio_engine.py:3795` | `_normalize_order_amount` |
| add_to_position | `portfolio_engine.py:3807` | Already in position |
| profitability_gate | `portfolio_engine.py:3828` | Expected move too small |
| DISCIPLINE_GATE | `portfolio_engine.py:3847` | `_can_open_position` |
| TRADE_STATE | `portfolio_engine.py:3860` | `_ts_allow_entry` |
| CASH_INVARIANT | `portfolio_engine.py:3872` | Balance check |
| GLOBAL_COOLDOWN | `ai_paper_autobuy_service.py:552` | `_check_cooldowns` |
| SYMBOL_COOLDOWN | `ai_paper_autobuy_service.py:559` | `_check_cooldowns` |
| MIN_HOLD_TIME | `ai_paper_autobuy_service.py:569` | Re-entry hold |
| CONFIDENCE | `ai_paper_autobuy_service.py:580`, `portfolio_engine_integration.py:415` | Below threshold |
| COOLDOWN | `paper_trading_endpoints.py:394` | `_check_cooldowns` |
| TRADE_STATE:{reason} | `paper_trading_endpoints.py:413` | `allow_new_entry` |
| SIGNAL_STALE | `portfolio_engine_integration.py:424` | Signal age |
| NO_POSITION | `portfolio_engine_integration.py:479` | SELL with no position |
| SELL_EXECUTION_BLOCKED | `portfolio_engine_integration.py:492` | execute_sell_from_signal returned None |
| NO_PRICE_DATA | `portfolio_engine_integration.py:781` | Stale/missing price |
| INVALID_PRICE | `portfolio_engine_integration.py:792` | Price validation |
| UNHANDLED_SIDE | `portfolio_engine_integration.py:507` | side not buy/sell |

### 3.2 Logging Consistency

- Pipeline decisions use `gate_result` and `gate_reason` in `pipeline_decision_service` schema.
- Portfolio engine logs `BUY_BLOCKED_*` and `_record_reject(..., "GATE_NAME")`.
- Two naming styles (gate_reason vs BUY_BLOCKED_*) but both are logged and traceable.

---

## 4. Duplicate Cooldown / Blocker Inventory

### 4.1 Search Terms

Searched: `cooldown`, `scratch_cooldown`, `sell_cooldown`, `lock`, `pause`, `kill_switch`, `circuit_breaker`, `quarantine`

### 4.2 Classification

| Location | Type | Classification | Notes |
|----------|------|----------------|-------|
| `trade_state.py` | COOLDOWN state | **ACTIVE GATE** | Authoritative. Used by `allow_new_entry` |
| `ai_paper_autobuy_service.py:550–561` | `_check_cooldowns` (global, symbol) | **ACTIVE GATE** | Different from trade_state: time-since-last-trade. Not redundant for trade_state COOLDOWN. |
| `ai_paper_autobuy_service.py:679–686` | Re-entry cooldown (profit/loss) | **ACTIVE GATE** | Enforces hold after close. Complements trade_state. |
| `ai_paper_autobuy_service.py:762` | `_check_sell_cooldown` | **DEAD / GUARDED** | Raises `RuntimeError` |
| `ai_paper_autobuy_service.py:2950` | `set_scratch_cooldown` | **DEAD / GUARDED** | Raises `RuntimeError` |
| `ai_paper_autobuy_service.py:2980` | `_check_scratch_cooldown` | **DEAD / GUARDED** | Raises `RuntimeError` |
| `ai_paper_autobuy_service.py:1379` | `trading_paused_until` (drawdown) | **ACTIVE GATE** | Drawdown pause; distinct purpose |
| `paper_trading_endpoints.py:392` | `_check_cooldowns` | **ACTIVE GATE** | Same as ai_paper logic |
| `paper_trading_endpoints.py:408` | `allow_new_entry` | **ACTIVE GATE** | Trade_state authority |
| `portfolio_engine.py:3734` | `_is_symbol_quarantined` | **ACTIVE GATE** | Stale-position / sync cleanup |
| `portfolio_engine.py:3721` | `_check_kill_switch_buy` | **ACTIVE GATE** | Admin/emergency stop |
| `trading_execution_service.py:257` | `is_trading_paused` | **ACTIVE GATE** | App-level pause; service is simulation-only |
| `autosell_service.py:149` | profit_lock | **OBSERVABILITY** | Profit locking, not entry gate |
| `exit_executor.py:121` | `exit:cooloff:{symbol}` | **OBSERVABILITY** | Rate limit on exit requests |
| `ai_paper_autobuy_service.py:809` | `ExitReason.CIRCUIT_BREAKER` | **OBSERVABILITY** | Exit reason enum |

### 4.3 Conflicts

- **None.** Legacy `_check_sell_cooldown`, `set_scratch_cooldown`, `_check_scratch_cooldown` are guarded and unreachable.
- `_monitor_scratch_exits` task is disabled; `set_scratch_cooldown` is never called.
- Global/symbol cooldowns and re-entry cooldowns are orthogonal to trade_state COOLDOWN (post-exit lockout).

---

## 5. Shadow Exits / Bypass Detection

### 5.1 Rule

Every path that closes a position must call `notify_exit()` or `_ts_on_exit()` after a confirmed fill, and `assert_exit_cooldown()`.

### 5.2 Verification

| SELL Path | Writes trade_state? | Postcondition? |
|-----------|---------------------|----------------|
| `execute_sell_fifo` | ✅ `_ts_on_exit` | ✅ `assert_exit_cooldown` |
| `exit_executor` → autosell | ✅ `notify_exit` | ✅ `assert_exit_cooldown` |
| `autosell_service` | ✅ `notify_exit` | ✅ `assert_exit_cooldown` |
| `automated_paper_selling` | ✅ `notify_exit` | ✅ `assert_exit_cooldown` |

### 5.3 Potential Bypass: Paper Trading Endpoints BUY Path

**Location:** `paper_trading_endpoints.py:434`

**Issue:** BUY via `paper_service.place_order(side="buy")` skips portfolio engine and never calls `_ts_on_entry`. The resulting position is not in the portfolio engine ledger, so when it is later sold:

- If sold via `automated_paper_selling` → `notify_exit` is called ✅
- If sold via some other path that only touches paper positions → possible bypass

No other code path was found that closes a position without going through one of the four SELL paths above. **No CRITICAL shadow-exit bypass** in the SELL paths themselves.

### 5.4 `trading_execution_service`

- `execute_trade` is in-memory only; no real orders.
- Guard comment at 310–320: if it ever performs real orders, it must call `notify_exit` and `assert_exit_cooldown`.

---

## 6. Summary

### 6.1 BUY Path

| Check | Status |
|-------|--------|
| Single trade-state authority | ✅ `trade_state.py` |
| `allow_new_entry` called per attempted entry (main path) | ✅ |
| No legacy cooldown gates in use | ✅ (guarded/dead) |
| Paper endpoints BUY routes through `execute_buy_from_signal` | ✅ (fixed 2026-03-02) |

### 6.2 SELL Paths

| Check | Status |
|-------|--------|
| All 4 paths write trade_state | ✅ |
| `assert_exit_cooldown` after each fill | ✅ |
| No shadow exits (position closed without state update) | ✅ |

### 6.3 Cooldowns / Blockers

| Check | Status |
|-------|--------|
| Legacy scratch/sell cooldown methods guarded | ✅ |
| No duplicate active gates vs trade_state | ✅ |

### 6.4 Final Verdict

| Category | Result |
|----------|--------|
| **PASS** | SELL paths, trade_state authority, legacy cooldown removal, postconditions |
| **PASS** | Paper trading endpoints route BUY/SELL through portfolio engine (fixed 2026-03-02) |

**Overall:** **PASS** — All BUY/SELL paths flow through portfolio engine. Paper and live share the same pipeline.
