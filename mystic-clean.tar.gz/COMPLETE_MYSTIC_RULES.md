# COMPLETE MYSTIC RULES — ALL FILES (DO NOT LEAVE ANYTHING OUT)

Generated for reference. Source files: `.cursor/rules/*.mdc`

---

# 1. mystic-bug-fixing-protocol.mdc

```yaml
---
description: Mystic backend bug fixing protocol - direct code fixes only, no reports
alwaysApply: true
---
```

## Mystic Bug Fixing Protocol

When fixing bugs in the Mystic backend (live trading system), follow these rules:

### Rule 0: Read-Only Defect Enumeration Mode (Allowed When Explicitly Requested)
- If the user explicitly requests a **read-only audit / structural verification / defect enumeration**:
- Do **not** apply patches, fixes, refactors, threshold changes, or strategy discussion
- Return **only confirmed runtime defects** in minimal format:
  - `FILE:`
  - `LINE:`
  - `DEFECT_TYPE:`
- No narrative, no speculation, no suggestions, no risk commentary

### Rule 1: No Reports or Summaries
- **Never** generate comprehensive reports, checklists, or plan documents
- **Never** list bugs, summarize phases, or outline next steps
- **Never** use phrases like "remaining bugs to fix", "here's what needs to be done", etc.
- Token budget is limited - all output must be action, not documentation

### Rule 2: Direct Code Fixes Only
- Apply code fixes directly to files (only when explicitly requested)
- After each fix, compile the file to verify syntax (`python3 -m py_compile`)
- Move immediately to the next bug without pausing for explanation
- Show only errors if they occur, not success messages

### Rule 3: Silent Operation
- Minimal output - only show what's necessary
- If a fix succeeds, move to the next one
- If an error occurs, fix it immediately and continue
- Do not announce what you're doing or what you've completed

### Rule 4: Continuous Progression
- When fixing multiple bugs: fix in one continuous sequence
- Do not stop or ask for direction between bugs
- Test the service once all fixes are applied

---

# 2. mystic-buy-audit-log-analysis.mdc

```yaml
---
description: How to interpret buy audit logs and recommend env tweaks (no code changes)
globs: **/logs/*.log,**/backend.log
alwaysApply: false
---
```

## Mystic Buy Audit — Log Analysis Protocol

When the user asks to analyze buy audit logs or determine why no buys are occurring:

### Rules
- **Do NOT change code.** Do NOT touch sell logic or diagnostics.
- **Only recommend small env tweaks.** One tweak at a time.
- **Read logs first.** Then apply the decision logic below.

### Logs to Read (in order)

#### 1. BUY_AUDIT_SUMMARY — Primary Truth
| Dominant Block | Meaning | Action |
|----------------|---------|--------|
| CONFIDENCE | Signals too weak | `MIN_CONFIDENCE_OVERRIDE` -0.05 |
| SPREAD | Market spreads wide | `MAX_SPREAD_PCT` +0.05 to +0.1 |
| ATR | Market flat | `MIN_ATR_RATIO` -0.0005 |
| COOLDOWN | Rebuy lock active | `BUY_COOLDOWN_SEC` -10 |
| MAXPOS | Position cap reached | Increase max positions or wait |
| MIN_NOTIONAL | Cash too low | Lower trade size or add capital |
| GLOBAL_GUARD | Kill/pause active | **Flag bug** — not tuning |

If `passes > 0` but still no buys → order placement or exchange logic issue (not filters).

#### 2. BUY_DECISION_TRACE — Spot Pattern
- **Repeated same block_reason** → threshold above market signal quality.
- **Mixed reasons** → filters stacked too tightly.

#### 3. GLOBAL_GUARDS
If `trading_paused=YES`, `kill_switch=YES`, `live_mode=OFF` → guard state issue, no tuning.

#### 4. MARKET_ENTRY_CONDITIONS
- `median_spread_pct > max_spread_pct` → spread filter too strict
- `median_atr_ratio < min_atr_ratio` → ATR too strict

#### 5. CONFIDENCE_HISTOGRAM
If most signals in `0.50–0.60` bucket while `min_conf_required` is 0.70+ → bar set above AI output.

### Decision Logic
```
if dominant_block == CONFIDENCE: recommend MIN_CONFIDENCE_OVERRIDE -0.05
elif dominant_block == SPREAD: recommend MAX_SPREAD_PCT +0.05
elif dominant_block == ATR: recommend MIN_ATR_RATIO -0.0005
elif dominant_block == COOLDOWN: recommend BUY_COOLDOWN_SEC -10
elif dominant_block == MAXPOS: recommend increase max positions
elif dominant_block == MIN_NOTIONAL: recommend lower trade size or add capital
elif dominant_block == GLOBAL_GUARD: flag bug
else: NO_CHANGE
```

### Output Format
1. Dominant blocker (from BUY_AUDIT_SUMMARY)
2. One recommended env change (or "NO_CHANGE" / "FLAG_BUG")
3. Brief rationale

---

# 3. mystic-digitalocean-deployment.mdc

```yaml
---
description: Mystic DigitalOcean Droplet deployment rules - follow exactly for all deployment tasks
alwaysApply: true
---
```

## MYSTIC DIGITALOCEAN DEPLOYMENT RULES — FOLLOW EXACTLY

### 1. ENVIRONMENT IDENTITY
- This is MYSTIC, not MarketLens, not MarkLens, not any other app.
- Production host is a DigitalOcean Droplet running Ubuntu 24.04.
- Mystic backend/dashboard runs on port 8000.
- Dashboard URL: http://SERVER_IP:8000/dashboard/
- HTTP unless SSL explicitly set up.

### 2. NO PLATFORM CONFUSION
- Do not suggest Railway, Render, Heroku, Vercel unless explicitly asked.
- Do not create platform-specific configs unless requested.
- Do not switch deployment strategy midstream.
- Do not mix PaaS with raw VPS/Droplet instructions.

### 3. SSH / ACCESS RULES
- Do not assume Windows PowerShell and Linux shell are interchangeable.
- State explicitly where commands run: Droplet console or local Windows.
- Never say "paste this" without saying where it runs.
- Do not alter SSH keys, authorized_keys, sshd_config unless requested.
- Do not claim SSH keys changed unless commands actually changed them.

### 4. ONE-STEP EXECUTION MODE
- Give exactly one action at a time unless asked for full batch.
- Do not provide multiple branches ("try this or maybe that").
- Do not speculate. Verify first, then instruct.
- After each step, require exact output before continuing.
- Use output to determine next step. Do not jump ahead.

### 5. NO GUESSING
- Do not guess: files, branch, service manager, Python version.
- Always inspect first: pwd, ls, git status, git branch --show-current, python3 --version, ss -ltnp, systemctl status.
- Base every instruction on actual output.

### 6. GITHUB / DEPLOYMENT RULES
- Cursor changes locally first.
- Local must be committed and pushed before Droplet receives them.
- Droplet updates via pull from correct branch.
- Never assume auto-deploy exists.
- Always identify branch before git pull.
- Never put GitHub tokens in clone URLs, logs, commands, or output.
- If token exposed: state it must be revoked and replaced.

### 7. PYTHON / DEPENDENCY RULES
- Use venv at /home/mystic/venv.
- All pip installs with venv activated.
- Do not use system pip for app deps.
- Respect full dependency integrity.
- When requirements fail: identify exact incompatible package and version.
- Fix version incompatibilities one at a time.

### 8. APP FILE INTEGRITY RULES
- If imports fail: verify file exists before blaming deps.
- Missing internal files = app code issue, not pip.
- When creating missing file: state it is reconstruction, reconcile later.
- Do not silently invent business logic. Minimum compatibility shim only.

### 9. CONFIG RULES
- Droplet must have required .env values.
- Do not print secrets.
- When verifying env: ask only if key exists and is populated.
- Never overwrite .env blindly.
- Never change execution mode, API keys, live-trading flags, JWT unless instructed.

### 10. SERVICE MANAGEMENT RULES
- Do not switch process-management method without saying so.
- Before enabling: verify service path, ExecStart, WorkingDirectory, EnvironmentFile, port.
- After enabling: systemctl status, ss -ltnp | grep :8000, curl endpoint.
- If systemd causes trouble: revert cleanly.

### 11. NETWORK / URL RULES
- Distinguish: app running, port listening, local curl, public IP, browser.
- Do not claim "running" when user asks about browser reachability.
- If local curl works but browser fails: "backend running locally, external reachability not confirmed".
- Specify HTTP vs HTTPS. If no SSL, never use https://.

### 12. DASHBOARD RULES
- Mystic has a dashboard. Check mounted routes.
- If root redirects to /dashboard/, say so.
- Treat dashboard as primary feature.

### 13. LOG / ERROR HANDLING RULES
- When app "stops": determine if crashed, in foreground, waiting, huge response, session died.
- Do not call normal foreground behavior a crash.
- Use logs and port checks before conclusions.

### 14. COMMUNICATION RULES
- No motivational filler.
- No "maybe", "probably" unless uncertainty is real.
- No repeated apologies, no circles, no conflicting instructions.
- When wrong: state exactly what (platform, deps, file, env, service, network).

### 15. USER PREFERENCE RULES
- One step at a time.
- No giant lists when single move requested.
- Do not simplify away production requirements.
- No placeholders, toy examples, fake values unless labeled.
- Assume 24/7/365 operation.
- Production fixes must not rely on manual babysitting.

### 16. SAFE DEPLOYMENT WORKFLOW
- Before production change: identify state, name what changes, make one change, verify.
- Verification order: file exists, syntax valid, dep installed, app starts, port listens, endpoint local, dashboard external.

### 17. ABSOLUTE DO-NOT-DO LIST
- No platform configs for wrong platform.
- No token exposure.
- No SSH access changes unless told.
- No HTTPS assumption.
- No auto-deploy assumption.
- No assuming missing modules are pip packages.
- No Windows commands for Linux or vice versa without labeling.
- Do not say fixed until exact thing user cares about is verified.

### 18. UPDATE PATH RULE
- Edit in Cursor locally.
- git add / commit / push to correct branch.
- On Droplet: git pull correct branch.
- Restart app.
- Verify endpoint and dashboard.
- Cursor edits do NOT auto-update Droplet unless verified.

### 19. IF UNCERTAIN
- Inspect first.
- Ask for exact output.
- Continue from evidence only.

---

# 4. mystic-git-operations.mdc

```yaml
---
description: Mystic git operations protocol - exact commands, environment detection, safe workflows
alwaysApply: true
---
```

## MYSTIC GIT OPERATIONS PROTOCOL

### ENVIRONMENT DETECTION (MANDATORY FIRST STEP)

```bash
hostname
whoami
pwd
git rev-parse --show-toplevel
```

**ENVIRONMENT 1: CURSOR VM (Development)**
- Hostname: mystic-Virtual-Machine
- Repo root: /home/mystic/mystic
- Database: /home/mystic/mystic/mystic_trading.db
- User: mystic

**ENVIRONMENT 2: PRODUCTION (Ocean)**
- Hostname: mystic-prod
- Repo root: /home/mystic
- Database: /home/mystic/mystic_trading.db
- User: root

### RULE 1: REPO ROOTS
| Hostname | Repo Root |
|----------|-----------|
| mystic-Virtual-Machine | /home/mystic/mystic |
| mystic-prod | /home/mystic |

### RULE 2: PRE-COMMAND VERIFICATION
```bash
cd /home/mystic  # or /home/mystic/mystic on VM
pwd
git rev-parse --show-toplevel
hostname
git branch --show-current
git status --short
```

### RULE 3: STAGING AND COMMITTING
- Step 1: git status --short
- Step 2: git add [FILE_PATH] ... (NEVER git add . unless requested; NEVER add .env)
- Step 3: git diff --cached --stat
- Step 4: git commit -m "Short description"
- Step 5: git log --oneline -1

Commit message: imperative, <50 chars, lowercase. No "fix stuff".

### RULE 4: PUSHING
- Check: git remote -v, git branch -vv
- Push: git push origin [BRANCH]
- NEVER force push unless requested. NEVER push to main/master without auth.
- Verify: git log --oneline -1, git status --short

### RULE 5: PULLING (Production)
1. cd /home/mystic, pwd, git status --short, git branch --show-current
2. If uncommitted changes: STOP, ask user
3. git pull origin [BRANCH]
4. If conflicts: output and STOP
5. systemctl restart mystic; sleep 5; systemctl status mystic | head -15

### RULE 6: COMMIT HISTORY
```bash
git log --oneline --decorate -10
git log --all --graph --decorate --oneline -15
git branch -vv
git remote -v
```

### RULE 7: DIFFS
```bash
git diff -- [FILE]
git diff --cached -- [FILE]
git show [COMMIT]
```

### RULE 8: REVERTING
- Undo last (keep changes): git reset --soft HEAD~1
- Undo last (discard): git reset --hard HEAD~1 (NEVER on production without auth)
- If pushed: git revert [COMMIT]; git push origin [BRANCH]

### RULE 9: STASHING
```bash
git stash save "description"
git stash list
git stash pop
```

### RULE 10: BRANCH MANAGEMENT
```bash
git branch -a
git checkout -b [NEW_BRANCH]
git checkout [EXISTING_BRANCH]
git branch -d [BRANCH]
git push origin [BRANCH]
```
Naming: fix/hold-time-churn, feature/scoreboard-sync — lowercase, hyphens.

### RULE 11: UNCOMMITTED CHANGES
- Always git status --short before switch/pull.
- If changes: ask user (commit, stash, discard). Do NOT auto-discard.

### RULE 12: PRODUCTION UPDATE (EXACT SEQUENCE)
**Local:** hostname, git diff, git add, git commit, git push
**Production:** hostname, pwd, systemctl stop mystic, git pull, py_compile, systemctl start mystic, curl status

Critical: Stop BEFORE pull.

### RULE 13: PUSH/PULL FAILURES
- rejected (non-fast-forward): git pull then push
- rejected (force): ask user
- fatal no repository: verify git rev-parse
- fatal unable to connect: check remote, network

### RULE 14: VERIFY DEPLOYMENT
```bash
systemctl status mystic | grep -E 'Active|Process|PID'
ps aux | grep uvicorn
curl -s http://localhost:8000/api/portfolio-engine/status | jq '.data.cash_balance'
```

### RULE 15: GIT CONFIG
- NEVER modify global config unless requested.
- Local: git config user.name "Mystic Agent", git config user.email "mystic@localhost"

### RULE 16: MERGE AND REBASE
- Prefer merge. Only rebase if user requests and branch is local/unpushed.
- NEVER rebase on production without auth.

### RULE 17: TAGS
```bash
git tag -a v1.0.0 -m "Version 1.0.0"
git push origin v1.0.0
git tag -l
git show v1.0.0
```

### ABSOLUTE DO-NOT-DO (GIT)
- No git add . without request
- No .env, keys, secrets
- No force-push without auth
- No push to main/master without auth
- No repo path assumption
- No git ops in wrong environment
- No skip "stop service before pull" on production
- No token exposure
- No commit sensitive then hide (history keeps it)

### VERIFICATION CHECKLIST
- [ ] Environment verified
- [ ] Branch identified
- [ ] Files staged correctly
- [ ] Commit message clear
- [ ] Push succeeded
- [ ] On prod: service stopped before pull, pull done, service restarted, endpoint responds

---

# 5. mystic-ocean-operations.mdc

```yaml
---
description: Mystic DigitalOcean Ocean operations - server access, database, services, deployment verification
alwaysApply: true
---
```

## MYSTIC DIGITALOCEAN OCEAN OPERATIONS PROTOCOL

### ENVIRONMENT
- Hostname: mystic-prod
- Provider: DigitalOcean Droplet
- OS: Ubuntu 24.04 LTS
- IP: 137.184.237.251
- SSH User: root
- Repo Root: /home/mystic
- Database: /home/mystic/mystic_trading.db
- Port: 8000
- Dashboard: http://137.184.237.251:8000/dashboard/
- Service: mystic.service
- DB: SQLite3, Cache: Redis

### RULE 1: SSH
```bash
ssh root@137.184.237.251
```
Verify: hostname (mystic-prod), whoami (root), pwd, date

### RULE 2: PRE-OPERATION
```bash
hostname
whoami
pwd
uname -a
df -h /
free -h
systemctl status mystic | head -10
redis-cli ping
```

### RULE 3: SERVICE
- Start: systemctl start mystic; sleep 5; systemctl status mystic | head -15
- Stop (ALWAYS before: git pull, migrations, table clears): systemctl stop mystic; sleep 3
- Restart: systemctl restart mystic; sleep 8; curl status
- Logs: journalctl -u mystic -n 30; journalctl -u mystic -f
- Status: systemctl status mystic; ps aux | grep uvicorn; netstat -tlnp | grep 8000; lsof -i :8000

### RULE 4: DATABASE
- Connect: sqlite3 /home/mystic/mystic_trading.db
- Tables: paper_trades, portfolio_engine_ledger, portfolio_engine_audit, portfolio_engine_positions, portfolio_engine_orders, portfolio_engine_rejects, trade_performance, portfolio_engine_scoreboard_daily
- Safe: SELECT ledger, COUNT trades, verify consistency
- Destructive (EXPLICIT AUTH ONLY):
```bash
systemctl stop mystic
sqlite3 /home/mystic/mystic_trading.db "
DELETE FROM paper_trades;
DELETE FROM portfolio_engine_audit;
DELETE FROM portfolio_engine_positions;
DELETE FROM portfolio_engine_orders;
DELETE FROM portfolio_engine_rejects;
DELETE FROM trade_performance;
DELETE FROM portfolio_engine_scoreboard_daily;
UPDATE portfolio_engine_ledger SET 
  cash_balance = 10000.0,
  positions_value = 0.0,
  realized_pnl = 0.0,
  unrealized_pnl = 0.0,
  total_equity = 10000.0,
  last_updated = datetime('now')
WHERE id = 1;
VACUUM;
"
systemctl start mystic
```

### RULE 5: REDIS
- Status: redis-cli ping, redis-cli info server, redis-cli DBSIZE, redis-cli KEYS '*'
- Clear: redis-cli FLUSHDB
- Key: redis-cli GET bwl:tokens; redis-cli DEL [KEY]

### RULE 6: FILESYSTEM
- Disk: df -h /; du -sh /home/mystic; find ... -mtime +7
- Free space: remove __pycache__, *.pyc, pip cache

### RULE 7: MEMORY/CPU
- free -h; top -bn1 | head -20
- OOM: dmesg; systemctl stop; redis-cli FLUSHDB; systemctl start

### RULE 8: NETWORK
- netstat -tlnp | grep 8000; ss -ltnp | grep 8000; lsof -i :8000
- Local: curl localhost:8000/api/portfolio-engine/status
- External: curl 137.184.237.251:8000/api/...
- Dashboard: curl -o /dev/null -w "%{http_code}" http://137.184.237.251:8000/dashboard/

### RULE 9: GIT ON OCEAN
- Before pull: cd /home/mystic; pwd; git rev-parse; git status
- Update: systemctl stop; git pull origin [BRANCH]; py_compile; systemctl start; curl status
- View: git log --oneline -5; git branch --show-current; git remote -v

### RULE 10: STARTUP FAILURES
1. systemctl status; journalctl -n 50
2. Run direct: /home/mystic/venv/bin/uvicorn ... 2>&1 | head -100
3. pkill -9 uvicorn; systemctl start
4. import backend; sqlite3 SELECT 1; redis-cli ping
5. redis-cli DEL bwl:tokens; systemctl restart

### RULE 11: DEPLOYMENT SUCCESS
- [ ] systemctl status
- [ ] netstat | grep 8000
- [ ] curl /api/portfolio-engine/status
- [ ] curl scoreboard/today
- [ ] curl dashboard HTTP 200
- [ ] dmesg no OOM
- [ ] SELECT COUNT paper_trades

### RULE 12: COMMON PROBLEMS
| Problem | Solution |
|---------|----------|
| Won't start | journalctl -n 50; redis-cli FLUSHDB |
| Port not listening | pkill -9 uvicorn; restart |
| OOM | stop; FLUSHDB; start; swap |
| No data | SELECT COUNT paper_trades |
| Git pull hangs | Ctrl+C; network/GitHub |

### RULE 13: MAINTENANCE SEQUENCE
hostname; pwd; df; free; systemctl status → stop → changes → log/compile → start → curl local → curl external

### RULE 14: RESOURCE LIMITS
- RAM: 961 MB, Disk: 24 GB, Swap: 2 GB
- Workers: 1, disk free > 2 GB, mem free > 100 MB

### RULE 15: DO-NOT-DO (OCEAN)
- No delete critical files without approval
- No modify systemd without request
- No SSH/keys changes without auth
- No HTTPS assumption
- No token exposure
- No skip systemctl stop before DB ops
- No auto-deploy assumption
- No force-push without auth
- No heavy processes (OOM risk)
- No destructive DB without request
- No assume auto-restart

### RULE 16: PERFORMANCE
```bash
echo SERVICE && systemctl status | head -5
echo PORT && netstat | grep 8000 | wc -l
echo MEMORY && free -h | grep Mem
echo DISK && df -h /
echo TRADES && sqlite3 ... "SELECT COUNT(*) FROM paper_trades WHERE side='SELL'"
echo REDIS && redis-cli DBSIZE
```

### VERIFICATION CHECKLIST
- [ ] hostname = mystic-prod
- [ ] whoami = root
- [ ] df > 1 GB free
- [ ] free > 100 MB
- [ ] systemctl status
- [ ] port listening
- [ ] sqlite3 works
- [ ] redis-cli ping = PONG
- [ ] curl JSON
- [ ] dmesg clear
- [ ] dashboard curl 200

---

# 6. AGENT-INTEGRATION.md

- All agents: start with hostname, pwd, whoami, git rev-parse
- VM (mystic-Virtual-Machine): edit, push to GitHub
- Ocean (mystic-prod): pull, restart
- No "skip rules" mode
- Git push sequence: verify env → add → commit → push → Ocean: stop → pull → start → verify
- DB changes: stop → SQL → VACUUM → start → test
- Common mistakes: pull without stop; wrong path /home/mystic/mystic on Ocean; assume auto-deploy

---

**End of Complete Mystic Rules**
