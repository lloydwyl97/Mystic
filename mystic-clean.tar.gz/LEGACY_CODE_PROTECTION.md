# LEGACY CODE PROTECTION - DO NOT MODIFY

## ⚠️ CRITICAL: READ BEFORE MAKING ANY CHANGES ⚠️

This document protects the WORKING LIVE TRADING SYSTEM from accidental reintroduction of legacy code.

**Last verified working: February 2026**

---

## ✅ ACTIVE SERVICES (DO NOT REPLACE)

These are the ONLY services used by the live trading system. Do NOT replace them with alternatives.

### Core Startup Scripts
| Script | Purpose | Status |
|--------|---------|--------|
| `start_mystic.sh` | Main startup script | ✅ ACTIVE |
| `start_ai_ml_trading.py` | AI Signal Generator | ✅ ACTIVE |
| `start_portfolio_engine_integration.py` | Trade Executor | ✅ ACTIVE |
| `start_agent_orchestrator.py` | Social/News/Sentiment | ✅ ACTIVE |
| `live_data_collector.py` | Market Data Feed | ✅ ACTIVE |

### Core Backend Services
| Service | File | Purpose |
|---------|------|---------|
| AI Signal Generator | `backend/services/ai_signal_generator.py` | ML-based signal generation |
| Portfolio Engine | `backend/services/portfolio_engine.py` | Position management & exits |
| Portfolio Engine Integration | `backend/services/portfolio_engine_integration.py` | Signal consumption & trade execution |
| Live Trading Service | `backend/services/live_trading_service.py` | Binance API execution |
| Live Market Data | `backend/services/live_market_data.py` | Price feeds |

---

## 🚫 LEGACY SERVICES (DO NOT USE)

These services exist in the codebase but are **NOT USED** by the live system. 
**DO NOT re-enable or import these.**

### Deprecated Trading Services
| Service | File | Why Deprecated |
|---------|------|----------------|
| ~~AI Live Engine~~ | `ai_live_engine.py` | Replaced by `portfolio_engine.py` |
| ~~Runtime AutoBuy~~ | `runtime_autobuy.py` | Replaced by `portfolio_engine_integration.py` |
| ~~AI AutoBuy Orchestrator~~ | `ai_autobuy_orchestrator.py` | Legacy signal flow |
| ~~AI Paper AutoBuy~~ | `ai_paper_autobuy_service.py` | Paper trading only |
| ~~AI Live AutoBuy~~ | `ai_live_autobuy_service.py` | Replaced by portfolio engine |
| ~~Automated Paper Selling~~ | `automated_paper_selling_service.py` | Paper trading only |
| ~~AutoSell Service~~ | `autosell_service.py` | Replaced by portfolio engine exits |
| ~~Exit Executor~~ | `exit_executor.py` | Replaced by portfolio_engine_integration (monitor + execute_sell) |
| ~~Protective Exits~~ | `protective_exits.py` | Writes exit:*; exit_executor is legacy; portfolio_engine owns exits |
| ~~Old Signal Service~~ | `signal_service.py` | Replaced by `ai_signal_generator.py` |
| ~~Unified Signal Manager~~ | `unified_signal_manager.py` | Legacy signal routing |
| ~~Signal Trade Processor~~ | `signal_trade_processor.py` | Replaced by portfolio engine |

### Deprecated Order Services
| Service | File | Why Deprecated |
|---------|------|----------------|
| ~~Advanced Order Manager~~ | `advanced_order_manager.py` | Over-engineered |
| ~~Advanced Order Service~~ | `advanced_order_service.py` | Over-engineered |
| ~~Order Manager Service~~ | `order_manager_service.py` | Replaced by live_trading_service |
| ~~Order Service~~ | `order_service.py` | Replaced by live_trading_service |
| ~~Smart Order Routing~~ | `smart_order_routing.py` | Unnecessary complexity |
| ~~Execution Router~~ | `execution_router.py` | Single exchange only |

### Deprecated Analysis Services
| Service | File | Why Deprecated |
|---------|------|----------------|
| ~~Shadow Decider~~ | `shadow_decider.py` | Experimental |
| ~~Shadow Inference~~ | `shadow_inference.py` | Experimental |
| ~~Quantum Pattern Analyzer~~ | `quantum_pattern_analyzer.py` | Experimental |
| ~~Advanced Model Ensemble~~ | `advanced_model_ensemble.py` | Not used |
| ~~Ensemble Predictor~~ | `ensemble_predictor.py` | Replaced by signal generator |
| ~~Synchronous Deep Predictor~~ | `synchronous_deep_predictor.py` | Blocking, replaced |

### Deprecated Portfolio Services
| Service | File | Why Deprecated |
|---------|------|----------------|
| ~~Portfolio Manager~~ | `portfolio_manager.py` | Replaced by `portfolio_engine.py` |
| ~~Portfolio Optimizer~~ | `portfolio_optimizer.py` | Not used in scalping |
| ~~Portfolio Service~~ | `portfolio_service.py` | Legacy |
| ~~Capital Allocation Engine~~ | `capital_allocation_engine.py` | Replaced by fixed allocation |
| ~~Capital Growth Strategy~~ | `capital_growth_strategy.py` | Not used |

---

## ⚠️ DANGEROUS PATTERNS TO AVOID

### 1. DO NOT re-enable these in app_factory.py:
```python
# LEGACY - DO NOT UNCOMMENT
# from backend.services.ai_live_engine import ai_live_engine
# from backend.services.runtime_autobuy import get_engine
# from backend.services.service_auto_restart import service_auto_restart
```

### 2. DO NOT replace portfolio_engine with alternatives
The current flow is:
```
ai_signal_generator.py -> Redis -> portfolio_engine_integration.py -> live_trading_service.py -> Binance
```

### 3. DO NOT modify signal format
Signals must be in Redis key format: `ai_signal:{SYMBOL}` with canonical `side` field:
- `side`: "buy", "sell", or "hold" (use backend/services/signal_action.py)
- `confidence`: 0.0 to 1.0
- `decision_id`: for global idempotency (executed:{decision_id})

### 4. SOLE EXECUTOR / CONTROL-PLANE
- `portfolio_engine_integration` is the sole control-plane authority
- Set `AUTO_TRADING_LOOP_EXECUTION_ENABLED=false` (default) so auto_trading_loop does not execute
- Set `SOLE_EXECUTOR=portfolio_engine_integration` (default) so ai_paper_autobuy signal monitor is disabled

### 5. IDEMPOTENCY INVARIANT

No signal emission (decision_id) can produce more than one buy or sell execution across all consumers, even under retries or concurrent loops. Sells are additionally protected by a short-lived inflight mutex.

**Where executed is set:**
- BUY: `executed:{decision_id}` is set only after `execute_buy_fifo` has written to ledger/SQLite and returned (bar processor, post-commit).
- SELL: `inflight:{decision_id}` acquired before attempt; `executed:{decision_id}` set on success. Prevents concurrent duplicate sells and reduces duplicate risk under crash/retry.

**Authorized writers only:** Only `portfolio_engine_integration` may set `executed:{decision_id}`—specifically: `_bar_processor_loop` for BUY (after `process_bar_candidates` returns with result), and `_signal_consumption_loop` for SELL (after `execute_sell_from_signal` succeeds). No other code path must write this key; doing so weakens idempotency guarantees. (System runs 24/7 live.)

**Assumptions (update if architecture changes):**
- **Canonical label mapping:** Current production uses `signal_action.py`: `1`,`2`→buy; `-1`→sell; `0`→hold. If model class or label ordering changes, update `signal_action.normalize_signal_action()` and tests.
- **decision_id uniqueness:** `{symbol}_{int(time.time()*1000)}` per emission. Assumes one emission per symbol per bar and single-threaded generator; if parallelized, use monotonic counter or UUID.
- **SELL inflight TTL:** 2 min. After crash before setting executed, retry is blocked only for TTL duration; position reconciliation limits real double-sell risk.

### 6. DO NOT change database schema
Tables in use:
- `portfolio_engine_positions` - Active positions
- `portfolio_engine_ledger` - Cash balance tracking
- `portfolio_engine_trades` - Trade history

---

## 🔒 PROTECTION RULES

1. **Before adding any new service import**: Check this document first
2. **Before modifying trading flow**: Consult this document
3. **Before "improving" signal processing**: The current flow WORKS - don't change it
4. **Before adding "advanced" features**: Most advanced services are legacy for a reason

---

## 📋 CURRENT LIVE ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────────┐
│                    LIVE TRADING SYSTEM                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  [live_data_collector.py]                                      │
│         │                                                       │
│         ▼                                                       │
│  [ai_signal_generator.py] ──► Redis (ai:signal:*)              │
│         │                          │                            │
│         │                          ▼                            │
│         │            [portfolio_engine_integration.py]          │
│         │                          │                            │
│         │                          ▼                            │
│         │                 [portfolio_engine.py]                 │
│         │                          │                            │
│         │                          ▼                            │
│         └──────────────► [live_trading_service.py]             │
│                                    │                            │
│                                    ▼                            │
│                            [Binance US API]                     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🗓️ Change Log

| Date | Change | By |
|------|--------|-----|
| 2026-02-03 | Created protection document | System |
| 2026-02-03 | Verified live system working | System |
| 2026-03-02 | Removed runtime_autobuy auto-start; autobuy_control now uses portfolio_engine; removed ExitExecutor/autosell from app_factory | System |

---

**DO NOT DELETE THIS FILE**
