# ETH EXIT OBSERVATION — QUICK REFERENCE

## ONE-LINER TO RUN OBSERVATION
```bash
bash /home/mystic/mystic/tools/observe_eth_exit.sh
```

## OUTPUT LOCATION
```
/home/mystic/mystic/observations/eth_exit_<TIMESTAMP>/
```

## KEY FILES TO REVIEW (in order)

1. **exit_detection.txt** - Was exit detected?
2. **sqlite_position.txt** - Pre-exit position state
3. **sqlite_trades.txt** - All BUY/SELL orders with PnL
4. **portfolio_eth_exit_keywords.log** - Exit trigger evidence
5. **sqlite_coin_performance.txt** - Performance metrics
6. **summary.txt** - Analysis template

## REAL-TIME MONITORING
```bash
# Watch for ETH exits live
tail -f /tmp/mystic_portfolio.log | grep -iE "SELL.*ETH|ETH.*SELL|exit.*ETH"

# When exit occurs, run observation script immediately
bash /home/mystic/mystic/tools/observe_eth_exit.sh
```

## WHAT YOU'LL GET

### From sqlite_position.txt:
- Entry time, price, quantity
- Stop loss, TP1, TP2 levels
- Highest price reached
- Entry confidence

### From sqlite_trades.txt:
- All BUY orders that built position
- All SELL orders that closed position
- Individual PnL per trade
- Hold times
- Fees and slippage

### From exit_detection.txt:
- Whether SELL occurred in last 48h
- Exit timestamp
- Exit price and PnL

### From portfolio_eth_exit_keywords.log:
- Which trigger fired (TP1/TP2/STOP/TRAIL/TIME/AI)
- Execution details
- Any errors or retries

### From sqlite_coin_performance.txt:
- Win/loss counts
- Expectancy
- Profit factor
- Sizing multiplier
- Pause status

## ANALYSIS QUESTIONS ANSWERED

✓ **WHY did it sell?** - Check portfolio_eth_exit_keywords.log for trigger keywords
✓ **HOW did it sell?** - Check sqlite_trades.txt for order execution details
✓ **WHAT PnL?** - Check sqlite_trades.txt pnl and pnl_pct columns
✓ **WHAT happened after?** - Check logs for cooldown/pause, check trades for re-entry

## NOTES

- Script is READ-ONLY (no trading modifications)
- Safe to run anytime (24/7 production)
- Auto-adapts to actual schema and key formats
- Captures 48h window to catch full lifecycle
- No dependencies beyond bash, python3, redis-cli

---

**Last Updated:** 2026-02-25
**Script Location:** /home/mystic/mystic/tools/observe_eth_exit.sh
**Documentation:** /home/mystic/mystic/tools/README_OBSERVATION.txt
