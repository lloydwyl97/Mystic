# Mystic Trading System

AI-powered cryptocurrency trading system for live, automated execution with built-in risk management and diagnostics.

## Quick Start

```bash
# Install dependencies
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt

# Configure (copy .env.example and add your keys)
cp .env.example .env

# Run
./start_mystic.sh
```

## Calibration & Monitoring

After 50+ trades, run the calibration report:

```bash
python scripts/calibration_report.py
```

With live backend:

```bash
BACKEND_URL=http://localhost:8000 python scripts/calibration_report.py
```

Other diagnostics:

```bash
python scripts/profit_sanity_check.py
python scripts/full_recovery_report.py
```

## Key Environment Variables

| Variable | Purpose |
|---------|---------|
| `MAX_SPREAD_PCT` | Max spread to enter (default 0.25%) |
| `MIN_ATR_RATIO` | Min ATR/price for volatility filter |
| `MIN_CONFIDENCE_OVERRIDE` | Override confidence threshold for testing |
| `BUY_COOLDOWN_SEC` | Seconds between buys per symbol |
| `BACKEND_URL` | API base URL for calibration script |
| `CALIBRATION_LOG_PATH` | Log path for calibration (when not using API) |

## Workflow: Tuning Without Code Changes

- New tweaks = new branch (e.g. `tune-confidence`, `tune-atr`)
- Only env/parameter changes unless fixing a bug
- Never commit `.env` or logs
- Tag major stable points

## Structure

- `backend/` — Core engine, services, API
- `scripts/` — Calibration, diagnostics, recovery
- `config/` — Configuration
- `logs/` — Runtime logs (gitignored)
