# Mystic Redis Keys Reference

Redis does not use "tables"; it uses **keys** (strings, hashes, lists, sets). The app creates these on first use. All are critical for their respective features.

## Connection

- **REDIS_URL** (env): `redis://localhost:6379/0` — must be set (or REDIS_HOST, REDIS_PORT, REDIS_DB).
- **mystic:redis_ready**: Set by `scripts/redis_bootstrap.py`; marks Redis as verified.

## Cooldowns & rate limiting

| Key pattern | Type | Purpose |
|-------------|------|---------|
| cd:last_global | string | Last global trade timestamp |
| cd:last_symbol:{symbol} | string | Last trade per symbol |
| cd:last_strategy:{strategy_id} | string | Last trade per strategy |
| cd:daily_count:{YYYYMMDD} | string | Daily order count (UTC) |

## AI / strategies

| Key | Type | Purpose |
|-----|------|---------|
| ai_strategy_queue | list | Queue of strategy generation requests |
| ai_strategies | list | IDs of active AI strategies (capped) |
| ai_strategy:{model_id} | string | JSON strategy payload (with TTL) |
| last_strategy_generation:{symbol}:{strategy_type} | string | Throttle / last gen time |
| genetic_population | string | JSON genetic algorithm state |
| best_strategy | string | JSON best strategy (genetic) |
| retrain_queue | list | Retrain requests |
| new_models_queue | list | New/retrained models |
| model_metrics | string | JSON metrics (TTL) |
| retrain_status | string | JSON retrain status (TTL) |

## Paper trading

| Key | Type | Purpose |
|-----|------|---------|
| paper_trading:cash_balance | string | Current paper cash balance |
| paper_trading:principal | string | Starting principal |
| paper_trading:realized_pnl_total | string | Cumulative realized PnL |
| paper_trading:paper_run_id | string | Run identifier |
| paper_trading:stats | string | JSON stats (TTL) |
| paper:positions:active | set | Active paper position symbols |

## Signals & trade engine

| Key | Type | Purpose |
|-----|------|---------|
| tier1_signals | string | JSON tier-1 signals |
| tier2_signals | string | JSON tier-2 signals |
| tier3_signals | string | JSON tier-3 signals |
| trade_decisions | string | JSON trade decisions |
| signal_status | string | JSON signal status |
| auto_trading_enabled | string | Auto-trade flag |
| auto_trade_config | string | JSON auto-trade config |

## Market & price cache

| Key pattern | Type | Purpose |
|-------------|------|---------|
| market:{coin} | string | JSON market data (TTL) |
| price:{coin} | hash | Price fields |
| price:{coin}:json | string | JSON price (TTL) |
| market_data:last_update | string | Last market data update time |

## Locks & alerts

| Key | Type | Purpose |
|-----|------|---------|
| ai_signal_writer | string | Writer lock (TTL) |
| alerts:writer_mismatch | string | Mismatch counter |
| alerts:exit_hard_paused:{symbol} | string | Exit pause state (TTL) |

## Other services

- **trade_data_latest**, **trade:{trade_id}** (hash), **exec:aiautobuy** (list)
- **live_profit:total_locked**, **live_profit:virtual_locked**, **live_profit:lock_history** (list)
- **recent_notifications** (list), **ai:model:accuracy**, **ai:model:accuracy_details** (hash)
- **system:recovery_status**, **strategy_performance**, and various cache keys

No keys need to be created manually before starting the app; they are created when each feature runs. Ensure Redis is running and REDIS_URL is set, then run `python scripts/redis_bootstrap.py` to verify and set `mystic:redis_ready`.
