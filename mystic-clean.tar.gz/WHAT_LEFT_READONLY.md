# WHAT'S LEFT (Read-Only)

Context: paper_trades cleared. No trade history. This describes why the system can still lose money based on current code and math. No new code, no extra systems.

---

## 1) Current True-Cost Math (What Must Be Beaten)

**Components:**
- `TAKER_FEE` 0.1% (backend/services/portfolio_engine.py:206)
- `SLIPPAGE_PCT` 0.05% (207)
- Roundtrip ≈ 2×taker + slippage + spread → **`ESTIMATED_ROUNDTRIP_COST` 0.35%** (150)

**Where applied:**
- **Buy gate:** `required_edge_pct = (2*TAKER_FEE) + SLIPPAGE_PCT + spread_pct + PROFIT_EDGE_BUFFER_PCT` (3817)
- **Exit decisions (TP/Trail/Time):** `net_pnl = pnl_pct - ESTIMATED_ROUNDTRIP_COST` (5061, 5302)
- **Net floors:** `gross_gate_tp = ESTIMATED_ROUNDTRIP_COST + min_net_tp` etc. (5076-5078)

---

## 2) Three Remaining Loss Sources (Ranked)

### A) Stop-loss is unconditional and uses gross pnl_pct
- **Scalper:** `pnl_pct < -coin_sl` → no net check. **portfolio_engine.py:5119**
- **Fallback:** `current_price <= stop_price` → hard price stop. **portfolio_engine.py:5248**
- `coin_sl` from `get_coin_profile` (199-201): 0.54%–0.81% depending on coin. Every hit realizes a loss (often −0.6%–−0.8% gross → ~−0.95%–−1.15% net after roundtrip). Compounding.

### B) Net PnL inconsistency
- **Exit decisions** use `net_pnl = pnl_pct - ESTIMATED_ROUNDTRIP_COST` (5061, 5302) where `pnl_pct` is gross.
- **Stored/realized pnl:** `entry_cost = quantity * position.entry_price` (4587) — no entry fee.
- **Realized:** `realized_pnl = proceeds - entry_cost`; `pnl_pct = (realized_pnl / entry_cost) * 100` (4588-4589). Proceeds subtract exit fee, but `entry_cost` omits entry fee → stored `pnl_pct` is not fully net.

### C) Trail/time floors vs true cost
- `MIN_NET_PROFIT_TO_SELL` 0.25% (151), `MIN_NET_PROFIT_TO_SELL_TRAIL` 0.15% (152), `MIN_NET_PROFIT_TO_SELL_TIME` 0.0 (153).
- Gross gates: TP 0.6%, Trail 0.5%, Time 0.35% (5076-5078, 5302-5303).
- If true roundtrip > 0.35% or spread is wider, exits allowed at “net ≥ 0” can still be net-negative in reality.

---

## 3) Next Move (One Line)

**Reduce stop frequency (widen stops or add net-pnl guard)** — stops are the main source of realized losses; every hit locks in net-negative results and compounds.

---

## FIXES APPLIED

- **entry_fee** on OpenPosition + portfolio_engine_positions; backfill from paper_trades (trade_id → fees_paid)
- **execute_sell_fifo** uses `entry_cost = qty*entry_price + entry_fee_pro_rata` for true-net realized_pnl
- **Stop-loss net-pnl guard:** MIN_NET_LOSS_TO_CUT (0.3%); don't fire SL until `net_pnl < -0.003` (scalper + fallback)
