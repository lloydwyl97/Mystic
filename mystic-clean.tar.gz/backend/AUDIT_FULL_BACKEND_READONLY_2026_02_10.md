# Full Backend Audit — Read-Only Report
**Date:** 2026-02-10  
**Scope:** All `.py` under `backend/`, integration scripts, services, engines, orchestrators, utils, models, startup scripts.  
**Directive:** Analysis only — no file modifications, no auto-fix, no refactor.

---

## 1. Critical Bugs — Can Cause Money Loss or Incorrect Trades

### C1. Bare `except: pass` in reconciliation path
- **File:** `backend/services/portfolio_engine.py`
- **Function:** `_reconcile_derived_state_from_canonical` (inner sync helper)
- **Line range:** ~2404–2408
- **Root cause:** After `cur.execute("ROLLBACK")`, a bare `except: pass` swallows any exception (e.g. connection already closed, or rollback failure), hiding real errors.
- **Impact:** Reconciliation can fail silently; canonical realized PnL read can return 0.0 on error while callers assume valid data. May affect cash/equity derivation.
- **Conceptual fix:** Use `except Exception as e: logger.debug(...); raise` or at minimum log and re-raise; avoid bare `except`.

### C2. Risk governor min_notional hardcode vs engine constraints
- **File:** `backend/services/risk_governor.py`
- **Function:** Governance loop (Layer2+3)
- **Line range:** ~211–214
- **Root cause:** `if target_notional < 10.0` is hardcoded; engine uses `_effective_min_notional()` and per-symbol `min_notional` from `_symbol_constraints`. Exchange min_notional can be > 10.
- **Impact:** Governor can allow a candidate with target_notional e.g. $10 while exchange min_notional is $15; engine later blocks with BUY_BLOCKED_EXCHANGE. Inconsistent UX and possible confusion; in edge cases could contribute to repeated reject/retry behavior.
- **Conceptual fix:** Pass effective min_notional (per symbol or global) into risk governor and use it instead of 10.0.

### C3. Potential IndexError when no allowed candidates but valid_candidates non-empty
- **File:** `backend/services/portfolio_engine.py`
- **Function:** `process_bar_candidates`
- **Line range:** ~5156–5158
- **Root cause:** `top_candidate = allowed_ordered[0] if (...) else valid_candidates[0]`. If `valid_candidates` is empty (e.g. ranking returns [] in an edge case), `valid_candidates[0]` raises IndexError.
- **Impact:** Unhandled exception in bar processing; that bar’s candidates are not processed. Needs runtime verification whether ranking ever returns empty after earlier guards.
- **Conceptual fix:** Explicit check: if not `allowed_ordered` and not `valid_candidates`: return None; else choose top from the non-empty list.

---

## 2. Medium Bugs — Logic or Sync Drift

### M1. Fallback constraints persisted with source "fallback"
- **File:** `backend/services/portfolio_engine.py`
- **Function:** `_ensure_symbol_constraints`
- **Line range:** ~3098–3132
- **Root cause:** When ccxt fetch fails and SQLite has no row, fallback (DEFAULT_QTY_STEP, MIN_POSITION_NOTIONAL) is written to SQLite with `source="fallback"`. C2 verification expects persistence; if a later run only loads from SQLite without re-fetching, it may keep using fallback values after exchange has changed.
- **Impact:** Stale fallback constraints could cause repeated filter failures or wrong sizing until next successful ccxt refresh.
- **Conceptual fix:** Either do not persist fallback, or persist with a TTL/version and force refresh after a delay; document that "fallback" means "not from exchange."

### M2. Cooldown semantics: bar_interval must be set before load
- **File:** `backend/services/portfolio_engine.py`; `backend/services/portfolio_engine_integration.py`
- **Line ranges:** engine ~6846–6848, 6917–6918; integration ~142–146
- **Root cause:** `record_sell_cooldown` and `load_quality_state_from_redis` depend on `_bar_interval_seconds`. If integration starts tasks before `set_bar_interval_seconds` + `load_quality_state_from_redis`, cooldowns can be skipped or wrong.
- **Impact:** Cooldowns may not apply after restart if init order is wrong; or cooldown_until in Redis (in bar-time seconds) interpreted incorrectly if bar_interval changes.
- **Conceptual fix:** Ensure init order is documented and enforced (e.g. assert bar_interval set before first sell/load); consider storing bar_interval version with cooldown state.

### M3. Paper vs engine ledger: two sources of cash in non-live
- **File:** `backend/services/portfolio_engine.py`
- **Function:** `_reconcile_derived_state_from_canonical`
- **Line range:** ~2414–2426
- **Root cause:** When not live and not test_mode, cash is taken from paper cache-only balance. Engine ledger (SQLite) and paper ledger can drift if paper updates (e.g. simulated trades) are not reflected in engine’s canonical state.
- **Impact:** Engine equity/cash can diverge from paper; reconciliation assumes paper as source of truth for cash in this mode.
- **Conceptual fix:** Document that in paper-only mode, engine cash is driven by paper cache; add a single place that defines “authoritative” cash per mode (paper vs live).

### M4. Performance monitor sync Redis in possibly async context
- **File:** `backend/performance_monitor.py`
- **Function:** `_get_redis_ai_stats`
- **Line range:** ~438–439, 464, 470
- **Root cause:** Uses `get_redis_service()` (sync client) and `r.get()`, `r.keys()`, `r.hgetall()`. If this method is ever called from an async path, it would block the event loop.
- **Impact:** If invoked from async endpoint or task, can cause latency spikes. Needs runtime verification of call sites.
- **Conceptual fix:** Use async Redis for any caller that is async; or document that this is sync-only and must not be called from async code.

### M5. Circuit breaker run_until_complete from sync context
- **File:** `backend/services/circuit_breaker_service.py`
- **Function:** `_load_circuit_state`, `_persist_circuit_state`
- **Line range:** ~316–327, 359–365
- **Root cause:** Sync methods use `loop.run_until_complete(get_state(...))`. If called from an async context (e.g. during request), `get_running_loop()` exists and persist path bails with a warning; load path may still run and create nested loop issues.
- **Impact:** In async context, state may not persist; or nested event loop errors. Needs runtime verification.
- **Conceptual fix:** Provide async variants and use them from async code; from sync code use run_until_complete only when no running loop.

### M6. BINANCE_SYNC dust check: engine vs raw SQLite min_qty
- **File:** `backend/services/portfolio_engine_integration.py`
- **Function:** `_binance_sync_loop`
- **Line range:** ~1195–1211
- **Root cause:** When engine is None, dust is inferred from SQLite `min_qty` only; engine uses `_dust_check(symbol, qty, price)` which uses min_notional and qty_step. So “drift forgiven” logic can differ (engine: dust = below min_notional or step; fallback: only below min_qty).
- **Impact:** In the rare case engine is missing, a position could be treated as non-dust locally but dust by exchange (or vice versa), leading to unnecessary drift warnings or missed cleanup.
- **Conceptual fix:** Use same dust semantics when engine is unavailable (e.g. reuse exchange_symbol_constraints min_notional/min_qty in a small helper).

### M7. Double orchestrator / writer lock
- **File:** `backend/services/ai_autobuy_orchestrator.py`; `backend/app_factory.py`
- **Root cause:** Orchestrator is deprecated; integration + portfolio_engine_integration are the active path. app_factory can still start orchestrator in non–external-supervisor mode. Writer lock prevents two orchestrators, but if both orchestrator and integration run (e.g. misconfiguration), decision routing could be ambiguous.
- **Impact:** Duplicate or conflicting decision writers if both are enabled. Mitigated by EXTERNAL_SUPERVISOR_MODE and deprecation; worth documenting and ensuring only one “decision writer” is active.
- **Conceptual fix:** Enforce single writer in config/startup (only integration, or only orchestrator); document that orchestrator is legacy and must not run with integration.

---

## 3. Low Bugs — Hygiene / Inconsistency

### L1. Redis KEYS usage (performance)
- **Files:** `backend/endpoints/paper_trading_endpoints.py` (290–291, 308–309 fallback); `backend/endpoints/ai_live_endpoints.py` (113); `backend/performance_monitor.py` (395, 464 fallback); `backend/services/ai_autobuy_orchestrator.py` (699); `backend/services/stateless_session_manager.py` (273, 277); others.
- **Root cause:** Several places use `redis.keys("pattern")` or sync `r.keys()` instead of SCAN. In production with many keys this can block.
- **Impact:** Latency spikes under load; possible Redis blocking.
- **Conceptual fix:** Prefer scan_iter / async SCAN everywhere; keep KEYS only as fallback with a cap and log.

### L2. ai_processor_service cancel_all_pending tight loop
- **File:** `backend/services/ai_processor_service.py`
- **Function:** `cancel_all_pending`
- **Line range:** ~230–234
- **Root cause:** `while True: self.task_queue.get_nowait()` until QueueEmpty. Not an infinite loop in practice (queue drains), but if queue were never empty due to a bug, this would spin without sleep.
- **Impact:** CPU spin in pathological case only.
- **Conceptual fix:** Add a max_iteration guard or small sleep after N iterations as a safety valve.

### L3. protective_exits override fetch exception scope
- **File:** `backend/services/protective_exits.py`
- **Line range:** ~231–242
- **Root cause:** `asyncio.gather(self._redis.get(...), ...)` wrapped in try/except that catches ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError. Redis client can raise other exceptions (e.g. ConnectionError).
- **Impact:** Unhandled exception could break the override fetch path; defaults would be used (acceptable) but error not logged.
- **Conceptual fix:** Broaden to `except Exception` and log, then use defaults.

### L4. Inconsistent confidence normalization entry points
- **Files:** `backend/services/portfolio_engine_integration.py` (~358–360); `backend/services/ai_live_autobuy_service.py` (~1114–1116); `backend/services/confidence_normalizer.py`
- **Root cause:** ConfidenceNormalizer.normalize() is used in integration and live autobuy; portfolio_engine sizing uses confidence directly (and documents “confidence scales the final result”). If a signal path does not call normalizer, confidence could be in a different scale (e.g. 0–100 vs 0–1).
- **Impact:** Thresholds (e.g. MIN_CONFIDENCE) assume 0–1; one path could pass raw 0–100 and incorrectly pass or fail. test_autobuy_config_confidence covers 0–1; ensure all signal producers feed normalized confidence.
- **Conceptual fix:** Single entry point: all signals normalized (or scaled) before reaching engine; document canonical scale 0.0–1.0 everywhere.

### L5. GATE_BLOCKED reasons in multiple layers
- **Files:** `backend/endpoints/paper_trading_endpoints.py`; `backend/services/ai_paper_autobuy_service.py`; `backend/services/portfolio_engine.py` (BUY_BLOCKED_*)
- **Root cause:** Paper/endpoints use gate_reason strings (COOLDOWN, SELL_COOLDOWN, CONFIDENCE, etc.); engine uses BUY_BLOCKED_* and SELL_BLOCKED. Two naming schemes.
- **Impact:** Log aggregation and dashboards need to handle both; no functional bug.
- **Conceptual fix:** Standardize reason codes (e.g. enum or shared constants) for gates and blocks.

---

## 4. Dead Code / Unused Paths

- **ai_autobuy_orchestrator.py:** File header marks it LEGACY/REPLACED by portfolio_engine_integration. Still importable and startable from app_factory when EXTERNAL_SUPERVISOR_MODE is false. Consider removing from startup or gating behind a feature flag.
- **runtime_autobuy.py / unified_signal_manager.py:** Referenced in integration docstring as deprecated; confirm no remaining callers.
- **scripts_unused/** (e.g. start_orchestrator, start_signals, start_paper_autobuy): Unused startup scripts; keep for reference or remove from active tree.
- **structural_audit_scan.py:** References _entry_ensure_constraints and _ensure_symbol_constraints; script may be one-off; not dead but could be moved to scripts/ or docs.

---

## 5. Unit / Semantic Risks

- **Bar time vs wall-clock:** `current_bar = int(time.time() / self.bar_interval) * self.bar_interval` is bar-close timestamp (seconds), not bar index. Cooldowns store `cooldown_until` in the same seconds. Consistent; document that “bar” here means “bar close timestamp” for cooldown math.
- **Seconds vs bars:** POST_SELL_COOLDOWN_BARS and GLOBAL_SELL_COOLDOWN_BARS are in bars; multiplied by `_bar_interval_seconds` to get seconds. Correct.
- **Paper autobuy bar_interval:** ai_paper_autobuy_service uses 60s; integration uses 60. Aligned.
- **qty_step / min_notional:** Both engine and live_trading_service use float; _floor_to_step uses Decimal for safety. Consistent.
- **Needs runtime verification:** Whether `valid_candidates` can ever be empty at line 5157 when we use `valid_candidates[0]` (depends on ranking and filters).

---

## 6. Design Inconsistencies

- **Decision gate vs execution gate:** Engine uses _entry_ensure_constraints so decision and execution share the same constraint source; comment at 5169 and 3138 confirms. Integration and paper endpoints apply their own gates (cooldown, confidence) before calling engine; engine’s execute_buy is the sole execution gate. No mismatch found; gates are layered correctly.
- **Two cooldown systems:** Paper autobuy has its own cooldowns (e.g. SELL_COOLDOWN_SECONDS, scratch cooldown in Redis). Engine has bar-based symbol/global cooldowns in QualityFilterState. Both can apply; document which layer applies in paper vs live.
- **Min notional sources:** risk_governor 10.0 vs engine _effective_min_notional() and exchange_symbol_constraints (see C2).
- **Orchestrator vs integration:** One codebase path should be canonical for “who writes ai_decision / drives buys”; currently integration is canonical, orchestrator legacy.

---

## 7. Performance Risks

- **Infinite loops with sleep:** All `while True` loops audited either have `await asyncio.sleep(...)` or `time.sleep(...)` (or break on CancelledError/QueueEmpty). startup_cleanup_manager uses SCAN with cursor until cursor==0 (correct). ai_processor_service cancel_all_pending is the only “tight” loop (see L2).
- **Repeated constraint fetches:** _ensure_symbol_constraints is called at multiple entry points (buy/sell paths); it short-circuits when symbol in _symbol_constraints and _constraints_fresh. Freshness TTL limits refetch rate. Acceptable.
- **Blocking in async:** portfolio_engine uses run_in_executor for SQLite and sync work; appropriate. circuit_breaker_service and performance_monitor sync Redis (see M4, M5).
- **Redis key scans:** See L1; replace KEYS with SCAN where possible.

---

## 8. Quality Filters & Guards

- **Wiring:** Quality filters (multi-bar, chop, cooldown, pacing, churn) are applied in _check_quality_filters before sizing in process_bar_candidates. Cooldowns are recorded in record_sell_cooldown after sells and persisted via _persist_quality_cooldowns. Load on startup via load_quality_state_from_redis. Wired correctly.
- **History pruning:** recent_bar_signals is bounded per symbol (MULTI_BAR_LOOKBACK + 2). Cooldowns in Redis are pruned on load (until <= current_bar). Acceptable.
- **Duplicate records:** pipeline_decision_service consolidates _update_pipeline_decision. Integration uses distributed lock and “claim” to prevent duplicate processing. Idempotency mentioned in several services (labeler, database_schema).
- **Cooldown logic:** record_sell_cooldown uses bar_interval_seconds; current_bar in _check_quality_filters uses same bar semantics. Correct; only risk is init order (M2).

---

## 9. Safe / Verified Areas

- **Constraint flow:** _ensure_symbol_constraints → in-memory _symbol_constraints + SQLite upsert; fallback persisted with source "fallback". C2 test verifies persistence and restart.
- **Dust handling:** _dust_check used consistently for min_notional and qty_step; LIVE_SELL uses it for writeoff; dust reconciliation loop and DUST_PENDING flow are documented.
- **Confidence:** ConfidenceNormalizer avoids double boost (comment in normalizer); sizing in portfolio_engine applies confidence scaling in one place.
- **Ledger order:** execute_sell_fifo updates position, then realized_pnl, _recompute_positions_values, _validate_invariants, _persist_ledger_to_sqlite, _record_audit. Cash/position update order is correct.
- **Deletion lock:** _deletion_lock used around position deletion and DUST_PENDING entry to avoid reconciliation race (BUG #1 FIX).
- **Restart safety:** Quality and regime state loaded from Redis on startup; constraints loaded from SQLite when ccxt unavailable; ledger in SQLite.

---

## 10. Needs Runtime Verification

- Whether `valid_candidates` can be empty at portfolio_engine.py ~5157 when `valid_candidates[0]` is used.
- Call sites of performance_monitor._get_redis_ai_stats (sync vs async).
- Call sites of circuit_breaker_service _load_circuit_state / _persist_circuit_state (sync vs async).
- That only one of orchestrator and portfolio_engine_integration is active in production (config/startup).

---

**End of report.**
