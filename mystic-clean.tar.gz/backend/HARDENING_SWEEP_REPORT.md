# Live Trading Hardening Sweep Report

**Scope:** Structural and drift-type issues. No strategy logic changes.

---

## 1. Exchange Filter Drift (High) — ADDRESSED

| Check | Status | Notes |
|-------|--------|------|
| Filters at startup | ✅ | Fetched on-demand via `_ensure_symbol_constraints` |
| Periodic refresh | ✅ | TTL now 12h (was 24h); env `CONSTRAINTS_TTL_HOURS` |
| Cached per symbol | ✅ | `_symbol_constraints` dict |
| Decimal quantization | ✅ | `_floor_to_step` uses `Decimal` internally |
| Fallback TTL | ✅ | 1h memory-only; not persisted |

**Failure symptom if wrong:** -2010, dust, unsellable balances.

---

## 2. Decimal vs Float (High) — PARTIAL

| Area | Status |
|------|--------|
| Quantization (`_floor_to_step`, `_dust_check`) | ✅ Decimal |
| Sizing (`_compute_size_from_confidence`) | float in/out |
| PnL, fees, ledger | float |
| `_apply_exchange_constraints` | ✅ Decimal |

**Recommendation:** Convert sizing/PnL to Decimal in a future pass. Current critical paths (quantize, dust) use Decimal.

---

## 3. Time Sync / Clock Drift (Medium–High) — ADDRESSED

| Check | Status |
|-------|--------|
| NTP / exchange_time_offset | ✅ Readiness check now fetches Binance `fetch_time` |
| recvWindow | ✅ 10000 ms in live_trading_service |
| Stale-signal guard | ✅ 120s; uses local time |

**Fix applied:** `/api/live/readiness` now compares exchange server time vs local.

---

## 4. Order Status Reconciliation (Medium)

| Check | Status |
|-------|--------|
| Poll / websocket after create_order | ❌ None |
| PARTIALLY_FILLED handling | ❌ Not in portfolio_engine |
| Timeout / EXPIRED | ❌ Not in portfolio_engine |

**Note:** CCXT `create_order` for market returns immediately; typically filled. No explicit poll. `order_manager_service` has status polling; portfolio_engine does not use it.

---

## 5. Position Size Rounding Before Buy (Medium) — OK

| Check | Status |
|-------|--------|
| Buy qty → step quantize | ✅ `_compute_size_from_confidence` uses `_floor_to_step` |
| min_notional check | ✅ `_below_decision_min_notional` |
| Fee buffer before quantize | ✅ `effective_min = MIN_POSITION_NOTIONAL * (1 + ENTRY_COST_PCT)` |

---

## 6. Memory / Cache Growth (Medium)

| Check | Status |
|-------|--------|
| Redis TTL | ✅ `setex` for quarantine; quality state TTL |
| Unbounded lists/dicts | ⚠️ `trade_explanations`, `coin_performance` grow; no cap |
| Candle buffers | ✅ Capped in market data |

**Recommendation:** Add bounds to `trade_explanations` (e.g. last N) if long-running.

---

## 7. Exception Boundaries (Medium)

| Path | Status |
|------|--------|
| portfolio_engine buy/sell | ✅ Logs + re-raise or return |
| portfolio_engine_integration | ⚠️ Several `except Exception: pass` (e.g. Redis lock) |
| live_trading_service place_order | ✅ Returns error dict; no silent pass |

**Note:** Integration `except pass` are in non-execution paths (Redis, cleanup). No bare pass in order placement.

---

## 8. Websocket / Stream Reconnect (Medium)

| Check | Status |
|-------|--------|
| websocket_manager (client) | ✅ Ping/pong, cleanup on disconnect |
| Binance user stream | ⚠️ Reconnect logic in binance_user_stream; not audited |
| On reconnect refresh | ❌ Not verified |

---

## 9. Fee Calculation Consistency (Low–Medium) — OK

| Constant | Usage |
|----------|--------|
| TAKER_FEE | Sell fee, exit gating |
| ESTIMATED_ROUNDTRIP_COST | TP/TRAIL/TIME net gates |
| ENTRY_COST_PCT | Min notional buffer |

No duplicate fee tables in portfolio_engine.

---

## 10. Kill-Switch / Safety Guards (Low) — OK

| Guard | Status |
|-------|--------|
| Max daily loss / drawdown | ✅ DRAWDOWN_LIMIT_PCT, DRAWDOWN_GUARD |
| Position cap | ✅ MAX_OPEN_POSITIONS before order |
| Trade-per-minute | ✅ MAX_BUYS_PER_HOUR, MAX_BUYS_PER_DAY |

---

## Changes Applied This Sweep

1. **CONSTRAINTS_TTL_SECONDS:** 24h → 12h (env `CONSTRAINTS_TTL_HOURS`)
2. **live_readiness exchange_time_sync_ok:** Now fetches Binance `fetch_time` vs local

---

## Not Touched (Per Directive)

- Coin profiles
- Canonical mismatch logic
- Reconciliation logic
- Paper sync retry
- External close cleanup
