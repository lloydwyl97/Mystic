import asyncio
import json
import logging
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import pandas as pd

from backend.services.task_manager import task_manager

logger = logging.getLogger(__name__)

"""
Advanced AI Orchestrator
Coordinates all AI agents including deep learning, reinforcement learning, and model management
"""

# Add parent directory and project root to path for imports
backend_path = str(Path(__file__).resolve().parent.parent)
if backend_path not in sys.path:
    sys.path.insert(0, backend_path)

root_path = str(Path(backend_path).parent)
if root_path not in sys.path:
    sys.path.insert(0, root_path)

from backend.agents.base_agent import BaseAgent

# Add usage for unused imports to satisfy F401
_timedelta: timedelta = timedelta(seconds=0)
_Tuple: tuple[int, int] = (0, 1)
_pd_df = pd.DataFrame()


class AIStrategy:
    """AI Strategy combining multiple AI approaches"""

    def __init__(self, strategy_id: str, symbol: str, components: dict[str, Any]) -> None:
        self.strategy_id = strategy_id
        self.symbol = symbol
        self.components = components
        self.created_at = datetime.now(tz=timezone.utc).isoformat()
        self.confidence = 0.0
        self.performance_metrics = {}
        self.status = "created"


class AdvancedAIOrchestrator(BaseAgent):
    """Advanced AI Orchestrator - Coordinates all AI agents"""

    def __init__(self, agent_id: str = "advanced_ai_orchestrator_001") -> None:
        super().__init__(agent_id, "advanced_ai_orchestrator")

        self.state.update(
            {
                "ai_strategies": {},
                "agent_coordination": {},
                "performance_metrics": {},
                "last_coordination": None,
                "coordination_count": 0,
            },
        )

        # AI coordination configuration
        self.coordination_config = {
            "ai_agents": {
                "deep_learning_agent": {
                    "type": "deep_learning",
                    "capabilities": [
                        "price_prediction",
                        "pattern_recognition",
                    ],
                    "weight": 0.4,
                    "enabled": True,
                },
                "reinforcement_learning_agent": {
                    "type": "reinforcement_learning",
                    "capabilities": [
                        "strategy_optimization",
                        "action_selection",
                    ],
                    "weight": 0.3,
                    "enabled": True,
                },
                "nlp_agent": {
                    "type": "nlp",
                    "capabilities": ["sentiment_analysis", "news_processing"],
                    "weight": 0.2,
                    "enabled": True,
                },
                "computer_vision_agent": {
                    "type": "computer_vision",
                    "capabilities": ["chart_analysis", "technical_indicators"],
                    "weight": 0.1,
                    "enabled": True,
                },
            },
            "coordination_settings": {
                "strategy_generation_interval": 300,  # seconds
                "performance_evaluation_interval": 600,  # seconds
                "confidence_threshold": 0.7,
                "min_agent_agreement": 0.6,
                "strategy_lifetime": 3600,  # seconds
            },
            "integration_settings": {
                "enable_cross_validation": True,
                "enable_ensemble_methods": True,
                "enable_adaptive_weights": True,
                "enable_fallback_strategies": True,
            },
        }

        # Trading symbols to monitor
        self.trading_symbols = [
            "BTC",
            "ETH",
            "ADA",
            "DOT",
            "LINK",
            "UNI",
            "AAVE",
        ]

        # AI agent connections
        self.ai_agents = {}
        self.agent_weights = {}
        self.agent_capabilities = {}

        # Strategy cache
        self.strategy_cache = {}
        self.performance_history = {}

        # Register orchestrator-specific handlers
        self.register_handler("coordinate_ai_agents", self.handle_coordinate_ai_agents)
        self.register_handler("generate_ai_strategy", self.handle_generate_ai_strategy)
        self.register_handler("get_ai_status", self.handle_get_ai_status)
        self.register_handler("ai_prediction", self.handle_ai_prediction)
        self.register_handler("ai_strategy", self.handle_ai_strategy)
        self.register_handler("model_deployment", self.handle_model_deployment)

        logger.info(f"[TARGET] Advanced AI Orchestrator {agent_id} initialized")

    async def initialize(self):
        """Initialize advanced AI orchestrator resources"""
        try:
            # Load coordination configuration
            await self.load_coordination_config()

            # Initialize AI agent connections
            await self.initialize_ai_agents()

            # Start AI coordination
            await self.start_ai_coordination()

            logger.info(f"[OK] Advanced AI Orchestrator {self.agent_id} initialized successfully")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error initializing Advanced AI Orchestrator")
            self.update_health_status("error")

    async def process_loop(self):
        """Main AI coordination processing loop"""
        while self.running:
            try:
                # Coordinate AI agents
                await self.coordinate_ai_agents()

                # Generate AI strategies
                await self.generate_ai_strategies()

                # Evaluate strategy performance
                await self.evaluate_strategy_performance()

                # Update coordination metrics
                await self.update_coordination_metrics()

                # Clean up old strategies
                await self.cleanup_old_strategies()

                await asyncio.sleep(30)  # Check every 30 seconds for better responsiveness

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Error in AI coordination processing loop")
                await asyncio.sleep(60)  # Reduced error retry time

    async def load_coordination_config(self):
        """Load coordination configuration from Redis"""
        try:
            # Load coordination configuration
            config_data = self.redis_client.get("advanced_ai_coordination_config")
            if config_data:
                if isinstance(config_data, bytes):
                    config_data = config_data.decode()
                self.coordination_config = json.loads(config_data)

            # Load trading symbols
            symbols_data = self.redis_client.get("trading_symbols")
            if symbols_data:
                if isinstance(symbols_data, bytes):
                    symbols_data = symbols_data.decode()
                self.trading_symbols = json.loads(symbols_data)

            logger.info(f"📋 Coordination configuration loaded: {len(self.coordination_config['ai_agents'])} AI agents, {len(self.trading_symbols)} symbols")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error loading coordination configuration")

    async def initialize_ai_agents(self):
        """Initialize AI agent connections"""
        try:
            for agent_name, agent_config in self.coordination_config["ai_agents"].items():
                if agent_config["enabled"]:
                    self.ai_agents[agent_name] = {
                        "type": agent_config["type"],
                        "capabilities": agent_config["capabilities"],
                        "weight": agent_config["weight"],
                        "status": "unknown",
                        "last_communication": None,
                    }

                    self.agent_weights[agent_name] = agent_config["weight"]
                    self.agent_capabilities[agent_name] = agent_config["capabilities"]

            logger.info(f"🧠 AI agents initialized: {len(self.ai_agents)} agents")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error initializing AI agents")

    async def start_ai_coordination(self):
        """Start AI coordination"""
        try:
            # Subscribe to AI agent updates
            pubsub = self.redis_client.pubsub()
            pubsub.subscribe("ai_predictions")
            pubsub.subscribe("ai_strategies")
            pubsub.subscribe("model_deployments")

            # Start coordination listener
            task = await task_manager.create_task(self.listen_ai_updates(pubsub), name="advanced_ai_orchestrator:listen_ai_updates")
            self._tasks.append(task)

            logger.info("AI coordination started")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error starting AI coordination")

    async def listen_ai_updates(self, pubsub) -> None:
        """Listen for AI agent updates"""
        try:
            # pubsub.listen() yields messages in blocking manner; run in background task
            for message in pubsub.listen():
                if not self.running:
                    break

                try:
                    mtype = message.get("type")
                    # Only handle actual messages
                    if mtype not in ("message", "pmessage"):
                        continue

                    channel = message.get("channel")
                    data = message.get("data")

                    # Decode channel and data if bytes
                    if isinstance(channel, bytes):
                        try:
                            channel = channel.decode()
                        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                            channel = str(channel)

                    payload = None
                    if isinstance(data, bytes):
                        try:
                            payload = json.loads(data.decode())
                        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                            try:
                                payload = data.decode()
                            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                                payload = data
                    else:
                        # data could already be a dict or str
                        payload = data

                    # Route messages based on channel
                    if channel == "ai_predictions":
                        await self.process_ai_update({"type": "ai_prediction", "payload": payload})
                    elif channel == "ai_strategies":
                        await self.process_ai_update({"type": "ai_strategy", "payload": payload})
                    elif channel == "model_deployments":
                        await self.process_ai_update({"type": "model_deployment", "payload": payload})
                    else:
                        # Unknown channel; log at debug
                        logger.debug(f"Received message on unknown channel {channel}: {payload}")

                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception("Error processing pubsub message")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error listening for AI updates")

    async def get_current_market_data(self, symbol: str) -> dict[str, Any] | None:
        """Retrieve current market data for a symbol from Redis"""
        try:
            raw = self.redis_client.get(f"market_data:{symbol}")
            if not raw:
                return None
            if isinstance(raw, bytes):
                try:
                    raw = raw.decode()
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    # If decoding fails, return None
                    return None
            try:
                return json.loads(raw)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # If stored as JSON already or not JSON, attempt to return as-is if dict
                if isinstance(raw, dict):
                    return raw
                return None
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error getting current market data")
            return None

    async def calculate_strategy_performance(self, strategy: dict[str, Any], market_data: dict[str, Any]) -> float:
        """Calculate strategy performance"""
        try:
            # Simplified performance calculation
            action = strategy.get("action", "hold")
            confidence = strategy.get("confidence", 0)

            # Get price change
            current_price = market_data.get("price", 0)
            previous_price = market_data.get("previous_price", current_price)

            price_change = (current_price - previous_price) / previous_price if previous_price > 0 else 0

            # Calculate performance based on action and price change
            if action == "buy" and price_change > 0:
                performance = confidence * price_change
            elif action == "sell" and price_change < 0:
                performance = confidence * abs(price_change)
            elif action == "hold":
                performance = 0
            else:
                performance = -confidence * abs(price_change)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error calculating strategy performance")
            return 0.0
        else:
            return performance

    async def cleanup_old_strategies(self):
        """Clean up old strategies"""
        try:
            current_time = datetime.now(tz=timezone.utc)
            lifetime = self.coordination_config["coordination_settings"]["strategy_lifetime"]

            # Remove expired strategies
            expired_strategies = []
            for strategy_id, strategy_info in list(self.state["ai_strategies"].items()):
                created_at = datetime.fromisoformat(strategy_info["created_at"])
                if (current_time - created_at).total_seconds() > lifetime:
                    expired_strategies.append(strategy_id)

            for strategy_id in expired_strategies:
                del self.state["ai_strategies"][strategy_id]

            if expired_strategies:
                logger.info(f"Cleaned up {len(expired_strategies)} expired strategies")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error cleaning up old strategies")

    async def coordinate_ai_agents(self):
        """Coordinate all AI agents"""
        try:
            # Update agent statuses
            for agent_name in self.ai_agents:
                # Check agent heartbeat
                heartbeat = self.redis_client.get(f"agent_heartbeat:{agent_name}")
                if heartbeat:
                    self.ai_agents[agent_name]["status"] = "active"
                    self.ai_agents[agent_name]["last_communication"] = datetime.now(tz=timezone.utc).isoformat()
                else:
                    self.ai_agents[agent_name]["status"] = "inactive"

            self.state["coordination_count"] += 1
            self.state["last_coordination"] = datetime.now(tz=timezone.utc).isoformat()
            logger.debug(f"Coordinated {len(self.ai_agents)} AI agents")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error coordinating AI agents")

    async def generate_ai_strategies(self):
        """Generate AI strategies for all trading symbols"""
        try:
            for symbol in self.trading_symbols:
                await self.generate_symbol_ai_strategy(symbol)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error generating AI strategies")

    async def generate_symbol_ai_strategy(self, symbol: str):
        """Generate AI strategy for a specific symbol"""
        try:
            import uuid

            strategy_id = f"ai_strategy_{symbol}_{uuid.uuid4().hex[:8]}"

            # Get market data
            market_data = await self.get_current_market_data(symbol)

            strategy = {
                "id": strategy_id,
                "symbol": symbol,
                "created_at": datetime.now(tz=timezone.utc).isoformat(),
                "action": "hold",
                "confidence": 0.5,
                "components": {},
                "market_data": market_data,
            }

            self.state["ai_strategies"][strategy_id] = strategy
            logger.debug(f"Generated AI strategy for {symbol}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception(f"Error generating AI strategy for {symbol}")

    async def evaluate_strategy_performance(self):
        """Evaluate performance of all active strategies"""
        try:
            for strategy_id, strategy in list(self.state["ai_strategies"].items()):
                symbol = strategy.get("symbol")
                if symbol:
                    market_data = await self.get_current_market_data(symbol)
                    if market_data:
                        performance = await self.calculate_strategy_performance(strategy, market_data)
                        if strategy_id not in self.performance_history:
                            self.performance_history[strategy_id] = []
                        self.performance_history[strategy_id].append(performance)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error evaluating strategy performance")

    async def process_ai_update(self, message: dict[str, Any]):
        """Process AI update from agents"""
        try:
            update_type = message.get("type")
            payload = message.get("payload", {})
            logger.debug(f"Processing AI update: {update_type}")

            if update_type == "ai_prediction":
                # Store prediction
                symbol = payload.get("symbol") if isinstance(payload, dict) else None
                if symbol:
                    self.state["agent_coordination"][f"prediction_{symbol}"] = payload
            elif update_type == "ai_strategy":
                # Store strategy
                strategy_id = payload.get("id") if isinstance(payload, dict) else None
                if strategy_id:
                    self.state["ai_strategies"][strategy_id] = payload

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error processing AI update")

    async def request_deep_learning_prediction(self, agent_name: str, symbol: str):
        """Request prediction from deep learning agent"""
        try:
            await self.send_message(
                agent_name,
                {
                    "type": "prediction_request",
                    "symbol": symbol,
                    "from_agent": self.agent_id,
                },
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.debug(f"Could not request deep learning prediction for {symbol}")

    async def request_reinforcement_learning_strategy(self, agent_name: str, symbol: str):
        """Request strategy from reinforcement learning agent"""
        try:
            await self.send_message(
                agent_name,
                {
                    "type": "strategy_request",
                    "symbol": symbol,
                    "from_agent": self.agent_id,
                },
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.debug(f"Could not request RL strategy for {symbol}")

    async def request_nlp_sentiment(self, agent_name: str, symbol: str):
        """Request sentiment from NLP agent"""
        try:
            await self.send_message(
                agent_name,
                {
                    "type": "sentiment_request",
                    "symbol": symbol,
                    "from_agent": self.agent_id,
                },
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.debug(f"Could not request NLP sentiment for {symbol}")

    async def request_computer_vision_analysis(self, agent_name: str, symbol: str):
        """Request analysis from computer vision agent"""
        try:
            await self.send_message(
                agent_name,
                {
                    "type": "analysis_request",
                    "symbol": symbol,
                    "from_agent": self.agent_id,
                },
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.debug(f"Could not request CV analysis for {symbol}")

    async def handle_coordinate_ai_agents(self, message: dict[str, Any]):
        """Handle manual AI coordination request"""
        try:
            logger.info("[TARGET] Manual AI coordination requested")

            # Perform coordination
            await self.coordinate_ai_agents()

            response = {
                "type": "ai_coordination_response",
                "status": "completed",
                "active_agents": len([a for a in self.ai_agents.values() if a["status"] == "active"]),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling AI coordination request")
            await self.broadcast_error(f"AI coordination error: {e}")

    async def handle_generate_ai_strategy(self, message: dict[str, Any]):
        """Handle manual AI strategy generation request"""
        try:
            symbol = message.get("symbol")

            logger.info(f"🧩 Manual AI strategy generation requested for {symbol}")

            if symbol:
                await self.generate_symbol_ai_strategy(symbol)

                response = {
                    "type": "ai_strategy_generation_response",
                    "symbol": symbol,
                    "status": "completed",
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                }
            else:
                response = {
                    "type": "ai_strategy_generation_response",
                    "symbol": symbol,
                    "status": "failed",
                    "error": "No symbol provided",
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling AI strategy generation request")
            await self.broadcast_error(f"AI strategy generation error: {e}")

    async def handle_get_ai_status(self, message: dict[str, Any]):
        """Handle AI status request"""
        try:
            logger.info("[STATS] AI status requested")

            # Get AI status
            ai_status = {
                "agents": self.ai_agents,
                "strategies_count": len(self.state["ai_strategies"]),
                "coordination_count": self.state["coordination_count"],
                "last_coordination": self.state["last_coordination"],
                "performance_history": {k: len(v) for k, v in self.performance_history.items()},
            }

            response = {
                "type": "ai_status_response",
                "status": ai_status,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling AI status request")
            await self.broadcast_error(f"AI status error: {e}")

    async def handle_ai_prediction(self, message: dict[str, Any]):
        """Handle AI prediction update"""
        try:
            await self.process_ai_update(message)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling AI prediction")

    async def handle_ai_strategy(self, message: dict[str, Any]):
        """Handle AI strategy update"""
        try:
            await self.process_ai_update(message)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling AI strategy")

    async def handle_model_deployment(self, message: dict[str, Any]):
        """Handle model deployment update"""
        try:
            await self.process_ai_update(message)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling model deployment")

    async def update_coordination_metrics(self):
        """Update coordination metrics"""
        try:
            metrics = {
                "agent_id": self.agent_id,
                "ai_agents_count": len(self.ai_agents),
                "active_agents_count": len([a for a in self.ai_agents.values() if a["status"] == "active"]),
                "strategies_count": len(self.state["ai_strategies"]),
                "coordination_count": self.state["coordination_count"],
                "last_coordination": self.state["last_coordination"],
                "symbols_count": len(self.trading_symbols),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Store metrics in Redis
            self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics), ex=300)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error updating coordination metrics")

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process incoming market data and coordinate AI agents"""
        try:
            logger.info(f"[UP] Processing market data for {len(market_data)} symbols")

            # Update market data in state
            self.state["last_market_data"] = market_data
            self.state["last_market_update"] = datetime.now(tz=timezone.utc).isoformat()

            # Process each symbol with AI agents
            for symbol, _data in market_data.items():
                if symbol in self.trading_symbols:
                    # Generate AI strategy for this symbol
                    await self.generate_symbol_ai_strategy(symbol)

                    # Request predictions from AI agents
                    await self.request_deep_learning_prediction("deep_learning_agent", symbol)
                    await self.request_reinforcement_learning_strategy("reinforcement_learning_agent", symbol)
                    await self.request_nlp_sentiment("nlp_agent", symbol)
                    await self.request_computer_vision_analysis("computer_vision_agent", symbol)

            # Coordinate AI agents
            await self.coordinate_ai_agents()

            # Update coordination metrics
            await self.update_coordination_metrics()

            logger.info("[OK] Market data processed successfully")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error processing market data")
            await self.broadcast_error(f"Market data processing error: {e}")
