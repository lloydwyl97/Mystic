import asyncio
import contextlib
import json
import logging
from datetime import datetime, timezone
from typing import Any

from backend.agents.advanced_ai_orchestrator import AdvancedAIOrchestrator
from backend.agents.ai_model_manager import AIModelManager
from backend.agents.auranet_channel import AuraNetChannel
from backend.agents.base_agent import BaseAgent
from backend.agents.chart_pattern_agent import ChartPatternAgent
from backend.agents.compliance_agent import ComplianceAgent
from backend.agents.computer_vision_orchestrator import ComputerVisionOrchestrator
from backend.agents.cosmic_pattern_recognizer import CosmicPatternRecognizer
from backend.agents.deep_learning_agent import DeepLearningAgent
from backend.agents.execution_agent import ExecutionAgent
from backend.agents.interdimensional_signal_decoder import (
    InterdimensionalSignalDecoder,
)
from backend.agents.market_sentiment_agent import MarketSentimentAgent
from backend.agents.market_visualization_agent import MarketVisualizationAgent
from backend.agents.neuro_synchronization_engine import NeuroSynchronizationEngine
from backend.agents.news_sentiment_agent import NewsSentimentAgent
from backend.agents.nlp_orchestrator import NLPOrchestrator
from backend.agents.quantum_algorithm_engine import QuantumAlgorithmEngine
from backend.agents.quantum_machine_learning_agent import QuantumMachineLearningAgent
from backend.agents.quantum_optimization_agent import QuantumOptimizationAgent

# QuantumTradingEngine module not found - commenting out
# from backend.agents.quantum_trading_engine import QuantumTradingEngine
from backend.agents.reinforcement_learning_agent import ReinforcementLearningAgent
from backend.agents.risk_agent import RiskAgent
from backend.agents.social_media_agent import SocialMediaAgent
from backend.agents.strategy_agent import StrategyAgent
from backend.agents.technical_indicator_agent import TechnicalIndicatorAgent
from backend.services.task_manager import task_manager

logger = logging.getLogger(__name__)

"""
Agent Orchestrator
Manages all AI agents, coordinates communication, and provides central control
"""

# Add parent directory to path for imports


class AgentOrchestrator(BaseAgent):
    """Agent Orchestrator - Coordinates all AI agents"""

    def __init__(self, agent_id: str = "orchestrator_001") -> None:
        super().__init__(agent_id, "orchestrator")

        self.state.update(
            {
                "agents": {},
                "agent_status": {},
                "system_status": "initializing",
                "agent_communication": {},
                "performance_metrics": [],
                "last_coordination": None,
            },
        )

        # Initialize agents
        self.strategy_agent = None
        self.risk_agent = None
        self.execution_agent = None
        self.compliance_agent = None
        self.news_sentiment_agent = None
        self.social_media_agent = None
        self.market_sentiment_agent = None
        self.deep_learning_agent = None
        # PHASE 1: Initialize RL agent (shadow mode - no impact on trading)
        self.reinforcement_learning_agent = None  # Will be initialized in initialize()
        self.ai_model_manager = None
        self.advanced_ai_orchestrator = None
        self.nlp_orchestrator = None
        self.chart_pattern_agent = None
        self.technical_indicator_agent = None
        self.market_visualization_agent = None
        self.computer_vision_orchestrator = None
        self.quantum_algorithm_engine = None
        self.quantum_machine_learning_agent = None
        self.quantum_optimization_agent = None
        # self.quantum_trading_engine = None  # Module not found - disabled
        self.interdimensional_signal_decoder = None
        self.neuro_synchronization_engine = None
        self.cosmic_pattern_recognizer = None
        self.auranet_channel = None

        # Internal monitoring task handle
        self._monitoring_task: asyncio.Task | None = None

        # Register orchestrator-specific handlers
        self.register_handler("agent_status_update", self.handle_agent_status_update)
        self.register_handler("system_command", self.handle_system_command)
        self.register_handler("performance_report", self.handle_performance_report)
        self.register_handler("agent_communication", self.handle_agent_communication)

        logger.info(f"ðŸŽ¼ Agent Orchestrator {agent_id} initialized")

    async def initialize(self):
        """Initialize orchestrator and all agents"""
        try:
            # Initialize all agents
            await self.initialize_agents()

            # Start agent monitoring (background)
            await self.start_agent_monitoring()

            # Initialize system coordination (stub / placeholder)
            await self.initialize_system_coordination()

            logger.info(f"âœ” Agent Orchestrator {self.agent_id} initialized successfully")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error initializing Agent Orchestrator")
            try:
                self.update_health_status("error")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to update health status during initialization error handling")

    async def process_loop(self):
        """Main orchestrator processing loop"""
        while getattr(self, "running", True):
            try:
                # Monitor all agents
                await self.monitor_agents()

                # Coordinate agent communication
                await self.coordinate_agents()

                # Update system metrics
                await self.update_system_metrics()

                # Check system health
                await self.check_system_health()

                await asyncio.sleep(30)  # Check every 30 seconds

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Error in orchestrator processing loop")
                await asyncio.sleep(60)

    async def initialize_agents(self):
        """Initialize all AI agents"""
        try:
            logger.info("ðŸ§ Initializing AI agents...")

            # Initialize Strategy Agent
            self.strategy_agent = StrategyAgent("strategy_agent_001")
            await self.strategy_agent.start()
            self.state["agents"]["strategy"] = self.strategy_agent
            self.state["agent_status"]["strategy"] = "running"

            # Initialize Risk Agent
            self.risk_agent = RiskAgent("risk_agent_001")
            await self.risk_agent.start()
            self.state["agents"]["risk"] = self.risk_agent
            self.state["agent_status"]["risk"] = "running"

            # Initialize Execution Agent
            self.execution_agent = ExecutionAgent("execution_agent_001")
            await self.execution_agent.start()
            self.state["agents"]["execution"] = self.execution_agent
            self.state["agent_status"]["execution"] = "running"

            # Initialize Compliance Agent
            self.compliance_agent = ComplianceAgent("compliance_agent_001")
            await self.compliance_agent.start()
            self.state["agents"]["compliance"] = self.compliance_agent
            self.state["agent_status"]["compliance"] = "running"

            # Initialize News Sentiment Agent
            self.news_sentiment_agent = NewsSentimentAgent("news_sentiment_agent_001")
            await self.news_sentiment_agent.start()
            self.state["agents"]["news_sentiment"] = self.news_sentiment_agent
            self.state["agent_status"]["news_sentiment"] = "running"

            # Initialize Social Media Agent
            self.social_media_agent = SocialMediaAgent("social_media_agent_001")
            await self.social_media_agent.start()
            self.state["agents"]["social_media"] = self.social_media_agent
            self.state["agent_status"]["social_media"] = "running"

            # Initialize Market Sentiment Agent
            self.market_sentiment_agent = MarketSentimentAgent("market_sentiment_agent_001")
            await self.market_sentiment_agent.start()
            self.state["agents"]["market_sentiment"] = self.market_sentiment_agent
            self.state["agent_status"]["market_sentiment"] = "running"

            # Initialize Deep Learning Agent
            self.deep_learning_agent = DeepLearningAgent("deep_learning_agent_001")
            await self.deep_learning_agent.start()
            self.state["agents"]["deep_learning"] = self.deep_learning_agent
            self.state["agent_status"]["deep_learning"] = "running"

            # Initialize Reinforcement Learning Agent
            self.reinforcement_learning_agent = ReinforcementLearningAgent("reinforcement_learning_agent_001")
            await self.reinforcement_learning_agent.start()
            self.state["agents"]["reinforcement_learning"] = self.reinforcement_learning_agent
            self.state["agent_status"]["reinforcement_learning"] = "running"

            # Initialize AI Model Manager
            self.ai_model_manager = AIModelManager("ai_model_manager_001")
            await self.ai_model_manager.start()
            self.state["agents"]["ai_model_manager"] = self.ai_model_manager
            self.state["agent_status"]["ai_model_manager"] = "running"

            # Initialize Advanced AI Orchestrator
            self.advanced_ai_orchestrator = AdvancedAIOrchestrator("advanced_ai_orchestrator_001")
            await self.advanced_ai_orchestrator.start()
            self.state["agents"]["advanced_ai_orchestrator"] = self.advanced_ai_orchestrator
            self.state["agent_status"]["advanced_ai_orchestrator"] = "running"

            # Initialize NLP Orchestrator
            self.nlp_orchestrator = NLPOrchestrator("nlp_orchestrator_001")
            await self.nlp_orchestrator.start()
            self.state["agents"]["nlp_orchestrator"] = self.nlp_orchestrator
            self.state["agent_status"]["nlp_orchestrator"] = "running"

            # Initialize Chart Pattern Agent
            self.chart_pattern_agent = ChartPatternAgent("chart_pattern_agent_001")
            await self.chart_pattern_agent.start()
            self.state["agents"]["chart_pattern"] = self.chart_pattern_agent
            self.state["agent_status"]["chart_pattern"] = "running"

            # Initialize Technical Indicator Agent
            self.technical_indicator_agent = TechnicalIndicatorAgent("technical_indicator_agent_001")
            await self.technical_indicator_agent.start()
            self.state["agents"]["technical_indicator"] = self.technical_indicator_agent
            self.state["agent_status"]["technical_indicator"] = "running"

            # Initialize Market Visualization Agent
            self.market_visualization_agent = MarketVisualizationAgent("market_visualization_agent_001")
            await self.market_visualization_agent.start()
            self.state["agents"]["market_visualization"] = self.market_visualization_agent
            self.state["agent_status"]["market_visualization"] = "running"

            # Initialize Computer Vision Orchestrator
            self.computer_vision_orchestrator = ComputerVisionOrchestrator("computer_vision_orchestrator_001")
            await self.computer_vision_orchestrator.start()
            self.state["agents"]["computer_vision_orchestrator"] = self.computer_vision_orchestrator
            self.state["agent_status"]["computer_vision_orchestrator"] = "running"

            # Initialize Quantum and related engines
            self.quantum_algorithm_engine = QuantumAlgorithmEngine("quantum_algorithm_engine_001")
            await self.quantum_algorithm_engine.start()
            self.state["agents"]["quantum_algorithm_engine"] = self.quantum_algorithm_engine
            self.state["agent_status"]["quantum_algorithm_engine"] = "running"

            self.quantum_machine_learning_agent = QuantumMachineLearningAgent("quantum_ml_agent_001")
            await self.quantum_machine_learning_agent.start()
            self.state["agents"]["quantum_ml"] = self.quantum_machine_learning_agent
            self.state["agent_status"]["quantum_ml"] = "running"

            self.quantum_optimization_agent = QuantumOptimizationAgent("quantum_optimization_agent_001")
            await self.quantum_optimization_agent.start()
            self.state["agents"]["quantum_optimization"] = self.quantum_optimization_agent
            self.state["agent_status"]["quantum_optimization"] = "running"

            # Quantum Trading Engine - disabled (module not found)
            # self.quantum_trading_engine = QuantumTradingEngine("quantum_trading_engine_001")
            # await self.quantum_trading_engine.start()
            # self.state["agents"]["quantum_trading"] = self.quantum_trading_engine
            self.state["agent_status"]["quantum_trading"] = "running"

            # Initialize additional agents / channels
            self.interdimensional_signal_decoder = InterdimensionalSignalDecoder("interdimensional_decoder_001")
            await self.interdimensional_signal_decoder.start()
            self.state["agents"]["interdimensional_decoder"] = self.interdimensional_signal_decoder
            self.state["agent_status"]["interdimensional_decoder"] = "running"

            self.neuro_synchronization_engine = NeuroSynchronizationEngine("neuro_sync_engine_001")
            await self.neuro_synchronization_engine.start()
            self.state["agents"]["neuro_sync"] = self.neuro_synchronization_engine
            self.state["agent_status"]["neuro_sync"] = "running"

            self.cosmic_pattern_recognizer = CosmicPatternRecognizer("cosmic_pattern_recognizer_001")
            await self.cosmic_pattern_recognizer.start()
            self.state["agents"]["cosmic_pattern_recognizer"] = self.cosmic_pattern_recognizer
            self.state["agent_status"]["cosmic_pattern_recognizer"] = "running"

            self.auranet_channel = AuraNetChannel("auranet_channel_001")
            await self.auranet_channel.start()
            self.state["agents"]["auranet_channel"] = self.auranet_channel
            self.state["agent_status"]["auranet_channel"] = "running"

            logger.info("âœ” All configured AI agents initialized")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error initializing agents")
            raise

    async def start_agent_monitoring(self):
        """Start background monitoring task for agents"""
        if self._monitoring_task and not self._monitoring_task.done():
            return
        self._monitoring_task = await task_manager.create_task(self._agent_monitoring_loop(), name="agent_orchestrator:agent_monitoring_loop")
        # Allow the caller to await once so exceptions can surface during startup if any
        await asyncio.sleep(0)

    async def _agent_monitoring_loop(self):
        """Background task to monitor agents periodically"""
        try:
            while getattr(self, "running", True):
                await self.monitor_agents()
                await asyncio.sleep(10)
        except asyncio.CancelledError:
            logger.info("Agent monitoring loop cancelled")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error in agent monitoring loop")

    async def initialize_system_coordination(self):
        """Initialize any required system coordination logic (stub)"""
        self.state["last_coordination"] = datetime.now(tz=timezone.utc).isoformat()
        logger.info("âœ” System coordination initialized")

    async def monitor_agents(self):
        """Poll or verify agent statuses and update internal state"""
        try:
            for name, agent in list(self.state.get("agents", {}).items()):
                status = getattr(agent, "state", {}).get("status", None)
                # fallback to running/stopped if agent provides running attribute
                if status is None:
                    status = "running" if getattr(agent, "running", False) else "stopped"
                self.state["agent_status"][name] = status
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error monitoring agents")

    async def coordinate_agents(self):
        """Coordinate communication between agents (stub)"""
        try:
            # Update last coordination time
            self.state["last_coordination"] = datetime.now(tz=timezone.utc).isoformat()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error coordinating agents")

    async def handle_agent_status_update(self, message: dict[str, Any]):
        """Handle incoming agent status update messages"""
        try:
            agent_name = message.get("agent_name")
            status = message.get("status")
            if agent_name:
                self.state["agent_status"][agent_name] = status
                # Optionally keep history
                history = self.state.setdefault("agent_status_history", [])
                history.append({"agent": agent_name, "status": status, "timestamp": datetime.now(tz=timezone.utc).isoformat()})
                # Keep history bounded
                if len(history) > 500:
                    self.state["agent_status_history"] = history[-500:]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling agent status update")

    async def handle_system_command(self, message: dict[str, Any]):
        """Handle system-level commands"""
        try:
            command = message.get("command")
            payload = message.get("payload", {})
            if command == "stop_system":
                await self.stop_system()
            elif command == "start_system":
                await self.start_system()
            elif command == "send_status":
                await self.send_system_status(payload.get("target"))
            elif command == "update_config":
                await self.update_system_config(payload.get("config", {}))
            else:
                logger.info(f"Unknown system command received: {command}")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling system command")

    async def handle_performance_report(self, message: dict[str, Any]):
        """Handle performance report messages from agents"""
        try:
            report = message.get("report", {})
            timestamp = message.get("timestamp", datetime.now(tz=timezone.utc).isoformat())
            metrics = self.state.setdefault("performance_metrics", [])
            metrics.append({"report": report, "timestamp": timestamp})
            # Keep metrics bounded to avoid memory growth
            if len(metrics) > 2000:
                self.state["performance_metrics"] = metrics[-1000:]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling performance report")

    async def handle_agent_communication(self, message: dict[str, Any]):
        """Log and optionally route agent-to-agent communication"""
        try:
            from_agent = message.get("from_agent")
            to_agent = message.get("to_agent")
            message_type = message.get("type")
            body = message.get("body", {})

            # Save last communication
            comms = self.state.setdefault("agent_communication", [])
            comm_entry = {
                "from": from_agent,
                "to": to_agent,
                "type": message_type,
                "body": body,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }
            comms.append(comm_entry)
            # Keep comms bounded
            if len(comms) > 2000:
                self.state["agent_communication"] = comms[-1000:]

            # Log communication to Redis if client available
            redis_client = getattr(self, "redis_client", None)
            if redis_client:
                try:
                    redis_client.lpush("agent_communication_log", json.dumps(comm_entry))
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.debug(f"Failed to push comm log to redis: {e}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling agent communication")

    async def stop_system(self):
        """Stop the entire system"""
        try:
            logger.info("Stopping AI trading system...")

            # Stop all agents
            for agent_name, agent in list(self.state.get("agents", {}).items()):
                try:
                    await agent.stop()
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception(f"Error stopping agent {agent_name}")

            # Update system status
            self.state["system_status"] = "stopped"

            # Broadcast system stopped
            await self.broadcast_message(
                {
                    "type": "system_stopped",
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                },
            )

            logger.info("âœ” AI trading system stopped")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error stopping system")

    async def start_system(self):
        """Start the entire system"""
        try:
            logger.info("ðŸš€ Starting AI trading system...")

            # Start all agents
            for agent_name, agent in list(self.state.get("agents", {}).items()):
                try:
                    await agent.start()
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception(f"Error starting agent {agent_name}")

            # Update system status
            self.state["system_status"] = "operational"

            # Broadcast system started
            await self.broadcast_message(
                {
                    "type": "system_started",
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                },
            )

            logger.info("âœ” AI trading system started")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error starting system")

    async def send_system_status(self, target_agent: str | None = None):
        """Send system status"""
        try:
            status = {
                "type": "system_status",
                "system_status": self.state.get("system_status"),
                "agent_status": self.state.get("agent_status"),
                "performance_metrics": self.state.get("performance_metrics"),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            if target_agent:
                await self.send_message(target_agent, status)
            else:
                await self.broadcast_message(status)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error sending system status")

    async def update_system_config(self, config: dict[str, Any]):
        """Update system configuration"""
        try:
            # Update orchestrator configuration
            if "orchestrator" in config:
                self.state.update(config["orchestrator"])

            # Update agent configurations
            for agent_name, agent_config in config.get("agents", {}).items():
                if agent_name in self.state.get("agents", {}):
                    agent = self.state["agents"][agent_name]
                    try:
                        agent.state.update(agent_config)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        logger.debug(f"Failed to update agent state for {agent_name}")

            # Store configuration in Redis if available
            redis_client = getattr(self, "redis_client", None)
            if redis_client:
                try:
                    redis_client.set("system_config", json.dumps(config), ex=3600)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.debug(f"Failed to persist system config to redis: {e}")

            logger.info("âœ” System configuration updated")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error updating system config")

    async def check_system_health(self):
        """Check overall system health"""
        try:
            # Calculate system health score
            health_score = 0
            total_agents = len(self.state.get("agent_status", {})) or 1

            for status in self.state.get("agent_status", {}).values():
                if status in {"healthy", "running"}:
                    health_score += 100
                elif status == "degraded":
                    health_score += 50
                else:
                    health_score += 0

            health_score = health_score // total_agents

            # Update system health
            if health_score >= 90:
                self.state["system_status"] = "operational"
            elif health_score >= 50:
                self.state["system_status"] = "degraded"
            else:
                self.state["system_status"] = "critical"

            # Broadcast health update
            await self.broadcast_message(
                {
                    "type": "system_health_update",
                    "health_score": health_score,
                    "system_status": self.state.get("system_status"),
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                },
            )

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error checking system health")

    async def update_system_metrics(self):
        """Update system metrics"""
        try:
            metrics = {
                "agent_id": self.agent_id,
                "system_status": self.state.get("system_status"),
                "agent_status": self.state.get("agent_status"),
                "performance_metrics": self.state.get("performance_metrics"),
                "last_coordination": self.state.get("last_coordination"),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            redis_client = getattr(self, "redis_client", None)
            if redis_client:
                try:
                    redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics), ex=300)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.debug("Failed to update metrics in redis")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error updating system metrics")

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process incoming market data and distribute to agents"""
        try:
            logger.info("ðŸ“Š Processing market data for agent orchestration")

            # Update market data in state
            self.state["last_market_data"] = market_data
            self.state["last_market_update"] = datetime.now(tz=timezone.utc).isoformat()

            # Distribute market data to all agents
            for agent_name, agent in list(self.state.get("agents", {}).items()):
                try:
                    if hasattr(agent, "process_market_data"):
                        await agent.process_market_data(market_data)
                        logger.info(f"âœ” Market data sent to {agent_name}")
                    else:
                        logger.info(f"Agent {agent_name} doesn't have process_market_data method")
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception(f"Error sending market data to {agent_name}")

            # Update system metrics
            await self.update_system_metrics()

            # Check system health after processing
            await self.check_system_health()

            logger.info("âœ” Market data processed for agent orchestration")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error processing market data for orchestration")
            await self.broadcast_error(f"Agent orchestration market data error: {e}")

    async def broadcast_error(self, message: str):
        """Broadcast an error message to all agents (best-effort)"""
        try:
            payload = {"type": "error", "message": message, "timestamp": datetime.now(tz=timezone.utc).isoformat()}
            await self.broadcast_message(payload)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.debug(f"Failed to broadcast error message: {e}")

    async def stop(self):
        """Stop the orchestrator and all agents"""
        try:
            logger.info("Stopping Agent Orchestrator...")

            # Cancel monitoring task if running
            if self._monitoring_task and not self._monitoring_task.done():
                self._monitoring_task.cancel()
                with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    await self._monitoring_task

            # Stop all agents
            for agent_name, agent in list(self.state.get("agents", {}).items()):
                try:
                    await agent.stop()
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception(f"Error stopping agent {agent_name}")

            # Stop orchestrator (BaseAgent stop)
            await super().stop()

            logger.info("âœ” Agent Orchestrator stopped")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error stopping orchestrator")


async def main():
    """Main function to run the agent orchestrator"""
    orchestrator: AgentOrchestrator | None = None
    try:
        # Create and start orchestrator
        orchestrator = AgentOrchestrator()
        await orchestrator.start()

        # Keep running with memory management
        while True:
            await asyncio.sleep(1)

            # Periodic memory cleanup
            if hasattr(orchestrator, "state") and "performance_metrics" in orchestrator.state:
                # Clean up old performance metrics to prevent memory accumulation
                pm = orchestrator.state.get("performance_metrics", [])
                if isinstance(pm, list) and len(pm) > 1000:
                    # Keep only the last 500 metrics
                    orchestrator.state["performance_metrics"] = pm[-500:]

                # Clean up old agent status history
                if "agent_status_history" in orchestrator.state:
                    ash = orchestrator.state.get("agent_status_history", [])
                    if isinstance(ash, list) and len(ash) > 100:
                        orchestrator.state["agent_status_history"] = ash[-100:]

    except KeyboardInterrupt:
        logger.info("Shutting down...")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        logger.exception("Error in main")
    finally:
        if orchestrator:
            try:
                await orchestrator.stop()
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.debug("Error during orchestrator stop in main cleanup")


if __name__ == "__main__":
    asyncio.run(main())
