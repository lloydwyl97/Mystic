import asyncio
import hashlib
import json
import logging
import shutil
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import joblib  # type: ignore[reportMissingTypeStubs]
import torch

from backend.agents.base_agent import BaseAgent
from backend.core.constants import MIN_AI_ACCURACY_FOR_RETRAINING
from backend.utils.path_helpers import ensure_model_directories, get_model_base_path

logger = logging.getLogger(__name__)

"""
AI Model Manager
Handles model versioning, deployment, and lifecycle management
"""

# Add parent directory to path for imports


class ModelVersion:
    """Model version information"""

    def __init__(
        self,
        model_id: str,
        version: str,
        model_type: str,
        metadata: dict[str, Any],
    ) -> None:
        self.model_id = model_id
        self.version = version
        self.model_type = model_type
        self.metadata = metadata
        self.created_at = datetime.now(timezone.utc).isoformat()
        self.status = "created"
        self.performance_metrics = {}
        self.deployment_status = "not_deployed"
        self.model_size: int | None = None
        self.last_updated: datetime | None = None
        self.retention_period: timedelta = timedelta(days=30)


class ModelRegistry:
    """Model registry for versioning and tracking"""

    def __init__(self, registry_path: str) -> None:
        self.registry_path = Path(registry_path)
        self.registry_path.mkdir(parents=True, exist_ok=True)
        self.models = {}
        self.load_registry()

    def load_registry(self):
        """Load model registry from disk"""
        try:
            registry_file = self.registry_path / "registry.json"
            if registry_file.exists():
                with registry_file.open() as f:
                    registry_data = json.load(f)
                    self.models = registry_data
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error loading model registry")

    def save_registry(self):
        """Save model registry to disk"""
        try:
            registry_file = self.registry_path / "registry.json"
            with registry_file.open("w") as f:
                json.dump(self.models, f, indent=2)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error saving model registry")

    def register_model(
        self,
        model_id: str,
        version: str,
        model_type: str,
        metadata: dict[str, Any],
    ) -> ModelVersion | None:
        """Register a new model version"""
        try:
            model_version = ModelVersion(model_id, version, model_type, metadata)

            if model_id not in self.models:
                self.models[model_id] = {}

            self.models[model_id][version] = {
                "model_type": model_type,
                "metadata": metadata,
                "created_at": model_version.created_at,
                "status": model_version.status,
                "performance_metrics": model_version.performance_metrics,
                "deployment_status": model_version.deployment_status,
            }

            self.save_registry()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error registering model")
            return None
        else:
            return model_version

    def get_model_versions(self, model_id: str) -> list[str]:
        """Get all versions of a model"""
        try:
            if model_id in self.models:
                return list(self.models[model_id].keys())
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error getting model versions")
            return []
        else:
            return []

    def get_latest_version(self, model_id: str) -> str | None:
        """Get the latest version of a model"""
        try:
            versions = self.get_model_versions(model_id)
            if versions:
                return max(
                    versions,
                    key=lambda v: self.models[model_id][v].get("created_at", ""),
                )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error getting latest version")
            return None
        else:
            return None

    def update_model_status(self, model_id: str, version: str, status: str):
        """Update model status"""
        try:
            if model_id in self.models and version in self.models[model_id]:
                self.models[model_id][version]["status"] = status
                self.save_registry()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error updating model status")

    def update_performance_metrics(self, model_id: str, version: str, metrics: dict[str, Any]):
        """Update model performance metrics"""
        try:
            if model_id in self.models and version in self.models[model_id]:
                self.models[model_id][version]["performance_metrics"] = metrics
                self.save_registry()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error updating performance metrics")


class AIModelManager(BaseAgent):
    """AI Model Manager - Handles model versioning and deployment"""

    def __init__(self, agent_id: str = "ai_model_manager_001") -> None:
        super().__init__(agent_id, "ai_model_manager")

        self.state.update(
            {
                "models_managed": {},
                "deployments_active": {},
                "model_metrics": {},
                "last_deployment": None,
                "deployment_count": 0,
            },
        )
        self._initialized = False
        self._init_model_config()

    async def initialize(self):
        """Initialize agent-specific resources"""
        if not self._initialized:
            logger.info(f"Initializing {self.agent_id}...")
            self._initialized = True
            logger.info(f"{self.agent_id} initialized")

    async def process_loop(self):
        """Main processing loop for agent-specific logic"""
        while True:
            try:
                await asyncio.sleep(60)  # Run every 60 seconds
                # Model health check and retraining triggers
                logger.debug(f"{self.agent_id} processing loop iteration")
            except Exception:
                logger.exception(f"Error in {self.agent_id} process loop")
                await asyncio.sleep(10)

    def _init_model_config(self):
        """Initialize model configuration"""
        # Model management configuration
        self.model_config = {
            "model_types": {
                "deep_learning": {
                    "extensions": [".pth", ".pt"],
                    "framework": "pytorch",
                    "supported_formats": ["state_dict", "full_model"],
                },
                "reinforcement_learning": {
                    "extensions": [".pth", ".pt"],
                    "framework": "pytorch",
                    "supported_formats": ["state_dict", "full_model"],
                },
                "machine_learning": {
                    "extensions": [".pkl", ".joblib"],
                    "framework": "sklearn",
                    "supported_formats": ["pickle", "joblib"],
                },
                "computer_vision": {
                    "extensions": [".pth", ".pt", ".onnx"],
                    "framework": "pytorch",
                    "supported_formats": ["state_dict", "full_model", "onnx"],
                },
            },
            "deployment_settings": {
                "auto_deploy": True,
                "deployment_threshold": (0.8),  # Performance threshold for auto-deployment
                "rollback_threshold": (0.6),  # Performance threshold for rollback
                "max_versions": 10,  # Maximum versions to keep
                "backup_enabled": True,
            },
            "monitoring_settings": {
                "performance_tracking": True,
                "drift_detection": True,
                "health_checks": True,
                "alerting": True,
            },
        }

        # Initialize model registry
        models_dir = get_model_base_path()
        ensure_model_directories()  # Ensure all subdirectories exist
        self.registry = ModelRegistry(models_dir)

        # Model storage paths
        self.models_path = Path(models_dir)
        self.models_path.mkdir(parents=True, exist_ok=True)

        # Register model manager-specific handlers
        self.register_handler("register_model", self.handle_register_model)
        self.register_handler("deploy_model", self.handle_deploy_model)
        self.register_handler("get_model_info", self.handle_get_model_info)
        self.register_handler("update_metrics", self.handle_update_metrics)

        logger.info(f"AI Model Manager {self.agent_id} initialized")

    async def validate_model_file(self, model_path: str, model_type: str) -> tuple[bool, str]:
        """Validate model file using appropriate framework"""
        try:
            model_file = Path(model_path)
            if not model_file.exists():
                return False, "Model file does not exist"

            # Check file extension
            file_ext = model_file.suffix.lower()
            if model_type not in self.model_config["model_types"]:
                return False, f"Unknown model type: {model_type}"

            supported_extensions = self.model_config["model_types"][model_type]["extensions"]

            if file_ext not in supported_extensions:
                return False, f"Unsupported file extension: {file_ext}"

            # Validate based on model type
            if model_type in [
                "deep_learning",
                "reinforcement_learning",
                "computer_vision",
            ]:
                # PyTorch model validation for .pth/.pt
                if file_ext in [".pth", ".pt"]:
                    try:
                        model_data = torch.load(str(model_file), map_location="cpu")
                        # Accept dicts (state_dict) or torch.nn.Module objects
                        if isinstance(model_data, dict) or hasattr(model_data, "state_dict"):
                            return True, "Valid PyTorch model"
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                        return False, f"PyTorch load error: {e}"
                    else:
                        return False, "Loaded object is not a recognized PyTorch model"
                # ONNX file: basic validation by checking existence and extension
                if file_ext == ".onnx":
                    return True, "ONNX model file present"

            elif model_type == "machine_learning":
                # joblib/pickle
                try:
                    _ = joblib.load(str(model_file))
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    return False, f"Joblib/pickle load error: {e}"
                else:
                    return True, "Valid scikit-learn model (joblib/pickle)"

            # Fallback: if reached here assume file exists and extension supported
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error validating model file")
            return False, "Validation error"
        else:
            return True, "Valid model file"

    async def handle_register_model(self, message: dict[str, Any]):
        """Handle register model message"""
        try:
            model_id = message.get("model_id")
            version = message.get("version")
            model_type = message.get("model_type")
            metadata = message.get("metadata", {})

            logger.info(f"ðŸ“¥ Registering model {model_id} v{version}")

            if not model_id or not version or not model_type:
                logger.error("Missing required parameters for model registration")
                return

            mv = self.registry.register_model(model_id, version, model_type, metadata)

            # Update internal state
            self.state["models_managed"].setdefault(model_id, {})
            self.state["models_managed"][model_id][version] = {
                "model_type": model_type,
                "metadata": metadata,
                "registered_at": datetime.now(timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            response = {
                "type": "register_model_response",
                "model_id": model_id,
                "version": version,
                "status": "registered" if mv else "failed",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling register model")
            await self.broadcast_error(f"Register model error: {e}")

    async def handle_deploy_model(self, message: dict[str, Any]):
        """Handle model deployment request"""
        try:
            model_id = message.get("model_id")
            version = message.get("version")
            model_type = message.get("model_type")
            model_path = message.get("model_path")
            metadata = message.get("metadata", {})

            logger.info(f"ðŸš€ Deploy request for model {model_id} v{version}")

            sender = message.get("from_agent")

            if not model_id or not version or not model_type or not model_path:
                response = {
                    "type": "deploy_model_response",
                    "model_id": model_id,
                    "version": version,
                    "status": "failed",
                    "error": "Missing required parameters",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
                if sender:
                    await self.send_message(sender, response)
                return

            # Validate model file
            valid, reason = await self.validate_model_file(model_path, model_type)
            if not valid:
                response = {
                    "type": "deploy_model_response",
                    "model_id": model_id,
                    "version": version,
                    "status": "failed",
                    "error": f"Validation failed: {reason}",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
                if sender:
                    await self.send_message(sender, response)
                return

            # Prepare target directory and copy model file
            target_dir = self.models_path / model_id / version
            target_dir.mkdir(parents=True, exist_ok=True)
            src = Path(model_path)
            dst = target_dir / src.name
            shutil.copy2(str(src), str(dst))

            # Compute model size and checksum
            model_size = dst.stat().st_size
            sha256_hash = hashlib.sha256()
            with dst.open("rb") as f:
                for chunk in iter(lambda: f.read(8192), b""):
                    sha256_hash.update(chunk)
            checksum = sha256_hash.hexdigest()

            # Register model in registry (or update metadata)
            # mv = self.registry.register_model(model_id, version, model_type, metadata or {})  # Commented out unused variable
            # Update registry entry with size/checksum
            try:
                if model_id in self.registry.models and version in self.registry.models[model_id]:
                    self.registry.models[model_id][version].update(
                        {
                            "model_size": model_size,
                            "checksum": checksum,
                            "file_name": dst.name,
                            "deployed_at": datetime.now(timezone.utc).isoformat(),
                        }
                    )
                    self.registry.save_registry()
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # Non-critical
                pass

            # Update manager state about the deployment
            self.state["models_managed"].setdefault(model_id, {})
            self.state["models_managed"][model_id][version] = {
                "model_type": model_type,
                "metadata": metadata,
                "path": str(dst),
                "deployed_at": datetime.now(timezone.utc).isoformat(),
            }

            # Mark deployment active
            self.state["deployments_active"][model_id] = {
                "version": version,
                "model_path": str(dst),
                "deployed_at": datetime.now(timezone.utc).isoformat(),
            }
            self.state["last_deployment"] = datetime.now(timezone.utc).isoformat()
            self.state["deployment_count"] = self.state.get("deployment_count", 0) + 1

            logger.info(f"âœ… Model {model_id} v{version} deployed")

            response = {
                "type": "deploy_model_response",
                "model_id": model_id,
                "version": version,
                "status": "deployed",
                "model_path": str(dst),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling deployment")

    async def handle_get_model_info(self, message: dict[str, Any]):
        """Handle model info request"""
        try:
            model_id = message.get("model_id")

            logger.info(f"ðŸ”Ž Model info requested for {model_id}")

            if model_id and model_id in self.state["models_managed"]:
                model_info = self.state["models_managed"][model_id]
                deployment_info = self.state["deployments_active"].get(model_id, {})

                response = {
                    "type": "model_info_response",
                    "model_id": model_id,
                    "model_info": model_info,
                    "deployment_info": deployment_info,
                    "registry_info": self.registry.models.get(model_id, {}),
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
            else:
                response = {
                    "type": "model_info_response",
                    "model_id": model_id,
                    "model_info": None,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling model info request")
            await self.broadcast_error(f"Model info error: {e}")

    async def handle_update_metrics(self, message: dict[str, Any]):
        """Handle metrics update request"""
        try:
            model_id = message.get("model_id")
            version = message.get("version")
            metrics = message.get("metrics", {})

            logger.info(f"Metrics update for {model_id} v{version}")

            if model_id and version and metrics:
                # Update performance metrics
                self.registry.update_performance_metrics(model_id, version, metrics)

                # Store in Redis for monitoring if redis_client available
                try:
                    metrics_key = f"model_metrics:{model_id}:{version}"
                    if hasattr(self, "redis_client") and self.redis_client:
                        self.redis_client.set(metrics_key, json.dumps(metrics), ex=3600)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    pass

                response = {
                    "type": "metrics_update_response",
                    "model_id": model_id,
                    "version": version,
                    "status": "updated",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
            else:
                response = {
                    "type": "metrics_update_response",
                    "model_id": model_id,
                    "version": version,
                    "status": "failed",
                    "error": "Missing required parameters",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling metrics update")
            await self.broadcast_error(f"Metrics update error: {e}")

    async def update_model_metrics(self):
        """Update model manager metrics"""
        try:
            metrics = {
                "agent_id": self.agent_id,
                "models_managed": len(self.state["models_managed"]),
                "deployments_active": len(self.state["deployments_active"]),
                "deployment_count": self.state["deployment_count"],
                "last_deployment": self.state["last_deployment"],
                "registry_size": len(self.registry.models),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            # Store metrics in Redis if available
            try:
                if hasattr(self, "redis_client") and self.redis_client:
                    self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics), ex=300)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pass

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error updating model metrics")

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process incoming market data for model management"""
        try:
            logger.info("ðŸ”Ž Processing market data for model management")

            # Update market data in state
            self.state["last_market_data"] = market_data
            self.state["last_market_update"] = datetime.now(timezone.utc).isoformat()

            # Check if any models need retraining based on market conditions
            for model_id, model_info in self.state["models_managed"].items():
                if model_info.get("auto_retrain", False):
                    # Analyze market data for model performance
                    performance_metrics = await self.analyze_model_performance(model_id, market_data)

                    if performance_metrics.get("needs_retraining", False):
                        logger.info(f"â†º Model {model_id} needs retraining based on market data")
                        await self.handle_model_retraining_request(model_id, performance_metrics)

            # Update model metrics
            await self.update_model_metrics()

            logger.info("âœ” Market data processed for model management")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error processing market data for model management")
            await self.broadcast_error(f"Model management market data error: {e}")

    async def analyze_model_performance(self, model_id: str, market_data: dict[str, Any]) -> dict[str, Any]:
        """Analyze model performance based on market data"""
        try:
            # Get actual model predictions and compare with market data
            # NO MOCK DATA - calculate real metrics or fail

            # Check if we have historical predictions for this model
            predictions = self.state.get(f"predictions_{model_id}", [])

            if not predictions:
                return {
                    "model_id": model_id,
                    "error": "No historical predictions available for performance analysis",
                    "needs_retraining": True,
                    "confidence": 0.0,
                }

            # Calculate actual accuracy from recent predictions vs outcomes
            recent_predictions = predictions[-100:]  # Last 100 predictions
            correct = sum(1 for p in recent_predictions if p.get("correct", False))
            accuracy = correct / len(recent_predictions) if recent_predictions else 0.0

            # Determine if retraining is needed based on actual performance
            needs_retraining = accuracy < MIN_AI_ACCURACY_FOR_RETRAINING

            # Calculate confidence from prediction certainty
            avg_confidence = sum(p.get("confidence", 0.0) for p in recent_predictions) / len(recent_predictions) if recent_predictions else 0.0

            return {
                "model_id": model_id,
                "accuracy": accuracy,
                "needs_retraining": needs_retraining,
                "confidence": avg_confidence,
                "predictions_analyzed": len(recent_predictions),
                "market_conditions": self._assess_market_conditions(market_data),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error analyzing model performance")
            return {
                "model_id": model_id,
                "accuracy": 0.0,
                "needs_retraining": False,
                "confidence": 0.0,
                "market_conditions": "unknown",
            }

    def _assess_market_conditions(self, market_data: dict[str, Any]) -> str:
        """Assess current market conditions from data"""
        try:
            # Analyze volatility and trend from market data
            change_pct = market_data.get("change_24h", 0)

            # Simple condition assessment
            if abs(change_pct) > 5:
                return "volatile"
            if abs(change_pct) < 1:
                return "stable"
            if change_pct > 0:
                return "bullish"
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            return "unknown"
        else:
            return "bearish"

    async def handle_model_retraining_request(self, model_id: str, performance_metrics: dict[str, Any]):
        """Handle model retraining request"""
        try:
            logger.info(f"â†º Initiating retraining for model {model_id}")

            # Broadcast retraining request
            await self.broadcast_message(
                {
                    "type": "model_retraining_request",
                    "model_id": model_id,
                    "performance_metrics": performance_metrics,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                },
            )

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling model retraining request")
            await self.broadcast_error(f"Model retraining error: {e}")

    async def get_latest_model(self) -> dict[str, Any] | None:
        """Get the latest model information with accuracy metrics"""
        try:
            # Get all models from registry
            if not self.registry.models:
                return None

            # Find the most recent model across all model_ids
            latest_model = None
            latest_time = None

            for model_id, versions in self.registry.models.items():
                for version, data in versions.items():
                    created_at = data.get("created_at", "")
                    if latest_time is None or created_at > latest_time:
                        latest_time = created_at
                        latest_model = {
                            "model_id": model_id,
                            "version": version,
                            "accuracy": data.get("performance_metrics", {}).get("accuracy", 0.0),
                            "timestamp": created_at,
                            "model_type": data.get("model_type"),
                        }
        except Exception:
            logger.exception("Error getting latest model")
            return None
        else:
            return latest_model


# Global instance for singleton pattern - using dict to avoid global keyword
_ai_model_manager_state: dict[str, AIModelManager | None] = {"instance": None}


def get_ai_model_manager() -> AIModelManager | None:
    """Get the global AI model manager instance"""
    if _ai_model_manager_state["instance"] is None:
        _ai_model_manager_state["instance"] = AIModelManager()
    return _ai_model_manager_state["instance"]


async def main():
    """Main function"""
    agent = AIModelManager()
    await agent.start()


if __name__ == "__main__":
    asyncio.run(main())
