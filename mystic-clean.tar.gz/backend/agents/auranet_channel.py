import asyncio
import contextlib
import json
import logging
from datetime import datetime, timezone
from typing import Any

import numpy as np

# Add parent directory to path for imports
from backend.agents.base_agent import BaseAgent
from backend.services.task_manager import task_manager

logger = logging.getLogger(__name__)

"""
AuraNet Channel Interface
Biofeedback/EEG-driven API interface for personal energy tuning and system alignment
"""


class AuraNetChannel(BaseAgent):
    """AuraNet Channel Interface - Biofeedback/EEG API for energy tuning and alignment"""

    def __init__(self, agent_id: str = "auranet_channel_001") -> None:
        super().__init__(agent_id, "auranet_channel")
        self.state.update(
            {
                "energy_status": {},
                "biofeedback_history": [],
                "alignment_metrics": {},
                "last_update": None,
                "update_count": 0,
            },
        )
        # Supported input types
        self.input_types = ["manual", "eeg", "bci", "wearable"]
        # Register handlers
        self.register_handler("sync_energy_status", self.handle_sync_energy_status)
        self.register_handler("get_alignment_metrics", self.handle_get_alignment_metrics)
        self.register_handler("update_biofeedback", self.handle_update_biofeedback)
        logger.info(f"AuraNet Channel Interface {agent_id} initialized")

    async def initialize(self):
        try:
            await self.load_auranet_config()
            await self.start_biofeedback_monitoring()
            logger.info(f"AuraNet Channel Interface {self.agent_id} initialized successfully")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error initializing AuraNet Channel")
            self.update_health_status("error")

    async def process_loop(self):
        while self.running:
            try:
                await self.monitor_biofeedback()
                await self.update_alignment_metrics()
                await self.cleanup_old_data()
                await asyncio.sleep(60)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Error in AuraNet processing loop")
                await asyncio.sleep(120)

    async def load_auranet_config(self):
        try:
            config_data = self.redis_client.get("auranet_config")
            if config_data:
                config_text = config_data.decode("utf-8") if isinstance(config_data, (bytes, bytearray)) else config_data
                try:
                    parsed = json.loads(config_text)
                    if isinstance(parsed, dict):
                        self.state["energy_status"].update(parsed)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.warning("auranet_config exists but could not be parsed as JSON")
            logger.info("AuraNet config loaded")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error loading AuraNet config")

    async def start_biofeedback_monitoring(self):
        try:
            pubsub = self.redis_client.pubsub()
            pubsub.subscribe("biofeedback_data")
            task = await task_manager.create_task(self.listen_biofeedback_data(pubsub), name="auranet_channel:listen_biofeedback_data")
            self._tasks.append(task)
            logger.info("Biofeedback monitoring started")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error starting biofeedback monitoring")

    async def listen_biofeedback_data(self, pubsub):
        try:
            # Use polling with timeout to avoid blocking the event loop
            while self.running:
                try:
                    message = pubsub.get_message(ignore_subscribe_messages=True, timeout=1)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception("Error getting pubsub message")
                    message = None

                if message:
                    try:
                        data_raw = message.get("data")
                        data_text = data_raw.decode("utf-8") if isinstance(data_raw, (bytes, bytearray)) else data_raw
                        data = json.loads(data_text)
                        await self.process_biofeedback_data(data)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        logger.exception("Error processing pubsub message")

                await asyncio.sleep(0.1)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error in biofeedback data listener")
        finally:
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pubsub.close()

    async def process_biofeedback_data(self, data: dict[str, Any]):
        try:
            input_type = data.get("input_type", "manual")
            if input_type not in self.input_types:
                return
            # Store biofeedback
            entry = {
                "input_type": input_type,
                "energy_level": float(data.get("energy_level", 0.5)),
                "focus": float(data.get("focus", 0.5)),
                "stress": float(data.get("stress", 0.5)),
                "timestamp": data.get("timestamp", datetime.now(tz=timezone.utc).isoformat()),
            }
            self.state["biofeedback_history"].append(entry)
            self.state["last_update"] = entry["timestamp"]
            self.state["update_count"] += 1
            # Limit history
            if len(self.state["biofeedback_history"]) > 100:
                self.state["biofeedback_history"] = self.state["biofeedback_history"][-100:]
            # Store in Redis
            key = f"auranet_biofeedback:{entry['timestamp']}"
            try:
                self.redis_client.set(key, json.dumps(entry), ex=3600)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # If redis set fails, log but continue
                logger.warning("Failed to write biofeedback entry to Redis")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error processing biofeedback data")

    async def monitor_biofeedback(self):
        try:
            # Analyze last 10 entries
            history = self.state["biofeedback_history"][-10:]
            if not history:
                return
            avg_energy = np.mean([e["energy_level"] for e in history])
            avg_focus = np.mean([e["focus"] for e in history])
            avg_stress = np.mean([e["stress"] for e in history])
            self.state["energy_status"] = {
                "avg_energy": float(avg_energy),
                "avg_focus": float(avg_focus),
                "avg_stress": float(avg_stress),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }
            # Store in Redis
            try:
                self.redis_client.set(
                    "auranet_energy_status",
                    json.dumps(self.state["energy_status"]),
                    ex=600,
                )
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.warning("Failed to write energy status to Redis")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error monitoring biofeedback")

    async def update_alignment_metrics(self):
        try:
            # Calculate alignment metrics
            status = self.state.get("energy_status", {})
            alignment_score = float(status.get("avg_energy", 0.5)) * 0.5 + float(status.get("avg_focus", 0.5)) * 0.4 - float(status.get("avg_stress", 0.5)) * 0.3
            alignment = {
                "alignment_score": float(alignment_score),
                "energy_bias": float(status.get("avg_energy", 0.5)),
                "focus_bias": float(status.get("avg_focus", 0.5)),
                "stress_bias": float(status.get("avg_stress", 0.5)),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }
            self.state["alignment_metrics"] = alignment
            try:
                self.redis_client.set("auranet_alignment_metrics", json.dumps(alignment), ex=600)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.warning("Failed to write alignment metrics to Redis")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error updating alignment metrics")

    async def cleanup_old_data(self):
        try:
            # Clean up old biofeedback (keep last 100)
            if len(self.state["biofeedback_history"]) > 100:
                self.state["biofeedback_history"] = self.state["biofeedback_history"][-100:]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error cleaning up old data")

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process market data for auranet integration"""
        try:
            logger.debug("AuraNet processing market data")
            self.state["last_market_data"] = market_data
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error processing market data")

    async def handle_sync_energy_status(self, message: dict[str, Any]):
        try:
            input_type = message.get("input_type", "manual")
            energy_level = float(message.get("energy_level", 0.5))
            focus = float(message.get("focus", 0.5))
            stress = float(message.get("stress", 0.5))
            logger.info(f"Manual energy sync: {input_type}, energy={energy_level}, focus={focus}, stress={stress}")
            entry = {
                "input_type": input_type,
                "energy_level": energy_level,
                "focus": focus,
                "stress": stress,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }
            self.state["biofeedback_history"].append(entry)
            self.state["last_update"] = entry["timestamp"]
            self.state["update_count"] += 1
            # Store in Redis
            try:
                self.redis_client.set(
                    f"auranet_biofeedback:{entry['timestamp']}",
                    json.dumps(entry),
                    ex=3600,
                )
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.warning("Failed to write manual biofeedback entry to Redis")
            # Send response
            response = {
                "type": "energy_sync_complete",
                "entry": entry,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }
            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling energy sync")
            try:
                await self.broadcast_error(f"Energy sync error: {e}")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to broadcast error")

    async def handle_get_alignment_metrics(self, message: dict[str, Any]):
        try:
            logger.info("Alignment metrics requested")
            response = {
                "type": "alignment_metrics_response",
                "alignment_metrics": self.state.get("alignment_metrics", {}),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }
            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling alignment metrics request")
            try:
                await self.broadcast_error(f"Alignment metrics error: {e}")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to broadcast error")

    async def handle_update_biofeedback(self, message: dict[str, Any]):
        try:
            logger.info("Biofeedback update received")
            await self.process_biofeedback_data(message)
            response = {
                "type": "biofeedback_update_complete",
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }
            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling biofeedback update")
            try:
                await self.broadcast_error(f"Biofeedback update error: {e}")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to broadcast error")


if __name__ == "__main__":
    agent = AuraNetChannel()
    asyncio.run(agent.start())
