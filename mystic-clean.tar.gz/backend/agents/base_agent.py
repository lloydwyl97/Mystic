import asyncio
import contextlib
import json
import logging
from abc import ABC, abstractmethod
from collections.abc import Awaitable, Callable
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

from backend.services.task_manager import task_manager

logger = logging.getLogger(__name__)

"""
Base Agent Class
Foundation for all AI trading agents
"""

# Load environment variables
load_dotenv(dotenv_path=str(Path(__file__).parent.parent / ".env"))


class BaseAgent(ABC):
    """Base class for all AI trading agents"""

    def __init__(self, agent_id: str, agent_type: str) -> None:
        """Initialize base agent"""
        self.agent_id = agent_id
        self.agent_type = agent_type
        self.running = False
        self.health_status = "healthy"
        self.last_heartbeat = datetime.now(tz=timezone.utc)
        self.message_handlers: dict[str, Callable[[dict[str, Any]], Awaitable[None]]] = {}
        self.state: dict[str, Any] = {}

        # Use shared Redis connection pool to prevent connection exhaustion
        from backend.config.redis_config import get_shared_redis_sync

        self.redis_client = get_shared_redis_sync()
        if self.redis_client is None:
            logger.error(f"CRITICAL: Failed to get Redis client for agent {agent_id}")
            logger.error("Agent will not be able to communicate. Check Redis server is running.")
            raise RuntimeError(f"Redis client initialization failed for agent {agent_id}")

        self.input_channel = f"agent:{agent_id}:input"
        self.output_channel = f"agent:{agent_id}:output"
        self.heartbeat_channel = f"agent:{agent_id}:heartbeat"
        self.status_channel = f"agent:{agent_id}:status"

        # Track background tasks for proper cleanup
        self._tasks: list[asyncio.Task[Any]] = []

        self.register_default_handlers()

        logger.info(f"Agent {self.agent_id} ({self.agent_type}) initialized")

    def register_default_handlers(self) -> None:
        """Register default message handlers"""
        self.register_handler("ping", self.handle_ping)
        self.register_handler("status", self.handle_status_request)
        self.register_handler("shutdown", self.handle_shutdown)
        self.register_handler("update_state", self.handle_state_update)

    def register_handler(self, message_type: str, handler: Callable[[dict[str, Any]], Awaitable[None]]) -> None:
        """Register a message handler"""
        self.message_handlers[message_type] = handler

    async def start(self):
        """Start the agent"""
        logger.info(f"[START] Starting agent {self.agent_id}")
        self.running = True

        # Start message listener
        task1 = await task_manager.create_task(self.listen_for_messages(), name="base_agent:listen_for_messages")
        self._tasks.append(task1)

        # Start heartbeat
        task2 = await task_manager.create_task(self.heartbeat_loop(), name="base_agent:heartbeat_loop")
        self._tasks.append(task2)

        # Start agent-specific processing
        task3 = await task_manager.create_task(self.process_loop(), name="base_agent:process_loop")
        self._tasks.append(task3)

        # Initialize agent state
        await self.initialize()

        # Broadcast agent startup
        await self.broadcast_status("started")

        logger.info(f"[OK] Agent {self.agent_id} started successfully")

    async def stop(self):
        """Stop the agent"""
        logger.info(f"Stopping agent {self.agent_id}")
        self.running = False

        # Cancel and await all background tasks
        for task in self._tasks:
            if not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
                except Exception as e:
                    logger.warning(f"Error cancelling task for {self.agent_id}: {e}")
        self._tasks.clear()

        # Broadcast agent shutdown
        await self.broadcast_status("stopped")

        logger.info(f"[OK] Agent {self.agent_id} stopped")

    async def listen_for_messages(self):
        """Listen for incoming messages using non-blocking polling to avoid blocking the event loop"""
        if self.redis_client is None:
            logger.error(f"Cannot listen for messages: Redis client is None for {self.agent_id}")
            return

        pubsub = self.redis_client.pubsub()
        pubsub.subscribe(self.input_channel)

        logger.info(f"Agent {self.agent_id} listening on {self.input_channel}")

        try:
            while self.running:
                try:
                    message = pubsub.get_message()
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception(f"Error getting message from pubsub for {self.agent_id}")
                    message = None

                if message and message.get("type") == "message":
                    data = message.get("data")
                    parsed = None
                    try:
                        if isinstance(data, (bytes, bytearray)):
                            parsed = json.loads(data.decode())
                        elif isinstance(data, str):
                            parsed = json.loads(data)
                        elif isinstance(data, dict):
                            parsed = data
                        else:
                            # Fallback: try to stringify then load
                            parsed = json.loads(str(data))
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                        logger.exception(f"Error parsing message data for {self.agent_id}")
                        await self.broadcast_error(f"Invalid message format: {e}")
                        parsed = None

                    if isinstance(parsed, dict):
                        await self.process_message(parsed)

                await asyncio.sleep(0.05)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception(f"Error in message listener for {self.agent_id}")
        finally:
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pubsub.close()

    async def process_message(self, message: dict[str, Any]):
        """Process incoming message"""
        if not isinstance(message, dict):
            msg = "Message must be a dict"
            raise TypeError(msg)

        try:
            message_type = message.get("type")
            handler = self.message_handlers.get(message_type)

            if handler:
                await handler(message)
            else:
                logger.info(f"No handler for message type: {message_type}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error processing message in {self.agent_id}")
            await self.broadcast_error(f"Message processing error: {e}")

    async def send_message(self, target_agent: str, message: dict[str, Any]):
        """Send message to another agent"""
        if self.redis_client is None:
            logger.error(f"Cannot send message: Redis client is None for {self.agent_id}")
            return

        try:
            # Make a shallow copy so caller's dict isn't mutated
            msg = dict(message)
            msg.update(
                {
                    "from_agent": self.agent_id,
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                },
            )

            target_channel = f"agent:{target_agent}:input"
            self.redis_client.publish(target_channel, json.dumps(msg))

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception(f"Error sending message to {target_agent}")

    async def broadcast_message(self, message: dict[str, Any]):
        """Broadcast message to all agents"""
        if self.redis_client is None:
            logger.error(f"Cannot broadcast message: Redis client is None for {self.agent_id}")
            return

        try:
            msg = dict(message)
            msg.update(
                {
                    "from_agent": self.agent_id,
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                },
            )

            self.redis_client.publish("agent:broadcast", json.dumps(msg))

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error broadcasting message")

    async def broadcast_status(self, status: str):
        """Broadcast agent status"""
        if self.redis_client is None:
            logger.error(f"Cannot broadcast status: Redis client is None for {self.agent_id}")
            return

        try:
            status_message = {
                "agent_id": self.agent_id,
                "agent_type": self.agent_type,
                "status": status,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                "health": self.health_status,
            }

            self.redis_client.publish(self.status_channel, json.dumps(status_message))
            self.redis_client.set(
                f"agent_status:{self.agent_id}",
                json.dumps(status_message),
                ex=300,
            )

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error broadcasting status")

    async def broadcast_error(self, error_message: str):
        """Broadcast error message"""
        if self.redis_client is None:
            logger.error(f"Cannot broadcast error: Redis client is None for {self.agent_id}")
            return

        try:
            error_data = {
                "agent_id": self.agent_id,
                "agent_type": self.agent_type,
                "error": error_message,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            self.redis_client.publish("agent:errors", json.dumps(error_data))

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error broadcasting error")

    def _get_serializable_state(self) -> dict[str, Any]:
        """Get a JSON-serializable version of the state, filtering out non-serializable objects"""

        def make_serializable(obj: Any) -> Any:
            if obj is None:
                return None
            if isinstance(obj, (str, int, float, bool)):
                return obj
            if isinstance(obj, (list, tuple)):
                return [make_serializable(item) for item in obj]
            if isinstance(obj, dict):
                return {k: make_serializable(v) for k, v in obj.items() if isinstance(k, str)}
            if isinstance(obj, datetime):
                return obj.isoformat()
            # For any other object, return its string representation or type name
            try:
                return f"<{type(obj).__name__}>"
            except Exception:
                return "<non-serializable>"

        return make_serializable(self.state)

    async def heartbeat_loop(self):
        """Send periodic heartbeat"""
        while self.running:
            if self.redis_client is None:
                logger.error(f"Cannot send heartbeat: Redis client is None for {self.agent_id}")
                await asyncio.sleep(60)
                continue

            try:
                heartbeat = {
                    "agent_id": self.agent_id,
                    "agent_type": self.agent_type,
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                    "health": self.health_status,
                    "state": self._get_serializable_state(),
                }

                self.redis_client.publish(self.heartbeat_channel, json.dumps(heartbeat))
                self.redis_client.set(
                    f"agent_heartbeat:{self.agent_id}",
                    json.dumps(heartbeat),
                    ex=60,
                )

                self.last_heartbeat = datetime.now(tz=timezone.utc)

                # Periodic memory cleanup every 10 heartbeats (5 minutes)
                if hasattr(self, "_heartbeat_count"):
                    self._heartbeat_count += 1
                else:
                    self._heartbeat_count = 1

                if self._heartbeat_count % 10 == 0:
                    self.cleanup_memory()

                await asyncio.sleep(30)  # Heartbeat every 30 seconds

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception(f"Error in heartbeat loop for {self.agent_id}")
                await asyncio.sleep(60)

    async def handle_ping(self, message: dict[str, Any]):
        """Handle ping message"""
        response = {
            "type": "pong",
            "agent_id": self.agent_id,
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        }

        sender = message.get("from_agent")
        if sender:
            await self.send_message(sender, response)

    async def handle_status_request(self, message: dict[str, Any]):
        """Handle status request"""
        status = {
            "type": "status_response",
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "status": "running" if self.running else "stopped",
            "health": self.health_status,
            "state": self.state,
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        }

        sender = message.get("from_agent")
        if sender:
            await self.send_message(sender, status)

    async def handle_shutdown(self, _message: dict[str, Any]):
        """Handle shutdown request"""
        logger.info(f"Agent {self.agent_id} received shutdown request")
        await self.stop()

    async def handle_state_update(self, message: dict[str, Any]):
        """Handle state update request"""
        new_state = message.get("state", {})
        if isinstance(new_state, dict):
            self.state.update(new_state)
            logger.info(f"Agent {self.agent_id} state updated: {new_state}")
        else:
            logger.error(f"Invalid state update received by {self.agent_id}: {new_state}")

    @abstractmethod
    async def initialize(self):
        """Initialize agent-specific resources"""

    @abstractmethod
    async def process_loop(self):
        """Main processing loop for agent-specific logic"""

    @abstractmethod
    async def process_market_data(self, market_data: dict[str, Any]):
        """Process market data (to be implemented by subclasses)"""

    def update_health_status(self, status: str):
        """Update agent health status"""
        self.health_status = status
        logger.info(f"Agent {self.agent_id} health status: {status}")

    def get_state(self) -> dict[str, Any]:
        """Get current agent state"""
        return {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "running": self.running,
            "health": self.health_status,
            "last_heartbeat": self.last_heartbeat.isoformat(),
            "state": self.state,
        }

    def is_healthy(self) -> bool:
        """Check if agent is healthy"""
        return self.running and self.health_status == "healthy" and (datetime.now(tz=timezone.utc) - self.last_heartbeat) < timedelta(minutes=2)

    def cleanup_memory(self):
        """Clean up memory to prevent leaks"""
        try:
            # Clean up large data structures in state
            if hasattr(self, "state") and isinstance(self.state, dict):
                for key, value in list(self.state.items()):
                    if isinstance(value, list) and len(value) > 1000:
                        # Keep only the last 500 items for large lists
                        self.state[key] = value[-500:]
                    elif (
                        isinstance(value, dict)
                        and len(value) > 100
                        and key
                        in [
                            "performance_metrics",
                            "training_history",
                            "sentiment_history",
                        ]
                    ):
                        # Keep only the last 100 entries for performance data
                        recent_items = dict(list(value.items())[-100:])
                        self.state[key] = recent_items

            # Clean up message handlers if too many
            if len(self.message_handlers) > 50:
                # Keep only essential handlers
                essential_handlers = ["ping", "status", "shutdown", "update_state"]
                self.message_handlers = {k: v for k, v in self.message_handlers.items() if k in essential_handlers}

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception(f"Memory cleanup error in {self.agent_id}")

    def get_memory_usage(self) -> dict[str, Any]:
        """Get memory usage statistics"""
        try:
            memory_stats = {
                "agent_id": self.agent_id,
                "state_size": len(self.state) if hasattr(self, "state") else 0,
                "message_handlers": len(self.message_handlers),
                "health_status": self.health_status,
            }

            # Calculate state memory usage
            if hasattr(self, "state"):
                total_items = 0
                large_structures = 0
                for _key, value in self.state.items():
                    if isinstance(value, list):
                        total_items += len(value)
                        if len(value) > 100:
                            large_structures += 1
                    elif isinstance(value, dict):
                        total_items += len(value)
                        if len(value) > 50:
                            large_structures += 1

                memory_stats.update(
                    {
                        "total_state_items": total_items,
                        "large_structures": large_structures,
                    },
                )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception(f"Error getting memory usage for {self.agent_id}")
            return {"error": "Failed to get memory usage"}
        else:
            return memory_stats
