import asyncio
import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Any

import cv2
import numpy as np

from backend.agents.base_agent import BaseAgent

logger = logging.getLogger(__name__)

"""
Chart Pattern Agent
Handles chart pattern recognition and technical analysis using computer vision
"""

# Add parent directory to path for imports


class ChartPatternAgent(BaseAgent):
    """Chart Pattern Agent - Analyzes price charts and identifies patterns"""

    def __init__(self, agent_id: str = "chart_pattern_agent_001") -> None:
        super().__init__(agent_id, "chart_pattern")

        self.state.update(
            {
                "patterns_detected": {},
                "chart_cache": {},
                "pattern_templates": {},
                "analysis_history": {},
                "last_analysis": None,
                "analysis_count": 0,
            },
        )

        # Pattern detection configuration
        self.pattern_config = {
            "supported_patterns": [
                "head_and_shoulders",
                "inverse_head_and_shoulders",
                "double_top",
                "double_bottom",
                "triangle_ascending",
                "triangle_descending",
                "triangle_symmetrical",
                "flag_bullish",
                "flag_bearish",
                "wedge_rising",
                "wedge_falling",
                "channel_horizontal",
                "channel_ascending",
                "channel_descending",
            ],
            "confidence_threshold": 0.7,
            "min_pattern_size": 10,  # minimum candles for pattern
            "max_pattern_size": 100,  # maximum candles for pattern
        }

        # Trading symbols to monitor
        self.trading_symbols = [
            "BTC",
            "ETH",
            "ADA",
            "DOT",
            "LINK",
            "UNI",
            "AAVE",
        ]

        # Chart generation settings
        self.chart_settings = {
            "timeframe": "1h",
            "period": 100,  # number of candles
            "chart_type": "candlestick",
            "indicators": ["sma_20", "sma_50", "volume"],
        }

        # Register chart pattern-specific handlers
        self.register_handler("analyze_chart", self.handle_analyze_chart)
        self.register_handler("detect_patterns", self.handle_detect_patterns)
        self.register_handler("get_pattern_signals", self.handle_get_pattern_signals)
        self.register_handler("market_data", self.handle_market_data)

        logger.info(f"ðŸ“Š Chart Pattern Agent {agent_id} initialized")

    async def initialize(self):
        """Initialize chart pattern agent resources"""
        try:
            # Load pattern configuration
            await self.load_pattern_config()

            # Initialize pattern templates
            await self.initialize_pattern_templates()

            # Initialize computer vision models
            await self.initialize_cv_models()

            # Start chart monitoring
            await self.start_chart_monitoring()

            logger.info(f"âœ“ Chart Pattern Agent {self.agent_id} initialized successfully")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error initializing Chart Pattern Agent")
            try:
                self.update_health_status("error")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to update health status")

    async def process_loop(self):
        """Main chart pattern processing loop"""
        while getattr(self, "running", True):
            try:
                # Analyze charts for all symbols
                await self.analyze_all_charts()

                # Update pattern detection models
                await self.update_pattern_models()

                # Generate pattern signals
                await self.generate_pattern_signals()

                # Update pattern metrics
                await self.update_pattern_metrics()

                # Clean up old cache entries
                await self.cleanup_cache()

                await asyncio.sleep(300)  # Check every 5 minutes

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("âŒ Error in chart pattern processing loop")
                await asyncio.sleep(600)

    async def load_pattern_config(self):
        """Load pattern configuration from Redis"""
        try:
            # Load pattern configuration
            config_data = None
            try:
                config_data = self.redis_client.get("chart_pattern_config")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # Redis client might be missing in some environments
                config_data = None

            if config_data:
                try:
                    if isinstance(config_data, bytes):
                        config_data = config_data.decode()
                    self.pattern_config = json.loads(config_data)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception("Failed to load chart_pattern_config from redis")

            # Load trading symbols
            symbols_data = None
            try:
                symbols_data = self.redis_client.get("trading_symbols")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                symbols_data = None
            if symbols_data:
                try:
                    if isinstance(symbols_data, bytes):
                        symbols_data = symbols_data.decode()
                    self.trading_symbols = json.loads(symbols_data)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception("Failed to load trading_symbols from redis")

            # Load chart settings
            chart_data = None
            try:
                chart_data = self.redis_client.get("chart_settings")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                chart_data = None
            if chart_data:
                try:
                    if isinstance(chart_data, bytes):
                        chart_data = chart_data.decode()
                    self.chart_settings = json.loads(chart_data)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception("Failed to load chart_settings from redis")

            logger.info(f"ðŸ“ Pattern configuration loaded: {len(self.pattern_config.get('supported_patterns', []))} patterns, {len(self.trading_symbols)} symbols")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error loading pattern configuration")

    async def initialize_pattern_templates(self):
        """Initialize pattern templates for detection"""
        try:
            # Create pattern templates for each supported pattern
            for pattern in self.pattern_config.get("supported_patterns", []):
                template = await self.create_pattern_template(pattern)
                self.state["pattern_templates"][pattern] = template

            logger.info(f"ðŸ”§ Pattern templates initialized: {len(self.state['pattern_templates'])} templates")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error initializing pattern templates")

    async def create_pattern_template(self, pattern_name: str) -> dict[str, Any]:
        """Create a template for pattern detection"""
        try:
            # Define pattern characteristics
            pattern_templates = {
                "head_and_shoulders": {
                    "type": "reversal",
                    "direction": "bearish",
                    "key_points": 5,
                    "shape": "m_wave",
                    "confidence_factors": ["symmetry", "neckline", "volume"],
                },
                "inverse_head_and_shoulders": {
                    "type": "reversal",
                    "direction": "bullish",
                    "key_points": 5,
                    "shape": "w_wave",
                    "confidence_factors": ["symmetry", "neckline", "volume"],
                },
                "double_top": {
                    "type": "reversal",
                    "direction": "bearish",
                    "key_points": 3,
                    "shape": "m_pattern",
                    "confidence_factors": [
                        "resistance_level",
                        "volume_decline",
                    ],
                },
                "double_bottom": {
                    "type": "reversal",
                    "direction": "bullish",
                    "key_points": 3,
                    "shape": "w_pattern",
                    "confidence_factors": ["support_level", "volume_increase"],
                },
                "triangle_ascending": {
                    "type": "continuation",
                    "direction": "bullish",
                    "key_points": 4,
                    "shape": "triangle_up",
                    "confidence_factors": ["breakout_volume", "support_line"],
                },
                "triangle_descending": {
                    "type": "continuation",
                    "direction": "bearish",
                    "key_points": 4,
                    "shape": "triangle_down",
                    "confidence_factors": [
                        "breakdown_volume",
                        "resistance_line",
                    ],
                },
                "triangle_symmetrical": {
                    "type": "continuation",
                    "direction": "neutral",
                    "key_points": 4,
                    "shape": "triangle_sym",
                    "confidence_factors": [
                        "breakout_direction",
                        "volume_confirmation",
                    ],
                },
                "flag_bullish": {
                    "type": "continuation",
                    "direction": "bullish",
                    "key_points": 3,
                    "shape": "flag_up",
                    "confidence_factors": [
                        "pole_height",
                        "flag_consolidation",
                    ],
                },
                "flag_bearish": {
                    "type": "continuation",
                    "direction": "bearish",
                    "key_points": 3,
                    "shape": "flag_down",
                    "confidence_factors": [
                        "pole_height",
                        "flag_consolidation",
                    ],
                },
                "wedge_rising": {
                    "type": "reversal",
                    "direction": "bearish",
                    "key_points": 4,
                    "shape": "rising_wedge",
                    "confidence_factors": ["slope_convergence", "volume_decline"],
                },
                "wedge_falling": {
                    "type": "reversal",
                    "direction": "bullish",
                    "key_points": 4,
                    "shape": "falling_wedge",
                    "confidence_factors": ["slope_convergence", "volume_decline"],
                },
                "channel_horizontal": {
                    "type": "continuation",
                    "direction": "neutral",
                    "key_points": 4,
                    "shape": "channel_flat",
                    "confidence_factors": ["support_resistance", "volume"],
                },
                "channel_ascending": {
                    "type": "continuation",
                    "direction": "bullish",
                    "key_points": 4,
                    "shape": "channel_up",
                    "confidence_factors": ["trend_slope", "volume_confirmation"],
                },
                "channel_descending": {
                    "type": "continuation",
                    "direction": "bearish",
                    "key_points": 4,
                    "shape": "channel_down",
                    "confidence_factors": ["trend_slope", "volume_confirmation"],
                },
            }

            template = pattern_templates.get(pattern_name)
            if not template:
                # Return a generic template if unknown
                template = {
                    "type": "unknown",
                    "direction": "neutral",
                    "key_points": 0,
                    "shape": "unknown",
                    "confidence_factors": [],
                }

            return template

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error creating pattern template for {pattern_name}")
            return {
                "type": "unknown",
                "direction": "neutral",
                "key_points": 0,
                "shape": "unknown",
                "confidence_factors": [],
            }
        else:
            return template

    # --- Basic stubs and utilities for omitted complex implementations ---
    async def initialize_cv_models(self):
        """Initialize any CV/ML models required for detection (stub)"""
        try:
            # In a real implementation, you'd load ML models or CV templates here.
            logger.info("CV models initialized (stub)")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error initializing CV models")

    async def start_chart_monitoring(self):
        """Start any background tasks for chart monitoring (stub)"""
        try:
            logger.info("Chart monitoring started (stub)")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error starting chart monitoring")

    async def analyze_all_charts(self):
        """Analyze charts for all configured trading symbols"""
        try:
            for symbol in list(self.trading_symbols):
                try:
                    await self.analyze_symbol_chart(symbol)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception(f"Error analyzing chart for {symbol}")
            self.state["analysis_count"] = self.state.get("analysis_count", 0) + 1
            self.state["last_analysis"] = datetime.now(timezone.utc).isoformat()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error analyzing all charts")

    async def analyze_symbol_chart(self, symbol: str):
        """Analyze a single symbol's chart and detect patterns (stub)"""
        try:
            market_data = await self.get_symbol_market_data(symbol)
            if not market_data:
                return

            chart_image = await self.generate_chart_image(symbol, market_data)
            patterns = await self.detect_patterns_in_chart(chart_image, symbol, market_data)
            # Update detected patterns state
            self.state["patterns_detected"][symbol] = patterns or []
            # Share via Redis for cross-process consumption (e.g. ai_signal_generator)
            try:
                data = json.dumps(self.state.get("patterns_detected", {}))
                self.redis_client.set("chart_pattern:patterns_detected", data, ex=300)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pass
            # Cache latest chart info
            cache_entry = {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "patterns": patterns or [],
            }
            self.state["chart_cache"].setdefault(symbol, []).append(cache_entry)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error analyzing symbol chart {symbol}")

    async def get_symbol_market_data(self, symbol: str) -> list[dict[str, Any]] | None:
        """Retrieve market data for a symbol from Redis or other source (stub)"""
        try:
            data = None
            try:
                raw = self.redis_client.get(f"market_data:{symbol}")
                if raw:
                    if isinstance(raw, bytes):
                        raw = raw.decode()
                    data = json.loads(raw)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                data = None

            # If no data found in redis, return None

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error fetching market data for {symbol}")
            return None
            return data

    async def generate_chart_image(self, symbol: str, _market_data: list[dict[str, Any]] | None):
        """Generate a chart image from market data (simple stub returning a blank image)"""
        try:
            # Create a simple blank image as placeholder
            height, width = 400, 600
            image = np.ones((height, width, 3), dtype=np.uint8) * 255
            # Optionally write symbol text
            cv2.putText(image, symbol, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 0), 2)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error generating chart image for {symbol}")
            return None
        else:
            return image

    async def detect_patterns_in_chart(self, _chart_image, _symbol: str, market_data: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
        """Detect chart patterns in the given chart image (very simple heuristic stub)"""
        try:
            patterns = []
            # Basic heuristic: if we have market_data length > min_pattern_size, return one candidate
            length = len(market_data) if market_data else 0
            if length >= self.pattern_config.get("min_pattern_size", 10):
                # Use first supported pattern as a placeholder detection
                supported = self.pattern_config.get("supported_patterns", [])
                if supported:
                    pattern_name = supported[0]
                    template = self.state["pattern_templates"].get(pattern_name, {})
                    confidence = max(0.0, min(1.0, 0.8))
                    if confidence >= self.pattern_config.get("confidence_threshold", 0.7):
                        patterns.append(
                            {
                                "pattern": pattern_name,
                                "confidence": confidence,
                                "template": template,
                                "detected_at": datetime.now(tz=timezone.utc).isoformat(),
                            }
                        )

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error detecting patterns in chart for {symbol}")
            return []
        else:
            return patterns

    async def broadcast_error(self, message: str):
        """Broadcast an error message to other agents (safe stub)"""
        try:
            payload = {"type": "error", "message": message, "timestamp": datetime.now(tz=timezone.utc).isoformat()}
            try:
                await self.broadcast_message(payload)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # If broadcast_message not available, just log
                logger.exception(f"Broadcast fallback: {payload}")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error broadcasting error")

    async def broadcast_pattern_detection(self, symbol: str, patterns: list[dict[str, Any]]):
        """Broadcast detected patterns to other agents (helper)"""
        try:
            pattern_update = {
                "type": "pattern_detection_update",
                "symbol": symbol,
                "patterns": patterns,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            try:
                await self.broadcast_message(pattern_update)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.debug("broadcast_message not available on BaseAgent")

            try:
                await self.send_message("strategy_agent", pattern_update)
                await self.send_message("risk_agent", pattern_update)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.debug("send_message not available or failed for pattern broadcast")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error broadcasting pattern detection")

    async def update_pattern_models(self):
        """Update pattern detection models"""
        try:
            # Update pattern templates based on recent detections
            # In production, you'd implement machine learning model updates here

            logger.info("ðŸ”„ Pattern models updated")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error updating pattern models")

    async def generate_pattern_signals(self):
        """Generate trading signals based on detected patterns"""
        try:
            signals = {}

            for symbol, patterns in self.state.get("patterns_detected", {}).items():
                if patterns:
                    signal = await self.generate_symbol_pattern_signal(symbol, patterns)
                    if signal:
                        signals[symbol] = signal

            # Broadcast signals
            if signals:
                await self.broadcast_pattern_signals(signals)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error generating pattern signals")

    async def generate_symbol_pattern_signal(self, symbol: str, patterns: list[dict[str, Any]]) -> dict[str, Any] | None:
        """Generate trading signal for a symbol based on patterns"""
        try:
            if not patterns:
                return None

            # Find the highest confidence pattern
            best_pattern = max(patterns, key=lambda x: x.get("confidence", 0))

            pattern_name = best_pattern.get("pattern")
            from backend.services.confidence_normalizer import ConfidenceNormalizer

            confidence = ConfidenceNormalizer.normalize(float(best_pattern.get("confidence", 0.0) or 0.0))
            template = best_pattern.get("template", {})

            # Generate signal based on pattern type and direction
            signal_type = "hold"
            strength = confidence

            if template.get("type") in ("reversal", "continuation"):
                if template.get("direction") == "bullish":
                    signal_type = "buy"
                elif template.get("direction") == "bearish":
                    signal_type = "sell"

            return {
                "symbol": symbol,
                "signal_type": signal_type,
                "strength": strength,
                "pattern": pattern_name,
                "confidence": confidence,
                "template": template,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error generating pattern signal for {symbol}")
            return None

    async def broadcast_pattern_signals(self, signals: dict[str, Any]):
        """Broadcast pattern signals to other agents"""
        try:
            signals_update = {
                "type": "pattern_signals_update",
                "signals": signals,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            # Broadcast to all agents
            try:
                await self.broadcast_message(signals_update)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.debug("broadcast_message unavailable")

            # Send to specific agents
            try:
                await self.send_message("strategy_agent", signals_update)
                await self.send_message("execution_agent", signals_update)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.debug("send_message unavailable for specific agents")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error broadcasting pattern signals")

    async def handle_analyze_chart(self, message: dict[str, Any]):
        """Handle manual chart analysis request"""
        try:
            symbol = message.get("symbol")

            logger.info(f"ðŸ” Manual chart analysis requested for {symbol}")

            if symbol:
                await self.analyze_symbol_chart(symbol)

            # Send response
            response = {
                "type": "chart_analysis_complete",
                "symbol": symbol,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                try:
                    await self.send_message(sender, response)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.debug("send_message unavailable to reply analysis completion")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("âŒ Error handling chart analysis request")
            await self.broadcast_error(f"Chart analysis error: {e}")

    async def handle_detect_patterns(self, message: dict[str, Any]):
        """Handle pattern detection request"""
        try:
            symbol = message.get("symbol")
            pattern_types = message.get("patterns", self.pattern_config.get("supported_patterns", []))

            logger.info(f"ðŸ”Ž Pattern detection requested for {symbol}")

            if symbol:
                # Get market data and detect specific patterns
                market_data = await self.get_symbol_market_data(symbol)
                if market_data:
                    chart_image = await self.generate_chart_image(symbol, market_data)
                    if chart_image is not None:
                        patterns = await self.detect_patterns_in_chart(chart_image, symbol, market_data)

                        # Filter by requested pattern types
                        filtered_patterns = [p for p in patterns if p.get("pattern") in pattern_types]

                        # Send response
                        response = {
                            "type": "pattern_detection_response",
                            "symbol": symbol,
                            "patterns": filtered_patterns,
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                        }

                        sender = message.get("from_agent")
                        if sender:
                            try:
                                await self.send_message(sender, response)
                            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                                logger.debug("send_message unavailable to reply pattern detection")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("âŒ Error handling pattern detection request")
            await self.broadcast_error(f"Pattern detection error: {e}")

    async def handle_get_pattern_signals(self, message: dict[str, Any]):
        """Handle pattern signals request"""
        try:
            symbol = message.get("symbol")

            logger.info(f"ðŸ“¡ Pattern signals requested for {symbol}")

            # Get pattern signals
            if symbol and symbol in self.state.get("patterns_detected", {}):
                patterns = self.state["patterns_detected"].get(symbol, [])
                signal = await self.generate_symbol_pattern_signal(symbol, patterns)

                response = {
                    "type": "pattern_signals_response",
                    "symbol": symbol,
                    "signal": signal,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
            else:
                response = {
                    "type": "pattern_signals_response",
                    "symbol": symbol,
                    "signal": None,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

            sender = message.get("from_agent")
            if sender:
                try:
                    await self.send_message(sender, response)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.debug("send_message unavailable to reply pattern signals")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("âŒ Error handling pattern signals request")
            await self.broadcast_error(f"Pattern signals error: {e}")

    async def update_pattern_metrics(self):
        """Update pattern metrics"""
        try:
            metrics = {
                "agent_id": self.agent_id,
                "symbols_count": len(self.trading_symbols),
                "patterns_count": len(self.pattern_config.get("supported_patterns", [])),
                "detected_patterns": len(self.state.get("patterns_detected", {})),
                "analysis_count": self.state.get("analysis_count", 0),
                "last_analysis": self.state.get("last_analysis"),
                "cache_size": len(self.state.get("chart_cache", {})),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            # Store metrics in Redis if available
            try:
                self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics), ex=300)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.debug("redis_client unavailable to store metrics")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error updating pattern metrics")

    async def cleanup_cache(self):
        """Clean up old cache entries"""
        try:
            current_time = datetime.now(timezone.utc)

            # Clean up old chart cache entries
            for symbol in list(self.state.get("chart_cache", {}).keys()):
                data_points = self.state["chart_cache"].get(symbol, [])

                # Keep only recent data points (last 24 hours)
                cutoff_time = current_time - timedelta(hours=24)
                recent_data = []
                for point in data_points:
                    ts = point.get("timestamp")
                    try:
                        if ts:
                            dt = datetime.fromisoformat(ts)
                            if dt > cutoff_time:
                                recent_data.append(point)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        # If timestamp invalid, drop it
                        continue

                if recent_data:
                    self.state["chart_cache"][symbol] = recent_data
                else:
                    self.state["chart_cache"].pop(symbol, None)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error cleaning up cache")

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process market data for chart pattern analysis"""
        try:
            if isinstance(market_data, dict):
                for symbol, data in market_data.items():
                    if symbol in self.trading_symbols:
                        self.state["chart_cache"].setdefault(symbol, []).append(
                            {
                                "timestamp": datetime.now(timezone.utc).isoformat(),
                                "data": data,
                            }
                        )
                        if len(self.state["chart_cache"][symbol]) > 500:
                            self.state["chart_cache"][symbol] = self.state["chart_cache"][symbol][-500:]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error processing market data")

    async def handle_market_data(self, message: dict[str, Any]):
        """Handle incoming market data messages"""
        try:
            symbol = message.get("symbol")
            data = message.get("data")
            if not symbol or data is None:
                return

            # Store data in chart_cache
            self.state["chart_cache"].setdefault(symbol, []).append({"timestamp": datetime.now(timezone.utc).isoformat(), "data": data})

            # Optionally trigger analysis for this symbol
            try:
                await self.analyze_symbol_chart(symbol)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception(f"Error analyzing symbol after market data update: {symbol}")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling market data")
