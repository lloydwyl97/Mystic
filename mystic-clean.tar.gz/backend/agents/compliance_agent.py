import asyncio
import contextlib
import json
import logging
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from backend.agents.base_agent import BaseAgent
from backend.services.task_manager import task_manager

# Lazy import for optional redis helpers (may not be available in all deployments)
try:
    from utils.redis_helpers import to_str_list as _to_str_list_impl
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    _to_str_list_impl = None

logger = logging.getLogger(__name__)

# Add parent directory to path for imports

"""
Compliance Agent
Handles regulatory compliance, trading limits, and audit logging
"""


class ComplianceAgent(BaseAgent):
    """Compliance Agent - Handles regulatory compliance and audit logging"""

    def __init__(self, agent_id: str = "compliance_agent_001") -> None:
        super().__init__(agent_id, "compliance")

        self.state.update(
            {
                "compliance_rules": {},
                "trading_limits": {},
                "audit_log": [],
                "violations": [],
                "regulatory_status": "compliant",
                "last_audit": None,
                "compliance_score": 100,
            },
        )

        # Register compliance-specific handlers
        self.register_handler("validate_trade", self.handle_validate_trade)
        self.register_handler("check_compliance", self.handle_check_compliance)
        self.register_handler("audit_request", self.handle_audit_request)
        self.register_handler("update_limits", self.handle_update_limits)
        self.register_handler("trading_signal", self.handle_trading_signal)

        logger.info(f"âœ“ Compliance Agent {agent_id} initialized")

    async def initialize(self):
        """Initialize compliance agent resources"""
        try:
            # Load compliance rules and limits
            await self.load_compliance_config()

            # Initialize audit system
            await self.initialize_audit_system()

            # Start compliance monitoring
            await self.start_compliance_monitoring()

            logger.info(f"âœ” Compliance Agent {self.agent_id} initialized successfully")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error initializing Compliance Agent")
            # Assuming BaseAgent has update_health_status
            try:
                self.update_health_status("error")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to update health status during initialization error")

    async def process_loop(self):
        """Main compliance processing loop"""
        while getattr(self, "running", True):
            try:
                # Monitor compliance status
                await self.monitor_compliance_status()

                # Check for violations
                await self.check_violations()

                # Update compliance metrics
                await self.update_compliance_metrics()

                # Clean up old audit logs
                await self.cleanup_audit_logs()

                await asyncio.sleep(60)  # Check every minute

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Error in compliance processing loop")
                await asyncio.sleep(120)

    async def load_compliance_config(self):
        """Load compliance configuration from Redis"""
        try:
            # Load compliance rules
            rules_data = self.redis_client.get("compliance_rules")
            if rules_data:
                try:
                    if isinstance(rules_data, bytes):
                        rules_data = rules_data.decode()
                    self.state["compliance_rules"] = json.loads(rules_data)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception("Failed to parse compliance_rules from redis; using defaults")
                    self.state["compliance_rules"] = {}
            else:
                # Set default compliance rules
                self.state["compliance_rules"] = {
                    "max_daily_trades": 100,
                    "max_daily_volume": 100000,
                    "max_position_size": 0.1,
                    "min_rest_period": 300,  # 5 minutes
                    "max_loss_per_day": 0.05,  # 5%
                    "prohibited_symbols": [],
                    "trading_hours": {"start": "00:00", "end": "23:59"},
                }

            # Load trading limits
            limits_data = self.redis_client.get("trading_limits")
            if limits_data:
                try:
                    if isinstance(limits_data, bytes):
                        limits_data = limits_data.decode()
                    self.state["trading_limits"] = json.loads(limits_data)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception("Failed to parse trading_limits from redis; using defaults")
                    self.state["trading_limits"] = {}
            else:
                # Set default trading limits
                self.state["trading_limits"] = {
                    "daily_trades": 0,
                    "daily_volume": 0,
                    "daily_loss": 0,
                    "last_trade_time": None,
                }

            logger.info("ðŸ” Compliance configuration loaded")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error loading compliance configuration")

    async def initialize_audit_system(self):
        """Initialize audit logging system"""
        try:
            # Create audit log directory
            audit_dir = "audit_logs"
            Path(audit_dir).mkdir(parents=True, exist_ok=True)

            # Load existing audit logs
            if _to_str_list_impl is None:
                # If helper not available, fall back to simple decode
                def to_str_list(items):
                    return [item.decode() if isinstance(item, bytes) else str(item) for item in items]
            else:
                to_str_list = _to_str_list_impl

            audit_data = to_str_list(self.redis_client.lrange("audit_log", 0, -1))
            parsed = []
            for item in audit_data:
                try:
                    parsed.append(json.loads(item))
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception("Failed to parse audit log item; skipping")
            self.state["audit_log"] = parsed

            logger.info("ðŸ“ Audit system initialized")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error initializing audit system")

    async def start_compliance_monitoring(self):
        """Start compliance monitoring"""
        try:
            # Subscribe to trading events
            pubsub = self.redis_client.pubsub()
            pubsub.subscribe("trading_events")

            # Start event listener
            task = await task_manager.create_task(self.listen_trading_events(pubsub), name="compliance_agent:listen_trading_events")
            self._tasks.append(task)

            logger.info("Compliance monitoring started")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error starting compliance monitoring")

    async def listen_trading_events(self, pubsub):
        """Listen for trading events"""
        try:
            # Use non-blocking get_message loop to avoid blocking the event loop
            while getattr(self, "running", True):
                try:
                    message = pubsub.get_message(ignore_subscribe_messages=True, timeout=1)
                except TypeError:
                    # Some redis clients may not accept timeout kwarg
                    message = pubsub.get_message(ignore_subscribe_messages=True)
                if not message:
                    await asyncio.sleep(0.1)
                    continue

                if message.get("type") == "message":
                    data = message.get("data")
                    try:
                        if isinstance(data, bytes):
                            data = data.decode()
                        event_data = json.loads(data)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        logger.exception("Failed to decode trading event message")
                        continue

                    await self.process_trading_event(event_data)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error in trading events listener")
        finally:
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pubsub.close()

    async def process_trading_event(self, event_data: dict[str, Any]):
        """Process trading event for compliance"""
        try:
            event_type = event_data.get("type")

            if event_type == "trade_executed":
                if hasattr(self, "audit_trade"):
                    await self.audit_trade(event_data)
            elif event_type == "order_placed":
                if hasattr(self, "audit_order"):
                    await self.audit_order(event_data)
            elif event_type == "position_opened" and hasattr(self, "audit_position"):
                await self.audit_position(event_data)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error processing trading event")

    async def handle_validate_trade(self, message: dict[str, Any]):
        """Handle trade validation request"""
        try:
            trade_data = message.get("trade_data", {})

            logger.info("âœ“ Validating trade compliance")

            # Validate trade
            validation_result = {}
            if hasattr(self, "validate_trade_compliance"):
                validation_result = await self.validate_trade_compliance(trade_data)
            else:
                # Default conservative behavior: approve
                validation_result = {"approved": True, "violations": []}

            # Send response
            response = {
                "type": "trade_validation",
                "approved": validation_result.get("approved", False),
                "reason": validation_result.get("reason", ""),
                "violations": validation_result.get("violations", []),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender and hasattr(self, "send_message"):
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error validating trade")
            if hasattr(self, "broadcast_error"):
                await self.broadcast_error(f"Trade validation error: {e}")

    async def handle_check_compliance(self, message: dict[str, Any]):
        """Handle compliance check request"""
        try:
            check_type = message.get("check_type", "general")

            logger.info(f"ðŸ” Performing compliance check: {check_type}")

            # Perform compliance check
            compliance_status = {}
            if hasattr(self, "perform_compliance_check"):
                compliance_status = await self.perform_compliance_check(check_type)
            else:
                compliance_status = {"status": "compliant", "score": 100, "violations": []}

            # Send response
            response = {
                "type": "compliance_status",
                "status": compliance_status,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender and hasattr(self, "send_message"):
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error checking compliance")
            if hasattr(self, "broadcast_error"):
                await self.broadcast_error(f"Compliance check error: {e}")

    async def handle_audit_request(self, message: dict[str, Any]):
        """Handle audit request"""
        try:
            audit_type = message.get("audit_type", "general")
            start_date = message.get("start_date")
            end_date = message.get("end_date")

            logger.info(f"ðŸ”Ž Performing audit: {audit_type}")

            # Perform audit
            audit_result = await self.perform_audit(audit_type, start_date, end_date)

            # Send response
            response = {
                "type": "audit_response",
                "audit_result": audit_result,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender and hasattr(self, "send_message"):
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling audit request")
            if hasattr(self, "broadcast_error"):
                await self.broadcast_error(f"Audit request error: {e}")

    async def check_compliance_rules(self) -> list[str]:
        """Check compliance rules and return list of violations"""
        try:
            violations = []

            # Example checks - relies on other methods that may be implemented elsewhere
            if hasattr(self, "check_trading_limits"):
                violations.extend(await self.check_trading_limits())

            # Example placeholder checks for daily trade/volume limits
            if hasattr(self, "check_daily_trade_limit") and not await self.check_daily_trade_limit():
                violations.append("Daily trade limit exceeded")

            if hasattr(self, "check_daily_volume_limit") and not await self.check_daily_volume_limit({"value": 0}):
                violations.append("Daily volume limit exceeded")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error checking compliance rules")
            return ["Compliance check error"]
        else:
            return violations

    async def check_trading_limits(self) -> list[str]:
        """Check trading limits"""
        try:
            violations = []

            limits = self.state.get("trading_limits", {})
            rules = self.state.get("compliance_rules", {})

            # Check daily trade limit
            if limits.get("daily_trades", 0) >= rules.get("max_daily_trades", 100):
                violations.append("Daily trade limit reached")

            # Check daily volume limit
            if limits.get("daily_volume", 0) >= rules.get("max_daily_volume", 100000):
                violations.append("Daily volume limit reached")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error checking trading limits")
            return ["Limit check error"]
        else:
            return violations

    async def perform_audit(self, audit_type: str, start_date: str | None = None, end_date: str | None = None) -> dict[str, Any]:
        """Perform an audit"""
        try:
            audit_result = {
                "audit_type": audit_type,
                "start_date": start_date,
                "end_date": end_date,
                "total_entries": 0,
                "violations": [],
                "compliance_score": 0,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Filter audit log by date range
            filtered_log = self.state.get("audit_log", [])

            if start_date and end_date:
                try:
                    start = datetime.fromisoformat(start_date)
                    end = datetime.fromisoformat(end_date)
                    filtered_log = [entry for entry in self.state.get("audit_log", []) if start <= datetime.fromisoformat(entry.get("timestamp", datetime.now(tz=timezone.utc).isoformat())) <= end]
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception("Error parsing audit date range; returning full log")

            audit_result["total_entries"] = len(filtered_log)

            # Analyze violations
            violations = []
            for entry in filtered_log:
                if entry.get("compliance_check", {}).get("violations"):
                    violations.extend(entry["compliance_check"]["violations"])

            audit_result["violations"] = list(set(violations))  # Remove duplicates
            audit_result["compliance_score"] = max(0, 100 - len(audit_result["violations"]) * 5)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error performing audit")
            return {"error": "Audit error"}
        else:
            return audit_result

    async def monitor_compliance_status(self):
        """Monitor compliance status"""
        try:
            # Perform periodic compliance check
            compliance_status = {}
            if hasattr(self, "perform_compliance_check"):
                compliance_status = await self.perform_compliance_check("general")
            else:
                compliance_status = {"status": "compliant", "score": 100, "violations": []}

            # Update state
            self.state["regulatory_status"] = compliance_status.get("status", self.state.get("regulatory_status"))
            self.state["compliance_score"] = compliance_status.get("score", self.state.get("compliance_score"))

            # Check for violations
            if compliance_status.get("violations"):
                await self.create_violation_report(compliance_status["violations"])

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error monitoring compliance status")

    async def check_violations(self):
        """Check for compliance violations"""
        try:
            # Check for new violations
            violations = await self.check_all_compliance_rules() if hasattr(self, "check_all_compliance_rules") else await self.check_compliance_rules()

            if violations:
                await self.create_violation_report(violations)

                # Update compliance status
                self.state["regulatory_status"] = "non_compliant"
                self.state["compliance_score"] = max(0, 100 - len(violations) * 10)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error checking violations")

    async def create_violation_report(self, violations: list[str]):
        """Create a violation report"""
        try:
            violation_report = {
                "report_id": str(uuid.uuid4()),
                "violations": violations,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                "severity": "high" if len(violations) > 3 else "medium",
                "status": "open",
            }

            # Add to violations list
            self.state.setdefault("violations", []).append(violation_report)

            # Store in Redis
            try:
                self.redis_client.lpush("compliance_violations", json.dumps(violation_report))
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to push violation report to redis")

            # Broadcast violation alert
            if hasattr(self, "broadcast_message"):
                await self.broadcast_message({"type": "compliance_violation", "report": violation_report})

            logger.info(f"ðŸš¨ Compliance violation report created: {violation_report['report_id']}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error creating violation report")

    async def update_compliance_metrics(self):
        """Update compliance metrics"""
        try:
            metrics = {
                "agent_id": self.agent_id,
                "regulatory_status": self.state.get("regulatory_status"),
                "compliance_score": self.state.get("compliance_score"),
                "audit_log_count": len(self.state.get("audit_log", [])),
                "violations_count": len(self.state.get("violations", [])),
                "last_audit": self.state.get("last_audit"),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Store metrics in Redis
            try:
                self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics), ex=300)
            except TypeError:
                # Some redis clients don't accept ex kwarg in set; fall back
                try:
                    self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics))
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception("Failed to set agent metrics in redis")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error updating compliance metrics")

    async def cleanup_audit_logs(self):
        """Clean up old audit logs"""
        try:
            current_time = datetime.now(tz=timezone.utc)

            # Keep only last 1000 audit entries
            if len(self.state.get("audit_log", [])) > 1000:
                self.state["audit_log"] = self.state.get("audit_log", [])[-1000:]

            # Remove violations older than 30 days
            violations = self.state.get("violations", [])
            filtered = []
            for violation in violations:
                try:
                    vtime = datetime.fromisoformat(violation["timestamp"])
                    if (current_time - vtime).days < 30:
                        filtered.append(violation)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    # If timestamp parsing fails, keep the violation to review
                    filtered.append(violation)
            self.state["violations"] = filtered

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error cleaning up audit logs")

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process incoming market data for compliance monitoring"""
        try:
            logger.info("ðŸ“Š Processing market data for compliance monitoring")

            # Update market data in state
            self.state["last_market_data"] = market_data
            self.state["last_market_update"] = datetime.now(tz=timezone.utc).isoformat()

            # Check for compliance issues in market data
            for symbol, data in market_data.items():
                # Check for unusual price movements that might indicate market manipulation
                if isinstance(data, dict) and "price" in data and "volume" in data:
                    volume = data["volume"]

                    # Check for unusual volume spikes
                    if volume > self.state.get("max_normal_volume", 1000000) and hasattr(self, "audit_market_anomaly"):
                        await self.audit_market_anomaly(symbol, "high_volume", data)

                    # Check for unusual price movements
                    if "change_24h" in data and abs(data.get("change_24h", 0)) > 20 and hasattr(self, "audit_market_anomaly"):
                        await self.audit_market_anomaly(symbol, "extreme_price_movement", data)

            # Update compliance metrics
            await self.update_compliance_metrics()

            logger.info("âœ” Market data processed for compliance monitoring")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error processing market data for compliance")
            if hasattr(self, "broadcast_error"):
                await self.broadcast_error(f"Compliance market data error: {e}")

    async def audit_market_anomaly(self, symbol: str, anomaly_type: str, data: dict[str, Any]):
        """Audit market anomalies for compliance"""
        try:
            audit_entry = {
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                "symbol": symbol,
                "anomaly_type": anomaly_type,
                "data": data,
                "severity": "high" if anomaly_type == "extreme_price_movement" else "medium",
            }

            # Add to audit log
            self.state.setdefault("audit_log", []).append(audit_entry)

            # Store in Redis
            try:
                self.redis_client.lpush("compliance_audit_log", json.dumps(audit_entry))
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to push market anomaly to redis")

            logger.info(f"ðŸ” Market anomaly audited: {symbol} - {anomaly_type}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error auditing market anomaly")

    async def handle_update_limits(self, message: dict[str, Any]):
        """Handle update limits request"""
        try:
            new_limits = message.get("limits", {})
            logger.info("Updating compliance limits")

            # Update trading limits
            for key, value in new_limits.items():
                if key in self.state.get("trading_limits", {}):
                    self.state["trading_limits"][key] = value

            # Store updated limits in Redis
            try:
                self.redis_client.set("trading_limits", json.dumps(self.state.get("trading_limits", {})))
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to store updated limits")

            # Send response
            response = {
                "type": "limits_updated",
                "limits": self.state.get("trading_limits", {}),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }
            sender = message.get("from_agent")
            if sender and hasattr(self, "send_message"):
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error updating limits")
            if hasattr(self, "broadcast_error"):
                await self.broadcast_error(f"Limits update error: {e}")

    async def handle_trading_signal(self, message: dict[str, Any]):
        """Handle trading signal for compliance validation"""
        try:
            signal_data = message.get("signal", message.get("data", {}))
            logger.debug("Validating trading signal for compliance")

            # Validate the signal against compliance rules
            validation_result = {"approved": True, "violations": []}
            if hasattr(self, "validate_trade_compliance"):
                validation_result = await self.validate_trade_compliance(signal_data)
            else:
                validation_result = {"approved": True, "violations": []}

            # Log the validation
            self.state.setdefault("audit_log", []).append(
                {
                    "type": "trading_signal_validation",
                    "signal": signal_data,
                    "result": validation_result,
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                }
            )

            # Send response
            response = {
                "type": "signal_validation_result",
                "approved": validation_result.get("approved", True),
                "violations": validation_result.get("violations", []),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }
            sender = message.get("from_agent")
            if sender and hasattr(self, "send_message"):
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling trading signal")
            if hasattr(self, "broadcast_error"):
                await self.broadcast_error(f"Trading signal validation error: {e}")
