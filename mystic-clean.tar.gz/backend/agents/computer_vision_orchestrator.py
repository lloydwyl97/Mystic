import asyncio
import contextlib
import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Any

from backend.agents.base_agent import BaseAgent
from backend.services.task_manager import task_manager

logger = logging.getLogger(__name__)

"""
Computer Vision Orchestrator
Coordinates all computer vision agents and provides unified API
"""

# Add parent directory to path for imports


class ComputerVisionOrchestrator(BaseAgent):
    """Computer Vision Orchestrator - Coordinates all CV agents"""

    def __init__(self, agent_id: str = "computer_vision_orchestrator_001") -> None:
        super().__init__(agent_id, "computer_vision_orchestrator")

        # Orchestrator-specific state
        self.state.update(
            {
                "cv_agents": {},
                "analysis_results": {},
                "coordination_history": {},
                "last_coordination": None,
                "coordination_count": 0,
            },
        )

        # CV agent configuration
        self.cv_config = {
            "agents": {
                "chart_pattern_agent": {
                    "type": "chart_pattern",
                    "priority": 1,
                    "enabled": True,
                },
                "technical_indicator_agent": {
                    "type": "technical_indicator",
                    "priority": 2,
                    "enabled": True,
                },
                "market_visualization_agent": {
                    "type": "market_visualization",
                    "priority": 3,
                    "enabled": True,
                },
            },
            "coordination_settings": {
                "analysis_interval": 300,  # 5 minutes
                "result_retention": 3600,  # 1 hour
                "max_concurrent_analyses": 5,
            },
        }

        # Register orchestrator-specific handlers
        self.register_handler("coordinate_analysis", self.handle_coordinate_analysis)
        self.register_handler("get_cv_results", self.handle_get_cv_results)
        self.register_handler("update_cv_config", self.handle_update_cv_config)
        self.register_handler("cv_agent_update", self.handle_cv_agent_update)

        logger.info(f"Computer Vision Orchestrator {agent_id} initialized")

    async def initialize(self):
        """Initialize computer vision orchestrator resources"""
        try:
            # Load CV configuration
            await self.load_cv_config()

            # Initialize CV agent tracking
            await self.initialize_cv_agent_tracking()

            # Start coordination monitoring
            await self.start_coordination_monitoring()

            logger.info(f"âœ“ Computer Vision Orchestrator {self.agent_id} initialized successfully")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error initializing Computer Vision Orchestrator")
            # Assume BaseAgent has this method; if not, ignore
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                self.update_health_status("error")

    async def process_loop(self):
        """Main coordination processing loop"""
        while getattr(self, "running", True):
            try:
                # Coordinate CV agent activities
                await self.coordinate_cv_agents()

                # Aggregate analysis results
                await self.aggregate_analysis_results()

                # Update coordination metrics
                await self.update_coordination_metrics()

                # Clean up old results
                await self.cleanup_old_results()

                await asyncio.sleep(60)  # Check every minute

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Error in coordination processing loop")
                await asyncio.sleep(120)

    async def load_cv_config(self):
        """Load CV configuration from Redis"""
        try:
            # Load CV configuration
            config_data = None
            try:
                config_data = self.redis_client.get("computer_vision_config")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # Redis client may not be available in some testing contexts
                config_data = None

            if config_data:
                # config_data might be bytes if using redis-py
                if isinstance(config_data, (bytes, bytearray)):
                    config_data = config_data.decode("utf-8")
                self.cv_config = json.loads(config_data)

            logger.info(f"CV configuration loaded: {len(self.cv_config.get('agents', {}))} agents")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error loading CV configuration")

    async def initialize_cv_agent_tracking(self):
        """Initialize CV agent tracking"""
        try:
            # Initialize agent tracking for each configured agent
            for agent_id, agent_config in self.cv_config.get("agents", {}).items():
                if agent_config.get("enabled", False):
                    self.state["cv_agents"][agent_id] = {
                        "config": agent_config,
                        "status": "unknown",
                        "last_update": None,
                        "analysis_count": 0,
                        "last_analysis": None,
                    }

            logger.info(f"CV agent tracking initialized: {len(self.state['cv_agents'])} agents")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error initializing CV agent tracking")

    async def start_coordination_monitoring(self):
        """Start coordination monitoring"""
        try:
            # Subscribe to CV agent updates if redis available
            try:
                pubsub = self.redis_client.pubsub()
                pubsub.subscribe("cv_agent_updates")
                # Start agent update listener
                task = await task_manager.create_task(self.listen_cv_agent_updates(pubsub), name="computer_vision_orchestrator:listen_cv_agent_updates")
                self._tasks.append(task)
                logger.info("Coordination monitoring started")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.warning("Redis pubsub not available; coordination monitoring not started")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error starting coordination monitoring")

    async def listen_cv_agent_updates(self, pubsub):
        """Listen for CV agent updates"""
        try:
            for message in pubsub.listen():
                if not getattr(self, "running", True):
                    break

                if message.get("type") == "message":
                    data = message.get("data")
                    try:
                        if isinstance(data, (bytes, bytearray)):
                            data = data.decode("utf-8")
                        agent_update = json.loads(data)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        agent_update = data if isinstance(data, dict) else {}
                    await self.process_cv_agent_update(agent_update)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error in CV agent update listener")
        finally:
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pubsub.close()

    async def process_cv_agent_update(self, agent_update: dict[str, Any]):
        """Process CV agent update"""
        try:
            agent_id = agent_update.get("agent_id")
            update_type = agent_update.get("type")

            if agent_id in self.state["cv_agents"]:
                # Update agent status
                self.state["cv_agents"][agent_id]["status"] = agent_update.get("status", "unknown")
                self.state["cv_agents"][agent_id]["last_update"] = datetime.now(tz=timezone.utc).isoformat()

                # Handle specific update types
                if update_type == "analysis_complete":
                    await self.handle_agent_analysis_complete(agent_id, agent_update)
                elif update_type == "pattern_detected":
                    await self.handle_pattern_detection(agent_id, agent_update)
                elif update_type == "indicator_signal":
                    await self.handle_indicator_signal(agent_id, agent_update)
                elif update_type == "chart_generated":
                    await self.handle_chart_generation(agent_id, agent_update)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error processing CV agent update")

    async def handle_agent_analysis_complete(self, agent_id: str, update: dict[str, Any]):
        """Handle agent analysis completion"""
        try:
            # Update agent analysis count
            self.state["cv_agents"][agent_id]["analysis_count"] += 1
            self.state["cv_agents"][agent_id]["last_analysis"] = datetime.now(timezone.utc).isoformat()

            # Store analysis result
            symbol = update.get("symbol")
            if symbol:
                if symbol not in self.state["analysis_results"]:
                    self.state["analysis_results"][symbol] = {}

                self.state["analysis_results"][symbol][agent_id] = {
                    "result": update.get("result"),
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

            logger.info(f"Analysis complete from {agent_id} for {symbol}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling agent analysis complete")

    async def handle_pattern_detection(self, agent_id: str, update: dict[str, Any]):
        """Handle pattern detection from chart pattern agent"""
        try:
            symbol = update.get("symbol")
            patterns = update.get("patterns", [])

            if symbol and patterns:
                # Store pattern detection result
                if symbol not in self.state["analysis_results"]:
                    self.state["analysis_results"][symbol] = {}

                self.state["analysis_results"][symbol]["pattern_detection"] = {
                    "patterns": patterns,
                    "agent_id": agent_id,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

                # Broadcast pattern detection
                await self.broadcast_pattern_detection(symbol, patterns)

                logger.info(f"Pattern detection stored and broadcasted for {symbol} from {agent_id}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling pattern detection")

    async def handle_indicator_signal(self, agent_id: str, update: dict[str, Any]):
        """Handle indicator signal from technical indicator agent"""
        try:
            symbol = update.get("symbol")
            signal = update.get("signal", {})

            if symbol and signal:
                if symbol not in self.state["analysis_results"]:
                    self.state["analysis_results"][symbol] = {}

                self.state["analysis_results"][symbol]["indicator_signal"] = {
                    "signal": signal,
                    "agent_id": agent_id,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

                # Broadcast indicator signal
                await self.broadcast_indicator_signal(symbol, signal)

                logger.info(f"Indicator signal stored and broadcasted for {symbol} from {agent_id}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling indicator signal")

    async def handle_chart_generation(self, agent_id: str, update: dict[str, Any]):
        """Handle chart generation from market visualization agent"""
        try:
            symbol = update.get("symbol")
            charts = update.get("charts", {})

            if symbol and charts:
                if symbol not in self.state["analysis_results"]:
                    self.state["analysis_results"][symbol] = {}

                self.state["analysis_results"][symbol]["charts"] = {
                    "charts": charts,
                    "agent_id": agent_id,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

                # Broadcast chart generation
                await self.broadcast_chart_generation(symbol, charts)

                logger.info(f"Chart generation stored and broadcasted for {symbol} from {agent_id}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling chart generation")

    async def generate_composite_signal(self, symbol: str):
        """Generate a composite signal for a symbol using available analysis results"""
        try:
            results = self.state["analysis_results"].get(symbol, {})
            composite = {"symbol": symbol, "signals": [], "timestamp": datetime.now(timezone.utc).isoformat()}

            # Combine patterns
            pd = results.get("pattern_detection")
            if pd:
                composite["signals"].append({"type": "pattern", "data": pd.get("patterns", [])})

            # Combine indicators
            ind = results.get("indicator_signal")
            if ind:
                composite["signals"].append({"type": "indicator", "data": ind.get("signal", {})})

            # Simple heuristic: if both pattern and indicator exist, create composite signal
            if pd and ind:
                composite["composite_signal"] = {
                    "recommendation": "consider",
                    "confidence": 0.8,
                    "details": {"patterns": pd.get("patterns"), "indicator": ind.get("signal")},
                }
            elif ind:
                composite["composite_signal"] = {"recommendation": "hold", "confidence": 0.5}
            elif pd:
                composite["composite_signal"] = {"recommendation": "watch", "confidence": 0.4}
            else:
                composite["composite_signal"] = {"recommendation": "none", "confidence": 0.0}

            # Store composite result
            self.state["analysis_results"].setdefault(symbol, {})["composite_signal"] = composite
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error generating composite signal for {symbol}")
            return None
        else:
            return composite

    async def broadcast_pattern_detection(self, symbol: str, patterns: list[dict[str, Any]]):
        """Broadcast pattern detection to other agents"""
        try:
            pattern_update = {
                "type": "pattern_detection_broadcast",
                "symbol": symbol,
                "patterns": patterns,
                "from_orchestrator": self.agent_id,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Broadcast to all agents
            await self.broadcast_message(pattern_update)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error broadcasting pattern detection")

    async def broadcast_indicator_signal(self, symbol: str, signal: dict[str, Any]):
        """Broadcast indicator signal to other agents"""
        try:
            signal_update = {
                "type": "indicator_signal_broadcast",
                "symbol": symbol,
                "signal": signal,
                "from_orchestrator": self.agent_id,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Broadcast to all agents
            await self.broadcast_message(signal_update)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error broadcasting indicator signal")

    async def broadcast_chart_generation(self, symbol: str, charts: dict[str, Any]):
        """Broadcast chart generation to other agents"""
        try:
            chart_update = {
                "type": "chart_generation_broadcast",
                "symbol": symbol,
                "charts": charts,
                "from_orchestrator": self.agent_id,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Broadcast to all agents
            await self.broadcast_message(chart_update)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error broadcasting chart generation")

    async def broadcast_aggregated_results(self, aggregated_results: dict[str, Any]):
        """Broadcast aggregated results to other agents"""
        try:
            aggregated_update = {
                "type": "aggregated_results_update",
                "results": aggregated_results,
                "from_orchestrator": self.agent_id,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Broadcast to all agents
            await self.broadcast_message(aggregated_update)

            # Send to specific agents if send_message available
            try:
                await self.send_message("strategy_agent", aggregated_update)
                await self.send_message("execution_agent", aggregated_update)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # If send_message isn't present or fails, ignore
                pass

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error broadcasting aggregated results")

    async def handle_coordinate_analysis(self, message: dict[str, Any]):
        """Handle manual coordination request"""
        try:
            symbol = message.get("symbol")

            logger.info(f"Manual coordination requested for {symbol}")

            if symbol:
                # Trigger analysis for all agents
                for agent_id, agent_data in self.state["cv_agents"].items():
                    if agent_data["config"].get("enabled", False):
                        await self.trigger_agent_analysis(agent_id, symbol)

                # Wait for results and aggregate
                await asyncio.sleep(10)  # Wait for agents to process
                await self.aggregate_analysis_results()

            # Send response
            response = {
                "type": "coordination_complete",
                "symbol": symbol,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                try:
                    await self.send_message(sender, response)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    # Fallback to broadcast
                    await self.broadcast_message(response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling coordination request")
            await self.broadcast_error(f"Coordination error: {e}")

    async def handle_get_cv_results(self, message: dict[str, Any]):
        """Handle CV results request"""
        try:
            symbol = message.get("symbol")

            logger.info(f"CV results requested for {symbol}")

            # Get CV results
            if symbol and symbol in self.state["analysis_results"]:
                results = self.state["analysis_results"][symbol]

                response = {
                    "type": "cv_results_response",
                    "symbol": symbol,
                    "results": results,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
            else:
                response = {
                    "type": "cv_results_response",
                    "symbol": symbol,
                    "results": None,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

            sender = message.get("from_agent")
            if sender:
                try:
                    await self.send_message(sender, response)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    await self.broadcast_message(response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling CV results request")
            await self.broadcast_error(f"CV results error: {e}")

    async def handle_update_cv_config(self, message: dict[str, Any]):
        """Handle CV configuration update request"""
        try:
            new_config = message.get("config", {})

            logger.info("CV configuration update requested")

            # Update configuration
            if "agents" in new_config:
                self.cv_config.setdefault("agents", {}).update(new_config["agents"])

            if "coordination_settings" in new_config:
                self.cv_config.setdefault("coordination_settings", {}).update(new_config["coordination_settings"])

            # Save to Redis
            try:
                self.redis_client.set("computer_vision_config", json.dumps(self.cv_config))
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.debug("Redis not available; skipping config persist")

            # Update agent tracking
            await self.initialize_cv_agent_tracking()

            # Send response
            response = {
                "type": "cv_config_update_complete",
                "config": self.cv_config,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                try:
                    await self.send_message(sender, response)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    await self.broadcast_message(response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling CV config update")
            await self.broadcast_error(f"CV config update error: {e}")

    async def handle_cv_agent_update(self, message: dict[str, Any]):
        """Handle CV agent update"""
        try:
            agent_id = message.get("agent_id")
            update_data = message.get("update_data", {})

            if agent_id in self.state["cv_agents"]:
                # Update agent data
                self.state["cv_agents"][agent_id].update(update_data)
                self.state["cv_agents"][agent_id]["last_update"] = datetime.now(timezone.utc).isoformat()

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling CV agent update")

    async def update_coordination_metrics(self):
        """Update coordination metrics"""
        try:
            metrics = {
                "agent_id": self.agent_id,
                "cv_agents_count": len(self.cv_config.get("agents", {})),
                "active_agents": len([a for a in self.state["cv_agents"].values() if a.get("status") == "healthy"]),
                "analysis_results_count": len(self.state.get("analysis_results", {})),
                "coordination_count": self.state.get("coordination_count", 0),
                "last_coordination": self.state.get("last_coordination"),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Store metrics in Redis
            try:
                self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics), ex=300)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.debug("Redis not available; skipping metrics persist")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error updating coordination metrics")

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process market data for computer vision analysis"""
        try:
            logger.debug("Computer Vision Orchestrator processing market data")
            self.state["last_market_data"] = market_data
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error processing market data")

    async def cleanup_old_results(self):
        """Clean up old analysis results"""
        try:
            current_time = datetime.now(timezone.utc)
            retention_time = timedelta(seconds=self.cv_config.get("coordination_settings", {}).get("result_retention", 3600))

            # Clean up old results
            for symbol in list(self.state.get("analysis_results", {}).keys()):
                results = self.state["analysis_results"][symbol]

                # Check if results are old
                for result_type, result_data in list(results.items()):
                    if isinstance(result_data, dict) and "timestamp" in result_data:
                        try:
                            result_time = datetime.fromisoformat(result_data["timestamp"])
                        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                            # If timestamp invalid, remove entry
                            del results[result_type]
                            continue
                        if current_time - result_time > retention_time:
                            del results[result_type]

                # Remove symbol if no results left
                if not results:
                    del self.state["analysis_results"][symbol]

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error cleaning up old results")

    # Additional helper implementations to fill omitted functionality

    async def coordinate_cv_agents(self):
        """Coordinate CV agents periodically based on configuration"""
        try:
            now = datetime.now(timezone.utc)
            last = self.state.get("last_coordination")
            interval = self.cv_config.get("coordination_settings", {}).get("analysis_interval", 300)
            should_coord = False

            if last is None:
                should_coord = True
            else:
                try:
                    last_dt = datetime.fromisoformat(last)
                    if (now - last_dt).total_seconds() >= interval:
                        should_coord = True
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    should_coord = True

            if should_coord:
                # Update coordination metadata
                self.state["last_coordination"] = now.isoformat()
                self.state["coordination_count"] = self.state.get("coordination_count", 0) + 1
                logger.info(f"Coordinating CV agents (count={self.state['coordination_count']})")
                # For safety, do not auto-trigger analyses without a symbol context here
                # This method primarily updates coordination cadence.
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error coordinating CV agents")

    async def aggregate_analysis_results(self):
        """Aggregate analysis results and broadcast composite signals where applicable"""
        try:
            aggregated = {}
            for symbol in list(self.state.get("analysis_results", {}).keys()):
                # For each symbol, attempt to create or update composite signal
                composite = await self.generate_composite_signal(symbol)
                aggregated[symbol] = {
                    "results": self.state["analysis_results"].get(symbol, {}),
                    "composite": composite,
                }

            if aggregated:
                await self.broadcast_aggregated_results(aggregated)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error aggregating analysis results")
            return {}
        else:
            return aggregated

    async def trigger_agent_analysis(self, agent_id: str, symbol: str):
        """Trigger a specific CV agent to analyze a symbol"""
        try:
            message = {
                "type": "perform_analysis",
                "symbol": symbol,
                "from_orchestrator": self.agent_id,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            try:
                await self.send_message(agent_id, message)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # Fallback to publishing to a channel named after the agent
                await self._publish_to_redis_channel(f"agent:{agent_id}", message)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error triggering agent analysis for {agent_id} on {symbol}")

    async def broadcast_message(self, payload: dict[str, Any]):
        """Broadcast a message to a general channel for CV agents"""
        try:
            # Prefer existing broadcast_message implementation if present
            bm = getattr(super(), "broadcast_message", None)
            if callable(bm):
                try:
                    await bm(payload)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    pass
                else:
                    return

            # Fallback: publish to redis channel "cv_broadcast"
            await self._publish_to_redis_channel("cv_broadcast", payload)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error broadcasting message")

    async def broadcast_error(self, error_message: str):
        """Broadcast an error message to interested agents or logs"""
        try:
            payload = {
                "type": "orchestrator_error",
                "message": error_message,
                "from_orchestrator": self.agent_id,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }
            await self.broadcast_message(payload)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error broadcasting error")

    async def _publish_to_redis_channel(self, channel: str, payload: dict[str, Any]):
        """Helper to publish a JSON payload to a redis channel if available"""
        try:
            if hasattr(self, "redis_client") and self.redis_client is not None:
                data = json.dumps(payload)
                try:
                    # redis-py publish returns number of subscribers
                    self.redis_client.publish(channel, data)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    # Some redis clients require encoding to bytes
                    self.redis_client.publish(channel, data.encode("utf-8"))
            else:
                logger.debug(f"No redis client available to publish to {channel}: {payload}")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error publishing to redis channel {channel}")
