import asyncio
import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Any

import torch
from sklearn.preprocessing import MinMaxScaler
from torch import nn

# Add parent directory to path for imports (keep before importing BaseAgent)
from backend.agents.base_agent import BaseAgent

logger = logging.getLogger(__name__)

"""
Deep Learning Agent
Handles deep learning models for price prediction and pattern recognition
"""


class LSTMModel(nn.Module):
    """LSTM model for time series prediction"""

    def __init__(
        self,
        input_size: int,
        hidden_size: int,
        num_layers: int,
        output_size: int,
        dropout: float = 0.2,
    ) -> None:
        super().__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers

        self.lstm = nn.LSTM(
            input_size,
            hidden_size,
            num_layers,
            batch_first=True,
            dropout=dropout,
        )
        self.fc = nn.Linear(hidden_size, output_size)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)

        out, _ = self.lstm(x, (h0, c0))
        out = self.dropout(out[:, -1, :])
        return self.fc(out)


class CNNModel(nn.Module):
    """CNN model for pattern recognition"""

    def __init__(self, input_channels: int, num_classes: int) -> None:
        super().__init__()
        self.conv1 = nn.Conv1d(input_channels, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv1d(32, 64, kernel_size=3, padding=1)
        self.conv3 = nn.Conv1d(64, 128, kernel_size=3, padding=1)

        self.pool = nn.MaxPool1d(2)
        self.dropout = nn.Dropout(0.3)
        # The flattened size depends on the sequence length; use a placeholder here.
        # Users should ensure sequence length matches network dimensions or adjust fc1 accordingly.
        self.fc1 = nn.Linear(128 * 12, 256)
        self.fc2 = nn.Linear(256, num_classes)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = self.pool(self.relu(self.conv1(x)))
        x = self.pool(self.relu(self.conv2(x)))
        x = self.pool(self.relu(self.conv3(x)))

        x = x.view(x.size(0), -1)
        x = self.dropout(self.relu(self.fc1(x)))
        return self.fc2(x)


class DeepLearningAgent(BaseAgent):
    """Deep Learning Agent - Uses neural networks for prediction and analysis"""

    def __init__(self, agent_id: str = "deep_learning_agent_001") -> None:
        super().__init__(agent_id, "deep_learning")

        self.state.update(
            {
                "models_trained": {},
                "predictions_made": {},
                "model_cache": {},
                "training_history": {},
                "last_training": None,
                "training_count": 0,
            },
        )

        # Model configuration
        self.model_config = {
            "models": {
                "lstm_price_predictor": {
                    "type": "lstm",
                    "input_size": 10,
                    "hidden_size": 128,
                    "num_layers": 3,
                    "output_size": 1,
                    "sequence_length": 60,
                    "enabled": True,
                },
                "cnn_pattern_recognizer": {
                    "type": "cnn",
                    "input_channels": 5,
                    "num_classes": 14,
                    "sequence_length": 100,
                    "enabled": True,
                },
                "transformer_forecaster": {
                    "type": "transformer",
                    "input_size": 10,
                    "hidden_size": 256,
                    "num_layers": 6,
                    "num_heads": 8,
                    "output_size": 1,
                    "enabled": False,  # Future enhancement
                },
            },
            "training_settings": {
                "batch_size": 32,
                "learning_rate": 0.001,
                "epochs": 100,
                "validation_split": 0.2,
                "early_stopping_patience": 10,
                "min_data_points": 1000,
            },
            "prediction_settings": {
                "prediction_horizon": 24,  # hours
                "confidence_threshold": 0.7,
                "update_frequency": 300,  # seconds
            },
        }

        # Trading symbols to monitor
        self.trading_symbols = [
            "BTC",
            "ETH",
            "ADA",
            "DOT",
            "LINK",
            "UNI",
            "AAVE",
        ]

        # Initialize models and scalers
        self.models = {}
        self.scalers = {}
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # Register deep learning-specific handlers
        self.register_handler("train_model", self.handle_train_model)
        self.register_handler("make_prediction", self.handle_make_prediction)
        self.register_handler("get_model_status", self.handle_get_model_status)
        self.register_handler("market_data", self.handle_market_data)

        logger.info(f"Deep Learning Agent {agent_id} initialized on {self.device}")

    async def initialize(self):
        """Initialize deep learning agent resources"""
        try:
            # Load model configuration
            await self.load_model_config()

            # Initialize models
            await self.initialize_models()

            # Load pre-trained models if available (method not yet implemented)
            # await self.load_pretrained_models()

            # Start model monitoring (method not yet implemented)
            # await self.start_model_monitoring()

            logger.info(f"Deep Learning Agent {self.agent_id} initialized successfully")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error initializing Deep Learning Agent")
            self.update_health_status("error")

    async def process_loop(self):
        """Main deep learning processing loop"""
        while self.running:
            try:
                # Train models if needed
                await self.train_models_if_needed()

                # Make predictions for all symbols
                await self.make_all_predictions()

                # Update model metrics
                await self.update_model_metrics()

                # Clean up old cache entries
                await self.cleanup_cache()

                await asyncio.sleep(300)  # Check every 5 minutes

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Error in deep learning processing loop")
                await asyncio.sleep(600)

    async def load_model_config(self):
        """Load model configuration from Redis"""
        try:
            # Load model configuration
            config_data = self.redis_client.get("deep_learning_config")
            if config_data:
                # redis returns bytes; decode if necessary
                if isinstance(config_data, (bytes, bytearray)):
                    config_data = config_data.decode()
                self.model_config = json.loads(config_data)

            # Load trading symbols
            symbols_data = self.redis_client.get("trading_symbols")
            if symbols_data:
                if isinstance(symbols_data, (bytes, bytearray)):
                    symbols_data = symbols_data.decode()
                self.trading_symbols = json.loads(symbols_data)

            logger.info(f"Model configuration loaded: {len(self.model_config['models'])} models, {len(self.trading_symbols)} symbols")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error loading model configuration")

    async def initialize_models(self):
        """Initialize deep learning models"""
        try:
            for model_name, model_config in self.model_config["models"].items():
                if model_config.get("enabled", False):
                    model = await self.create_model(model_name, model_config)
                    if model:
                        self.models[model_name] = model

                        # Initialize scaler for this model
                        self.scalers[model_name] = MinMaxScaler()

            logger.info(f"Models initialized: {len(self.models)} models")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error initializing models")

    async def create_model(self, model_name: str, model_config: dict[str, Any]) -> nn.Module | None:
        """Create a deep learning model"""
        try:
            model_type = model_config.get("type")

            if model_type == "lstm":
                model = LSTMModel(
                    input_size=int(model_config.get("input_size", 1)),
                    hidden_size=int(model_config.get("hidden_size", 64)),
                    num_layers=int(model_config.get("num_layers", 1)),
                    output_size=int(model_config.get("output_size", 1)),
                    dropout=float(model_config.get("dropout", 0.2)),
                )
            elif model_type == "cnn":
                model = CNNModel(
                    input_channels=int(model_config.get("input_channels", 1)),
                    num_classes=int(model_config.get("num_classes", 2)),
                )
            elif model_type == "transformer":
                # Transformer not yet implemented; log and skip creation
                logger.warning(f"Transformer model type requested for {model_name} but not implemented.")
                return None
            else:
                logger.error(f"Unknown model type '{model_type}' for model '{model_name}'")
                return None

            model.to(self.device)
            return model

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error creating model {model_name}")
            return None
        else:
            return model

    async def broadcast_predictions(self, symbol: str, predictions: dict[str, Any]):
        """Broadcast predictions to other agents"""
        try:
            prediction_update = {
                "type": "deep_learning_prediction_update",
                "symbol": symbol,
                "predictions": predictions,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Broadcast to all agents
            await self.broadcast_message(prediction_update)

            # Send to specific agents
            await self.send_message("strategy_agent", prediction_update)
            await self.send_message("risk_agent", prediction_update)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error broadcasting predictions")

    async def handle_train_model(self, message: dict[str, Any]):
        """Handle manual model training request"""
        try:
            symbol = message.get("symbol")
            model_name = message.get("model_name")

            logger.info(f"Manual model training requested for {symbol}")

            if symbol:
                if model_name and model_name in self.models:
                    # Train specific model
                    market_data = await self.get_symbol_market_data(symbol)
                    if market_data:
                        await self.train_model(
                            symbol,
                            model_name,
                            self.models[model_name],
                            market_data,
                        )
                else:
                    # Train all models
                    await self.train_symbol_models(symbol)

            # Send response
            response = {
                "type": "model_training_complete",
                "symbol": symbol,
                "model_name": model_name,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling model training request")
            await self.broadcast_error(f"Model training error: {e}")

    async def handle_make_prediction(self, message: dict[str, Any]):
        """Handle manual prediction request"""
        try:
            symbol = message.get("symbol")
            model_name = message.get("model_name")

            logger.info(f"Manual prediction requested for {symbol}")

            if symbol:
                market_data = await self.get_symbol_market_data(symbol)
                if market_data:
                    if model_name and model_name in self.models:
                        # Make prediction with specific model
                        prediction = await self.make_model_prediction(
                            symbol,
                            model_name,
                            self.models[model_name],
                            market_data,
                        )

                        response = {
                            "type": "prediction_response",
                            "symbol": symbol,
                            "model_name": model_name,
                            "prediction": prediction,
                            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                        }
                    else:
                        # Make predictions with all models
                        await self.make_symbol_predictions(symbol)

                        response = {
                            "type": "prediction_response",
                            "symbol": symbol,
                            "predictions": (self.state["predictions_made"].get(symbol, {}).get("predictions", {})),
                            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                        }
                else:
                    response = {
                        "type": "prediction_response",
                        "symbol": symbol,
                        "prediction": None,
                        "error": "No market data available",
                        "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                    }
            else:
                response = {
                    "type": "prediction_response",
                    "symbol": symbol,
                    "prediction": None,
                    "error": "No symbol provided",
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling prediction request")
            await self.broadcast_error(f"Prediction error: {e}")

    async def handle_get_model_status(self, message: dict[str, Any]):
        """Handle model status request"""
        try:
            symbol = message.get("symbol")

            logger.info(f"Model status requested for {symbol}")

            # Get model status
            if symbol and symbol in self.state["training_history"]:
                status = self.state["training_history"][symbol]

                response = {
                    "type": "model_status_response",
                    "symbol": symbol,
                    "status": status,
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                }
            else:
                response = {
                    "type": "model_status_response",
                    "symbol": symbol,
                    "status": None,
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling model status request")
            await self.broadcast_error(f"Model status error: {e}")

    async def update_model_metrics(self):
        """Update model metrics"""
        try:
            metrics = {
                "agent_id": self.agent_id,
                "symbols_count": len(self.trading_symbols),
                "models_count": len(self.models),
                "predictions_count": len(self.state["predictions_made"]),
                "training_count": self.state["training_count"],
                "last_training": self.state["last_training"],
                "cache_size": len(self.state["model_cache"]),
                "device": str(self.device),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Store metrics in Redis
            self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics), ex=300)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error updating model metrics")

    async def cleanup_cache(self):
        """Clean up old cache entries"""
        try:
            current_time = datetime.now(tz=timezone.utc)

            # Clean up old model cache entries
            for symbol in list(self.state["model_cache"].keys()):
                data_points = self.state["model_cache"][symbol]

                # Keep only recent data points (last 48 hours)
                cutoff_time = current_time - timedelta(hours=48)
                recent_data = [point for point in data_points if datetime.fromisoformat(point["timestamp"]) > cutoff_time]

                if recent_data:
                    self.state["model_cache"][symbol] = recent_data
                else:
                    del self.state["model_cache"][symbol]

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error cleaning up cache")

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process market data for deep learning predictions"""
        try:
            logger.info(f"Processing market data for {len(market_data) if isinstance(market_data, dict) else 0} symbols")

            # Store and analyze market data
            if isinstance(market_data, dict):
                for symbol, data in market_data.items():
                    if symbol in self.trading_symbols:
                        price = data.get("price", 0) if isinstance(data, dict) else 0
                        volume = data.get("volume", 0) if isinstance(data, dict) else 0

                        # Store in model cache
                        if symbol not in self.state["model_cache"]:
                            self.state["model_cache"][symbol] = []

                        self.state["model_cache"][symbol].append(
                            {
                                "price": price,
                                "volume": volume,
                                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                            }
                        )

                        # Keep only last 1000 points
                        if len(self.state["model_cache"][symbol]) > 1000:
                            self.state["model_cache"][symbol] = self.state["model_cache"][symbol][-1000:]

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error processing market data")

    async def handle_market_data(self, message: dict[str, Any]):
        """Handle market data message"""
        try:
            market_data = message.get("market_data", {})
            logger.info(f"Deep Learning Agent received market data for {len(market_data)} symbols")

            # Process market data
            await self.process_market_data(market_data)

            # Store market data for each symbol
            for symbol, data in market_data.items():
                if symbol in self.trading_symbols:
                    price = data.get("price", 0)
                    volume = data.get("volume", 0)
                    timestamp = data.get("timestamp", datetime.now(tz=timezone.utc).isoformat())

                    await self.store_market_data(symbol, price, volume, timestamp)

            # Check if models need retraining
            await self.train_models_if_needed()

            # Make predictions with new data
            await self.make_all_predictions()

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling market data")
            await self.broadcast_error(f"Market data handling error: {e}")
