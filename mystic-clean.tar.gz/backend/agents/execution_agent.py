"""
Execution Agent
Handles order execution, trade management, and position tracking
"""

import asyncio
import contextlib
import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Any

# Add parent directory to path for imports
from backend.agents.base_agent import BaseAgent
from backend.services.task_manager import task_manager

# Lazy import for optional redis helpers (may not be available in all deployments)
try:
    from utils.redis_helpers import to_str_list as _to_str_list_impl
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    _to_str_list_impl = None

logger = logging.getLogger(__name__)


class ExecutionAgent(BaseAgent):
    """Execution Agent - Handles order execution and trade management"""

    def __init__(self, agent_id: str = "execution_agent_001") -> None:
        super().__init__(agent_id, "execution")

        self.state.update(
            {
                "active_orders": {},
                "positions": {},
                "trade_history": [],
                "execution_stats": {
                    "total_trades": 0,
                    "successful_trades": 0,
                    "failed_trades": 0,
                    "total_volume": 0,
                    "total_fees": 0,
                },
                "exchange_status": "connected",
                "last_execution": None,
            },
        )

        # Register execution-specific handlers
        self.register_handler("approved_trading_signal", self.handle_approved_signal)
        self.register_handler("cancel_order", self.handle_cancel_order)
        self.register_handler("modify_order", self.handle_modify_order)
        self.register_handler("portfolio_update", self.handle_portfolio_update)
        self.register_handler("market_data", self.handle_market_data)

        logger.info(f"Execution Agent {agent_id} initialized")

    async def initialize(self):
        """Initialize execution agent resources"""
        try:
            # Load existing positions and orders
            await self.load_existing_data()

            # Initialize exchange connection
            await self.initialize_exchange()

            # Subscribe to market data
            await self.subscribe_to_market_data()

            logger.info(f"Execution Agent {self.agent_id} initialized successfully")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error initializing Execution Agent")
            self.update_health_status("error")

    async def process_loop(self):
        """Main execution processing loop"""
        while self.running:
            try:
                # Monitor active orders
                await self.monitor_active_orders()

                # Update positions
                await self.update_positions()

                # Check for order timeouts
                await self.check_order_timeouts()

                # Update execution metrics
                await self.update_execution_metrics()

                await asyncio.sleep(10)  # Check every 10 seconds

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Error in execution processing loop")
                await asyncio.sleep(30)

    async def load_existing_data(self):
        """Load existing positions and orders from Redis"""
        try:
            # Load positions
            positions_data = self.redis_client.get("positions")
            if positions_data:
                try:
                    self.state["positions"] = json.loads(positions_data)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    # If stored as bytes/string representation
                    self.state["positions"] = json.loads(positions_data.decode() if isinstance(positions_data, bytes) else positions_data)

            # Load active orders
            orders_data = self.redis_client.get("active_orders")
            if orders_data:
                try:
                    self.state["active_orders"] = json.loads(orders_data)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    self.state["active_orders"] = json.loads(orders_data.decode() if isinstance(orders_data, bytes) else orders_data)

            # Load trade history
            if _to_str_list_impl is None:
                # Fallback if helper not available
                def to_str_list(items):
                    return [item.decode() if isinstance(item, bytes) else str(item) for item in items]
            else:
                to_str_list = _to_str_list_impl

            history_data = to_str_list(self.redis_client.lrange("trade_history", 0, -1))
            self.state["trade_history"] = [json.loads(item) for item in history_data]

            logger.info(f"Loaded {len(self.state['positions'])} positions and {len(self.state['active_orders'])} orders")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error loading existing data")

    async def initialize_exchange(self):
        """Initialize exchange connection"""
        try:
            # This would typically initialize exchange API connections
            # For now, simulate exchange connection

            exchange_config = {
                "status": "connected",
                "last_heartbeat": datetime.now(tz=timezone.utc).isoformat(),
                "supported_pairs": ["BTCUSDT", "ETHUSDT", "ADAUSDT"],
                "min_order_size": 0.001,
                "max_order_size": 1000,
                "fee_rate": 0.001,
            }

            self.redis_client.set("exchange_config", json.dumps(exchange_config), ex=3600)

            logger.info("Exchange connection initialized")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error initializing exchange")
            self.state["exchange_status"] = "disconnected"

    async def subscribe_to_market_data(self):
        """Subscribe to market data updates"""
        try:
            # Subscribe to market data channel
            pubsub = self.redis_client.pubsub()
            pubsub.subscribe("market_data")

            # Start market data listener
            task = await task_manager.create_task(self.listen_market_data(pubsub), name="execution_agent:listen_market_data")
            self._tasks.append(task)

            logger.info("Execution Agent subscribed to market data")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error subscribing to market data")

    async def listen_market_data(self, pubsub):
        """Listen for market data updates"""
        try:
            # Use a non-blocking loop to poll for messages to avoid blocking the event loop
            while self.running:
                try:
                    message = pubsub.get_message(ignore_subscribe_messages=True, timeout=1)
                except TypeError:
                    # Some redis clients may not accept timeout kwarg
                    message = pubsub.get_message(ignore_subscribe_messages=True)

                if message and message.get("type") == "message":
                    data = message.get("data")
                    if isinstance(data, (bytes, bytearray)):
                        with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                            data = data.decode("utf-8")
                    try:
                        market_data = json.loads(data)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        market_data = data
                    await self.process_market_data(market_data)

                await asyncio.sleep(0.01)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error in market data listener")
        finally:
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pubsub.close()

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process incoming market data for execution"""
        try:
            if not market_data:
                return

            symbol = market_data.get("symbol") if isinstance(market_data, dict) else None
            price = market_data.get("price") if isinstance(market_data, dict) else None
            _ = market_data.get("timestamp") if isinstance(market_data, dict) else None

            # Update order prices
            if symbol and price is not None:
                await self.update_order_prices(symbol, price)

                # Check for order triggers
                await self.check_order_triggers(symbol, price)
            # If market_data is a mapping of symbols to data, handle each
            elif isinstance(market_data, dict):
                for sym, data in market_data.items():
                    p = None
                    if isinstance(data, dict):
                        p = data.get("price")
                    elif isinstance(data, (int, float)):
                        p = data
                    if p is not None:
                        await self.update_order_prices(sym, p)
                        await self.check_order_triggers(sym, p)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error processing market data")

    async def handle_approved_signal(self, message: dict[str, Any]):
        """Handle approved trading signal"""
        try:
            strategy_id = message.get("strategy_id")
            signal = message.get("signal", {})
            market_data = message.get("market_data", {})
            position_size = message.get("position_size", {})
            _ = message.get("risk_validation", {})

            symbol = market_data.get("symbol")
            signal_type = signal.get("type")
            confidence = signal.get("confidence", 0)
            price = market_data.get("price", 0)

            logger.info(f"Executing approved signal for {symbol} ({signal_type})")

            # Execute the trade
            execution_result = await self.execute_trade(
                symbol=symbol,
                signal_type=signal_type,
                position_size=position_size,
                price=price,
                strategy_id=strategy_id,
                confidence=confidence,
            )

            # Send execution result to strategy agent
            await self.send_message(
                "strategy_agent",
                {
                    "type": "execution_result",
                    "strategy_id": strategy_id,
                    "execution": execution_result,
                    "signal": signal,
                },
            )

            # Broadcast execution
            await self.broadcast_message({"type": "trade_executed", "execution": execution_result})

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling approved signal")
            await self.broadcast_error(f"Execution error: {e}")

    async def handle_cancel_order(self, message: dict[str, Any]):
        """Handle order cancellation request"""
        try:
            order_id = message.get("order_id")

            logger.info(f"Cancelling order {order_id}")

            # Cancel order
            cancellation_result = await self.cancel_order(order_id)

            # Send response
            response = {
                "type": "order_cancelled",
                "order_id": order_id,
                "result": cancellation_result,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error cancelling order")
            await self.broadcast_error(f"Order cancel error: {e}")

    async def cancel_order(self, order_id: str) -> dict[str, Any]:
        """Cancel an active order"""
        if not order_id:
            msg = "order_id is required to cancel order"
            raise ValueError(msg)

        try:
            if order_id not in self.state["active_orders"]:
                logger.warning(f"Order {order_id} not found when attempting cancel")
                return {"order_id": order_id, "status": "not_found", "timestamp": datetime.now(tz=timezone.utc).isoformat()}

            order = self.state["active_orders"].get(order_id, {})
            # Simulate cancellation
            cancellation_result = {
                "order_id": order_id,
                "status": "cancelled",
                "original_order": order,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Append to trade history
            try:
                self.state["trade_history"].append(cancellation_result)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                self.state["trade_history"] = [cancellation_result]

            # Update execution stats
            self.state["execution_stats"]["failed_trades"] += 1

            # Remove from active orders
            with contextlib.suppress(KeyError):
                del self.state["active_orders"][order_id]

            # Update Redis
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                self.redis_client.delete(f"order:{order_id}")

            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                self.redis_client.set(
                    "active_orders",
                    json.dumps(self.state["active_orders"]),
                    ex=3600,
                )

            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # Store trade history entry
                self.redis_client.rpush("trade_history", json.dumps(cancellation_result))

            logger.info(f"Order cancelled: {order_id}")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error cancelling order")
            raise
        else:
            return cancellation_result

    async def handle_modify_order(self, message: dict[str, Any]):
        """Handler wrapper for modify order messages"""
        try:
            order_id = message.get("order_id")
            new_params = message.get("new_params", {})

            modification_result = await self.modify_order(order_id, new_params)

            response = {
                "type": "order_modified",
                "order_id": order_id,
                "result": modification_result,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling modify order")
            await self.broadcast_error(f"Order modify error: {e}")

    async def modify_order(self, order_id: str, new_params: dict[str, Any]) -> dict[str, Any]:
        """Modify an order"""
        if order_id not in self.state["active_orders"]:
            msg = f"Order {order_id} not found"
            raise ValueError(msg)

        try:
            # Update order parameters
            self.state["active_orders"][order_id].update(new_params)

            # Simulate order modification
            modification_result = {
                "order_id": order_id,
                "status": "modified",
                "new_params": new_params,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Update Redis
            try:
                self.redis_client.set(
                    f"order:{order_id}",
                    json.dumps(self.state["active_orders"][order_id]),
                    ex=3600,
                )
                self.redis_client.set(
                    "active_orders",
                    json.dumps(self.state["active_orders"]),
                    ex=3600,
                )
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pass

            logger.info(f"Order modified: {order_id}")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error modifying order")
            raise
        else:
            return modification_result

    async def monitor_active_orders(self):
        """Monitor active orders"""
        try:
            # Use snapshot to avoid runtime errors if dict is modified during iteration
            for order_id, order in list(self.state["active_orders"].items()):
                # Check if order is still active
                if order.get("status") == "filled":
                    # Remove filled orders
                    with contextlib.suppress(KeyError):
                        del self.state["active_orders"][order_id]
                    with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        self.redis_client.delete(f"order:{order_id}")

                    # Update execution stats
                    self.state["execution_stats"]["successful_trades"] += 1

                    logger.info(f"Order filled: {order_id}")
                    continue

                # Check for order timeouts
                order_time = datetime.fromisoformat(order.get("timestamp", datetime.now(tz=timezone.utc).isoformat()))
                if (datetime.now(tz=timezone.utc) - order_time) > timedelta(minutes=5):
                    # Cancel timed out orders
                    await self.cancel_order(order_id)

            # Update Redis
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                self.redis_client.set(
                    "active_orders",
                    json.dumps(self.state["active_orders"]),
                    ex=3600,
                )

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error monitoring active orders")

    async def update_positions(self):
        """Update position information"""
        try:
            # Get current positions from exchange
            positions = await self.get_exchange_positions()

            # Update state
            self.state["positions"] = positions

            # Store in Redis
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                self.redis_client.set("positions", json.dumps(positions), ex=300)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error updating positions")

    async def update_positions_from_portfolio(self, portfolio: dict[str, Any]):
        """Update positions from portfolio data"""
        try:
            positions = portfolio.get("positions", [])

            # Convert to position dict
            position_dict = {}
            for position in positions:
                symbol = position.get("symbol")
                if symbol:
                    position_dict[symbol] = position

            self.state["positions"] = position_dict

            # Store in Redis
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                self.redis_client.set("positions", json.dumps(position_dict), ex=300)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error updating positions from portfolio")

    async def get_exchange_positions(self) -> dict[str, Any]:
        """Get current positions from exchange"""
        try:
            # Simulate getting positions from exchange
            # In real implementation, this would call exchange API

            positions = {}

            # Get positions from Redis as fallback
            positions_data = self.redis_client.get("positions")
            if positions_data:
                try:
                    positions = json.loads(positions_data)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    positions = json.loads(positions_data.decode() if isinstance(positions_data, bytes) else positions_data)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error getting exchange positions")
            return {}
        else:
            return positions

    async def check_order_timeouts(self):
        """Check for order timeouts"""
        try:
            current_time = datetime.now(tz=timezone.utc)

            for order_id, order in list(self.state["active_orders"].items()):
                order_time = datetime.fromisoformat(order.get("timestamp", current_time.isoformat()))

                # Cancel orders older than 5 minutes
                if (current_time - order_time) > timedelta(minutes=5):
                    logger.info(f"Order timeout: {order_id}")
                    await self.cancel_order(order_id)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error checking order timeouts")

    async def update_order_prices(self, symbol: str, price: float):
        """Update order prices for a symbol"""
        try:
            for order_id, order in list(self.state["active_orders"].items()):
                if order.get("symbol") == symbol:
                    # Update current price
                    order["current_price"] = price

                    # Check for price-based triggers
                    await self.check_price_triggers(order_id, order, price)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error updating order prices")

    async def check_price_triggers(self, order_id: str, order: dict[str, Any], current_price: float):
        """Check for price-based order triggers"""
        try:
            # Check stop loss
            stop_loss = order.get("stop_loss")
            if stop_loss is not None and current_price <= stop_loss:
                logger.info(f"Stop loss triggered for order {order_id}")
                await self.cancel_order(order_id)

            # Check take profit
            take_profit = order.get("take_profit")
            if take_profit is not None and current_price >= take_profit:
                logger.info(f"Take profit triggered for order {order_id}")
                await self.cancel_order(order_id)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error checking price triggers")

    async def check_order_triggers(self, symbol: str, price: float):
        """Check for order triggers"""
        try:
            # This would check for various order triggers
            # For now, just update prices
            await self.update_order_prices(symbol, price)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error checking order triggers")

    async def update_execution_metrics(self):
        """Update execution metrics"""
        try:
            metrics = {
                "agent_id": self.agent_id,
                "execution_stats": self.state["execution_stats"],
                "active_orders_count": len(self.state["active_orders"]),
                "positions_count": len(self.state["positions"]),
                "exchange_status": self.state["exchange_status"],
                "last_execution": self.state["last_execution"],
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Store metrics in Redis
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics), ex=300)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error updating execution metrics")

    async def handle_portfolio_update(self, message: dict[str, Any]):
        """Handle portfolio update message"""
        try:
            portfolio_data = message.get("portfolio", message.get("data", {}))
            logger.debug("Execution Agent received portfolio update")

            # Update positions from portfolio
            if isinstance(portfolio_data, dict):
                positions = portfolio_data.get("positions", {})
                if positions:
                    self.state["positions"].update(positions)

                # Update balances
                balance = portfolio_data.get("balance")
                if balance is not None:
                    self.state["balance"] = balance

            # Update execution metrics
            await self.update_execution_metrics()

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling portfolio update")
            await self.broadcast_error(f"Portfolio update handling error: {e}")

    async def handle_market_data(self, message: dict[str, Any]):
        """Handle market data message"""
        try:
            market_data = message.get("market_data", {})
            if isinstance(market_data, dict):
                logger.info(f"Execution Agent received market data for {len(market_data)} symbols")
            else:
                logger.info("Execution Agent received market data")

            # Process market data
            await self.process_market_data(market_data)

            # Check order triggers for each symbol
            if isinstance(market_data, dict):
                for symbol, data in market_data.items():
                    price = data.get("price", 0) if isinstance(data, dict) else (data or 0)
                    if price and price > 0:
                        await self.check_order_triggers(symbol, price)

            # Update execution metrics
            await self.update_execution_metrics()

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling market data")
            await self.broadcast_error(f"Market data handling error: {e}")
