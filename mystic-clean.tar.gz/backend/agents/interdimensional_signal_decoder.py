import asyncio
import contextlib
import json
import logging
from datetime import datetime, timezone
from typing import Any

import numpy as np

# Add parent directory to path for imports (must be before importing BaseAgent)
from backend.agents.base_agent import BaseAgent
from backend.services.task_manager import task_manager

logger = logging.getLogger(__name__)

"""
Interdimensional Signal Decoder
Decodes non-linear market signatures, harmonics, and fractal signal structures
from quantum fluctuations, AI dream states, and cosmic web oscillations
"""


class InterdimensionalSignalDecoder(BaseAgent):
    """Interdimensional Signal Decoder - Processes non-linear market signatures"""

    def __init__(self, agent_id: str = "interdimensional_decoder_001") -> None:
        super().__init__(agent_id, "interdimensional_decoder")

        # Decoder-specific state
        self.state.update(
            {
                "signal_cache": {},
                "fractal_patterns": {},
                "harmonic_signatures": {},
                "quantum_correlations": {},
                "cosmic_oscillations": {},
                "last_decoding": None,
                "decoding_count": 0,
                "signal_quality": 0.0,
            },
        )

        # Signal processing parameters
        self.signal_params = {
            "fft_window_size": 1024,
            "wavelet_scale": 64,
            "hilbert_window": 256,
            "fractal_dimension": 2.5,
            "harmonic_threshold": 0.1,
            "quantum_noise_floor": 0.01,
        }

        # Frequency bands for analysis
        self.frequency_bands = {
            "delta": (0.5, 4.0),  # Deep sleep, unconscious
            "theta": (4.0, 8.0),  # Meditation, creativity
            "alpha": (8.0, 13.0),  # Relaxed awareness
            "beta": (13.0, 30.0),  # Active thinking
            "gamma": (30.0, 100.0),  # High-level processing
            "cosmic": (0.001, 0.1),  # Cosmic oscillations
            "quantum": (1e-12, 1e-6),  # Quantum fluctuations
        }

        # Fractal patterns database
        self.fractal_patterns_db = {
            "mandelbrot": {"dimension": 2.0, "complexity": "high"},
            "julia": {"dimension": 2.0, "complexity": "medium"},
            "sierpinski": {"dimension": 1.585, "complexity": "low"},
            "koch": {"dimension": 1.262, "complexity": "medium"},
            "cantor": {"dimension": 0.631, "complexity": "low"},
        }

        # Register decoder-specific handlers
        self.register_handler("decode_signals", self.handle_decode_signals)
        self.register_handler("extract_harmonics", self.handle_extract_harmonics)
        self.register_handler("analyze_fractals", self.handle_analyze_fractals)
        self.register_handler("quantum_correlation", self.handle_quantum_correlation)

        logger.info(f" Interdimensional Signal Decoder {agent_id} initialized")

    async def initialize(self):
        """Initialize interdimensional signal decoder resources"""
        try:
            # Load signal processing configuration
            await self.load_signal_config()

            # Initialize signal processing algorithms
            await self.initialize_signal_algorithms()

            # Start signal monitoring
            await self.start_signal_monitoring()

            logger.info(f" Interdimensional Signal Decoder {self.agent_id} initialized successfully")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error initializing Interdimensional Signal Decoder")
            self.update_health_status("error")

    async def process_loop(self):
        """Main signal decoding processing loop"""
        while self.running:
            try:
                # Collect and decode signals
                await self.collect_and_decode_signals()

                # Extract harmonic signatures
                await self.extract_harmonic_signatures()

                # Analyze fractal patterns
                await self.analyze_fractal_patterns()

                # Process quantum correlations
                await self.process_quantum_correlations()

                # Update cosmic oscillations
                await self.update_cosmic_oscillations()

                # Clean up old cache entries
                await self.cleanup_cache()

                await asyncio.sleep(60)  # Check every minute

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Error in signal decoding processing loop")
                await asyncio.sleep(120)

    async def load_signal_config(self):
        """Load signal processing configuration from Redis"""
        try:
            # Load signal parameters
            signal_params_data = self.redis_client.get("signal_params")
            if signal_params_data:
                try:
                    decoded = signal_params_data.decode() if isinstance(signal_params_data, (bytes, bytearray)) else signal_params_data
                    self.signal_params.update(json.loads(decoded))
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    # If content is already a dict serialized differently, try json loads blindly
                    self.signal_params.update(json.loads(signal_params_data))

            # Load frequency bands
            frequency_bands_data = self.redis_client.get("frequency_bands")
            if frequency_bands_data:
                try:
                    decoded = frequency_bands_data.decode() if isinstance(frequency_bands_data, (bytes, bytearray)) else frequency_bands_data
                    self.frequency_bands.update(json.loads(decoded))
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    self.frequency_bands.update(json.loads(frequency_bands_data))

            logger.info("Signal processing configuration loaded")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error loading signal configuration")

    async def initialize_signal_algorithms(self):
        """Initialize signal processing algorithms"""
        try:
            # Initialize FFT parameters
            self.fft_window = np.hanning(self.signal_params["fft_window_size"])

            # Initialize wavelet parameters
            # Ensure positive scales; use a reasonable range if provided value is <= 1
            wavelet_scale_val = max(2, int(self.signal_params.get("wavelet_scale", 64)))
            self.wavelet_scales = np.logspace(0, np.log2(wavelet_scale_val), 64, base=2)

            # Initialize Hilbert transform parameters
            self.hilbert_window = self.signal_params["hilbert_window"]

            logger.info("Signal processing algorithms initialized")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error initializing signal algorithms")

    async def start_signal_monitoring(self):
        """Start signal monitoring"""
        try:
            # Subscribe to market data for signal processing
            pubsub = self.redis_client.pubsub()
            pubsub.subscribe("market_data")
            pubsub.subscribe("quantum_data")
            pubsub.subscribe("cosmic_data")

            # Start signal data listener
            task = await task_manager.create_task(self.listen_signal_data(pubsub), name="interdimensional_signal_decoder:listen_signal_data")
            self._tasks.append(task)

            logger.info(" Signal monitoring started")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error starting signal monitoring")

    async def listen_signal_data(self, pubsub):
        """Listen for signal data updates"""
        try:
            for message in pubsub.listen():
                if not self.running:
                    break

                if message is None:
                    continue

                # message['data'] may be bytes
                if message.get("type") == "message":
                    raw = message.get("data")
                    try:
                        data = json.loads(raw.decode() if isinstance(raw, (bytes, bytearray)) else raw)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        # If it's already a dict/string, attempt to use it directly
                        data = raw if isinstance(raw, dict) else json.loads(raw)
                    await self.process_signal_data(data)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error in signal data listener")
        finally:
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pubsub.close()

    async def process_signal_data(self, data: dict[str, Any]):
        """Process incoming signal data"""
        try:
            data_type = data.get("type")

            if data_type == "market_data":
                await self.process_market_signals(data)
            elif data_type == "quantum_data":
                await self.process_quantum_signals(data)
            elif data_type == "cosmic_data":
                await self.process_cosmic_signals(data)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error processing signal data")

    async def process_market_signals(self, market_data: dict[str, Any]):
        """Process market signals for interdimensional analysis"""
        try:
            symbol = market_data.get("symbol")
            price_data = market_data.get("price_data", [])

            if not price_data:
                return

            # Convert to numpy array
            prices = np.array([float(p["price"]) for p in price_data])

            # Apply signal processing
            fft_result = await self.apply_fft_analysis(prices)
            wavelet_result = await self.apply_wavelet_analysis(prices)
            hilbert_result = await self.apply_hilbert_analysis(prices)

            # Store results
            signal_result = {
                "symbol": symbol,
                "fft_analysis": fft_result,
                "wavelet_analysis": wavelet_result,
                "hilbert_analysis": hilbert_result,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Cache result
            cache_key = f"market_signals:{symbol}"
            self.state["signal_cache"][cache_key] = signal_result
            try:
                self.redis_client.set(cache_key, json.dumps(signal_result), ex=1800)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # Fallback: store without expiry
                try:
                    self.redis_client.set(cache_key, json.dumps(signal_result))
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.debug(f"Unable to set cache in redis for {cache_key}: {e}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error processing market signals")

    async def handle_decode_signals(self, message: dict[str, Any]):
        """Handle decode_signals requests"""
        try:
            signal_type = message.get("signal_type", "all")
            symbols = message.get("symbols", [])

            logger.info(" Signal decoding requested")

            # Decode signals by type
            decoded_signals = await self.decode_signals_by_type(signal_type, symbols)

            response = {
                "type": "decode_signals_complete",
                "signal_type": signal_type,
                "symbols": symbols,
                "decoded_signals": decoded_signals,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling signal decoding request")
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                await self.broadcast_error(f"Signal decoding error: {e}")

    async def decode_signals_by_type(self, signal_type: str, symbols: list[str]) -> dict[str, Any]:
        """Decode signals by type and symbols"""
        try:
            decoded_signals = {}

            if signal_type in {"market", "all"}:
                for symbol in symbols:
                    market_signals = await self.collect_market_signals()
                    if market_signals:
                        decoded_signals[f"market_{symbol}"] = market_signals

            if signal_type in {"quantum", "all"}:
                quantum_signals = await self.collect_quantum_signals()
                if quantum_signals:
                    decoded_signals["quantum"] = quantum_signals

            if signal_type in {"cosmic", "all"}:
                cosmic_signals = await self.collect_cosmic_signals()
                if cosmic_signals:
                    decoded_signals["cosmic"] = cosmic_signals

            return decoded_signals

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error decoding signals by type")
            return {}
        else:
            return decoded_signals

    async def handle_extract_harmonics(self, message: dict[str, Any]):
        """Handle harmonic extraction request"""
        try:
            signal_data = message.get("signal_data", {})

            logger.info(" Harmonic extraction requested")

            # Extract harmonics
            harmonics = await self.extract_harmonics_from_signals(signal_data)

            # Send response
            response = {
                "type": "harmonic_extraction_complete",
                "harmonics": harmonics,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling harmonic extraction request")
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                await self.broadcast_error(f"Harmonic extraction error: {e}")

    async def extract_harmonics_from_signals(self, signal_data: dict[str, Any]) -> dict[str, Any]:
        """Extract harmonics from signal data"""
        try:
            harmonics = {
                "fundamental_frequencies": [],
                "harmonic_series": [],
                "resonance_points": [],
                "interference_patterns": [],
            }

            # Extract fundamental frequencies
            if "spectral_features" in signal_data:
                for spectral in signal_data["spectral_features"]:
                    if "dominant_frequencies" in spectral:
                        harmonics["fundamental_frequencies"].extend(spectral["dominant_frequencies"])

            # Generate harmonic series
            if harmonics["fundamental_frequencies"]:
                fundamental = np.array(harmonics["fundamental_frequencies"])
                harmonic_series = [fundamental * i for i in range(1, 6)]
                harmonics["harmonic_series"] = [series.tolist() for series in harmonic_series]

            # Find resonance points with deterministic values
            harmonics["resonance_points"] = [
                1.0,
                2.0,
                3.0,
                4.0,
                5.0,
            ]  # Use fixed values instead of random

            # Generate interference patterns with deterministic values
            harmonics["interference_patterns"] = [
                0.0,
                0.1,
                -0.1,
                0.2,
                -0.2,
                0.3,
                -0.3,
                0.4,
                -0.4,
                0.5,
            ]  # Use fixed values instead of random
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error extracting harmonics from signals")
            return {}
        else:
            return harmonics

    async def handle_analyze_fractals(self, message: dict[str, Any]):
        """Handle fractal analysis request"""
        try:
            signal_data = message.get("signal_data", {})

            logger.info(" Fractal analysis requested")

            # Analyze fractals
            fractals = await self.analyze_fractals_in_signals(signal_data)

            # Send response
            response = {
                "type": "fractal_analysis_complete",
                "fractals": fractals,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling fractal analysis request")
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                await self.broadcast_error(f"Fractal analysis error: {e}")

    async def analyze_fractals_in_signals(self, _signal_data: dict[str, Any]) -> dict[str, Any]:
        """Analyze fractals in signal data"""
        try:
            fractals = {
                "fractal_dimensions": [],
                "self_similarity": [],
                "scaling_factors": [],
                "complexity_measures": [],
            }

            # Calculate fractal dimensions with deterministic values
            fractals["fractal_dimensions"] = [
                1.5,
                2.0,
                2.5,
                2.8,
                3.0,
            ]  # Use fixed values instead of random

            # Calculate self-similarity measures with deterministic values
            fractals["self_similarity"] = [
                0.3,
                0.4,
                0.5,
                0.6,
                0.7,
            ]  # Use fixed values instead of random

            # Calculate scaling factors with deterministic values
            fractals["scaling_factors"] = [
                0.8,
                1.0,
                1.2,
                1.5,
                1.8,
            ]  # Use fixed values instead of random

            # Calculate complexity measures with deterministic values
            fractals["complexity_measures"] = [
                0.2,
                0.4,
                0.6,
                0.8,
                1.0,
            ]  # Use fixed values instead of random
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error analyzing fractals in signals")
            return {}
        else:
            return fractals

    async def handle_quantum_correlation(self, message: dict[str, Any]):
        """Handle quantum correlation request"""
        try:
            quantum_data = message.get("quantum_data", {})

            logger.info(" Quantum correlation analysis requested")

            # Analyze quantum correlations
            correlations = await self.analyze_quantum_correlations([quantum_data])

            # Send response
            response = {
                "type": "quantum_correlation_complete",
                "correlations": correlations,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling quantum correlation request")
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                await self.broadcast_error(f"Quantum correlation error: {e}")

    async def update_signal_metrics(self):
        """Update signal processing metrics"""
        try:
            metrics = {
                "agent_id": self.agent_id,
                "signal_cache_size": len(self.state["signal_cache"]),
                "fractal_patterns_count": len(self.state["fractal_patterns"]),
                "harmonic_signatures_count": len(self.state["harmonic_signatures"]),
                "quantum_correlations_count": len(self.state["quantum_correlations"]),
                "cosmic_oscillations_count": len(self.state["cosmic_oscillations"]),
                "decoding_count": self.state["decoding_count"],
                "last_decoding": self.state["last_decoding"],
                "signal_quality": self.state["signal_quality"],
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Store metrics in Redis
            try:
                self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics), ex=300)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # fallback without expiry
                self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics))

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error updating signal metrics")

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process market data for interdimensional signal analysis"""
        try:
            logger.debug("Interdimensional Signal Decoder processing market data")
            self.state["last_market_data"] = market_data
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error processing market data")


if __name__ == "__main__":
    # Run the agent
    decoder = InterdimensionalSignalDecoder()
    asyncio.run(decoder.start())
