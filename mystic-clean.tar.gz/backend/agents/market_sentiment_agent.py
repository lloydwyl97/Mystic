import asyncio
import contextlib
import json
import logging
from datetime import datetime, timezone
from typing import Any

from backend.agents.base_agent import BaseAgent
from backend.services.task_manager import task_manager

logger = logging.getLogger(__name__)

"""
Market Sentiment Agent
Handles aggregated market sentiment analysis from multiple sources
"""


class MarketSentimentAgent(BaseAgent):
    """Market Sentiment Agent - Aggregates sentiment from multiple sources"""

    def __init__(self, agent_id: str = "market_sentiment_agent_001") -> None:
        super().__init__(agent_id, "market_sentiment")

        # Market sentiment-specific state
        self.state.update(
            {
                "aggregated_sentiment": {},
                "source_weights": {},
                "sentiment_history": {},
                "market_fear_greed": {},
                "sentiment_signals": {},
                "last_aggregation": None,
                "aggregation_count": 0,
            },
        )

        # Source weights for sentiment aggregation
        self.source_weights = {
            "news_sentiment": 0.3,
            "social_media": 0.25,
            "market_data": 0.25,
            "technical_indicators": 0.2,
        }

        # Trading symbols to monitor
        self.trading_symbols = [
            "BTC",
            "ETH",
            "ADA",
            "DOT",
            "LINK",
            "UNI",
            "AAVE",
        ]

        # Fear & Greed thresholds
        self.fear_greed_thresholds = {
            "extreme_fear": 25,
            "fear": 45,
            "neutral": 55,
            "greed": 75,
            "extreme_greed": 100,
        }

        # Register market sentiment-specific handlers
        self.register_handler("aggregate_sentiment", self.handle_aggregate_sentiment)
        self.register_handler("get_market_sentiment", self.handle_get_market_sentiment)
        self.register_handler("update_weights", self.handle_update_weights)
        self.register_handler("news_sentiment_update", self.handle_news_sentiment_update)
        self.register_handler("social_sentiment_update", self.handle_social_sentiment_update)
        self.register_handler("market_data", self.handle_market_data)

        logger.info(f"[STATS] Market Sentiment Agent {agent_id} initialized")

    async def initialize(self):
        """Initialize market sentiment agent resources"""
        try:
            # Load sentiment configuration
            await self.load_sentiment_config()

            # Initialize sentiment aggregation models
            await self.initialize_aggregation_models()

            # Start sentiment monitoring
            await self.start_sentiment_monitoring()

            logger.info(f"[OK] Market Sentiment Agent {self.agent_id} initialized successfully")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error initializing Market Sentiment Agent")
            self.update_health_status("error")

    async def process_loop(self):
        """Main sentiment aggregation loop"""
        while self.running:
            try:
                # Aggregate sentiment from all sources
                await self.aggregate_all_sentiment()

                # Calculate fear & greed index
                await self.calculate_fear_greed_index()

                # Generate sentiment signals
                await self.generate_sentiment_signals()

                # Update sentiment metrics
                await self.update_sentiment_metrics()

                # Clean up old history
                await self.cleanup_history()

                await asyncio.sleep(60)  # Check every minute

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Error in sentiment aggregation loop")
                await asyncio.sleep(120)

    async def load_sentiment_config(self):
        """Load sentiment configuration from Redis"""
        try:
            # Load source weights
            weights_data = self.redis_client.get("sentiment_source_weights")
            if weights_data:
                try:
                    if isinstance(weights_data, (bytes, bytearray)):
                        weights_data = weights_data.decode("utf-8")
                    self.source_weights = json.loads(weights_data)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.debug("Could not parse sentiment_source_weights from Redis, using defaults")

            # Load trading symbols
            symbols_data = self.redis_client.get("trading_symbols")
            if symbols_data:
                try:
                    if isinstance(symbols_data, (bytes, bytearray)):
                        symbols_data = symbols_data.decode("utf-8")
                    self.trading_symbols = json.loads(symbols_data)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.debug("Could not parse trading_symbols from Redis, using defaults")

            # Load fear & greed thresholds
            thresholds_data = self.redis_client.get("fear_greed_thresholds")
            if thresholds_data:
                try:
                    if isinstance(thresholds_data, (bytes, bytearray)):
                        thresholds_data = thresholds_data.decode("utf-8")
                    self.fear_greed_thresholds = json.loads(thresholds_data)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.debug("Could not parse fear_greed_thresholds from Redis, using defaults")

            logger.info(f"📋 Sentiment configuration loaded: {len(self.source_weights)} sources, {len(self.trading_symbols)} symbols")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error loading sentiment configuration")

    async def initialize_aggregation_models(self):
        """Initialize sentiment aggregation models"""
        try:
            # Initialize sentiment aggregation algorithms
            # In production, you might use more sophisticated models like:
            # - Ensemble methods for sentiment aggregation
            # - Time-series analysis for sentiment trends
            # - Machine learning models for sentiment prediction

            # For now, using weighted averaging as baseline
            logger.info("🧠 Sentiment aggregation models initialized")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error initializing aggregation models")

    async def start_sentiment_monitoring(self):
        """Start sentiment monitoring"""
        try:
            # Subscribe to sentiment updates from other agents
            pubsub = self.redis_client.pubsub()
            pubsub.subscribe("news_sentiment_update")
            pubsub.subscribe("social_sentiment_update")
            pubsub.subscribe("market_data")

            # Start sentiment listener
            task = await task_manager.create_task(self.listen_sentiment_updates(pubsub), name="market_sentiment_agent:listen_sentiment_updates")
            self._tasks.append(task)

            logger.info("Sentiment monitoring started")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error starting sentiment monitoring")

    async def listen_sentiment_updates(self, pubsub):
        """Listen for sentiment updates from other agents"""
        try:
            for message in pubsub.listen():
                if not self.running:
                    break

                if message.get("type") == "message":
                    try:
                        raw_data = message.get("data")
                        if isinstance(raw_data, (bytes, bytearray)):
                            raw_data = raw_data.decode("utf-8")

                        data = json.loads(raw_data)

                        channel = message.get("channel")
                        if isinstance(channel, (bytes, bytearray)):
                            channel = channel.decode("utf-8")

                        if channel == "news_sentiment_update":
                            await self.handle_news_sentiment_update(data)
                        elif channel == "social_sentiment_update":
                            await self.handle_social_sentiment_update(data)
                        elif channel == "market_data":
                            await self.handle_market_data(data)

                    except json.JSONDecodeError:
                        logger.exception(f"Error decoding sentiment update: {message.get('data')}")
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        logger.exception("Error handling sentiment update")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error in sentiment listener")
        finally:
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pubsub.close()

    async def handle_news_sentiment_update(self, data: dict[str, Any]):
        """Handle news sentiment updates"""
        try:
            article = data.get("article", {})
            if article:
                logger.info(f"Received article for sentiment: {article.get('title', 'No Title')}")
            sentiment = data.get("sentiment", {})
            symbols = data.get("symbols", [])

            # Store news sentiment
            for symbol in symbols:
                if symbol not in self.state["sentiment_history"]:
                    self.state["sentiment_history"][symbol] = {
                        "news": [],
                        "social": [],
                        "market": [],
                        "technical": [],
                    }

                self.state["sentiment_history"][symbol]["news"].append(
                    {
                        "sentiment": sentiment,
                        "source": "news",
                        "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                    },
                )

            logger.info(f"📰 News sentiment update for {symbols}: {sentiment.get('category', 'neutral')}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling news sentiment update")

    async def handle_social_sentiment_update(self, data: dict[str, Any]):
        """Handle social sentiment updates"""
        try:
            post = data.get("post", {})
            if post:
                logger.info(f"Received social post for sentiment: {post.get('text', post.get('id', 'No ID'))}")
            sentiment = data.get("sentiment", {})
            symbols = data.get("symbols", [])

            # Store social sentiment
            for symbol in symbols:
                if symbol not in self.state["sentiment_history"]:
                    self.state["sentiment_history"][symbol] = {
                        "news": [],
                        "social": [],
                        "market": [],
                        "technical": [],
                    }

                self.state["sentiment_history"][symbol]["social"].append(
                    {
                        "sentiment": sentiment,
                        "source": "social",
                        "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                    }
                )

            logger.info(f"💬 Social sentiment update for {symbols}: {sentiment.get('category', 'neutral')}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling social sentiment update")

    async def handle_market_data(self, data: dict[str, Any]):
        """Handler invoked when market data update is received via messages/pubsub"""
        try:
            await self.process_market_data(data)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling market data message")

    async def handle_aggregate_sentiment(self, message: dict[str, Any]):
        """Handle manual sentiment aggregation request"""
        try:
            symbol = message.get("symbol")

            logger.info(f"🔊 Manual sentiment aggregation requested for {symbol}")

            if symbol:
                await self.aggregate_symbol_sentiment(symbol)
            else:
                await self.aggregate_all_sentiment()

            # Send response
            response = {
                "type": "sentiment_aggregation_complete",
                "symbol": symbol,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling sentiment aggregation request")
            await self.broadcast_error(f"Sentiment aggregation error: {e}")

    async def handle_get_market_sentiment(self, message: dict[str, Any]):
        """Handle market sentiment request"""
        try:
            symbol = message.get("symbol")
            timeframe = message.get("timeframe", "1h")

            logger.info(f"🔎 Market sentiment request for {symbol} ({timeframe})")

            # Get aggregated sentiment
            sentiment_data = self.state["aggregated_sentiment"].get(symbol) if symbol else {"market_overview": self.state["market_fear_greed"], "symbols": self.state["aggregated_sentiment"]}

            # Send response
            response = {
                "type": "market_sentiment_response",
                "symbol": symbol,
                "timeframe": timeframe,
                "sentiment": sentiment_data,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error handling market sentiment request")
            await self.broadcast_error(f"Market sentiment request error: {e}")

    async def handle_update_weights(self, message: dict[str, Any]):
        """Handle source weights update request"""
        try:
            new_weights = message.get("weights", {})

            logger.info("Updating sentiment source weights")

            # Update weights
            self.source_weights.update(new_weights)

            # Store in Redis
            try:
                self.redis_client.set(
                    "sentiment_source_weights",
                    json.dumps(self.source_weights),
                    ex=3600,
                )
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.debug("Could not persist sentiment_source_weights to Redis")

            # Send confirmation
            response = {
                "type": "weights_updated",
                "weights": self.source_weights,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error updating source weights")
            await self.broadcast_error(f"Weights update error: {e}")

    async def update_sentiment_metrics(self):
        """Update sentiment metrics"""
        try:
            metrics = {
                "agent_id": self.agent_id,
                "symbols_count": len(self.trading_symbols),
                "sources_count": len(self.source_weights),
                "aggregated_symbols": len(self.state["aggregated_sentiment"]),
                "aggregation_count": self.state["aggregation_count"],
                "last_aggregation": self.state["last_aggregation"],
                "fear_greed_index": self.state["market_fear_greed"],
                "active_signals": len(self.state["sentiment_signals"]),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Store metrics in Redis
            try:
                self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics), ex=300)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.debug("Could not persist agent metrics to Redis")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error updating sentiment metrics")

    async def cleanup_history(self):
        """Clean up old sentiment history"""
        try:
            for symbol in list(self.state["sentiment_history"].keys()):
                for source in list(self.state["sentiment_history"][symbol].keys()):
                    history = self.state["sentiment_history"][symbol][source]

                    # Keep only last 1000 entries per source
                    if len(history) > 1000:
                        self.state["sentiment_history"][symbol][source] = history[-1000:]

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error cleaning up history")

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process incoming market data for sentiment analysis"""
        try:
            logger.info("[RELOAD] Processing market data for sentiment analysis")

            # Update market data in state
            self.state["last_market_data"] = market_data
            self.state["last_market_update"] = datetime.now(tz=timezone.utc).isoformat()

            # Process each symbol for sentiment analysis
            for symbol, data in market_data.items():
                if symbol in self.trading_symbols:
                    price = data.get("price", 0)
                    volume = data.get("volume", 0)
                    change_24h = data.get("change_24h", 0)

                    if price > 0:
                        # Calculate market sentiment for this symbol
                        sentiment = await self.calculate_market_sentiment(symbol, price, volume, change_24h)

                        # Update sentiment history
                        if symbol not in self.state["sentiment_history"]:
                            self.state["sentiment_history"][symbol] = {
                                "news": [],
                                "social": [],
                                "market": [],
                                "technical": [],
                            }

                        if "market_data" not in self.state["sentiment_history"][symbol]:
                            self.state["sentiment_history"][symbol]["market_data"] = []

                        self.state["sentiment_history"][symbol]["market_data"].append(
                            {
                                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                                "sentiment": sentiment,
                            }
                        )

            # Aggregate sentiment with new market data
            await self.aggregate_all_sentiment()

            # Generate sentiment signals
            await self.generate_sentiment_signals()

            # Update sentiment metrics
            await self.update_sentiment_metrics()

            logger.info("[OK] Market data processed for sentiment analysis")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error processing market data for sentiment analysis")
            await self.broadcast_error(f"Sentiment analysis market data error: {e}")
