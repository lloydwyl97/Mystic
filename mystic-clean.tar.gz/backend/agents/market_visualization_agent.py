import asyncio
import base64
import contextlib
import io
import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Any

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

from backend.agents.base_agent import BaseAgent
from backend.services.task_manager import task_manager

logger = logging.getLogger(__name__)

"""
Market Visualization Agent
Handles market visualization and chart generation for trading analysis
"""


class MarketVisualizationAgent(BaseAgent):
    """Market Visualization Agent - Generates charts and visual analysis"""

    def __init__(self, agent_id: str = "market_visualization_agent_001") -> None:
        super().__init__(agent_id, "market_visualization")

        # Visualization-specific state
        self.state.update(
            {
                "charts_generated": {},
                "visual_analysis": {},
                "chart_cache": {},
                "last_generation": None,
                "generation_count": 0,
            },
        )

        # Chart configuration
        self.chart_config = {
            "chart_types": [
                "candlestick",
                "line",
                "volume",
                "heatmap",
                "correlation",
            ],
            "timeframes": ["1m", "5m", "15m", "1h", "4h", "1d"],
            "indicators": ["sma", "ema", "bollinger_bands", "rsi", "macd"],
            "chart_style": "dark_background",
        }

        # Trading symbols to monitor
        self.trading_symbols = [
            "BTC",
            "ETH",
            "ADA",
            "DOT",
            "LINK",
            "UNI",
            "AAVE",
        ]

        # Register visualization-specific handlers
        self.register_handler("generate_chart", self.handle_generate_chart)
        self.register_handler("get_visual_analysis", self.handle_get_visual_analysis)
        self.register_handler("market_data", self.handle_market_data)

        logger.info(f"ðŸ“Š Market Visualization Agent {agent_id} initialized")

    async def initialize(self):
        """Initialize market visualization agent resources"""
        try:
            # Load chart configuration
            await self.load_chart_config()

            # Initialize visualization settings
            await self.initialize_visualization_settings()

            # Start chart monitoring
            await self.start_chart_monitoring()

            logger.info(f"âœ… Market Visualization Agent {self.agent_id} initialized successfully")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error initializing Market Visualization Agent")
            self.update_health_status("error")

    async def process_loop(self):
        """Main visualization processing loop"""
        while self.running:
            try:
                # Generate charts for all symbols
                await self.generate_all_charts()

                # Update visualization metrics
                await self.update_visualization_metrics()

                # Clean up old cache entries
                await self.cleanup_cache()

                await asyncio.sleep(300)  # Check every 5 minutes

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("âŒ Error in visualization processing loop")
                await asyncio.sleep(600)

    async def load_chart_config(self):
        """Load chart configuration from Redis"""
        try:
            # Load chart configuration
            config_data = self.redis_client.get("chart_config")
            if config_data:
                # redis returns bytes sometimes
                if isinstance(config_data, (bytes, bytearray)):
                    config_data = config_data.decode()
                self.chart_config = json.loads(config_data)

            # Load trading symbols
            symbols_data = self.redis_client.get("trading_symbols")
            if symbols_data:
                if isinstance(symbols_data, (bytes, bytearray)):
                    symbols_data = symbols_data.decode()
                self.trading_symbols = json.loads(symbols_data)

            logger.info(f"Chart configuration loaded: {len(self.chart_config.get('chart_types', []))} chart types, {len(self.trading_symbols)} symbols")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error loading chart configuration")

    async def initialize_visualization_settings(self):
        """Initialize visualization settings"""
        try:
            # Set matplotlib style
            plt.style.use(self.chart_config.get("chart_style", "dark_background"))

            # Configure seaborn
            sns.set_palette("husl")

            logger.info("ðŸŽ¨ Visualization settings initialized")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error initializing visualization settings")

    async def start_chart_monitoring(self):
        """Start chart monitoring"""
        try:
            # Subscribe to market data for chart generation
            pubsub = self.redis_client.pubsub()
            pubsub.subscribe("market_data")

            # Start market data listener
            task = await task_manager.create_task(self.listen_market_data(pubsub), name="market_visualization_agent:listen_market_data")
            self._tasks.append(task)

            logger.info("ðŸ“¡ Chart monitoring started")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error starting chart monitoring")

    async def listen_market_data(self, pubsub):
        """Listen for market data updates"""
        try:
            for message in pubsub.listen():
                if not self.running:
                    break

                if message.get("type") == "message":
                    raw = message.get("data")
                    try:
                        if isinstance(raw, (bytes, bytearray)):
                            raw = raw.decode()
                        market_data = json.loads(raw)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        # If it's already a dict or cannot be decoded, attempt to use it directly
                        market_data = raw if isinstance(raw, dict) else None

                    if market_data:
                        await self.process_market_data(market_data)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error in market data listener")
        finally:
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pubsub.close()

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process market data for chart generation"""
        try:
            symbol = market_data.get("symbol")
            price = market_data.get("price")
            volume = market_data.get("volume", 0)
            timestamp = market_data.get("timestamp")

            # Store market data for chart generation
            if symbol and price is not None and timestamp:
                await self.store_market_data(symbol, price, volume, timestamp)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error processing market data")

    async def store_market_data(self, symbol: str, price: float, volume: float, timestamp: str):
        """Store market data for chart generation"""
        try:
            # Create data point
            data_point = {
                "symbol": symbol,
                "price": price,
                "volume": volume,
                "timestamp": timestamp,
            }

            # Store in Redis with expiration
            cache_key = f"visualization_data:{symbol}:{timestamp}"
            try:
                self.redis_client.set(cache_key, json.dumps(data_point), ex=3600)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # redis client may not accept ex kw in certain wrappers; fallback
                try:
                    self.redis_client.set(cache_key, json.dumps(data_point))
                    self.redis_client.expire(cache_key, 3600)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    pass

            # Update symbol data cache
            if symbol not in self.state["chart_cache"]:
                self.state["chart_cache"][symbol] = []

            self.state["chart_cache"][symbol].append(data_point)

            # Keep only recent data points
            if len(self.state["chart_cache"][symbol]) > 200:
                self.state["chart_cache"][symbol] = self.state["chart_cache"][symbol][-200:]

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error storing market data")

    async def generate_all_charts(self):
        """Generate charts for all symbols"""
        try:
            logger.info(f"ðŸ“Š Generating charts for {len(self.trading_symbols)} symbols...")

            for symbol in self.trading_symbols:
                try:
                    await self.generate_symbol_charts(symbol)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception("âŒ Error generating charts for {symbol}")

            # Update generation count
            self.state["generation_count"] += 1
            self.state["last_generation"] = datetime.now(tz=timezone.utc).isoformat()

            logger.info("âœ… Chart generation complete")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error generating all charts")

    async def get_symbol_market_data(self, symbol: str) -> list[dict[str, Any]]:
        """Retrieve market data for a symbol from cache or Redis fallback"""
        try:
            # Prefer in-memory cache
            cache = self.state.get("chart_cache", {})
            if cache.get(symbol):
                # return a shallow copy to avoid external mutation
                return list(cache[symbol])

            # Fallback: try to scan Redis keys for the symbol
            pattern = f"visualization_data:{symbol}:*"
            try:
                keys = list(self.redis_client.scan_iter(match=pattern, count=100))
                if not keys:
                    return []
                # keys might be bytes
                keys = [k.decode() if isinstance(k, (bytes, bytearray)) else k for k in keys]
                data_points = []
                for k in keys:
                    raw = self.redis_client.get(k)
                    if not raw:
                        continue
                    if isinstance(raw, (bytes, bytearray)):
                        with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                            raw = raw.decode()
                    try:
                        dp = json.loads(raw)
                        data_points.append(dp)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        continue
                # sort by timestamp
                data_points = sorted(data_points, key=lambda x: x.get("timestamp", ""))
                # store in cache
                if data_points:
                    self.state["chart_cache"][symbol] = data_points

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                return []
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error getting symbol market data")
            return []

    async def generate_symbol_charts(self, symbol: str):
        """Generate charts for a specific symbol"""
        try:
            # Get market data for symbol
            market_data = await self.get_symbol_market_data(symbol)

            if not market_data or len(market_data) < 20:
                return

            # Generate different chart types
            charts: dict[str, Any] = {}

            for chart_type in self.chart_config.get("chart_types", []):
                try:
                    chart_obj = await self.generate_chart_type(symbol, market_data, chart_type)
                    if chart_obj:
                        charts[chart_obj.get("type", chart_type)] = chart_obj
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception("âŒ Error generating {chart_type} for {symbol}")

            # Persist generated charts in state and Redis
            if charts:
                self.state["charts_generated"][symbol] = charts
                try:
                    self.redis_client.set(f"charts:{symbol}", json.dumps(charts), ex=3600)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        self.redis_client.set(f"charts:{symbol}", json.dumps(charts))

                # Broadcast updates
                await self.broadcast_chart_generation(symbol, charts)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error generating symbol charts for {symbol}")

    async def generate_chart_type(self, symbol: str, market_data: list[dict[str, Any]], chart_type: str) -> dict[str, Any] | None:
        """Dispatch to specific chart generators"""
        try:
            chart_type = (chart_type or "").lower()
            if chart_type == "heatmap":
                return await self.generate_heatmap_chart(symbol, market_data)
            if chart_type == "correlation":
                return await self.generate_correlation_chart(symbol, market_data)
            if chart_type == "line":
                return await self.generate_line_chart(symbol, market_data)
            if chart_type == "volume":
                return await self.generate_volume_chart(symbol, market_data)
            if chart_type == "candlestick":
                return await self.generate_candlestick_chart(symbol, market_data)

            # Default fallback: line chart
            return await self.generate_line_chart(symbol, market_data)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error generating chart type {chart_type} for {symbol}")
            return None

    async def generate_line_chart(self, symbol: str, market_data: list[dict[str, Any]]) -> dict[str, Any] | None:
        """Generate a simple line chart of price over time"""
        try:
            df = pd.DataFrame(market_data)
            df["timestamp"] = pd.to_datetime(df["timestamp"])
            df = df.sort_values("timestamp")

            fig, ax = plt.subplots(figsize=(10, 4))
            ax.plot(df["timestamp"], df["price"], label="Price", color="#1f77b4")
            ax.set_title(f"{symbol} Price Over Time")
            ax.set_xlabel("Time")
            ax.set_ylabel("Price")
            ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d %H:%M"))
            fig.autofmt_xdate()
            ax.legend()

            plt.tight_layout()
            chart_data = await self.figure_to_base64(fig)
            plt.close(fig)

            return {
                "type": "line",
                "data": chart_data,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error generating line chart")
            return None

    async def generate_volume_chart(self, symbol: str, market_data: list[dict[str, Any]]) -> dict[str, Any] | None:
        """Generate a volume chart"""
        try:
            df = pd.DataFrame(market_data)
            df["timestamp"] = pd.to_datetime(df["timestamp"])
            df = df.sort_values("timestamp")

            fig, ax = plt.subplots(figsize=(10, 3))
            ax.bar(df["timestamp"], df["volume"], width=0.0005, color="#6baed6")
            ax.set_title(f"{symbol} Volume Over Time")
            ax.set_xlabel("Time")
            ax.set_ylabel("Volume")
            ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d %H:%M"))
            fig.autofmt_xdate()

            plt.tight_layout()
            chart_data = await self.figure_to_base64(fig)
            plt.close(fig)

            return {
                "type": "volume",
                "data": chart_data,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error generating volume chart")
            return None

    async def generate_candlestick_chart(self, symbol: str, market_data: list[dict[str, Any]]) -> dict[str, Any] | None:
        """Generate a simplified candlestick-like chart from price series"""
        try:
            df = pd.DataFrame(market_data)
            df["timestamp"] = pd.to_datetime(df["timestamp"])
            df = df.sort_values("timestamp").reset_index(drop=True)

            # Create OHLC by grouping into buckets
            n_buckets = min(50, max(1, len(df) // 4))
            group_size = max(1, len(df) // n_buckets)
            df["group"] = (np.arange(len(df)) // group_size).astype(int)

            ohlc = (
                df.groupby("group")
                .agg(
                    open=("price", "first"),
                    high=("price", "max"),
                    low=("price", "min"),
                    close=("price", "last"),
                    timestamp=("timestamp", "first"),
                )
                .reset_index(drop=True)
            )

            fig, ax = plt.subplots(figsize=(12, 4))
            ax.set_title(f"{symbol} Candlestick (Simplified)")
            ax.set_xlabel("Time")
            ax.set_ylabel("Price")

            # Plot high-low as vertical lines and open-close as thicker lines
            for _idx, row in ohlc.iterrows():
                t = row["timestamp"]
                high = row["high"]
                low = row["low"]
                open_p = row["open"]
                close_p = row["close"]
                color = "#26a69a" if close_p >= open_p else "#ef5350"
                # vertical line
                ax.vlines(t, low, high, color=color, linewidth=1)
                # thicker line for open-close
                ax.plot([t, t], [open_p, close_p], color=color, linewidth=6)

            ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d %H:%M"))
            fig.autofmt_xdate()
            plt.tight_layout()

            chart_data = await self.figure_to_base64(fig)
            plt.close(fig)

            return {
                "type": "candlestick",
                "data": chart_data,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error generating candlestick chart")
            return None

    async def generate_heatmap_chart(self, symbol: str, market_data: list[dict[str, Any]]) -> dict[str, Any] | None:
        """Generate a simplified heatmap of recent price changes"""
        try:
            df = pd.DataFrame(market_data)
            df["timestamp"] = pd.to_datetime(df["timestamp"])
            df = df.sort_values("timestamp")

            # Calculate percent changes
            price_changes = df["price"].pct_change().dropna()

            # Reshape for heatmap (simplified)
            n_periods = 10
            if len(price_changes) >= n_periods:
                changes_matrix = price_changes.tail(n_periods).to_numpy().reshape(1, -1)

                # Create figure
                fig, ax = plt.subplots(figsize=(12, 4))

                # Create heatmap
                sns.heatmap(
                    changes_matrix,
                    ax=ax,
                    cmap="RdYlGn",
                    center=0,
                    cbar_kws={"label": "Price Change %"},
                )

                ax.set_title(f"{symbol} Price Change Heatmap")
                ax.set_xlabel("Time Periods")
                ax.set_ylabel("Price Changes")

                # Adjust layout
                plt.tight_layout()

                # Convert to base64
                chart_data = await self.figure_to_base64(fig)
                plt.close(fig)

                return {
                    "type": "heatmap",
                    "data": chart_data,
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error generating heatmap chart")
            return None

    async def generate_correlation_chart(self, symbol: str, market_data: list[dict[str, Any]]) -> dict[str, Any] | None:
        """Generate correlation chart"""
        try:
            # Convert to DataFrame
            df = pd.DataFrame(market_data)
            df["timestamp"] = pd.to_datetime(df["timestamp"])
            df = df.sort_values("timestamp")

            # Calculate correlations
            df["price_change"] = df["price"].pct_change()
            df["volume_change"] = df["volume"].pct_change()

            # Create correlation matrix
            correlation_data = df[["price", "volume", "price_change", "volume_change"]].corr()

            # Create figure
            fig, ax = plt.subplots(figsize=(8, 6))

            # Create correlation heatmap
            sns.heatmap(
                correlation_data,
                ax=ax,
                annot=True,
                cmap="coolwarm",
                center=0,
                square=True,
            )

            ax.set_title(f"{symbol} Correlation Matrix")

            # Adjust layout
            plt.tight_layout()

            # Convert to base64
            chart_data = await self.figure_to_base64(fig)
            plt.close()

            return {
                "type": "correlation",
                "data": chart_data,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error generating correlation chart")
            return None

    async def figure_to_base64(self, fig) -> str:
        """Convert matplotlib figure to base64 string"""
        try:
            # Save figure to bytes buffer
            buf = io.BytesIO()
            fig.savefig(buf, format="png", dpi=100, bbox_inches="tight")
            buf.seek(0)

            # Convert to base64
            return base64.b64encode(buf.getvalue()).decode()

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error converting figure to base64")
            return ""

    async def broadcast_chart_generation(self, symbol: str, charts: dict[str, Any]):
        """Broadcast chart generation to other agents"""
        try:
            chart_update = {
                "type": "chart_generation_update",
                "symbol": symbol,
                "charts": charts,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Broadcast to all agents
            await self.broadcast_message(chart_update)

            # Send to specific agents
            await self.send_message("chart_pattern_agent", chart_update)
            await self.send_message("technical_indicator_agent", chart_update)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error broadcasting chart generation")

    async def handle_generate_chart(self, message: dict[str, Any]):
        """Handle manual chart generation request"""
        try:
            symbol = message.get("symbol")
            chart_type = message.get("chart_type", "candlestick")

            logger.info(f"ðŸ“Š Manual chart generation requested for {symbol}")

            if symbol:
                market_data = await self.get_symbol_market_data(symbol)
                if market_data:
                    chart_data = await self.generate_chart_type(symbol, market_data, chart_type)

                    response = {
                        "type": "chart_generation_response",
                        "symbol": symbol,
                        "chart_type": chart_type,
                        "chart_data": chart_data,
                        "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                    }
                else:
                    response = {
                        "type": "chart_generation_response",
                        "symbol": symbol,
                        "chart_type": chart_type,
                        "chart_data": None,
                        "error": "No market data available",
                        "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                    }
            else:
                response = {
                    "type": "chart_generation_response",
                    "symbol": symbol,
                    "chart_type": chart_type,
                    "chart_data": None,
                    "error": "No symbol provided",
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("âŒ Error handling chart generation request")
            await self.broadcast_error(f"Chart generation error: {e}")

    async def handle_market_data(self, message: dict[str, Any]):
        """Handle incoming market data updates"""
        try:
            await self.process_market_data(message)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error handling market data: {e}")

    async def handle_get_visual_analysis(self, message: dict[str, Any]):
        """Handle visual analysis request"""
        try:
            symbol = message.get("symbol")

            logger.info(f"Visual analysis requested for {symbol}")

            # Get visual analysis
            if symbol and symbol in self.state["charts_generated"]:
                charts = self.state["charts_generated"][symbol]

                response = {
                    "type": "visual_analysis_response",
                    "symbol": symbol,
                    "charts": charts,
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                }
            else:
                response = {
                    "type": "visual_analysis_response",
                    "symbol": symbol,
                    "charts": None,
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("âŒ Error handling visual analysis request")
            await self.broadcast_error(f"Visual analysis error: {e}")

    async def update_visualization_metrics(self):
        """Update visualization metrics"""
        try:
            metrics = {
                "agent_id": self.agent_id,
                "symbols_count": len(self.trading_symbols),
                "chart_types_count": len(self.chart_config.get("chart_types", [])),
                "charts_generated": len(self.state["charts_generated"]),
                "generation_count": self.state["generation_count"],
                "last_generation": self.state["last_generation"],
                "cache_size": len(self.state["chart_cache"]),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Store metrics in Redis
            try:
                self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics), ex=300)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                try:
                    self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics))
                    self.redis_client.expire(f"agent_metrics:{self.agent_id}", 300)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    pass

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error updating visualization metrics")

    async def cleanup_cache(self):
        """Clean up old cache entries"""
        try:
            current_time = datetime.now(tz=timezone.utc)

            # Clean up old chart cache entries
            for symbol in list(self.state["chart_cache"].keys()):
                data_points = self.state["chart_cache"][symbol]

                # Keep only recent data points (last 24 hours)
                cutoff_time = current_time - timedelta(hours=24)
                recent_data = []
                for point in data_points:
                    try:
                        ts = datetime.fromisoformat(point["timestamp"])
                        if ts > cutoff_time:
                            recent_data.append(point)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        # If timestamp parsing fails, drop the point
                        continue

                if recent_data:
                    self.state["chart_cache"][symbol] = recent_data
                else:
                    del self.state["chart_cache"][symbol]

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error cleaning up cache")
