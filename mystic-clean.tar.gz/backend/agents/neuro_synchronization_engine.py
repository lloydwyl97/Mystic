import asyncio
import contextlib
import json
import logging
import threading
import time
from datetime import datetime, timedelta, timezone
from typing import Any

import numpy as np

from backend.agents.base_agent import BaseAgent

logger = logging.getLogger(__name__)

"""
Neuro-Synchronization Engine
Links internal brainwave profiles (theta/alpha ranges) to system parameters
for resonance-aligned decision making
"""


class NeuroSynchronizationEngine(BaseAgent):
    """Neuro-Synchronization Engine - Links brainwave profiles to system parameters"""

    def __init__(self, agent_id: str = "neuro_sync_engine_001") -> None:
        super().__init__(agent_id, "neuro_synchronization")

        # Random number generator for live data operations
        self.rng = np.random.default_rng()

        # Neuro-sync specific state
        self.state.update(
            {
                "brainwave_profiles": {},
                "system_parameters": {},
                "resonance_states": {},
                "biofeedback_data": {},
                "synchronization_history": [],
                "last_sync": None,
                "sync_count": 0,
                "resonance_quality": 0.0,
            },
        )

        # Brainwave frequency bands
        self.brainwave_bands = {
            "delta": (0.5, 4.0),  # Deep sleep, unconscious processing
            "theta": (4.0, 8.0),  # Meditation, creativity, intuition
            "alpha": (8.0, 13.0),  # Relaxed awareness, calm focus
            "beta": (13.0, 30.0),  # Active thinking, concentration
            "gamma": (30.0, 100.0),  # High-level processing, insight
            "epsilon": (0.1, 0.5),  # Deep meditation, spiritual states
            "lambda": (100.0, 200.0),  # Hyper-gamma, peak performance
        }

        # System parameter mappings
        self.parameter_mappings = {
            "risk_tolerance": {
                "delta": 0.1,  # Low risk in deep states
                "theta": 0.3,  # Moderate risk in creative states
                "alpha": 0.5,  # Balanced risk in calm states
                "beta": 0.7,  # Higher risk in active states
                "gamma": 0.9,  # High risk in peak states
                "epsilon": 0.2,  # Very low risk in deep meditation
                "lambda": 1.0,  # Maximum risk in hyper states
            },
            "aggression_level": {
                "delta": 0.1,
                "theta": 0.2,
                "alpha": 0.4,
                "beta": 0.6,
                "gamma": 0.8,
                "epsilon": 0.1,
                "lambda": 0.9,
            },
            "holding_duration": {
                "delta": 24.0,  # Long holds in deep states
                "theta": 12.0,  # Medium-long holds in creative states
                "alpha": 6.0,  # Medium holds in calm states
                "beta": 2.0,  # Short holds in active states
                "gamma": 1.0,  # Very short holds in peak states
                "epsilon": 48.0,  # Very long holds in deep meditation
                "lambda": 0.5,  # Ultra-short holds in hyper states
            },
            "position_size": {
                "delta": 0.1,
                "theta": 0.3,
                "alpha": 0.5,
                "beta": 0.7,
                "gamma": 0.9,
                "epsilon": 0.2,
                "lambda": 1.0,
            },
        }

        # EEG/BCI simulation parameters
        self.eeg_simulation = {
            "enabled": True,
            "sample_rate": 256,  # Hz
            "channels": [
                "Fp1",
                "Fp2",
                "F7",
                "F3",
                "Fz",
                "F4",
                "F8",
                "T3",
                "C3",
                "Cz",
                "C4",
                "T4",
                "T5",
                "P3",
                "Pz",
                "P4",
                "T6",
                "O1",
                "O2",
            ],
            "noise_level": 0.1,
            "signal_strength": 0.8,
        }

        # Resonance frequency presets
        self.resonance_presets = {
            "meditation": {
                "target_bands": ["theta", "alpha"],
                "frequency": 7.83,  # Schumann resonance
                "intensity": 0.8,
            },
            "focus": {
                "target_bands": ["beta", "gamma"],
                "frequency": 40.0,
                "intensity": 0.9,
            },
            "creativity": {
                "target_bands": ["theta", "gamma"],
                "frequency": 6.0,
                "intensity": 0.7,
            },
            "deep_work": {
                "target_bands": ["alpha", "beta"],
                "frequency": 10.0,
                "intensity": 0.8,
            },
            "peak_performance": {
                "target_bands": ["gamma", "lambda"],
                "frequency": 60.0,
                "intensity": 1.0,
            },
        }

        # Register neuro-sync specific handlers
        self.register_handler("sync_brainwaves", self.handle_sync_brainwaves)
        self.register_handler("set_resonance_preset", self.handle_set_resonance_preset)
        self.register_handler("get_biofeedback", self.handle_get_biofeedback)
        self.register_handler("update_parameters", self.handle_update_parameters)

        # Attributes for EEG simulation
        self.eeg_generator = None
        self.eeg_thread: threading.Thread | None = None

        logger.info(f"🧠 Neuro-Synchronization Engine {agent_id} initialized")

    async def initialize(self):
        """Initialize neuro-synchronization engine resources"""
        try:
            # Load neuro-sync configuration
            await self.load_neuro_config()

            # Initialize EEG/BCI interface
            await self.initialize_eeg_interface()

            # Start brainwave monitoring
            await self.start_brainwave_monitoring()

            logger.info(f"✔ Neuro-Synchronization Engine {self.agent_id} initialized successfully")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error initializing Neuro-Synchronization Engine")
            try:
                self.update_health_status("error")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to update health status during initialization error handling")

    async def process_loop(self):
        """Main neuro-synchronization processing loop"""
        while self.running:
            try:
                # Monitor brainwave activity
                await self.monitor_brainwave_activity()

                # Update system parameters
                await self.update_system_parameters()

                # Check resonance states
                await self.check_resonance_states()

                # Process biofeedback
                await self.process_biofeedback()

                # Update synchronization metrics
                await self.update_sync_metrics()

                # Clean up old data
                await self.cleanup_old_data()

                await asyncio.sleep(30)  # Check every 30 seconds

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Error in neuro-synchronization processing loop")
                await asyncio.sleep(60)

    async def load_neuro_config(self):
        """Load neuro-synchronization configuration from Redis"""
        try:
            # Load brainwave bands
            bands_data = None
            try:
                bands_data = self.redis_client.get("brainwave_bands")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                bands_data = None
            if bands_data:
                try:
                    self.brainwave_bands.update(json.loads(bands_data))
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception("Failed to parse brainwave_bands from redis")

            # Load parameter mappings
            mappings_data = None
            try:
                mappings_data = self.redis_client.get("parameter_mappings")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                mappings_data = None
            if mappings_data:
                try:
                    self.parameter_mappings.update(json.loads(mappings_data))
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception("Failed to parse parameter_mappings from redis")

            # Load resonance presets
            presets_data = None
            try:
                presets_data = self.redis_client.get("resonance_presets")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                presets_data = None
            if presets_data:
                try:
                    self.resonance_presets.update(json.loads(presets_data))
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception("Failed to parse resonance_presets from redis")

            logger.info("Neuro-synchronization configuration loaded")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error loading neuro configuration")

    async def initialize_eeg_interface(self):
        """Initialize EEG/BCI interface"""
        try:
            if self.eeg_simulation.get("enabled", False):
                # Initialize simulated EEG data generator
                self.eeg_generator = self.create_eeg_generator()

                # Start EEG data generation thread
                self.eeg_thread = threading.Thread(target=self.generate_eeg_data, daemon=True)
                self.eeg_thread.start()

                logger.info("🧪 EEG/BCI interface initialized (simulation)")
            else:
                logger.info("🔌 EEG/BCI hardware interface not enabled; skipped initialization")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error initializing EEG interface")

    def create_eeg_generator(self):
        """Create a simulated EEG generator function"""
        channels = list(self.eeg_simulation.get("channels", []))
        noise_level = float(self.eeg_simulation.get("noise_level", 0.1))
        signal_strength = float(self.eeg_simulation.get("signal_strength", 0.8))
        base_freqs = np.linspace(1.0, 30.0, num=max(1, len(channels)))

        def generator():
            t = time.time()
            values = {}
            for idx, ch in enumerate(channels):
                freq = float(base_freqs[idx % len(base_freqs)])
                # simple sinusoidal component + noise
                val = signal_strength * np.sin(2.0 * np.pi * freq * t) + float(self.rng.normal(scale=noise_level))
                values[ch] = float(val)
            return values

        return generator

    def generate_eeg_data(self):
        """Continuously generate simulated EEG data in a background thread"""
        sample_interval = 1.0  # produce a summarized sample every second (not raw sample_rate-level)
        try:
            while getattr(self, "running", True):
                try:
                    if not self.eeg_generator:
                        time.sleep(sample_interval)
                        continue

                    sample = self.eeg_generator()
                    timestamp = datetime.now(tz=timezone.utc).isoformat()

                    # Store raw-ish profile per timestamp
                    try:
                        self.state["brainwave_profiles"][timestamp] = sample
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        logger.exception("Failed to store brainwave profile sample")

                    # Simulate band power summary and store in biofeedback_data
                    band_powers = {}
                    for band_name, (_low, _high) in self.brainwave_bands.items():
                        # Simulate some power value influenced by signal_strength and noise
                        base = float(self.eeg_simulation.get("signal_strength", 0.8)) * 0.5
                        noise = float(self.eeg_simulation.get("noise_level", 0.1))
                        val = abs(self.rng.normal(loc=base, scale=noise))
                        band_powers[band_name] = float(val)

                    try:
                        self.state["biofeedback_data"][timestamp] = {"band_powers": band_powers}
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        logger.exception("Failed to store biofeedback sample")

                    time.sleep(sample_interval)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception("Error in EEG data generation loop; sleeping briefly")
                    time.sleep(1.0)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("EEG data generation thread terminated unexpectedly")

    # The following methods are expected to exist on BaseAgent or elsewhere.
    # We provide minimal safe async wrappers that call into BaseAgent where appropriate.
    async def start_brainwave_monitoring(self):
        """Start any additional monitoring tasks (placeholder)"""
        # This method is kept minimal to preserve public API.
        return True

    async def monitor_brainwave_activity(self):
        """Monitor brainwave activity - placeholder to integrate with real monitoring"""
        # If simulation is used, data is already being generated; this can compute derivatives or checks.
        await asyncio.sleep(0)  # yield control

    async def update_system_parameters(self):
        """Update system parameters based on latest biofeedback (placeholder)"""
        await asyncio.sleep(0)  # yield control

    async def check_resonance_states(self):
        """Check and update resonance states (placeholder)"""
        await asyncio.sleep(0)

    async def process_biofeedback(self):
        """Process biofeedback data to update internal state (placeholder)"""
        await asyncio.sleep(0)

    async def update_sync_metrics(self):
        """Update synchronization metrics (placeholder)"""
        await asyncio.sleep(0)

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process market data for neuro synchronization"""
        try:
            logger.debug("Neuro Synchronization Engine processing market data")
            self.state["last_market_data"] = market_data
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error processing market data")

    async def cleanup_old_data(self):
        """Clean up old data"""
        try:
            # Clean up brainwave profiles (keep last 50)
            profile_keys = list(self.state["brainwave_profiles"].keys())
            if len(profile_keys) > 50:
                for key in profile_keys[:-50]:
                    with contextlib.suppress(KeyError):
                        del self.state["brainwave_profiles"][key]

            # Clean up resonance states (keep last 30)
            resonance_keys = list(self.state["resonance_states"].keys())
            if len(resonance_keys) > 30:
                for key in resonance_keys[:-30]:
                    with contextlib.suppress(KeyError):
                        del self.state["resonance_states"][key]

            # Clean up biofeedback data (keep last 40)
            biofeedback_keys = list(self.state["biofeedback_data"].keys())
            if len(biofeedback_keys) > 40:
                for key in biofeedback_keys[:-40]:
                    with contextlib.suppress(KeyError):
                        del self.state["biofeedback_data"][key]

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error cleaning up old data")

    async def handle_sync_brainwaves(self, message: dict[str, Any]):
        """Handle manual brainwave synchronization request"""
        try:
            target_band = message.get("target_band", "alpha")
            duration = message.get("duration", 300)  # 5 minutes

            logger.info(f"🧠 Manual brainwave synchronization requested for {target_band} band")

            # Perform targeted synchronization
            sync_result = await self.perform_targeted_sync(target_band, duration)

            # Send response
            response = {
                "type": "brainwave_sync_complete",
                "target_band": target_band,
                "duration": duration,
                "sync_result": sync_result,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling brainwave sync request")
            try:
                await self.broadcast_error("Brainwave sync error")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to broadcast error for brainwave sync request")

    async def perform_targeted_sync(self, target_band: str, duration: int) -> dict[str, Any]:
        """Perform targeted brainwave synchronization"""
        try:
            # Get target frequency
            target_freq = self.brainwave_bands.get(target_band, (8.0, 13.0))
            target_frequency = float(np.mean(target_freq))

            # Create synchronization session
            sync_session = {
                "target_band": target_band,
                "target_frequency": target_frequency,
                "duration": duration,
                "start_time": datetime.now(tz=timezone.utc).isoformat(),
                "status": "active",
            }

            try:
                # Store session if redis client available
                if hasattr(self, "redis_client") and getattr(self, "redis_client", None):
                    try:
                        self.redis_client.set("sync_session", json.dumps(sync_session), ex=duration)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        logger.exception("Failed to set sync_session in redis")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pass

            # Simulate synchronization process
            await asyncio.sleep(2)  # Simulate processing time

            # Complete session
            sync_session["status"] = "completed"
            sync_session["end_time"] = datetime.now(tz=timezone.utc).isoformat()

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error performing targeted sync")
            return {"error": "Sync error"}
        else:
            return sync_session

    async def handle_set_resonance_preset(self, message: dict[str, Any]):
        """Handle resonance preset setting request"""
        try:
            preset_name = message.get("preset_name", "meditation")

            logger.info(f"🎵 Setting resonance preset: {preset_name}")

            # Get preset configuration
            preset = self.resonance_presets.get(preset_name, self.resonance_presets["meditation"])

            # Apply preset
            preset_result = await self.apply_resonance_preset(preset)

            # Send response
            response = {
                "type": "resonance_preset_set",
                "preset_name": preset_name,
                "preset_config": preset,
                "result": preset_result,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling resonance preset request")
            try:
                await self.broadcast_error("Resonance preset error")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to broadcast resonance preset error")

    async def apply_resonance_preset(self, preset: dict[str, Any]) -> dict[str, Any]:
        """Apply resonance preset"""
        try:
            target_bands = preset.get("target_bands", ["alpha"])
            frequency = float(preset.get("frequency", 10.0))
            intensity = float(preset.get("intensity", 0.8))

            # Apply preset to system
            preset_config = {
                "target_bands": target_bands,
                "frequency": frequency,
                "intensity": intensity,
                "applied_at": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Store preset configuration
            try:
                if hasattr(self, "redis_client") and getattr(self, "redis_client", None):
                    try:
                        self.redis_client.set("active_resonance_preset", json.dumps(preset_config), ex=3600)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        logger.exception("Failed to store active_resonance_preset in redis")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pass

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error applying resonance preset")
            return {"error": "Preset error"}
        else:
            return preset_config

    async def handle_get_biofeedback(self, message: dict[str, Any]):
        """Handle biofeedback data request"""
        try:
            data_type = message.get("data_type", "all")
            timeframe = message.get("timeframe", "1h")

            logger.info(f"[STATS] Biofeedback data request for {data_type} ({timeframe})")

            # Get biofeedback data
            biofeedback_data = await self.get_biofeedback_data(data_type, timeframe)

            # Send response
            response = {
                "type": "biofeedback_data_response",
                "data_type": data_type,
                "timeframe": timeframe,
                "biofeedback_data": biofeedback_data,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling biofeedback request")
            try:
                await self.broadcast_error("Biofeedback request error")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to broadcast biofeedback request error")

    async def get_biofeedback_data(self, data_type: str, timeframe: str) -> dict[str, Any]:
        """Get biofeedback data"""
        try:
            # Calculate cutoff time
            cutoff_time = datetime.now(tz=timezone.utc)
            if timeframe == "30m":
                cutoff_time -= timedelta(minutes=30)
            elif timeframe == "1h":
                cutoff_time -= timedelta(hours=1)
            elif timeframe == "6h":
                cutoff_time -= timedelta(hours=6)
            elif timeframe == "24h":
                cutoff_time -= timedelta(hours=24)
            else:
                cutoff_time -= timedelta(hours=1)

            # Filter biofeedback data by timeframe
            filtered_data = {}
            for timestamp, data in self.state["biofeedback_data"].items():
                if isinstance(timestamp, str):
                    try:
                        data_time = datetime.fromisoformat(timestamp)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        continue
                    if data_time > cutoff_time and (data_type == "all" or data_type in data):
                        filtered_data[timestamp] = data

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error getting biofeedback data")
            return {}
        else:
            return filtered_data

    async def handle_update_parameters(self, message: dict[str, Any]):
        """Handle parameter update request"""
        try:
            parameters = message.get("parameters", {})

            logger.info("Parameter update request received")

            # Update system parameters
            self.state["system_parameters"].update(parameters)

            # Broadcast updates
            try:
                await self.broadcast_parameter_updates(self.state["system_parameters"])
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to broadcast parameter updates")

            # Send confirmation
            response = {
                "type": "parameter_update_complete",
                "updated_parameters": parameters,
                "current_parameters": self.state["system_parameters"],
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error handling parameter update request")
            try:
                await self.broadcast_error("Parameter update error")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to broadcast parameter update error")


if __name__ == "__main__":
    # Run the agent
    engine = NeuroSynchronizationEngine()
    try:
        asyncio.run(engine.start())
    except KeyboardInterrupt:
        # Graceful shutdown if possible
        with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            engine.running = False
        logger.info("NeuroSynchronizationEngine stopped by KeyboardInterrupt")
