import asyncio
import contextlib
import json
import logging
import os
import re
from datetime import datetime, timedelta, timezone
from typing import Any

import feedparser
import httpx
import numpy as np
from textblob import TextBlob

from backend.agents.base_agent import BaseAgent
from backend.services.task_manager import task_manager

logger = logging.getLogger(__name__)

"""
News Sentiment Agent
Handles financial news analysis and sentiment extraction
"""


class NewsSentimentAgent(BaseAgent):
    """News Sentiment Agent - Analyzes financial news and extracts sentiment"""

    def __init__(self, agent_id: str = "news_sentiment_agent_001") -> None:
        super().__init__(agent_id, "news_sentiment")

        # News-specific state
        self.state.update(
            {
                "news_sources": [],
                "sentiment_cache": {},
                "keyword_sentiment": {},
                "symbol_sentiment": {},
                "last_analysis": None,
                "analysis_count": 0,
            },
        )

        # News sources configuration
        self.news_sources = [
            {
                "name": "Reuters Business",
                "url": "http://feeds.reuters.com/reuters/businessNews",
                "type": "rss",
                "keywords": [
                    "crypto",
                    "bitcoin",
                    "ethereum",
                    "blockchain",
                    "trading",
                ],
            },
            {
                "name": "Bloomberg Crypto",
                "url": "https://feeds.bloomberg.com/markets/news.rss",
                "type": "rss",
                "keywords": [
                    "crypto",
                    "bitcoin",
                    "ethereum",
                    "blockchain",
                    "trading",
                ],
            },
            {
                "name": "CoinDesk",
                "url": "https://www.coindesk.com/arc/outboundfeeds/rss/",
                "type": "rss",
                "keywords": [
                    "crypto",
                    "bitcoin",
                    "ethereum",
                    "blockchain",
                    "trading",
                ],
            },
        ]

        # Trading symbols to monitor
        self.trading_symbols = [
            "BTC",
            "ETH",
            "ADA",
            "DOT",
            "LINK",
            "UNI",
            "AAVE",
        ]

        # Register news-specific handlers
        self.register_handler("analyze_news", self.handle_analyze_news)
        self.register_handler("get_sentiment", self.handle_get_sentiment)
        self.register_handler("update_sources", self.handle_update_sources)
        self.register_handler("market_data", self.handle_market_data)

        logger.info(f"ðŸ“° News Sentiment Agent {agent_id} initialized")

    async def initialize(self):
        """Initialize news sentiment agent resources"""
        try:
            # Load news sources configuration
            await self.load_news_config()

            # Initialize sentiment analysis models
            await self.initialize_sentiment_models()

            # Start news monitoring
            await self.start_news_monitoring()

            logger.info(f"âœ… News Sentiment Agent {self.agent_id} initialized successfully")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error initializing News Sentiment Agent")
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # BaseAgent may or may not implement update_health_status
                self.update_health_status("error")

    async def process_loop(self):
        """Main news processing loop"""
        while self.running:
            try:
                # Fetch and analyze news
                await self.fetch_and_analyze_news()

                # Update sentiment metrics
                await self.update_sentiment_metrics()

                # Clean up old cache entries
                await self.cleanup_cache()

                # Use configurable interval from .env
                interval = int(os.getenv("NEWS_FETCH_INTERVAL_SEC", "300"))
                await asyncio.sleep(interval)

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("âŒ Error in news processing loop")
                await asyncio.sleep(600)

    async def load_news_config(self):
        """Load news configuration from Redis"""
        try:
            # Load news sources
            sources_data = self.redis_client.get("news_sources")
            if sources_data:
                # redis might return bytes
                if isinstance(sources_data, (bytes, bytearray)):
                    sources_data = sources_data.decode()
                self.news_sources = json.loads(sources_data)

            # Load trading symbols
            symbols_data = self.redis_client.get("trading_symbols")
            if symbols_data:
                if isinstance(symbols_data, (bytes, bytearray)):
                    symbols_data = symbols_data.decode()
                self.trading_symbols = json.loads(symbols_data)

            logger.info(f"News configuration loaded: {len(self.news_sources)} sources, {len(self.trading_symbols)} symbols")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error loading news configuration")

    async def initialize_sentiment_models(self):
        """Initialize sentiment analysis models"""
        try:
            # Initialize TextBlob for sentiment analysis
            test_text = "Bitcoin price increases significantly"
            TextBlob(test_text)

            logger.info("Sentiment models initialized (TextBlob")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error initializing sentiment models")

    async def start_news_monitoring(self):
        """Start news monitoring"""
        try:
            # Subscribe to market data for context
            pubsub = self.redis_client.pubsub()
            pubsub.subscribe("market_data")

            # Start market data listener
            task = await task_manager.create_task(self.listen_market_data(pubsub), name="news_sentiment_agent:listen_market_data")
            self._tasks.append(task)

            logger.info("ðŸ“¡ News monitoring started")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error starting news monitoring")

    async def listen_market_data(self, pubsub):
        """Listen for market data updates"""
        try:
            while self.running:
                # FIXED: Use async-friendly polling instead of blocking listen()
                # This was causing the orchestrator to freeze on startup
                message = await asyncio.to_thread(
                    pubsub.get_message,
                    timeout=1.0,  # Non-blocking 1-second poll
                )

                if message and message["type"] == "message":
                    data = message.get("data")
                    try:
                        if isinstance(data, (bytes, bytearray)):
                            data = data.decode()
                        market_data = json.loads(data)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        market_data = data
                    await self.process_market_data(market_data)

                # Yield to event loop
                await asyncio.sleep(0.1)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error in market data listener")
        finally:
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pubsub.close()

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process market data for news context"""
        try:
            symbol = market_data.get("symbol")
            price = market_data.get("price")

            # Update symbol sentiment context
            if symbol and price is not None:
                await self.update_symbol_context(symbol, price)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error processing market data")

    async def handle_market_data(self, message: dict[str, Any]):
        """Handle market data message"""
        try:
            market_data = message.get("market_data", {})
            logger.info(f"ðŸ“Š News Sentiment Agent received market data for {len(market_data) if hasattr(market_data, '__len__') else 1} symbols")
            await self.process_market_data(market_data)
            await self.fetch_and_analyze_news()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error handling market data")
            if hasattr(self, "broadcast_error"):
                await self.broadcast_error("Market data handling error")

    async def fetch_and_analyze_news(self):
        """Fetch and analyze news from all sources"""
        try:
            logger.info(f"ðŸ“° Fetching news from {len(self.news_sources)} sources...")

            all_articles = []

            # Fetch news from each source
            for source in self.news_sources:
                try:
                    articles = await self.fetch_news_from_source(source)
                    if articles:
                        all_articles.extend(articles)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception(f"âŒ Error fetching from {source.get('name')}")

            # Analyze sentiment for all articles
            if all_articles:
                await self.analyze_articles_sentiment(all_articles)

                # Update analysis count
                self.state["analysis_count"] += 1
                self.state["last_analysis"] = datetime.now(tz=timezone.utc)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error fetching and analyzing news")

    async def fetch_news_from_source(self, source: dict[str, Any]) -> list[dict[str, Any]]:
        """Fetch news from a given source (RSS or manual)"""
        try:
            url = source.get("url")
            source_name = source.get("name", "unknown")
            keywords = [k.lower() for k in source.get("keywords", [])]

            if not url:
                return []

            async with httpx.AsyncClient(timeout=15) as client:
                resp = await client.get(url)
                content = resp.text

            feed = feedparser.parse(content)
            articles: list[dict[str, Any]] = []
            for entry in feed.entries:
                title = entry.get("title", "") or ""
                summary = entry.get("summary", "") or entry.get("description", "") or ""
                link = entry.get("link", "") or entry.get("id", "")
                published = entry.get("published", "") or entry.get("updated", "")
                combined = f"{title}\n{summary}".lower()

                # Filter by keywords if provided
                if keywords and not any(k in combined for k in keywords):
                    continue

                article = {
                    "title": title,
                    "summary": summary,
                    "link": link,
                    "published": published,
                    "source": source_name,
                    "fetched_at": datetime.now(tz=timezone.utc).isoformat(),
                }
                articles.append(article)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception(f"âŒ Error fetching news from source {source.get('name')}")
            return []

    async def analyze_articles_sentiment(self, articles: list[dict[str, Any]]):
        """Analyze sentiment for a list of articles"""
        try:
            for article in articles:
                try:
                    sentiment, symbols = await self.analyze_article_sentiment(article)
                    await self.update_sentiment_cache(article, sentiment, symbols)
                    # Broadcast update for this article
                    await self.broadcast_sentiment_update(article, sentiment, symbols)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception(f"âŒ Error analyzing article {article.get('link')}")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error in analyze_articles_sentiment")

    async def analyze_article_sentiment(self, article: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
        """Analyze sentiment for a single article using TextBlob and detect symbols"""
        try:
            text = f"{article.get('title', '')} {article.get('summary', '')}".strip()
            tb = TextBlob(text)
            polarity = float(tb.sentiment.polarity)
            subjectivity = float(tb.sentiment.subjectivity)
            confidence = min(max(abs(polarity), 0.0), 1.0)

            # Detect mentioned symbols
            symbols_found: list[str] = []
            text_upper = text.upper()
            for sym in self.trading_symbols:
                # word boundary to avoid partial matches
                if re.search(rf"\b{re.escape(sym.upper())}\b", text_upper):
                    symbols_found.append(sym)

            # Sentiment calculated for return value
            {
                "polarity": polarity,
                "subjectivity": subjectivity,
                "confidence": confidence,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error analyzing article sentiment")
            return {"polarity": 0.0, "subjectivity": 0.0, "confidence": 0.0, "timestamp": datetime.now(tz=timezone.utc).isoformat()}, []

    async def update_sentiment_cache(self, article: dict[str, Any], sentiment: dict[str, Any], symbols: list[str]):
        """Update in-memory and Redis-backed sentiment cache and per-symbol lists"""
        try:
            key = article.get("link") or article.get("title") or str(hash(json.dumps(article, sort_keys=True)))
            ts = sentiment.get("timestamp", datetime.now(tz=timezone.utc).isoformat())

            # Update in-memory cache
            self.state["sentiment_cache"][key] = {
                "article": article,
                "sentiment": sentiment,
                "symbols": symbols,
                "timestamp": ts,
            }

            # Update per-symbol sentiment lists
            for sym in symbols:
                if sym not in self.state["symbol_sentiment"]:
                    self.state["symbol_sentiment"][sym] = []
                entry = {
                    "article": article,
                    "sentiment": sentiment,
                    "timestamp": ts,
                }
                self.state["symbol_sentiment"][sym].append(entry)

            # Optionally persist to Redis (best-effort)
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # Redis persistence is best-effort; ignore failures
                self.redis_client.set(f"sentiment_cache:{key}", json.dumps(self.state["sentiment_cache"][key]), ex=24 * 3600)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error updating sentiment cache")

    async def broadcast_sentiment_update(
        self,
        article: dict[str, Any],
        sentiment: dict[str, Any],
        symbols: list[str],
    ):
        """Broadcast sentiment update to other agents"""
        try:
            sentiment_update = {
                "type": "news_sentiment_update",
                "article": article,
                "sentiment": sentiment,
                "symbols": symbols,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Broadcast to all agents
            if hasattr(self, "broadcast_message"):
                await self.broadcast_message(sentiment_update)

            # Send to specific agents if available
            if hasattr(self, "send_message"):
                await self.send_message("strategy_agent", sentiment_update)
                await self.send_message("risk_agent", sentiment_update)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error broadcasting sentiment update")

    async def update_symbol_context(self, symbol: str, price: float):
        """Update symbol context for sentiment analysis"""
        try:
            # Store price context for sentiment correlation
            price_context = {
                "symbol": symbol,
                "price": price,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Store in Redis
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # Best-effort persistence
                self.redis_client.set(f"price_context:{symbol}", json.dumps(price_context), ex=300)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error updating symbol context")

    async def handle_analyze_news(self, message: dict[str, Any]):
        """Handle manual news analysis request"""
        try:
            source_url = message.get("source_url")
            keywords = message.get("keywords", [])

            logger.info(f"ðŸ“° Manual news analysis requested for {source_url}")

            # Fetch and analyze news from specified source
            source = {
                "name": "Manual Request",
                "url": source_url,
                "type": "manual",
                "keywords": keywords,
            }

            articles = await self.fetch_news_from_source(source)
            if articles:
                await self.analyze_articles_sentiment(articles)

            # Send response
            response = {
                "type": "news_analysis_complete",
                "articles_analyzed": len(articles),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender and hasattr(self, "send_message"):
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error handling news analysis request")
            if hasattr(self, "broadcast_error"):
                await self.broadcast_error("News analysis error")

    async def handle_get_sentiment(self, message: dict[str, Any]):
        """Handle sentiment request"""
        try:
            symbol = message.get("symbol")
            timeframe = message.get("timeframe", "24h")

            logger.info(f"ðŸ“Š Sentiment request for {symbol} ({timeframe}")

            # Get sentiment for symbol
            sentiment_data = await self.get_symbol_sentiment(symbol, timeframe)

            # Send response
            response = {
                "type": "sentiment_response",
                "symbol": symbol,
                "timeframe": timeframe,
                "sentiment": sentiment_data,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender and hasattr(self, "send_message"):
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error handling sentiment request")
            if hasattr(self, "broadcast_error"):
                await self.broadcast_error("Sentiment request error")

    async def handle_update_sources(self, message: dict[str, Any]):
        """Handle news sources update request"""
        try:
            new_sources = message.get("sources", [])

            logger.info("Updating news sources")

            # Update sources
            self.news_sources = new_sources

            # Store in Redis
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                self.redis_client.set("news_sources", json.dumps(new_sources), ex=3600)

            # Send confirmation
            response = {
                "type": "sources_updated",
                "sources_count": len(new_sources),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender and hasattr(self, "send_message"):
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error updating news sources")
            if hasattr(self, "broadcast_error"):
                await self.broadcast_error("Sources update error")

    async def get_symbol_sentiment(self, symbol: str, timeframe: str) -> dict[str, Any]:
        """Get sentiment data for a symbol"""
        try:
            symbol_sentiments = self.state["symbol_sentiment"].get(symbol, [])

            if not symbol_sentiments:
                return {
                    "average_polarity": 0,
                    "sentiment_category": "neutral",
                    "confidence": 0,
                    "article_count": 0,
                }

            # Filter by timeframe
            cutoff_time = datetime.now(timezone.utc)
            if timeframe == "1h":
                cutoff_time -= timedelta(hours=1)
            elif timeframe == "6h":
                cutoff_time -= timedelta(hours=6)
            elif timeframe == "24h":
                cutoff_time -= timedelta(hours=24)
            else:
                cutoff_time -= timedelta(hours=24)  # Default to 24h

            recent_sentiments = [s for s in symbol_sentiments if datetime.fromisoformat(s["timestamp"]) > cutoff_time]

            if not recent_sentiments:
                return {
                    "average_polarity": 0,
                    "sentiment_category": "neutral",
                    "confidence": 0,
                    "article_count": 0,
                }

            # Calculate average sentiment
            polarities = [s["sentiment"]["polarity"] for s in recent_sentiments]
            confidences = [s["sentiment"]["confidence"] for s in recent_sentiments]

            avg_polarity = float(np.mean(polarities)) if polarities else 0.0
            raw_conf = float(np.mean(confidences)) if confidences else 0.0
            from backend.services.confidence_normalizer import ConfidenceNormalizer

            avg_confidence = ConfidenceNormalizer.normalize(raw_conf)

            # Determine sentiment category
            if avg_polarity > 0.1:
                sentiment_category = "positive"
            elif avg_polarity < -0.1:
                sentiment_category = "negative"
            else:
                sentiment_category = "neutral"

            return {
                "average_polarity": avg_polarity,
                "sentiment_category": sentiment_category,
                "confidence": avg_confidence,
                "article_count": len(recent_sentiments),
                "recent_articles": recent_sentiments[-5:],  # Last 5 articles
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error getting symbol sentiment")
            return {
                "average_polarity": 0,
                "sentiment_category": "neutral",
                "confidence": 0,
                "article_count": 0,
            }

    async def update_sentiment_metrics(self):
        """Update sentiment metrics"""
        try:
            metrics = {
                "agent_id": self.agent_id,
                "sources_count": len(self.news_sources),
                "symbols_count": len(self.trading_symbols),
                "cache_size": len(self.state["sentiment_cache"]),
                "analysis_count": self.state["analysis_count"],
                "last_analysis": self.state["last_analysis"].isoformat() if isinstance(self.state["last_analysis"], datetime) else self.state["last_analysis"],
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            # Store metrics in Redis
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics), ex=300)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error updating sentiment metrics")

    async def cleanup_cache(self):
        """Clean up old cache entries"""
        try:
            current_time = datetime.now(timezone.utc)
            cache_keys = list(self.state["sentiment_cache"].keys())

            for key in cache_keys:
                entry = self.state["sentiment_cache"].get(key)
                if not entry:
                    continue
                entry_time_str = entry.get("timestamp")
                try:
                    entry_time = datetime.fromisoformat(entry_time_str) if entry_time_str else current_time
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    entry_time = current_time

                # Remove entries older than 24 hours
                if (current_time - entry_time) > timedelta(hours=24):
                    with contextlib.suppress(KeyError):
                        del self.state["sentiment_cache"][key]

            # Clean up symbol sentiment (keep last 100 entries per symbol)
            for symbol in list(self.state["symbol_sentiment"].keys()):
                sentiments = self.state["symbol_sentiment"].get(symbol, [])
                if len(sentiments) > 100:
                    self.state["symbol_sentiment"][symbol] = sentiments[-100:]

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("âŒ Error cleaning up cache")
