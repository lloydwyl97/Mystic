import asyncio
import contextlib
import json
import logging
from datetime import datetime, timezone
from typing import Any

from backend.agents.base_agent import BaseAgent
from backend.services.task_manager import task_manager

logger = logging.getLogger(__name__)

"""
NLP Orchestrator Agent
Coordinates all NLP agents and provides unified NLP services
"""


class NLPOrchestrator(BaseAgent):
    """NLP Orchestrator - Coordinates all NLP agents"""

    def __init__(self, agent_id: str = "nlp_orchestrator_001") -> None:
        super().__init__(agent_id, "nlp_orchestrator")

        # NLP orchestrator-specific state
        self.state.update(
            {
                "nlp_agents": {},
                "unified_sentiment": {},
                "nlp_services": {},
                "coordination_tasks": [],
                "last_coordination": None,
                "coordination_count": 0,
            },
        )

        # NLP agents configuration
        self.nlp_agents = {
            "news_sentiment": {
                "agent_id": "news_sentiment_agent_001",
                "status": "unknown",
                "last_heartbeat": None,
                "capabilities": [
                    "news_analysis",
                    "sentiment_extraction",
                    "symbol_detection",
                ],
            },
            "social_media": {
                "agent_id": "social_media_agent_001",
                "status": "unknown",
                "last_heartbeat": None,
                "capabilities": [
                    "social_monitoring",
                    "trending_topics",
                    "influencer_tracking",
                ],
            },
            "market_sentiment": {
                "agent_id": "market_sentiment_agent_001",
                "status": "unknown",
                "last_heartbeat": None,
                "capabilities": [
                    "sentiment_aggregation",
                    "fear_greed_index",
                    "signal_generation",
                ],
            },
        }

        # NLP services configuration
        self.nlp_services = {
            "real_time_sentiment": {
                "enabled": True,
                "update_interval": 60,  # seconds
                "sources": ["news", "social", "market"],
            },
            "trending_analysis": {
                "enabled": True,
                "update_interval": 300,
                "sources": ["social", "news"],
            },  # seconds
            "sentiment_forecasting": {
                "enabled": True,
                "update_interval": 600,
                "sources": ["all"],
            },  # seconds
            "market_intelligence": {
                "enabled": True,
                "update_interval": 180,  # seconds
                "sources": ["news", "social", "market"],
            },
        }

        # Register NLP orchestrator-specific handlers
        self.register_handler("coordinate_nlp", self.handle_coordinate_nlp)
        self.register_handler("get_unified_sentiment", self.handle_get_unified_sentiment)
        self.register_handler("nlp_service_request", self.handle_nlp_service_request)
        self.register_handler("agent_heartbeat", self.handle_agent_heartbeat)
        self.register_handler("market_data", self.handle_market_data)

        logger.info(f"NLP Orchestrator {agent_id} initialized")

    async def initialize(self):
        """Initialize NLP orchestrator resources"""
        try:
            # Load NLP configuration
            await self.load_nlp_config()

            # Initialize coordination systems
            await self.initialize_coordination()

            # Start NLP monitoring
            await self.start_nlp_monitoring()

            logger.info(f"NLP Orchestrator {self.agent_id} initialized successfully")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"NLP Orchestrator: {e}")
            self.update_health_status("error")

    async def process_loop(self):
        """NLP coordination loop"""
        while self.running:
            try:
                # Coordinate NLP agents
                await self.coordinate_nlp_agents()

                # Update unified sentiment
                await self.update_unified_sentiment()

                # Manage NLP services
                await self.manage_nlp_services()

                # Update coordination metrics
                await self.update_coordination_metrics()

                # Clean up old tasks
                await self.cleanup_tasks()

                await asyncio.sleep(30)  # Check every 30 seconds

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception(f"NLP coordination loop: {e}")
                await asyncio.sleep(60)

    async def load_nlp_config(self):
        """Load NLP configuration from Redis"""
        try:
            # Load NLP agents configuration
            agents_data = self.redis_client.get("nlp_agents_config")
            if agents_data:
                self.nlp_agents = json.loads(agents_data)

            # Load NLP services configuration
            services_data = self.redis_client.get("nlp_services_config")
            if services_data:
                self.nlp_services = json.loads(services_data)

            logger.info(f"NLP configuration loaded: {len(self.nlp_agents)} agents, {len(self.nlp_services)} services")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"NLP configuration: {e}")

    async def initialize_coordination(self):
        """NLP coordination systems"""
        try:
            # Initialize agent monitoring
            await self.initialize_agent_monitoring()

            # Initialize service management
            await self.initialize_service_management()

            logger.info("NLP coordination systems initialized")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error initializing coordination: {e}")

    async def initialize_agent_monitoring(self):
        """Initialize agent monitoring"""
        try:
            # Start monitoring each NLP agent
            for agent_name, agent_config in self.nlp_agents.items():
                await self.monitor_agent_health(agent_name, agent_config)

            logger.info("ðŸ“¡ Agent monitoring initialized")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error initializing agent monitoring: {e}")

    async def initialize_service_management(self):
        """Initialize service management"""
        try:
            # Start service management tasks
            for service_name, service_config in self.nlp_services.items():
                if service_config.get("enabled", False):
                    await self.start_service(service_name, service_config)

            logger.info("Service management initialized")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error initializing service management: {e}")

    async def start_nlp_monitoring(self):
        """Start NLP monitoring"""
        try:
            # Subscribe to agent heartbeats and market data
            pubsub = self.redis_client.pubsub()
            pubsub.subscribe("agent_heartbeat")
            pubsub.subscribe("market_data")
            pubsub.subscribe("aggregated_sentiment_update")

            # Start monitoring listener
            task = await task_manager.create_task(self.listen_nlp_updates(pubsub), name="nlp_orchestrator:listen_nlp_updates")
            self._tasks.append(task)

            logger.info("ðŸ“¡ NLP monitoring started")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error starting NLP monitoring: {e}")

    async def listen_nlp_updates(self, pubsub):
        """Listen for NLP updates"""
        try:
            for message in pubsub.listen():
                if not self.running:
                    break

                if message["type"] == "message":
                    try:
                        data = json.loads(message["data"])
                        channel = message["channel"]

                        if channel == "agent_heartbeat":
                            await self.handle_agent_heartbeat(data)
                        elif channel == "market_data":
                            await self.handle_market_data(data)
                        elif channel == "aggregated_sentiment_update":
                            await self.handle_sentiment_update(data)

                    except json.JSONDecodeError:
                        logger.exception(f"âŒ Error decoding NLP update: {message.get('data')}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error in NLP listen: {e}")

    async def monitor_agent_health(self, agent_name: str, agent_config: dict[str, Any]):
        """Monitor health of a specific agent"""
        try:
            agent_id = agent_config["agent_id"]

            # Send health check
            health_check = {
                "type": "health_check",
                "from_agent": self.agent_id,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            await self.send_message(agent_id, health_check)

            logger.info(f"Monitoring agent: {agent_name} ({agent_id})")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error monitoring agent {agent_name}: {e}")

    async def handle_coordinate_nlp(self, message: dict[str, Any]):
        """NLP coordination request"""
        try:
            coordination_type = message.get("type", "full")

            logger.info(f"NLP coordination requested: {coordination_type}")

            if coordination_type == "full":
                await self.coordinate_nlp_agents()
            elif coordination_type == "health_check":
                await self.check_agent_health()
            elif coordination_type == "sentiment_update":
                await self.update_unified_sentiment()

            # Send response
            response = {
                "type": "nlp_coordination_complete",
                "coordination_type": coordination_type,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"NLP coordination request: {e}")
            await self.broadcast_error(f"NLP coordination error: {e}")

    async def handle_get_unified_sentiment(self, message: dict[str, Any]):
        """Handle unified sentiment request"""
        try:
            symbols = message.get("symbols", [])
            timeframe = message.get("timeframe", "1h")

            logger.info(f"ðŸ“Š Unified sentiment request for {symbols} ({timeframe})")

            # Get unified sentiment data
            sentiment_data = {
                "unified_sentiment": self.state["unified_sentiment"],
                "agent_status": {name: config["status"] for name, config in self.nlp_agents.items()},
                "services_status": (self.state["nlp_services"].get("services", {})),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            # Send response
            response = {
                "type": "unified_sentiment_response",
                "symbols": symbols,
                "timeframe": timeframe,
                "sentiment": sentiment_data,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error handling unified sentiment request: {e}")
            await self.broadcast_error(f"Unified sentiment request error: {e}")

    async def handle_nlp_service_request(self, message: dict[str, Any]):
        """Handle NLP service request"""
        try:
            service_name = message.get("service")
            parameters = message.get("parameters", {})

            logger.info(f"ðŸ”§ NLP service request: {service_name}")

            # Route service request to appropriate agent
            service_response = await self.route_service_request(service_name, parameters)

            # Send response
            response = {
                "type": "nlp_service_response",
                "service": service_name,
                "result": service_response,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error handling NLP service request: {e}")
            await self.broadcast_error(f"NLP service request error: {e}")

    async def route_service_request(self, service_name: str, parameters: dict[str, Any]) -> dict[str, Any]:
        """Route service request to appropriate agent"""
        try:
            # Define service routing
            service_routing = {
                "news_analysis": "news_sentiment_agent_001",
                "social_monitoring": "social_media_agent_001",
                "sentiment_aggregation": "market_sentiment_agent_001",
                "trending_analysis": "social_media_agent_001",
                "market_intelligence": "market_sentiment_agent_001",
            }

            target_agent = service_routing.get(service_name)

            if target_agent:
                # Forward request to target agent
                service_message = {
                    "type": f"service_request_{service_name}",
                    "from_agent": self.agent_id,
                    "parameters": parameters,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

                await self.send_message(target_agent, service_message)

                # Wait for actual response with timeout - NO MOCK DATA
                with contextlib.suppress(asyncio.TimeoutError):
                    await asyncio.wait_for(
                        self._get_agent_response(target_agent, service_message.get("correlation_id")),
                        timeout=10.0,
                    )
            else:
                pass

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error routing service request: {e}")
            return {"status": "error", "message": str(e)}

    async def update_coordination_metrics(self):
        """Update coordination metrics"""
        try:
            metrics = {
                "agent_id": self.agent_id,
                "agents_count": len(self.nlp_agents),
                "services_count": len(self.nlp_services),
                "coordination_count": self.state["coordination_count"],
                "last_coordination": self.state["last_coordination"],
                "agent_status": {name: config["status"] for name, config in self.nlp_agents.items()},
                "services_status": (self.state["nlp_services"].get("services", {})),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            # Store metrics in Redis
            self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics), ex=300)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error updating coordination metrics: {e}")

    async def cleanup_tasks(self):
        """Clean up old coordination tasks"""
        try:
            datetime.now(timezone.utc)

            # Clean up old tasks (keep only last 100)
            if len(self.state["coordination_tasks"]) > 100:
                self.state["coordination_tasks"] = self.state["coordination_tasks"][-100:]

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error cleaning up tasks: {e}")

    async def handle_agent_heartbeat(self, message: dict[str, Any]):
        """Handle agent heartbeat message"""
        try:
            agent_id = message.get("agent_id", "unknown")
            status = message.get("status", "unknown")
            logger.debug(f"Received heartbeat from {agent_id}: {status}")

            # Update agent status in state
            self.state.setdefault("agent_status", {})[agent_id] = {
                "status": status,
                "last_heartbeat": datetime.now(timezone.utc).isoformat(),
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error handling agent heartbeat: {e}")

    async def handle_market_data(self, message: dict[str, Any]):
        """Handle incoming market data updates"""
        try:
            await self.process_market_data(message)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error handling market data: {e}")

    async def process_market_data(self, market_data: dict[str, Any]):
        """NLP coordination"""
        try:
            logger.info("NLP coordination")

            # Update market data in state
            self.state["last_market_data"] = market_data
            self.state["last_market_update"] = datetime.now(timezone.utc).isoformat()

            # Update market context for each symbol
            for symbol, data in market_data.items():
                price = data.get("price", 0)
                await self.update_market_context(symbol, price)

            # Coordinate NLP agents with new market data
            await self.coordinate_nlp_agents()

            # Update unified sentiment with new market context
            await self.update_unified_sentiment()

            # Update coordination metrics
            await self.update_coordination_metrics()

            logger.info("NLP coordination")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"NLP coordination: {e}")
            await self.broadcast_error(f"NLP coordination market data error: {e}")

    async def start_service(self, service_name: str, service_config: dict[str, Any]):
        """Start an NLP service"""
        try:
            logger.info(f"Starting NLP service: {service_name}")

            # Store service configuration in state
            if "nlp_services" not in self.state:
                self.state["nlp_services"] = {}
            if "services" not in self.state["nlp_services"]:
                self.state["nlp_services"]["services"] = {}

            self.state["nlp_services"]["services"][service_name] = {
                "status": "running",
                "config": service_config,
                "started_at": datetime.now(timezone.utc).isoformat(),
            }

            logger.info(f"✅ NLP service started: {service_name}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error starting service {service_name}: {e}")

    async def coordinate_nlp_agents(self):
        """Coordinate all NLP agents"""
        try:
            logger.debug("Coordinating NLP agents")

            # Check health of all agents
            for agent_name, agent_config in self.nlp_agents.items():
                await self.monitor_agent_health(agent_name, agent_config)

            # Update coordination count
            self.state["coordination_count"] += 1
            self.state["last_coordination"] = datetime.now(timezone.utc).isoformat()

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error coordinating NLP agents: {e}")

    async def update_unified_sentiment(self):
        """Update unified sentiment from all sources"""
        try:
            logger.debug("Updating unified sentiment")

            # Aggregate sentiment from all NLP agents
            unified_sentiment = {}

            # Get sentiment from Redis keys
            for agent_name in self.nlp_agents:
                sentiment_key = f"sentiment:{agent_name}"
                sentiment_data = self.redis_client.get(sentiment_key)
                if sentiment_data:
                    with contextlib.suppress(json.JSONDecodeError):
                        unified_sentiment[agent_name] = json.loads(sentiment_data)

            # Update state
            self.state["unified_sentiment"] = unified_sentiment

            # Store in Redis
            self.redis_client.set("nlp:unified_sentiment", json.dumps(unified_sentiment), ex=300)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error updating unified sentiment: {e}")

    async def manage_nlp_services(self):
        """Manage NLP services"""
        try:
            logger.debug("Managing NLP services")

            # Check status of each service
            for service_name, service_config in self.nlp_services.items():
                if service_config.get("enabled", False):
                    # Verify service is running
                    service_status = self.state.get("nlp_services", {}).get("services", {}).get(service_name)
                    if not service_status:
                        # Restart service if not running
                        await self.start_service(service_name, service_config)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error managing NLP services: {e}")

    async def check_agent_health(self):
        """Check health of all NLP agents"""
        try:
            logger.debug("Checking agent health")

            for agent_name, agent_config in self.nlp_agents.items():
                await self.monitor_agent_health(agent_name, agent_config)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error checking agent health: {e}")

    async def handle_sentiment_update(self, _data: dict[str, Any]):
        """Handle sentiment update from agents"""
        try:
            logger.debug("Handling sentiment update")

            # Update unified sentiment
            await self.update_unified_sentiment()

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error handling sentiment update: {e}")

    async def update_market_context(self, symbol: str, price: float):
        """Update market context for a symbol"""
        try:
            logger.debug(f"Updating market context for {symbol}: ${price}")

            # Store market context in state
            if "market_context" not in self.state:
                self.state["market_context"] = {}

            self.state["market_context"][symbol] = {
                "price": price,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error updating market context: {e}")

    async def _get_agent_response(self, _agent_id: str, _correlation_id: str | None) -> dict[str, Any]:
        """Wait for agent response (placeholder for future implementation)"""
        try:
            # This is a placeholder - in a real implementation, this would wait for
            # a response message from the agent with the matching correlation_id
            await asyncio.sleep(0.1)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error getting agent response: {e}")
            return {"status": "error", "message": str(e)}
        else:
            return {"status": "pending"}
