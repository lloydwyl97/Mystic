import asyncio
import contextlib

from backend.config.redis_config import get_shared_redis_async

r = get_shared_redis_async()


async def fetch_metric(key, default="..."):
    try:
        value = await r.get(key)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        return default
    else:
        return value or default


def get_phase5_overlay_metrics():
    # Preserve existing event loop (if any), create a fresh one for our synchronous call,
    # run the async fetches concurrently, then restore and close the temporary loop.
    try:
        previous_loop = asyncio.get_event_loop()
    except RuntimeError:
        previous_loop = None

    loop = asyncio.new_event_loop()
    try:
        asyncio.set_event_loop(loop)
        neuro_sync, cosmic_signal, aura_alignment, interdim_activity = loop.run_until_complete(
            asyncio.gather(
                fetch_metric("neuro_sync_index"),
                fetch_metric("cosmic_harmonic_status"),
                fetch_metric("aura_alignment_score"),
                fetch_metric("interdim_signal_strength"),
            )
        )
    finally:
        # Restore previous loop if possible and close the temporary loop.
        try:
            if previous_loop is not None:
                asyncio.set_event_loop(previous_loop)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            # Best-effort restore; ignore failures to avoid masking metric results.
            pass
        with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            loop.close()

    return {
        "neuro_sync": neuro_sync,
        "cosmic_signal": cosmic_signal,
        "aura_alignment": aura_alignment,
        "interdim_activity": interdim_activity,
    }
