import asyncio
import logging
from typing import Any

import numpy as np
from qiskit import (
    ClassicalRegister,
    QuantumCircuit,
    QuantumRegister,
)
from qiskit.circuit.library import QFT
from qiskit_aer import Aer

# Qiskit 2.x compatibility - execute is deprecated, use Sampler instead
try:
    from qiskit.execute_function import execute
except (ImportError, ModuleNotFoundError):
    # Fallback for Qiskit 2.x - create a wrapper
    def execute(circuit, backend, shots=1000):
        """Compatibility wrapper for Qiskit 2.x"""
        from qiskit_aer import AerSimulator

        backend_instance = AerSimulator() if isinstance(backend, str) else backend
        job = backend_instance.run(circuit, shots=shots)
        return job


try:
    from qiskit.algorithms.optimizers import SPSA
except ImportError:
    # Fallback for newer qiskit versions
    from qiskit_algorithms.optimizers import SPSA

logger = logging.getLogger(__name__)

"""
Quantum Algorithm Engine
Implements quantum algorithms for financial applications
"""

# Direct imports for production

from backend.agents.base_agent import BaseAgent


class QuantumAlgorithmEngine(BaseAgent):
    """Quantum Algorithm Engine - Coordinates quantum algorithms"""

    def __init__(self, agent_id: str = "quantum_algorithm_engine_001") -> None:
        super().__init__(agent_id, "quantum_algorithm")
        self.portfolio_optimizer = None
        self.fourier_transform = None
        self.search = None
        logger.info(f"🔬 Quantum Algorithm Engine {agent_id} initialized")

    async def initialize(self):
        """Initialize quantum components"""
        try:
            self.portfolio_optimizer = QuantumPortfolioOptimizer(num_assets=10)
            self.fourier_transform = QuantumFourierTransform(num_qubits=8)
            self.search = QuantumSearch()
            logger.info(f"✓ Quantum Algorithm Engine {self.agent_id} initialized")
        except Exception as e:
            logger.exception(f"Error initializing Quantum Algorithm Engine: {e}")
            self.update_health_status("error")

    async def process_loop(self):
        """Main quantum processing loop"""
        while self.running:
            try:
                # Quantum algorithms run on-demand, not in continuous loop
                await asyncio.sleep(60)
            except Exception as e:
                logger.exception(f"Error in quantum processing loop: {e}")
                await asyncio.sleep(300)

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process market data for quantum analysis"""
        try:
            logger.debug("Quantum Algorithm Engine processing market data")
            self.state["last_market_data"] = market_data
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error processing market data")


class QuantumPortfolioOptimizer:
    """Quantum portfolio optimization using VQE"""

    def __init__(self, num_assets: int, backend: str = "qasm_simulator") -> None:
        self.num_assets = num_assets
        self.backend = backend
        self.qubits = num_assets
        self.circuit = None
        self.optimizer = None

    def create_portfolio_circuit(self, returns: np.ndarray, _risk_free_rate: float = 0.02):
        """Create quantum circuit for portfolio optimization"""
        try:
            # Calculate covariance matrix (unused here but kept for API/behavior)
            _ = np.cov(returns.T)

            # Create quantum circuit
            qr = QuantumRegister(self.qubits, "q")
            cr = ClassicalRegister(self.qubits, "c")
            circuit = QuantumCircuit(qr, cr)

            # Initialize with equal weights
            circuit.h(qr)

            # Add rotation gates for optimization with deterministic angles
            for i in range(self.qubits):
                circuit.ry(2 * np.pi * 0.5, qr[i])  # Use fixed angle

            # Measure all qubits
            circuit.measure(qr, cr)

            self.circuit = circuit
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error creating portfolio circuit: {e}")
            return None
        else:
            return circuit

    def optimize_portfolio(
        self,
        returns: np.ndarray,
        target_return: float | None = None,
        _max_risk: float | None = None,
    ):
        """Optimize portfolio using quantum variational algorithm"""
        try:
            # Create circuit
            circuit = self.create_portfolio_circuit(returns)
            if circuit is None:
                return None

            # Define cost function
            def cost_function(params):
                # Bind parameters if circuit has parameters
                if circuit.num_parameters > 0:
                    # Map parameters to circuit parameters in deterministic order
                    param_list = list(params)
                    bind_map = dict(zip(circuit.parameters, param_list, strict=False))
                    circuit_with_params = circuit.bind_parameters(bind_map)
                else:
                    circuit_with_params = circuit

                backend_instance = Aer.get_backend(self.backend)
                job = backend_instance.run(circuit_with_params, shots=1000)
                result = job.result()
                counts = result.get_counts()

                # Calculate portfolio metrics
                weights = self.extract_weights_from_counts(counts)
                mean_returns = np.mean(returns, axis=0)
                portfolio_return = np.sum(weights * mean_returns)
                portfolio_risk = np.sqrt(weights.T @ np.cov(returns.T) @ weights)

                # Cost function (minimize risk for given return)
                if target_return is not None:
                    return_cost = abs(portfolio_return - target_return) * 100
                    risk_cost = portfolio_risk * 10
                    return return_cost + risk_cost
                return portfolio_risk

            # If circuit has no parameters, just evaluate once
            if circuit.num_parameters == 0:
                job = execute(circuit, Aer.get_backend(self.backend), shots=1000)
                counts = job.result().get_counts()
                optimal_weights = self.extract_weights_from_counts(counts)
                expected_return = np.sum(optimal_weights * np.mean(returns, axis=0))
                risk = np.sqrt(optimal_weights.T @ np.cov(returns.T) @ optimal_weights)
                sharpe = (expected_return - 0.02) / risk if risk != 0 else 0.0

                return {
                    "weights": optimal_weights,
                    "expected_return": expected_return,
                    "risk": risk,
                    "sharpe_ratio": sharpe,
                }

            # Optimize using SPSA with deterministic initial parameters
            optimizer = SPSA(maxiter=100)
            initial_params = np.full(circuit.num_parameters, np.pi)  # fixed parameters

            # Some optimizer implementations expect a scipy-like signature
            try:
                result = optimizer.minimize(cost_function, initial_params)
                optimal_params = getattr(result, "x", result)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # Fallback: try a simple iterative search (deterministic grid)
                optimal_params = initial_params

            # Bind optimal parameters and evaluate
            bind_map = dict(zip(circuit.parameters, list(optimal_params), strict=False))
            optimal_circuit = circuit.bind_parameters(bind_map)
            job = execute(optimal_circuit, Aer.get_backend(self.backend), shots=1000)
            counts = job.result().get_counts()
            optimal_weights = self.extract_weights_from_counts(counts)

            expected_return = np.sum(optimal_weights * np.mean(returns, axis=0))
            risk = np.sqrt(optimal_weights.T @ np.cov(returns.T) @ optimal_weights)
            sharpe = (expected_return - 0.02) / risk if risk != 0 else 0.0
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error optimizing portfolio: {e}")
            raise
        else:
            return {
                "weights": optimal_weights,
                "expected_return": expected_return,
                "risk": risk,
                "sharpe_ratio": sharpe,
            }

    def extract_weights_from_counts(self, counts: dict[str, int]) -> np.ndarray:
        """Extract portfolio weights from measurement counts"""
        try:
            total_shots = sum(counts.values()) if counts else 0
            weights = np.zeros(self.num_assets)

            if total_shots == 0:
                return np.ones(self.num_assets) / self.num_assets

            for bitstring, count in counts.items():
                # Convert bitstring to weights (assume bitstring MSB->LSB corresponds to asset 0..n-1)
                # Ensure bitstring length matches number of assets by padding/truncating
                bs = bitstring[::-1]  # reverse so index 0 corresponds to first qubit
                for i in range(self.num_assets):
                    if i < len(bs) and bs[i] == "1":
                        weights[i] += count / total_shots

            total = np.sum(weights)
            if total == 0:
                return np.ones(self.num_assets) / self.num_assets

            # Normalize weights
            return weights / total

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error extracting weights: {e}")
            return np.ones(self.num_assets) / self.num_assets


class QuantumFourierTransform:
    """Quantum Fourier Transform for time series analysis"""

    def __init__(self, num_qubits: int, backend: str = "qasm_simulator") -> None:
        self.num_qubits = num_qubits
        self.backend = backend

    def apply_qft(self, data: np.ndarray) -> np.ndarray:
        """Apply Quantum Fourier Transform to time series data"""
        try:
            data = np.asarray(data)
            if data.size == 0:
                return np.array([])

            data_min = np.min(data)
            data_max = np.max(data)
            normalized_data = np.zeros_like(data) if data_max - data_min == 0 else (data - data_min) / (data_max - data_min)

            # Create quantum circuit
            qr = QuantumRegister(self.num_qubits, "q")
            cr = ClassicalRegister(self.num_qubits, "c")
            circuit = QuantumCircuit(qr, cr)

            # Encode data into quantum state (simple amplitude encoding via X gates thresholded)
            for i, value in enumerate(normalized_data[: 2**self.num_qubits]):
                if value > 0.5 and i < self.num_qubits:
                    circuit.x(qr[i])

            # Apply QFT
            qft_circuit = QFT(num_qubits=self.num_qubits)
            circuit = circuit.compose(qft_circuit)

            # Measure
            circuit.measure(qr, cr)

            # Execute
            job = execute(circuit, Aer.get_backend(self.backend), shots=1000)
            result = job.result()
            counts = result.get_counts()

            # Extract frequency components
            return self.extract_frequencies(counts)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error applying QFT: {e}")
            # Fallback to classical FFT
            try:
                return np.fft.fft(data)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                return np.array([])

    def extract_frequencies(self, counts: dict[str, int]) -> np.ndarray:
        """Extract frequency components from measurement counts"""
        try:
            total_shots = sum(counts.values()) if counts else 0
            size = 2**self.num_qubits
            frequencies = np.zeros(size)

            if total_shots == 0:
                return frequencies

            for bitstring, count in counts.items():
                # Convert bitstring to integer (bitstring is MSB->LSB)
                freq_index = int(bitstring, 2)
                if 0 <= freq_index < size:
                    frequencies[freq_index] = count / total_shots
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error extracting frequencies: {e}")
            return np.zeros(2**self.num_qubits)
        else:
            return frequencies


class QuantumSearch:
    """Quantum search algorithms for pattern recognition"""

    def __init__(self, backend: str = "qasm_simulator") -> None:
        self.backend = backend

    def grover_search(self, oracle_function, num_qubits: int, _num_iterations: int | None = None):
        """Implement Grover's search algorithm (simplified/classical fallback)

        oracle_function: callable taking integer index and returning True if index is a marked item.
        This simplified implementation will return the list of matching indices. If a genuine
        quantum implementation is available, it can be substituted later.
        """
        if not callable(oracle_function):
            msg = "oracle_function must be callable"
            raise TypeError(msg)

        try:
            n_states = 2**num_qubits
            matches = []
            for i in range(n_states):
                try:
                    if oracle_function(i):
                        matches.append(i)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    # If oracle errors for a particular index, skip it
                    continue
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error running Grover search (fallback): {e}")
            return []
        else:
            return matches
