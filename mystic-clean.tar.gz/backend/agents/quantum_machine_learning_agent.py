import asyncio
import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Any

import numpy as np
from sklearn.preprocessing import StandardScaler

try:
    from qiskit_aer import Aer  # type: ignore[import-not-found]
except ImportError:
    Aer = None

try:
    from qiskit.algorithms.optimizers import SPSA  # type: ignore[import-not-found]
except ImportError:
    try:
        from qiskit_algorithms.optimizers import SPSA  # type: ignore[import-not-found]
    except ImportError:
        SPSA = None

try:
    from qiskit.circuit.library import TwoLocal, ZZFeatureMap  # type: ignore[import-not-found]
except ImportError:
    TwoLocal = None
    ZZFeatureMap = None

try:
    from qiskit.primitives import Sampler  # type: ignore[import-not-found]
except ImportError:
    try:
        from qiskit_aer.primitives import Sampler  # type: ignore[import-not-found]
    except ImportError:
        Sampler = None

QISKIT_AVAILABLE = all(x is not None for x in (Aer, SPSA, TwoLocal, ZZFeatureMap, Sampler))

try:
    from qiskit_machine_learning.algorithms import QSVC, VQC, VQR  # type: ignore[import-not-found]
    from qiskit_machine_learning.kernels import QuantumKernel  # type: ignore[import-not-found]
except ImportError:
    QSVC = None
    VQC = None
    VQR = None
    QuantumKernel = None

from backend.agents.base_agent import BaseAgent

logger = logging.getLogger(__name__)

if not QISKIT_AVAILABLE:
    logger.warning("qiskit core packages not available; quantum ML features disabled")
if QSVC is None:
    logger.warning("qiskit-machine-learning not available; quantum ML features limited")

"""
Quantum Machine Learning Agent
Implements quantum machine learning algorithms for trading
"""


class QuantumNeuralNetwork:
    """Quantum Neural Network for classification and regression"""

    def __init__(
        self,
        num_qubits: int,
        num_classes: int = 2,
        backend: str = "qasm_simulator",
    ) -> None:
        self.num_qubits = num_qubits
        self.num_classes = num_classes
        self.backend = backend
        self.circuit = None
        self.optimizer = None
        self.scaler = StandardScaler()

    def create_qnn_circuit(self, input_size: int):
        """Create quantum neural network circuit"""
        try:
            # Feature map
            feature_map = ZZFeatureMap(input_size, reps=2)

            # Variational form
            var_form = TwoLocal(input_size, ["ry", "rz"], "cz", reps=3)

            # Combine feature map and variational form
            circuit = feature_map.compose(var_form)

            self.circuit = circuit
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Error creating QNN circuit: {e}")
            return None
        else:
            return circuit

    def train_qnn(self, X: np.ndarray, y: np.ndarray, epochs: int = 100):
        """Train quantum neural network"""
        try:
            if VQC is None:
                msg = "qiskit-machine-learning missing: cannot train VQC"
                logger.error(msg)
                return None
            # Preprocess data
            X_scaled = self.scaler.fit_transform(X)

            # Create VQC
            vqc = VQC(
                feature_map=ZZFeatureMap(X.shape[1], reps=2),
                ansatz=TwoLocal(X.shape[1], ["ry", "rz"], "cz", reps=3),
                optimizer=SPSA(maxiter=epochs),
                sampler=Sampler(),
            )

            # Train
            # Some VQC versions expect fit(X, y); wrap in try/except to handle variations
            try:
                vqc.fit(X_scaled, y)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # If alternative API exists, attempt calling .train or similar (best-effort)
                if hasattr(vqc, "train"):
                    vqc.train(X_scaled, y)
                else:
                    raise

            self.vqc = vqc
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Error training QNN: {e}")
            return None
        else:
            return vqc

    def predict_qnn(self, X: np.ndarray) -> np.ndarray:
        """Make predictions with quantum neural network"""
        try:
            if not hasattr(self, "vqc"):
                return np.full(len(X), 0)  # Use neutral predictions instead of random

            X_scaled = self.scaler.transform(X)
            predictions = self.vqc.predict(X_scaled)
            return np.array(predictions)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Error predicting with QNN: {e}")
            return np.full(len(X), 0)  # Use neutral predictions instead of random


class QuantumSupportVectorMachine:
    """Quantum Support Vector Machine for classification"""

    def __init__(self, backend: str = "qasm_simulator") -> None:
        self.backend = backend
        self.qsvc = None
        self.scaler = StandardScaler()

    def train_qsvc(self, X: np.ndarray, y: np.ndarray):
        """Train quantum support vector classifier"""
        try:
            if QSVC is None or QuantumKernel is None:
                msg = "qiskit-machine-learning missing: cannot train QSVC"
                logger.error(msg)
                return None
            # Preprocess data
            X_scaled = self.scaler.fit_transform(X)

            # Create quantum kernel
            feature_map = ZZFeatureMap(X.shape[1], reps=2)
            try:
                quantum_kernel = QuantumKernel(
                    feature_map=feature_map,
                    quantum_instance=Aer.get_backend(self.backend),
                )
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # Fall back to creating kernel without quantum_instance if API differs
                quantum_kernel = QuantumKernel(feature_map=feature_map)

            # Create QSVC
            self.qsvc = QSVC(quantum_kernel=quantum_kernel)

            # Train
            self.qsvc.fit(X_scaled, y)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Error training QSVC: {e}")
            return None
        else:
            return self.qsvc

    def predict_qsvc(self, X: np.ndarray) -> np.ndarray:
        """Make predictions with quantum support vector classifier"""
        try:
            if self.qsvc is None:
                return np.full(len(X), 0)  # Use neutral predictions instead of random

            X_scaled = self.scaler.transform(X)
            predictions = self.qsvc.predict(X_scaled)
            return np.array(predictions)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Error predicting with QSVC: {e}")
            return np.full(len(X), 0)  # Use neutral predictions instead of random


class QuantumRegression:
    """Quantum regression for price prediction"""

    def __init__(self, backend: str = "qasm_simulator") -> None:
        self.backend = backend
        self.vqr = None
        self.scaler = StandardScaler()
        # Store training targets' mean and std for denormalization
        self.y_mean = 0.0
        self.y_std = 1.0

    def train_vqr(self, X: np.ndarray, y: np.ndarray, epochs: int = 100):
        """Train variational quantum regressor"""
        try:
            if VQR is None:
                msg = "qiskit-machine-learning missing: cannot train VQR"
                logger.error(msg)
                return None
            # Preprocess data
            X_scaled = self.scaler.fit_transform(X)
            # Compute and store mean/std for denormalization later
            self.y_mean = float(np.mean(y))
            self.y_std = float(np.std(y)) if float(np.std(y)) != 0.0 else 1.0
            y_scaled = (y - self.y_mean) / self.y_std

            # Create VQR
            self.vqr = VQR(
                feature_map=ZZFeatureMap(X.shape[1], reps=2),
                ansatz=TwoLocal(X.shape[1], ["ry", "rz"], "cz", reps=3),
                optimizer=SPSA(maxiter=epochs),
                sampler=Sampler(),
            )

            # Train
            try:
                self.vqr.fit(X_scaled, y_scaled)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                if hasattr(self.vqr, "train"):
                    self.vqr.train(X_scaled, y_scaled)
                else:
                    raise
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Error training VQR: {e}")
            return None
        else:
            return self.vqr

    def predict_vqr(self, X: np.ndarray) -> np.ndarray:
        """Make predictions with variational quantum regressor"""
        try:
            if self.vqr is None:
                return np.full(len(X), 0.5)  # Use neutral predictions instead of random

            X_scaled = self.scaler.transform(X)
            predictions_scaled = self.vqr.predict(X_scaled)

            predictions_scaled = np.array(predictions_scaled, dtype=float)
            # Denormalize predictions using stored mean/std
            return predictions_scaled * self.y_std + self.y_mean

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Error predicting with VQR: {e}")
            return np.full(len(X), 0.5)  # Use neutral predictions instead of random


class QuantumMachineLearningAgent(BaseAgent):
    """Quantum Machine Learning Agent - Implements quantum ML algorithms for trading"""

    def __init__(self, agent_id: str = "quantum_ml_agent_001") -> None:
        super().__init__(agent_id, "quantum_ml")

        self.state.update(
            {
                "models_trained": {},
                "predictions_made": {},
                "training_history": {},
                "last_training": None,
                "training_count": 0,
            },
        )

        # Initialize model containers
        self.qnn_models: dict[str, QuantumNeuralNetwork] = {}
        self.qsvc_models: dict[str, QuantumSupportVectorMachine] = {}
        self.vqr_models: dict[str, QuantumRegression] = {}

        # Quantum ML configuration
        self.quantum_ml_config = {
            "algorithms": {
                "quantum_neural_network": {
                    "type": "qnn",
                    "backend": "qasm_simulator",
                    "num_qubits": 8,
                    "epochs": 100,
                    "enabled": True,
                },
                "quantum_support_vector": {
                    "type": "qsvc",
                    "backend": "qasm_simulator",
                    "enabled": True,
                },
                "quantum_regression": {
                    "type": "vqr",
                    "backend": "qasm_simulator",
                    "epochs": 100,
                    "enabled": True,
                },
            },
            "training_settings": {},
        }

    async def get_symbol_market_data(self, symbol: str) -> list[dict[str, Any]]:
        try:
            if hasattr(self, "redis_client") and self.redis_client:
                binance_symbol = symbol.upper()
                if not binance_symbol.endswith("USDT"):
                    binance_symbol = f"{binance_symbol}USDT"
                raw = self.redis_client.get(f"market_data:{binance_symbol}")
                if raw:
                    data = json.loads(raw if isinstance(raw, str) else raw.decode())
                    if isinstance(data, list):
                        return data
                    if isinstance(data, dict):
                        return [data]
        except Exception as e:
            logger.debug(f"get_symbol_market_data({symbol}): {e}")
        return []

    async def prepare_training_data(self, market_data: list[dict[str, Any]]):
        try:
            if not market_data or len(market_data) < 10:
                return None, None, None
            prices = np.array([d.get("close", d.get("price", 0.0)) for d in market_data], dtype=float)
            volumes = np.array([d.get("volume", 0.0) for d in market_data], dtype=float)
            returns = np.diff(prices) / (prices[:-1] + 1e-10)
            X = np.column_stack([prices[1:], volumes[1:], returns])
            y_classification = (returns > 0).astype(int)
            y_regression = returns
            return X, y_classification, y_regression
        except Exception as e:
            logger.debug(f"prepare_training_data: {e}")
            return None, None, None

    async def make_symbol_quantum_predictions(self, symbol: str):
        try:
            market_data = await self.get_symbol_market_data(symbol)
            if not market_data:
                return
            for model_type in ("qnn", "qsvc", "vqr"):
                await self.make_specific_quantum_prediction(symbol, model_type, market_data)
        except Exception as e:
            logger.debug(f"make_symbol_quantum_predictions({symbol}): {e}")

    async def prepare_prediction_data(self, market_data: list[dict[str, Any]]):
        try:
            if not market_data:
                return None
            prices = np.array([d.get("close", d.get("price", 0.0)) for d in market_data], dtype=float)
            volumes = np.array([d.get("volume", 0.0) for d in market_data], dtype=float)
            if len(prices) < 2:
                return None
            returns = np.diff(prices) / (prices[:-1] + 1e-10)
            X = np.column_stack([prices[1:], volumes[1:], returns])
            return X
        except Exception as e:
            logger.debug(f"prepare_prediction_data: {e}")
            return None

    async def handle_quantum_model_training(self, message: dict[str, Any]):
        """Handle incoming request to train quantum models"""
        symbol = message.get("symbol")
        model_type = message.get("model_type")

        logger.info(f"Quantum model training requested for {symbol} model_type={model_type}")

        if not symbol:
            msg = "No symbol provided for training"
            raise ValueError(msg)

        try:
            # Delegate to training function
            await self.train_specific_quantum_model(symbol, model_type)

            response = {
                "type": "quantum_model_training_response",
                "symbol": symbol,
                "model_type": model_type,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Error handling quantum model training request: {e}")
            await self.broadcast_error(f"Quantum model training error: {e}")

    async def train_specific_quantum_model(self, symbol: str, model_type: str):
        """Train a specific quantum model type"""
        try:
            market_data = await self.get_symbol_market_data(symbol)

            if not market_data or len(market_data) < 500:
                return

            X, y_classification, y_regression = await self.prepare_training_data(market_data)

            if X is None:
                return

            if model_type == "qnn" and symbol in self.qnn_models:
                qnn = self.qnn_models[symbol]
                qnn.train_qnn(X, y_classification, epochs=100)
                logger.info(f"[OK] QNN training complete for {symbol}")

            elif model_type == "qsvc" and symbol in self.qsvc_models:
                qsvc = self.qsvc_models[symbol]
                qsvc.train_qsvc(X, y_classification)
                logger.info(f"[OK] QSVC training complete for {symbol}")

            elif model_type == "vqr" and symbol in self.vqr_models:
                vqr = self.vqr_models[symbol]
                vqr.train_vqr(X, y_regression, epochs=100)
                logger.info(f"[OK] VQR training complete for {symbol}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Error training specific quantum model: {e}")

    async def handle_quantum_prediction(self, message: dict[str, Any]):
        """Handle manual quantum prediction request"""
        try:
            symbol = message.get("symbol")
            model_type = message.get("model_type")

            logger.info(f"Manual quantum prediction requested for {symbol}")

            if symbol:
                market_data = await self.get_symbol_market_data(symbol)
                if market_data:
                    if model_type:
                        # Make prediction with specific model
                        prediction = await self.make_specific_quantum_prediction(symbol, model_type, market_data)

                        response = {
                            "type": "quantum_prediction_response",
                            "symbol": symbol,
                            "model_type": model_type,
                            "prediction": prediction,
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                        }
                    else:
                        # Make predictions with all models
                        await self.make_symbol_quantum_predictions(symbol)

                        response = {
                            "type": "quantum_prediction_response",
                            "symbol": symbol,
                            "predictions": (self.state["predictions_made"].get(symbol, {}).get("predictions", {})),
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                        }
                else:
                    response = {
                        "type": "quantum_prediction_response",
                        "symbol": symbol,
                        "prediction": None,
                        "error": "No market data available",
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    }
            else:
                response = {
                    "type": "quantum_prediction_response",
                    "symbol": symbol,
                    "prediction": None,
                    "error": "No symbol provided",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Error handling quantum prediction request: {e}")
            await self.broadcast_error(f"Quantum prediction error: {e}")

    async def make_specific_quantum_prediction(self, symbol: str, model_type: str, market_data: list[dict[str, Any]]) -> dict[str, Any] | None:
        """Make prediction with a specific quantum model"""
        try:
            X_pred = await self.prepare_prediction_data(market_data)

            if X_pred is None:
                return None

            try:
                from backend.services import confidence_normalizer as _confidence_normalizer_mod
            except Exception:
                _confidence_normalizer_mod = None

            def _norm(v: float) -> float:
                if _confidence_normalizer_mod is None:
                    return v
                return _confidence_normalizer_mod.ConfidenceNormalizer.normalize(v)

            if model_type == "qnn" and symbol in self.qnn_models:
                predictions = self.qnn_models[symbol].predict_qnn(X_pred)
                result = {
                    "predictions": np.asarray(predictions).tolist(),
                    "confidence": _norm(float(np.mean(predictions))),
                    "model_type": "quantum_neural_network",
                }
            elif model_type == "qsvc" and symbol in self.qsvc_models:
                predictions = self.qsvc_models[symbol].predict_qsvc(X_pred)
                result = {
                    "predictions": np.asarray(predictions).tolist(),
                    "confidence": _norm(float(np.mean(predictions))),
                    "model_type": "quantum_support_vector",
                }
            elif model_type == "vqr" and symbol in self.vqr_models:
                predictions = self.vqr_models[symbol].predict_vqr(X_pred)
                result = {
                    "predictions": np.asarray(predictions).tolist(),
                    "confidence": _norm(float(np.std(predictions))),
                    "model_type": "quantum_regression",
                }
            else:
                result = None
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Error making specific quantum prediction: {e}")
            return None
        else:
            return result

    async def handle_get_quantum_ml_status(self, message: dict[str, Any]):
        """Handle quantum ML status request"""
        try:
            symbol = message.get("symbol")

            logger.info(f"[STATS] Quantum ML status requested for {symbol}")

            # Get quantum ML status
            if symbol and symbol in self.state["training_history"]:
                status = self.state["training_history"][symbol]

                response = {
                    "type": "quantum_ml_status_response",
                    "symbol": symbol,
                    "status": status,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
            else:
                response = {
                    "type": "quantum_ml_status_response",
                    "symbol": symbol,
                    "status": None,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Error handling quantum ML status request: {e}")
            await self.broadcast_error(f"Quantum ML status error: {e}")

    async def update_quantum_ml_metrics(self):
        """Update quantum ML metrics"""
        try:
            metrics = {
                "agent_id": self.agent_id,
                "symbols_count": len(getattr(self, "trading_symbols", [])),
                "models_trained": len(self.state["models_trained"]),
                "predictions_count": len(self.state["predictions_made"]),
                "training_count": self.state["training_count"],
                "last_training": self.state["last_training"],
                "qnn_models": len(self.qnn_models),
                "qsvc_models": len(self.qsvc_models),
                "vqr_models": len(self.vqr_models),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            # Store metrics in Redis if client exists
            if hasattr(self, "redis_client") and self.redis_client:
                try:
                    self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics), ex=300)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.exception(f"Failed to set metrics in Redis: {e}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Error updating quantum ML metrics: {e}")

    async def initialize(self):
        """Initialize quantum ML agent - register message handlers"""
        try:
            # Register message handlers for quantum ML operations
            self.register_handler("quantum_model_training", self.handle_quantum_model_training)
            self.register_handler("quantum_prediction", self.handle_quantum_prediction)
            self.register_handler("get_quantum_ml_status", self.handle_get_quantum_ml_status)

            logger.info("[OK] Quantum ML agent handlers registered")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Error initializing quantum ML agent: {e}")

    async def process_loop(self):
        """Main processing loop - update metrics periodically"""
        while self.running:
            try:
                await self.update_quantum_ml_metrics()
                await asyncio.sleep(300)  # Update metrics every 5 minutes
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception(f"[ERROR] Error in quantum ML process loop: {e}")
                await asyncio.sleep(60)  # Retry after 1 minute on error

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process market data - quantum agent processes on demand via messages"""
        # Quantum ML agent processes data reactively via message handlers
        # No continuous processing needed
        pass

    async def cleanup_cache(self):
        """Clean up old cache entries"""
        try:
            current_time = datetime.now(timezone.utc)

            # Clean up old training history entries
            for symbol in list(self.state["training_history"].keys()):
                if "data" in self.state["training_history"][symbol]:
                    data_points = self.state["training_history"][symbol]["data"]

                    # Keep only recent data points (last 48 hours)
                    cutoff_time = current_time - timedelta(hours=48)
                    recent_data = [point for point in data_points if datetime.fromisoformat(point["timestamp"]) > cutoff_time]

                    if recent_data:
                        self.state["training_history"][symbol]["data"] = recent_data
                    else:
                        del self.state["training_history"][symbol]

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Error cleaning up cache: {e}")
