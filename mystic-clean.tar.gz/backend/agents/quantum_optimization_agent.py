import asyncio
import logging
from collections.abc import Callable
from typing import Any

import numpy as np
from qiskit import (
    ClassicalRegister,
    QuantumCircuit,
    QuantumRegister,
)
from qiskit.quantum_info import SparsePauliOp
from qiskit_aer import Aer
from scipy.optimize import minimize

# Qiskit 2.x compatibility - execute is deprecated, use Sampler instead
try:
    from qiskit.execute_function import execute
except (ImportError, ModuleNotFoundError):
    # Fallback for Qiskit 2.x - create a wrapper
    def execute(circuit, backend, shots=1000):
        """Compatibility wrapper for Qiskit 2.x"""
        from qiskit_aer import AerSimulator

        backend_instance = AerSimulator() if isinstance(backend, str) else backend
        job = backend_instance.run(circuit, shots=shots)
        return job


from backend.agents.base_agent import BaseAgent

logger = logging.getLogger(__name__)

"""
Quantum Optimization Agent
Implements quantum optimization algorithms for trading strategies
"""

# Direct imports for production


class QuantumOptimizationAgent(BaseAgent):
    """Quantum Optimization Agent - Uses quantum algorithms for optimization"""

    def __init__(self, agent_id: str = "quantum_optimization_agent_001") -> None:
        super().__init__(agent_id, "quantum_optimization")
        self.vqe = None
        self.qaoa = None
        self.annealer = None
        logger.info(f"🔬 Quantum Optimization Agent {agent_id} initialized")

    async def initialize(self):
        """Initialize quantum optimization components"""
        try:
            self.annealer = QuantumAnnealingOptimizer()
            self.vqe = VariationalQuantumOptimizer()
            self.constraint_opt = QuantumConstraintOptimizer()
            logger.info(f"✓ Quantum Optimization Agent {self.agent_id} initialized")
        except Exception as e:
            logger.exception(f"Error initializing Quantum Optimization Agent: {e}")
            self.update_health_status("error")

    async def process_loop(self):
        """Main quantum optimization processing loop"""
        while self.running:
            try:
                # Quantum optimization runs on-demand
                await asyncio.sleep(60)
            except Exception as e:
                logger.exception(f"Error in quantum optimization loop: {e}")
                await asyncio.sleep(300)

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process market data for quantum optimization"""
        try:
            logger.debug("Quantum Optimization Agent processing market data")
            self.state["last_market_data"] = market_data
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error processing market data")


class QuantumAnnealingOptimizer:
    """Quantum Annealing for optimization problems"""

    def __init__(self, backend: str = "qasm_simulator") -> None:
        self.backend = backend
        self.optimizer = None

    def optimize_portfolio_quantum_annealing(self, returns: np.ndarray, risk_free_rate: float = 0.02):
        """Optimize portfolio using quantum annealing approach"""
        try:
            # Calculate expected returns and covariance
            expected_returns = np.mean(returns, axis=0)
            covariance_matrix = np.cov(returns.T)

            # Create portfolio optimization problem
            num_assets = len(expected_returns)

            # Create quantum circuit for QAOA
            qr = QuantumRegister(num_assets, "q")
            cr = ClassicalRegister(num_assets, "c")
            circuit = QuantumCircuit(qr, cr)

            # Initialize with equal superposition
            circuit.h(qr)

            # Apply QAOA-like layers (simplified variational circuit)
            for _layer in range(3):  # 3 layers
                # Cost-like operations using covariance as interaction strengths
                for i in range(num_assets):
                    for j in range(i + 1, num_assets):
                        if covariance_matrix[i, j] != 0:
                            circuit.cx(qr[i], qr[j])
                            circuit.rz(float(covariance_matrix[i, j]), qr[j])
                            circuit.cx(qr[i], qr[j])

                # Mixing layer
                circuit.h(qr)
                for i in range(num_assets):
                    circuit.rx(np.pi / 4, qr[i])

            # Measure
            circuit.measure(qr, cr)

            # Execute
            backend = Aer.get_backend(self.backend)
            job = execute(circuit, backend, shots=1000)
            result = job.result()
            counts = result.get_counts()

            # Extract optimal weights
            optimal_weights = self.extract_weights_from_counts(counts, num_assets)

            # Calculate portfolio metrics
            portfolio_return = float(np.sum(optimal_weights * expected_returns))
            portfolio_risk = float(np.sqrt(optimal_weights.T @ covariance_matrix @ optimal_weights))
            sharpe_ratio = float((portfolio_return - risk_free_rate) / (portfolio_risk + 1e-12))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error in quantum annealing optimization: {e}")
            return None
        else:
            return {
                "weights": optimal_weights,
                "expected_return": portfolio_return,
                "risk": portfolio_risk,
                "sharpe_ratio": sharpe_ratio,
                "optimization_method": "quantum_annealing",
            }

    def extract_weights_from_counts(self, counts: dict[str, int], num_assets: int) -> np.ndarray:
        """Extract portfolio weights from measurement counts"""
        try:
            total_shots = sum(counts.values()) if counts else 0
            if total_shots == 0:
                # No measurements recorded; return uniform weights
                return np.ones(num_assets) / num_assets

            weights = np.zeros(num_assets)

            for bitstring, count in counts.items():
                # Qiskit returns bitstrings with qubit-0 as rightmost; align to our indexing by reversing
                # Here we map bit 0 to asset 0 by taking reversed bitstring
                bs = bitstring[::-1]
                for i, bit in enumerate(bs):
                    if i >= num_assets:
                        break
                    if bit == "1":
                        weights[i] += count / total_shots

            total_weight = np.sum(weights)
            if total_weight == 0:
                return np.ones(num_assets) / num_assets

            # Normalize weights
            return weights / total_weight

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error extracting weights: {e}")
            return np.ones(num_assets) / num_assets


class VariationalQuantumOptimizer:
    """Variational Quantum Optimization for complex problems"""

    def __init__(self, backend: str = "qasm_simulator") -> None:
        self.backend = backend
        self.optimizer = None

    def optimize_trading_strategy_vqe(self, strategy_params: dict[str, Any], market_data: np.ndarray):
        """Optimize trading strategy parameters using a variational approach (fallback classical optimizer)"""
        try:
            # Define objective function for strategy optimization
            def objective_function(params):
                # Simulate strategy performance with given parameters
                performance = self.simulate_strategy_performance(np.asarray(params), market_data)
                return -float(performance)  # Minimize negative performance (maximize performance)

            # Prepare initial guess from provided strategy_params (use values if provided, else zeros)
            if isinstance(strategy_params, dict):
                initial_guess = np.array([float(v) if isinstance(v, (int, float)) else 0.0 for v in strategy_params.values()])
            else:
                # If user passed iterable
                initial_guess = np.asarray(strategy_params, dtype=float)

            if initial_guess.size == 0:
                initial_guess = np.zeros(1)

            # Use a classical optimizer as a fallback (SLSQP)
            res = minimize(objective_function, initial_guess, method="SLSQP", options={"maxiter": 200})

            optimal_params = res.x
            optimal_value = -res.fun  # because we minimized negative performance

            return {
                "optimal_parameters": optimal_params,
                "optimal_value": optimal_value,
                "success": bool(res.success),
                "message": res.message,
                "optimization_method": "vqe_classical_fallback",
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error in VQE optimization: {e}")
            return None

    def create_strategy_hamiltonian(self, strategy_params: dict[str, Any]):
        """Create Hamiltonian for strategy optimization (simplified)"""
        try:
            # Create a simple Hamiltonian based on strategy parameters
            num_qubits = len(strategy_params)
            hamiltonian_terms = []

            # Add terms for each parameter; SparsePauliOp.from_list expects (pauli_label, coeff)
            for i, (_param_name, param_value) in enumerate(strategy_params.items()):
                pauli_string = ["I"] * num_qubits
                pauli_string[i] = "Z"
                pauli_label = "".join(pauli_string[::-1])  # order typically reversed
                hamiltonian_terms.append((pauli_label, float(param_value)))

            if not hamiltonian_terms:
                # Return a zero operator for safety
                return SparsePauliOp.from_list([("I" * 1, 0.0)])

            return SparsePauliOp.from_list(hamiltonian_terms)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error creating strategy Hamiltonian: {e}")
            return None

    def simulate_strategy_performance(self, params: np.ndarray, market_data: np.ndarray) -> float:
        """Simulate trading strategy performance with given parameters"""
        try:
            params = np.asarray(params, dtype=float)
            market_data = np.asarray(market_data, dtype=float)

            returns = np.diff(market_data) / (market_data[:-1] + 1e-12) if market_data.ndim == 1 else np.diff(market_data, axis=0)

            if returns.size == 0:
                return 0.0

            # If params length doesn't match returns' feature dimension, trim or pad
            if returns.ndim == 1:
                # Single series: use scalar or first param
                signal = returns if params.size == 0 else returns * params[0]
            else:
                # Multi-dimensional returns: ensure inner dimension
                feature_len = returns.shape[1]
                p = np.pad(params, (0, feature_len - params.size), "constant") if params.size < feature_len else params[:feature_len]
                signal = returns @ p

            # Calculate performance metric (Sharpe-like)
            return float(np.mean(signal) / (np.std(signal) + 1e-08)) if signal.size > 1 else float(np.mean(signal))

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error simulating strategy performance: {e}")
            return 0.0


class QuantumConstraintOptimizer:
    """Quantum optimization with constraints (classical fallback)"""

    def __init__(self, backend: str = "qasm_simulator") -> None:
        self.backend = backend

    def optimize_with_constraints(
        self,
        objective_func: Callable[[np.ndarray], float],
        constraints: list[dict[str, Any]],
        bounds: list[tuple[float, float]],
        initial_guess: np.ndarray,
    ):
        """Optimize with constraints using classical solver as a fallback.

        objective_func: callable that accepts a 1D numpy array and returns a scalar to minimize.
        constraints: list of dicts with keys matching scipy.optimize.minimize format, e.g.
            {"type": "eq" or "ineq", "fun": callable}
        bounds: list of (min, max) tuples for each variable
        initial_guess: initial guess array
        """
        try:
            # Prepare constraints for scipy.optimize
            scipy_constraints = []
            for c in constraints:
                if not isinstance(c, dict):
                    continue
                ctype = c.get("type")
                cfun = c.get("fun")
                if ctype in ("eq", "ineq") and callable(cfun):
                    scipy_constraints.append({"type": ctype, "fun": cfun})

            # Ensure initial guess is numpy array
            x0 = np.asarray(initial_guess, dtype=float)
            if x0.size == 0:
                # If no initial guess provided, initialize in the middle of bounds or zeros
                x0 = np.array([(b[0] + b[1]) / 2.0 for b in bounds], dtype=float) if bounds else np.zeros(1)

            res = minimize(
                objective_func,
                x0,
                method="SLSQP",
                bounds=bounds if bounds else None,
                constraints=scipy_constraints if scipy_constraints else (),
                options={"maxiter": 500},
            )

            return {
                "success": bool(res.success),
                "x": res.x,
                "fun": res.fun,
                "message": res.message,
                "optimization_method": "slsqp_classical_fallback",
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error in constraint optimization: {e}")
            return {
                "success": False,
                "x": np.asarray(initial_guess),
                "fun": None,
                "message": str(e),
                "optimization_method": "slsqp_classical_fallback",
            }
