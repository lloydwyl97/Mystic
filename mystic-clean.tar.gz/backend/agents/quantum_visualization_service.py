import asyncio
import logging

import numpy as np
import plotly.graph_objs as go

from backend.config.redis_config import get_shared_redis_async

logger = logging.getLogger(__name__)

r = get_shared_redis_async()


async def fetch(key, default="N/A"):
    try:
        val = await r.get(key)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        return default
    else:
        return val if val else default


def render_quantum_indicators():
    # Intentionally lightweight/no-op function that previously created an event loop.
    # Keep signature and behavior (no return value). Avoid leaking/setting global event loop.
    loop = asyncio.new_event_loop()
    loop.close()


async def get_waveform_data():
    try:
        raw = await r.lrange("quantum_waveform_data", 0, -1)
        waveform_data = []
        for x in raw[-300:]:
            try:
                value = float(x)
                # Validate for NaN and infinite values
                if not (np.isnan(value) or np.isinf(value)):
                    waveform_data.append(value)
                else:
                    # Replace invalid values with safe fallback
                    waveform_data.append(0.0)
            except (ValueError, TypeError):
                # Replace invalid data with safe fallback
                waveform_data.append(0.0)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error fetching waveform data: {e}")
        return []
    else:
        return waveform_data


def render_quantum_waveform_chart():
    loop = asyncio.new_event_loop()
    try:
        y = loop.run_until_complete(get_waveform_data())
    finally:
        loop.close()

    if not y:
        logger.info("[INFO] No waveform data available yet.")
        return None

    # Validate waveform data
    try:
        if any(np.isnan(y)) or any(np.isinf(y)):
            logger.warning("[WARN] Invalid waveform data detected, using fallback")
            y = [0.0] * len(y) if y else [0.0] * 100
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        # If validation fails for any reason, fall back safely
        logger.exception("[ERROR] Exception during waveform validation, using fallback data")
        y = [0.0] * (len(y) if y else 100)

    x = list(range(len(y)))
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=x, y=y, mode="lines", name="Quantum Signal"))
    fig.update_layout(
        height=200,
        margin={"l": 0, "r": 0, "t": 10, "b": 10},
        paper_bgcolor="#0e1117",
        plot_bgcolor="#0e1117",
        font_color="#FFFFFF",
        showlegend=False,
    )
    # Chart rendering - function returns figure object
    return fig
