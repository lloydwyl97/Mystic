import asyncio
import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Any

import numpy as np
import pandas as pd
import torch
from torch import nn

from backend.agents.base_agent import BaseAgent
from backend.core.constants import TOTAL_FEATURES

logger = logging.getLogger(__name__)

"""
Reinforcement Learning Agent
Handles reinforcement learning for trading strategy optimization
"""

# Make all imports live (F401_ = Tuple[int, int]

# Add parent directory to path for imports


class DQNetwork(nn.Module):
    """Deep Q-Network for trading"""

    def __init__(self, state_size: int, action_size: int, hidden_size: int = 128) -> None:
        super().__init__()
        self.fc1 = nn.Linear(state_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc3 = nn.Linear(hidden_size, action_size)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.2)

    def forward(self, x):
        x = self.dropout(self.relu(self.fc1(x)))
        x = self.dropout(self.relu(self.fc2(x)))
        return self.fc3(x)


class PolicyNetwork(nn.Module):
    """Policy Network for Actor-Critic methods"""

    def __init__(self, state_size: int, action_size: int, hidden_size: int = 128) -> None:
        super().__init__()
        self.fc1 = nn.Linear(state_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc3 = nn.Linear(hidden_size, action_size)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.2)

    def forward(self, x):
        x = self.dropout(self.relu(self.fc1(x)))
        x = self.dropout(self.relu(self.fc2(x)))
        x = self.fc3(x)
        return torch.softmax(x, dim=-1)


class ValueNetwork(nn.Module):
    """Value Network for Actor-Critic methods"""

    def __init__(self, state_size: int, hidden_size: int = 128) -> None:
        super().__init__()
        self.fc1 = nn.Linear(state_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc3 = nn.Linear(hidden_size, 1)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.2)

    def forward(self, x):
        x = self.dropout(self.relu(self.fc1(x)))
        x = self.dropout(self.relu(self.fc2(x)))
        return self.fc3(x)


class ReplayBuffer:
    """Experience replay buffer for DQN training"""

    def __init__(self, capacity: int = 10000):
        self.capacity = capacity
        self.buffer = []
        self.position = 0

    def push(self, state, action, reward, next_state, done):
        """Store experience in replay buffer"""
        if len(self.buffer) < self.capacity:
            self.buffer.append(None)
        self.buffer[self.position] = (state, action, reward, next_state, done)
        self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size: int):
        """Sample random batch from buffer"""
        import random

        batch = random.sample(self.buffer, min(batch_size, len(self.buffer)))
        states, actions, rewards, next_states, dones = zip(*batch, strict=True)
        return (np.array(states), np.array(actions), np.array(rewards), np.array(next_states), np.array(dones))

    def __len__(self):
        return len(self.buffer)


class TradingEnvironment:
    """Trading environment for reinforcement learning"""

    def __init__(
        self,
        data: pd.DataFrame,
        initial_balance: float = 10000.0,
        transaction_fee: float = 0.001,
    ) -> None:
        self.data = data
        self.initial_balance = initial_balance
        self.transaction_fee = transaction_fee
        self.reset()

    def reset(self):
        """Reset environment to initial state"""
        self.current_step = 0
        self.balance = self.initial_balance
        self.shares_held = 0
        self.total_shares_sold = 0
        self.total_sales_value = 0
        # Support both "price" and "close" columns
        price_col = "price" if "price" in self.data.columns else "close"
        self.current_price = self.data.iloc[0][price_col]
        self.price_col = price_col
        return self._get_state()

    def step(self, action: int):
        """Take action and return new state, reward, done"""
        # Actions: 0 = hold, 1 = buy, 2 = sell
        reward = 0
        done = False

        if self.current_step >= len(self.data) - 1:
            done = True
            return self._get_state(), reward, done

        self.current_price = self.data.iloc[self.current_step][self.price_col]
        next_price = self.data.iloc[self.current_step + 1][self.price_col]

        if action == 1:  # Buy
            if self.balance > 0:
                shares_to_buy = self.balance / (self.current_price * (1 + self.transaction_fee))
                self.shares_held += shares_to_buy
                self.balance -= shares_to_buy * self.current_price * (1 + self.transaction_fee)

        elif action == 2 and self.shares_held > 0:  # Sell
            self.total_shares_sold += self.shares_held
            self.total_sales_value += self.shares_held * self.current_price * (1 - self.transaction_fee)
            self.balance += self.shares_held * self.current_price * (1 - self.transaction_fee)
            self.shares_held = 0

        # Calculate reward (price change)
        price_change = (next_price - self.current_price) / self.current_price
        reward = price_change

        self.current_step += 1

        return self._get_state(), reward, done

    def _get_state(self):
        """Get current state representation using 124 features from system"""
        if self.current_step >= len(self.data):
            return np.zeros(TOTAL_FEATURES)

        # Phase 4: full 124-feature pipeline in ai_signal_generator / feature_builder (canonical ML).
        # Current: basic features for RL compatibility only.
        # - backend/services/ai_signal_generator.py, backend/services/feature_builder.py

        # Basic features (same as before for compatibility)
        price_col = "price" if "price" in self.data.columns else "close"
        current_price = self.data.iloc[self.current_step].get(price_col, 0.0)
        prev_price = self.data.iloc[max(0, self.current_step - 1)].get(price_col, 0.0)
        price_change = current_price - prev_price
        current_volume = self.data.iloc[self.current_step].get("volume", 0.0)
        prev_volume = self.data.iloc[max(0, self.current_step - 1)].get("volume", 0.0)
        volume_change = current_volume - prev_volume

        # Technical indicators (simplified)
        # Support both "price" and "close" columns
        price_col = "price" if "price" in self.data.columns else "close"
        if self.current_step >= 20:
            sma_20 = self.data.iloc[self.current_step - 20 : self.current_step][price_col].mean()
            price_vs_sma = (current_price - sma_20) / sma_20 if sma_20 > 0 else 0
        else:
            price_vs_sma = 0

        if self.current_step >= 50:
            sma_50 = self.data.iloc[self.current_step - 50 : self.current_step][price_col].mean()
            price_vs_sma_50 = (current_price - sma_50) / sma_50 if sma_50 > 0 else 0
        else:
            price_vs_sma_50 = 0

        # Portfolio state
        portfolio_value = self.balance + (self.shares_held * current_price)
        portfolio_return = (portfolio_value - self.initial_balance) / self.initial_balance if self.initial_balance > 0 else 0

        # Create 124-feature vector (padding rest with zeros for now)
        # First 10 features are the basic ones we have
        basic_features = [
            current_price / 1000 if current_price > 0 else 0,  # Normalized price
            price_change / 100 if abs(price_change) > 0 else 0,  # Normalized price change
            current_volume / 1000000 if current_volume > 0 else 0,  # Normalized volume
            volume_change / 100000 if abs(volume_change) > 0 else 0,  # Normalized volume change
            price_vs_sma,  # Price vs 20-day SMA
            price_vs_sma_50,  # Price vs 50-day SMA
            self.balance / self.initial_balance if self.initial_balance > 0 else 0,  # Cash ratio
            self.shares_held / 100 if self.shares_held > 0 else 0,  # Shares held
            portfolio_return,  # Portfolio return
            self.current_step / len(self.data) if len(self.data) > 0 else 0,  # Progress
        ]

        # Pad to 124 features with zeros (will be filled by real feature pipeline in Phase 4)
        full_features = basic_features + [0.0] * (TOTAL_FEATURES - len(basic_features))

        return np.array(full_features, dtype=np.float32)


class ReinforcementLearningAgent(BaseAgent):
    """Reinforcement Learning Agent - Uses RL for trading strategy optimization"""

    def __init__(self, agent_id: str = "reinforcement_learning_agent_001") -> None:
        super().__init__(agent_id, "reinforcement_learning")

        # Initialize random number generator for modern NumPy API
        self.rng = np.random.Generator(np.random.PCG64())

        self.state.update(
            {
                "models_trained": {},
                "strategies_generated": {},
                "training_history": {},
                "last_training": None,
                "training_count": 0,
            },
        )

        # RL configuration - UPDATED to use 124 features from system
        self.rl_config = {
            "algorithms": {
                "dqn": {
                    "type": "deep_q_learning",
                    "state_size": TOTAL_FEATURES,  # 124 features (social, news, technical, sentiment)
                    "action_size": 3,
                    "hidden_size": 256,  # Increased for more features
                    "learning_rate": 0.001,
                    "gamma": 0.95,
                    "epsilon": 1.0,
                    "epsilon_min": 0.01,
                    "epsilon_decay": 0.995,
                    "memory_size": 10000,
                    "batch_size": 32,
                    "enabled": True,
                },
                "actor_critic": {
                    "type": "actor_critic",
                    "state_size": TOTAL_FEATURES,  # 124 features
                    "action_size": 3,
                    "hidden_size": 256,  # Increased for more features
                    "learning_rate": 0.001,
                    "gamma": 0.95,
                    "enabled": True,
                },
            },
            "training_settings": {
                "episodes": 1000,
                "max_steps": 1000,
                "min_data_points": 500,
                "validation_split": 0.2,
                "early_stopping_patience": 50,
            },
            "strategy_settings": {
                "confidence_threshold": 0.7,
                "min_trades": 10,
                "max_position_size": 0.5,
            },
        }

        # Trading symbols to monitor
        self.trading_symbols = [
            "BTC",
            "ETH",
            "ADA",
            "DOT",
            "LINK",
            "UNI",
            "AAVE",
        ]

        # Initialize models and environments
        self.models = {}
        self.environments = {}
        self.memories = {}
        self.scalers = {}
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # Phase 4: Training infrastructure
        self._training_lock = asyncio.Lock()
        self._replay_buffers = {}  # Symbol -> ReplayBuffer
        self._training_stats = {}  # Symbol -> training metrics
        self._episode_rewards = {}  # Symbol -> list of rewards
        self._trade_history = {}  # Symbol -> list of (state, action, reward, next_state)

        # Model paths
        from pathlib import Path

        self.model_dir = Path("models/rl")
        self.model_dir.mkdir(parents=True, exist_ok=True)

        # redis_client may be provided by BaseAgent or external setup; keep attribute if present
        self.redis_client = getattr(self, "redis_client", None)

    async def broadcast_message(self, message: dict[str, Any]):
        """Placeholder broadcast - actual implementation provided by BaseAgent or system."""
        # If BaseAgent implements broadcast, prefer that. Otherwise, noop.
        if hasattr(super(), "broadcast_message"):
            try:
                return await super().broadcast_message(message)  # type: ignore[misc]
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pass
        return None

    async def send_message(self, recipient: str, message: dict[str, Any]):
        """Placeholder send - actual implementation provided by BaseAgent or system."""
        if hasattr(super(), "send_message"):
            try:
                return await super().send_message(recipient, message)  # type: ignore[misc]
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pass
        return None

    async def broadcast_error(self, error_message: str):
        """Broadcast error message - placeholder"""
        try:
            err = {
                "type": "agent_error",
                "agent_id": self.agent_id,
                "error": error_message,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            await self.broadcast_message(err)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            pass

    # ========================
    # BaseAgent abstract methods implementation
    # ========================

    async def initialize(self):
        """Initialize RL agent - Phase 4: Initialize models"""
        logger.info(f"🤖 Initializing Reinforcement Learning Agent {self.agent_id}")
        logger.info(f"   Features: {self.rl_config['algorithms']['dqn']['state_size']} (social, news, technical)")

        # Phase 4: Initialize models
        for algo_name, config in self.rl_config["algorithms"].items():
            if config["enabled"]:
                state_size = config["state_size"]
                action_size = config["action_size"]
                hidden_size = config["hidden_size"]

                if algo_name == "dqn":
                    model = DQNetwork(state_size, action_size, hidden_size).to(self.device)
                    self.models[algo_name] = model
                    logger.info(f"   ✅ DQN model initialized: {state_size} features -> {action_size} actions")

                elif algo_name == "actor_critic":
                    self.models[f"{algo_name}_policy"] = PolicyNetwork(state_size, action_size, hidden_size).to(self.device)
                    self.models[f"{algo_name}_value"] = ValueNetwork(state_size, hidden_size).to(self.device)
                    logger.info("   ✅ Actor-Critic models initialized")

        logger.info("   Status: Ready for market data collection and training")

    async def process_loop(self):
        """Main processing loop - Phase 4: Generate RL recommendations continuously"""
        logger.info(f"🔄 RL Agent {self.agent_id} starting recommendation generation loop")

        while self.running:
            try:
                # Generate recommendations for all trading symbols
                for symbol in self.trading_symbols:
                    try:
                        # Fetch current market features
                        features = await self._fetch_current_features(symbol)

                        if features:
                            # Get current confidence from AI signal if available
                            confidence = features.get("confidence", 0.6)

                            # Generate position sizing recommendation
                            await self.recommend_position_multiplier(
                                symbol=symbol,
                                kelly_size=100.0,  # Base size (will be adjusted by Kelly in autobuy)
                                confidence=confidence,
                                market_state=features,
                            )

                            # Generate timing recommendation
                            await self.recommend_timing_signal(symbol=symbol, decision_pending=True, last_decision_elapsed=0.0, market_conditions=features)

                            logger.debug(f"✅ Generated RL recommendations for {symbol}")
                        else:
                            logger.debug(f"No features available for {symbol}, skipping")

                    except Exception as e:
                        logger.debug(f"Error generating recommendations for {symbol}: {e}")
                        continue

                # Update metrics
                await self.update_rl_metrics()

                # Generate recommendations every 5 seconds (aligns with trade engine)
                await asyncio.sleep(5)

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception(f"Error in RL agent process loop: {e}")
                await asyncio.sleep(30)  # Longer sleep on error

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process market data - Phase 1/4: Store and prepare for training"""
        # Phase 1: Just acknowledge receipt
        logger.debug(f"RL Agent processing market data for {len(market_data)} symbols")

        # Phase 4: Store for training
        for symbol, data in market_data.items():
            if symbol in self.trading_symbols:
                # Build feature vector
                features = self._build_feature_vector(symbol, data)
                if features:
                    # Store in trade history for training
                    if symbol not in self._trade_history:
                        self._trade_history[symbol] = []

                    self._trade_history[symbol].append(
                        {
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                            "features": features,
                            "price": data.get("price", 0.0),
                        }
                    )

                    # Keep only recent history (last 1000 samples)
                    if len(self._trade_history[symbol]) > 1000:
                        self._trade_history[symbol] = self._trade_history[symbol][-1000:]

    async def _fetch_current_features(self, symbol: str) -> dict[str, Any] | None:
        """
        Fetch current market features for RL recommendation generation.
        Queries Redis for latest AI decision data and market data.
        """
        try:
            if not self.redis_client:
                return None

            # Normalize symbol to BINANCE format (e.g., BTC -> BTCUSDT)
            binance_symbol = symbol.upper()
            if not binance_symbol.endswith("USDT"):
                binance_symbol = f"{binance_symbol}USDT"

            # Try to get AI decision data (has most complete features)
            ai_decision_key = f"ai_decision:{binance_symbol}"
            try:
                decision_data = self.redis_client.hgetall(ai_decision_key)
                if decision_data:
                    # Decode bytes to strings
                    features = {}
                    for k, v in decision_data.items():
                        try:
                            key = k.decode() if isinstance(k, bytes) else k
                            val = v.decode() if isinstance(v, bytes) else v
                            # Try to convert to float for numeric features
                            try:
                                features[key] = float(val)
                            except (ValueError, TypeError):
                                features[key] = val
                        except Exception:
                            continue

                    if features:
                        logger.debug(f"Fetched {len(features)} features for {symbol} from AI decision")
                        return features
            except Exception as e:
                logger.debug(f"Could not fetch AI decision for {symbol}: {e}")

            # Fallback: Try market data
            market_data_key = f"market_data:{binance_symbol}"
            try:
                market_data = self.redis_client.hgetall(market_data_key)
                if market_data:
                    features = {}
                    for k, v in market_data.items():
                        try:
                            key = k.decode() if isinstance(k, bytes) else k
                            val = v.decode() if isinstance(v, bytes) else v
                            try:
                                features[key] = float(val)
                            except (ValueError, TypeError):
                                features[key] = val
                        except Exception:
                            continue

                    if features:
                        logger.debug(f"Fetched {len(features)} features for {symbol} from market data")
                        return features
            except Exception as e:
                logger.debug(f"Could not fetch market data for {symbol}: {e}")

        except Exception as e:
            logger.debug(f"Error fetching features for {symbol}: {e}")
            return None
        else:
            # No data available
            return None

    async def record_trade_result(
        self,
        symbol: str,
        action: int,  # 0=reduce, 1=hold, 2=increase
        state_before: list[float],
        state_after: list[float],
        profit_loss: float,
        trade_success: bool,
    ):
        """
        Phase 4: Record trade results for RL training.
        This creates experience tuples (s, a, r, s') for replay buffer.

        Args:
            symbol: Trading symbol
            action: Action taken (0-2)
            state_before: Feature vector before trade
            state_after: Feature vector after trade
            profit_loss: Profit/loss from trade
            trade_success: Whether trade was successful
        """
        try:
            # Calculate reward
            # Positive reward for profitable trades, negative for losses
            reward = profit_loss

            # Bonus for successful high-conviction trades
            if trade_success and profit_loss > 0:
                reward *= 1.2

            # Penalty for failed trades
            if not trade_success:
                reward -= 0.1

            # Get or create replay buffer for symbol
            if symbol not in self._replay_buffers:
                self._replay_buffers[symbol] = ReplayBuffer(capacity=10000)

            # Store experience
            done = False  # Trades are continuous, not episodic
            self._replay_buffers[symbol].push(state_before, action, reward, state_after, done)

            # Record for episode tracking
            if symbol not in self._episode_rewards:
                self._episode_rewards[symbol] = []
            self._episode_rewards[symbol].append(reward)

            logger.debug(f"RL trade result recorded for {symbol}: action={action}, reward={reward:.4f}, buffer_size={len(self._replay_buffers[symbol])}")

            # Store in Redis for monitoring
            if self.redis_client:
                try:
                    key = f"rl_trade_result:{symbol}:latest"
                    self.redis_client.hset(key, "action", str(action))
                    self.redis_client.hset(key, "reward", str(reward))
                    self.redis_client.hset(key, "profit_loss", str(profit_loss))
                    self.redis_client.hset(key, "success", str(trade_success))
                    self.redis_client.hset(key, "timestamp", datetime.now(timezone.utc).isoformat())
                    self.redis_client.expire(key, 300)  # 5 min TTL
                except Exception as e:
                    logger.debug(f"Failed to store trade result in Redis: {e}")

            # Trigger training if enough samples collected
            if len(self._replay_buffers[symbol]) >= 500:
                # Train asynchronously in background
                task = asyncio.create_task(self._train_from_buffer(symbol))
                self._tasks.append(task)

        except Exception as e:
            logger.exception(f"Error recording trade result for {symbol}: {e}")

    async def _train_from_buffer(self, symbol: str):
        """
        Phase 4: Train model from replay buffer (background task).
        Only trains if not already training.
        """
        if not self._training_lock.locked():
            try:
                async with self._training_lock:
                    logger.info(f"Starting background training for {symbol}")

                    # Create simple environment for training
                    # (In real scenario, this would be more sophisticated)
                    if symbol in self._trade_history and len(self._trade_history[symbol]) > 100:
                        prices = [entry["price"] for entry in self._trade_history[symbol]]
                        df_data = {
                            "close": prices,
                            "open": prices,
                            "high": prices,
                            "low": prices,
                            "volume": [0.0] * len(prices),
                        }
                        df = pd.DataFrame(df_data)

                        environment = TradingEnvironment(df)
                        model = self.models.get("dqn")

                        if model:
                            # Run training
                            await self.train_rl_model(symbol, "dqn", model, environment)

                            logger.info(f"Background training complete for {symbol}")
            except Exception as e:
                logger.exception(f"Error in background training for {symbol}: {e}")
        # Storage handled by handle_market_data method

    # ========================
    # Placeholder methods (will be implemented in Phase 4 - Training)
    # ========================

    async def get_symbol_market_data(self, _symbol: str):
        """Retrieve market data for a symbol from Redis or trade history."""
        try:
            if self.redis_client:
                binance_symbol = _symbol.upper()
                if not binance_symbol.endswith("USDT"):
                    binance_symbol = f"{binance_symbol}USDT"
                raw = self.redis_client.get(f"market_data:{binance_symbol}")
                if raw:
                    data = json.loads(raw if isinstance(raw, str) else raw.decode())
                    if isinstance(data, list) and data:
                        return data
                    if isinstance(data, dict):
                        return [data]
            if _symbol in self._trade_history and self._trade_history[_symbol]:
                return [
                    {"close": e["price"], "price": e["price"], "volume": 0, "timestamp": e["timestamp"]}
                    for e in self._trade_history[_symbol]
                ]
        except Exception as e:
            logger.debug(f"get_symbol_market_data({_symbol}): {e}")
        return None

    async def train_rl_model(self, symbol: str, algorithm_name: str, model: Any, environment: TradingEnvironment):
        """Phase 4: Train RL model using experience replay"""
        try:
            already_held = self._training_lock.locked()
            if already_held:
                logger.info(f"Training {algorithm_name} model for {symbol}")
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(None, self._train_dqn_sync, symbol, model, environment)
                logger.info(f"Training complete for {symbol}")
            else:
                async with self._training_lock:
                    logger.info(f"Training {algorithm_name} model for {symbol}")
                    loop = asyncio.get_event_loop()
                    await loop.run_in_executor(None, self._train_dqn_sync, symbol, model, environment)
                    logger.info(f"Training complete for {symbol}")

        except Exception as e:
            logger.exception(f"Error training {algorithm_name} for {symbol}: {e}")

    def _train_dqn_sync(self, symbol: str, model: DQNetwork, environment: TradingEnvironment):
        """Synchronous DQN training (runs in thread pool)"""
        try:
            # Get or create replay buffer
            if symbol not in self._replay_buffers:
                self._replay_buffers[symbol] = ReplayBuffer(capacity=10000)

            replay_buffer = self._replay_buffers[symbol]

            # Training hyperparameters
            config = self.rl_config["algorithms"]["dqn"]
            learning_rate = config["learning_rate"]
            gamma = config["gamma"]
            epsilon = config["epsilon"]
            epsilon_min = config["epsilon_min"]
            epsilon_decay = config["epsilon_decay"]
            batch_size = config["batch_size"]
            episodes = min(self.rl_config["training_settings"]["episodes"], 100)  # Limit for now

            # Optimizer
            optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
            criterion = nn.MSELoss()

            # Training loop
            episode_rewards = []

            for episode in range(episodes):
                state = environment.reset()
                total_reward = 0
                done = False
                steps = 0
                max_steps = self.rl_config["training_settings"]["max_steps"]

                while not done and steps < max_steps:
                    # Epsilon-greedy action selection
                    if self.rng.random() < epsilon:
                        action = self.rng.integers(0, config["action_size"])
                    else:
                        with torch.no_grad():
                            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
                            q_values = model(state_tensor)
                            action = q_values.argmax().item()

                    # Take action in environment
                    next_state, reward, done = environment.step(action)

                    # Store experience
                    replay_buffer.push(state, action, reward, next_state, done)

                    # Train on batch if enough samples
                    if len(replay_buffer) >= batch_size:
                        states, actions, rewards, next_states, dones = replay_buffer.sample(batch_size)

                        # Convert to tensors
                        states = torch.FloatTensor(states).to(self.device)
                        actions = torch.LongTensor(actions).to(self.device)
                        rewards = torch.FloatTensor(rewards).to(self.device)
                        next_states = torch.FloatTensor(next_states).to(self.device)
                        dones = torch.FloatTensor(dones).to(self.device)

                        # Compute Q values
                        current_q = model(states).gather(1, actions.unsqueeze(1)).squeeze(1)

                        # Compute target Q values
                        with torch.no_grad():
                            next_q = model(next_states).max(1)[0]
                            target_q = rewards + gamma * next_q * (1 - dones)

                        # Compute loss and update
                        loss = criterion(current_q, target_q)

                        optimizer.zero_grad()
                        loss.backward()
                        optimizer.step()

                    state = next_state
                    total_reward += reward
                    steps += 1

                episode_rewards.append(total_reward)

                # Decay epsilon
                epsilon = max(epsilon_min, epsilon * epsilon_decay)

                # Log progress every 10 episodes
                if (episode + 1) % 10 == 0:
                    avg_reward = np.mean(episode_rewards[-10:])
                    logger.info(f"{symbol} Episode {episode + 1}/{episodes}: Avg Reward = {avg_reward:.2f}")

            # Store training stats
            self._training_stats[symbol] = {
                "episodes": episodes,
                "final_epsilon": epsilon,
                "avg_reward": np.mean(episode_rewards[-10:]) if episode_rewards else 0,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            # Save model
            self._save_model(symbol, "dqn", model)

        except Exception as e:
            logger.exception(f"Error in DQN training for {symbol}: {e}")

    def _build_feature_vector(self, symbol: str, market_data: dict[str, Any] | None) -> list[float] | None:
        """
        Build 124-feature vector from market data.
        Returns None if insufficient data.
        """
        try:
            if not market_data:
                return None

            # Build features (simplified version - real implementation would fetch from feature service)
            features = []

            # Core price features (0-19): price, volume, returns
            features.extend(
                [
                    market_data.get("price", 0.0),
                    market_data.get("volume", 0.0),
                    market_data.get("return_1h", 0.0),
                    market_data.get("return_24h", 0.0),
                    market_data.get("sma_20", 0.0),
                    market_data.get("ema_12", 0.0),
                    market_data.get("ema_26", 0.0),
                    market_data.get("rsi", 50.0),
                    market_data.get("macd", 0.0),
                    market_data.get("macd_signal", 0.0),
                    market_data.get("bollinger_upper", 0.0),
                    market_data.get("bollinger_middle", 0.0),
                    market_data.get("bollinger_lower", 0.0),
                    market_data.get("atr", 0.0),
                    market_data.get("volatility", 0.0),
                    market_data.get("spread", 0.0),
                    market_data.get("bid_volume", 0.0),
                    market_data.get("ask_volume", 0.0),
                    market_data.get("trade_count", 0.0),
                    market_data.get("vwap", 0.0),
                ]
            )

            # Technical indicators (20-49): 30 more indicators
            for i in range(30):
                features.append(market_data.get(f"indicator_{i}", 0.0))

            # Sentiment features (50-79): social + news
            for i in range(30):
                features.append(market_data.get(f"sentiment_{i}", 0.0))

            # Cosmic/exotic signals (80-99): phase of moon, etc.
            for i in range(20):
                features.append(market_data.get(f"cosmic_{i}", 0.0))

            # Market microstructure (100-119): order book depth, etc.
            for i in range(20):
                features.append(market_data.get(f"microstructure_{i}", 0.0))

            # Meta features (120-123): time, day of week, etc.
            features.extend(
                [
                    market_data.get("hour_of_day", 12.0) / 24.0,  # Normalized
                    market_data.get("day_of_week", 3.0) / 7.0,  # Normalized
                    market_data.get("confidence", 0.5),
                    market_data.get("signal_strength", 0.5),
                ]
            )

            # Ensure exactly 124 features
            if len(features) < TOTAL_FEATURES:
                features.extend([0.0] * (TOTAL_FEATURES - len(features)))
            elif len(features) > TOTAL_FEATURES:
                features = features[:TOTAL_FEATURES]

        except Exception as e:
            logger.debug(f"Error building feature vector for {symbol}: {e}")
            return None
        else:
            return features

    def _save_model(self, symbol: str, algorithm: str, model: nn.Module):
        """Save trained model to disk"""
        try:
            from pathlib import Path

            model_dir = Path(self.model_dir) if isinstance(self.model_dir, str) else self.model_dir
            model_path = model_dir / f"{symbol}_{algorithm}_model.pt"
            torch.save(
                {
                    "model_state_dict": model.state_dict(),
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "stats": self._training_stats.get(symbol, {}),
                },
                model_path,
            )
            logger.info(f"Saved {algorithm} model for {symbol} to {model_path}")
        except Exception as e:
            logger.exception(f"Error saving model for {symbol}: {e}")

    def _load_model(self, symbol: str, algorithm: str, model: nn.Module) -> bool:
        """Load trained model from disk"""
        try:
            from pathlib import Path

            model_dir = Path(self.model_dir) if isinstance(self.model_dir, str) else self.model_dir
            model_path = model_dir / f"{symbol}_{algorithm}_model.pt"
            if not model_path.exists():
                logger.warning(f"No saved model found for {symbol} at {model_path}")
                return False

            checkpoint = torch.load(model_path, map_location=self.device)
            model.load_state_dict(checkpoint["model_state_dict"])
            model.eval()  # Set to evaluation mode
            logger.info(f"Loaded {algorithm} model for {symbol} from {model_path}")

            # Restore training stats
            if symbol not in self._training_stats:
                self._training_stats[symbol] = checkpoint.get("stats", {})

        except Exception as e:
            logger.exception(f"Error loading model for {symbol}: {e}")
            return False
        else:
            return True

    async def train_symbol_models(self, _symbol: str):
        """Placeholder to train all models for a symbol"""
        # Phase 4: Train all RL algorithms for this symbol
        return

    async def generate_model_strategy(self, _symbol: str, _algorithm_name: str, _model: Any, _market_data: Any):
        """Placeholder to generate a strategy from a model"""
        # Phase 2/3: Will generate position sizing and timing recommendations
        return

    # ========================
    # Phase 2: Position Sizing Recommendations
    # ========================

    async def recommend_position_multiplier(self, symbol: str, _kelly_size: float, confidence: float, market_state: dict[str, Any] | None = None) -> dict[str, Any]:
        """
        Phase 2: Recommend position size multiplier based on market conditions

        Args:
            symbol: Trading symbol (e.g., 'BTCUSDT')
            _kelly_size: Base Kelly Criterion position size
            confidence: AI signal confidence (0-1)
            market_state: Optional market conditions

        Returns:
            {
                "multiplier": float (0.5 - 2.0),
                "confidence": float (0-1),
                "model_version": str,
                "timestamp": str,
                "reasoning": str
            }
        """
        try:
            # Phase 4: Try model inference first, fall back to rules
            multiplier = 1.0
            rl_confidence = 0.5
            reasoning_parts = []
            model_used = False

            # Try model inference
            if "dqn" in self.models:
                try:
                    model = self.models["dqn"]
                    # Try to load symbol-specific model
                    if self._load_model(symbol, "dqn", model):
                        # Build feature vector from market_state
                        features = self._build_feature_vector(symbol, market_state)
                        if features is not None and len(features) == TOTAL_FEATURES:
                            with torch.no_grad():
                                state_tensor = torch.FloatTensor(features).unsqueeze(0).to(self.device)
                                q_values = model(state_tensor)
                                action = q_values.argmax().item()

                                # Map action to multiplier (0=reduce, 1=hold, 2=increase)
                                if action == 0:  # Reduce
                                    multiplier = 0.5 + (confidence * 0.3)  # 0.5-0.8x
                                    rl_confidence = 0.8
                                    reasoning_parts.append("Model: reduce position")
                                elif action == 1:  # Hold
                                    multiplier = 0.9 + (confidence * 0.2)  # 0.9-1.1x
                                    rl_confidence = 0.75
                                    reasoning_parts.append("Model: maintain position")
                                else:  # Increase
                                    multiplier = 1.2 + (confidence * 0.8)  # 1.2-2.0x
                                    rl_confidence = 0.85
                                    reasoning_parts.append("Model: increase position")

                                model_used = True
                except Exception as e:
                    logger.debug(f"Model inference failed for {symbol}: {e}")

            # Fallback to Phase 2 rule-based logic if model not available
            if not model_used:
                # Base multiplier starts at 1.0 (neutral)
                multiplier = 1.0
                rl_confidence = 0.5  # Medium confidence until trained
                reasoning_parts = []

            # Adjust based on AI confidence
            if confidence >= 0.7:
                # High confidence: increase position slightly
                multiplier = 1.2
                rl_confidence = 0.75
                reasoning_parts.append(f"High AI confidence ({confidence:.2f})")
            elif confidence >= 0.55:
                # Medium-high confidence: slight increase
                multiplier = 1.1
                rl_confidence = 0.65
                reasoning_parts.append(f"Medium-high confidence ({confidence:.2f})")
            elif confidence < 0.5:
                # Low confidence: reduce position
                multiplier = 0.8
                rl_confidence = 0.6
                reasoning_parts.append(f"Low confidence ({confidence:.2f})")

            # Market state adjustments (if provided)
            if market_state:
                volatility = market_state.get("volatility", 0)
                if volatility > 0.05:  # High volatility
                    multiplier *= 0.9  # Reduce size
                    reasoning_parts.append("High volatility reduction")

                trend_strength = market_state.get("trend_strength", 0)
                if trend_strength > 0.7:  # Strong trend
                    multiplier *= 1.1  # Increase size
                    reasoning_parts.append("Strong trend boost")

            # Bound multiplier to safe range
            multiplier = max(0.5, min(2.0, multiplier))

            reasoning = "; ".join(reasoning_parts) if reasoning_parts else "Neutral conditions"

            recommendation = {
                "multiplier": round(multiplier, 3),
                "confidence": round(rl_confidence, 3),
                "model_version": f"dqn-{symbol}-trained" if model_used else "v0.1.0-rule-based",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "reasoning": reasoning,
                "phase": "4-model" if model_used else "2-rule-based",
            }

            # Store recommendation in Redis for autobuy service to query
            if self.redis_client:
                try:
                    key = f"rl_recommendation:{symbol}:position"
                    # Use sync Redis operations (BaseAgent provides sync client)
                    for field, value in recommendation.items():
                        self.redis_client.hset(key, field, str(value))
                    self.redis_client.expire(key, 30)  # 30 second TTL
                    logger.debug(f"✅ RL position: {symbol} = {multiplier:.2f}x (conf: {rl_confidence:.2f})")
                except Exception as e:
                    logger.debug(f"Failed to store RL recommendation in Redis: {e}")

        except Exception as e:
            logger.exception(f"Error generating RL position recommendation for {symbol}: {e}")
            # Fallback: neutral multiplier
            return {
                "multiplier": 1.0,
                "confidence": 0.0,
                "model_version": "error",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "reasoning": f"Error: {e!s}",
                "phase": "2-error",
            }
        else:
            return recommendation

    async def generate_symbol_strategy(self, _symbol: str):
        """Placeholder to generate strategies for a symbol using all models"""
        # Phase 2/3: Will combine recommendations from all RL models
        return

    # ========================
    # Phase 3: Timing Optimization
    # ========================

    async def recommend_timing_signal(self, symbol: str, decision_pending: bool = False, last_decision_elapsed: float = 0.0, market_conditions: dict[str, Any] | None = None) -> dict[str, Any]:
        """
        Phase 3: Recommend optimal timing for trade execution

        Args:
            symbol: Trading symbol
            decision_pending: Whether there's a decision ready to execute
            last_decision_elapsed: Seconds since last decision
            market_conditions: Optional market microstructure data

        Returns:
            {
                "action": "execute" | "wait",
                "confidence": float (0-1),
                "wait_seconds": int (0-300),
                "reasoning": str,
                "timestamp": str
            }
        """
        try:
            # Phase 4: Try model inference first, fall back to rules
            action = "execute"
            confidence = 0.6
            wait_seconds = 0
            reasoning_parts = []
            model_used = False

            # Try model inference
            if "dqn" in self.models and decision_pending:
                try:
                    model = self.models["dqn"]
                    # Try to load symbol-specific model
                    if self._load_model(symbol, "dqn", model):
                        # Build feature vector from market_conditions
                        features = self._build_feature_vector(symbol, market_conditions)
                        if features is not None and len(features) == TOTAL_FEATURES:
                            with torch.no_grad():
                                state_tensor = torch.FloatTensor(features).unsqueeze(0).to(self.device)
                                q_values = model(state_tensor)
                                model_action = q_values.argmax().item()

                                # Map action to timing (0=execute, 1=wait_5s, 2=wait_30s)
                                if model_action == 0:
                                    action = "execute"
                                    wait_seconds = 0
                                    confidence = 0.85
                                    reasoning_parts.append("Model: optimal entry timing")
                                elif model_action == 1:
                                    action = "wait"
                                    wait_seconds = 5
                                    confidence = 0.8
                                    reasoning_parts.append("Model: short wait advised")
                                else:  # model_action == 2
                                    action = "wait"
                                    wait_seconds = 30
                                    confidence = 0.75
                                    reasoning_parts.append("Model: wait for better conditions")

                                model_used = True
                except Exception as e:
                    logger.debug(f"Model inference failed for {symbol}: {e}")

            # Fallback to Phase 3 rule-based logic if model not available
            if not model_used:
                action = "execute"
                confidence = 0.6
                wait_seconds = 0
                reasoning_parts = []

            # Don't recommend waiting if no decision pending
            if not decision_pending:
                return {
                    "action": "execute",
                    "confidence": 0.5,
                    "wait_seconds": 0,
                    "reasoning": "No decision pending",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

            # Check market conditions
            if market_conditions:
                volatility = market_conditions.get("volatility", 0)
                spread = market_conditions.get("spread", 0)
                volume = market_conditions.get("volume", 0)

                # High volatility: wait for calmer conditions
                if volatility > 0.05:
                    action = "wait"
                    wait_seconds = 30
                    confidence = 0.7
                    reasoning_parts.append(f"High volatility ({volatility:.3f}), wait for calm")

                # Wide spread: wait for better liquidity
                elif spread > 0.01:
                    action = "wait"
                    wait_seconds = 15
                    confidence = 0.65
                    reasoning_parts.append(f"Wide spread ({spread:.3f}), wait for tighter")

                # Low volume: wait for better liquidity
                elif volume < 100:
                    action = "wait"
                    wait_seconds = 20
                    confidence = 0.65
                    reasoning_parts.append(f"Low volume ({volume:.0f}), wait for activity")

                # Good conditions: execute now
                else:
                    action = "execute"
                    confidence = 0.75
                    reasoning_parts.append("Good market conditions")

            # If recently decided, don't rush another decision
            if last_decision_elapsed < 5.0:
                action = "wait"
                wait_seconds = max(5, int(5.0 - last_decision_elapsed))
                confidence = 0.8
                reasoning_parts.append(f"Recent decision ({last_decision_elapsed:.1f}s ago)")

            reasoning = "; ".join(reasoning_parts) if reasoning_parts else "Normal timing"

            recommendation = {
                "action": action,
                "confidence": round(confidence, 3),
                "wait_seconds": wait_seconds,
                "reasoning": reasoning,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "phase": "4-model" if model_used else "3-rule-based",
            }

            # Store in Redis for TradeEngine to query
            if self.redis_client:
                try:
                    key = f"rl_recommendation:{symbol}:timing"
                    for field, value in recommendation.items():
                        self.redis_client.hset(key, field, str(value))
                    self.redis_client.expire(key, 15)  # 15 second TTL (shorter for timing)
                    logger.debug(f"✅ RL timing: {symbol} = {action} (wait: {wait_seconds}s, conf: {confidence:.2f})")
                except Exception as e:
                    logger.debug(f"Failed to store RL timing in Redis: {e}")

        except Exception as e:
            logger.exception(f"Error generating RL timing recommendation for {symbol}: {e}")
            # Fallback: execute immediately
            return {
                "action": "execute",
                "confidence": 0.0,
                "wait_seconds": 0,
                "reasoning": f"Error: {e!s}",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "phase": "3-error",
            }
        else:
            return recommendation

    async def generate_all_strategies(self):
        """Placeholder to generate strategies for all symbols"""
        # Phase 2/3: Will generate recommendations for all trading symbols
        return

    async def train_models_if_needed(self):
        """Placeholder check to trigger model training"""
        # Phase 4: Will check if models need retraining based on new data
        return

    async def store_market_data(self, _symbol: str, _price: float, _volume: float, _timestamp: str):
        """Placeholder for storing market data"""
        # Phase 4: Will store data for training
        logger.debug(f"Storing market data for {_symbol}: price={_price}, volume={_volume}")

    async def handle_train_rl_model(self, message: dict[str, Any]):
        """Handle manual RL model training request"""
        try:
            symbol = message.get("symbol")
            algorithm_name = message.get("algorithm_name")

            logger.info(f"Manual RL model training requested for {symbol}")

            if symbol:
                if algorithm_name and algorithm_name in self.models:
                    # Train specific model
                    market_data = await self.get_symbol_market_data(symbol)
                    if market_data:
                        df = pd.DataFrame(market_data)
                        df["timestamp"] = pd.to_datetime(df["timestamp"])
                        df = df.sort_values("timestamp")

                        environment = TradingEnvironment(df)
                        await self.train_rl_model(
                            symbol,
                            algorithm_name,
                            self.models[algorithm_name],
                            environment,
                        )
                else:
                    # Train all models
                    await self.train_symbol_models(symbol)

            # Send response
            response = {
                "type": "rl_model_training_complete",
                "symbol": symbol,
                "algorithm_name": algorithm_name,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error handling RL model training request: {e}")
            await self.broadcast_error(f"RL model training error: {e}")

    async def handle_generate_strategy(self, message: dict[str, Any]):
        """Handle manual strategy generation request"""
        try:
            symbol = message.get("symbol")
            algorithm_name = message.get("algorithm_name")

            logger.info(f"Manual strategy generation requested for {symbol}")

            if symbol:
                market_data = await self.get_symbol_market_data(symbol)
                if market_data:
                    if algorithm_name and algorithm_name in self.models:
                        # Generate strategy with specific model
                        strategy = await self.generate_model_strategy(
                            symbol,
                            algorithm_name,
                            self.models[algorithm_name],
                            market_data,
                        )

                        response = {
                            "type": "strategy_generation_response",
                            "symbol": symbol,
                            "algorithm_name": algorithm_name,
                            "strategy": strategy,
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                        }
                    else:
                        # Generate strategies with all models
                        await self.generate_symbol_strategy(symbol)

                        response = {
                            "type": "strategy_generation_response",
                            "symbol": symbol,
                            "strategies": (self.state["strategies_generated"].get(symbol, {}).get("strategies", {})),
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                        }
                else:
                    response = {
                        "type": "strategy_generation_response",
                        "symbol": symbol,
                        "strategy": None,
                        "error": "No market data available",
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    }
            else:
                response = {
                    "type": "strategy_generation_response",
                    "symbol": symbol,
                    "strategy": None,
                    "error": "No symbol provided",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error handling strategy generation request: {e}")
            await self.broadcast_error(f"Strategy generation error: {e}")

    async def handle_get_rl_status(self, message: dict[str, Any]):
        """Handle RL status request"""
        try:
            symbol = message.get("symbol")

            logger.info(f"RL status requested for {symbol}")

            # Get RL status
            if symbol and symbol in self.state["training_history"]:
                status = self.state["training_history"][symbol]

                response = {
                    "type": "rl_status_response",
                    "symbol": symbol,
                    "status": status,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
            else:
                response = {
                    "type": "rl_status_response",
                    "symbol": symbol,
                    "status": None,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error handling RL status request: {e}")
            await self.broadcast_error(f"RL status error: {e}")

    async def update_rl_metrics(self):
        """Update RL metrics"""
        try:
            metrics = {
                "agent_id": self.agent_id,
                "symbols_count": len(self.trading_symbols),
                "models_count": len(self.models),
                "strategies_count": len(self.state["strategies_generated"]),
                "training_count": self.state["training_count"],
                "last_training": self.state["last_training"],
                "device": str(self.device),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            # Store metrics in Redis
            if self.redis_client is not None:
                try:
                    self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics), ex=300)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    # If redis client doesn't support .set signature with ex, try without expiry
                    try:
                        self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics))
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        logger.debug("Could not store metrics in redis_client")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error updating RL metrics: {e}")

    async def cleanup_cache(self):
        """Clean up old cache entries"""
        try:
            current_time = datetime.now(timezone.utc)

            # Clean up old training history entries
            for symbol in list(self.state["training_history"].keys()):
                if "data" in self.state["training_history"][symbol]:
                    data_points = self.state["training_history"][symbol]["data"]

                    # Keep only recent data points (last 48 hours)
                    cutoff_time = current_time - timedelta(hours=48)
                    recent_data = [point for point in data_points if datetime.fromisoformat(point["timestamp"]) > cutoff_time]

                    if recent_data:
                        self.state["training_history"][symbol]["data"] = recent_data
                    else:
                        del self.state["training_history"][symbol]

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error cleaning up cache: {e}")

    async def handle_market_data(self, message: dict[str, Any]):
        """Handle market data message - PHASE 2: Generate position recommendations"""
        try:
            market_data = message.get("market_data", {})
            logger.debug(f"RL Agent received market data for {len(market_data)} symbols")

            # Phase 2: Generate position size recommendations
            for symbol, data in market_data.items():
                if symbol in self.trading_symbols:
                    price = data.get("price", 0)
                    volume = data.get("volume", 0)
                    confidence = data.get("confidence", 0.5)  # AI signal confidence
                    timestamp = data.get("timestamp", datetime.now(timezone.utc).isoformat())

                    # Store for later use (Phase 4 - training)
                    await self.store_market_data(symbol, price, volume, timestamp)

                    # Phase 2: Generate position recommendation
                    kelly_size = data.get("kelly_size", 0.0)  # If available
                    market_state = {
                        "volatility": data.get("volatility", 0),
                        "trend_strength": data.get("trend_strength", 0),
                    }

                    # Generate and store recommendation in Redis
                    await self.recommend_position_multiplier(symbol=symbol, kelly_size=kelly_size, confidence=confidence, market_state=market_state)

            # Update metrics
            await self.update_rl_metrics()

            logger.debug("RL Agent processed market data and generated recommendations")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error handling market data in RL agent: {e}")
            # Don't propagate errors - should fail gracefully
