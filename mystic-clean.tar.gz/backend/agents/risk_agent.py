import asyncio
import contextlib
import json
import logging
import time
from datetime import datetime, timezone
from typing import Any

import numpy as np

from backend.agents.base_agent import BaseAgent
from backend.services.task_manager import task_manager

logger = logging.getLogger(__name__)

"""
Risk Agent
Handles risk management, position sizing, and portfolio risk monitoring
"""

# Add parent directory to path for imports


class RiskAgent(BaseAgent):
    """Risk Management Agent - Handles risk assessment and position sizing"""

    def __init__(self, agent_id: str = "risk_agent_001") -> None:
        super().__init__(agent_id, "risk")

        self.state.update(
            {
                "portfolio_risk": {},
                "position_limits": {},
                "risk_metrics": {},
                "alerts": [],
                "risk_level": "medium",
                "max_portfolio_risk": 0.02,
                "max_position_size": 0.1,
                "stop_loss_pct": 0.05,  # 5% stop loss
                "take_profit_pct": 0.15,  # 15% take profit
            },
        )

        # Register risk-specific handlers
        self.register_handler("assess_risk", self.handle_assess_risk)
        self.register_handler("calculate_position_size", self.handle_calculate_position_size)
        self.register_handler("portfolio_update", self.handle_portfolio_update)
        self.register_handler("trading_signal", self.handle_trading_signal)
        self.register_handler("market_data", self.handle_market_data)

        logger.info(f"Risk Agent {agent_id} initialized")

    async def initialize(self):
        """Initialize risk agent resources"""
        try:
            # Load risk configuration
            await self.load_risk_config()

            # Initialize portfolio monitoring
            await self.initialize_portfolio_monitoring()

            # Subscribe to market data
            await self.subscribe_to_market_data()

            logger.info(f"âœ” Risk Agent {self.agent_id} initialized successfully")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error initializing Risk Agent: {e}")
            # If BaseAgent has update_health_status
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                self.update_health_status("error")

    async def process_loop(self):
        """Main risk processing loop"""
        while getattr(self, "running", True):
            try:
                # Monitor portfolio risk
                await self.monitor_portfolio_risk()

                # Check for risk alerts
                await self.check_risk_alerts()

                # Update risk metrics
                await self.update_risk_metrics()

                # Clean up old alerts
                await self.cleanup_alerts()

                await asyncio.sleep(30)  # Check every 30 seconds

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception(f"Error in risk processing loop: {e}")
                await asyncio.sleep(60)

    async def _decode_redis(self, value: bytes | None) -> str | None:
        if value is None:
            return None
        if isinstance(value, bytes):
            try:
                return value.decode("utf-8")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                return value.decode("latin-1", errors="ignore")
        if isinstance(value, str):
            return value
        return str(value)

    async def load_risk_config(self):
        """Load risk configuration from Redis"""
        try:
            # Load risk configuration
            raw = self.redis_client.get("risk_config")
            risk_config = await self._decode_redis(raw)
            if risk_config:
                config = json.loads(risk_config)
                self.state.update(config)

            # Load position limits
            raw_limits = self.redis_client.get("position_limits")
            position_limits = await self._decode_redis(raw_limits)
            if position_limits:
                self.state["position_limits"] = json.loads(position_limits)

            logger.info("Risk configuration loaded")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error loading risk configuration: {e}")

    async def initialize_portfolio_monitoring(self):
        """Initialize portfolio monitoring"""
        try:
            # Get current portfolio
            raw_portfolio = self.redis_client.get("portfolio")
            portfolio_data = await self._decode_redis(raw_portfolio)
            if portfolio_data:
                portfolio = json.loads(portfolio_data)
                await self.analyze_portfolio_risk(portfolio)

            logger.info("Portfolio monitoring initialized")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error initializing portfolio monitoring: {e}")

    async def subscribe_to_market_data(self):
        """Subscribe to market data updates"""
        try:
            # Subscribe to market data channel
            pubsub = self.redis_client.pubsub()
            pubsub.subscribe("market_data")

            # Start market data listener
            task = await task_manager.create_task(self.listen_market_data(pubsub), name="risk_agent:listen_market_data")
            self._tasks.append(task)

            logger.info("Risk Agent subscribed to market data")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error subscribing to market data: {e}")

    async def listen_market_data(self, pubsub):
        """Listen for market data updates"""
        try:
            # pubsub.listen() is blocking; run in executor to avoid blocking event loop
            # loop = asyncio.get_event_loop()  # Commented out unused variable
            for message in pubsub.listen():
                if not getattr(self, "running", True):
                    break

                if message is None:
                    continue

                if message.get("type") == "message":
                    data = message.get("data")
                    # data may be bytes
                    if isinstance(data, (bytes, bytearray)):
                        try:
                            data = data.decode("utf-8")
                        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                            data = data.decode("latin-1", errors="ignore")
                    try:
                        market_data = json.loads(data)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        # If data already a dict
                        market_data = data if isinstance(data, dict) else {}
                    # schedule processing asynchronously
                    task = await task_manager.create_task(self.process_market_data(market_data), name="risk_agent:process_market_data")
                    self._tasks.append(task)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error in market data listener: {e}")
        finally:
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pubsub.close()

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process incoming market data for risk assessment"""
        try:
            # If market_data is a dict keyed by symbol, handle accordingly
            if "symbol" in market_data and "price" in market_data:
                # single symbol update
                symbol = market_data.get("symbol")
                price = market_data.get("price")
                volume = market_data.get("volume", 0)
                await self.update_symbol_risk(symbol, price, volume)
                await self.check_symbol_risk_alerts(symbol, {"price": price, "volume": volume})
            else:
                # assume dict of symbols
                for symbol, data in market_data.items():
                    price = data.get("price")
                    volume = data.get("volume", 0)
                    if price is None:
                        continue
                    await self.update_symbol_risk(symbol, price, volume)
                    await self.check_symbol_risk_alerts(symbol, {"price": price, "volume": volume})

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error processing market data: {e}")

    async def handle_assess_risk(self, message: dict[str, Any]):
        """Handle risk assessment request"""
        try:
            symbol = message.get("symbol")
            position_size = message.get("position_size", 0)
            current_price = message.get("current_price", 0)

            logger.info(f"Assessing risk for {symbol}")

            # Perform risk assessment
            risk_assessment = await self.assess_trade_risk(symbol, position_size, current_price)

            # Send response
            response = {
                "type": "risk_assessment",
                "symbol": symbol,
                "assessment": risk_assessment,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error assessing risk: {e}")
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                await self.broadcast_error(f"Risk assessment error: {e}")

    async def handle_calculate_position_size(self, message: dict[str, Any]):
        """Handle position size calculation request"""
        try:
            symbol = message.get("symbol")
            signal_strength = message.get("signal_strength", 0.5)
            available_capital = message.get("available_capital", 0)
            current_price = message.get("current_price", 0)

            logger.info(f"Calculating position size for {symbol}")

            # Calculate optimal position size
            position_size = await self.calculate_optimal_position_size(symbol, signal_strength, available_capital, current_price)

            # Send response
            response = {
                "type": "position_size_calculation",
                "symbol": symbol,
                "position_size": position_size,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error calculating position size: {e}")
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                await self.broadcast_error(f"Position size calculation error: {e}")

    async def handle_portfolio_update(self, message: dict[str, Any]):
        """Handle portfolio update"""
        try:
            portfolio = message.get("portfolio", {})

            # Analyze portfolio risk
            await self.analyze_portfolio_risk(portfolio)

            # Check for portfolio-level risk alerts
            await self.check_portfolio_risk_alerts(portfolio)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error handling portfolio update: {e}")

    async def handle_trading_signal(self, message: dict[str, Any]):
        """Handle trading signal for risk validation"""
        try:
            strategy_id = message.get("strategy_id")
            signal = message.get("signal", {})
            market_data = message.get("market_data", {})

            symbol = market_data.get("symbol")
            signal_type = signal.get("type")
            confidence = signal.get("confidence", 0)

            logger.info(f"Validating trading signal from {strategy_id} for {symbol}: {signal_type} (confidence={confidence})")

            # Basic validation: require symbol and price
            price = market_data.get("price")
            if not symbol or price is None:
                logger.warning("Trading signal missing symbol or price")
                return

            # Determine position size and risk
            position_size = await self.calculate_optimal_position_size(symbol, confidence, message.get("available_capital", 0), price)
            trade_risk = await self.assess_trade_risk(symbol, position_size, price)

            # Formulate response
            decision = {
                "type": "trading_signal_validation",
                "strategy_id": strategy_id,
                "symbol": symbol,
                "signal": signal,
                "price": price,
                "position_size": position_size,
                "risk_assessment": trade_risk,
                "recommendation": trade_risk.get("recommendation"),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, decision)
            else:
                await self.broadcast_message(decision)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error handling trading signal: {e}")

    async def assess_trade_risk(self, symbol: str, position_size: float, current_price: float) -> dict[str, Any]:
        """Assess risk for a proposed trade"""
        try:
            volatility = await self.get_symbol_volatility(symbol)
            dollar_risk = position_size * current_price * self.state.get("stop_loss_pct", 0.05)
            # Simple VaR approximation: volatility * position_value * 1.65 (~95% VaR for normal)
            position_value = position_size * current_price
            var_95 = volatility * position_value * 1.65

            portfolio_contribution = 0.0
            try:
                total_portfolio_value = sum([p.get("value", 0) for p in (self.state.get("portfolio", {}).get("positions", []) if isinstance(self.state.get("portfolio", {}), dict) else [])])
                if total_portfolio_value > 0:
                    portfolio_contribution = position_value / total_portfolio_value
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                portfolio_contribution = 0.0

            trade_risk = {
                "symbol": symbol,
                "position_size": position_size,
                "position_value": position_value,
                "dollar_risk": dollar_risk,
                "var_95": var_95,
                "portfolio_risk_contribution": portfolio_contribution,
            }

            # Risk score and recommendation
            score = self.calculate_trade_risk_score(trade_risk)
            trade_risk["risk_score"] = score
            trade_risk["recommendation"] = self.generate_risk_recommendation(trade_risk)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error in assess_trade_risk: {e}")
            return {
                "symbol": symbol,
                "position_size": position_size,
                "dollar_risk": 0,
                "var_95": 0,
                "portfolio_risk_contribution": 0,
                "risk_score": 50,
                "recommendation": "hold",
            }
        else:
            return trade_risk

    async def calculate_optimal_position_size(self, _symbol: str, signal_strength: float, available_capital: float, current_price: float) -> float:
        """Calculate an optimal position size given risk constraints"""
        try:
            if current_price <= 0 or available_capital <= 0:
                return 0.0

            max_portfolio_risk = self.state.get("max_portfolio_risk", 0.02)
            stop_loss = self.state.get("stop_loss_pct", 0.05)
            # Risk per trade in dollars
            risk_per_trade = max_portfolio_risk * available_capital * min(max(signal_strength, 0.0), 1.0)
            dollar_risk_per_unit = current_price * stop_loss
            if dollar_risk_per_unit <= 0:
                return 0.0
            raw_size = risk_per_trade / dollar_risk_per_unit

            # Cap by max position size fraction
            max_pos_frac = self.state.get("max_position_size", 0.1)
            max_units = (available_capital * max_pos_frac) / current_price if current_price > 0 else raw_size
            position_size = min(raw_size, max_units)

            # Ensure non-negative
            return max(0.0, float(position_size))

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error calculating optimal position size: {e}")
            return 0.0

    async def analyze_portfolio_risk(self, portfolio: dict[str, Any]):
        """Analyze portfolio risk and update state"""
        try:
            positions = portfolio.get("positions", []) if isinstance(portfolio, dict) else []

            total_value = 0.0
            exposures: dict[str, float] = {}
            for pos in positions:
                value = float(pos.get("value", 0) or 0)
                symbol = pos.get("symbol", "UNKNOWN")
                total_value += value
                exposures[symbol] = exposures.get(symbol, 0.0) + value

            concentration = {}
            for symbol, value in exposures.items():
                concentration[symbol] = value / total_value if total_value > 0 else 0.0

            # Basic portfolio risk metric
            portfolio_risk_metric = {
                "total_value": total_value,
                "concentration": concentration,
                "positions_count": len(positions),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            self.state["portfolio"] = portfolio
            self.state["portfolio_risk"] = portfolio_risk_metric

            # Check for high concentration
            for symbol, pct in concentration.items():
                if pct > 0.3:
                    await self.create_alert("high_concentration_risk", {"symbol": symbol, "concentration": pct})

            # Update risk level based on simple heuristics
            max_conc = max(concentration.values()) if concentration else 0.0
            if max_conc > 0.5:
                self.state["risk_level"] = "high"
            elif max_conc > 0.3:
                self.state["risk_level"] = "medium"
            else:
                self.state["risk_level"] = "low"

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error analyzing portfolio risk: {e}")

    async def check_risk_alerts(self):
        """Aggregate and evaluate current alerts to update agent risk status"""
        try:
            alerts = self.state.get("alerts", [])
            high_count = sum(1 for a in alerts if a.get("severity") == "high")
            if high_count > 5:
                self.state["risk_level"] = "high"
            elif high_count > 0:
                self.state["risk_level"] = "medium"
            else:
                # keep existing or default
                self.state.setdefault("risk_level", "low")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error checking risk alerts: {e}")

    async def check_symbol_risk_alerts(self, symbol: str, market_data: dict[str, Any]):
        """Check for symbol-level risk alerts"""
        try:
            price = market_data.get("price", 0)
            # volume = market_data.get("volume", 0)  # Commented out unused variable

            symbol_risk = self.state["risk_metrics"].get(symbol, {})
            last_price = symbol_risk.get("last_price", price)

            if last_price and last_price > 0:
                price_change = abs(price - last_price) / last_price
                if price_change > 0.1:  # 10% price gap
                    await self.create_alert(
                        "price_gap",
                        {
                            "symbol": symbol,
                            "price_change": price_change,
                            "current_price": price,
                            "last_price": last_price,
                        },
                    )

            # Update last price
            symbol_risk["last_price"] = price
            self.state["risk_metrics"][symbol] = symbol_risk

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error checking symbol risk alerts: {e}")

    async def check_portfolio_risk_alerts(self, portfolio: dict[str, Any]):
        """Check for portfolio-level risk alerts"""
        try:
            positions = portfolio.get("positions", [])

            # Check for large losses
            for position in positions:
                symbol = position.get("symbol")
                unrealized_pnl = position.get("unrealized_pnl", 0)
                value = position.get("value", 0)

                if value and value > 0 and unrealized_pnl < -value * 0.1:  # 10% loss
                    await self.create_alert(
                        "large_loss",
                        {
                            "symbol": symbol,
                            "unrealized_pnl": unrealized_pnl,
                            "value": value,
                            "loss_pct": unrealized_pnl / value if value else 0,
                        },
                    )

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error checking portfolio risk alerts: {e}")

    async def create_alert(self, alert_type: str, data: dict[str, Any]):
        """Create a risk alert"""
        try:
            alert = {
                "id": f"alert_{int(time.time())}",
                "type": alert_type,
                "data": data,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "severity": self.get_alert_severity(alert_type),
                "acknowledged": False,
            }

            # Add to alerts list
            self.state.setdefault("alerts", []).append(alert)

            # Broadcast alert
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                await self.broadcast_message({"type": "risk_alert", "alert": alert})

            # Store in Redis
            try:
                self.redis_client.lpush("risk_alerts", json.dumps(alert))
                self.redis_client.ltrim("risk_alerts", 0, 99)  # Keep last 100 alerts
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pass

            logger.info(f"Risk alert created: {alert_type}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error creating alert: {e}")

    def get_alert_severity(self, alert_type: str) -> str:
        """Get alert severity level"""
        severity_map = {
            "high_portfolio_risk": "high",
            "high_concentration_risk": "high",
            "high_var_risk": "high",
            "volatility_spike": "medium",
            "price_gap": "medium",
            "large_loss": "high",
        }

        return severity_map.get(alert_type, "low")

    async def update_symbol_risk(self, symbol: str, price: float, _volume: float):
        """Update risk metrics for a symbol"""
        try:
            symbol_risk = self.state["risk_metrics"].get(symbol, {})

            # Update price history
            price_history = symbol_risk.get("price_history", [])
            price_history.append({"price": price, "timestamp": datetime.now(timezone.utc).isoformat()})

            # Keep last 100 prices
            if len(price_history) > 100:
                price_history = price_history[-100:]

            # Calculate volatility
            if len(price_history) > 1:
                prices = [p["price"] for p in price_history if p.get("price") is not None]
                if len(prices) > 1:
                    # numpy expects float array
                    try:
                        returns = np.diff(np.log(np.array(prices, dtype=float)))
                        volatility = float(np.std(returns) * np.sqrt(252))  # Annualized
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        volatility = symbol_risk.get("volatility", 0.2)

                    symbol_risk.update(
                        {
                            "volatility": volatility,
                            "historical_volatility": symbol_risk.get("volatility", volatility),
                            "price_history": price_history,
                            "last_update": datetime.now(timezone.utc).isoformat(),
                        },
                    )
                else:
                    symbol_risk.update(
                        {
                            "volatility": symbol_risk.get("volatility", 0.2),
                            "price_history": price_history,
                            "last_update": datetime.now(timezone.utc).isoformat(),
                        }
                    )
            else:
                symbol_risk.update(
                    {
                        "price_history": price_history,
                        "last_update": datetime.now(timezone.utc).isoformat(),
                    }
                )

            # Determine risk level
            if symbol_risk.get("volatility", 0) > 0.5:
                symbol_risk["risk_level"] = "high"
            elif symbol_risk.get("volatility", 0) > 0.3:
                symbol_risk["risk_level"] = "medium"
            else:
                symbol_risk["risk_level"] = "low"

            # Update state
            self.state["risk_metrics"][symbol] = symbol_risk

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error updating symbol risk: {e}")

    async def get_symbol_volatility(self, symbol: str) -> float:
        """Get volatility for a symbol"""
        try:
            symbol_risk = self.state["risk_metrics"].get(symbol, {})
            return float(symbol_risk.get("volatility", 0.2))  # Default 20% volatility
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error getting symbol volatility: {e}")
            return 0.2

    def calculate_trade_risk_score(self, trade_risk: dict[str, Any]) -> float:
        """Calculate risk score for a trade (0-100, higher is riskier)"""
        try:
            score = 0.0

            # Portfolio risk contribution (40% weight)
            portfolio_contribution = float(trade_risk.get("portfolio_risk_contribution", 0) or 0)
            score += portfolio_contribution * 40

            # VaR contribution (30% weight)
            var = float(trade_risk.get("var_95", 0) or 0)
            dollar_risk = float(trade_risk.get("dollar_risk", 1) or 1)
            var_contribution = var / dollar_risk if dollar_risk != 0 else 0.0
            score += var_contribution * 30

            # Position size (30% weight)
            position_size = float(trade_risk.get("position_size", 0) or 0)
            max_size = float(self.state.get("max_position_size", 0.1) or 0.1)
            size_ratio = min(position_size / max_size, 1.0) if max_size > 0 else 0.0
            score += size_ratio * 30

            return min(100.0, float(score))

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error calculating trade risk score: {e}")
            return 50.0

    def generate_risk_recommendation(self, trade_risk: dict[str, Any]) -> str:
        """Generate risk recommendation for a trade"""
        try:
            risk_score = float(trade_risk.get("risk_score", 50) or 50)

            if risk_score < 30:
                result = "proceed"
            elif risk_score < 60:
                result = "proceed_with_caution"
            elif risk_score < 80:
                result = "reduce_size"
            else:
                result = "avoid"
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error generating risk recommendation: {e}")
            return "hold"
        else:
            return result

    async def update_risk_metrics(self):
        """Update risk metrics"""
        try:
            metrics = {
                "agent_id": self.agent_id,
                "portfolio_risk": self.state.get("portfolio_risk", {}),
                "alerts_count": len(self.state.get("alerts", [])),
                "risk_level": self.state.get("risk_level", "medium"),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            # Store metrics in Redis (setex not assumed; use set with ex if available)
            try:
                self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics), ex=300)
            except TypeError:
                # older redis-py variations
                self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics))
                with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    self.redis_client.expire(f"agent_metrics:{self.agent_id}", 300)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error updating risk metrics: {e}")

    async def cleanup_alerts(self):
        """Clean up old alerts"""
        try:
            current_time = datetime.now(timezone.utc)
            alerts = self.state.get("alerts", [])

            # Remove alerts older than 24 hours
            cleaned = []
            for alert in alerts:
                try:
                    alert_time = datetime.fromisoformat(alert["timestamp"])
                    if (current_time - alert_time).days < 1:
                        cleaned.append(alert)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    # keep alert if timestamp invalid
                    cleaned.append(alert)

            self.state["alerts"] = cleaned

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error cleaning up alerts: {e}")

    async def handle_market_data(self, message: dict[str, Any]):
        """Handle market data message"""
        try:
            market_data = message.get("market_data", {})
            if isinstance(market_data, dict):
                logger.info(f"Risk Agent received market data for {len(market_data)} symbols")
            else:
                logger.info("Risk Agent received market data")

            # Process market data
            await self.process_market_data(market_data)

            # Update risk metrics for each symbol
            if isinstance(market_data, dict):
                for symbol, data in market_data.items():
                    if not isinstance(data, dict):
                        continue
                    price = data.get("price", 0)
                    volume = data.get("volume", 0)
                    if price > 0:
                        await self.update_symbol_risk(symbol, price, volume)

            # Check for risk alerts
            await self.check_risk_alerts()

            # Update risk metrics
            await self.update_risk_metrics()

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error handling market data: {e}")
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                await self.broadcast_error(f"Market data handling error: {e}")

    # Placeholder for monitor_portfolio_risk in case BaseAgent doesn't implement it
    async def monitor_portfolio_risk(self):
        """Periodic portfolio risk monitoring task"""
        try:
            portfolio = self.state.get("portfolio", {})
            if portfolio:
                await self.analyze_portfolio_risk(portfolio)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error in monitor_portfolio_risk: {e}")
