import asyncio
import contextlib
import json
import logging
import os
import re
from datetime import datetime, timedelta, timezone
from typing import Any

import numpy as np
from textblob import TextBlob

from backend.agents.base_agent import BaseAgent
from backend.config.trading_universe import TOP10_COINS
from backend.services.task_manager import task_manager

logger = logging.getLogger(__name__)

"""
Social Media Agent
Handles social media sentiment analysis and monitoring
"""

# Add parent directory to path for imports


class SocialMediaAgent(BaseAgent):
    """Social Media Agent - Monitors social media sentiment"""

    def __init__(self, agent_id: str = "social_media_agent_001") -> None:
        super().__init__(agent_id, "social_media")

        # Ensure symbol_sentiment exists as it's used in multiple places
        self.state.update(
            {
                "platforms": [],
                "sentiment_cache": {},
                "trending_topics": {},
                "influencer_sentiment": {},
                "last_analysis": None,
                "analysis_count": 0,
                "symbol_sentiment": {},  # per-symbol sentiment history
                "symbol_prices": {},  # contextual market prices
            },
        )

        # Social media platforms configuration
        self.platforms = [
            {
                "name": "Twitter",
                "type": "twitter",
                "keywords": [
                    "#bitcoin",
                    "#crypto",
                    "#btc",
                    "#eth",
                    "#trading",
                ],
                "api_endpoint": ("https://api.twitter.com/2/tweets/search/recent"),
                "enabled": False,  # Requires API keys
            },
            {
                "name": "Reddit",
                "type": "reddit",
                "subreddits": [
                    "cryptocurrency",
                    "bitcoin",
                    "ethereum",
                    "CryptoMarkets",
                ],
                "keywords": ["bitcoin", "crypto", "btc", "eth", "trading"],
                "enabled": True,
            },
            {
                "name": "Telegram",
                "type": "telegram",
                "channels": ["@binance", "@cryptocom"],
                "keywords": ["bitcoin", "crypto", "btc", "eth", "trading"],
                "enabled": False,  # Requires bot token
            },
        ]

        # Trading symbols to monitor - Import from single source
        self.trading_symbols = TOP10_COINS.copy()

        # Influencer accounts to monitor
        self.influencers = [
            "elonmusk",
            "cz_binance",
            "VitalikButerin",
            "SBF_FTX",
            "michael_saylor",
            "jack",
            "chamath",
        ]

        # Register social media-specific handlers
        self.register_handler("analyze_social", self.handle_analyze_social)
        self.register_handler("get_sentiment", self.handle_get_sentiment)
        self.register_handler("monitor_influencer", self.handle_monitor_influencer)
        self.register_handler("market_data", self.handle_market_data)

        logger.info(f"ðŸ“± Social Media Agent {agent_id} initialized")

    async def initialize(self):
        """Initialize social media agent resources"""
        try:
            # Load social media configuration
            await self.load_social_config()

            # Initialize sentiment analysis models
            await self.initialize_sentiment_models()

            # Start social media monitoring
            await self.start_social_monitoring()

            logger.info(f"âœ“ Social Media Agent {self.agent_id} initialized successfully")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error initializing Social Media Agent: {e}")
            self.update_health_status("error")

    async def process_loop(self):
        """Main social media processing loop"""
        while self.running:
            try:
                # Fetch and analyze social media posts
                await self.fetch_and_analyze_social()

                # Update trending topics
                await self.update_trending_topics()

                # Monitor influencers
                await self.monitor_influencers()

                # Update sentiment metrics
                await self.update_sentiment_metrics()

                # Clean up old cache entries
                await self.cleanup_cache()

                # Use configurable intervals from .env (Twitter=10min, Reddit=3min, etc.)
                # Default to 180 seconds if not set
                interval = int(os.getenv("REDDIT_FETCH_INTERVAL_SEC", "180"))
                await asyncio.sleep(interval)

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception(f"âŒ Error in social media processing loop: {e}")
                await asyncio.sleep(300)

    async def load_social_config(self):
        """Load social media configuration from Redis"""
        try:
            # Load platforms configuration
            platforms_data = self.redis_client.get("social_platforms")
            if platforms_data:
                self.platforms = json.loads(platforms_data)

            # Load trading symbols
            symbols_data = self.redis_client.get("trading_symbols")
            if symbols_data:
                self.trading_symbols = json.loads(symbols_data)

            # Load influencers
            influencers_data = self.redis_client.get("social_influencers")
            if influencers_data:
                self.influencers = json.loads(influencers_data)

            logger.info(f"ðŸ” Social media configuration loaded: {len(self.platforms)} platforms, {len(self.trading_symbols)} symbols")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error loading social media configuration: {e}")

    async def initialize_sentiment_models(self):
        """Initialize sentiment analysis models"""
        try:
            # Initialize TextBlob for sentiment analysis
            # In production, you might use more sophisticated models like:
            # - BERT for social media sentiment
            # - RoBERTa for Twitter sentiment
            # - Custom models trained on crypto social data

            # For now, using TextBlob as a baseline
            test_text = "Bitcoin is going to the moon! ðŸš€"
            TextBlob(test_text)

            logger.info("Social sentiment models initialized (TextBlob)")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error initializing sentiment models: {e}")

    async def start_social_monitoring(self):
        """Start social media monitoring"""
        try:
            # Subscribe to market data for context
            pubsub = self.redis_client.pubsub()
            pubsub.subscribe("market_data")

            # Start market data listener
            task = await task_manager.create_task(self.listen_market_data(pubsub), name="social_media_agent:listen_market_data")
            self._tasks.append(task)

            logger.info("ðŸ“¡ Social media monitoring started")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error starting social media monitoring: {e}")

    async def listen_market_data(self, pubsub):
        """Listen for market data updates"""
        try:
            while self.running:
                # FIXED: Use async-friendly polling instead of blocking listen()
                # This was causing the orchestrator to freeze on startup
                message = await asyncio.to_thread(
                    pubsub.get_message,
                    timeout=1.0,  # Non-blocking 1-second poll
                )

                if message and message["type"] == "message":
                    try:
                        # message["data"] may be bytes
                        data = message["data"]
                        if isinstance(data, bytes):
                            data = data.decode("utf-8")
                        market_data = json.loads(data)
                        await self.process_market_data(market_data)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as inner_e:
                        logger.exception(f"âŒ Error parsing market data message: {inner_e}")

                # Yield to event loop
                await asyncio.sleep(0.1)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error in market data listener: {e}")
        finally:
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pubsub.close()

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process market data for social media context"""
        try:
            symbol = market_data.get("symbol")
            price = market_data.get("price")

            # Update symbol context for social sentiment correlation
            if symbol and price is not None:
                await self.update_symbol_context(symbol, price)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error processing market data: {e}")

    async def fetch_and_analyze_social(self):
        """Fetch and analyze social media posts"""
        try:
            logger.info(f"ðŸ“± Fetching social media posts from {len(self.platforms)} platforms...")

            all_posts = []

            # Fetch posts from each platform
            for platform in self.platforms:
                if platform.get("enabled", False):
                    try:
                        posts = await self.fetch_posts_from_platform(platform)
                        if posts:
                            all_posts.extend(posts)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                        logger.exception(f"âŒ Error fetching from {platform.get('name', 'unknown')}: {e}")

            # Analyze sentiment for all posts
            if all_posts:
                await self.analyze_posts_sentiment(all_posts)

                # Update analysis count
                self.state["analysis_count"] += 1
                self.state["last_analysis"] = datetime.now(timezone.utc).isoformat()

            logger.info(f"âœ“ Analyzed {len(all_posts)} social media posts")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error fetching and analyzing social media: {e}")

    async def fetch_posts_from_platform(self, platform_config: dict[str, Any]) -> list[dict[str, Any]]:
        """
        Fetch posts from a platform.
        This is a simplified placeholder; real implementation would call platform APIs.
        """
        try:
            # Simulate network delay
            await asyncio.sleep(0.1)

            platform_name = platform_config.get("name", "unknown")
            keywords = platform_config.get("keywords", [])
            posts: list[dict[str, Any]] = []

            # Create a few mock posts based on keywords and trading symbols
            timestamp = datetime.now(timezone.utc).isoformat()
            for i, kw in enumerate(keywords[:5]):
                text = f"{kw} discussion about {self.trading_symbols[i % len(self.trading_symbols)]}"
                author = f"user_{i}"
                post_id = f"{platform_name.lower()}_{int(datetime.now(timezone.utc).timestamp())}_{i}"
                # Detect symbols mentioned
                symbols = [s for s in self.trading_symbols if re.search(rf"\b{s}\b", text, re.IGNORECASE)]
                posts.append(
                    {
                        "id": post_id,
                        "platform": platform_config.get("type", platform_name),
                        "platform_name": platform_name,
                        "text": text,
                        "author": author,
                        "timestamp": timestamp,
                        "symbols": symbols,
                    }
                )

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error in fetch_posts_from_platform: {e}")
            return []

    async def analyze_posts_sentiment(self, posts: list[dict[str, Any]]):
        """Analyze sentiment for a list of posts and store results"""
        try:
            for post in posts:
                text = post.get("text", "")
                if not text:
                    continue

                tb = TextBlob(text)
                polarity = float(tb.sentiment.polarity)
                subjectivity = float(tb.sentiment.subjectivity)
                # Confidence heuristic: higher subjectivity -> lower objective confidence
                confidence = max(0.0, min(1.0, 1.0 - subjectivity))

                sentiment = {"polarity": polarity, "subjectivity": subjectivity, "confidence": confidence}

                post_entry = {
                    "id": post.get("id"),
                    "platform": post.get("platform"),
                    "platform_name": post.get("platform_name"),
                    "author": post.get("author"),
                    "text": text,
                    "timestamp": post.get("timestamp", datetime.now(timezone.utc).isoformat()),
                    "sentiment": sentiment,
                    "symbols": post.get("symbols", []),
                }

                # Cache sentiment by post id
                post_id = post_entry["id"]
                if post_id:
                    self.state["sentiment_cache"][post_id] = {
                        "timestamp": post_entry["timestamp"],
                        "sentiment": sentiment,
                        "platform": post_entry["platform"],
                        "author": post_entry["author"],
                        "text": text,
                        "symbols": post_entry["symbols"],
                    }

                # Save per-symbol sentiment history
                for sym in post_entry["symbols"]:
                    if sym not in self.state["symbol_sentiment"]:
                        self.state["symbol_sentiment"][sym] = []
                    self.state["symbol_sentiment"][sym].append(
                        {
                            "timestamp": post_entry["timestamp"],
                            "platform": post_entry["platform"],
                            "author": post_entry["author"],
                            "text": text,
                            "sentiment": sentiment,
                        }
                    )

                # Update influencer sentiment if applicable
                author = post_entry.get("author")
                if author in self.influencers:
                    if author not in self.state["influencer_sentiment"]:
                        self.state["influencer_sentiment"][author] = []
                    self.state["influencer_sentiment"][author].append(
                        {
                            "timestamp": post_entry["timestamp"],
                            "platform": post_entry["platform"],
                            "sentiment": sentiment,
                            "text": text,
                        }
                    )

            logger.debug(f"Analyzed {len(posts)} posts and updated sentiment cache and symbol histories")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error analyzing posts sentiment: {e}")

    async def handle_analyze_social(self, message: dict[str, Any]):
        """Handle incoming request to analyze social media for a platform or overall"""
        try:
            platform = message.get("platform", "all")
            logger.info(f"ðŸ”Ž Received analyze_social request for platform={platform}")

            posts_analyzed = 0

            if platform == "all":
                for platform_config in self.platforms:
                    if platform_config.get("enabled", False):
                        posts = await self.fetch_posts_from_platform(platform_config)
                        if posts:
                            await self.analyze_posts_sentiment(posts)
                            posts_analyzed += len(posts)
            else:
                # find matching platform config
                matched = None
                for cfg in self.platforms:
                    if cfg.get("type") == platform or cfg.get("name") == platform:
                        matched = cfg
                        break
                if matched:
                    posts = await self.fetch_posts_from_platform(matched)
                    if posts:
                        await self.analyze_posts_sentiment(posts)
                        posts_analyzed = len(posts)

            response = {
                "type": "social_analysis_complete",
                "platform": platform,
                "posts_analyzed": posts_analyzed,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error handling social media analysis request: {e}")
            await self.broadcast_error(f"Social media analysis error: {e}")

    async def handle_market_data(self, message: dict[str, Any]):
        """Handler for market data messages directed to this agent"""
        try:
            # Expect message to contain symbol and price
            symbol = message.get("symbol")
            price = message.get("price")
            if symbol and price is not None:
                await self.update_symbol_context(symbol, price)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error in handle_market_data: {e}")
            await self.broadcast_error(f"Market data handler error: {e}")

    async def handle_get_sentiment(self, message: dict[str, Any]):
        """Handle sentiment request"""
        try:
            symbol = message.get("symbol")
            platform = message.get("platform", "all")
            timeframe = message.get("timeframe", "1h")

            logger.info(f"ðŸ”Ž Social sentiment request for {symbol} on {platform} ({timeframe})")

            # Get sentiment for symbol
            sentiment_data = await self.get_symbol_sentiment(symbol, platform, timeframe)

            # Send response
            response = {
                "type": "social_sentiment_response",
                "symbol": symbol,
                "platform": platform,
                "timeframe": timeframe,
                "sentiment": sentiment_data,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error handling sentiment request: {e}")
            await self.broadcast_error(f"Sentiment request error: {e}")

    async def handle_monitor_influencer(self, message: dict[str, Any]):
        """Handle influencer monitoring request"""
        try:
            influencer = message.get("influencer")

            logger.info(f"Monitoring influencer: {influencer}")

            # Add influencer to monitoring list
            if influencer and influencer not in self.influencers:
                self.influencers.append(influencer)

                # Store in Redis
                with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    # Redis may be unavailable; continue regardless
                    self.redis_client.set("social_influencers", json.dumps(self.influencers), ex=3600)

            # Send confirmation
            response = {
                "type": "influencer_monitoring_started",
                "influencer": influencer,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error monitoring influencer: {e}")
            await self.broadcast_error(f"Influencer monitoring error: {e}")

    async def get_symbol_sentiment(self, symbol: str, platform: str = "all", timeframe: str = "1h") -> dict[str, Any]:
        """Get sentiment data for a symbol"""
        try:
            if not symbol:
                return {
                    "average_polarity": 0,
                    "sentiment_category": "neutral",
                    "confidence": 0,
                    "post_count": 0,
                    "platform_breakdown": {},
                }

            symbol_sentiments = self.state["symbol_sentiment"].get(symbol, [])

            if not symbol_sentiments:
                return {
                    "average_polarity": 0,
                    "sentiment_category": "neutral",
                    "confidence": 0,
                    "post_count": 0,
                    "platform_breakdown": {},
                }

            # Filter by timeframe
            cutoff_time = datetime.now(timezone.utc)
            if timeframe == "30m":
                cutoff_time -= timedelta(minutes=30)
            elif timeframe == "1h":
                cutoff_time -= timedelta(hours=1)
            elif timeframe == "6h":
                cutoff_time -= timedelta(hours=6)
            elif timeframe == "24h":
                cutoff_time -= timedelta(hours=24)
            else:
                cutoff_time -= timedelta(hours=1)  # Default to 1h

            recent_sentiments = [s for s in symbol_sentiments if datetime.fromisoformat(s["timestamp"]) > cutoff_time]

            if not recent_sentiments:
                return {
                    "average_polarity": 0,
                    "sentiment_category": "neutral",
                    "confidence": 0,
                    "post_count": 0,
                    "platform_breakdown": {},
                }

            # Filter by platform if specified
            if platform != "all":
                recent_sentiments = [s for s in recent_sentiments if s.get("platform") == platform]

            if not recent_sentiments:
                return {
                    "average_polarity": 0,
                    "sentiment_category": "neutral",
                    "confidence": 0,
                    "post_count": 0,
                    "platform_breakdown": {},
                }

            # Calculate average sentiment
            polarities = [s["sentiment"]["polarity"] for s in recent_sentiments]
            confidences = [s["sentiment"]["confidence"] for s in recent_sentiments]

            avg_polarity = float(np.mean(polarities)) if polarities else 0.0
            raw_conf = float(np.mean(confidences)) if confidences else 0.0
            from backend.services.confidence_normalizer import ConfidenceNormalizer

            avg_confidence = ConfidenceNormalizer.normalize(raw_conf)

            # Determine sentiment category
            if avg_polarity > 0.1:
                sentiment_category = "positive"
            elif avg_polarity < -0.1:
                sentiment_category = "negative"
            else:
                sentiment_category = "neutral"

            # Calculate platform breakdown
            platform_breakdown: dict[str, dict[str, Any]] = {}
            for sentiment in recent_sentiments:
                p = sentiment.get("platform", "unknown")
                if p not in platform_breakdown:
                    platform_breakdown[p] = {
                        "count": 0,
                        "avg_polarity": 0,
                        "polarities": [],
                    }

                platform_breakdown[p]["count"] += 1
                platform_breakdown[p]["polarities"].append(sentiment["sentiment"]["polarity"])

            # Calculate averages for each platform
            for platform_data in platform_breakdown.values():
                if platform_data["polarities"]:
                    platform_data["avg_polarity"] = float(np.mean(platform_data["polarities"]))
                else:
                    platform_data["avg_polarity"] = 0.0
                del platform_data["polarities"]  # Remove raw data

            return {
                "average_polarity": avg_polarity,
                "sentiment_category": sentiment_category,
                "confidence": avg_confidence,
                "post_count": len(recent_sentiments),
                "platform_breakdown": platform_breakdown,
                "recent_posts": recent_sentiments[-10:],  # Last 10 posts
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error getting symbol sentiment: {e}")
            return {
                "average_polarity": 0,
                "sentiment_category": "neutral",
                "confidence": 0,
                "post_count": 0,
                "platform_breakdown": {},
            }

    async def update_trending_topics(self):
        """Update trending topics based on recent sentiment cache"""
        try:
            # Simple trending algorithm: count hashtags and keywords in recent cached posts
            counts: dict[str, int] = {}
            cutoff = datetime.now(timezone.utc) - timedelta(hours=2)
            for entry in list(self.state["sentiment_cache"].values()):
                try:
                    if datetime.fromisoformat(entry["timestamp"]) < cutoff:
                        continue
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    continue

                text = entry.get("text", "")
                # Extract hashtags
                tags = re.findall(r"#\w+", text)
                words = re.findall(r"\b[a-zA-Z]{3,}\b", text)
                for t in tags + words[:5]:
                    key = t.lower()
                    counts[key] = counts.get(key, 0) + 1

            # Top 10 topics
            sorted_topics = sorted(counts.items(), key=lambda x: x[1], reverse=True)[:10]
            self.state["trending_topics"] = dict(sorted_topics)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error updating trending topics: {e}")

    async def monitor_influencers(self):
        """Aggregate influencer sentiment"""
        try:
            for influencer in self.influencers:
                records = self.state["influencer_sentiment"].get(influencer, [])
                if not records:
                    continue
                # Keep only last 50 entries
                if len(records) > 50:
                    self.state["influencer_sentiment"][influencer] = records[-50:]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error monitoring influencers: {e}")

    async def update_symbol_context(self, symbol: str, price: float):
        """Update internal context for a symbol (e.g., latest price)"""
        try:
            self.state["symbol_prices"][symbol] = {"price": price, "timestamp": datetime.now(timezone.utc).isoformat()}
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error updating symbol context: {e}")

    async def update_sentiment_metrics(self):
        """Update sentiment metrics"""
        try:
            metrics = {
                "agent_id": self.agent_id,
                "platforms_count": len(self.platforms),
                "symbols_count": len(self.trading_symbols),
                "influencers_count": len(self.influencers),
                "cache_size": len(self.state["sentiment_cache"]),
                "analysis_count": self.state["analysis_count"],
                "last_analysis": self.state["last_analysis"],
                "trending_topics": self.state["trending_topics"],
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            # Store metrics in Redis
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # If Redis not available, skip persisting metrics
                self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics), ex=300)

                # NEW: Publish symbol-specific sentiment for ensemble predictor
                for symbol, sentiment_list in self.state["symbol_sentiment"].items():
                    if sentiment_list and len(sentiment_list) > 0:
                        # Calculate aggregated sentiment from recent posts (last 10)
                        recent = sentiment_list[-10:]

                        if recent:
                            avg_polarity = sum(s["sentiment"]["polarity"] for s in recent) / len(recent)
                            raw_avg = sum(s["sentiment"]["confidence"] for s in recent) / len(recent)
                            from backend.services.confidence_normalizer import ConfidenceNormalizer

                            avg_confidence = ConfidenceNormalizer.normalize(float(raw_avg))
                            volume = len(sentiment_list)  # Total mentions

                            # Publish to Redis for ensemble to read
                            key = f"social_sentiment:{symbol}"
                            self.redis_client.set(
                                key,
                                json.dumps(
                                    {
                                        "score": round(avg_polarity, 4),  # -1 to +1
                                        "confidence": round(avg_confidence, 4),  # 0 to 1 canonical
                                        "volume": volume,  # Number of mentions
                                        "timestamp": datetime.now(timezone.utc).isoformat(),
                                    }
                                ),
                                ex=300,  # 5 minute expiry
                            )
                            logger.debug(f"Published social sentiment for {symbol}: polarity={avg_polarity:.3f}, conf={avg_confidence:.3f}, vol={volume}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error updating sentiment metrics: {e}")

    async def cleanup_cache(self):
        """Clean up old cache entries"""
        try:
            current_time = datetime.now(timezone.utc)
            cache_keys = list(self.state["sentiment_cache"].keys())

            for key in cache_keys:
                entry = self.state["sentiment_cache"].get(key)
                if not entry:
                    continue
                try:
                    entry_time = datetime.fromisoformat(entry["timestamp"])
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    # If timestamp is malformed, just remove the entry
                    del self.state["sentiment_cache"][key]
                    continue

                # Remove entries older than 2 hours
                if (current_time - entry_time) > timedelta(hours=2):
                    del self.state["sentiment_cache"][key]

            # Clean up symbol sentiment (keep last 200 entries per symbol)
            for symbol in list(self.state["symbol_sentiment"].keys()):
                sentiments = self.state["symbol_sentiment"].get(symbol, [])
                if len(sentiments) > 200:
                    self.state["symbol_sentiment"][symbol] = sentiments[-200:]

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error cleaning up cache: {e}")
