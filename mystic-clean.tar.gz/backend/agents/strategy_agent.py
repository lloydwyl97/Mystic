"""
Strategy Agent
Handles AI strategy generation, analysis, and optimization
"""

import asyncio
import contextlib
import json
import logging
from datetime import datetime, timezone
from typing import Any

from ai_auto_retrain import AutoRetrainService
from ai_strategy_generator import AIStrategyGenerator

# Direct imports for production
from backend.agents.base_agent import BaseAgent
from backend.services.task_manager import task_manager

# Lazy import for optional redis helpers (may not be available in all deployments)
try:
    from utils.redis_helpers import to_str_list as _to_str_list_impl
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    _to_str_list_impl = None

logger = logging.getLogger(__name__)


class StrategyAgent(BaseAgent):
    """AI Strategy Agent - Handles strategy generation and analysis"""

    def __init__(self, agent_id: str = "strategy_agent_001") -> None:
        super().__init__(agent_id, "strategy")

        self.state.update(
            {
                "active_strategies": [],
                "strategy_performance": {},
                "generation_count": 0,
                "last_generation": None,
                "optimization_running": False,
            },
        )

        # Initialize strategy components
        self.strategy_generator = None
        self.auto_retrain = None

        # Register strategy-specific handlers
        self.register_handler("generate_strategy", self.handle_generate_strategy)
        self.register_handler("analyze_strategy", self.handle_analyze_strategy)
        self.register_handler("optimize_strategy", self.handle_optimize_strategy)
        self.register_handler("market_data", self.handle_market_data)
        self.register_handler("performance_update", self.handle_performance_update)

        logger.info(f"Strategy Agent {agent_id} initialized")

    async def initialize(self):
        """Initialize strategy agent resources"""
        try:
            # Initialize AI strategy generator if available
            if AIStrategyGenerator is not None:
                try:
                    self.strategy_generator = AIStrategyGenerator()
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.exception(f"âŒ Failed to initialize AIStrategyGenerator: {e}")
                    self.strategy_generator = None

            # Initialize auto-retrain system if available
            if AutoRetrainService is not None:
                try:
                    self.auto_retrain = AutoRetrainService()
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.exception(f"âŒ Failed to initialize AutoRetrainService: {e}")
                    self.auto_retrain = None

            # Load existing strategies
            await self.load_active_strategies()

            # Subscribe to market data
            await self.subscribe_to_market_data()

            logger.info(f"Strategy Agent {self.agent_id} initialized successfully")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Strategy Agent: {e}")
            self.update_health_status("error")

    async def process_loop(self):
        """Main strategy processing loop"""
        while self.running:
            try:
                # Monitor strategy performance
                await self.monitor_strategy_performance()

                # Check for strategy optimization opportunities
                await self.check_optimization_opportunities()

                # Update strategy metrics
                await self.update_strategy_metrics()

                await asyncio.sleep(60)  # Check every minute

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception(f"âŒ Error in strategy processing loop: {e}")
                await asyncio.sleep(120)

    async def monitor_strategy_performance(self):
        """Monitor performance of all active strategies"""
        try:
            for strategy in self.state.get("active_strategies", []):
                strategy_id = strategy.get("id")
                if strategy_id:
                    # Check if performance is degrading
                    performance = self.state["strategy_performance"].get(strategy_id, {})
                    if await self.is_performance_degrading(performance):
                        logger.warning(f"Strategy {strategy_id} performance degrading")
                        await self.trigger_retrain(strategy_id)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error monitoring strategy performance: {e}")

    async def check_optimization_opportunities(self):
        """Check for strategy optimization opportunities"""
        try:
            for strategy in self.state.get("active_strategies", []):
                if await self.should_optimize(strategy):
                    strategy_id = strategy.get("id")
                    if strategy_id:
                        logger.info(f"Optimization opportunity found for {strategy_id}")
                        await self.optimize_strategy(strategy_id, "genetic")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error checking optimization opportunities: {e}")

    async def update_strategy_metrics(self):
        """Update strategy metrics in Redis"""
        try:
            metrics = {
                "agent_id": self.agent_id,
                "active_strategies": len(self.state.get("active_strategies", [])),
                "generation_count": self.state.get("generation_count", 0),
                "last_generation": self.state.get("last_generation"),
                "optimization_running": self.state.get("optimization_running", False),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }
            self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics), ex=300)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error updating strategy metrics: {e}")

    async def update_strategy_performance(self, symbol: str, price: float, timestamp: str):
        """Update strategy performance based on market data"""
        try:
            for strategy in self.state.get("active_strategies", []):
                if strategy.get("symbol") == symbol:
                    strategy_id = strategy.get("id")
                    if strategy_id:
                        # Update performance tracking
                        if strategy_id not in self.state["strategy_performance"]:
                            self.state["strategy_performance"][strategy_id] = {}
                        self.state["strategy_performance"][strategy_id]["last_price"] = price
                        self.state["strategy_performance"][strategy_id]["last_update"] = timestamp
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error updating strategy performance: {e}")

    async def generate_strategy(self, symbol: str, strategy_type: str, parameters: dict) -> dict:
        """Generate a new trading strategy"""
        try:
            import uuid

            strategy_id = f"strategy_{uuid.uuid4().hex[:8]}"

            strategy = {
                "id": strategy_id,
                "symbol": symbol,
                "type": strategy_type,
                "parameters": parameters,
                "created_at": datetime.now(tz=timezone.utc).isoformat(),
                "performance": {"accuracy": 0.0, "sharpe_ratio": 0.0},
                "status": "active",
            }

            # Use strategy generator if available
            if self.strategy_generator:
                try:
                    generated = self.strategy_generator.generate(symbol, strategy_type, parameters)
                    if generated:
                        strategy.update(generated)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    pass

            # Store in Redis
            self.redis_client.set(f"ai_strategy:{strategy_id}", json.dumps(strategy))
            self.redis_client.rpush("ai_strategies", strategy_id)

            # Add to active strategies
            self.state["active_strategies"].append(strategy)
            self.state["generation_count"] += 1
            self.state["last_generation"] = datetime.now(tz=timezone.utc).isoformat()

            logger.info(f"Generated strategy {strategy_id} for {symbol}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error generating strategy: {e}")
            return {"id": None, "error": str(e)}
        else:
            return strategy

    async def analyze_strategy(self, strategy_id: str) -> dict:
        """Analyze a strategy's performance and characteristics"""
        try:
            # Get strategy from state or Redis
            strategy = None
            for s in self.state.get("active_strategies", []):
                if s.get("id") == strategy_id:
                    strategy = s
                    break

            if not strategy:
                strategy_data = self.redis_client.get(f"ai_strategy:{strategy_id}")
                if strategy_data:
                    if isinstance(strategy_data, bytes):
                        strategy_data = strategy_data.decode()
                    strategy = json.loads(strategy_data)

            if not strategy:
                return {"error": "Strategy not found"}

            # Analyze strategy
            analysis = {
                "strategy_id": strategy_id,
                "symbol": strategy.get("symbol"),
                "type": strategy.get("type"),
                "performance": strategy.get("performance", {}),
                "optimization_potential": await self.assess_optimization_potential(strategy),
                "market_conditions": await self.analyze_market_conditions(strategy),
                "recommendations": await self.generate_recommendations(strategy),
                "analyzed_at": datetime.now(tz=timezone.utc).isoformat(),
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error analyzing strategy: {e}")
            return {"error": str(e)}
        else:
            return analysis

    async def optimize_strategy(self, strategy_id: str, optimization_type: str):
        """Optimize a strategy using the specified method"""
        try:
            self.state["optimization_running"] = True
            logger.info(f"Starting {optimization_type} optimization for {strategy_id}")

            # Use auto-retrain if available
            if self.auto_retrain:
                try:
                    await asyncio.get_event_loop().run_in_executor(None, self.auto_retrain.optimize, strategy_id, optimization_type)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.exception(f"Auto-retrain optimization failed: {e}")

            logger.info(f"Optimization completed for {strategy_id}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error optimizing strategy: {e}")
        finally:
            self.state["optimization_running"] = False

    async def load_active_strategies(self):
        """Load active strategies from Redis"""
        try:
            if _to_str_list_impl is None:
                # Fallback if helper not available
                def to_str_list(items):
                    return [item.decode() if isinstance(item, bytes) else str(item) for item in items]
            else:
                to_str_list = _to_str_list_impl

            active_strategies = to_str_list(self.redis_client.lrange("ai_strategies", 0, -1))

            for strategy_id in active_strategies:
                strategy_data = self.redis_client.get(f"ai_strategy:{strategy_id}")
                if strategy_data:
                    # Ensure bytes are decoded if necessary
                    if isinstance(strategy_data, (bytes, bytearray)):
                        try:
                            strategy_data = strategy_data.decode()
                        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                            strategy_data = strategy_data.decode("utf-8", errors="ignore")
                    strategy = json.loads(strategy_data)
                    self.state["active_strategies"].append(strategy)

            logger.info(f"ðŸ“Š Loaded {len(self.state['active_strategies'])} active strategies")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error loading active strategies: {e}")

    async def subscribe_to_market_data(self):
        """Subscribe to market data updates"""
        try:
            # Subscribe to market data channel
            pubsub = self.redis_client.pubsub()
            pubsub.subscribe("market_data")

            # Start market data listener
            task = await task_manager.create_task(self.listen_market_data(pubsub), name="strategy_agent:listen_market_data")
            self._tasks.append(task)

            logger.info("ðŸ“¡ Strategy Agent subscribed to market data")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error subscribing to market data: {e}")

    async def listen_market_data(self, pubsub):
        """Listen for market data updates"""
        try:
            # pubsub.listen() is a blocking generator; run it in a thread to avoid blocking event loop
            loop = asyncio.get_event_loop()

            def _iter_messages():
                yield from pubsub.listen()

            for message in await loop.run_in_executor(None, lambda: list(_iter_messages())):
                if not self.running:
                    break

                if not message:
                    continue

                # message['data'] might be bytes
                data = message.get("data")
                try:
                    if isinstance(data, (bytes, bytearray)):
                        data = data.decode("utf-8")
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    pass

                if message.get("type") == "message" and data:
                    try:
                        market_data = json.loads(data)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        market_data = data
                    await self.process_market_data(market_data)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error in market data listener: {e}")
        finally:
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pubsub.close()

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process incoming market data"""
        try:
            symbol = market_data.get("symbol")
            price = market_data.get("price")
            timestamp = market_data.get("timestamp")

            # Update strategy performance with new market data
            await self.update_strategy_performance(symbol, price, timestamp)

            # Check for strategy signals
            await self.check_strategy_signals(market_data)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error processing market data: {e}")

    async def handle_generate_strategy(self, message: dict[str, Any]):
        """Handle strategy generation request"""
        try:
            symbol = message.get("symbol", "BTCUSDT")
            strategy_type = message.get("strategy_type", "lstm")
            parameters = message.get("parameters", {})

            logger.info(f"ðŸŽ¯ Generating strategy for {symbol} ({strategy_type})")

            # Generate new strategy
            strategy = await self.generate_strategy(symbol, strategy_type, parameters)

            # Send response
            response = {
                "type": "strategy_generated",
                "strategy_id": strategy.get("id") if isinstance(strategy, dict) else None,
                "symbol": symbol,
                "strategy_type": strategy_type,
                "performance": strategy.get("performance", {}) if isinstance(strategy, dict) else {},
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

            # Broadcast strategy generation
            await self.broadcast_message({"type": "strategy_generated", "strategy": strategy})

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error generating strategy: {e}")
            try:
                await self.broadcast_error(f"Strategy generation error: {e}")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to broadcast strategy generation error")

    async def handle_analyze_strategy(self, message: dict[str, Any]):
        """Handle strategy analysis request"""
        try:
            strategy_id = message.get("strategy_id")

            logger.info(f"ðŸ“Š Analyzing strategy {strategy_id}")

            # Analyze strategy
            analysis = await self.analyze_strategy(strategy_id)

            # Send response
            response = {
                "type": "strategy_analysis",
                "strategy_id": strategy_id,
                "analysis": analysis,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error analyzing strategy: {e}")
            try:
                await self.broadcast_error(f"Strategy analysis error: {e}")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to broadcast strategy analysis error")

    async def handle_optimize_strategy(self, message: dict[str, Any]):
        """Handle strategy optimization request"""
        try:
            strategy_id = message.get("strategy_id")
            optimization_type = message.get("optimization_type", "genetic")

            logger.info(f"âš¡ Optimizing strategy {strategy_id} ({optimization_type})")

            # Start optimization
            await self.optimize_strategy(strategy_id, optimization_type)

            # Send response
            response = {
                "type": "optimization_started",
                "strategy_id": strategy_id,
                "optimization_type": optimization_type,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error optimizing strategy: {e}")
            try:
                await self.broadcast_error(f"Strategy optimization error: {e}")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to broadcast strategy optimization error")

    async def handle_market_data(self, message: dict[str, Any]):
        """Handle incoming market data updates"""
        try:
            await self.process_market_data(message)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error handling market data: {e}")

    async def handle_performance_update(self, message: dict[str, Any]):
        """Handle performance update messages"""
        try:
            strategy_id = message.get("strategy_id")
            performance = message.get("performance", {})

            if strategy_id and performance:
                self.state["strategy_performance"][strategy_id] = performance
                logger.debug(f"Updated performance for strategy {strategy_id}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error handling performance update: {e}")

    async def assess_optimization_potential(self, strategy: dict[str, Any]) -> dict[str, Any]:
        """Assess optimization potential"""
        try:
            performance = strategy.get("performance", {})

            # Assess different optimization opportunities
            optimization_potential = {
                "parameter_tuning": self.assess_parameter_tuning(performance),
                "feature_engineering": self.assess_feature_engineering(performance),
                "model_architecture": self.assess_model_architecture(performance),
                "overall_potential": 0,
            }

            # Calculate overall potential
            optimization_potential["overall_potential"] = (
                optimization_potential["parameter_tuning"] + optimization_potential["feature_engineering"] + optimization_potential["model_architecture"]
            ) / 3

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error assessing optimization potential: {e}")
            return {}

    def assess_parameter_tuning(self, performance: dict[str, Any]) -> float:
        """Assess parameter tuning potential (0-100)"""
        accuracy = performance.get("accuracy", 0)
        if accuracy < 0.7:
            return 80  # High potential for improvement
        if accuracy < 0.8:
            return 50  # Medium potential
        return 20  # Low potential

    def assess_feature_engineering(self, _performance: dict[str, Any]) -> float:
        """Assess feature engineering potential (0-100)"""
        # Simple assessment based on performance
        return 60  # Medium potential

    def assess_model_architecture(self, _performance: dict[str, Any]) -> float:
        """Assess model architecture potential (0-100)"""
        # Simple assessment based on performance
        return 40  # Low-medium potential

    async def analyze_market_conditions(self, strategy: dict[str, Any]) -> dict[str, Any]:
        """Analyze current market conditions for strategy"""
        try:
            symbol = strategy.get("symbol", "BTCUSDT")

            # Get recent market data
            market_data = self.redis_client.get(f"market_data:{symbol}")
            if market_data:
                if isinstance(market_data, (bytes, bytearray)):
                    try:
                        market_data = market_data.decode("utf-8")
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        market_data = market_data.decode("utf-8", errors="ignore")
                market = json.loads(market_data)

                # Analyze market conditions
                return {
                    "volatility": self.calculate_market_volatility(market),
                    "trend": self.analyze_market_trend(market),
                    "volume": self.analyze_market_volume(market),
                    "suitability": self.assess_market_suitability(strategy, market),
                }

            else:
                pass
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error analyzing market conditions: {e}")
            return {}

    def calculate_market_volatility(self, _market_data: dict[str, Any]) -> float:
        """Calculate market volatility"""
        try:
            # Simple volatility calculation
            return 0.15  # Default value
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error calculating market volatility: {e}")
            return 0.0

    def analyze_market_trend(self, _market_data: dict[str, Any]) -> str:
        """Analyze market trend"""
        try:
            # Simple trend analysis
            return "bullish"  # Default trend
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error analyzing market trend: {e}")
            return "neutral"

    def analyze_market_volume(self, _market_data: dict[str, Any]) -> str:
        """Analyze market volume"""
        try:
            # Simple volume analysis
            return "normal"  # Default volume
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error analyzing market volume: {e}")
            return "normal"

    def assess_market_suitability(self, _strategy: dict[str, Any], _market_data: dict[str, Any]) -> float:
        """Assess how suitable current market conditions are for strategy"""
        try:
            # Simple suitability assessment
            return 0.75  # Default suitability
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error assessing market suitability: {e}")
            return 0.5

    async def generate_recommendations(self, strategy: dict[str, Any]) -> list[str]:
        """Generate recommendations for strategy improvement"""
        try:
            recommendations = []
            performance = strategy.get("performance", {})

            # Generate recommendations based on performance
            if performance.get("accuracy", 0) < 0.7:
                recommendations.append("Consider retraining with more data")

            if performance.get("sharpe_ratio", 0) < 1.0:
                recommendations.append("Optimize risk management parameters")

            if performance.get("max_drawdown", 0) > 0.2:
                recommendations.append("Implement stricter stop-loss mechanisms")

            if not recommendations:
                recommendations.append("Strategy performing well - monitor for changes")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error generating recommendations: {e}")
            return ["Unable to generate recommendations"]

    async def is_performance_degrading(self, performance: dict[str, Any]) -> bool:
        """Check if strategy performance is degrading"""
        try:
            performance.get("accuracy", 0)
            performance.get("sharpe_ratio", 0)

            # Simple degradation check
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error checking performance degradation: {e}")
            return False

    async def should_optimize(self, strategy: dict[str, Any]) -> bool:
        """Check if strategy should be optimized"""
        try:
            performance = strategy.get("performance", {})
            accuracy = performance.get("accuracy", 0)

            # Simple optimization trigger
            return accuracy < 0.75 and not self.state.get("optimization_running", False)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error checking optimization need: {e}")
            return False

    async def trigger_retrain(self, strategy_id: str):
        """Trigger retrain for strategy"""
        try:
            logger.info(f"ðŸ”„ Triggering retrain for strategy {strategy_id}")

            # Send retrain request to auto-retrain service
            await self.send_message(
                "auto_retrain_agent",
                {
                    "type": "retrain_request",
                    "strategy_id": strategy_id,
                    "reason": "performance_degradation",
                    "priority": "high",
                },
            )

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error triggering retrain: {e}")

    async def check_strategy_signals(self, market_data: dict[str, Any]):
        """Check for trading signals from strategies"""
        try:
            symbol = market_data.get("symbol")

            # Check each strategy for signals
            for strategy in self.state.get("active_strategies", []):
                if strategy.get("symbol") == symbol:
                    signal = await self.generate_signal(strategy, market_data)

                    if signal:
                        # Send signal to execution agent
                        await self.send_message(
                            "execution_agent",
                            {
                                "type": "trading_signal",
                                "strategy_id": strategy.get("id"),
                                "signal": signal,
                                "market_data": market_data,
                            },
                        )

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error checking strategy signals: {e}")

    async def generate_signal(self, _strategy: dict[str, Any], market_data: dict[str, Any]) -> dict[str, Any] | None:
        """Generate trading signal from strategy"""
        try:
            # Simple signal generation
            # In real implementation, this would use the actual strategy model

            price = market_data.get("price", 0)
            if price and price > 0:
                # Use deterministic signal instead of random
                signal_type = "hold"  # Use neutral signal

                if signal_type != "hold":
                    return {
                        "type": signal_type,
                        "confidence": 0.75,  # Use fixed confidence instead of random
                        "price": price,
                        "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                    }

            else:
                pass
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error generating signal: {e}")
            return None
