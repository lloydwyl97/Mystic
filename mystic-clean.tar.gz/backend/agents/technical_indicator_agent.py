import asyncio
import contextlib
import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Any

import pandas as pd

from backend.agents.base_agent import BaseAgent
from backend.services.task_manager import task_manager

logger = logging.getLogger(__name__)

"""
Technical Indicator Agent
Handles technical indicator analysis and signal generation
"""

# Add parent directory to path for imports


class TechnicalIndicatorAgent(BaseAgent):
    """Technical Indicator Agent - Analyzes technical indicators and generates signals"""

    def __init__(self, agent_id: str = "technical_indicator_agent_001") -> None:
        super().__init__(agent_id, "technical_indicator")

        self.state.update(
            {
                "indicators_calculated": {},
                "signals_generated": {},
                "indicator_cache": {},
                "analysis_history": {},
                "last_analysis": None,
                "analysis_count": 0,
            },
        )

        # Indicator configuration
        self.indicator_config = {
            "supported_indicators": [
                "sma",
                "ema",
                "rsi",
                "macd",
                "bollinger_bands",
                "stochastic",
                "williams_r",
                "cci",
                "adx",
                "atr",
                "obv",
                "volume_sma",
                "price_channels",
                "parabolic_sar",
            ],
            "signal_thresholds": {
                "rsi_oversold": 30,
                "rsi_overbought": 70,
                "stochastic_oversold": 20,
                "stochastic_overbought": 80,
                "williams_r_oversold": -80,
                "williams_r_overbought": -20,
                "cci_oversold": -100,
                "cci_overbought": 100,
            },
            "crossover_threshold": (0.001),  # minimum change for crossover detection
            "signal_confidence": {
                "strong_buy": 0.8,
                "buy": 0.6,
                "neutral": 0.4,
                "sell": 0.6,
                "strong_sell": 0.8,
            },
        }

        # Trading symbols to monitor
        self.trading_symbols = [
            "BTC",
            "ETH",
            "ADA",
            "DOT",
            "LINK",
            "UNI",
            "AAVE",
        ]

        # Timeframe settings
        self.timeframe_settings = {
            "short_term": {"period": 14, "multiplier": 1},
            "medium_term": {"period": 20, "multiplier": 2},
            "long_term": {"period": 50, "multiplier": 3},
        }

        # Register technical indicator-specific handlers
        self.register_handler("calculate_indicators", self.handle_calculate_indicators)
        self.register_handler("get_indicator_signals", self.handle_get_indicator_signals)
        self.register_handler("analyze_crossovers", self.handle_analyze_crossovers)
        self.register_handler("market_data", self.handle_market_data)

        logger.info(f"Technical Indicator Agent {agent_id} initialized")

    async def initialize(self):
        """Initialize technical indicator agent resources"""
        try:
            # Load indicator configuration
            await self.load_indicator_config()

            # Initialize indicator calculation functions
            await self.initialize_indicator_functions()

            # Start indicator monitoring
            await self.start_indicator_monitoring()

            logger.info(f"Technical Indicator Agent {self.agent_id} initialized successfully")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Technical Indicator Agent: {e}")
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                self.update_health_status("error")

    async def process_loop(self):
        """Main technical indicator processing loop"""
        while self.running:
            try:
                # Calculate indicators for all symbols
                await self.calculate_all_indicators()

                # Generate indicator signals
                await self.generate_indicator_signals()

                # Analyze crossovers
                await self.analyze_all_crossovers()

                # Update indicator metrics
                await self.update_indicator_metrics()

                # Clean up old cache entries
                await self.cleanup_cache()

                await asyncio.sleep(60)  # Check every minute

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception(f"âŒ Error in technical indicator processing loop: {e}")
                await asyncio.sleep(120)

    async def load_indicator_config(self):
        """Load indicator configuration from Redis"""
        try:
            # Load indicator configuration
            config_data = None
            try:
                config_data = self.redis_client.get("technical_indicator_config")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # Some redis clients might have different interfaces or be async; ignore if not available
                config_data = None

            if config_data:
                try:
                    self.indicator_config = json.loads(config_data)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    # If stored as bytes
                    self.indicator_config = json.loads(config_data.decode() if isinstance(config_data, (bytes, bytearray)) else config_data)

            # Load trading symbols
            symbols_data = None
            try:
                symbols_data = self.redis_client.get("trading_symbols")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                symbols_data = None

            if symbols_data:
                try:
                    self.trading_symbols = json.loads(symbols_data)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    self.trading_symbols = json.loads(symbols_data.decode() if isinstance(symbols_data, (bytes, bytearray)) else symbols_data)

            # Load timeframe settings
            timeframe_data = None
            try:
                timeframe_data = self.redis_client.get("timeframe_settings")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                timeframe_data = None

            if timeframe_data:
                try:
                    self.timeframe_settings = json.loads(timeframe_data)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    self.timeframe_settings = json.loads(timeframe_data.decode() if isinstance(timeframe_data, (bytes, bytearray)) else timeframe_data)

            logger.info(f"Indicator configuration loaded: {len(self.indicator_config.get('supported_indicators', []))} indicators, {len(self.trading_symbols)} symbols")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error loading indicator configuration: {e}")

    async def initialize_indicator_functions(self):
        """Initialize indicator calculation functions"""
        try:
            # Initialize pandas-ta functions for each indicator
            # Note: These lambdas assume pandas_ta is installed and enabled as df.ta
            self.indicator_functions = {
                "sma": lambda df, period=14: df["close"].ta.sma(length=period) if hasattr(df, "ta") else df["close"].rolling(window=period).mean(),
                "ema": lambda df, period=14: df["close"].ta.ema(length=period) if hasattr(df, "ta") else df["close"].ewm(span=period, adjust=False).mean(),
                "rsi": lambda df, period=14: df["close"].ta.rsi(length=period) if hasattr(df, "ta") else pd.Series(dtype=float),
                "macd": lambda df, fast=12, slow=26, signal=9: df.ta.macd(fast=fast, slow=slow, signal=signal) if hasattr(df, "ta") else pd.DataFrame(),
                "bollinger_bands": lambda df, period=20, std=2: df.ta.bbands(length=period, std=std) if hasattr(df, "ta") else pd.DataFrame(),
                "stochastic": lambda df, k=14, d=3: df.ta.stoch(k=k, d=d) if hasattr(df, "ta") else pd.DataFrame(),
                "williams_r": lambda df, period=14: df.ta.willr(length=period) if hasattr(df, "ta") else pd.Series(dtype=float),
                "cci": lambda df, period=20: df.ta.cci(length=period) if hasattr(df, "ta") else pd.Series(dtype=float),
                "adx": lambda df, period=14: df.ta.adx(length=period) if hasattr(df, "ta") else pd.DataFrame(),
                "atr": lambda df, period=14: df.ta.atr(length=period) if hasattr(df, "ta") else pd.Series(dtype=float),
                "obv": lambda df: df.ta.obv() if hasattr(df, "ta") else pd.Series(dtype=float),
                "parabolic_sar": lambda df, af0=0.02, af=0.02, max_af=0.2: df.ta.psar(af0=af0, af=af, max_af=max_af) if hasattr(df, "ta") else pd.Series(dtype=float),
            }

            logger.info(f"Indicator functions initialized: {len(self.indicator_functions)} functions")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error initializing indicator functions: {e}")

    async def start_indicator_monitoring(self):
        """Start indicator monitoring"""
        try:
            # Subscribe to market data for indicator calculation
            pubsub = None
            try:
                pubsub = self.redis_client.pubsub()
                pubsub.subscribe("market_data")
                # Start market data listener
                task = await task_manager.create_task(self.listen_market_data(pubsub), name="technical_indicator_agent:listen_market_data")
                self._tasks.append(task)
                logger.info("ðŸ”” Indicator monitoring started")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # If redis client doesn't support pubsub or fails, skip starting listener
                if pubsub:
                    with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        pubsub.close()

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error starting indicator monitoring: {e}")

    async def listen_market_data(self, pubsub):
        """Listen for market data updates"""
        try:
            # pubsub.listen() is blocking; run in thread executor if needed
            for message in pubsub.listen():
                if not self.running:
                    break

                if message.get("type") == "message":
                    data = message.get("data")
                    try:
                        market_data = json.loads(data)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        try:
                            market_data = json.loads(data.decode() if isinstance(data, (bytes, bytearray)) else data)
                        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                            market_data = {}
                    await self.process_market_data(market_data)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error in market data listener: {e}")
        finally:
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pubsub.close()

    async def process_market_data(self, market_data: dict[str, Any]):
        """Process market data for indicator calculation"""
        try:
            # market_data may be a single symbol dict or mapping of symbols
            symbol = market_data.get("symbol") if isinstance(market_data, dict) else None
            price = market_data.get("price") if isinstance(market_data, dict) else None
            volume = market_data.get("volume", 0) if isinstance(market_data, dict) else 0
            timestamp = market_data.get("timestamp") if isinstance(market_data, dict) else None

            # If it's a dict of multiple symbols (e.g., { "BTC": {...}, "ETH": {...} })
            if symbol and price is not None and timestamp:
                # Single symbol update
                await self.store_market_data(symbol, price, volume, timestamp)
            else:
                # Possibly a batch of symbols
                # If market_data is mapping with symbol keys:
                for sym, data in market_data.items() if isinstance(market_data, dict) else []:
                    if not isinstance(data, dict):
                        continue
                    price = data.get("price")
                    volume = data.get("volume", 0)
                    timestamp = data.get("timestamp", datetime.now(tz=timezone.utc).isoformat())
                    if price is not None:
                        await self.store_market_data(sym, price, volume, timestamp)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error processing market data: {e}")

    async def store_market_data(self, symbol: str, price: float, volume: float, timestamp: str | None):
        """Store market data for indicator calculation"""
        try:
            if timestamp is None:
                timestamp_iso = datetime.now(tz=timezone.utc).isoformat()
            elif isinstance(timestamp, datetime):
                timestamp_iso = timestamp.isoformat()
            else:
                # Try to ensure timestamp is ISO string
                timestamp_iso = str(timestamp)

            entry = {
                "close": float(price),
                "price": float(price),
                "volume": float(volume or 0),
                "timestamp": timestamp_iso,
            }

            if symbol not in self.state["indicator_cache"]:
                self.state["indicator_cache"][symbol] = []

            self.state["indicator_cache"][symbol].append(entry)

            # Keep a reasonable limit to cache to avoid memory growth, e.g., last 2000 points
            if len(self.state["indicator_cache"][symbol]) > 2000:
                self.state["indicator_cache"][symbol] = self.state["indicator_cache"][symbol][-2000:]

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error storing market data: {e}")

    async def calculate_symbol_indicators(self, symbol: str):
        """Calculate indicators for a single symbol and store results"""
        try:
            data_points = self.state["indicator_cache"].get(symbol, [])
            if not data_points:
                return None

            # Build DataFrame; ensure order by timestamp
            try:
                df = pd.DataFrame(data_points)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                df = pd.DataFrame(data_points)

            if df.empty or "close" not in df.columns:
                return None

            # Ensure numeric types
            df["close"] = pd.to_numeric(df["close"], errors="coerce")
            if "volume" in df.columns:
                df["volume"] = pd.to_numeric(df["volume"], errors="coerce")
            # sort by timestamp if possible
            if "timestamp" in df.columns:
                try:
                    df["timestamp"] = pd.to_datetime(df["timestamp"])
                    df = df.sort_values("timestamp").reset_index(drop=True)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    pass

            indicator_result: dict[str, Any] = {}
            for name, func in getattr(self, "indicator_functions", {}).items():
                try:
                    # Try calling with df only
                    try:
                        res = func(df)
                    except TypeError:
                        # Try with a default period from short_term
                        period = self.timeframe_settings.get("short_term", {}).get("period", 14)
                        try:
                            res = func(df, period)
                        except TypeError:
                            # Final fallback: call with no args
                            res = func(df)
                    # Extract last value(s)
                    if isinstance(res, pd.Series):
                        last_val = res.dropna()
                        if not last_val.empty:
                            indicator_result[name] = float(last_val.iloc[-1])
                        else:
                            indicator_result[name] = None
                    elif isinstance(res, pd.DataFrame):
                        # If multiple columns, store the last row as dict of scalars
                        last_row = res.dropna(how="all")
                        if not last_row.empty:
                            last = last_row.iloc[-1]
                            # Convert to native types
                            try:
                                indicator_result[name] = {str(k): (float(v) if pd.notna(v) and isinstance(v, (int, float)) else (None if pd.isna(v) else v)) for k, v in last.items()}
                            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                                indicator_result[name] = last.to_dict()
                        else:
                            indicator_result[name] = None
                    else:
                        # Unknown type; attempt to coerce to float
                        try:
                            indicator_result[name] = float(res)
                        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                            indicator_result[name] = res
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    # Ignore failures per indicator
                    indicator_result[name] = None

            # Update state
            self.state["indicators_calculated"][symbol] = {
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                "values": indicator_result,
            }
            self.state["last_analysis"] = datetime.now(tz=timezone.utc).isoformat()
            self.state["analysis_count"] = self.state.get("analysis_count", 0) + 1

            # Add to history
            hist = self.state["analysis_history"].get(symbol, [])
            hist.append({"timestamp": self.state["last_analysis"], "indicators": indicator_result})
            # Keep history short
            if len(hist) > 100:
                hist = hist[-100:]
            self.state["analysis_history"][symbol] = hist
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error calculating indicators for {symbol}: {e}")
            return None
        else:
            return indicator_result

    async def calculate_all_indicators(self):
        """Calculate indicators for all subscribed trading symbols"""
        try:
            tasks = []
            for symbol in self.trading_symbols:
                tasks.append(self.calculate_symbol_indicators(symbol))
            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error calculating all indicators: {e}")

    async def generate_indicator_signals(self):
        """Generate simplistic indicator-based signals for each symbol"""
        try:
            thresholds = self.indicator_config.get("signal_thresholds", {})
            signals = {}
            for symbol, data in self.state.get("indicators_calculated", {}).items():
                values = data.get("values", {})
                rsi = values.get("rsi")
                sma = values.get("sma")
                ema = values.get("ema")
                macd = values.get("macd")
                # signal_line = None  # Commented out unused variable
                # macd may be a dict if returned as DataFrame
                if isinstance(macd, dict):
                    # try common keys
                    for k in ["MACD_12_26_9", "MACD"]:
                        if k in macd:
                            try:
                                macd_val = float(macd[k])
                                macd = macd_val
                                break
                            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                                pass
                # simplistic rules
                signal = "neutral"
                confidence = self.indicator_config.get("signal_confidence", {}).get("neutral", 0.4)
                reasons = []

                if isinstance(rsi, (int, float)):
                    if rsi < thresholds.get("rsi_oversold", 30):
                        signal = "buy"
                        confidence = max(confidence, self.indicator_config.get("signal_confidence", {}).get("buy", 0.6))
                        reasons.append("rsi_oversold")
                    elif rsi > thresholds.get("rsi_overbought", 70):
                        signal = "sell"
                        confidence = max(confidence, self.indicator_config.get("signal_confidence", {}).get("sell", 0.6))
                        reasons.append("rsi_overbought")

                # SMA/EMA trend confirmation
                try:
                    if isinstance(sma, (int, float)) and isinstance(ema, (int, float)):
                        if ema > sma:
                            if signal == "buy":
                                confidence = min(1.0, confidence + 0.1)
                                reasons.append("ema_above_sma")
                            elif signal == "neutral":
                                signal = "buy"
                                confidence = self.indicator_config.get("signal_confidence", {}).get("buy", 0.6)
                                reasons.append("ema_above_sma")
                        elif ema < sma:
                            if signal == "sell":
                                confidence = min(1.0, confidence + 0.1)
                                reasons.append("ema_below_sma")
                            elif signal == "neutral":
                                signal = "sell"
                                confidence = self.indicator_config.get("signal_confidence", {}).get("sell", 0.6)
                                reasons.append("ema_below_sma")
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    pass

                signals[symbol] = {
                    "signal": signal,
                    "confidence": confidence,
                    "reasons": reasons,
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                }

            # Update state
            self.state["signals_generated"].update(signals)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error generating indicator signals: {e}")
            return {}
        else:
            return signals

    async def analyze_symbol_crossovers(self, symbol: str):
        """Analyze crossovers for a single symbol"""
        try:
            indicators_entry = self.state.get("indicators_calculated", {}).get(symbol)
            if not indicators_entry:
                return None

            values = indicators_entry.get("values", {})
            crossovers = {}

            # SMA crossover (short vs long)
            sma = values.get("sma")
            # for demonstration, compare sma (short_term) vs long_term sma if available
            # Many indicator implementations may return only one SMA; we attempt reasonable checks
            try:
                sma_short = sma if isinstance(sma, (int, float)) else None
                # long term - attempt to compute if available in cache by recalculating quickly
                # For simplicity, derive long term SMA from cached close series if possible
                data_points = self.state["indicator_cache"].get(symbol, [])
                if data_points:
                    df = pd.DataFrame(data_points)
                    df["close"] = pd.to_numeric(df["close"], errors="coerce")
                    long_period = self.timeframe_settings.get("long_term", {}).get("period", 50)
                    if len(df) >= long_period:
                        long_sma_series = df["close"].rolling(window=long_period).mean()
                        long_sma_val = long_sma_series.dropna()
                        sma_long = float(long_sma_val.iloc[-1]) if not long_sma_val.empty else None
                    else:
                        sma_long = None
                else:
                    sma_long = None

                if sma_short is not None and sma_long is not None:
                    if sma_short > sma_long:
                        crossovers["sma"] = {"type": "bullish", "signal": "buy", "reason": "short_sma_above_long_sma"}
                    elif sma_short < sma_long:
                        crossovers["sma"] = {"type": "bearish", "signal": "sell", "reason": "short_sma_below_long_sma"}
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pass

            # EMA crossover using existing analyzer if possible
            ema_analysis = await self.analyze_ema_crossover({"ema_12": values.get("ema"), "ema_26": values.get("ema")})
            if ema_analysis:
                crossovers["ema"] = ema_analysis

            # MACD crossover
            macd_val = values.get("macd")
            if isinstance(macd_val, dict):
                # try to find macd and signal keys
                macd_num = None
                signal_num = None
                for k, v in macd_val.items():
                    if "macd" in k.lower():
                        with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                            macd_num = float(v)
                    if "signal" in k.lower():
                        with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                            signal_num = float(v)
                macd_data = {"macd": macd_num, "signal": signal_num}
                macd_analysis = await self.analyze_macd_crossover(macd_data)
                if macd_analysis:
                    crossovers["macd"] = macd_analysis

            # Broadcast if any crossovers found
            if crossovers:
                await self.broadcast_crossover_analysis(symbol, crossovers)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error analyzing crossovers for {symbol}: {e}")
            return None
        else:
            return crossovers

    async def analyze_all_crossovers(self):
        """Analyze crossovers for all monitored symbols"""
        try:
            tasks = []
            for symbol in self.trading_symbols:
                tasks.append(self.analyze_symbol_crossovers(symbol))
            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error analyzing all crossovers: {e}")

    async def analyze_ema_crossover(self, ema_data: dict[str, Any]) -> dict[str, Any] | None:
        """Analyze EMA crossover"""
        try:
            ema_12 = ema_data.get("ema_12")
            ema_26 = ema_data.get("ema_26")

            if ema_12 is None or ema_26 is None:
                return None

            # Check for crossover
            if ema_12 > ema_26:
                return {
                    "type": "bullish",
                    "signal": "buy",
                    "confidence": 0.6,
                    "reason": "EMA 12 crossed above EMA 26",
                }
            if ema_12 < ema_26:
                return {
                    "type": "bearish",
                    "signal": "sell",
                    "confidence": 0.6,
                    "reason": "EMA 12 crossed below EMA 26",
                }
            else:
                pass
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error analyzing EMA crossover: {e}")
            return None

    async def analyze_macd_crossover(self, macd_data: dict[str, Any]) -> dict[str, Any] | None:
        """Analyze MACD crossover"""
        try:
            macd = macd_data.get("macd")
            signal = macd_data.get("signal")

            if macd is None or signal is None:
                return None

            # Check for crossover
            if macd > signal or macd < signal:
                pass
            else:
                pass
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error analyzing MACD crossover: {e}")
            return None

    async def broadcast_crossover_analysis(self, symbol: str, crossovers: dict[str, Any]):
        """Broadcast crossover analysis to other agents"""
        try:
            crossover_update = {
                "type": "crossover_analysis_update",
                "symbol": symbol,
                "crossovers": crossovers,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Broadcast to all agents
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # Best-effort; continue
                await self.broadcast_message(crossover_update)

            # Send to specific agents
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                await self.send_message("strategy_agent", crossover_update)
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                await self.send_message("risk_agent", crossover_update)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error broadcasting crossover analysis: {e}")

    async def handle_calculate_indicators(self, message: dict[str, Any]):
        """Handle manual indicator calculation request"""
        try:
            symbol = message.get("symbol")
            indicators = message.get("indicators", self.indicator_config["supported_indicators"])

            logger.info(f"Manual indicator calculation requested for {symbol}")

            if symbol:
                await self.calculate_symbol_indicators(symbol)

            # Send response
            response = {
                "type": "indicator_calculation_complete",
                "symbol": symbol,
                "indicators": indicators,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error handling indicator calculation request: {e}")
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                await self.broadcast_error(f"Indicator calculation error: {e}")

    async def handle_get_indicator_signals(self, message: dict[str, Any]):
        """Handle indicator signals request"""
        try:
            symbol = message.get("symbol")

            logger.info(f"Indicator signals requested for {symbol}")

            # Get indicator signals
            if symbol and symbol in self.state["signals_generated"]:
                signal = self.state["signals_generated"][symbol]

                response = {
                    "type": "indicator_signals_response",
                    "symbol": symbol,
                    "signal": signal,
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                }
            else:
                response = {
                    "type": "indicator_signals_response",
                    "symbol": symbol,
                    "signal": None,
                    "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                }

            sender = message.get("from_agent")
            if sender:
                with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error handling indicator signals request: {e}")
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                await self.broadcast_error(f"Indicator signals error: {e}")

    async def handle_analyze_crossovers(self, message: dict[str, Any]):
        """Handle crossover analysis request"""
        try:
            symbol = message.get("symbol")

            logger.info(f"ðŸ”Ž Crossover analysis requested for {symbol}")

            if symbol:
                await self.analyze_symbol_crossovers(symbol)

            # Send response
            response = {
                "type": "crossover_analysis_complete",
                "symbol": symbol,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            sender = message.get("from_agent")
            if sender:
                with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    await self.send_message(sender, response)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error handling crossover analysis request: {e}")
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                await self.broadcast_error(f"Crossover analysis error: {e}")

    async def update_indicator_metrics(self):
        """Update indicator metrics"""
        try:
            metrics = {
                "agent_id": self.agent_id,
                "symbols_count": len(self.trading_symbols),
                "indicators_count": len(self.indicator_config.get("supported_indicators", [])),
                "calculated_symbols": len(self.state.get("indicators_calculated", {})),
                "signals_generated": len(self.state.get("signals_generated", {})),
                "analysis_count": self.state.get("analysis_count", 0),
                "last_analysis": self.state.get("last_analysis"),
                "cache_size": len(self.state.get("indicator_cache", {})),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }

            # Store metrics in Redis if available
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # ignore if redis client not available or fails
                self.redis_client.set(f"agent_metrics:{self.agent_id}", json.dumps(metrics), ex=300)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error updating indicator metrics: {e}")

    async def cleanup_cache(self):
        """Clean up old cache entries"""
        try:
            current_time = datetime.now(tz=timezone.utc)

            # Clean up old indicator cache entries
            for symbol in list(self.state["indicator_cache"].keys()):
                data_points = self.state["indicator_cache"][symbol]

                # Keep only recent data points (last 24 hours)
                cutoff_time = current_time - timedelta(hours=24)
                recent_data = []
                for point in data_points:
                    ts = point.get("timestamp")
                    try:
                        t = datetime.fromisoformat(ts) if isinstance(ts, str) else (ts if isinstance(ts, datetime) else None)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        t = None
                    if t and t > cutoff_time:
                        recent_data.append(point)

                if recent_data:
                    self.state["indicator_cache"][symbol] = recent_data
                else:
                    with contextlib.suppress(KeyError):
                        del self.state["indicator_cache"][symbol]

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error cleaning up cache: {e}")

    async def handle_market_data(self, message: dict[str, Any]):
        """Handle market data message"""
        try:
            market_data = message.get("market_data", {})
            logger.info(f"Technical Indicator Agent received market data for {len(market_data) if isinstance(market_data, dict) else 0} symbols")

            # Process market data
            await self.process_market_data(market_data)

            # Store market data for each symbol if presented as mapping
            if isinstance(market_data, dict):
                for symbol, data in market_data.items():
                    if symbol in self.trading_symbols and isinstance(data, dict):
                        price = data.get("price", 0)
                        volume = data.get("volume", 0)
                        timestamp = data.get("timestamp", datetime.now(tz=timezone.utc).isoformat())

                        await self.store_market_data(symbol, price, volume, timestamp)

            # Calculate indicators with new data
            await self.calculate_all_indicators()

            # Generate signals
            await self.generate_indicator_signals()

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"âŒ Error handling market data: {e}")
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                await self.broadcast_error(f"Market data handling error: {e}")
