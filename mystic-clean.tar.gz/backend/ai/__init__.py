import importlib
import sys

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

_pkg = importlib.import_module("backend.modules.ai")
for _name in getattr(_pkg, "__all__", []):
    try:
        globals()[_name] = getattr(_pkg, _name)
    except AttributeError:
        # Skip any names listed in __all__ that aren't actually present.
        continue
# Make sure importing backend.ai.persistent_cache works
# CRITICAL: All data must be live: if persistent cache import fails, escalate exception,
# do NOT use fallback, mock, or hardcoded data.
sys.modules[f"{__name__}.persistent_cache"] = importlib.import_module("backend.modules.ai.persistent_cache")
# --- Compatibility shims for legacy callers (update_* methods) ---
# We already import import_module above in this file.
try:
    _pcm = importlib.import_module("backend.modules.ai.persistent_cache")
    PC = getattr(_pcm, "PersistentCache", None)

    def _bind_update(ns_name):
        def _update(self, data=None, **kwargs):
            payload = data if data is not None else kwargs
            key = f"market:{ns_name}"
            try:
                # Prefer the real setter if present
                return self.set(key, payload)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # Best-effort in-memory fallback
                self._store = getattr(self, "_store", {})
                self._store[key] = payload
                return True

        return _update

    if PC and not hasattr(PC, "update_binance"):
        # Use EXCHANGE_ID from trading_universe, convert to cache format (remove underscore)
        # EXCHANGE_ID is "binance_us", but cache expects "binanceus" format
        cache_namespace = EXCHANGE_ID.replace("_", "") if EXCHANGE_ID else "binanceus"
        PC.update_binance = _bind_update(cache_namespace)
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
    # Dont break import on environments that dont need this.
    pass
