BINANCE_SYMBOLS = [
    "BTCUSDT",
    "ETHUSDT",
    "ADAUSDT",
    "SOLUSDT",
    "DOGEUSDT",
    "XRPUSDT",
    "BCHUSDT",
    "LTCUSDT",
    "AVAXUSDT",
    "LINKUSDT",
]
