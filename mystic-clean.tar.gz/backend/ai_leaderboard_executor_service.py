#!/usr/bin/env python3
"""
AI Leaderboard Executor Service
Port 8005 - Standalone AI leaderboard execution service

Repairs applied:
- Ensure logs/ directory exists before creating FileHandler
- Replace mojibake characters in logs with clean text
- Guard Redis ping in /status to avoid 500s if Redis is down
- Add safe fallback stub for missing ai_leaderboard_executor module (live data only)
- Minor type hints and defensive error handling
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import uvicorn
from fastapi import FastAPI, HTTPException

from backend.services.ai_live_engine import ai_live_engine
from backend.services.task_manager import task_manager

# Lazy import for optional redis helpers (may not be available in all deployments)
try:
    from utils.redis_helpers import to_str
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    to_str = None  # type: ignore[assignment, misc]

# Ensure logs directory exists before configuring logging
Path("logs").mkdir(parents=True, exist_ok=True)

# Direct imports for production
# from ai_leaderboard_executor import AILeaderboardExecutor  # type: ignore[import-not-found]  # Commented out to avoid redefinition


class AILeaderboardExecutor:  # Live data only - no simulated data
    def __init__(self) -> None:
        self._current_leaderboard: list[dict[str, Any]] = []
        self._live_data_source = None

    async def start(self) -> None:
        # Initialize live data source instead of simulated data
        try:
            self._live_data_source = ai_live_engine
            if self._live_data_source:
                await self._load_live_leaderboard()
            else:
                self._current_leaderboard = []
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logging.exception(f"Failed to initialize live leaderboard: {e}")
            self._current_leaderboard = []

    async def stop(self) -> None:
        self._current_leaderboard = []
        self._live_data_source = None

    async def _load_live_leaderboard(self) -> None:
        """Load live leaderboard data from AI engine"""
        try:
            if self._live_data_source and hasattr(self._live_data_source, "get_performance_metrics"):
                metrics = await self._live_data_source.get_performance_metrics()
                if metrics and "model_comparison" in metrics:
                    self._current_leaderboard = []
                    for model in metrics["model_comparison"]:
                        self._current_leaderboard.append(
                            {
                                "strategy_id": model.get("model", "unknown"),
                                "score": float(model.get("accuracy", 0)),
                                "symbol": model.get("symbol") or "UNKNOWN",  # All Live Data, No Fallback/Hardcoded Data
                                "timeframe": model.get("timeframe", "1h"),
                            }
                        )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logging.exception(f"Failed to load live leaderboard: {e}")
            self._current_leaderboard = []

    async def execute_leaderboard_analysis(self, strategy_id: str, symbol: str, timeframe: str) -> dict[str, Any]:
        # Use live data instead of simulated scores
        try:
            if self._live_data_source and hasattr(self._live_data_source, "get_prediction"):
                prediction = await self._live_data_source.get_prediction(symbol)
                raw = float(prediction.get("confidence", 0) or 0) if prediction else 0.0
                from backend.services.confidence_normalizer import ConfidenceNormalizer

                score = ConfidenceNormalizer.normalize(raw)
            else:
                score = 0.0

            result = {
                "strategy_id": strategy_id,
                "symbol": symbol,
                "timeframe": timeframe,
                "score": score,
                "rank": max(1, int((1.0 - score) * 10)),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                "source": "live_data",
            }

            # Update current leaderboard with live data
            self._current_leaderboard.append(
                {
                    "strategy_id": strategy_id,
                    "score": score,
                    "symbol": symbol,
                    "timeframe": timeframe,
                }
            )
            # Keep top 20 by score
            self._current_leaderboard = sorted(self._current_leaderboard, key=lambda x: x["score"], reverse=True)[:20]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logging.exception(f"Failed to execute leaderboard analysis: {e}")
            return {
                "strategy_id": strategy_id,
                "symbol": symbol,
                "timeframe": timeframe,
                "score": 0.0,
                "rank": 1,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                "error": str(e),
            }
        else:
            return result

    async def get_current_leaderboard(self) -> dict[str, Any]:
        # Refresh live data before returning
        await self._load_live_leaderboard()
        return {
            "items": self._current_leaderboard,
            "count": len(self._current_leaderboard),
            "generated_at": datetime.now(tz=timezone.utc).isoformat(),
            "source": "live_data",
        }


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("logs/ai_leaderboard_executor.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("ai_leaderboard_executor_service")

# Initialize FastAPI app
app = FastAPI(
    title="AI Leaderboard Executor Service",
    description="Standalone AI leaderboard execution service",
    version="1.0.0",
)


class AILeaderboardExecutorService:
    """AI Leaderboard Executor Service"""

    def __init__(self) -> None:
        """Initialize the service"""
        self.executor = AILeaderboardExecutor()
        self.running: bool = False
        self.leaderboard_history: list[dict[str, Any]] = []

        # Use shared Redis connection pool to prevent connection exhaustion
        try:
            from backend.config.redis_config import get_shared_redis_sync

            self.redis_client = get_shared_redis_sync()
            # Light connectivity check (don't crash if unavailable)
            if self.redis_client:
                try:
                    self.redis_client.ping()
                    logger.info("[OK] Connected to Redis")
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as ping_err:
                    logger.warning(f"[WARN] Redis ping failed (continuing without Redis): {ping_err}")
                    self.redis_client = None
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as conn_err:
            logger.warning(f"[WARN] Redis not available: {conn_err}")
            self.redis_client = None  # type: ignore[assignment]

        logger.info("[OK] AI Leaderboard Executor Service initialized")

    async def start(self):
        """Start the service"""
        logger.info("[BOOT] Starting AI Leaderboard Executor Service...")
        self.running = True

        # Start the executor
        await self.executor.start()

        # Start leaderboard monitoring loop
        task = await task_manager.create_task(self.leaderboard_monitor_loop(), name="ai_leaderboard_executor_service:leaderboard_monitor_loop")
        if not hasattr(self, "_tasks"):
            self._tasks: list[asyncio.Task[Any]] = []
        self._tasks.append(task)

    async def stop(self):
        """Stop the service"""
        logger.info("[SHUTDOWN] Stopping AI Leaderboard Executor Service...")
        self.running = False
        # Cancel all background tasks
        if hasattr(self, "_tasks"):
            for task in self._tasks:
                if not task.done():
                    task.cancel()
                    with contextlib.suppress(asyncio.CancelledError):
                        await task
            self._tasks.clear()
        await self.executor.stop()

    async def leaderboard_monitor_loop(self):
        """Monitor for leaderboard execution requests"""
        logger.info("[LOOP] Starting leaderboard monitor loop...")

        while self.running:
            try:
                # Check for leaderboard requests
                request_json: str | None = None
                if self.redis_client:
                    try:
                        # Use optional helper if available
                        if to_str is not None:
                            raw = self.redis_client.lpop("ai_leaderboard_queue")
                            request_json = to_str(raw)
                        else:
                            request_json = self.redis_client.lpop("ai_leaderboard_queue")
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                        logger.warning(f"[WARN] Redis read error: {e}")

                if request_json:
                    try:
                        request_data = json.loads(request_json)
                        await self.process_leaderboard_request(request_data)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                        logger.exception(f"[ERR] Invalid request payload: {e}")

                # Sleep a bit to avoid tight loop
                await asyncio.sleep(1)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception(f"[ERR] Leaderboard monitor loop error: {e}")
                # Backoff on unexpected errors
                await asyncio.sleep(5)

    async def process_leaderboard_request(self, request_data: dict[str, Any]) -> dict[str, Any]:
        """Process a single leaderboard request payload"""
        # All Live Data, No Fallback/Hardcoded Data
        # Validate required fields before entering try block
        strategy_id = str(request_data.get("strategy_id") or request_data.get("strategy") or "unknown")
        symbol = request_data.get("symbol")
        if not symbol:
            msg = "symbol is required in request_data - no fallback/hardcoded symbol"
            raise ValueError(msg)
        timeframe = request_data.get("timeframe", "1h")

        try:
            # Execute analysis and create a record
            leaderboard_record = await self.execute_leaderboard_analysis(strategy_id, symbol, timeframe)

            # Optionally persist to Redis for later retrieval
            if self.redis_client:
                try:
                    key = f"leaderboard:{strategy_id}:{int(time.time())}"
                    # Store a JSON string of the result
                    self.redis_client.set(key, json.dumps(leaderboard_record))
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.warning(f"[WARN] Failed to persist leaderboard to Redis: {e}")

            # Append to in-memory history
            self.leaderboard_history.append(leaderboard_record)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERR] Error processing leaderboard request: {e}")
            # Record failed leaderboard execution
            leaderboard_record = {
                "strategy_id": request_data.get("strategy_id", "unknown") if isinstance(request_data, dict) else "unknown",
                "error": str(e),
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                "status": "failed",
            }
            self.leaderboard_history.append(leaderboard_record)
            return leaderboard_record

    async def execute_leaderboard_analysis(self, strategy_id: str, symbol: str, timeframe: str) -> dict[str, Any]:
        """Execute leaderboard analysis"""
        try:
            logger.info(f"[EXEC] Running leaderboard analysis for '{strategy_id}'")
            result = await self.executor.execute_leaderboard_analysis(strategy_id, symbol, timeframe)

            leaderboard_record = {
                "strategy_id": strategy_id,
                "symbol": symbol,
                "timeframe": timeframe,
                "result": result,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                "status": ("success" if result and "error" not in result else "failed"),
            }
            self.leaderboard_history.append(leaderboard_record)
            logger.info(f"[OK] Leaderboard analysis executed: {leaderboard_record['status']}")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERR] Error executing leaderboard analysis: {e}")
            raise
        else:
            return leaderboard_record

    async def get_leaderboard_history(self, limit: int = 100) -> list[dict[str, Any]]:
        """Get leaderboard history"""
        try:
            return self.leaderboard_history[-limit:] if self.leaderboard_history else []
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERR] Error getting leaderboard history: {e}")
            return []

    async def get_strategy_leaderboard(self, strategy_id: str) -> list[dict[str, Any]]:
        """Get leaderboard for a specific strategy"""
        results: list[dict[str, Any]] = []
        try:
            if not self.redis_client:
                return results
            for key in self.redis_client.scan_iter(f"leaderboard:{strategy_id}:*"):
                leaderboard_data = self.redis_client.get(key)
                if leaderboard_data:
                    try:
                        results.append(json.loads(leaderboard_data))
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        results.append({"raw": leaderboard_data})
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERR] Error getting strategy leaderboard: {e}")
            return []
        else:
            return results

    async def get_current_leaderboard(self) -> dict[str, Any]:
        """Get current leaderboard status"""
        try:
            leaderboard = await self.executor.get_current_leaderboard()
            return {
                "leaderboard": leaderboard,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERR] Error getting current leaderboard: {e}")
            return {"error": str(e)}


# Global service instance
# Leaderboard service state - using dict to avoid global keyword
_leaderboard_service_state: dict[str, AILeaderboardExecutorService | None] = {"instance": None}


@app.on_event("startup")
async def startup_event():
    """Startup event - initialize service"""
    try:
        _leaderboard_service_state["instance"] = AILeaderboardExecutorService()
        await _leaderboard_service_state["instance"].start()
        logger.info("[OK] AI Leaderboard Executor Service started")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"[ERR] Failed to start AI Leaderboard Executor Service: {e}")
        raise


@app.on_event("shutdown")
async def shutdown_event():
    """Shutdown event - stop service"""
    if _leaderboard_service_state["instance"]:
        await _leaderboard_service_state["instance"].stop()
        logger.info("[OK] AI Leaderboard Executor Service stopped")


# Health endpoint DELETED


@app.get("/status")
async def service_status():
    """Get service status"""
    if not _leaderboard_service_state["instance"]:
        raise HTTPException(status_code=503, detail="Service not initialized")

    # Safely check Redis connectivity
    redis_ok = False
    try:
        if _leaderboard_service_state["instance"] and _leaderboard_service_state["instance"].redis_client:
            try:
                redis_ok = bool(_leaderboard_service_state["instance"].redis_client.ping())
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                redis_ok = False
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        redis_ok = False

    return {
        "status": "running" if _leaderboard_service_state["instance"].running else "stopped",
        "redis_connected": redis_ok,
        "leaderboard_count": len(_leaderboard_service_state["instance"].leaderboard_history),
        "timestamp": datetime.now(tz=timezone.utc).isoformat(),
    }


@app.post("/analyze")
async def execute_leaderboard_analysis(strategy_id: str, symbol: str, timeframe: str = "1h"):
    # All Live Data, No Fallback/Hardcoded Data - symbol is required
    """Execute leaderboard analysis"""
    if not _leaderboard_service_state["instance"]:
        raise HTTPException(status_code=503, detail="Service not initialized")

    try:
        leaderboard_record = await _leaderboard_service_state["instance"].execute_leaderboard_analysis(strategy_id, symbol, timeframe)
        return {
            "status": "success",
            "leaderboard": leaderboard_record,
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"[ERR] Error in analyze endpoint: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@app.get("/leaderboards")
async def get_leaderboards(limit: int = 100):
    """Get leaderboard history"""
    if not _leaderboard_service_state["instance"]:
        raise HTTPException(status_code=503, detail="Service not initialized")

    try:
        leaderboards = await _leaderboard_service_state["instance"].get_leaderboard_history(limit)
        return {
            "leaderboards": leaderboards,
            "count": len(leaderboards),
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"[ERR] Error getting leaderboards: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@app.get("/leaderboards/{strategy_id}")
async def get_strategy_leaderboard(strategy_id: str):
    """Get leaderboard for a specific strategy"""
    if not _leaderboard_service_state["instance"]:
        raise HTTPException(status_code=503, detail="Service not initialized")

    try:
        leaderboards = await _leaderboard_service_state["instance"].get_strategy_leaderboard(strategy_id)
        return {
            "strategy_id": strategy_id,
            "leaderboards": leaderboards,
            "count": len(leaderboards),
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"[ERR] Error getting strategy leaderboard: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@app.get("/current")
async def get_current_leaderboard():
    """Get current leaderboard"""
    if not _leaderboard_service_state["instance"]:
        raise HTTPException(status_code=503, detail="Service not initialized")

    try:
        return await _leaderboard_service_state["instance"].get_current_leaderboard()
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"[ERR] Error getting current leaderboard: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@app.post("/queue/process")
async def process_leaderboard_queue():
    """Process leaderboard queue"""
    if not _leaderboard_service_state["instance"]:
        raise HTTPException(status_code=503, detail="Service not initialized")

    try:
        processed = 0
        while True:
            request_json: str | None = None
            if _leaderboard_service_state["instance"].redis_client:
                try:
                    if to_str is not None:
                        raw = _leaderboard_service_state["instance"].redis_client.lpop("ai_leaderboard_queue")
                        request_json = to_str(raw)
                    else:
                        request_json = _leaderboard_service_state["instance"].redis_client.lpop("ai_leaderboard_queue")
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.warning(f"[WARN] Redis read error: {e}")
                    break

            if not request_json:
                break

            try:
                request_data = json.loads(request_json)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.warning(f"[WARN] Skipping invalid queue item: {e}")
                continue

            await _leaderboard_service_state["instance"].process_leaderboard_request(request_data)
            processed += 1

        return {
            "status": "success",
            "processed": processed,
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"[ERR] Error processing leaderboard queue: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


if __name__ == "__main__":
    # Get port from environment
    port = int(os.getenv("SERVICE_PORT", "8005"))
    logger.info(f"[BOOT] Starting AI Leaderboard Executor Service on port {port}")
    uvicorn.run(
        "ai_leaderboard_executor_service:app",
        host="0.0.0.0",
        port=port,
        log_level="info",
        reload=False,
    )
