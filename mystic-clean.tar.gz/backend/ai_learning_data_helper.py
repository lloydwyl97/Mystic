#!/usr/bin/env python3
"""
AI Learning Data Helper
Provides real AI learning data for endpoints
"""

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from backend.config.redis_config import get_shared_redis_sync
from backend.services.canonical_cache import canonical_cache as get_shared_cache

# Lazy import for optional training pipeline (may not be available in all deployments)
try:
    from backend.ai_training_pipeline import get_ai_training_pipeline
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    get_ai_training_pipeline = None  # type: ignore[assignment, misc]

logger = logging.getLogger(__name__)


def get_real_ai_success_rate() -> float:
    """Get real AI success rate from the enhanced training pipeline"""
    try:
        if get_ai_training_pipeline is None:
            logger.warning("AI training pipeline not available")
            return 0.0

        pipeline = get_ai_training_pipeline()
        if pipeline is None:
            return 0.0

        # AITrainingDataPipeline uses performance_metrics.best_accuracy
        perf = getattr(pipeline, "performance_metrics", {})
        best_accuracy = float(perf.get("best_accuracy", 0.0))
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.warning(f"Could not get real AI success rate: {e}")
        return 0.0
    else:
        # Return best accuracy (0.0 to 1.0 range)
        return best_accuracy


class AILearningDataHelper:
    """Helper class for AI learning data"""

    def __init__(self, cache: Any = None) -> None:
        self.cache = cache
        self.data_file = "data/ai_learning_data.json"
        self._ensure_data_file()

    def _ensure_data_file(self):
        """NO-OP - data comes from Redis only, no file needed"""

    def get_ai_learning_data(self) -> dict[str, Any]:
        """Get LIVE AI learning data from Redis, fallback to file if Redis empty"""
        r = get_shared_redis_sync()
        if r is None:
            logger.warning("Shared Redis client unavailable for AI learning data")
            return {"error": "Shared Redis client unavailable"}

        try:
            # Get AI learning stats from Redis (written by ai_training_pipeline)
            ai_stats_json = r.get("ai_learning_stats")
            ai_stats = json.loads(ai_stats_json) if ai_stats_json else {}

            # Get AI live engine state from Redis
            ai_state_json = r.get("ai_live_engine:state")
            ai_state = json.loads(ai_state_json) if ai_state_json else {}

            # Get paper trading stats
            paper_stats_json = r.get("paper_trading:stats")
            paper_stats = json.loads(paper_stats_json) if paper_stats_json else {}

            # Get signal generator stats
            signal_stats_json = r.get("signal_generator:stats")
            signal_stats = json.loads(signal_stats_json) if signal_stats_json else {}

            # FALLBACK: If Redis is empty, read from file
            if not ai_stats and Path(self.data_file).exists():
                try:
                    with Path(self.data_file).open() as f:
                        file_data = json.load(f)
                    learning_metrics = file_data.get("learning_metrics", {})
                    ai_stats = {
                        "total_data_points": learning_metrics.get("total_data_points", 0),
                        "patterns_discovered": learning_metrics.get("patterns_discovered", 0),
                        "accuracy_improvement": learning_metrics.get("accuracy_improvement", 0.0),
                        "learning_progress": learning_metrics.get("learning_progress", 0.0),
                        "training_status": file_data.get("training_status", {}).get("status", "INACTIVE"),
                        "current_epoch": file_data.get("training_status", {}).get("current_epoch", 0),
                        "total_epochs": file_data.get("training_status", {}).get("total_epochs", 0),
                        "last_updated": learning_metrics.get("last_updated", datetime.now(timezone.utc).isoformat()),
                    }
                    logger.info("Loaded AI learning stats from file (Redis was empty)")
                except Exception as e:
                    logger.warning(f"Failed to load from file: {e}")

            last_updated_default = datetime.now(timezone.utc).isoformat()

            # Build LIVE data response
            return {
                "learning_metrics": {
                    "total_data_points": int(ai_stats.get("total_data_points", 0)),
                    "patterns_discovered": int(ai_stats.get("patterns_discovered", 0)),
                    "accuracy_improvement": float(ai_stats.get("accuracy_improvement", 0.0)),
                    "active_strategies": int(signal_stats.get("active_signals_count", 0)),
                    "learning_progress": float(ai_stats.get("learning_progress", 0.0)),
                    "queue_size": int(ai_stats.get("queue_size", 0)),
                },
                "training_status": {
                    "active": ai_stats.get("training_status") == "active",
                    "status": str(ai_stats.get("training_status", "INACTIVE")),
                    "current_epoch": int(ai_stats.get("current_epoch", 0)),
                    "total_epochs": int(ai_stats.get("total_epochs", 0)),
                    "loss": float(ai_stats.get("loss", 0.0)),
                    "val_loss": float(ai_stats.get("val_loss", 0.0)),
                },
                "model_performance": {
                    "lstm_model": {
                        "accuracy": float(ai_state.get("accuracy", 0.0)),
                        "status": "active" if ai_state.get("initialized") else "inactive",
                        "last_trained": ai_stats.get("last_updated", last_updated_default),
                    },
                    "transformer_model": {
                        "accuracy": float(ai_state.get("accuracy", 0.0)),
                        "status": "active" if ai_state.get("initialized") else "inactive",
                        "last_trained": ai_stats.get("last_updated", last_updated_default),
                    },
                    "ensemble_model": {
                        "accuracy": float(ai_state.get("accuracy", 0.0)),
                        "status": "active" if ai_state.get("initialized") else "inactive",
                        "last_trained": ai_stats.get("last_updated", last_updated_default),
                    },
                    "cnn_model": {
                        "accuracy": float(ai_state.get("accuracy", 0.0)),
                        "status": "training" if ai_state.get("is_training") else "inactive",
                        "last_trained": ai_stats.get("last_updated", last_updated_default),
                    },
                },
                "ai_trading_simulation": {
                    "total_trades": int(paper_stats.get("total_trades", 0)),
                    "winning_trades": int(paper_stats.get("winning_trades", 0)),
                    "losing_trades": int(paper_stats.get("losing_trades", 0)),
                    "total_pnl": float(paper_stats.get("total_pnl", 0.0)),
                    "average_win_rate": float(paper_stats.get("win_rate", 0.0)),
                    "sharpe_ratio": float(paper_stats.get("sharpe_ratio", 0.0)),
                    "max_drawdown": float(paper_stats.get("max_drawdown", 0.0)),
                },
                "latest_learning_trades": [],
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error loading LIVE AI learning data from Redis: {e}")
            return {"error": f"AI learning data unavailable - Redis connection failed: {e}"}

    def update_learning_data(self, updates: dict[str, Any]):
        """Update AI learning data in Redis"""
        r = get_shared_redis_sync()
        if r is None:
            logger.warning("Shared Redis client unavailable; skipping AI learning data update")
            return

        try:
            # Update Redis keys with new data
            for key, value in updates.items():
                # Ensure key is a string
                key_str = str(key)
                r.set(f"ai_learning:{key_str}", json.dumps(value))

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error updating AI learning data in Redis: {e}")


# Global instance
# AI learning helper state - using dict to avoid global keyword
_ai_learning_helper_state: dict[str, AILearningDataHelper | None] = {"instance": None}


def get_ai_learning_data() -> dict[str, Any]:
    """Get AI learning data - global function"""
    if _ai_learning_helper_state["instance"] is None:
        _ai_learning_helper_state["instance"] = AILearningDataHelper()
    return _ai_learning_helper_state["instance"].get_ai_learning_data()
