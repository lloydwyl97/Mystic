"""
Mutation Manager for AI Strategy Evolution

Manages the AI mutation system, including strategy evolution cycles,
performance tracking, and system status monitoring.
"""

import asyncio
import json
import logging
import os
import random
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from backend.services.task_manager import task_manager

logger = logging.getLogger(__name__)


class MutationManager:
    """Manages AI strategy mutation and evolution cycles"""

    def __init__(self) -> None:
        self.is_running = False
        self.cycle_count = 0
        self.last_cycle_time = None
        self.cycle_interval = 300  # 5 minutes
        self.enable_ai_generation = True
        self.enable_base_mutation = True
        self.base_strategy = "breakout_ai.json"
        self.mutation_task = None
        self.db_path = os.getenv("SIMULATION_TRADES_DB", "simulation_trades.db")

        # Initialize database
        self._init_database()

    def _init_database(self):
        """Initialize the mutation database"""
        try:
            conn = sqlite3.connect(self.db_path)
            try:
                cursor = conn.cursor()

                # Create ai_mutations table if it doesn't exist
                cursor.execute(
                    """
                    CREATE TABLE IF NOT EXISTS ai_mutations (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        strategy_file TEXT NOT NULL,
                        strategy_type TEXT,
                        strategy_name TEXT,
                        simulated_profit REAL,
                        win_rate REAL,
                        num_trades INTEGER,
                        max_drawdown REAL,
                        sharpe_ratio REAL,
                        promoted INTEGER DEFAULT 0,
                        backtest_results TEXT,
                        cycle_number INTEGER,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """
                )

                conn.commit()
                logger.info("[OK] Mutation database initialized")
            finally:
                conn.close()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error initializing mutation database: {e}")

    def start_mutation_engine(self):
        """Start the mutation engine"""
        if not self.is_running:
            self.is_running = True
            try:
                self.mutation_task = task_manager.create_task_sync(self._mutation_loop(), name="mutation_manager:mutation_loop")
                logger.info("[START] Mutation engine started")
            except RuntimeError:
                # If there's no running loop, log and leave is_running True;
                # caller should start the event loop or call run_single_cycle manually.
                logger.warning("No running event loop; mutation task not started")

    def stop_mutation_engine(self):
        """Stop the mutation engine"""
        if self.is_running:
            self.is_running = False
            if self.mutation_task:
                self.mutation_task.cancel()
            logger.info("Mutation engine stopped")

    async def _mutation_loop(self):
        """Main mutation loop"""
        while self.is_running:
            try:
                await self.run_single_cycle()
                await asyncio.sleep(self.cycle_interval)
            except asyncio.CancelledError:
                break
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception(f"Error in mutation loop: {e}")
                await asyncio.sleep(60)  # Wait 1 minute before retrying

    async def run_single_cycle(self) -> dict[str, Any]:
        """Run a single mutation cycle"""
        try:
            self.cycle_count += 1
            self.last_cycle_time = datetime.now(timezone.utc)

            logger.info(f"Running mutation cycle {self.cycle_count}")

            # Generate new strategies
            new_strategies: list[dict[str, Any]] = []

            if self.enable_ai_generation:
                ai_strategies = await self._generate_ai_strategies()
                new_strategies.extend(ai_strategies)

            if self.enable_base_mutation:
                base_strategies = await self._mutate_base_strategies()
                new_strategies.extend(base_strategies)

            # Evaluate strategies
            evaluated_strategies: list[dict[str, Any]] = []
            for strategy in new_strategies:
                evaluation = await self._evaluate_strategy(strategy)
                evaluated_strategies.append(evaluation)

            # Save to database
            for strategy in evaluated_strategies:
                self._save_mutation(strategy)

            # Promote best strategies
            await self._promote_best_strategies()

            logger.info(f"[OK] Mutation cycle {self.cycle_count} completed")
            return {
                "cycle_number": self.cycle_count,
                "strategies_generated": len(new_strategies),
                "strategies_evaluated": len(evaluated_strategies),
                "timestamp": self.last_cycle_time.isoformat(),
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error in mutation cycle: {e}")
            return {"error": str(e)}

    async def _generate_ai_strategies(self) -> list[dict[str, Any]]:
        """Generate new AI strategies"""
        strategies: list[dict[str, Any]] = []

        # Generate different types of strategies
        strategy_types = ["breakout", "mean_reversion", "momentum", "scalping"]

        for strategy_type in strategy_types:
            strategy = {
                "strategy_type": strategy_type,
                "strategy_name": f"{strategy_type}_ai_v{self.cycle_count}",
                "strategy_file": (f"{strategy_type}_ai_v{self.cycle_count}.json"),
                "created_by": "ai_mutation",
                "ai_version": "v1.0.0",
                "parent": self.base_strategy,
                "description": f"AI-generated {strategy_type} strategy",
                "parameters": self._generate_strategy_parameters(strategy_type),
            }
            strategies.append(strategy)

        return strategies

    async def _mutate_base_strategies(self) -> list[dict[str, Any]]:
        """Mutate existing base strategies"""
        strategies: list[dict[str, Any]] = []

        # Load and mutate base strategy
        base_path = Path("strategies") / self.base_strategy
        if base_path.exists():
            try:
                with base_path.open(encoding="utf-8") as f:
                    base_data = json.load(f)

                # Create mutated version
                mutated_strategy = {
                    "strategy_type": base_data.get("strategy_type", "breakout"),
                    "strategy_name": f"mutated_{self.base_strategy.replace('.json', '')}_v{self.cycle_count}",
                    "strategy_file": f"mutated_{self.base_strategy.replace('.json', '')}_v{self.cycle_count}.json",
                    "created_by": "ai_mutation",
                    "ai_version": "v1.0.0",
                    "parent": self.base_strategy,
                    "description": f"Mutated version of {self.base_strategy}",
                    "parameters": self._mutate_parameters(base_data.get("parameters", {})),
                }
                strategies.append(mutated_strategy)

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception(f"Error mutating base strategy: {e}")

        return strategies

    def _generate_strategy_parameters(self, strategy_type: str) -> dict[str, Any]:
        """Generate parameters for a strategy type"""
        if strategy_type == "breakout":
            return {
                "lookback_period": 20,
                "breakout_threshold": 0.02,
                "stop_loss": 0.05,
                "take_profit": 0.10,
                "volume_threshold": 1.5,
            }
        if strategy_type == "mean_reversion":
            return {
                "sma_period": 50,
                "std_deviation": 2.0,
                "entry_threshold": 0.03,
                "exit_threshold": 0.01,
            }
        if strategy_type == "momentum":
            return {
                "rsi_period": 14,
                "rsi_oversold": 30,
                "rsi_overbought": 70,
                "momentum_period": 10,
            }
        # scalping
        return {
            "ema_fast": 9,
            "ema_slow": 21,
            "profit_target": 0.005,
            "stop_loss": 0.003,
        }

    def _mutate_parameters(self, base_params: dict[str, Any]) -> dict[str, Any]:
        """Mutate existing parameters"""
        mutated_params = base_params.copy()

        # Randomly adjust some parameters
        for key, value in list(mutated_params.items()):
            if isinstance(value, (int, float)):
                # Add/subtract up to 20% of the value
                variation = value * 0.2 * random.uniform(-1, 1)
                mutated_value = value + variation

                # Ensure reasonable bounds
                if key.endswith("_period") and mutated_value < 1:
                    mutated_value = 1
                elif key.endswith("_threshold") and mutated_value < 0:
                    mutated_value = 0.001

                # If original was int, cast back to int for period-like params
                if isinstance(value, int):
                    mutated_value = round(mutated_value)

                mutated_params[key] = mutated_value

        return mutated_params

    async def _evaluate_strategy(self, strategy: dict[str, Any]) -> dict[str, Any]:
        """Evaluate a strategy's performance"""
        # Simulate backtesting
        # Simulate performance metrics
        simulated_profit = random.uniform(-0.15, 0.25)  # -15% to +25%
        win_rate = random.uniform(0.3, 0.7)  # 30% to 70%
        num_trades = random.randint(10, 100)
        max_drawdown = random.uniform(0.05, 0.20)  # 5% to 20%
        sharpe_ratio = random.uniform(-1.0, 2.0)

        return {
            **strategy,
            "simulated_profit": simulated_profit,
            "win_rate": win_rate,
            "num_trades": num_trades,
            "max_drawdown": max_drawdown,
            "sharpe_ratio": sharpe_ratio,
            "promoted": False,
            "cycle_number": self.cycle_count,
            "backtest_results": json.dumps(
                {
                    "trades": [],
                    "equity_curve": [],
                    "metrics": {
                        "profit": simulated_profit,
                        "win_rate": win_rate,
                        "num_trades": num_trades,
                        "max_drawdown": max_drawdown,
                        "sharpe_ratio": sharpe_ratio,
                    },
                }
            ),
        }

    def _save_mutation(self, strategy: dict[str, Any]):
        """Save mutation to database"""
        try:
            conn = sqlite3.connect(self.db_path)
            try:
                cursor = conn.cursor()

                cursor.execute(
                    """
                    INSERT INTO ai_mutations (
                        strategy_file, strategy_type, strategy_name, simulated_profit,
                        win_rate, num_trades, max_drawdown, sharpe_ratio, promoted,
                        backtest_results, cycle_number, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                    (
                        strategy.get("strategy_file"),
                        strategy.get("strategy_type"),
                        strategy.get("strategy_name"),
                        strategy.get("simulated_profit"),
                        strategy.get("win_rate"),
                        strategy.get("num_trades"),
                        strategy.get("max_drawdown"),
                        strategy.get("sharpe_ratio"),
                        int(strategy.get("promoted", False)),
                        strategy.get("backtest_results"),
                        strategy.get("cycle_number"),
                        datetime.now(timezone.utc).isoformat(),
                    ),
                )

                conn.commit()
            finally:
                conn.close()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error saving mutation: {e}")

    async def _promote_best_strategies(self):
        """Promote the best performing strategies"""
        try:
            conn = sqlite3.connect(self.db_path)
            try:
                cursor = conn.cursor()

                # Find best strategies from recent cycles
                cursor.execute(
                    """
                    SELECT id, strategy_file, simulated_profit, win_rate, sharpe_ratio
                    FROM ai_mutations
                    WHERE promoted = 0 AND cycle_number >= ?
                    ORDER BY simulated_profit DESC, sharpe_ratio DESC
                    LIMIT 3
                """,
                    (max(1, self.cycle_count - 5),),
                )

                best_strategies = cursor.fetchall()

                for (
                    strategy_id,
                    strategy_file,
                    profit,
                    win_rate,
                    sharpe,
                ) in best_strategies:
                    # Promote if meets criteria
                    if profit is not None and win_rate is not None and sharpe is not None and profit > 0.05 and win_rate > 0.5 and sharpe > 0.5:
                        cursor.execute(
                            """
                                UPDATE ai_mutations
                                SET promoted = 1
                                WHERE id = ?
                            """,
                            (strategy_id,),
                        )

                        logger.info(f"🏆 Promoted strategy: {strategy_file}")

                conn.commit()
            finally:
                conn.close()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error promoting strategies: {e}")

    def get_mutation_stats(self) -> dict[str, Any]:
        """Get mutation system statistics"""
        default_result = {
            "total_mutations": 0,
            "promoted_mutations": 0,
            "success_rate": 0.0,
            "average_profit": 0.0,
            "cycle_count": self.cycle_count,
            "is_running": self.is_running,
        }
        try:
            conn = sqlite3.connect(self.db_path)
            try:
                cursor = conn.cursor()

                # Get total mutations
                cursor.execute("SELECT COUNT(*) FROM ai_mutations")
                total_row = cursor.fetchone()
                total_mutations = total_row[0] if total_row else 0

                # Get promoted mutations
                cursor.execute("SELECT COUNT(*) FROM ai_mutations WHERE promoted = 1")
                promoted_row = cursor.fetchone()
                promoted_mutations = promoted_row[0] if promoted_row else 0

                # Get average profit
                cursor.execute("SELECT AVG(simulated_profit) FROM ai_mutations WHERE simulated_profit IS NOT NULL")
                avg_row = cursor.fetchone()
                avg_profit = avg_row[0] or 0.0

                # Get success rate
                success_rate = (promoted_mutations / total_mutations * 100) if total_mutations > 0 else 0.0

                return {
                    "total_mutations": total_mutations,
                    "promoted_mutations": promoted_mutations,
                    "success_rate": round(success_rate, 2),
                    "average_profit": round(avg_profit, 4),
                    "cycle_count": self.cycle_count,
                    "is_running": self.is_running,
                }
            finally:
                conn.close()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error getting mutation stats: {e}")
            return default_result

    def get_recent_mutations(self, limit: int = 20) -> list[dict[str, Any]]:
        """Get recent mutations"""
        try:
            conn = sqlite3.connect(self.db_path)
            try:
                cursor = conn.cursor()

                cursor.execute(
                    """
                    SELECT strategy_file, strategy_type, strategy_name, simulated_profit,
                           win_rate, num_trades, promoted, created_at
                    FROM ai_mutations
                    ORDER BY created_at DESC
                    LIMIT ?
                """,
                    (limit,),
                )

                rows = cursor.fetchall()

                mutations: list[dict[str, Any]] = []
                for row in rows:
                    mutations.append(
                        {
                            "strategy_file": row[0],
                            "strategy_type": row[1],
                            "strategy_name": row[2],
                            "profit": row[3],
                            "win_rate": row[4],
                            "num_trades": row[5],
                            "promoted": bool(row[6]),
                            "timestamp": row[7],
                        }
                    )
                return mutations
            finally:
                conn.close()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error getting recent mutations: {e}")
            return []


# Singleton instance
mutation_manager = MutationManager()
