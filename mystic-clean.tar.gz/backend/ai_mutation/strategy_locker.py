"""
Strategy Locker Module

Manages the current live strategy and provides access to strategy files.
Handles strategy locking, unlocking, and status tracking.
"""

import json
import logging
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def get_live_strategy() -> str | None:
    """Get the currently active live strategy file"""
    try:
        # Check for live strategy lock file
        lock_file = Path("strategies/live_strategy.lock")
        if lock_file.exists():
            with lock_file.open() as f:
                strategy_file = f.read().strip()

            # Verify the strategy file exists (try under strategies/ and promoted/)
            strategy_path = Path("strategies") / strategy_file
            if strategy_path.exists():
                return strategy_file

            promoted_path = Path("strategies") / "promoted" / Path(strategy_file).name
            if promoted_path.exists():
                # return in same form as lock contents (likely just the filename)
                return strategy_file

            logger.warning(f"Live strategy file not found: {strategy_file}")
            return None

        # Fallback: look for promoted strategies
        promoted_dir = Path("strategies/promoted")
        if promoted_dir.exists():
            promoted_files = list(promoted_dir.glob("*.json"))
            if promoted_files:
                # Return the most recently modified promoted strategy
                latest_strategy = max(promoted_files, key=lambda f: f.stat().st_mtime)
                return latest_strategy.name

        # Fallback: look for any strategy in main strategies directory
        strategies_dir = Path("strategies")
        if strategies_dir.exists():
            strategy_files = list(strategies_dir.glob("*.json"))
            if strategy_files:
                # Return the most recently modified strategy
                latest_strategy = max(strategy_files, key=lambda f: f.stat().st_mtime)
                result = latest_strategy.name
            else:
                result = None
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"[ERROR] Error getting live strategy: {e}")
        return None
    else:
        return result


def set_live_strategy(strategy_file: str) -> bool:
    """Set the current live strategy"""
    try:
        # Verify strategy file exists (accept promoted and mutated paths too)
        sp = Path(strategy_file)
        if sp.parts and sp.parts[0] == "promoted":
            strategy_path = Path("strategies") / sp
        elif sp.parts and sp.parts[0] == "mutated_strategies":
            strategy_path = Path("mutated_strategies") / Path(*sp.parts[1:])
        else:
            strategy_path = Path("strategies") / sp

        if not strategy_path.exists():
            logger.error(f"Strategy file not found: {strategy_file}")
            return False

        # Create lock file
        lock_file = Path("strategies/live_strategy.lock")
        lock_file.parent.mkdir(parents=True, exist_ok=True)

        with lock_file.open("w") as f:
            # store the name as the basename to be consistent with prior behavior
            f.write(sp.name)

        logger.info(f"[OK] Live strategy set to: {sp.name}")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"[ERROR] Error setting live strategy: {e}")
        return False
    else:
        return True


def unlock_strategy() -> bool:
    """Remove the live strategy lock"""
    try:
        lock_file = Path("strategies/live_strategy.lock")
        if lock_file.exists():
            lock_file.unlink()
            logger.info("🔓 Live strategy lock removed")
            result = True
        else:
            result = False
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"[ERROR] Error unlocking strategy: {e}")
        return False
    else:
        return result


def get_strategy_info(strategy_file: str) -> dict[str, Any] | None:
    """Get detailed information about a strategy"""
    try:
        sp = Path(strategy_file)

        # Resolve the actual file path based on common locations:
        if sp.is_absolute():
            strategy_path = sp
        # promoted/<name> -> strategies/promoted/<name>
        elif sp.parts[0] == "promoted":
            strategy_path = Path("strategies") / sp
        # mutated_strategies/<name> -> mutated_strategies/<name>
        elif sp.parts[0] == "mutated_strategies":
            strategy_path = Path("mutated_strategies") / Path(*sp.parts[1:])
        # strategies/<...> -> strategies/<...>
        elif sp.parts[0] == "strategies":
            strategy_path = Path(*sp.parts)
        # plain filename -> strategies/<filename>
        else:
            strategy_path = Path("strategies") / sp

        if not strategy_path.exists():
            return None

        with strategy_path.open() as f:
            strategy_data = json.load(f)

        # Get file stats
        stat = strategy_path.stat()

        return {
            "file": strategy_file,
            "name": strategy_data.get("strategy_name", Path(strategy_file).name.replace(".json", "")),
            "type": strategy_data.get("strategy_type", "unknown"),
            "parameters": strategy_data.get("parameters", {}),
            "performance": strategy_data.get("performance", {}),
            "metadata": strategy_data.get("metadata", {}),
            "promoted": strategy_data.get("promoted", False),
            "created_at": strategy_data.get("created_at"),
            "modified_at": datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).isoformat(),
            "file_size": stat.st_size,
            "is_live": is_strategy_locked(strategy_file),
        }

    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"[ERROR] Error getting strategy info: {e}")
        return None


def list_available_strategies() -> list:
    """List all available strategies"""
    strategies = []

    try:
        # Check main strategies directory
        strategies_dir = Path("strategies")
        if strategies_dir.exists():
            for strategy_file in strategies_dir.glob("*.json"):
                info = get_strategy_info(strategy_file.name)
                if info:
                    strategies.append(info)

        # Check promoted strategies directory
        promoted_dir = Path("strategies/promoted")
        if promoted_dir.exists():
            for strategy_file in promoted_dir.glob("*.json"):
                info = get_strategy_info(f"promoted/{strategy_file.name}")
                if info:
                    strategies.append(info)

        # Check mutated strategies directory
        mutated_dir = Path("mutated_strategies")
        if mutated_dir.exists():
            for strategy_file in mutated_dir.glob("*.json"):
                info = get_strategy_info(f"mutated_strategies/{strategy_file.name}")
                if info:
                    strategies.append(info)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"[ERROR] Error listing strategies: {e}")
        return []
    else:
        return strategies


def is_strategy_locked(strategy_file: str) -> bool:
    """Check if a strategy is currently locked as live"""
    live_strategy = get_live_strategy()
    if not live_strategy:
        return False

    # Direct match
    if live_strategy == strategy_file:
        return True

    # Compare basenames (handle promoted/foo.json vs foo.json)
    if Path(live_strategy).name == Path(strategy_file).name:
        return True

    # Compare resolved paths under strategies/
    try:
        live_path = Path("strategies") / live_strategy
        candidate_path = Path("strategies") / strategy_file
        if live_path.exists() and candidate_path.exists() and live_path.samefile(candidate_path):
            return True
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        # samefile may raise if files don't exist or are on different devices; ignore
        pass

    return False


def get_strategy_status(strategy_file: str) -> dict[str, Any]:
    """Get comprehensive status of a strategy"""
    try:
        info = get_strategy_info(strategy_file)
        if not info:
            return {"error": f"Strategy not found: {strategy_file}"}

        # Check if strategy is live
        is_live = is_strategy_locked(strategy_file)

        # Get performance metrics
        performance = info.get("performance", {})

        return {
            "file": strategy_file,
            "name": info.get("name"),
            "type": info.get("type"),
            "is_live": is_live,
            "promoted": info.get("promoted", False),
            "performance": {
                "profit": performance.get("profit", 0),
                "win_rate": performance.get("win_rate", 0),
                "num_trades": performance.get("num_trades", 0),
                "max_drawdown": performance.get("max_drawdown", 0),
                "sharpe_ratio": performance.get("sharpe_ratio", 0),
            },
            "metadata": info.get("metadata", {}),
            "created_at": info.get("created_at"),
            "modified_at": info.get("modified_at"),
        }

    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"[ERROR] Error getting strategy status: {e}")
        return {"error": str(e)}


def backup_strategy(strategy_file: str) -> str | None:
    """Create a backup of a strategy file"""
    try:
        sp = Path(strategy_file)

        # Determine actual source path
        if sp.parts and sp.parts[0] == "promoted":
            strategy_path = Path("strategies") / sp
        elif sp.parts and sp.parts[0] == "mutated_strategies":
            strategy_path = Path("mutated_strategies") / Path(*sp.parts[1:])
        else:
            strategy_path = Path("strategies") / sp

        if not strategy_path.exists():
            logger.error(f"Strategy file not found: {strategy_file}")
            return None

        # Create backup directory
        backup_dir = Path("strategies/backup")
        backup_dir.mkdir(parents=True, exist_ok=True)

        # Create backup filename with timestamp using the base name only
        timestamp = datetime.now(tz=timezone.utc).strftime("%Y%m%d_%H%M%S")
        base_name = sp.name.replace(".json", "")
        backup_filename = f"{base_name}_backup_{timestamp}.json"
        backup_path = backup_dir / backup_filename

        # Copy file
        shutil.copy2(strategy_path, backup_path)

        logger.info(f"💼 Strategy backed up: {backup_filename}")
        return str(backup_path)

    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"[ERROR] Error backing up strategy: {e}")
        return None
