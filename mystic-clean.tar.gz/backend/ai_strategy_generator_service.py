#!/usr/bin/env python3
"""
AI Strategy Generator Service
Port 8000 - Standalone AI strategy generation service
"""

import contextlib
import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import uvicorn
from ai_strategy_generator import AIStrategyGenerator
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

import redis
from backend.config.redis_config import get_shared_redis_sync

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID, TRADING_SYMBOLS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

# All Live Data, No Fallback/Hardcoded Data
ALLOWED_SYMBOLS = tuple(TRADING_SYMBOLS)
QUEUE_KEY = "strategy_queue"

if not Path("logs").is_dir():
    with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        Path("logs").mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("logs/ai_strategy_generator.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("ai_strategy_generator_service")

app = FastAPI(
    title="AI Strategy Generator Service",
    description="Standalone AI strategy generation service",
    version="1.0.0",
)


class GenerateRequest(BaseModel):
    strategy_type: str = Field(..., min_length=1)
    symbol: str = Field(..., min_length=3)
    parameters: dict[str, Any] = Field(default_factory=dict)


class GenerateResponse(BaseModel):
    status: str
    strategy: dict[str, Any]
    timestamp: str


class StatusResponse(BaseModel):
    status: str
    redis_connected: bool
    timestamp: str


class StrategiesResponse(BaseModel):
    strategies: list[dict[str, Any]]
    count: int
    timestamp: str


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _normalize_symbol(s: str) -> str:
    return str(s).replace("/", "").upper()


def _validate_symbol(s: str) -> str:
    sym = _normalize_symbol(s)
    if sym not in ALLOWED_SYMBOLS:
        raise HTTPException(status_code=400, detail=f"symbol not allowed: {sym}")
    return sym


def _redis_from_env() -> redis.Redis:
    client = get_shared_redis_sync()
    if client is None:
        msg = "Shared Redis client unavailable"
        raise RuntimeError(msg)
    return client


class AIStrategyGeneratorService:
    def __init__(self) -> None:
        self.generator = AIStrategyGenerator()
        self.running = False
        self.redis_client = _redis_from_env()
        try:
            self.redis_client.ping()
            logger.info(f"[{EXCHANGE_ID}] redis connected")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[{EXCHANGE_ID}] redis connect failed: {e}")

        logger.info(f"[{EXCHANGE_ID}] AI Strategy Generator Service initialized")

    async def start(self) -> None:
        logger.info(f"[{EXCHANGE_ID}] starting AI Strategy Generator Service")
        self.running = True
        await self.generator.start()

    async def stop(self) -> None:
        logger.info(f"[{EXCHANGE_ID}] stopping AI Strategy Generator Service")
        self.running = False
        await self.generator.stop()

    async def generate_strategy(self, strategy_type: str, symbol: str, parameters: dict[str, Any]) -> dict[str, Any] | None:
        sym = _validate_symbol(symbol)
        logger.info(f"[{EXCHANGE_ID}] generating {strategy_type} for {sym}")
        strategy = await self.generator.create_ai_strategy(strategy_type, sym, parameters or {})
        if not strategy:
            logger.warning(f"[{EXCHANGE_ID}] generation failed for {sym}")
            return None
        try:
            sid = strategy.get("id") or strategy.get("strategy_id") or f"{strategy_type}:{sym}:{_now_iso()}"
            self.redis_client.set(f"strategy:{sid}", json.dumps(strategy))
            self.redis_client.lpush(QUEUE_KEY, json.dumps(strategy))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[{EXCHANGE_ID}] redis persist failed: {e}")
        logger.info(f"[{EXCHANGE_ID}] generated strategy {strategy.get('id')}")
        return strategy

    async def get_strategy_status(self, strategy_id: str) -> dict[str, Any] | None:
        try:
            data = self.redis_client.get(f"strategy:{strategy_id}")
            result = json.loads(data) if data else None
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[{EXCHANGE_ID}] get strategy status failed: {e}")
            return None
        else:
            return result

    async def list_strategies(self) -> list[dict[str, Any]]:
        try:
            out: list[dict[str, Any]] = []
            for key in self.redis_client.scan_iter("strategy:*"):
                raw = self.redis_client.get(key)
                if raw:
                    try:
                        out.append(json.loads(raw))
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        continue
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[{EXCHANGE_ID}] list strategies failed: {e}")
            return []
        else:
            return out


# Strategy service state - using dict to avoid global keyword
_strategy_service_state: dict[str, AIStrategyGeneratorService | None] = {"instance": None}


@app.on_event("startup")
async def startup_event() -> None:
    _strategy_service_state["instance"] = AIStrategyGeneratorService()
    try:
        await _strategy_service_state["instance"].start()
        logger.info(f"[{EXCHANGE_ID}] service started")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"[{EXCHANGE_ID}] failed to start service: {e}")
        raise


@app.on_event("shutdown")
async def shutdown_event() -> None:
    if _strategy_service_state["instance"]:
        await _strategy_service_state["instance"].stop()
        logger.info(f"[{EXCHANGE_ID}] service stopped")


# Health endpoint DELETED


@app.get("/status", response_model=StatusResponse)
async def service_status() -> StatusResponse:
    if not _strategy_service_state["instance"]:
        raise HTTPException(status_code=503, detail="service not initialized")
    try:
        ok = bool(_strategy_service_state["instance"].redis_client.ping())
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        ok = False
    return StatusResponse(
        status="running" if _strategy_service_state["instance"].running else "stopped",
        redis_connected=ok,
        timestamp=_now_iso(),
    )


@app.post("/generate", response_model=GenerateResponse)
async def generate_endpoint(req: GenerateRequest) -> GenerateResponse:
    if not _strategy_service_state["instance"]:
        raise HTTPException(status_code=503, detail="service not initialized")
    strategy = await _strategy_service_state["instance"].generate_strategy(req.strategy_type, req.symbol, req.parameters)
    if not strategy:
        raise HTTPException(status_code=500, detail="failed to generate strategy")
    return GenerateResponse(status="success", strategy=strategy, timestamp=_now_iso())


@app.get("/strategies", response_model=StrategiesResponse)
async def list_strategies() -> StrategiesResponse:
    if not _strategy_service_state["instance"]:
        raise HTTPException(status_code=503, detail="service not initialized")
    strategies = await _strategy_service_state["instance"].list_strategies()
    return StrategiesResponse(strategies=strategies, count=len(strategies), timestamp=_now_iso())


@app.get("/strategies/{strategy_id}")
async def get_strategy(strategy_id: str) -> dict[str, Any]:
    if not _strategy_service_state["instance"]:
        raise HTTPException(status_code=503, detail="service not initialized")
    data = await _strategy_service_state["instance"].get_strategy_status(strategy_id)
    if not data:
        raise HTTPException(status_code=404, detail="strategy not found")
    return data


@app.post("/queue/process")
async def process_strategy_queue(max_batch: int = 100) -> dict[str, Any]:
    if not _strategy_service_state["instance"]:
        raise HTTPException(status_code=503, detail="service not initialized")
    processed = 0
    while processed < max_batch:
        item = _strategy_service_state["instance"].redis_client.lpop(QUEUE_KEY)
        if not item:
            break
        try:
            payload = json.loads(item)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            continue

        # Validate required fields before processing - move outside try to avoid TRY301
        stype = str(payload.get("type") or payload.get("strategy_type") or "custom")
        sym_input = payload.get("symbol")
        if not sym_input:
            msg = "symbol is required in queue payload - no fallback/hardcoded symbol"
            raise ValueError(msg)
        sym = str(sym_input)
        params = dict(payload.get("parameters") or {})

        try:
            await _strategy_service_state["instance"].generate_strategy(stype, sym, params)
            processed += 1
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[{EXCHANGE_ID}] queue processing failed: {e}")
            raise HTTPException(status_code=500, detail=str(e)) from e

    return {"status": "success", "processed": processed, "timestamp": _now_iso()}


if __name__ == "__main__":
    port = int(os.getenv("SERVICE_PORT", "8000"))
    logger.info(f"[{EXCHANGE_ID}] starting on port {port}")
    uvicorn.run(app, host="0.0.0.0", port=port, log_level="info", reload=False)
