import contextlib
import json
import os
import time
from pathlib import Path
from typing import Any

import anyio
import httpx
import pandas as pd

import redis
from backend.config.redis_config import get_shared_redis_sync

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID, TRADING_SYMBOLS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

from backend.config.settings import settings
from backend.services.binance_rest_client import BinanceREST
from backend.utils.binance_weight_limiter import BinanceWeightLimiter
from backend.utils.exceptions import TradingError

logger = settings.logging.get_logger(__name__)

BINANCE_KEY = settings.exchange.binance_us_api_key
BINANCE_SECRET = settings.exchange.binance_us_secret_key
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
DISCORD_WEBHOOK_URL = os.getenv("DISCORD_WEBHOOK")
TP_PERCENT = float(os.getenv("TAKE_PROFIT_PCT", "0.15"))
TS_PERCENT = float(os.getenv("TRAIL_STOP_PCT", "0.03"))
# All Live Data, No Fallback/Hardcoded Data
# Use first symbol from trading_universe (live data)
BINANCE_SYMBOL = os.getenv("SYMBOL_PAIR_BINANCE") or (TRADING_SYMBOLS[0] if TRADING_SYMBOLS else None)
if not BINANCE_SYMBOL:
    msg = "SYMBOL_PAIR_BINANCE environment variable is required - no fallback/hardcoded symbol"
    raise RuntimeError(msg)
USD_AMOUNT = float(os.getenv("USD_TRADE_AMOUNT", "50"))

# AI Engine timing constants
AI_ENGINE_CHECK_INTERVAL = int(os.getenv("AI_ENGINE_CHECK_INTERVAL", "60"))  # 60 seconds
AI_ENGINE_ERROR_RECOVERY_DELAY = int(os.getenv("AI_ENGINE_ERROR_RECOVERY_DELAY", "300"))  # 5 minutes

# Position state - using dict to avoid global keyword
_position_state: dict[str, Any | None] = {"position": None}


def save_position_file(data: dict[str, Any]) -> None:
    position_path = Path("position.json")
    with position_path.open("w") as f:
        json.dump(data, f, indent=2)


def update_position(current_price: float | None) -> None:
    if _position_state["position"]:
        _position_state["position"]["current_price"] = current_price
        save_position_file(_position_state["position"])
    else:
        save_position_file({})


def send_alert(msg: str) -> None:
    try:
        if TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID:
            try:
                httpx.post(
                    f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage",
                    data={"chat_id": TELEGRAM_CHAT_ID, "text": msg},
                    timeout=10,
                )
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception(f"Telegram alert failed: {e}")

        if DISCORD_WEBHOOK_URL and DISCORD_WEBHOOK_URL != "your_discord_webhook_url_here":
            try:
                httpx.post(DISCORD_WEBHOOK_URL, json={"content": msg}, timeout=10)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception(f"Discord alert failed: {e}")

        logger.info(f"Alert sent: {msg}")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to send alert: {e}")


def _get_shared_redis() -> redis.Redis | None:
    """Fetch shared sync Redis client; tolerate failures to keep trading live."""
    try:
        return get_shared_redis_sync()
    except Exception as e:
        logger.debug("Shared Redis unavailable: %s", e)
        return None


def get_price_binance(symbol: str = BINANCE_SYMBOL) -> float | None:
    try:
        # Cache-only quick path via shared pool (prevents connection leaks)
        if redis is not None:
            r = _get_shared_redis()
            if r is not None:
                try:
                    cached = r.get(f"price:{symbol}")
                    if cached:
                        return float(cached)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.debug(f"Redis price lookup failed: {e}")

        # Fallback to direct API call using async client run in sync context
        async def _req():
            limiter = await BinanceWeightLimiter.create()
            client = BinanceREST(limiter)
            return await client.price(symbol)

        result = anyio.run(_req)
        if result and isinstance(result, dict) and "price" in result:
            price = float(result["price"])
            # Cache for 30 seconds if redis available
            try:
                if redis is not None:
                    r = _get_shared_redis()
                    if r is not None:
                        r.setex(f"price:{symbol}", 30, str(price))
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.debug(f"Redis setex failed: {e}")
            result = price
        else:
            result = None
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get Binance price for {symbol}: {e}")
        return None
    else:
        return result


def binance_market_order(symbol: str, side: str, quote_qty: float) -> dict[str, Any]:
    try:

        async def _req():
            limiter = await BinanceWeightLimiter.create()
            client = BinanceREST(limiter)
            return await client.order_market(symbol, side.upper(), quoteOrderQty=str(quote_qty))

        result = anyio.run(_req)
        if result is None:
            msg = "order_market returned None"
            raise TradingError(msg)
        send_alert(f"{side} Binance: ${quote_qty}\n{result}")
        logger.info(f"Binance {side} order executed: {symbol} ${quote_qty}")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        error_msg = f"ERROR: Binance {side} Error: {e}"
        with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            send_alert(error_msg)
        logger.exception(f"Binance {side} order failed: {e}")
        return {"error": str(e)}
    else:
        return result


def check_for_buy_signal() -> bool:
    """Live buy signal logic using RSI and MACD from Binance price data"""
    try:

        async def _req():
            limiter = await BinanceWeightLimiter.create()
            client = BinanceREST(limiter)
            return await client.klines(BINANCE_SYMBOL, "1h", limit=100)

        klines = anyio.run(_req)

        if not klines or len(klines) < 50:
            return False

        # Convert to DataFrame
        df = pd.DataFrame(
            klines,
            columns=[
                "timestamp",
                "open",
                "high",
                "low",
                "close",
                "volume",
                "close_time",
                "quote_volume",
                "trades",
                "taker_buy_base",
                "taker_buy_quote",
                "ignore",
            ],
        )

        # Convert to numeric
        for col in ["open", "high", "low", "close", "volume"]:
            df[col] = pd.to_numeric(df[col])

        # Calculate RSI
        delta = df["close"].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))

        # Calculate MACD
        ema12 = df["close"].ewm(span=12).mean()
        ema26 = df["close"].ewm(span=26).mean()
        macd = ema12 - ema26
        signal_line = macd.ewm(span=9).mean()

        # Buy signal: RSI < 30 (oversold) and MACD > signal (bullish crossover)
        current_rsi = float(rsi.iloc[-1])
        current_macd = float(macd.iloc[-1])
        current_signal = float(signal_line.iloc[-1])

        buy_signal = current_rsi < 30 and current_macd > current_signal

        if buy_signal:
            logger.info(f"BUY SIGNAL: RSI={current_rsi:.2f}, MACD={current_macd:.6f}, Signal={current_signal:.6f}")

        return bool(buy_signal)

    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error checking buy signal: {e}")
        return False


def get_position_status() -> dict[str, Any]:
    """Get current position status - Binance US only"""
    if _position_state["position"]:
        current_price = get_price_binance()
        if current_price is not None:
            entry_price = _position_state["position"]["entry_price"]
            peak_price = _position_state["position"]["peak_price"]
            current_pnl = ((current_price - entry_price) / entry_price) * 100
            return {
                "active": True,
                "exchange": EXCHANGE_ID,
                "entry_price": entry_price,
                "current_price": current_price,
                "peak_price": peak_price,
                "pnl_percent": current_pnl,
                "take_profit_target": entry_price * (1 + TP_PERCENT),
                "trailing_stop": peak_price * (1 - TS_PERCENT),
            }
    return {"active": False}


def trade_loop() -> None:
    logger.info("Starting AI trade engine - Binance US only...")
    logger.info(f"Configuration: {BINANCE_SYMBOL} ${USD_AMOUNT}")
    logger.info(f"Take Profit: {TP_PERCENT * 100}%, Trailing Stop: {TS_PERCENT * 100}%")

    while True:
        try:
            signal = check_for_buy_signal()
            b_price = get_price_binance()

            if b_price is None:
                logger.warning("Failed to get Binance price, skipping iteration")
                # Wait before retry - sync sleep OK for standalone trading script
                time.sleep(AI_ENGINE_CHECK_INTERVAL)
                update_position(None)
                continue

            if not _position_state["position"] and signal:
                logger.info("Buy signal detected, executing Binance order...")
                result = binance_market_order(BINANCE_SYMBOL, "BUY", USD_AMOUNT)
                if isinstance(result, dict) and "error" not in result:
                    _position_state["position"] = {
                        "entry_price": b_price,
                        "exchange": EXCHANGE_ID,
                        "peak_price": b_price,
                    }
                    logger.info(f"Position opened: Binance {BINANCE_SYMBOL} @ ${b_price}")
                else:
                    logger.error(f"Failed to open position: {result}")

            elif _position_state["position"]:
                # Update peak price
                _position_state["position"]["peak_price"] = max(_position_state["position"].get("peak_price", b_price), b_price)

                # Check exit conditions
                entry_price = _position_state["position"]["entry_price"]
                peak_price = _position_state["position"]["peak_price"]

                # Take profit check
                if b_price >= entry_price * (1 + TP_PERCENT):
                    logger.info(f"Take profit hit: {b_price} >= {entry_price * (1 + TP_PERCENT)}")
                    result = binance_market_order(BINANCE_SYMBOL, "SELL", USD_AMOUNT)
                    if isinstance(result, dict) and "error" not in result:
                        _position_state["position"] = None
                        logger.info(f"Position closed: Take profit at ${b_price}")
                    else:
                        logger.error(f"Failed to close position: {result}")

                # Trailing stop check
                elif b_price <= peak_price * (1 - TS_PERCENT):
                    logger.info(f"Trailing stop hit: {b_price} <= {peak_price * (1 - TS_PERCENT)}")
                    result = binance_market_order(BINANCE_SYMBOL, "SELL", USD_AMOUNT)
                    if isinstance(result, dict) and "error" not in result:
                        _position_state["position"] = None
                        logger.info(f"Position closed: Trailing stop at ${b_price}")
                    else:
                        logger.error(f"Failed to close position: {result}")

            update_position(b_price)

            # Status logging
            if _position_state["position"]:
                status = get_position_status()
                if status.get("active"):
                    logger.info(f"Position active: {status['exchange']} @ ${status['entry_price']:.2f} | Current: ${status['current_price']:.2f} | PnL: {status['pnl_percent']:.2f}%")
                else:
                    logger.info(f"No Position | Binance: ${b_price:.2f}")
            else:
                logger.info(f"No Position | Binance: ${b_price:.2f}")

            # Check every minute for new trading opportunities
            time.sleep(AI_ENGINE_CHECK_INTERVAL)

        except KeyboardInterrupt:
            logger.info("Trade loop interrupted by user")
            break
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Trade loop error: {e}")
            # Error recovery delay before retry
            time.sleep(AI_ENGINE_ERROR_RECOVERY_DELAY)


def test_connections() -> None:
    """Test Binance US connection"""
    try:
        b_price = get_price_binance()
        if b_price:
            logger.info(f"SUCCESS: Binance US price: ${b_price}")
        else:
            logger.error("FAILED: Binance US price feed failed")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Connection test failed: {e}")


if __name__ == "__main__":
    test_connections()
    trade_loop()
