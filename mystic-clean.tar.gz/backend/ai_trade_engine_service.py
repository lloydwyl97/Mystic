#!/usr/bin/env python3
"""
AI Trade Engine Service
Port 8000 - Standalone AI trading engine service
"""

import asyncio
import contextlib
import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import uvicorn

import redis

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID, TRADING_SYMBOLS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

# Ensure local imports work
from ai_trade_engine import AITradeEngine
from fastapi import FastAPI, HTTPException

from backend.services.task_manager import task_manager

# Use trading_universe symbols (live data)
ALLOWED_SYMBOLS = tuple(TRADING_SYMBOLS)
QUEUE_KEY = "ai_trade_queue"
RESULTS_KEY = "trade_results"

if not Path("logs").is_dir():
    with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        Path("logs").mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("logs/ai_trade_engine.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("ai_trade_engine_service")


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _normalize_symbol(s: str) -> str:
    return str(s).replace("/", "").upper()


def _validate_symbol(s: str) -> str:
    sym = _normalize_symbol(s)
    if sym not in ALLOWED_SYMBOLS:
        raise HTTPException(status_code=400, detail=f"symbol not allowed: {sym}")
    return sym


def _redis_from_env() -> redis.Redis:
    # Use shared Redis connection pool to prevent connection exhaustion
    from backend.config.redis_config import get_shared_redis_sync

    return get_shared_redis_sync()


def _b(s: str) -> bytes:
    return s.encode()


def _decode(b: bytes | None) -> str | None:
    if b is None:
        return None
    try:
        return b.decode()
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        return None


app = FastAPI(
    title="AI Trade Engine Service",
    description="Standalone AI trading engine service",
    version="1.0.0",
)


class AITradeEngineService:
    def __init__(self) -> None:
        self.trade_engine = AITradeEngine()
        self.running = False
        self.trade_history: list[dict[str, Any]] = []
        self.redis_client = _redis_from_env()
        try:
            self.redis_client.ping()
            logger.info(f"[{EXCHANGE_ID}] redis connected")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[{EXCHANGE_ID}] redis connect failed: {e}")
        self._monitor_task: asyncio.Task | None = None
        logger.info(f"[{EXCHANGE_ID}] AI Trade Engine Service initialized")

    async def start(self) -> None:
        logger.info(f"[{EXCHANGE_ID}] starting AI Trade Engine Service")
        self.running = True
        await self.trade_engine.start()
        self._monitor_task = await task_manager.create_task(self.trade_monitor_loop(), name="ai_trade_engine_service:trade_monitor_loop")

    async def stop(self) -> None:
        logger.info(f"[{EXCHANGE_ID}] stopping AI Trade Engine Service")
        self.running = False
        try:
            if self._monitor_task:
                self._monitor_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await self._monitor_task
        finally:
            await self.trade_engine.stop()

    async def trade_monitor_loop(self) -> None:
        logger.info(f"[{EXCHANGE_ID}] trade monitor loop started")
        while self.running:
            try:
                req_bytes = self.redis_client.lpop(_b(QUEUE_KEY))
                if req_bytes:
                    req_str = _decode(req_bytes)
                    if not req_str:
                        await asyncio.sleep(1)
                        continue
                    try:
                        request = json.loads(req_str)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        await asyncio.sleep(1)
                        continue
                    await self.process_trade_request(request)
                await asyncio.sleep(5)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception(f"[{EXCHANGE_ID}] trade monitor loop error: {e}")
                await asyncio.sleep(30)

    async def process_trade_request(self, request_data: dict[str, Any]) -> dict[str, Any]:
        try:
            symbol = _validate_symbol(request_data.get("symbol", "ETHUSDT"))
            side = str(request_data.get("side", "BUY")).upper()
            quantity = float(request_data.get("quantity", 0.01))
            price = float(request_data["price"]) if request_data.get("price") is not None else None
            strategy_id = str(request_data.get("strategy_id") or "unknown")

            logger.info(f"[{EXCHANGE_ID}] processing trade {symbol} {side} {quantity}")

            result = await self.trade_engine.execute_trade(symbol, side, quantity, price)

            trade_record: dict[str, Any] = {
                "strategy_id": strategy_id,
                "symbol": symbol,
                "side": side,
                "quantity": quantity,
                "price": price,
                "result": result,
                "timestamp": _now_iso(),
                "status": ("success" if result and isinstance(result, dict) and "error" not in result else "failed"),
            }

            self.trade_history.append(trade_record)
            try:
                self.redis_client.set(
                    _b(f"trade:{strategy_id}:{int(time.time())}"),
                    _b(json.dumps(trade_record)),
                )
                self.redis_client.lpush(_b(RESULTS_KEY), _b(json.dumps(trade_record)))
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception(f"[{EXCHANGE_ID}] redis write failed: {e}")

            logger.info(f"[{EXCHANGE_ID}] trade processed: {trade_record['status']}")
        except HTTPException:
            raise
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[{EXCHANGE_ID}] process trade error: {e}")
            trade_record = {
                "strategy_id": str(request_data.get("strategy_id") or "unknown"),
                "error": str(e),
                "timestamp": _now_iso(),
                "status": "failed",
            }
            self.trade_history.append(trade_record)
            return trade_record
        else:
            return trade_record

    async def execute_trade(self, symbol: str, side: str, quantity: float, price: float | None = None) -> dict[str, Any]:
        symbol_ok = _validate_symbol(symbol)
        side_ok = side.upper()
        logger.info(f"[{EXCHANGE_ID}] executing trade {symbol_ok} {side_ok} {quantity}")
        result = await self.trade_engine.execute_trade(
            symbol_ok,
            side_ok,
            float(quantity),
            price if price is None else float(price),
        )
        trade_record: dict[str, Any] = {
            "symbol": symbol_ok,
            "side": side_ok,
            "quantity": float(quantity),
            "price": price if price is None else float(price),
            "result": result,
            "timestamp": _now_iso(),
            "status": ("success" if result and isinstance(result, dict) and "error" not in result else "failed"),
        }
        self.trade_history.append(trade_record)
        logger.info(f"[{EXCHANGE_ID}] trade executed: {trade_record['status']}")
        return trade_record

    async def get_trade_history(self, limit: int = 100) -> list[dict[str, Any]]:
        try:
            return self.trade_history[-limit:] if self.trade_history else []
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[{EXCHANGE_ID}] get history error: {e}")
            return []

    async def get_strategy_trades(self, strategy_id: str) -> list[dict[str, Any]]:
        try:
            out: list[dict[str, Any]] = []
            for key in self.redis_client.scan_iter(match=_b(f"trade:{strategy_id}:*")):
                raw = self.redis_client.get(key)
                s = _decode(raw)
                if not s:
                    continue
                try:
                    out.append(json.loads(s))
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    continue
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[{EXCHANGE_ID}] get strategy trades error: {e}")
            return []
        else:
            return out

    async def get_portfolio_status(self) -> dict[str, Any]:
        try:
            portfolio = await self.trade_engine.get_portfolio()
            return {"portfolio": portfolio, "timestamp": _now_iso()}
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[{EXCHANGE_ID}] portfolio status error: {e}")
            return {"error": str(e)}


# Trade service state - using dict to avoid global keyword
_trade_service_state: dict[str, AITradeEngineService | None] = {"instance": None}


@app.on_event("startup")
async def startup_event() -> None:
    _trade_service_state["instance"] = AITradeEngineService()
    try:
        await _trade_service_state["instance"].start()
        logger.info(f"[{EXCHANGE_ID}] AI Trade Engine Service started")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"[{EXCHANGE_ID}] failed to start: {e}")
        raise


@app.on_event("shutdown")
async def shutdown_event() -> None:
    if _trade_service_state["instance"]:
        await _trade_service_state["instance"].stop()
        logger.info(f"[{EXCHANGE_ID}] AI Trade Engine Service stopped")


# Health endpoint DELETED


@app.get("/status")
async def service_status():
    if not _trade_service_state["instance"]:
        raise HTTPException(status_code=503, detail="service not initialized")
    try:
        ok = bool(_trade_service_state["instance"].redis_client.ping())
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        ok = False
    return {
        "status": "running" if _trade_service_state["instance"].running else "stopped",
        "redis_connected": ok,
        "trade_count": len(_trade_service_state["instance"].trade_history) if _trade_service_state["instance"] else 0,
        "timestamp": _now_iso(),
    }


@app.post("/trade")
async def execute_trade(
    symbol: str,
    side: str,
    quantity: float,
    price: float | None = None,
    strategy_id: str | None = None,
):
    if not _trade_service_state["instance"]:
        raise HTTPException(status_code=503, detail="service not initialized")
    trade_record = await _trade_service_state["instance"].execute_trade(symbol, side, quantity, price)
    if strategy_id:
        trade_record["strategy_id"] = strategy_id
    return {"status": "success", "trade": trade_record, "timestamp": _now_iso()}


@app.get("/trades")
async def get_trades(limit: int = 100):
    if not _trade_service_state["instance"]:
        raise HTTPException(status_code=503, detail="service not initialized")
    trades = await _trade_service_state["instance"].get_trade_history(limit)
    return {"trades": trades, "count": len(trades), "timestamp": _now_iso()}


@app.get("/trades/{strategy_id}")
async def get_strategy_trades(strategy_id: str):
    if not _trade_service_state["instance"]:
        raise HTTPException(status_code=503, detail="service not initialized")
    trades = await _trade_service_state["instance"].get_strategy_trades(strategy_id)
    return {
        "strategy_id": strategy_id,
        "trades": trades,
        "count": len(trades),
        "timestamp": _now_iso(),
    }


@app.get("/portfolio")
async def get_portfolio():
    if not _trade_service_state["instance"]:
        raise HTTPException(status_code=503, detail="service not initialized")
    return await _trade_service_state["instance"].get_portfolio_status()


@app.post("/queue/process")
async def process_trade_queue(max_batch: int = 100):
    if not _trade_service_state["instance"]:
        raise HTTPException(status_code=503, detail="service not initialized")
    processed = 0
    try:
        while processed < max_batch:
            req_b = _trade_service_state["instance"].redis_client.lpop(_b(QUEUE_KEY))
            if not req_b:
                break
            req_s = _decode(req_b)
            if not req_s:
                continue
            try:
                data = json.loads(req_s)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                continue
            await _trade_service_state["instance"].process_trade_request(data)
            processed += 1
        return {"status": "success", "processed": processed, "timestamp": _now_iso()}
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"[{EXCHANGE_ID}] queue processing failed: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


if __name__ == "__main__":
    port = int(os.getenv("SERVICE_PORT", "8000"))
    logger.info(f"[{EXCHANGE_ID}] starting on port {port}")
    uvicorn.run(app=app, host="0.0.0.0", port=port, log_level="info", reload=False)
