#!/usr/bin/env python3
"""
AI Training Data Pipeline
Collects real trade data and market signals for AI learning and model training
"""

import asyncio
import json
import logging
import os
import pickle
import shutil
import time
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from backend.config.redis_config import get_shared_redis_async, get_shared_redis_sync
from backend.config.trading_universe import TOP10_COINS, TRADING_SYMBOLS
from backend.services.market_data import market_data_service

# Optional import for learning metrics
try:
    from ai_learning_report import AILearningReport
except ImportError:
    AILearningReport = None

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import EXCHANGE_ID from trading_universe: {e}"
    raise RuntimeError(msg) from e

from backend.services.task_manager import task_manager

# Lazy imports for optional AI services (may not be available in all deployments)
try:
    from ai_learning_report import AILearningReport
except ImportError:
    AILearningReport = None  # type: ignore[assignment, misc]

try:
    from backend.modules.ai.ai_model_versioning import get_ai_model_versioning
except ImportError:
    get_ai_model_versioning = None  # type: ignore[assignment, misc]

try:
    from backend.modules.market.binance_data_fetcher import _to_ccxt_symbol
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import _to_ccxt_symbol from binance_data_fetcher: {e}"
    raise RuntimeError(msg) from e

from backend.services.canonical_cache import canonical_cache
from backend.services.smart_training_data_manager import smart_training_data_manager
from backend.utils.path_helpers import ensure_model_directories

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _now_dt() -> datetime:
    return datetime.now(timezone.utc)


def _format_float(v: Any) -> float:
    try:
        if isinstance(v, (int, float)):
            result = float(v)
        elif isinstance(v, str):
            result = float(v.replace("%", "").replace(",", "").strip())
        else:
            result = 0.0
    except (ValueError, TypeError, AttributeError):
        return 0.0
    else:
        return result


def _decode(b: bytes | None) -> str | None:
    if b is None:
        return None

    try:
        return b.decode()
    except (UnicodeDecodeError, AttributeError, TypeError):
        return None


# RF: per-symbol StandardScaler + one shared RandomForest (see ai_signal_generator inference).
MIN_RF_TRAIN_SAMPLES = 100
MIN_SCALER_ROWS_PER_SYMBOL = 5
_FEATURE_DIM = 124


def _canonical_training_pair_symbol(raw: str) -> str:
    """Map cache base (e.g. BTC) or pair to TRADING_SYMBOLS form (e.g. BTCUSDT)."""
    s = (raw or "").strip().upper()
    if s.endswith("USDT"):
        return s
    try:
        idx = TOP10_COINS.index(s)
    except ValueError:
        return f"{s}USDT"
    return TRADING_SYMBOLS[idx]


LABEL_LOOKAHEAD = int(os.getenv("RF_LABEL_LOOKAHEAD", "30"))
LABEL_MIN_MOVE_PCT = float(os.getenv("RF_LABEL_MIN_MOVE_PCT", "0.003"))


def build_xy_arrays_per_symbol(rows: list[dict[str, Any]]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Build X, y, sym_row from labeled samples.

    Label uses price N samples ahead (LABEL_LOOKAHEAD) to align the prediction
    horizon with the actual trading hold period (~60-120 min).  Samples where
    the price moved less than LABEL_MIN_MOVE_PCT are discarded (ambiguous).
    """
    from collections import defaultdict

    by_sym: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for r in rows:
        if not isinstance(r, dict) or "features" not in r:
            continue
        sym_raw = r.get("symbol")
        if not sym_raw:
            continue
        sym_k = _canonical_training_pair_symbol(str(sym_raw))
        by_sym[sym_k].append(r)

    x_parts: list[np.ndarray] = []
    y_parts: list[np.ndarray] = []
    sym_parts: list[np.ndarray] = []
    for sym_k, items in by_sym.items():
        items.sort(key=lambda x: (str(x.get("timestamp") or ""), str(x.get("collection_time") or "")))
        feats = [it["features"] for it in items]
        if not feats or any(not isinstance(f, (list, tuple)) or len(f) != _FEATURE_DIM for f in feats):
            continue
        xs = np.asarray(feats, dtype=np.float64)
        n = xs.shape[0]
        ahead = min(LABEL_LOOKAHEAD, n - 1)
        if ahead < 2:
            continue
        keep_x = []
        keep_y = []
        for i in range(n - ahead):
            cur_price = xs[i, 0]
            fut_price = xs[i + ahead, 0]
            if cur_price <= 0:
                continue
            move = (fut_price - cur_price) / cur_price
            if abs(move) < LABEL_MIN_MOVE_PCT:
                continue
            keep_x.append(xs[i])
            keep_y.append(1 if move > 0 else 0)
        if len(keep_x) < 10:
            continue
        x_parts.append(np.array(keep_x))
        y_parts.append(np.array(keep_y, dtype=np.int64))
        sym_parts.append(np.array([sym_k] * len(keep_x), dtype=object))
    if not x_parts:
        return np.array([]), np.array([]), np.array([])
    return np.vstack(x_parts), np.concatenate(y_parts), np.concatenate(sym_parts)


def transform_rows_per_symbol_scalers(
    X: np.ndarray,
    sym_row: np.ndarray,
    scalers_by_symbol: dict[str, StandardScaler],
    global_scaler: StandardScaler,
) -> np.ndarray:
    out = np.empty_like(X, dtype=np.float64)
    for i in range(X.shape[0]):
        s = str(sym_row[i])
        sc = scalers_by_symbol.get(s) or global_scaler
        out[i] = sc.transform(X[i : i + 1])[0]
    return out


def fit_per_symbol_scalers_for_rf(
    X_train: np.ndarray,
    sym_train: np.ndarray,
    *,
    min_rows: int = MIN_SCALER_ROWS_PER_SYMBOL,
) -> tuple[dict[str, StandardScaler], StandardScaler]:
    """Fit global scaler on all train rows; per-symbol scalers when a symbol has >= min_rows."""
    global_scaler = StandardScaler()
    global_scaler.fit(X_train)

    per_sym: dict[str, StandardScaler] = {}
    for s in np.unique(sym_train):
        sk = str(s)
        mask = sym_train == s
        sub = X_train[mask]
        if sub.shape[0] >= min_rows:
            sc = StandardScaler()
            sc.fit(sub)
            per_sym[sk] = sc
        else:
            per_sym[sk] = global_scaler

    scalers_out: dict[str, StandardScaler] = {}
    for sym in TRADING_SYMBOLS:
        scalers_out[sym] = per_sym.get(sym, global_scaler)
    return scalers_out, global_scaler


class AITrainingDataPipeline:
    """Collects and processes training data for AI models"""

    def __init__(self, cache: Any = None) -> None:
        self.cache = cache or canonical_cache
        self.is_running = False
        self._current_accuracy = 0.0  # Store current accuracy from enhanced models
        self._start_time = time.time()
        # Track background tasks for proper cleanup
        self._tasks: list[asyncio.Task[Any]] = []

        # Training data storage - use path helpers for consistency
        directories = ensure_model_directories()
        self.training_data_dir = directories["training_data"]
        self.model_versions_dir = directories["versions"]

        # Ensure directories exist
        Path(self.training_data_dir).mkdir(parents=True, exist_ok=True)
        Path(self.model_versions_dir).mkdir(parents=True, exist_ok=True)

        # Data collection settings - BALANCED for sustainable 24/7 operation
        # Indicators don't change meaningfully faster than 10 seconds
        self.collection_interval = int(os.getenv("AI_COLLECTION_INTERVAL", "10"))  # Collect every 10 seconds
        self.feature_window = int(os.getenv("AI_FEATURE_WINDOW", "10000"))  # 10K features per symbol
        self.prediction_horizon = 48  # Hours to predict ahead
        self.continuous_learning_enabled = True
        self.learning_frequency = int(os.getenv("AI_LEARNING_FREQUENCY", "900"))  # Train every 15 minutes (900s)
        self.last_retrain_time = 0
        self.feature_count = 124  # Enhanced with 124 comprehensive features
        self.feature_importance_threshold = 0.01  # Minimum importance threshold for features

        # Training data cache - BALANCED for memory efficiency
        self.training_cache: dict[str, list[dict[str, Any]]] = {}
        self.max_training_cache_size = int(os.getenv("AI_MAX_CACHE_SIZE", "100000"))  # 100K per symbol
        self.last_collection: dict[str, str] = {}

        # Load existing training data from disk on startup
        self._load_existing_training_data()

        # Model performance tracking - BALANCED for efficiency
        self.model_performance: dict[str, dict[str, Any]] = {}
        self.training_history: list[dict[str, Any]] = []
        self.max_training_history = int(os.getenv("AI_MAX_TRAINING_HISTORY", "5000"))  # 5K sessions
        self.performance_metrics = {
            "total_training_sessions": 0,
            "successful_trainings": 0,
            "failed_trainings": 0,
            "average_accuracy": 0.0,
            "best_accuracy": 0.0,
            "last_training_time": None,
            "models_trained": 0,
        }

        # Model versioning - BALANCED to keep best models, prune old ones
        self.model_versions: dict[str, list[dict[str, Any]]] = {}
        self.max_model_versions = int(os.getenv("AI_MAX_MODEL_VERSIONS", "50"))  # Keep 50 best models
        self.current_versions: dict[str, str] = {}
        self._last_prune_time = 0  # Track when we last pruned models

    def _load_existing_training_data(self) -> None:
        """Load existing training data from disk on startup"""
        try:
            training_data_path = Path(self.training_data_dir)
            if not training_data_path.exists():
                logger.info("No existing training data directory found")
                return

            # Load data from all _latest.json files
            loaded_samples = 0
            for file_path in training_data_path.glob("*_latest.json"):
                try:
                    with file_path.open() as f:
                        symbol_data = json.load(f)

                    # Extract symbol from filename (remove _latest.json suffix)
                    symbol = file_path.stem.replace("_latest", "").replace("_", "/")

                    if symbol_data and isinstance(symbol_data, list):
                        training_pair = _canonical_training_pair_symbol(symbol)
                        for row in symbol_data:
                            if isinstance(row, dict) and not row.get("symbol"):
                                row["symbol"] = training_pair
                        self.training_cache[symbol] = symbol_data[-self.max_training_cache_size :]
                        loaded_samples += len(self.training_cache[symbol])

                        # Update last collection time
                        if self.training_cache[symbol]:
                            latest_entry = max(self.training_cache[symbol], key=lambda x: x.get("timestamp", ""))
                            self.last_collection[symbol] = latest_entry.get("collection_time", _now_iso())

                        logger.info(f"Loaded {len(self.training_cache[symbol])} training samples for {symbol}")

                except (json.JSONDecodeError, OSError, ValueError) as e:
                    logger.warning(f"Failed to load training data from {file_path}: {e}")
                    continue

            if loaded_samples > 0:
                logger.info(f"Successfully loaded {loaded_samples} total training samples from disk")
            else:
                logger.info("No training data found on disk")

        except Exception as e:
            logger.exception(f"Error loading existing training data: {e}")

    def _normalize_symbol(self, symbol: str | None) -> str | None:
        """Normalize symbol to order book key format (e.g., BTC from BTCUSDT)."""
        if not symbol:
            return None
        normalized = str(symbol).upper().replace("/", "").replace("-", "").strip()
        if normalized.endswith("USDT"):
            return normalized[:-4] or None
        if normalized.endswith("USD"):
            return normalized[:-3] or None
        return normalized or None

    async def _fetch_order_book_features(self, symbol: str | None) -> dict[str, float] | None:
        """Fetch latest order book microstructure features stored in Redis."""
        normalized = self._normalize_symbol(symbol)
        if not normalized:
            return None
        try:
            redis_client = get_shared_redis_async()
            if redis_client is None:
                logger.debug("Shared Redis async client unavailable for order book lookup")
                return None

            key = f"orderbook:{normalized}"
            raw = await redis_client.hgetall(key)
            if not raw:
                logger.debug("No order book hash found for %s", normalized)
                return None

            parsed: dict[str, float] = {}
            for field, value in raw.items():
                try:
                    parsed[field] = float(value)
                except (TypeError, ValueError):
                    continue
        except Exception as error:
            logger.debug("Failed to fetch order book features for %s: %s", normalized, error)
            return None
        else:
            return parsed or None

    async def start(self) -> None:
        """Start the training data collection process"""
        logger.info("Starting AI Training Data Pipeline with Continuous Learning")
        self.is_running = True
        self._start_time = time.time()
        try:
            # Start background tasks with proper exception handling
            task1 = await task_manager.create_task(self._collection_loop(), name="ai_training_pipeline:collection_loop")
            self._tasks.append(task1)
            task2 = await task_manager.create_task(self._continuous_learning_loop(), name="ai_training_pipeline:continuous_learning_loop")
            self._tasks.append(task2)
        except (RuntimeError, AttributeError, TypeError, ValueError) as e:
            logger.exception(f"Error starting training pipeline: {e}")
            self.is_running = False
            raise

    async def _collection_loop(self) -> None:
        """Background task to collect training data at regular intervals"""
        attempt = 0
        max_attempts = 5
        backoff_seconds = 60

        while self.is_running:
            try:
                await self.collect_training_data()
                await self._train_lightweight_models(features=[])
                attempt = 0  # Reset attempt counter on success

                # Wait for next collection interval
                await asyncio.sleep(self.collection_interval)

            except (ValueError, TypeError, AttributeError, RuntimeError, ConnectionError) as e:
                attempt += 1
                logger.exception(f"Error in training data collection (attempt {attempt}/{max_attempts}): {e}")

                if attempt >= max_attempts:
                    logger.exception(f"Failed to collect training data after {max_attempts} attempts, pausing collection")
                    attempt = 0
                    await asyncio.sleep(300)  # Longer pause after max attempts
                else:
                    # Exponential backoff
                    retry_time = backoff_seconds * attempt
                    logger.info(f"Retrying in {retry_time} seconds...")
                    await asyncio.sleep(retry_time)

    async def _continuous_learning_loop(self) -> None:
        """Run advanced continuous model retraining with all 124 features"""
        while self.is_running:
            try:
                # Always collect data first to ensure we have fresh data
                await self.collect_training_data()

                current_time = time.time()
                time_since_last_train = current_time - self.last_retrain_time

                # Check if it's time to retrain
                if self.continuous_learning_enabled and time_since_last_train >= self.learning_frequency:
                    logger.info(f"[{EXCHANGE_ID}] Starting advanced continuous learning retrain with 124 features")
                    try:
                        # Collect fresh training data
                        await self.collect_training_data()

                        # Prepare batch training data from cache
                        all_features = []
                        total_samples = 0
                        for _symbol, data_points in self.training_cache.items():
                            symbol_samples = len(data_points)
                            total_samples += symbol_samples
                            logger.debug(f"Symbol {_symbol}: {symbol_samples} samples")

                        logger.info(f"Total training samples available: {total_samples}")

                        # Use any available data for training, even if below threshold
                        for _symbol, data_points in self.training_cache.items():
                            if len(data_points) > 0:  # Use any data we have
                                # Get the most recent data points for each symbol
                                recent_points = data_points[-1000:] if len(data_points) > 1000 else data_points
                                all_features.extend(recent_points)

                        # Do not shuffle: labels are sequential next-step within symbol; shuffling would leak future across symbols/times.

                        # Limit to a reasonable batch size for efficient training
                        max_batch_size = 10000
                        training_batch = all_features[:max_batch_size] if len(all_features) > max_batch_size else all_features

                        if len(training_batch) >= 5:  # Lower threshold for testing
                            # Train models with the collected features
                            await self._train_lightweight_models(training_batch)

                            # Perform advanced feature analysis
                            await self._analyze_feature_importance(training_batch)

                            # Update learning progress metrics
                            self._update_learning_progress(len(training_batch))

                            # BALANCED: Keep training history within limits for memory efficiency
                            if len(self.training_history) > self.max_training_history:
                                self.training_history = self.training_history[-self.max_training_history :]
                                logger.debug(f"Trimmed training history to {self.max_training_history} entries")

                            # SMART CLEANUP: Intelligent training data management
                            # Runs once per day, keeps best learning examples, removes garbage
                            if smart_training_data_manager.should_run_cleanup():
                                logger.info("Running smart training data cleanup...")
                                cleanup_result = await smart_training_data_manager.smart_cleanup()
                                logger.info(f"Cleanup result: {cleanup_result}")

                            # MODEL PRUNING: Keep only best N models to prevent disk bloat
                            await self._prune_old_models()

                            # DISK USAGE MONITORING: Emergency cleanup at 90%
                            disk_stats = smart_training_data_manager.get_disk_usage_stats()
                            if disk_stats.get("usage_percent", 0) > 90:
                                logger.warning(f"Training data disk usage HIGH: {disk_stats}")
                                loop = asyncio.get_running_loop()
                                await loop.run_in_executor(None, smart_training_data_manager.emergency_cleanup)

                            # Generate periodic learning reports
                            await self._generate_learning_report()
                        else:
                            logger.warning(f"Insufficient training data: {len(training_batch)} samples (need at least 100)")

                        self.last_retrain_time = time.time()
                    except (ValueError, TypeError, AttributeError, RuntimeError, ConnectionError) as e:
                        logger.exception(f"Error in continuous learning process: {e}")
                        logger.exception(f"[{EXCHANGE_ID}] Continuous learning error: {e}")

                # Wait before checking again - use configured learning frequency
                # Sleep for 60 seconds between checks (actual training controlled by learning_frequency)
                await asyncio.sleep(60)

            except (ValueError, TypeError, AttributeError, RuntimeError, ConnectionError) as e:
                logger.exception(f"Error in continuous learning loop: {e}")
                await asyncio.sleep(30)  # Wait before retrying after error

    async def _analyze_feature_importance(self, features: list[dict[str, Any]]) -> None:
        """Analyze feature importance using the same lookahead label as RF classifier training."""
        try:
            if len(features) < 100:
                return

            by_symbol: dict[str, list[list[float]]] = defaultdict(list)
            for feature_dict in features:
                if not isinstance(feature_dict, dict) or "features" not in feature_dict:
                    continue
                sym = feature_dict.get("symbol")
                if not sym:
                    continue
                row = feature_dict["features"]
                if isinstance(row, list) and len(row) >= 2:
                    by_symbol[str(sym)].append([float(x) for x in row])

            xs: list[list[float]] = []
            ys: list[int] = []
            for rows in by_symbol.values():
                if len(rows) < LABEL_LOOKAHEAD + 1:
                    continue
                arr = np.asarray(rows, dtype=float)
                for i in range(len(arr) - LABEL_LOOKAHEAD):
                    cp = arr[i][0]
                    fp = arr[i + LABEL_LOOKAHEAD][0]
                    if cp <= 0:
                        continue
                    mv = (fp - cp) / cp
                    if abs(mv) < LABEL_MIN_MOVE_PCT:
                        continue
                    xs.append(arr[i].tolist())
                    ys.append(1 if mv > 0 else 0)

            if len(xs) < 100:
                flat: list[list[float]] = []
                for feature_dict in features:
                    if isinstance(feature_dict, dict) and "features" in feature_dict:
                        row = feature_dict["features"]
                        if isinstance(row, list) and row:
                            flat.append([float(x) for x in row])
                if len(flat) < LABEL_LOOKAHEAD + 10:
                    return
                arr = np.asarray(flat, dtype=float)
                xs = []
                ys = []
                for i in range(len(arr) - LABEL_LOOKAHEAD):
                    cp = arr[i][0]
                    fp = arr[i + LABEL_LOOKAHEAD][0]
                    if cp <= 0:
                        continue
                    mv = (fp - cp) / cp
                    if abs(mv) < LABEL_MIN_MOVE_PCT:
                        continue
                    xs.append(arr[i].tolist())
                    ys.append(1 if mv > 0 else 0)
                if len(xs) < 100:
                    return

            X = np.asarray(xs, dtype=float)
            y = np.asarray(ys, dtype=int)

            model = RandomForestClassifier(
                n_estimators=50,
                max_depth=12,
                random_state=42,
                n_jobs=-1,
                class_weight="balanced_subsample",
            )
            model.fit(X, y)

            # Extract feature importance
            importances = model.feature_importances_

            # Store feature importance using shared Redis pool (prevents new connections)
            redis_client = get_shared_redis_async()
            if redis_client is None:
                logger.warning("Shared Redis client unavailable; skipping feature importance storage")
                return

            # Create mapping of feature index to name for better interpretability
            feature_names = [
                # Basic price features (10)
                "price",
                "high",
                "low",
                "open",
                "volume",
                "change_24h",
                "change_7d",
                "change_30d",
                "price_range",
                "typical_price",
                # Technical indicators (24)
                "ma_5",
                "ma_10",
                "ma_20",
                "ma_50",
                "ma_100",
                "ma_200",
                "ema_12",
                "ema_26",
                "ema_50",
                "rsi",
                "rsi_14",
                "stoch_k",
                "stoch_d",
                "williams_r",
                "cci",
                "macd",
                "macd_signal",
                "macd_histogram",
                "bb_upper",
                "bb_middle",
                "bb_lower",
                "bb_position",
                "bb_width",
                "obv",
                "ad_line",
                "cmf",
                "mfi",
                # Volatility indicators (10)
                "volatility",
                "atr",
                "natr",
                "keltner_upper",
                "keltner_lower",
                "donchian_upper",
                "donchian_lower",
                "parabolic_sar",
                "volatility_ratio",
                "price_volatility",
                # Momentum indicators (15)
                "roc",
                "momentum",
                "ppo",
                "trix",
                "ultimate_oscillator",
                "awesome_oscillator",
                "balance_of_power",
                "ease_of_movement",
                "mass_index",
                "vortex_vi_plus",
                "vortex_vi_minus",
                "kst",
                "tsi",
                "aroon_up",
                "aroon_down",
                # Trend indicators (10)
                "adx",
                "di_plus",
                "di_minus",
                "aroon_oscillator",
                "ichimoku_tenkan",
                "ichimoku_kijun",
                "ichimoku_senkou_a",
                "ichimoku_senkou_b",
                "psar",
                "trend_strength",
                # Volume profile (8)
                "volume_ma_5",
                "volume_ma_10",
                "volume_ma_20",
                "volume_ratio",
                "volume_price_trend",
                "negative_volume_index",
                "positive_volume_index",
                "volume_weighted_price",
                # Market sentiment (10)
                "fear_greed_index",
                "social_sentiment",
                "news_sentiment",
                "put_call_ratio",
                "vix",
                "market_cap",
                "supply",
                "circulating_supply",
                "max_supply",
                "market_dominance",
                # Time-based features (10)
                "hour",
                "day_of_week",
                "day_of_month",
                "month",
                "iso_weekday",
                "day_of_year",
                "hour_12h",
                "minute",
                "second",
                "seconds_since_midnight",
                # Advanced technical analysis (8)
                "fib_23.6",
                "fib_38.2",
                "fib_61.8",
                "pivot_point",
                "resistance_1",
                "resistance_2",
                "support_1",
                "support_2",
                # Advanced volume analysis (8)
                "volume_profile_poc",
                "volume_profile_vah",
                "volume_profile_val",
                "vwap",
                "twap",
                "volume_imbalance",
                "volume_delta",
                "order_flow",
                # Advanced market microstructure (8)
                "bid_ask_spread",
                "order_book_imbalance",
                "market_depth",
                "liquidity_score",
                "price_impact",
                "market_efficiency",
                "volatility_smile",
                "price_skewness",
            ]

            # Ensure we have the right number of feature names
            if len(feature_names) != len(importances):
                feature_names = [f"feature_{i}" for i in range(len(importances))]

            # Create sorted importance data
            importance_data = []
            for i, imp in enumerate(importances):
                if i < len(feature_names):
                    importance_data.append({"name": feature_names[i], "importance": float(imp)})
                else:
                    importance_data.append({"name": f"feature_{i}", "importance": float(imp)})

            # Sort by importance (descending)
            importance_data.sort(key=lambda x: x["importance"], reverse=True)

            # Store in Redis (async client)
            await redis_client.set("ai_feature_importances", json.dumps(importance_data))
            await redis_client.set("ai_feature_importances_updated", _now_iso())

            # Log top 10 most important features
            top_features = importance_data[:10]
            logger.info(f"Top 10 most important features: {[f['name'] for f in top_features]}")

        except (ImportError, ValueError, TypeError, AttributeError) as e:
            logger.exception(f"Error analyzing feature importance: {e}")

    def _update_learning_progress(self, _batch_size: int) -> None:
        """Update AI learning progress metrics"""
        try:
            # Update learning progress metrics
            if AILearningReport is None:
                # Skip report generation if AILearningReport is not available
                logger.debug("AI learning report not available - skipping report generation")
                return

            # Create report generator
            report_generator = AILearningReport()  # type: ignore[misc]

            # Update metrics with new data points
            metrics = report_generator.update_metrics()

            # Log progress
            if metrics:
                progress = metrics.get("learning_progress", 0)
                total_points = metrics.get("total_data_points", 0)
                patterns = metrics.get("patterns_discovered", 0)

                logger.info(f"AI Learning Progress: {progress:.2f}% complete, {total_points:,} data points, {patterns:,} patterns")

        except (ImportError, ValueError, TypeError, AttributeError) as e:
            logger.exception(f"Error updating learning progress: {e}")

    async def _prune_old_models(self) -> None:
        """Prune old model files to prevent disk bloat. Keeps only the best N models."""
        try:
            # Only run pruning every hour (3600 seconds)
            current_time = time.time()
            if current_time - self._last_prune_time < 3600:
                return

            self._last_prune_time = current_time

            model_dir = Path(self.model_versions_dir) / "lightweight"
            if not model_dir.exists():
                return

            # Get all model files grouped by type
            model_types = {
                "model_": [],  # RandomForest
                "gb_model_": [],  # GradientBoosting
                "xgb_model_": [],  # XGBoost
            }

            for file_path in model_dir.glob("*.pkl"):
                for prefix, file_list in model_types.items():
                    if file_path.name.startswith(prefix):
                        file_list.append(file_path)
                        break

            # For each type, keep only the latest N models
            total_deleted = 0
            for _prefix, files in model_types.items():
                if len(files) <= self.max_model_versions:
                    continue

                # Sort by modification time (newest first)
                files_sorted = sorted(files, key=lambda f: f.stat().st_mtime, reverse=True)

                # Delete older files beyond the limit
                for file_to_delete in files_sorted[self.max_model_versions :]:
                    try:
                        file_to_delete.unlink()
                        total_deleted += 1
                    except OSError as e:
                        logger.debug(f"Could not delete {file_to_delete}: {e}")

            if total_deleted > 0:
                logger.info(f"Model pruning: deleted {total_deleted} old models, keeping {self.max_model_versions} per type")

        except Exception as e:
            logger.debug(f"Model pruning error (non-fatal): {e}")

    async def _generate_learning_report(self) -> None:
        """Generate periodic AI learning reports"""
        try:
            # Generate reports once every hour (3600 seconds)
            current_time = time.time()
            last_report_time_str = await self.cache.get("last_learning_report_time")

            if not last_report_time_str:
                last_report_time = 0
            else:
                try:
                    last_report_time = float(last_report_time_str)
                except (ValueError, TypeError):
                    last_report_time = 0

            if current_time - last_report_time >= 3600:  # Generate report every hour
                # Use optional report generator if available
                if AILearningReport is None:
                    logger.debug("AI learning report not available - skipping report generation")
                    return None

                # Create report generator
                report_generator = AILearningReport()  # type: ignore[misc]

                # Generate report
                report_path = report_generator.generate_report()

                if report_path:
                    logger.info(f"Generated AI learning report: {report_path}")

                    # Create visualization
                    viz_path = report_generator.visualize_progress()
                    if viz_path:
                        logger.info(f"Generated AI learning visualization: {viz_path}")

                # Update last report time
                await self.cache.set("last_learning_report_time", str(current_time))

        except (ImportError, ValueError, TypeError, AttributeError) as e:
            logger.exception(f"Error generating learning report: {e}")

    async def _train_lightweight_models(self, features: list[dict[str, Any]]):
        """Train lightweight models for real-time prediction using all 124 features"""
        # Get current model accuracy from shared Redis pool (no new connections)
        redis_client = get_shared_redis_async()
        if redis_client is None:
            logger.warning("Shared Redis client unavailable; skipping lightweight model training")
            return

        try:
            accuracy_key = "ai_model_accuracy"

            try:
                accuracy = await redis_client.get(accuracy_key)
                if accuracy:
                    accuracy_value = float(_decode(accuracy) or "0.0")
                    self._current_accuracy = accuracy_value
            except (ConnectionError, OSError, AttributeError, TypeError, ValueError):
                pass

            # If we have features, use them for incremental learning
            if features:
                # Use imported libraries for model training
                try:
                    rows_with_sym = [r for r in features if isinstance(r, dict) and r.get("symbol") and "features" in r]
                    feature_arrays_legacy = [r["features"] for r in features if isinstance(r, dict) and "features" in r]

                    X_ps, y_ps, sym_ps = build_xy_arrays_per_symbol(rows_with_sym)
                    use_per_symbol_path = len(X_ps) >= MIN_RF_TRAIN_SAMPLES

                    if not use_per_symbol_path and len(feature_arrays_legacy) >= MIN_RF_TRAIN_SAMPLES:
                        logger.warning(
                            "RF training: only %s rows carry symbol (need %s for per-symbol scaling); using legacy single-scaler path until cache backfills",
                            len(rows_with_sym),
                            MIN_RF_TRAIN_SAMPLES,
                        )

                    if use_per_symbol_path:
                        n_total = len(X_ps)
                        split_idx = int(n_total * 0.8)
                        X_train, X_val = X_ps[:split_idx], X_ps[split_idx:]
                        y_train, y_val = y_ps[:split_idx], y_ps[split_idx:]
                        sym_train, sym_val = sym_ps[:split_idx], sym_ps[split_idx:]
                        scalers_out, global_scaler = fit_per_symbol_scalers_for_rf(X_train, sym_train)
                        X_train_scaled = transform_rows_per_symbol_scalers(X_train, sym_train, scalers_out, global_scaler)
                        X_val_scaled = transform_rows_per_symbol_scalers(X_val, sym_val, scalers_out, global_scaler)
                        legacy_scaler = None
                    elif len(feature_arrays_legacy) >= MIN_RF_TRAIN_SAMPLES:
                        X_legacy = np.array(feature_arrays_legacy)
                        n_leg = len(X_legacy)
                        ahead_leg = min(LABEL_LOOKAHEAD, n_leg - 1)
                        keep_x_leg, keep_y_leg = [], []
                        for i in range(n_leg - ahead_leg):
                            cp = X_legacy[i][0]
                            fp = X_legacy[i + ahead_leg][0]
                            if cp <= 0:
                                continue
                            mv = (fp - cp) / cp
                            if abs(mv) < LABEL_MIN_MOVE_PCT:
                                continue
                            keep_x_leg.append(X_legacy[i])
                            keep_y_leg.append(1 if mv > 0 else 0)
                        if len(keep_x_leg) < MIN_RF_TRAIN_SAMPLES:
                            X_train_scaled = None
                        else:
                            X_legacy = np.array(keep_x_leg)
                            y_legacy = np.array(keep_y_leg)
                            n_leg_s = len(X_legacy)
                            split_leg = int(n_leg_s * 0.8)
                            X_train, X_val = X_legacy[:split_leg], X_legacy[split_leg:]
                            y_train, y_val = y_legacy[:split_leg], y_legacy[split_leg:]
                            legacy_scaler = StandardScaler()
                            X_train_scaled = legacy_scaler.fit_transform(X_train)
                            X_val_scaled = legacy_scaler.transform(X_val)
                            scalers_out = None
                            global_scaler = None
                    else:
                        X_train_scaled = None

                    if X_train_scaled is not None:
                        # Train a lightweight RandomForest model (shared across all symbols at inference)
                        model = RandomForestClassifier(
                            n_estimators=50,
                            max_depth=10,
                            min_samples_split=5,
                            random_state=42,
                            n_jobs=-1,
                            class_weight="balanced_subsample",
                        )
                        model.fit(X_train_scaled, y_train)
                        accuracy = model.score(X_val_scaled, y_val)

                        self._current_accuracy = accuracy
                        self.performance_metrics["average_accuracy"] = (self.performance_metrics["average_accuracy"] * self.performance_metrics["successful_trainings"] + accuracy) / (
                            self.performance_metrics["successful_trainings"] + 1
                        )
                        self.performance_metrics["best_accuracy"] = max(self.performance_metrics["best_accuracy"], accuracy)

                        try:
                            model_dir = Path(self.model_versions_dir) / "lightweight"
                            model_dir.mkdir(parents=True, exist_ok=True)
                            ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
                            model_path = model_dir / f"model_{ts}.pkl"

                            if use_per_symbol_path and scalers_out is not None and global_scaler is not None:
                                rf_artifact: dict[str, Any] = {
                                    "model": model,
                                    "scalers": scalers_out,
                                    "global_scaler": global_scaler,
                                }
                            else:
                                rf_artifact = {"model": model, "scaler": legacy_scaler}

                            with model_path.open("wb") as f:
                                pickle.dump(rf_artifact, f)

                            active_dir = Path(ensure_model_directories()["active"])
                            active_dir.mkdir(parents=True, exist_ok=True)
                            shutil.copy2(model_path, active_dir / "model_latest.pkl")

                            await redis_client.set(accuracy_key, str(accuracy))
                            await redis_client.set("ai_model_last_trained", _now_iso())
                            await redis_client.set("ai_model_features", "124")

                            gb_model = GradientBoostingClassifier(
                                n_estimators=100,
                                max_depth=6,
                                learning_rate=0.1,
                                random_state=42,
                            )
                            gb_model.fit(X_train_scaled, y_train)
                            gb_accuracy = gb_model.score(X_val_scaled, y_val)
                            logger.info(f"GradientBoosting accuracy: {gb_accuracy:.4f}")

                            gb_model_path = model_dir / f"gb_model_{ts}.pkl"
                            gb_payload: dict[str, Any] = {"model": gb_model}
                            if use_per_symbol_path and scalers_out is not None and global_scaler is not None:
                                gb_payload["scalers"] = scalers_out
                                gb_payload["global_scaler"] = global_scaler
                            else:
                                gb_payload["scaler"] = legacy_scaler
                            with gb_model_path.open("wb") as f:
                                pickle.dump(gb_payload, f)

                            xgb_model = None
                            xgb_accuracy = 0.0
                            try:
                                from xgboost import XGBClassifier

                                xgb_model = XGBClassifier(
                                    n_estimators=100,
                                    max_depth=6,
                                    learning_rate=0.1,
                                    random_state=42,
                                    eval_metric="logloss",
                                    use_label_encoder=False,
                                )
                                xgb_model.fit(X_train_scaled, y_train)
                                xgb_accuracy = xgb_model.score(X_val_scaled, y_val)
                                logger.info(f"XGBoost accuracy: {xgb_accuracy:.4f}")

                                xgb_model_path = model_dir / f"xgb_model_{ts}.pkl"
                                xgb_payload: dict[str, Any] = {"model": xgb_model}
                                if use_per_symbol_path and scalers_out is not None and global_scaler is not None:
                                    xgb_payload["scalers"] = scalers_out
                                    xgb_payload["global_scaler"] = global_scaler
                                else:
                                    xgb_payload["scaler"] = legacy_scaler
                                with xgb_model_path.open("wb") as f:
                                    pickle.dump(xgb_payload, f)
                            except ImportError:
                                logger.info("XGBoost not available, using RF + GB ensemble only")
                            except Exception as xgb_e:
                                logger.debug(f"XGBoost training error: {xgb_e}")

                            total_accuracy = accuracy + gb_accuracy + (xgb_accuracy if xgb_model else 0)
                            if total_accuracy > 0:
                                rf_weight = accuracy / total_accuracy
                                gb_weight = gb_accuracy / total_accuracy
                                xgb_weight = xgb_accuracy / total_accuracy if xgb_model else 0
                            else:
                                rf_weight = 0.4
                                gb_weight = 0.35
                                xgb_weight = 0.25 if xgb_model else 0

                            ensemble_weights = {
                                "rf_weight": rf_weight,
                                "gb_weight": gb_weight,
                                "xgb_weight": xgb_weight,
                                "rf_accuracy": accuracy,
                                "gb_accuracy": gb_accuracy,
                                "xgb_accuracy": xgb_accuracy,
                            }
                            await redis_client.set("ai_ensemble_weights", json.dumps(ensemble_weights))
                            logger.info(f"OPTIMIZED Ensemble weights: RF={rf_weight:.2f}, GB={gb_weight:.2f}, XGB={xgb_weight:.2f}")

                            if hasattr(model, "feature_importances_"):
                                importances = model.feature_importances_
                                await redis_client.set("ai_feature_importances", json.dumps(importances.tolist()))

                        except (OSError, pickle.PickleError, ConnectionError) as e:
                            logger.exception(f"Error saving model: {e}")

                        if get_ai_model_versioning is not None:
                            versioning = get_ai_model_versioning()  # type: ignore[misc]
                            versioning.create_version(
                                model_type="lightweight_rf",
                                accuracy=accuracy,
                                metadata={"features": 124, "training_samples": len(X_train), "timestamp": _now_iso()},
                            )
                        else:
                            logger.warning("AI model versioning not available")

                        mode = "per_symbol_scalers" if use_per_symbol_path else "legacy_global_scaler"
                        logger.info(
                            "Trained lightweight RF (%s) with 124 features. Accuracy: %.4f",
                            mode,
                            accuracy,
                        )
                        self.performance_metrics["models_trained"] += 1
                        self.performance_metrics["successful_trainings"] += 1

                except ImportError as e:
                    logger.exception(f"Required library not available: {e}")
                except Exception as e:
                    logger.exception(f"Error during model training: {e}")
                    self.performance_metrics["failed_trainings"] += 1
            else:
                # No features provided, just update the counter
                self.performance_metrics["total_training_sessions"] += 1

            # Update metrics
            self.performance_metrics["last_training_time"] = _now_iso()
            # Publish live training metrics to Redis for dashboards
            try:
                await self._publish_metrics(redis_client)
            except Exception as pub_exc:  # pragma: no cover - defensive
                logger.debug(f"Non-fatal: failed to publish training metrics: {pub_exc}")

        except (ValueError, TypeError, AttributeError, RuntimeError, ConnectionError) as e:
            logger.exception(f"Error training lightweight models: {e}")
            self.performance_metrics["failed_trainings"] += 1

    async def _publish_metrics(self, redis_client) -> None:
        """Persist live training metrics to Redis for downstream consumers."""
        if redis_client is None:
            return

        try:
            uptime = max(0.0, time.time() - self._start_time)

            # Get learning metrics from report generator (same data as ai_learning_report.py)
            learning_metrics = {}
            try:
                if AILearningReport is not None:
                    report_gen = AILearningReport()
                    learning_metrics = report_gen.update_metrics() or {}
            except Exception as e:
                logger.debug(f"Could not get learning metrics: {e}")

            # Format data for ai_learning_data_helper expectations
            training_stats = {
                # Basic training status
                "status": "active" if self.is_running else "inactive",
                "pipeline_running": self.is_running,
                "current_accuracy": float(self._current_accuracy),
                "sessions": int(self.performance_metrics.get("total_training_sessions", 0)),
                "successful_trainings": int(self.performance_metrics.get("successful_trainings", 0)),
                "failed_trainings": int(self.performance_metrics.get("failed_trainings", 0)),
                "best_accuracy": float(self.performance_metrics.get("best_accuracy", 0.0)),
                "average_accuracy": float(self.performance_metrics.get("average_accuracy", 0.0)),
                "last_training_time": self.performance_metrics.get("last_training_time"),
                "models_trained": int(self.performance_metrics.get("models_trained", 0)),
                "timestamp": _now_iso(),
                # Learning metrics for ai_learning_data_helper
                "total_data_points": int(learning_metrics.get("total_data_points", 0)),
                "patterns_discovered": int(learning_metrics.get("patterns_discovered", 0)),
                "accuracy_improvement": float(learning_metrics.get("accuracy_improvement", 0.0)),
                "learning_progress": float(learning_metrics.get("learning_progress", 0.0)),
                "active_strategies": int(learning_metrics.get("active_strategies", 0)),
                # Training status object
                "training_status": {
                    "status": "active" if self.is_running else "inactive",
                    "current_epoch": int(self.performance_metrics.get("current_epoch", 0)),
                    "total_epochs": int(self.performance_metrics.get("total_epochs", 0)),
                },
                # Additional metadata
                "last_updated": _now_iso(),
                "source": "redis",
            }

            # ai_learning_stats key consumed by ai_learning_data_helper
            await redis_client.set("ai_learning_stats", json.dumps(training_stats))

            # Minimal live engine state for dashboards expecting ai_live_engine:state
            live_state = {
                "accuracy": float(self._current_accuracy),
                "initialized": True,
                "running": self.is_running,
                "uptime_seconds": uptime,
                "last_training": self.performance_metrics.get("last_training_time"),
                "prediction_count": 0,
                "training_count": training_stats["sessions"],
                "timestamp": _now_iso(),
            }
            await redis_client.set("ai_live_engine:state", json.dumps(live_state))
        except Exception as e:  # pragma: no cover - defensive
            logger.debug(f"Failed to publish training metrics: {e}")

    def create_feature_vector(self, market_data: dict[str, Any], mystic_data: dict[str, Any], trade_data: dict[str, Any]) -> list[float]:
        """
        Create a comprehensive feature vector from market, mystic and trade data
        This method extracts and normalizes 124 features for advanced AI training
        """
        # Initialize empty feature vector
        feature_vector = []

        try:
            # Helper function for safe float conversion
            def safe_float(value: Any, default: float = 0.0) -> float:
                try:
                    if isinstance(value, (int, float)):
                        result = float(value)
                    elif isinstance(value, str):
                        result = float(value.replace("%", "").replace(",", "").strip())
                    else:
                        result = default
                except (ValueError, TypeError, AttributeError):
                    return default
                else:
                    return result

            # === BASIC PRICE FEATURES (10) ===
            if market_data:
                close_price = safe_float(market_data.get("close", 0))
                open_price = safe_float(market_data.get("open", 0))
                high_price = safe_float(market_data.get("high", 0))
                low_price = safe_float(market_data.get("low", 0))
                volume = safe_float(market_data.get("volume", 0))

                feature_vector.extend(
                    [
                        close_price,  # 1. Current price
                        high_price,  # 2. High price
                        low_price,  # 3. Low price
                        open_price,  # 4. Open price
                        volume,  # 5. Volume
                        safe_float(market_data.get("change_24h", 0)),  # 6. 24h change
                        safe_float(market_data.get("change_7d", 0)),  # 7. 7d change
                        safe_float(market_data.get("change_30d", 0)),  # 8. 30d change
                        high_price - low_price,  # 9. Price range
                        (high_price + low_price + close_price) / 3,  # 10. Typical price
                    ]
                )
            else:
                feature_vector.extend([0.0] * 10)

            # === TECHNICAL INDICATORS (24) ===
            # Moving Averages
            if market_data:
                feature_vector.extend(
                    [
                        safe_float(market_data.get("ma_5", 0)),  # 11. MA5
                        safe_float(market_data.get("ma_10", 0)),  # 12. MA10
                        safe_float(market_data.get("ma_20", 0)),  # 13. MA20
                        safe_float(market_data.get("ma_50", 0)),  # 14. MA50
                        safe_float(market_data.get("ma_100", 0)),  # 15. MA100
                        safe_float(market_data.get("ma_200", 0)),  # 16. MA200
                    ]
                )

                # Exponential Moving Averages
                feature_vector.extend(
                    [
                        safe_float(market_data.get("ema_12", 0)),  # 17. EMA12
                        safe_float(market_data.get("ema_26", 0)),  # 18. EMA26
                        safe_float(market_data.get("ema_50", 0)),  # 19. EMA50
                    ]
                )

                # Oscillators
                feature_vector.extend(
                    [
                        safe_float(market_data.get("rsi", 50)),  # 20. RSI
                        safe_float(market_data.get("rsi_14", 50)),  # 21. RSI14
                        safe_float(market_data.get("stoch_k", 50)),  # 22. Stochastic %K
                        safe_float(market_data.get("stoch_d", 50)),  # 23. Stochastic %D
                        safe_float(market_data.get("williams_r", -50)),  # 24. Williams %R
                        safe_float(market_data.get("cci", 0)),  # 25. Commodity Channel Index
                    ]
                )

                # MACD Components
                feature_vector.extend(
                    [
                        safe_float(market_data.get("macd", 0)),  # 26. MACD
                        safe_float(market_data.get("macd_signal", 0)),  # 27. MACD Signal
                        safe_float(market_data.get("macd_histogram", 0)),  # 28. MACD Histogram
                    ]
                )

                # Bollinger Bands
                feature_vector.extend(
                    [
                        safe_float(market_data.get("bb_upper", 0)),  # 29. BB Upper
                        safe_float(market_data.get("bb_middle", 0)),  # 30. BB Middle
                        safe_float(market_data.get("bb_lower", 0)),  # 31. BB Lower
                        safe_float(market_data.get("bb_position", 0.5)),  # 32. BB Position
                        safe_float(market_data.get("bb_width", 0)),  # 33. BB Width
                    ]
                )

                # Volume Indicators
                feature_vector.extend(
                    [
                        safe_float(market_data.get("obv", 0)),  # 34. On-Balance Volume
                        safe_float(market_data.get("ad_line", 0)),  # 35. A/D Line
                        safe_float(market_data.get("cmf", 0)),  # 36. Chaikin Money Flow
                        safe_float(market_data.get("mfi", 50)),  # 37. Money Flow Index
                    ]
                )
            else:
                feature_vector.extend([0.0] * 24)

            # === VOLATILITY INDICATORS (10) ===
            if market_data:
                feature_vector.extend(
                    [
                        safe_float(market_data.get("volatility")),  # 38. Volatility (0 if unknown)
                        safe_float(market_data.get("atr", 0)),  # 39. Average True Range
                        safe_float(market_data.get("natr", 0)),  # 40. Normalized ATR
                        safe_float(market_data.get("keltner_upper", 0)),  # 41. Keltner Upper
                        safe_float(market_data.get("keltner_lower", 0)),  # 42. Keltner Lower
                        safe_float(market_data.get("donchian_upper", 0)),  # 43. Donchian Upper
                        safe_float(market_data.get("donchian_lower", 0)),  # 44. Donchian Lower
                        safe_float(market_data.get("parabolic_sar", 0)),  # 45. Parabolic SAR
                        safe_float(market_data.get("volatility_ratio", 1)),  # 46. Volatility Ratio
                        safe_float(market_data.get("price_volatility", 0)),  # 47. Price Volatility
                    ]
                )
            else:
                feature_vector.extend([0.0] * 10)

            # === MOMENTUM INDICATORS (15) ===
            if market_data:
                feature_vector.extend(
                    [
                        safe_float(market_data.get("roc", 0)),  # 48. Rate of Change
                        safe_float(market_data.get("momentum", 0)),  # 49. Momentum
                        safe_float(market_data.get("ppo", 0)),  # 50. Percentage Price Oscillator
                        safe_float(market_data.get("trix", 0)),  # 51. TRIX
                        safe_float(market_data.get("ultimate_oscillator", 50)),  # 52. Ultimate Oscillator
                        safe_float(market_data.get("awesome_oscillator", 0)),  # 53. Awesome Oscillator
                        safe_float(market_data.get("balance_of_power", 0)),  # 54. Balance of Power
                        safe_float(market_data.get("ease_of_movement", 0)),  # 55. Ease of Movement
                        safe_float(market_data.get("mass_index", 25)),  # 56. Mass Index
                        safe_float(market_data.get("vortex_vi_plus", 1)),  # 57. Vortex VI+
                        safe_float(market_data.get("vortex_vi_minus", 1)),  # 58. Vortex VI-
                        safe_float(market_data.get("kst", 0)),  # 59. Know Sure Thing
                        safe_float(market_data.get("tsi", 0)),  # 60. True Strength Index
                        safe_float(market_data.get("aroon_up", 50)),  # 61. Aroon Up
                        safe_float(market_data.get("aroon_down", 50)),  # 62. Aroon Down
                    ]
                )
            else:
                feature_vector.extend([0.0] * 15)

            # === TREND INDICATORS (10) ===
            if market_data:
                feature_vector.extend(
                    [
                        safe_float(market_data.get("adx", 25)),  # 63. ADX
                        safe_float(market_data.get("di_plus", 25)),  # 64. DI+
                        safe_float(market_data.get("di_minus", 25)),  # 65. DI-
                        safe_float(market_data.get("aroon_oscillator", 0)),  # 66. Aroon Oscillator
                        safe_float(market_data.get("ichimoku_tenkan", 0)),  # 67. Ichimoku Tenkan
                        safe_float(market_data.get("ichimoku_kijun", 0)),  # 68. Ichimoku Kijun
                        safe_float(market_data.get("ichimoku_senkou_a", 0)),  # 69. Ichimoku Senkou A
                        safe_float(market_data.get("ichimoku_senkou_b", 0)),  # 70. Ichimoku Senkou B
                        safe_float(market_data.get("psar", 0)),  # 71. Parabolic SAR
                        safe_float(market_data.get("trend_strength", 0)),  # 72. Trend Strength
                    ]
                )
            else:
                feature_vector.extend([0.0] * 10)

            # === VOLUME PROFILE (8) ===
            if market_data:
                feature_vector.extend(
                    [
                        safe_float(market_data.get("volume_ma_5", 0)),  # 73. Volume MA5
                        safe_float(market_data.get("volume_ma_10", 0)),  # 74. Volume MA10
                        safe_float(market_data.get("volume_ma_20", 0)),  # 75. Volume MA20
                        safe_float(market_data.get("volume_ratio", 1)),  # 76. Volume Ratio
                        safe_float(market_data.get("volume_price_trend", 0)),  # 77. Volume Price Trend
                        safe_float(market_data.get("negative_volume_index", 1000)),  # 78. Negative Volume Index
                        safe_float(market_data.get("positive_volume_index", 1000)),  # 79. Positive Volume Index
                        safe_float(market_data.get("volume_weighted_price", 0)),  # 80. Volume Weighted Price
                    ]
                )
            else:
                feature_vector.extend([0.0] * 8)

            # === MARKET SENTIMENT (10) ===
            if mystic_data:
                sentiment_data = mystic_data.get("sentiment", {})
                market_data = market_data or {}
                feature_vector.extend(
                    [
                        safe_float(sentiment_data.get("fear_greed_index", 50)),  # 81. Fear & Greed Index
                        safe_float(sentiment_data.get("social_sentiment", 0.5)),  # 82. Social Sentiment
                        safe_float(sentiment_data.get("news_sentiment", 0.5)),  # 83. News Sentiment
                        safe_float(sentiment_data.get("put_call_ratio", 1)),  # 84. Put/Call Ratio
                        safe_float(sentiment_data.get("vix", 20)),  # 85. VIX
                        safe_float(market_data.get("market_cap", 0)),  # 86. Market Cap
                        safe_float(market_data.get("supply", 0)),  # 87. Supply
                        safe_float(market_data.get("circulating_supply", 0)),  # 88. Circulating Supply
                        safe_float(market_data.get("max_supply", 0)),  # 89. Max Supply
                        safe_float(market_data.get("market_dominance", 0)),  # 90. Market Dominance
                    ]
                )
            else:
                feature_vector.extend([0.0] * 10)

            # === TIME-BASED FEATURES (10) ===
            now = datetime.now(timezone.utc)
            timestamp = market_data.get("timestamp") if market_data else None
            if timestamp:
                try:
                    if isinstance(timestamp, (int, float)):
                        dt = datetime.fromtimestamp(timestamp / 1000 if timestamp > 10000000000 else timestamp, tz=timezone.utc)
                    else:
                        dt = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
                except (ValueError, TypeError, AttributeError):
                    dt = now
            else:
                dt = now

            feature_vector.extend(
                [
                    float(dt.hour),  # 91. Hour of day
                    float(dt.weekday()),  # 92. Day of week
                    float(dt.day),  # 93. Day of month
                    float(dt.month),  # 94. Month
                    float(dt.isoweekday()),  # 95. ISO weekday
                    float(dt.timetuple().tm_yday),  # 96. Day of year
                    float(dt.hour % 12),  # 97. Hour in 12h format
                    float(dt.minute),  # 98. Minute
                    float(dt.second),  # 99. Second
                    float(dt.timestamp() % 86400),  # 100. Seconds since midnight
                ]
            )

            # === ADDITIONAL ADVANCED INDICATORS (24) ===
            # Advanced Technical Analysis
            if market_data:
                feature_vector.extend(
                    [
                        safe_float(market_data.get("fibonacci_retracement_23.6", 0)),  # 101. Fib 23.6%
                        safe_float(market_data.get("fibonacci_retracement_38.2", 0)),  # 102. Fib 38.2%
                        safe_float(market_data.get("fibonacci_retracement_61.8", 0)),  # 103. Fib 61.8%
                        safe_float(market_data.get("pivot_point", 0)),  # 104. Pivot Point
                        safe_float(market_data.get("resistance_1", 0)),  # 105. Resistance 1
                        safe_float(market_data.get("resistance_2", 0)),  # 106. Resistance 2
                        safe_float(market_data.get("support_1", 0)),  # 107. Support 1
                        safe_float(market_data.get("support_2", 0)),  # 108. Support 2
                    ]
                )
            else:
                feature_vector.extend([0.0] * 8)

            # Advanced Volume Analysis
            if market_data:
                feature_vector.extend(
                    [
                        safe_float(market_data.get("volume_profile_poc", 0)),  # 109. Volume Profile POC
                        safe_float(market_data.get("volume_profile_vah", 0)),  # 110. Volume Profile VAH
                        safe_float(market_data.get("volume_profile_val", 0)),  # 111. Volume Profile VAL
                        safe_float(market_data.get("vwap", 0)),  # 112. VWAP
                        safe_float(market_data.get("twap", 0)),  # 113. TWAP
                        safe_float(market_data.get("volume_imbalance", 0)),  # 114. Volume Imbalance
                        safe_float(market_data.get("volume_delta", 0)),  # 115. Volume Delta
                        safe_float(market_data.get("order_flow", 0)),  # 116. Order Flow
                    ]
                )
            else:
                feature_vector.extend([0.0] * 8)

            # Advanced Market Microstructure
            if trade_data:
                feature_vector.extend(
                    [
                        safe_float(trade_data.get("bid_ask_spread", 0)),  # 117. Bid-Ask Spread
                        safe_float(trade_data.get("order_book_imbalance", 0)),  # 118. Order Book Imbalance
                        safe_float(trade_data.get("market_depth", 0)),  # 119. Market Depth
                        safe_float(trade_data.get("liquidity_score", 0)),  # 120. Liquidity Score
                        safe_float(trade_data.get("price_impact", 0)),  # 121. Price Impact
                        safe_float(trade_data.get("market_efficiency", 0)),  # 122. Market Efficiency
                        safe_float(trade_data.get("volatility_smile", 0)),  # 123. Volatility Smile
                        safe_float(trade_data.get("price_skewness", trade_data.get("skewness", 0))),  # 124. Price Skewness
                    ]
                )
            else:
                feature_vector.extend([0.0] * 8)

            # Ensure all values are valid floats - VECTORIZED for performance
            feature_array = np.array(feature_vector, dtype=float)
            # Replace non-finite values with 0.0 using vectorized operations
            feature_array[~np.isfinite(feature_array)] = 0.0
            feature_vector = feature_array.tolist()

            # Ensure we have exactly 124 features
            if len(feature_vector) != 124:
                # Pad or truncate to 124 features without noisy warnings
                while len(feature_vector) < 124:
                    feature_vector.append(0.0)
                feature_vector = feature_vector[:124]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError) as e:
            logger.exception("Error creating feature vector: %s", e)
            # All Live Data, No Fallback/Hardcoded Data
            # Raise exception instead of returning fallback zero vector
            msg = f"Failed to create feature vector from live data: {e}"
            raise RuntimeError(msg) from e
        else:
            # Return the feature vector
            return feature_vector

    async def collect_training_data(self):
        """Collect market, mystic and trade data and store feature vectors in cache using canonical feature builder"""
        from backend.services.feature_builder import build_feature_dict_from_ohlcv
        from backend.services.feature_mapping import dict_to_feature_vector
        from backend.services.live_market_data import live_market_data_service

        try:
            # Cycle through all TOP10_COINS to collect diverse training data
            coin_index = int(time.time() // 10) % len(TOP10_COINS)
            current_coin = TOP10_COINS[coin_index]

            # Get real OHLCV from canonical source
            ccxt_symbol = f"{current_coin}/USDT"
            from backend.services.history_context_gates import min_ohlcv_bars_for_signal, ohlcv_fetch_limit_1m

            min_b = min_ohlcv_bars_for_signal()
            ohlcv = None
            ohlcv_1d = None
            if live_market_data_service:
                try:
                    lim = ohlcv_fetch_limit_1m()
                    ohlcv = await live_market_data_service.get_ohlcv(ccxt_symbol, "1m", lim)
                    d1 = await live_market_data_service.get_ohlcv(ccxt_symbol, "1d", 40)
                    if isinstance(d1, list) and len(d1) >= 2:
                        ohlcv_1d = d1
                except Exception as e:
                    logger.debug(f"Failed to get OHLCV for {ccxt_symbol}: {e}")
                    ohlcv = None

            if not ohlcv or len(ohlcv) < min_b:
                logger.debug("No sufficient OHLCV for %s (len=%s need=%s), skipping", current_coin, len(ohlcv or []), min_b)
                return []

            symbol_hint = current_coin

            # Get orderbook features from Redis
            order_book_features = await self._fetch_order_book_features(symbol_hint)
            trade_data = order_book_features or {}

            # Get volume profile from Redis
            vp = None
            try:
                redis_client = get_shared_redis_async()
                if redis_client:
                    raw_vp = await redis_client.hgetall(f"volume_profile:{symbol_hint}")
                    if raw_vp:
                        vp = {k.decode() if isinstance(k, bytes) else k: float(v.decode() if isinstance(v, bytes) else v) for k, v in raw_vp.items()}
            except Exception as ex:
                logger.debug("Volume profile fetch failed for %s: %s", symbol_hint, ex)
                vp = None

            # Build canonical feature dict
            feature_dict = build_feature_dict_from_ohlcv(
                symbol_ccxt=ccxt_symbol,
                ohlcv=ohlcv,
                volume_profile=vp,
                orderbook=trade_data,
                sentiment=None,
                ohlcv_1d=ohlcv_1d,
            )

            # Convert to 124-element feature vector using canonical mapping
            features = dict_to_feature_vector(feature_dict)

            symbol = current_coin
            logger.debug(f"Collected canonical training data for {current_coin} (features: {len(features)})")

            # Store under symbol if available
            symbol = str(current_coin) if current_coin else "global"
            if isinstance(feature_dict, dict):
                symbol = feature_dict.get("symbol") or feature_dict.get("pair") or symbol
            if not symbol:
                symbol = "global"

            # Store timestamp with features for better tracking
            timestamp = _now_iso()
            training_pair = _canonical_training_pair_symbol(str(current_coin))
            feature_data = {
                "timestamp": timestamp,
                "features": features,
                "feature_count": len(features),  # Track feature count for validation
                "collection_time": timestamp,
                "symbol": training_pair,
            }

            # Use memory-efficient storage with a maximum capacity
            # Use configured max size to prevent memory leaks
            symbol_cache = self.training_cache.setdefault(symbol, [])
            symbol_cache.append(feature_data)

            # 24/7 FIX: Enforce cache trimming to prevent unbounded memory growth
            if len(symbol_cache) > self.max_training_cache_size:
                self.training_cache[symbol] = symbol_cache[-self.max_training_cache_size :]

            self.last_collection[symbol] = timestamp

            # Persist data to disk in chunks for better performance and durability
            # Only write every 100 collections to reduce I/O overhead
            if len(symbol_cache) % 100 == 0:
                try:
                    # Create directory if it doesn't exist
                    Path(self.training_data_dir).mkdir(parents=True, exist_ok=True)

                    # Save latest chunk to disk (24/7: preserve more for restart recovery)
                    latest_path = Path(self.training_data_dir) / f"{symbol.replace('/', '_')}_latest.json"
                    save_count = min(5000, len(symbol_cache), self.max_training_cache_size)
                    with latest_path.open("w") as f:
                        json.dump(symbol_cache[-save_count:], f)

                    # Save a timestamped chunk periodically for historical records
                    if len(symbol_cache) % 1000 == 0:
                        timestamp_str = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
                        archive_path = Path(self.training_data_dir) / f"{symbol.replace('/', '_')}_{timestamp_str}.json"
                        with archive_path.open("w") as f:
                            json.dump(symbol_cache[-1000:], f)
                except (OSError, FileNotFoundError, PermissionError, json.JSONDecodeError) as e:
                    # Non-fatal, just log the error
                    logger.debug(f"Error persisting training data: {e}")

            self.log_training_progress(symbol, features)
        except (ValueError, TypeError, AttributeError, KeyError, RuntimeError) as e:
            logger.exception(f"Error in collect_training_data: {e}")
            return []
        else:
            return features

    def log_training_progress(self, symbol: str, features: list[float]) -> None:
        """Log training progress with automatic history cleanup"""
        try:
            # Only log periodically to avoid flooding
            should_log = len(self.training_cache.get(symbol, [])) % 100 == 0
            if should_log:
                feature_count = len(features)
                # VECTORIZED total samples calculation for performance
                total_samples = sum(len(samples) for samples in self.training_cache.values())
                logger.info(f"Training data collection: {symbol} - {feature_count} features, {total_samples} total samples")

            # 24/7 FIX: Trim training history to prevent unbounded memory growth
            if len(self.training_history) > self.max_training_history:
                self.training_history = self.training_history[-self.max_training_history :]

        except (ValueError, TypeError, AttributeError, KeyError) as e:
            # Non-fatal error, just log it
            logger.debug(f"Error logging training progress: {e}")


# AI training pipeline state - using dict to avoid global keyword
_ai_training_pipeline_state: dict[str, AITrainingDataPipeline | None] = {"instance": None}


def get_ai_training_pipeline(cache: Any = None) -> AITrainingDataPipeline | None:
    """
    Get or create the global AI training pipeline instance.

    Args:
        cache: Optional cache instance. If None, uses canonical_cache.

    Returns:
        AITrainingDataPipeline instance or None if initialization fails.
    """
    try:
        if _ai_training_pipeline_state["instance"] is None:
            _ai_training_pipeline_state["instance"] = AITrainingDataPipeline(cache=cache)
        return _ai_training_pipeline_state["instance"]
    except Exception as e:
        logger.warning(f"Failed to get AI training pipeline: {e}")
        return None


def get_training_stats() -> dict[str, Any]:
    """
    Get training statistics from the AI training pipeline.

    Returns:
        Dictionary containing training statistics.
    """
    try:
        pipeline = get_ai_training_pipeline()
        if pipeline is None:
            return {
                "status": "unavailable",
                "error": "AI training pipeline not available",
                "timestamp": _now_iso(),
            }

        # Get training status from pipeline
        status = pipeline.get_training_status() if hasattr(pipeline, "get_training_status") else {}

        return {
            "status": "ok",
            "pipeline_running": getattr(pipeline, "is_running", False),
            "current_accuracy": getattr(pipeline, "_current_accuracy", 0.0),
            "training_status": status,
            "timestamp": _now_iso(),
        }
    except Exception as e:
        logger.warning(f"Failed to get training stats: {e}")
        return {
            "status": "error",
            "error": str(e),
            "timestamp": _now_iso(),
        }


# Auto-start pipeline when module is imported (opt-out via env)
# DISABLED: Now started explicitly in app_factory.py lifespan for proper event loop
try:
    if os.getenv("AUTO_START_AI_TRAINING", "0") == "1":
        import asyncio

        _pipeline = get_ai_training_pipeline()
        if _pipeline is not None and not getattr(_pipeline, "is_running", False):
            loop = asyncio.get_event_loop()
            if loop.is_running():
                loop.create_task(_pipeline.start())
            else:
                loop.run_until_complete(_pipeline.start())
except Exception as _auto_exc:  # pragma: no cover - defensive autostart guard
    logger.debug(f"Auto-start of AI training pipeline skipped: {_auto_exc}")
