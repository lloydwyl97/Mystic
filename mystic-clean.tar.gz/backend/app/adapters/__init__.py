"""
App adapters module
"""
