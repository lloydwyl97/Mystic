"""
App core module
"""
