"""
App domain module
"""
