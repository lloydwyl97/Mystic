"""
Auto Trading Loop Service
Runs every 60 seconds to process signals and execute trades
Integrates with existing alert and signal systems

LEGACY EXECUTION PATH: When portfolio_engine_integration is the sole control-plane,
set AUTO_TRADING_LOOP_EXECUTION_ENABLED=false. This loop then runs mode evaluation
and alerts only; no trade execution.
"""

import asyncio
import contextlib
import inspect
import json
import logging
import os
import random
import time
from datetime import datetime, timezone
from typing import Any

import aiohttp

from backend.ai_strategy_execution import execute_ai_strategy_signal
from backend.services.auto_trader_mode_manager import get_auto_trader_mode_manager
from backend.services.circuit_breaker_service import trading_circuit_breaker
from backend.services.task_manager import task_manager
from backend.signal_manager import SignalManager

# Import from single source of truth
try:
    from backend.config.trading_universe import (
        EXCHANGE_ID,
        TOP10_COINS,
        TRADING_SYMBOLS,
    )
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

from backend.utils.alerts import broadcast_alert

# Direct imports for production
from backend.websocket_manager import websocket_manager

WEBSOCKET_MANAGER_AVAILABLE = True
AI_STRATEGY_EXECUTION_AVAILABLE = True
SIGNAL_MANAGER_AVAILABLE = True
ALERTS_AVAILABLE = True

logger = logging.getLogger("auto_trading_loop")

# Configuration
TRADE_AMOUNT_USD = float(os.getenv("TRADE_AMOUNT_USD", "15"))
_val = os.getenv("MIN_SIGNAL_CONFIDENCE")
MIN_SIGNAL_CONFIDENCE = float(_val) if _val is not None else int(os.getenv("MIN_SIGNAL_CONFIDENCE_PCT", "46")) / 100.0
AUTO_TRADING_ENABLED = os.getenv("AUTO_TRADING_ENABLED", "true").lower() == "true"  # LIVE MODE ENABLED
# SOLE EXECUTOR: When portfolio_engine_integration is canonical, auto_trading_loop must NOT execute.
# Set to false to make portfolio_engine the sole control-plane authority.
AUTO_TRADING_LOOP_EXECUTION_ENABLED = os.getenv("AUTO_TRADING_LOOP_EXECUTION_ENABLED", "false").lower() in ("1", "true", "yes")

# Use TRADING_SYMBOLS from trading_universe (live data)
BINANCE_US_TOP10 = list(TRADING_SYMBOLS)

# Canonical symbol mapping from signal IDs to Binance.US tickers (dynamically generated from TOP10_COINS)
# Only include symbols that are in the Top-10
CANONICAL_SYMBOL_MAP: dict[str, str] = {}
for symbol in TRADING_SYMBOLS:
    base = symbol.replace("USDT", "").lower()
    CANONICAL_SYMBOL_MAP[base] = symbol
    # Add common variations
    if base == "btc":
        CANONICAL_SYMBOL_MAP["bitcoin"] = symbol
    elif base == "eth":
        CANONICAL_SYMBOL_MAP["ethereum"] = symbol
    elif base == "sol":
        CANONICAL_SYMBOL_MAP["solana"] = symbol
    elif base == "ada":
        CANONICAL_SYMBOL_MAP["cardano"] = symbol
    elif base == "doge":
        CANONICAL_SYMBOL_MAP["dogecoin"] = symbol
    elif base == "ltc":
        CANONICAL_SYMBOL_MAP["litecoin"] = symbol
    elif base == "avax":
        CANONICAL_SYMBOL_MAP["avalanche-2"] = symbol
    elif base == "link":
        CANONICAL_SYMBOL_MAP["chainlink"] = symbol
    elif base == "xrp":
        CANONICAL_SYMBOL_MAP["ripple"] = symbol
        CANONICAL_SYMBOL_MAP["xrp"] = symbol
    elif base == "bch":
        CANONICAL_SYMBOL_MAP["bitcoin-cash"] = symbol
        CANONICAL_SYMBOL_MAP["bitcoin cash"] = symbol

# Exchange routing configuration - Binance US only (uses EXCHANGE_ID from trading_universe)
EXCHANGE_ROUTING = dict.fromkeys(CANONICAL_SYMBOL_MAP.keys(), EXCHANGE_ID)

# Redis keys we consider when reading live signals
HASHED_SIGNAL_PATTERNS: dict[str, str] = {
    "signal:*": "ai_signal",
    "ai_signal:*": "ai_signal_generator",
    "ai_decision:*": "ai_decision",
    "social_signal:*": "social_trading",
}


class AutoTradingLoop:
    """Auto trading loop that processes signals every 60 seconds"""

    def __init__(self, redis_client: Any) -> None:
        self.redis_client = redis_client
        self.signal_manager = SignalManager(redis_client)
        self.is_running = False
        self.last_execution_time = 0
        self.total_trades = 0
        self.successful_trades = 0
        self.failed_trades = 0
        self.health_issues = []
        self.data_source = "redis" if redis_client else "local_only"
        # Track background tasks for proper cleanup
        self._tasks: list[asyncio.Task[Any]] = []
        # Drawdown tracking: (timestamp, equity) last 2h; session_high for today
        self._equity_history: list[tuple[float, float]] = []
        self._session_high_equity: float = 0.0
        self._today_start_equity: float = 0.0
        self._last_midnight_ts: float = 0.0

        logger.info(f"Auto Trading Loop initialized - Enabled: {AUTO_TRADING_ENABLED}")
        logger.info(f"Trade amount: ${TRADE_AMOUNT_USD}, Min confidence: {MIN_SIGNAL_CONFIDENCE}")
        logger.info(f"Data source: {self.data_source}")

        # Log availability of dependencies
        if not WEBSOCKET_MANAGER_AVAILABLE:
            self.health_issues.append("Websocket manager not available")
        if not AI_STRATEGY_EXECUTION_AVAILABLE:
            self.health_issues.append("AI strategy execution not available")
        if not SIGNAL_MANAGER_AVAILABLE:
            self.health_issues.append("Signal manager not available")
        if not ALERTS_AVAILABLE:
            self.health_issues.append("Alerts not available")

    async def start(self):
        """Start the auto trading loop"""
        if self.is_running:
            logger.warning("Auto trading loop is already running")
            return

        if not AUTO_TRADING_ENABLED:
            logger.info("Auto trading is disabled - running in simulation mode")

        self.is_running = True
        logger.info("[START] Starting Auto Trading Loop (60s intervals)")

        # Send startup alert with ASCII-only content
        mode = "LIVE" if AUTO_TRADING_ENABLED else "SIMULATION"
        alert_msg = f"[START] Auto Trading Loop Started\nTrade Amount: ${TRADE_AMOUNT_USD}\nMin Confidence: {MIN_SIGNAL_CONFIDENCE}\nMode: {mode}\nData Source: {self.data_source}"
        await broadcast_alert(alert_msg)

        # Start the main loop
        task = await task_manager.create_task(self._run_loop(), name="auto_trading_loop:run_loop")
        self._tasks.append(task)

    async def stop(self):
        """Stop the auto trading loop"""
        if not self.is_running:
            return
        # Cancel all background tasks
        for task in self._tasks:
            if not task.done():
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task
        self._tasks.clear()
        self.is_running = False
        logger.info("[STOP] Auto Trading Loop stopped")

        # Send shutdown alert with ASCII-only content
        if self.total_trades > 0:
            success_rate = self.successful_trades / self.total_trades * 100
            alert_msg = f"[STOP] Auto Trading Loop Stopped\nTotal Trades: {self.total_trades}\nSuccess Rate: {success_rate:.1f}%\nData Source: {self.data_source}"
        else:
            alert_msg = f"[STOP] Auto Trading Loop Stopped\nNo trades executed\nData Source: {self.data_source}"

        await broadcast_alert(alert_msg)

    async def _run_loop(self):
        """Main trading loop - runs every 60 seconds"""
        while self.is_running:
            try:
                start_time = time.time()

                # AUTO-TRADER MODE MANAGEMENT - Evaluate and switch modes
                await self._evaluate_and_switch_modes()

                # Process signals and execute trades
                await self._process_signals()

                # Update last execution time
                self.last_execution_time = time.time()

                # Calculate execution time
                execution_time = time.time() - start_time
                logger.info(f"Trading cycle completed in {execution_time:.2f}s")

                # Wait for next cycle (60 seconds) with jitter to avoid thundering herd
                jitter = random.uniform(0, 5)  # 0-5 second jitter
                await asyncio.sleep(60 + jitter)

            except asyncio.CancelledError:
                logger.info("Auto trading loop cancelled")
                break
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError, ConnectionError, OSError) as e:
                logger.exception(f"Error in auto trading loop: {e}")
                self.health_issues.append(f"Loop error: {e}")
                await asyncio.sleep(60)  # Continue after error

    async def _evaluate_and_switch_modes(self) -> None:
        """Evaluate market conditions and switch auto-trader modes if needed"""
        try:
            mode_manager = get_auto_trader_mode_manager()

            # Get current portfolio and market data for evaluation
            portfolio_data = await self._get_portfolio_data()
            market_data = await self._get_market_data()
            ai_signals = await self._get_ai_signals()

            # Check hard kill circuit breakers first (24/7: use async to persist state)
            hard_kill_check = await trading_circuit_breaker.check_all_hard_kills_async(portfolio_data)
            if hard_kill_check["any_active"]:
                logger.warning(f"[HARD KILL] Circuit breaker active: {hard_kill_check['conditions']}")
                mode_manager.force_safe_mode("circuit_breaker")
                return

            # Evaluate auto-switch conditions
            new_mode = mode_manager.evaluate_and_switch(portfolio_data, market_data, ai_signals)

            if new_mode:
                logger.info(f"[MODE SWITCH] Auto-switched to {new_mode} based on market conditions")

        except Exception as e:
            logger.exception(f"[MODE EVAL] Error in mode evaluation: {e}")
            # On error, force safe mode for safety
            try:
                mode_manager = get_auto_trader_mode_manager()
                mode_manager.force_safe_mode("evaluation_error")
            except Exception as e:
                logger.warning("Mode manager force_safe_mode failed: %s", e)

    async def _get_portfolio_data(self) -> dict[str, float]:
        """Get current portfolio data for mode evaluation"""
        try:
            # Get from paper trading API
            async with aiohttp.ClientSession() as session, session.get("http://localhost:8000/api/paper-trading/status") as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("status") == "success":
                        details = data.get("details", {})
                        equity = float(details.get("total_balance_usd", 0.0) or 0.0)
                        principal = float(details.get("principal", 0.0) or 0.0)
                        realized = float(details.get("realized_pnl", 0) or 0)

                        # Drawdown tracking: update history and compute
                        now = time.time()
                        cutoff_2h = now - 7200.0
                        self._equity_history.append((now, equity))
                        self._equity_history = [(t, e) for t, e in self._equity_history if t >= cutoff_2h]

                        midnight = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
                        midnight_ts = midnight.timestamp()
                        if midnight_ts > self._last_midnight_ts:
                            self._last_midnight_ts = midnight_ts
                            self._session_high_equity = equity
                            self._today_start_equity = equity
                        else:
                            self._session_high_equity = max(self._session_high_equity, equity)
                            if self._today_start_equity == 0 and equity > 0:
                                self._today_start_equity = equity

                        max_2h = max((e for _, e in self._equity_history), default=0.0) or 1.0
                        max_today = self._session_high_equity or 1.0
                        dd_2h = (max_2h - equity) / max_2h if max_2h > 0 else 0.0
                        dd_today = (max_today - equity) / max_today if max_today > 0 else 0.0

                        return {
                            "total_equity": equity,
                            "principal": principal,
                            "unrealized_pct": details.get("pnl_vs_principal_pct", 0) / 100.0,
                            "realized_pnl_today": realized,
                            "drawdown_2h": max(0.0, min(1.0, dd_2h)),
                            "drawdown_today": max(0.0, min(1.0, dd_today)),
                        }
        except Exception as e:
            logger.debug(f"Could not get portfolio data: {e}")

        # Fallback defaults
        return {"total_equity": 0.0, "principal": 0.0, "unrealized_pct": 0.0, "realized_pnl_today": 0.0, "drawdown_2h": 0.0, "drawdown_today": 0.0}

    async def _get_market_data(self) -> dict[str, float]:
        """Get current market data for mode evaluation"""
        try:
            # Get ATR and trend data from market analysis
            async with aiohttp.ClientSession() as session, session.get("http://localhost:8000/api/market-analysis/summary") as response:
                if response.status == 200:
                    data = await response.json()
                    return {"atr_percent": data.get("average_atr_percent", 0.03), "trend_strength": data.get("average_trend_strength", 0.5)}
        except Exception as e:
            logger.debug(f"Could not get market data: {e}")

        # Fallback defaults
        return {
            "atr_percent": 0.03,  # Default 3%
            "trend_strength": 0.5,  # Neutral
        }

    async def _get_ai_signals(self) -> dict[str, float]:
        """Get current AI signals for mode evaluation"""
        try:
            # Get active signals
            signals = await self._get_all_signals()
            if signals:
                # Calculate average confidence (normalize each to 0-1 before averaging)
                from backend.services.confidence_normalizer import ConfidenceNormalizer

                confidences = []
                for s in signals:
                    if "confidence" in s:
                        raw = s.get("confidence", 0.5)
                        confidences.append(ConfidenceNormalizer.normalize(float(raw) if raw is not None else 0.5))
                avg_confidence = sum(confidences) / len(confidences) if confidences else 0.5
                return {"confidence": avg_confidence}
        except Exception as e:
            logger.debug(f"Could not get AI signals: {e}")

        # Fallback defaults
        return {"confidence": 0.5}  # Neutral confidence

    async def _process_signals(self):
        """Process all available signals and execute trades"""
        try:
            # Get all signals from Redis
            signals = await self._get_all_signals()

            if not signals:
                logger.debug("No signals to process")
                return

            logger.info(f"Processing {len(signals)} signals")

            # Process each signal
            for signal in signals:
                await self._process_single_signal(signal)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error processing signals: {e}")

    async def _get_all_signals(self) -> list[dict[str, Any]]:
        """Get all available signals from Redis using non-blocking scan"""
        try:
            all_signals: list[dict[str, Any]] = []
            stale_signals = 0
            current_time = time.time()
            max_signal_age = 300  # 5 minutes max age for signals

            if not self.redis_client:
                logger.debug("No redis client configured, returning empty signal list")
                return []

            scan_iter = getattr(self.redis_client, "scan_iter", None)
            if not scan_iter:
                logger.debug("Redis client does not support scan_iter, returning empty signal list")
                return []

            # Helper: iterate keys for a given pattern, whether the iterator is async or sync
            async def _yield_keys(pattern: str):
                try:
                    iterator = scan_iter(match=pattern, count=100)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.debug(f"Failed to iterate pattern {pattern}: {e}")
                    return

                if iterator is None:
                    return

                if hasattr(iterator, "__aiter__"):
                    async for key in iterator:
                        if key is None:
                            continue
                        yield key.decode("utf-8") if isinstance(key, (bytes, bytearray)) else str(key)
                else:
                    loop = asyncio.get_event_loop()
                    try:
                        keys = await loop.run_in_executor(None, lambda: list(iterator))
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                        logger.debug(f"Failed to collect keys for pattern {pattern}: {e}")
                        return

                    for key in keys:
                        if key is None:
                            continue
                        yield key.decode("utf-8") if isinstance(key, (bytes, bytearray)) else str(key)

            async def _call_lindex(key: str):
                try:
                    res = self.redis_client.lindex(key, 0)
                    if asyncio.iscoroutine(res) or asyncio.isfuture(res):
                        res = await res
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    loop = asyncio.get_event_loop()
                    try:
                        res = await loop.run_in_executor(None, lambda: self.redis_client.lindex(key, 0))
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                        logger.debug(f"Failed to lindex key {key}: {e}")
                        return None
                else:
                    return res

            async def _call_hgetall(key: str):
                try:
                    res = self.redis_client.hgetall(key)
                    if asyncio.iscoroutine(res) or asyncio.isfuture(res):
                        res = await res
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    # Try executor for blocking clients
                    loop = asyncio.get_event_loop()
                    try:
                        res = await loop.run_in_executor(None, lambda: self.redis_client.hgetall(key))
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                        logger.debug(f"Failed to hgetall key {key}: {e}")
                        return {}
                return res or {}

            def _decode_value(raw: Any) -> Any:
                if isinstance(raw, (bytes, bytearray)):
                    try:
                        return raw.decode("utf-8")
                    except UnicodeDecodeError:
                        return raw.decode("utf-8", "ignore")
                return raw

            def _parse_timestamp(value: Any, fallback: float) -> float:
                if isinstance(value, (int, float)):
                    return float(value)
                if isinstance(value, str):
                    try:
                        return float(value)
                    except ValueError:
                        try:
                            return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
                        except (ValueError, TypeError):
                            return fallback
                return fallback

            def _normalize_symbol(value: Any) -> str:
                if value is None:
                    return ""
                raw = str(value).strip()
                if not raw:
                    return ""
                cleaned = raw.replace("_", "").replace("-", "").replace("/", "").replace(" ", "").upper()
                if cleaned.endswith("USDT"):
                    cleaned = cleaned[:-4]
                elif cleaned.endswith("USD"):
                    cleaned = cleaned[:-3]
                return cleaned.lower() if cleaned else raw.lower()

            def _normalize_hash_signal(key: str, raw_data: dict[str, Any], source: str):
                if not isinstance(raw_data, dict):
                    return None
                normalized: dict[str, Any] = {}
                for field_key, value in raw_data.items():
                    normalized[str(field_key)] = _decode_value(value)
                symbol_value = normalized.get("symbol") or normalized.get("pair") or normalized.get("ticker") or key.split(":", 1)[-1]
                symbol = _normalize_symbol(symbol_value)
                if not symbol:
                    return None
                raw_confidence = normalized.get("confidence") or normalized.get("conf") or normalized.get("score") or 0.0
                try:
                    from backend.services.confidence_normalizer import ConfidenceNormalizer

                    confidence = ConfidenceNormalizer.normalize(float(raw_confidence) if raw_confidence is not None else 0.0)
                except (TypeError, ValueError):
                    confidence = 0.0
                from backend.services.signal_action import extract_canonical_action

                side = extract_canonical_action(normalized)
                timestamp = _parse_timestamp(
                    normalized.get("timestamp") or normalized.get("ts") or normalized.get("time") or normalized.get("updated_at"),
                    current_time,
                )
                return {
                    "symbol": symbol,
                    "confidence": confidence,
                    "side": side,
                    "timestamp": timestamp,
                    "source": source,
                    "metadata": normalized,
                    "redis_key": key,
                }

            seen_keys: set[str] = set()
            hashed_signals: list[dict[str, Any]] = []
            for pattern, source in HASHED_SIGNAL_PATTERNS.items():
                async for key in _yield_keys(pattern):
                    if not key or key in seen_keys:
                        continue
                    seen_keys.add(key)
                    signal_data = await _call_hgetall(key)
                    signal = _normalize_hash_signal(key, signal_data, source)
                    if not signal:
                        continue
                    if current_time - signal["timestamp"] > max_signal_age:
                        stale_signals += 1
                        continue
                    hashed_signals.append(signal)

            if hashed_signals:
                all_signals.extend(hashed_signals)

            # Legacy signal_history fallbacks (list-based)
            async for key in _yield_keys("signal_history:*"):
                try:
                    signal_data = await _call_lindex(key)
                    if not signal_data:
                        continue
                    if isinstance(signal_data, bytes):
                        with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                            signal_data = signal_data.decode("utf-8")

                    signal = json.loads(signal_data)
                    signal_timestamp = signal.get("timestamp", 0)
                    if current_time - signal_timestamp > max_signal_age:
                        stale_signals += 1
                        continue

                    all_signals.append(signal)
                except (json.JSONDecodeError, UnicodeDecodeError) as e:
                    logger.warning(f"Error parsing signal from {key}: {e}")
                    continue
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.debug(f"Error reading signal from {key}: {e}")
                    continue

            if stale_signals > 0:
                logger.info(f"Filtered {stale_signals} stale signals (older than {max_signal_age}s)")

            logger.debug(f"Retrieved {len(all_signals)} fresh signals")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error getting signals: {e}")
            self.health_issues.append(f"Signal retrieval error: {e}")
            return []
        else:
            return all_signals

    async def _process_single_signal(self, signal: dict[str, Any]):
        """Process a single signal and execute trade if conditions are met"""
        try:
            # Only BUY signals; SELL/HOLD are handled by portfolio_engine_integration
            from backend.services.signal_action import extract_canonical_action

            if extract_canonical_action(signal) != "buy":
                return

            symbol_id = signal.get("symbol", "").lower()

            # Map symbol to canonical Binance.US ticker
            binance_symbol = CANONICAL_SYMBOL_MAP.get(symbol_id)
            if not binance_symbol:
                logger.debug(f"Symbol {symbol_id} not in canonical mapping")
                return

            # Enforce Top-10 Binance.US allowlist
            if binance_symbol not in BINANCE_US_TOP10:
                logger.debug(f"Symbol {binance_symbol} not in Binance.US Top-10 allowlist")
                return

            # Normalize confidence via single entry point (0-1 or 0-100 -> canonical 0.0-1.0)
            from backend.services.confidence_normalizer import ConfidenceNormalizer

            raw_confidence = signal.get("confidence", 0)
            confidence = ConfidenceNormalizer.normalize(float(raw_confidence) if raw_confidence is not None else 0.0)

            # Check if signal meets minimum confidence
            if confidence < MIN_SIGNAL_CONFIDENCE:
                logger.debug(f"Signal confidence too low for {binance_symbol}: {confidence:.3f} < {MIN_SIGNAL_CONFIDENCE}")
                return

            # Check if signal indicates a breakout or strong signal
            if not self._is_strong_signal(signal, confidence):
                logger.debug(f"Signal not strong enough for {binance_symbol}")
                return

            # Determine exchange to use
            exchange = EXCHANGE_ROUTING.get(symbol_id, EXCHANGE_ID)

            # Execute trade
            success = await self._execute_trade(binance_symbol, exchange, signal)

            if success is True:
                self.successful_trades += 1
                self.total_trades += 1
                logger.info(f"[SUCCESS] Trade executed successfully: {binance_symbol} via {exchange}")
            elif success is False:
                self.failed_trades += 1
                self.total_trades += 1
                logger.warning(f"[FAIL] Trade failed: {binance_symbol} via {exchange}")

            # After processing the signal (success/failure), broadcast it:
            if WEBSOCKET_MANAGER_AVAILABLE:
                try:
                    await websocket_manager.broadcast_json({"type": "signal", "data": signal})
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.warning(f"Failed to broadcast signal: {e}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error processing signal for {signal.get('symbol', 'unknown')}: {e}")

    def _is_strong_signal(self, signal: dict[str, Any], confidence: float) -> bool:
        """Check if signal is strong enough to execute trade"""
        try:
            # Check for breakout signals
            if signal.get("breakout", False):
                logger.debug("Strong signal: breakout detected")
                return True

            # Check for high confidence signals
            if confidence > 0.8:  # 80% confidence
                logger.debug(f"Strong signal: high confidence {confidence:.3f}")
                return True

            # Check for strong technical indicators
            indicators = signal.get("indicators", {}) or {}
            rsi = indicators.get("rsi")
            if rsi is not None and (rsi < 20 or rsi > 80):
                logger.debug(f"Strong signal: extreme RSI {rsi}")
                return True

            # Check for momentum signals
            signal_type = signal.get("signal_type")
            if signal_type == "momentum" and confidence > 0.7:
                logger.debug(f"Strong signal: momentum with confidence {confidence:.3f}")
                return True

            # Check for volume signals
            volume_ratio = indicators.get("volume_ratio", 0)
            if volume_ratio > 2.0:  # 2x normal volume
                logger.debug(f"Strong signal: high volume ratio {volume_ratio}")
                result = True
            else:
                logger.debug(f"Signal not strong enough: confidence={confidence:.3f}, type={signal_type}, rsi={rsi}, volume_ratio={volume_ratio}")
                result = False
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error checking signal strength: {e}")
            self.health_issues.append(f"Signal strength check error: {e}")
            return False
        else:
            return result

    async def _execute_trade(self, symbol: str, exchange: str, signal: dict[str, Any]) -> bool | None:
        """Execute a trade on the specified exchange"""
        try:
            # SOLE EXECUTOR: portfolio_engine_integration is the canonical control-plane.
            # When execution disabled, skip (do not count as failure).
            if not AUTO_TRADING_LOOP_EXECUTION_ENABLED:
                logger.info(
                    "[LEGACY_EXECUTION_SKIPPED] portfolio_engine_integration is sole executor; AUTO_TRADING_LOOP_EXECUTION_ENABLED=false - would have executed %s via %s",
                    symbol,
                    exchange,
                )
                return None  # Skipped, not failed; caller must not increment failed_trades
            if not AUTO_TRADING_ENABLED:
                # Simulation mode
                logger.info(f"[SIM] SIMULATION: Would execute {symbol} trade via {exchange}")
                from backend.services.confidence_normalizer import ConfidenceNormalizer

                raw = signal.get("confidence", 0)
                confidence = ConfidenceNormalizer.normalize(float(raw) if raw is not None else 0.0)
                alert_msg = f"[SIM] SIMULATION TRADE\nSymbol: {symbol}\nExchange: {exchange.upper()}\nAmount: ${TRADE_AMOUNT_USD}\nConfidence: {confidence:.1%}"
                await broadcast_alert(alert_msg)
                return True

            # Live trading mode
            logger.info(f"[LIVE] Executing live trade: {symbol} via {exchange}")

            # Execute trade using existing AI strategy execution
            if AI_STRATEGY_EXECUTION_AVAILABLE:
                # Check if function is async or sync
                if inspect.iscoroutinefunction(execute_ai_strategy_signal):
                    # Function is async
                    result = await execute_ai_strategy_signal(symbol, TRADE_AMOUNT_USD, True)
                else:
                    # Function is sync - run in thread pool to avoid blocking
                    loop = asyncio.get_event_loop()
                    result = await loop.run_in_executor(
                        None,
                        execute_ai_strategy_signal,
                        symbol,
                        TRADE_AMOUNT_USD,
                        True,
                    )
            else:
                result = {"error": "AI strategy execution not available"}

            if result and "error" not in result:
                alert_msg = f"[SUCCESS] LIVE TRADE EXECUTED\nSymbol: {symbol}\nExchange: {exchange.upper()}\nAmount: ${TRADE_AMOUNT_USD}\nOrder ID: {result.get('orderId', 'N/A')}"
                await broadcast_alert(alert_msg)
                trade_result = True
            else:
                error_msg = result.get("error", "Unknown error") if result else "No result"
                await broadcast_alert(f"[FAIL] TRADE FAILED\nSymbol: {symbol.upper()}\nExchange: {exchange.upper()}\nError: {error_msg}")
                trade_result = False
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error executing trade for {symbol}: {e}")
            await broadcast_alert(f"[ERROR] Trade execution error for {symbol}: {e!s}")
            return False
        else:
            return trade_result

    def get_stats(self) -> dict[str, Any]:
        """Get trading statistics"""
        return {
            "is_running": self.is_running,
            "auto_trading_enabled": AUTO_TRADING_ENABLED,
            "total_trades": self.total_trades,
            "successful_trades": self.successful_trades,
            "failed_trades": self.failed_trades,
            "success_rate": ((self.successful_trades / self.total_trades * 100) if self.total_trades > 0 else 0),
            "trade_amount_usd": TRADE_AMOUNT_USD,
            "min_confidence": MIN_SIGNAL_CONFIDENCE,
            "last_execution_time": self.last_execution_time,
        }


# Global instance
# Auto trading loop state - using dict to avoid global keyword
_auto_trading_loop_state: dict[str, AutoTradingLoop | None] = {"instance": None}


def get_auto_trading_loop(redis_client: Any) -> AutoTradingLoop:
    """Get or create auto trading loop instance"""
    if _auto_trading_loop_state["instance"] is None:
        _auto_trading_loop_state["instance"] = AutoTradingLoop(redis_client)
    return _auto_trading_loop_state["instance"]
