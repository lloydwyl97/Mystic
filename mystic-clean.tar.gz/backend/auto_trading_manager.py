"""
Auto Trading Manager for Mystic Trading

Manages automated trading operations, separated from signal management for better modularity.
"""

import json
import logging
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# Direct imports for production with graceful fallback
try:
    from notification_service import get_notification_service

    NOTIFICATION_SERVICE_AVAILABLE = True
except (ImportError, ModuleNotFoundError):
    get_notification_service = None  # type: ignore[assignment]
    NOTIFICATION_SERVICE_AVAILABLE = False

try:
    from trading_config import trading_config

    TRADING_CONFIG_AVAILABLE = True
except (ImportError, ModuleNotFoundError):
    trading_config = None  # type: ignore[assignment]
    TRADING_CONFIG_AVAILABLE = False

logger = logging.getLogger(__name__)

# trading_config = SafeTradingConfig()  # Commented out to avoid redefinition


class AutoTradingManager:
    def __init__(self, redis_client: Any) -> None:
        self.redis_client = redis_client
        self.auto_trading_enabled: bool = False
        self.health_issues: deque[str] = deque(maxlen=50)

        # Key namespace for Redis to avoid collisions
        self.key_namespace = "mystic:auto_trading"

        # Initialize notification service with safe fallback
        if NOTIFICATION_SERVICE_AVAILABLE:
            try:
                self.notification_service = get_notification_service(redis_client)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.warning(f"Failed to initialize notification service: {e!s}")
                self.notification_service = None
                self.health_issues.append(f"Notification service unavailable: {e}")
        else:
            self.notification_service = None
            self.health_issues.append("Notification service module not available")

        # Load trading strategies with graceful degradation
        self.trading_strategies: dict[str, dict[str, Any]] = self._load_trading_strategies()

        # Initialize auto-trading status from Redis if available
        self._initialize_status()

    def _load_trading_strategies(self) -> dict[str, dict[str, Any]]:
        """Load trading strategies from Redis or config file. Degrade gracefully if unavailable."""
        try:
            # Try Redis first with namespaced key
            strategy_data = None
            if self.redis_client:
                try:
                    strategy_data = self.redis_client.get(f"{self.key_namespace}:trading_strategies")
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.warning(f"Error fetching trading strategies from Redis: {e!s}")
                    self.health_issues.append(f"Redis fetch failed: {e}")
            if strategy_data:
                try:
                    if isinstance(strategy_data, (bytes, bytearray)):
                        strategy_data = strategy_data.decode("utf-8")
                    strategies = json.loads(strategy_data)
                    if self._validate_strategy_schema(strategies):
                        return strategies
                    self.health_issues.append("Invalid trading strategies schema in Redis")
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.warning(f"Error parsing trading strategies from Redis: {e!s}")
                    self.health_issues.append(f"Redis strategy parsing failed: {e}")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.warning(f"Error loading trading strategies from Redis: {e!s}")
            self.health_issues.append(f"Redis strategy loading failed: {e}")

        # Try to load from config file
        config_path = str(Path(__file__).parent / "autobuy_config.json")
        config_path_obj = Path(config_path)
        if config_path_obj.exists():
            try:
                with config_path_obj.open() as f:
                    config = json.load(f)
                    if "trading_strategies" in config:
                        strategies = config["trading_strategies"]
                        if self._validate_strategy_schema(strategies):
                            return strategies
                        self.health_issues.append("Invalid trading strategies schema in config file")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.warning(f"Error loading trading strategies from config file: {e!s}")
                self.health_issues.append(f"Config file strategy loading failed: {e}")

        # No strategies available - degrade gracefully
        logger.warning("No trading strategies found in Redis or config file. Using empty strategy set.")
        self.health_issues.append("No strategies available - using empty strategy set")
        return {}

    def _validate_strategy_schema(self, strategies: dict[str, dict[str, Any]]) -> bool:
        """Validate trading strategies schema"""
        try:
            if not isinstance(strategies, dict):
                return False

            for strategy_name, strategy_config in strategies.items():
                if not isinstance(strategy_name, str) or not isinstance(strategy_config, dict):
                    return False

                # Check for required keys
                required_keys = ["enabled", "parameters"]
                if not all(key in strategy_config for key in required_keys):
                    return False
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error validating strategy schema: {e!s}")
            return False
        else:
            return True

    def _initialize_status(self) -> None:
        """Initialize auto-trading status from Redis"""
        try:
            auto_trade_data = None
            if self.redis_client:
                try:
                    auto_trade_data = self.redis_client.get(f"{self.key_namespace}:auto_trading_enabled")
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.warning(f"Error fetching auto_trading_enabled from Redis: {e!s}")
                    self.health_issues.append(f"Redis fetch failed: {e}")

            if auto_trade_data:
                try:
                    if isinstance(auto_trade_data, (bytes, bytearray)):
                        auto_trade_data = auto_trade_data.decode("utf-8")
                    auto_trading = json.loads(auto_trade_data)
                    self.auto_trading_enabled = auto_trading.get("enabled", False)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.warning(f"Error parsing auto_trading_enabled: {e!s}")
                    self.health_issues.append(f"Invalid auto_trading_enabled data: {e}")
                    self.auto_trading_enabled = False

            config_data = None
            if self.redis_client:
                try:
                    config_data = self.redis_client.get(f"{self.key_namespace}:auto_trade_config")
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.warning(f"Error fetching auto_trade_config from Redis: {e!s}")
                    self.health_issues.append(f"Redis fetch failed: {e}")

            if config_data:
                # Auto-trading config exists, no need to initialize
                logger.info("Auto-trading configuration loaded from Redis")
            else:
                # Initialize with default disabled config
                self._save_default_config(enabled=False)
                logger.info("Initialized default auto-trading configuration")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.warning(f"Error initializing auto-trading status: {e!s}")
            self.auto_trading_enabled = False
            self.health_issues.append(f"Status initialization failed: {e}")

    def _save_default_config(self, enabled: bool = False) -> None:
        """Save default auto-trading configuration to Redis"""
        try:
            # Get config methods safely
            risk_config = trading_config.get_risk_management_config() if TRADING_CONFIG_AVAILABLE else {"max_concurrent_trades": 5}
            perf_config = trading_config.get_performance_config() if TRADING_CONFIG_AVAILABLE else {"target_profit": 0.05}
            auto_trade_config: dict[str, Any] = {
                "enabled": enabled,
                "start_time": (datetime.now(timezone.utc).isoformat() if enabled else None),
                # Set stop_time when disabling to mark when it was stopped
                "stop_time": (None if enabled else datetime.now(timezone.utc).isoformat()),
                "strategies": (list(self.trading_strategies.keys()) if enabled else []),
                "risk_management": risk_config,
                "performance": perf_config,
                "data_source": "redis" if self.redis_client else "local_only",
                "health_issues": list(self.health_issues),
            }

            # Store in Redis with error handling and namespaced keys
            if self.redis_client:
                ttl = trading_config.AUTO_TRADE_CONFIG_TTL if TRADING_CONFIG_AVAILABLE else 3600
                try:
                    # Use setex if available, otherwise fallback to set
                    if hasattr(self.redis_client, "setex"):
                        self.redis_client.setex(
                            f"{self.key_namespace}:auto_trade_config",
                            ttl,
                            json.dumps(auto_trade_config),
                        )
                    else:
                        # Some redis-like clients may not implement setex
                        self.redis_client.set(f"{self.key_namespace}:auto_trade_config", json.dumps(auto_trade_config))
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.exception(f"Error writing auto_trade_config to Redis: {e!s}")
                    self.health_issues.append(f"Config save to Redis failed: {e}")

                # Update enabled flag in Redis
                enabled_ttl = trading_config.AUTO_TRADING_ENABLED_TTL if TRADING_CONFIG_AVAILABLE else 3600
                try:
                    enabled_payload = json.dumps(
                        {
                            "enabled": enabled,
                            "updated_at": (datetime.now(timezone.utc).isoformat()),
                        },
                    )
                    if hasattr(self.redis_client, "setex"):
                        self.redis_client.setex(
                            f"{self.key_namespace}:auto_trading_enabled",
                            enabled_ttl,
                            enabled_payload,
                        )
                    else:
                        self.redis_client.set(f"{self.key_namespace}:auto_trading_enabled", enabled_payload)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.exception(f"Error writing auto_trading_enabled to Redis: {e!s}")
                    self.health_issues.append(f"Enabled flag save to Redis failed: {e}")
            else:
                logger.warning("Redis client not available - using local state only")
                self.health_issues.append("Redis unavailable - using local state only")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error saving default auto-trading config: {e!s}")
            self.health_issues.append(f"Config save failed: {e}")

    async def start_auto_trading(self) -> dict[str, Any]:
        """Start automated trading"""
        try:
            logger.info("Starting automated trading...")
            self.auto_trading_enabled = True

            # Persist updated config
            self._save_default_config(enabled=True)

            # Optionally notify
            if self.notification_service:
                try:
                    # Best-effort notification; ignore failures
                    self.notification_service.notify("Auto-trading started")
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.warning(f"Notification failed on start: {e!s}")
                    self.health_issues.append(f"Start notification failed: {e}")

            return {
                "status": "success",
                "message": "Auto-trading started",
                "auto_trading": {"enabled": True},
                "redis_available": bool(self.redis_client),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error starting auto-trading: {e!s}")
            return {
                "status": "error",
                "message": f"Failed to start auto-trading: {e!s}",
                "auto_trading": {"enabled": self.auto_trading_enabled},
                "redis_available": bool(self.redis_client),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

    async def stop_auto_trading(self) -> dict[str, Any]:
        """Stop automated trading"""
        try:
            logger.info("Stopping automated trading...")
            self.auto_trading_enabled = False

            # Persist updated config (this will set stop_time)
            self._save_default_config(enabled=False)

            # Optionally notify
            if self.notification_service:
                try:
                    self.notification_service.notify("Auto-trading stopped")
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.warning(f"Notification failed on stop: {e!s}")
                    self.health_issues.append(f"Stop notification failed: {e}")

            return {
                "status": "success",
                "message": "Auto-trading stopped",
                "auto_trading": {"enabled": False},
                "redis_available": bool(self.redis_client),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error stopping auto-trading: {e!s}")
            return {
                "status": "error",
                "message": f"Failed to stop auto-trading: {e!s}",
                "auto_trading": {"enabled": self.auto_trading_enabled},
                "redis_available": bool(self.redis_client),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

    async def get_auto_trade_status(self) -> dict[str, Any]:
        """Get the current auto-trading configuration/status"""
        try:
            config_data = None
            redis_available = False

            if self.redis_client:
                try:
                    raw = self.redis_client.get(f"{self.key_namespace}:auto_trade_config")
                    if raw:
                        if isinstance(raw, (bytes, bytearray)):
                            raw = raw.decode("utf-8")
                        config_data = raw
                    redis_available = True
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.warning(f"Redis error getting auto-trade status: {e!s}")
                    self.health_issues.append(f"Redis status fetch failed: {e}")
                    redis_available = False

            if not config_data:
                # No config in Redis - return local status
                config = {
                    "enabled": self.auto_trading_enabled,
                    "strategies": list(self.trading_strategies.keys()),
                    "risk_management": trading_config.get_risk_management_config() if TRADING_CONFIG_AVAILABLE else {"max_concurrent_trades": 5},
                    "performance": trading_config.get_performance_config() if TRADING_CONFIG_AVAILABLE else {"target_profit": 0.05},
                    "data_source": "local_only" if not redis_available else "redis_missing_config",
                }
                config["health_issues"] = list(self.health_issues)

                return {
                    "status": "success",
                    "message": "Auto-trading status retrieved successfully",
                    "auto_trading": config,
                    "redis_available": redis_available,
                    "data_source": config["data_source"],
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

            config = json.loads(config_data)
            # Ensure health_issues present and updated
            config["health_issues"] = list(self.health_issues)
            return {
                "status": "success",
                "message": "Auto-trading status retrieved successfully",
                "auto_trading": config,
                "redis_available": redis_available,
                "data_source": "redis",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error getting auto-trade status: {e!s}")
            return {
                "status": "error",
                "message": f"Failed to get auto-trade status: {e!s}",
                "auto_trading": {
                    "enabled": self.auto_trading_enabled,
                    "data_source": "error",
                    "health_issues": [*list(self.health_issues), f"Status check error: {e}"],
                },
                "redis_available": False,
                "data_source": "error",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

    async def check_health(self) -> dict[str, Any]:
        """Check the health of auto-trading. Never raises - returns structured degraded status if unavailable."""
        try:
            config_data = None
            redis_available = False
            health_issues = []

            if self.redis_client:
                try:
                    config_data = self.redis_client.get(f"{self.key_namespace}:auto_trade_config")
                    redis_available = True
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.warning(f"Redis error checking health: {e!s}")
                    health_issues.append(f"Redis health check failed: {e}")

            if not config_data:
                health_issues.append("auto_trade_config missing from Redis" if redis_available else "Redis unavailable")
                return {
                    "healthy": False,
                    "status": "degraded",
                    "message": "Auto-trading config not found - using local state",
                    "redis_available": redis_available,
                    "data_source": "local_only",
                    "health_issues": health_issues + list(self.health_issues),
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

            if isinstance(config_data, (bytes, bytearray)):
                config_data = config_data.decode("utf-8")
            config = json.loads(config_data)
            redis_enabled = config.get("enabled", False)
            local_enabled = self.auto_trading_enabled

            # Check for mismatches
            if redis_enabled != local_enabled:
                health_issues.append(f"State mismatch: Redis={redis_enabled}, Local={local_enabled}")

            healthy = redis_enabled == local_enabled and len(health_issues) == 0

            return {
                "healthy": healthy,
                "status": "success" if healthy else "degraded",
                "message": "Health check completed successfully" if healthy else "Health issues detected",
                "redis_available": redis_available,
                "data_source": "redis",
                "health_issues": health_issues + list(self.health_issues),
                "state_match": redis_enabled == local_enabled,
                "redis_enabled": redis_enabled,
                "local_enabled": local_enabled,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error checking auto-trading health: {e!s}")
            return {
                "healthy": False,
                "status": "error",
                "message": f"Health check failed: {e!s}",
                "redis_available": False,
                "data_source": "error",
                "health_issues": [*list(self.health_issues), f"Health check error: {e}"],
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

    async def self_heal(self) -> dict[str, Any]:
        """Self-heal auto-trading if needed - reconcile both auto_trading_enabled and auto_trade_config"""
        try:
            redis_available = False
            auto_trade_data = None
            config_data = None
            if self.redis_client:
                try:
                    auto_trade_data = self.redis_client.get(f"{self.key_namespace}:auto_trading_enabled")
                    config_data = self.redis_client.get(f"{self.key_namespace}:auto_trade_config")
                    redis_available = True
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.warning(f"Redis error during self-heal: {e!s}")
                    self.health_issues.append(f"Self-heal Redis failed: {e}")

            should_be_enabled = False
            config_enabled = False

            # Check auto_trading_enabled flag
            if auto_trade_data:
                try:
                    if isinstance(auto_trade_data, (bytes, bytearray)):
                        auto_trade_data = auto_trade_data.decode("utf-8")
                    auto_trading = json.loads(auto_trade_data)
                    should_be_enabled = auto_trading.get("enabled", False)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.warning(f"Error parsing auto_trading_enabled: {e!s}")
                    self.health_issues.append(f"Invalid auto_trading_enabled data: {e}")

            # Check auto_trade_config
            if config_data:
                try:
                    if isinstance(config_data, (bytes, bytearray)):
                        config_data = config_data.decode("utf-8")
                    config = json.loads(config_data)
                    config_enabled = config.get("enabled", False)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.warning(f"Error parsing auto_trade_config: {e!s}")
                    self.health_issues.append(f"Invalid auto_trade_config data: {e}")

            # Check for mismatches between Redis keys
            if redis_available and auto_trade_data and config_data and should_be_enabled != config_enabled:
                logger.warning(f"Redis key mismatch: auto_trading_enabled={should_be_enabled}, auto_trade_config.enabled={config_enabled}")
                self.health_issues.append(f"Redis key mismatch: flag={should_be_enabled}, config={config_enabled}")
                # Use the config as the source of truth
                should_be_enabled = config_enabled

            # Determine what should be the current state
            target_enabled = should_be_enabled if redis_available else self.auto_trading_enabled

            if target_enabled and not self.auto_trading_enabled:
                # Auto-trading should be enabled but isn't
                logger.warning("Auto-trading is supposed to be enabled but isn't. Self-healing...")
                # best-effort: enable locally and persist
                self.auto_trading_enabled = True
                self._save_default_config(enabled=True)
                return {
                    "status": "healed",
                    "message": "Auto-trading was reactivated",
                    "healing_action": "start",
                    "redis_available": redis_available,
                    "data_source": "redis" if redis_available else "local_only",
                    "timestamp": (datetime.now(timezone.utc).isoformat()),
                }
            if not target_enabled and self.auto_trading_enabled:
                # Auto-trading should be disabled but isn't
                logger.warning("Auto-trading is supposed to be disabled but isn't. Self-healing...")
                self.auto_trading_enabled = False
                self._save_default_config(enabled=False)
                return {
                    "status": "healed",
                    "message": "Auto-trading was deactivated",
                    "healing_action": "stop",
                    "redis_available": redis_available,
                    "data_source": "redis" if redis_available else "local_only",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

            # No healing needed
            return {
                "status": "healthy",
                "message": "Auto-trading is in the correct state",
                "redis_available": redis_available,
                "data_source": "redis" if redis_available else "local_only",
                "health_issues": list(self.health_issues),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error self-healing auto-trading: {e!s}")
            return {
                "status": "error",
                "message": f"Error self-healing auto-trading: {e!s}",
                "redis_available": False,
                "data_source": "error",
                "health_issues": [*list(self.health_issues), f"Self-heal error: {e}"],
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }


# Global auto trading manager instance
# Auto trading manager state - using dict to avoid global keyword
_auto_trading_manager_state: dict[str, AutoTradingManager | None] = {"instance": None}


def get_auto_trading_manager(redis_client: Any) -> AutoTradingManager:
    """Get or create auto trading manager instance"""
    if _auto_trading_manager_state["instance"] is None:
        _auto_trading_manager_state["instance"] = AutoTradingManager(redis_client)
    return _auto_trading_manager_state["instance"]
