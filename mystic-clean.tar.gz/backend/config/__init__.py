"""Configuration module for the trading system."""

try:
    from .autobuy import AUTO_BUY_CONFIG, BOT_MONITORING
except ImportError as e:
    import logging

    logging.warning(f"Failed to import autobuy config: {e}")
    # Provide minimal fallback to prevent import errors
    AUTO_BUY_CONFIG = {
        "enabled": False,
        "symbols": [],
        "min_confidence": 0.75,
        "max_daily_orders": 200,
        "starting_capital": 250.0,
    }
    BOT_MONITORING = {
        "enabled": True,
        "log_trades": True,
        "max_log_size": 1000,
        "alert_on_error": True,
    }

try:
    from .settings import settings
except ImportError as e:
    import logging

    logging.warning(f"Failed to import settings: {e}")
    settings = None  # type: ignore[assignment]

__all__ = ["AUTO_BUY_CONFIG", "BOT_MONITORING", "settings"]
