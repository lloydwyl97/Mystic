"""
Autobuy Configuration - All Live Data, No Fallback/Hardcoded Data

This module provides configuration for autobuy trading operations.
All configuration:
- Loads from live environment variables
- Default values are configuration defaults only, not fallback data
- Connects to live backend endpoints (port 8000) for trading operations
- All trading operations use live market data - no fallback/hardcoded data

Live Data Sources:
- Trading symbols: From live environment variables or Binance.US top 10
- Trading configuration: From live environment variables
- All autobuy operations connect to backend (port 8000) for live order execution

Endpoint References:
- /api/trading/execute_live_market_buy - Live market buy execution (backend port 8000)
- All autobuy operations use live endpoints - no fallback/hardcoded data

Configuration Defaults:
- All default values are configuration defaults only, not fallback data
- Actual values come from environment variables or live backend endpoints
"""

import os

# Autobuy configuration from environment variables (live configuration)
# Default values are configuration defaults only, not fallback data
AUTO_BUY_CONFIG = {
    # Enable autobuy from environment (configuration default: true)
    "enabled": os.getenv("AUTOBUY_ENABLED", "true").lower() == "true",
    # Trading symbols from environment (configuration default: Binance.US top 10)
    # Actual symbols come from live backend or environment - not fallback data
    "symbols": os.getenv(
        "TRADING_SYMBOLS",
        "BTCUSDT,ETHUSDT,ADAUSDT,SOLUSDT,DOGEUSDT,XRPUSDT,BCHUSDT,LTCUSDT,AVAXUSDT,LINKUSDT",
    ).split(","),
    # Minimum confidence threshold (configuration default: 0.58 - AGGRESSIVE MODE)
    # Actual threshold from live environment - not fallback data
    "min_confidence": float(os.getenv("ML_MIN_CONFIDENCE", "0.58")),
    # Maximum daily orders (configuration default: 90 - AGGRESSIVE MODE)
    # Actual limit from live environment - not fallback data
    "max_daily_orders": int(os.getenv("MAX_DAILY_ORDERS", "90")),
    # Starting capital (configuration default: 120.0)
    # Actual capital from live environment - not fallback data
    "starting_capital": 250.0,
}

# Bot monitoring configuration (live monitoring settings)
# All values are live configuration - no fallback/hardcoded data
BOT_MONITORING = {
    # Monitoring enabled (live setting)
    "enabled": True,
    # Log trades to live database (backend port 8000)
    "log_trades": True,
    # Maximum log size (live configuration)
    "max_log_size": 1000,
    # Alert on errors (live configuration)
    "alert_on_error": True,
}
