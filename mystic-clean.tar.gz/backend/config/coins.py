"""
Coins Configuration - Binance.US Top-10 Only, All Live Data, No Fallback/Hardcoded Data

This module provides coin configuration using ONLY Binance.US Top-10 symbols.
All configuration:
- Uses Binance.US Top-10 symbols from live trading universe (no universal coin lists)
- All operations connect to live Binance.US endpoints via backend (port 8000)
- No fallback/hardcoded coin lists - all from live trading universe configuration
- Enforces Binance.US Top-10 only - no other exchanges or universal coins

Live Data Sources:
- Trading symbols: From `backend.config.trading_universe.TRADING_SYMBOLS` (Binance.US Top-10 only)
- All coin operations use live Binance.US Top-10 - no universal coin lists
- All trading operations connect to live Binance.US API via backend (port 8000)

Endpoint References:
- Binance.US API: https://api.binance.us (live exchange API)
- Backend API: Port 8000 (for live trading operations)
- All operations use live endpoints - no fallback/hardcoded data

IMPORTANT: This module ONLY uses Binance.US Top-10 coins.
No universal coin lists - all symbols from Binance.US Top-10 allowlist.
"""

# Import from single source of truth - Binance.US Top-10 only (live configuration)
from backend.config.trading_universe import FEATURED_EXCHANGE, TRADING_SYMBOLS

# Export exchange name (Binance.US only - from live trading universe configuration)
# No other exchanges supported - Binance.US only
__all__ = ["FEATURED_EXCHANGE", "FEATURED_SYMBOLS"]

# Binance.US Top-10 featured symbols (from live trading universe - ALL 10 COINS)
# No universal coin lists - Binance.US Top-10 only
# All 10 Binance.US Top-10 symbols: BTCUSDT, ETHUSDT, ADAUSDT, SOLUSDT, DOGEUSDT, XRPUSDT, BCHUSDT, LTCUSDT, AVAXUSDT, LINKUSDT
FEATURED_SYMBOLS: list[str] = list(TRADING_SYMBOLS)
