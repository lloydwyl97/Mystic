"""
Unified Exchange Configuration - Binance.US Only, All Live Data, No Fallback/Hardcoded Data

This module provides exchange configuration using ONLY Binance.US Top-10 symbols.
All configuration:
- Uses Binance.US Top-10 symbols from live trading universe (no hardcoded lists)
- All operations connect to live Binance.US endpoints via backend (port 8000)
- No fallback/hardcoded exchange or symbol lists - all from live trading universe
- Enforces Binance.US only - no other exchanges supported

Live Data Sources:
- Trading symbols: From `backend.config.trading_universe.TRADING_SYMBOLS` (Binance.US Top-10 only)
- Exchange configuration: From live trading universe (Binance.US only)
- All operations use live Binance.US Top-10 - no hardcoded lists
- All trading operations connect to live Binance.US API via backend (port 8000)

Endpoint References:
- Binance.US API: https://api.binance.us (live exchange API)
- Backend API: Port 8000 (for live trading operations)
- All operations use live endpoints - no fallback/hardcoded data

IMPORTANT: This module ONLY supports Binance.US exchange.
Binance.US Top-10 symbols only - all from live trading universe configuration.
"""

# Import from single source of truth - Binance.US Top-10 only (live configuration)
from backend.config.trading_universe import EXCHANGE_ID, TRADING_SYMBOLS

# Binance.US exchange key (from live trading universe configuration)
# No other exchanges supported - Binance.US only
BINANCE_EXCHANGE_KEY: str = EXCHANGE_ID

# Binance.US Top-10 symbols (from live trading universe - ALL 10 COINS)
# No hardcoded lists - all from live configuration
BINANCE_TOP10: list[str] = list(TRADING_SYMBOLS)

# Supported exchanges (Binance.US only - from live configuration)
# No other exchanges - Binance.US only
SUPPORTED_EXCHANGES: list[str] = [BINANCE_EXCHANGE_KEY]


def is_supported_exchange(exchange: str) -> bool:
    """
    Check if exchange is supported (Binance.US only).

    Args:
        exchange: Exchange identifier to check

    Returns:
        True if exchange is Binance.US, False otherwise
    """
    return exchange in SUPPORTED_EXCHANGES


def is_supported_symbol(symbol: str) -> bool:
    """
    Check if symbol is in live Binance.US Top-10 allowlist.

    Args:
        symbol: Symbol to check (from live trading operations)

    Returns:
        True if symbol is in live Binance.US Top-10 allowlist, False otherwise
    """
    return symbol in BINANCE_TOP10


def normalize_symbol_for_display(symbol: str) -> str:
    """
    Convert symbol to display format (BTCUSDT -> BTC-USD) - Live allowlist enforced.

    Args:
        symbol: Symbol to convert (from live trading operations)

    Returns:
        Symbol in BTC-USD display format if in live allowlist, original otherwise
    """
    if symbol in BINANCE_TOP10:
        return symbol.replace("USDT", "-USD")
    return symbol


def normalize_symbol_for_storage(symbol: str) -> str:
    """
    Convert symbol to storage format (BTC-USD -> BTCUSDT) - Live allowlist enforced.

    Args:
        symbol: Symbol to normalize (from live trading operations)

    Returns:
        Symbol in BTCUSDT storage format (normalized from live input)
    """
    if "-USD" in symbol:
        return symbol.replace("-USD", "USDT")
    return symbol
