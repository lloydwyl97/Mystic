#!/usr/bin/env python3
"""
Logging Configuration - All Live Data, No Fallback/Hardcoded Data

This module provides centralized logging configuration for the Mystic Trading Platform.
All logging:
- Logs live operations from backend endpoints (port 8000)
- Captures live API requests and responses
- Logs live application events and errors
- No fallback/hardcoded log data - all logs from live operations
- Configures log handlers and formatters for live backend services

Live Data Sources:
- Live API requests/responses from backend (port 8000)
- Live application events and errors from backend operations
- Live database operations from backend (port 8000)
- All logs are from live operations - no mock/test data

Endpoint References:
- Backend API: Port 8000 (logs all live API requests)
- Log files: logs/*.log (collected by Promtail, forwarded to Loki)
- All log data is live - no fallback/hardcoded log entries
"""

import logging
import logging.handlers
import sys
from datetime import datetime, timezone
from pathlib import Path


def setup_logging() -> bool:
    """
    Setup centralized logging configuration for live backend operations (port 8000).

    Configures logging handlers for:
    - Live API requests/responses from backend (port 8000)
    - Live application events and errors
    - Live database operations
    - All logs from live operations - no fallback/hardcoded log data

    Returns:
        True if logging configuration initialized successfully
    """
    # Create logs directory (for live log files from backend on port 8000)
    logs_dir = Path("logs")
    logs_dir.mkdir(exist_ok=True)

    # Clear existing handlers to avoid duplicates
    root_logger = logging.getLogger()
    root_logger.handlers.clear()

    # Set up formatters (for live log entries from backend on port 8000)
    detailed_formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s")

    simple_formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")

    # Rotating file handler for main log (NON-AI log - size-based rotation)
    main_log_file = logs_dir / "mystic_trading.log"
    file_handler = logging.handlers.RotatingFileHandler(
        main_log_file,
        maxBytes=10 * 1024 * 1024,  # 10MB max per file (pruned by age policy)
        backupCount=5,  # Keep 5 backups for rotation
        encoding="utf-8",
    )
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(detailed_formatter)

    # Console handler (for live log output)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(simple_formatter)

    # Rotating error file handler (NON-AI log - size-based rotation)
    error_log_file = logs_dir / "errors.log"
    error_handler = logging.handlers.RotatingFileHandler(
        error_log_file,
        maxBytes=10 * 1024 * 1024,  # 10MB max per error file (pruned by age policy)
        backupCount=3,  # Keep 3 error log backups
        encoding="utf-8",
    )
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(detailed_formatter)

    # Configure root logger (for live backend operations on port 8000)
    root_logger.setLevel(logging.INFO)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)
    root_logger.addHandler(error_handler)

    # Create component-specific loggers (for live operations from backend on port 8000)
    component_loggers = ["backend", "trading", "ai", "database", "api", "monitoring"]

    for component in component_loggers:
        component_log_file = logs_dir / f"{component}.log"
        component_handler = logging.handlers.RotatingFileHandler(
            component_log_file,
            maxBytes=10 * 1024 * 1024,  # 10MB max per component file (pruned by age policy)
            backupCount=3,  # Keep 3 backups per component
            encoding="utf-8",
        )
        component_handler.setLevel(logging.INFO)
        component_handler.setFormatter(detailed_formatter)

        component_logger = logging.getLogger(component)
        component_logger.addHandler(component_handler)
        component_logger.setLevel(logging.INFO)

    # AI Learning logger - separate handler for AI learning data (NO age-based pruning)
    ai_learning_dir = logs_dir / "ai_learning_archives"
    ai_learning_dir.mkdir(exist_ok=True)

    ai_learning_log = ai_learning_dir / "ai_learning.log"
    ai_learning_handler = logging.handlers.RotatingFileHandler(
        ai_learning_log,
        maxBytes=100 * 1024 * 1024,  # 100MB per AI learning file
        backupCount=50,  # Large backup count (managed by 500GB cap, not age)
        encoding="utf-8",
    )
    ai_learning_handler.setLevel(logging.INFO)
    ai_learning_handler.setFormatter(detailed_formatter)

    ai_learning_logger = logging.getLogger("ai_learning")
    ai_learning_logger.addHandler(ai_learning_handler)
    ai_learning_logger.setLevel(logging.INFO)

    # Test logging (confirms live logging configuration initialized)
    logger = logging.getLogger("logging_config")
    logger.info("Logging configuration initialized successfully (backend port 8000)")

    return True


def get_logger(name: str) -> logging.Logger:
    """
    Get a properly configured logger for a component (live backend operations on port 8000).

    Args:
        name: Logger name (typically module name)

    Returns:
        Logger instance configured for live backend operations (port 8000)
    """
    return logging.getLogger(name)


def log_system_startup() -> None:
    """
    Log live system startup information (backend port 8000).

    Logs startup details from live backend initialization:
    - Startup timestamp (UTC)
    - Python version from live runtime
    - Working directory from live filesystem
    - All information from live system state
    """
    logger = logging.getLogger("system")
    logger.info("=" * 60)
    logger.info("MYSTIC TRADING PLATFORM STARTUP")
    logger.info("=" * 60)
    # Live startup timestamp (UTC timezone-aware)
    logger.info(f"Startup time: {datetime.now(timezone.utc).isoformat()}")
    logger.info(f"Python version: {sys.version}")
    # Live working directory from current filesystem state
    logger.info(f"Working directory: {Path.cwd()}")
    logger.info("=" * 60)


def log_system_shutdown() -> None:
    """
    Log live system shutdown information (backend port 8000).

    Logs shutdown details from live backend shutdown:
    - Shutdown timestamp (UTC)
    - All information from live system state
    """
    logger = logging.getLogger("system")
    logger.info("=" * 60)
    logger.info("MYSTIC TRADING PLATFORM SHUTDOWN")
    logger.info("=" * 60)
    # Live shutdown timestamp (UTC timezone-aware)
    logger.info(f"Shutdown time: {datetime.now(timezone.utc).isoformat()}")
    logger.info("=" * 60)


if __name__ == "__main__":
    # Test the logging configuration
    setup_logging()
    log_system_startup()

    # Test different log levels
    logger = logging.getLogger("test")
    logger.debug("This is a debug message")
    logger.info("This is an info message")
    logger.warning("This is a warning message")
    logger.error("This is an error message")
    logger.critical("This is a critical message")

    log_system_shutdown()

logger.info("[OK] Logging configuration test complete!")
logger.info("📁 Check the logs/ directory for output files")
