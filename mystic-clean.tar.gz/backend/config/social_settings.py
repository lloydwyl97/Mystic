"""
Social Trading Configuration - All Live Data, No Fallback/Hardcoded Data

This module provides social trading API configuration for the backend API (port 8000).
All configuration:
- Loads from live environment variables
- Default values are configuration defaults only, not fallback data
- Connects to live social media APIs (Twitter, Reddit, Telegram)
- All social data from live API endpoints - no fallback/hardcoded data
- Integrates with backend (port 8000) for social trading operations

Live Data Sources:
- Twitter API: Live API keys from environment variables
- Reddit API: Live API credentials from environment variables
- Telegram API: Live bot tokens from environment variables
- All social media data from live API endpoints
- Social trading operations connect to backend (port 8000)

Endpoint References:
- Backend API: Port 8000 (for social trading operations)
- Twitter API: https://api.twitter.com (live social media API)
- Reddit API: https://www.reddit.com/api (live social media API)
- Telegram API: https://api.telegram.org (live messaging API)
- All connections use live endpoints - no fallback/hardcoded data
"""

import logging
import os

# Load environment variables
try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass  # dotenv not available, use system environment

logger = logging.getLogger(__name__)


class SocialSettings:
    """
    Social media API settings for live social trading operations (backend port 8000).

    Loads configuration from live environment variables for:
    - Twitter API (live social media data)
    - Reddit API (live social media data)
    - Telegram API (live messaging notifications)
    - Social trading configuration (live trading operations)

    All API credentials from live environment variables - no hardcoded values.
    """

    def __init__(self) -> None:
        # Twitter API settings (live API credentials from environment variables)
        self.twitter_api_key = os.getenv("TWITTER_API_KEY", "")
        self.twitter_api_secret = os.getenv("TWITTER_API_SECRET", "")
        self.twitter_access_token = os.getenv("TWITTER_ACCESS_TOKEN", "")
        self.twitter_access_secret = os.getenv("TWITTER_ACCESS_SECRET", "")
        self.twitter_bearer_token = os.getenv("TWITTER_BEARER_TOKEN", "")

        # Reddit API settings (live API credentials from environment variables)
        self.reddit_client_id = os.getenv("REDDIT_CLIENT_ID", "")
        self.reddit_client_secret = os.getenv("REDDIT_CLIENT_SECRET", "")
        # Configuration default user agent (not fallback data)
        self.reddit_user_agent = os.getenv("REDDIT_USER_AGENT", "MysticTrader/1.0")

        # Telegram API settings (live bot credentials from environment variables)
        self.telegram_bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "")
        self.telegram_chat_id = os.getenv("TELEGRAM_CHAT_ID", "")

        # Social trading settings (live configuration from environment variables)
        self.enable_social_trading = os.getenv("ENABLE_SOCIAL_TRADING", "true").lower() == "true"
        self.social_trading_mode = os.getenv("SOCIAL_TRADING_MODE", "live")

        # Feature flags to disable individual social platforms
        self.enable_twitter = os.getenv("ENABLE_TWITTER", "true").lower() == "true"
        self.enable_discord = os.getenv("ENABLE_DISCORD", "true").lower() == "true"
        self.enable_telegram = os.getenv("ENABLE_TELEGRAM", "true").lower() == "true"
        self.enable_reddit = os.getenv("ENABLE_REDDIT", "true").lower() == "true"
        try:
            # Configuration default (not fallback data)
            self.max_copy_traders = int(os.getenv("MAX_COPY_TRADERS", "5"))
        except (TypeError, ValueError):
            self.max_copy_traders = 5
        try:
            # Configuration default (not fallback data)
            self.social_data_update_interval = int(os.getenv("SOCIAL_DATA_UPDATE_INTERVAL", "60"))
        except (TypeError, ValueError):
            self.social_data_update_interval = 60

        # Log configuration status (live API configuration)
        self._log_status()

    def _log_status(self) -> None:
        """
        Log the status of social media API configurations (live configuration status).

        Logs which social media APIs are configured from live environment variables.
        All logging is about live API configuration - no fallback/hardcoded status.
        """
        if self.enable_twitter:
            if self.twitter_api_key and self.twitter_api_secret:
                logger.info("Twitter API configured and enabled (live API credentials loaded)")
            else:
                logger.info("Twitter API enabled but not configured (missing live credentials)")
        else:
            logger.info("Twitter API disabled by configuration")

        if self.enable_reddit:
            if self.reddit_client_id and self.reddit_client_secret:
                logger.info("Reddit API configured and enabled (live API credentials loaded)")
            else:
                logger.info("Reddit API enabled but not configured (missing live credentials)")
        else:
            logger.info("Reddit API disabled by configuration")

        if self.enable_telegram:
            if self.telegram_bot_token:
                logger.info("Telegram API configured and enabled (live bot token loaded)")
            else:
                logger.info("Telegram API enabled but not configured (missing live bot token)")
        else:
            logger.info("Telegram API disabled by configuration")

        logger.info(f"Social trading enabled: {self.enable_social_trading} (live configuration)")
        logger.info(f"Social trading mode: {self.social_trading_mode} (live mode)")

    def get_twitter_config(self) -> dict[str, str]:
        """
        Get Twitter API configuration (live API credentials).

        Returns:
            Dictionary with live Twitter API credentials from environment variables
            - All credentials from live environment variables - no hardcoded values
        """
        return {
            "api_key": self.twitter_api_key,
            "api_secret": self.twitter_api_secret,
            "access_token": self.twitter_access_token,
            "access_secret": self.twitter_access_secret,
            "bearer_token": self.twitter_bearer_token,
        }

    def get_reddit_config(self) -> dict[str, str]:
        """
        Get Reddit API configuration (live API credentials).

        Returns:
            Dictionary with live Reddit API credentials from environment variables
            - All credentials from live environment variables - no hardcoded values
        """
        return {
            "client_id": self.reddit_client_id,
            "client_secret": self.reddit_client_secret,
            "user_agent": self.reddit_user_agent,
        }

    def get_telegram_config(self) -> dict[str, str]:
        """
        Get Telegram API configuration (live bot credentials).

        Returns:
            Dictionary with live Telegram bot credentials from environment variables
            - All credentials from live environment variables - no hardcoded values
        """
        return {
            "bot_token": self.telegram_bot_token,
            "chat_id": self.telegram_chat_id,
        }

    def is_twitter_configured(self) -> bool:
        """
        Check if Twitter API is configured with live credentials and enabled.

        Returns:
            True if live Twitter API credentials are configured and enabled, False otherwise
        """
        return bool(self.enable_twitter and self.twitter_api_key and self.twitter_api_secret)

    def is_reddit_configured(self) -> bool:
        """
        Check if Reddit API is configured with live credentials and enabled.

        Returns:
            True if live Reddit API credentials are configured and enabled, False otherwise
        """
        return bool(self.enable_reddit and self.reddit_client_id and self.reddit_client_secret)

    def is_telegram_configured(self) -> bool:
        """
        Check if Telegram API is configured with live bot credentials and enabled.

        Returns:
            True if live Telegram bot credentials are configured and enabled, False otherwise
        """
        return bool(self.enable_telegram and self.telegram_bot_token and self.telegram_chat_id)


# Global instance (lazy-loaded after environment variables are available)
_social_settings: SocialSettings | None = None


def get_social_settings() -> SocialSettings:
    """
    Get the social settings instance (live configuration from environment variables).

    Returns:
        SocialSettings instance with live API credentials from environment variables
        - All configuration from live environment variables - no hardcoded values
        - Lazy-loaded to ensure environment variables are available
    """
    global _social_settings
    if _social_settings is None:
        _social_settings = SocialSettings()
    return _social_settings


# Backward compatibility - direct access (lazy-loaded)
# Use a class to provide lazy loading
class _LazySocialSettings:
    _instance = None

    def __getattr__(self, name):
        if self._instance is None:
            self._instance = get_social_settings()
        return getattr(self._instance, name)

    def __call__(self):
        if self._instance is None:
            self._instance = get_social_settings()
        return self._instance


social_settings = _LazySocialSettings()
