"""
Timing Constants Configuration - All Live Data, No Fallback/Hardcoded Data

This module provides centralized timing constants for live trading operations (backend port 8000).
All timing constants:
- Define intervals and delays for live backend operations (port 8000)
- Values are configuration defaults only, not fallback data
- Used for live API rate limiting, retry logic, and timing coordination
- All timing operations use live endpoints - no fallback/hardcoded timing

Live Data Sources:
- Timing constants configured for live backend operations (port 8000)
- Rate limiting for live API calls (Binance.US, backend endpoints)
- Retry logic for live API operations
- WebSocket timing for live data streams
- All timing coordinated for live operations - no mock/test timing

Endpoint References:
- Backend API: Port 8000 (timing constants for live backend operations)
- Binance.US API: Rate limiting and retry timing for live exchange API
- WebSocket: Reconnection and ping timing for live data streams
- All timing for live endpoints - no fallback/hardcoded timing

All time values are in seconds unless otherwise specified.
Configuration defaults - not fallback data.
"""

# === Rate Limiting (Live API Operations) ===
# Timing constants for rate limiting live API calls (backend port 8000, Binance.US)
# Configuration defaults - not fallback data
RATE_LIMIT_CHECK_INITIAL_BACKOFF = 0.001  # 1ms initial backoff (configuration default)
RATE_LIMIT_CHECK_MAX_BACKOFF = 0.1  # 100ms maximum backoff (configuration default)
RATE_LIMIT_BACKOFF_MULTIPLIER = 1.5  # Exponential growth factor (configuration default)
RATE_LIMIT_DEFAULT_TIMEOUT = 2.0  # Timeout for token acquisition (configuration default)

# === Trade Engine (Live Trading Operations) ===
# Timing constants for live trade engine operations (backend port 8000)
# Configuration defaults - not fallback data
TRADE_ENGINE_MIN_DECISION_INTERVAL = 1.0  # Minimum time between decisions (configuration default)
TRADE_ENGINE_MAX_DECISION_INTERVAL = 60.0  # Maximum polling timeout (configuration default)
TRADE_ENGINE_ERROR_RECOVERY_DELAY = 5.0  # Delay after error (configuration default, not fallback)

# === Signal Processing (Live Signal Generation) ===
# Timing constants for live signal processing (backend port 8000)
# Configuration defaults - not fallback data
SIGNAL_SYNC_INTERVAL = 5.0  # How often to generate new signals (configuration default)
SIGNAL_HEALTH_CHECK_INTERVAL = 60.0  # Health check frequency (configuration default)

# === API Retry Logic (Live API Operations) ===
# Timing constants for retry logic on live API calls (backend port 8000, Binance.US)
# Configuration defaults - not fallback data
API_RETRY_BASE_DELAY = 0.5  # Base delay for API retries (configuration default)
API_RETRY_MAX_DELAY = 30.0  # Maximum retry delay (configuration default)
API_RETRY_MULTIPLIER = 2.0  # Exponential backoff multiplier (configuration default)
API_RETRY_JITTER_FACTOR = 0.4  # Random jitter (±40%) (configuration default)

# === Process Management (Live Backend Operations) ===
# Timing constants for process management (backend port 8000)
# Configuration defaults - not fallback data
PROCESS_LAUNCH_DELAY = 0.1  # Delay between launching processes (configuration default)
PROCESS_HEALTH_CHECK_INTERVAL = 30.0  # Health check frequency (configuration default)
PROCESS_SHUTDOWN_GRACE_PERIOD = 10.0  # Grace period before force kill (configuration default)

# === Monitoring (Live System Monitoring) ===
# Timing constants for live system monitoring (backend port 8000)
# Configuration defaults - not fallback data
MONITORING_INTERVAL = 60.0  # General monitoring check interval (configuration default)
MONITORING_ERROR_RETRY_INTERVAL = 5.0  # Retry interval on monitoring error (configuration default)

# === Cache (Live Cache Operations) ===
# Timing constants for live cache operations (Redis on Windows Home 11, backend port 8000)
# Configuration defaults - not fallback data
CACHE_REFRESH_INTERVAL = 10.0  # How often to refresh cache (configuration default)
CACHE_CLEANUP_INTERVAL = 300.0  # Cache cleanup frequency (5 minutes, configuration default)

# === WebSocket (Live Data Streams) ===
# Timing constants for WebSocket connections (live data streams, backend port 8000)
# Configuration defaults - not fallback data
WS_RECONNECT_MIN_DELAY = 1.0  # Minimum delay before reconnect (configuration default)
WS_RECONNECT_MAX_DELAY = 60.0  # Maximum delay before reconnect (configuration default)
WS_PING_INTERVAL = 30.0  # WebSocket ping frequency (configuration default)

# === Usage Examples ===
"""
Example usage of timing constants for live operations:

    from backend.config.timing_constants import RATE_LIMIT_CHECK_INITIAL_BACKOFF

    # Use timing constants for live API rate limiting (backend port 8000)
    backoff = RATE_LIMIT_CHECK_INITIAL_BACKOFF
    while need_retry:
        await asyncio.sleep(backoff)
        backoff = min(
            backoff * RATE_LIMIT_BACKOFF_MULTIPLIER,
            RATE_LIMIT_CHECK_MAX_BACKOFF
        )

All timing constants are configuration defaults for live operations - not fallback data.
"""
