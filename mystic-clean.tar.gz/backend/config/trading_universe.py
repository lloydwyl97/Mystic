"""
Trading Universe Configuration - Single Source of Truth, All Live Data, No Fallback/Hardcoded Data

This module is the SINGLE SOURCE OF TRUTH for all Binance.US Top-10 trading symbols in the system.
All trading symbols:
- Binance.US Top-10 only - ALL 10 COINS (BTCUSDT, ETHUSDT, ADAUSDT, SOLUSDT, DOGEUSDT,
  XRPUSDT, BCHUSDT, LTCUSDT, AVAXUSDT, LINKUSDT)
- Used for live trading operations via backend (port 8000)
- No fallback/hardcoded symbol lists - this is the authoritative source
- DO NOT duplicate this list elsewhere - import from here

COIN UNIVERSE RULES (MANDATORY — NO AUTO-EXPANSION):
- The active trading universe is exactly this configured list. Never auto-add or
  auto-discover new symbols in code. Any change to the coin list must be explicit
  configuration (edit this file or config), not code logic. See backend.config.coin_universe_rules.

Live Data Sources:
- Trading symbols: All 10 Binance.US Top-10 symbols for live trading operations
- Exchange identifier: Binance.US only (live exchange for all operations)
- All symbols used for live API calls to Binance.US via backend (port 8000)
- All trading operations use these symbols - no fallback/hardcoded symbols

Endpoint References:
- Binance.US API: https://api.binance.us (live exchange API)
- Backend API: Port 8000 (for live trading operations using these symbols)
- All operations use live endpoints - no fallback/hardcoded data

IMPORTANT: This is the SINGLE SOURCE OF TRUTH for trading symbols.
All other modules MUST import from here - DO NOT duplicate this list elsewhere.
"""

from typing import Final

# Coin universe is fixed; no auto-expansion (see backend.config.coin_universe_rules)
COIN_UNIVERSE_FIXED: Final[bool] = True
# Max share of total capital per coin (%). Log warning when approached or exceeded.
MAX_COIN_CONCENTRATION_PCT: Final[float] = 30.0
CONCENTRATION_WARN_PCT: Final[float] = 25.0

# AUTHORITATIVE BINANCE.US TOP 10 - SINGLE SOURCE OF TRUTH
# All 10 Binance.US Top-10 symbols for live trading operations (backend port 8000)
# These are the live trading symbols - not fallback/hardcoded data
TRADING_SYMBOLS: Final[list[str]] = [
    "BTCUSDT",  # Bitcoin - live Binance.US trading symbol
    "ETHUSDT",  # Ethereum - live Binance.US trading symbol
    "ADAUSDT",  # Cardano - live Binance.US trading symbol
    "SOLUSDT",  # Solana - live Binance.US trading symbol
    "DOGEUSDT",  # Dogecoin - live Binance.US trading symbol
    "XRPUSDT",  # Ripple - live Binance.US trading symbol
    "BCHUSDT",  # Bitcoin Cash - live Binance.US trading symbol
    "LTCUSDT",  # Litecoin - live Binance.US trading symbol
    "AVAXUSDT",  # Avalanche - live Binance.US trading symbol
    "LINKUSDT",  # Chainlink - live Binance.US trading symbol
]

# Base symbols (without USDT suffix) - derived from live trading symbols
# All 10 Binance.US Top-10 base symbols for live operations
TOP10_COINS: Final[list[str]] = [
    "BTC",  # Bitcoin base symbol (from live trading universe)
    "ETH",  # Ethereum base symbol (from live trading universe)
    "ADA",  # Cardano base symbol (from live trading universe)
    "SOL",  # Solana base symbol (from live trading universe)
    "DOGE",  # Dogecoin base symbol (from live trading universe)
    "XRP",  # Ripple base symbol (from live trading universe)
    "BCH",  # Bitcoin Cash base symbol (from live trading universe)
    "LTC",  # Litecoin base symbol (from live trading universe)
    "AVAX",  # Avalanche base symbol (from live trading universe)
    "LINK",  # Chainlink base symbol (from live trading universe)
]

# Exchange identifier (Binance.US only - live trading exchange)
# All operations connect to Binance.US for live trading (backend port 8000)
EXCHANGE_ID: Final[str] = "binance_us"
FEATURED_EXCHANGE: Final[str] = "binance_us"


# Convenience accessors (for live trading operations)


def get_trading_symbols() -> list[str]:
    """
    Get list of live trading symbols (with USDT suffix) - Binance.US Top-10 only.

    Returns a copy of all 10 Binance.US Top-10 trading symbols for live operations.
    These symbols are used for live API calls to Binance.US via backend (port 8000).

    Returns:
        List of all 10 live Binance.US Top-10 trading symbols (with USDT suffix)
    """
    return TRADING_SYMBOLS.copy()


def get_base_symbols() -> list[str]:
    """
    Get list of live base coin symbols (without USDT suffix) - Binance.US Top-10 only.

    Returns a copy of all 10 Binance.US Top-10 base symbols for live operations.
    These symbols are used for live trading operations via backend (port 8000).

    Returns:
        List of live Binance.US base symbols (without USDT suffix)
    """
    return TOP10_COINS.copy()


def get_symbol_count() -> int:
    """
    Get count of live trading symbols - always 10 (Binance.US Top-10).

    Returns:
        Integer count of live trading symbols (10)
    """
    return len(TRADING_SYMBOLS)


def is_valid_symbol(symbol: str) -> bool:
    """
    Check if a symbol is in the live Binance.US Top-10 trading universe.

    Args:
        symbol: Symbol to check (e.g., "BTCUSDT" or "BTC")

    Returns:
        True if symbol is in live trading universe, False otherwise
    """
    return symbol in TRADING_SYMBOLS or symbol in TOP10_COINS
