# Full Pipeline Audit Report — BUY/SELL/HOLD + Paper/Live + AI/Learning/Weights

**Date:** 2026-03-05  
**Scope:** Read-only code audit. All claims cite file and function references.

---

## One-Page Summary (Single Source of Truth)

| Component | Status | Notes |
|-----------|--------|-------|
| **Active buy/sell execution** | `portfolio_engine_integration` | Sole executor. Consumes `ai_signal:*`, `ai_signal_hot:*`, `ai_decision:*`; enqueues candidates; bar processor calls `process_bar_candidates` → `execute_buy_from_signal` → `execute_buy_fifo`. |
| **Active signal generation** | `ai_signal_generator` | Writes `ai_signal:{symbol}` with ensemble (RF/LSTM/Transformer/Chart/FearGreed). Uses `signal_action.normalize_signal_action`. |
| **Hot-signal bridge** | `portfolio_engine_integration._publish_hot_market_signals` | Publishes `ai_signal_hot:*` from `risk_adjusted_signals()` when `HOT_SIGNAL_BRIDGE_ENABLED=true`. Score threshold: `HOT_SIGNAL_MIN_SCORE` (default 65). |
| **Mode gating** | `execution_mode_service` | `EXECUTION_MODE` (paper/live) + `LIVE_TRADES_ALLOWED` (true/false). `is_live_execution_allowed_sync()` = both live. Real orders only when true. |
| **Live order placement** | `portfolio_engine.execute_buy_fifo` / `execute_sell_fifo` | Gate: `_live_execution_enabled and _live_service and is_live_execution_allowed_sync()`. Routes to `LiveTradingService.place_order`. |
| **Paper order placement** | Paper adapter: `create_buy_order` (buys), `place_order` (sells) | Same funnel; paper path when live gate false. |
| **Exits** | `portfolio_engine.monitor_all_positions` → `_check_exit_conditions` | Single authority. AI SELL via `set_ai_sell_intent`; monitor evaluates `ai_exit_recommended` with min-hold and net-profit gates. |
| **Legacy (not started in this deployment)** | `exit_executor`, `ai_live_engine`, `autosell_service` | In current deployment topology: ExitExecutor not wired in `app_factory` (line 330); ai_live_engine disabled. May differ in other topologies. |
| **Confidence normalization** | `ConfidenceNormalizer` | `backend/services/confidence_normalizer.py`. Used in ai_signal_generator, integration, paper endpoints. |

---

## 1. BUY Flow — Call Graph and Gating

### Stage 1: AI Produces Signal (side/confidence/decision_id)

| Item | Reference |
|------|-----------|
| **Function** | `RealTimeAISignalGenerator._signal_generation_loop` |
| **File** | `backend/services/ai_signal_generator.py` |
| **Redis keys** | `ai_signal:{symbol}` (e.g. `ai_signal:BTCUSDT`) |
| **Canonical action** | `signal_action.normalize_signal_action(prediction)` → `buy`/`sell`/`hold` |
| **Decision ID** | `f"{symbol}_{int(time.time() * 1000)}"` (line 696, 914) |
| **Gates** | `confidence < self.confidence_threshold` → override to HOLD |

### Stage 2: Hot-Signal Bridge (optional)

| Item | Reference |
|------|-----------|
| **Function** | `PortfolioEngineIntegration._publish_hot_market_signals` |
| **File** | `backend/services/portfolio_engine_integration.py` (lines 939–1015) |
| **Source** | `risk_adjusted_signals()` from `backend/modules/ai/ai_signals.py` |
| **Redis keys** | `ai_signal_hot:{symbol}` |
| **Filter** | `action == "BUY"` and `score >= hot_signal_min_score` (default 65) |
| **Env** | `HOT_SIGNAL_BRIDGE_ENABLED`, `HOT_SIGNAL_MIN_SCORE` |

### Stage 3: Integration Consumes Signal and Enqueues Candidate

| Item | Reference |
|------|-----------|
| **Loop** | `_signal_consumption_loop` |
| **File** | `backend/services/portfolio_engine_integration.py` (line 521) |
| **Key priority** | `ai_signal_hot:*` > `ai_signal:*` > `ai_decision:*` (one key per symbol) |
| **Process** | `_process_ai_signal` → `extract_canonical_action` → BUY path: `engine.add_buy_candidate(...)` |
| **Redis** | Reads `ai_signal_hot:*`, `ai_signal:*`, `ai_decision:*`; uses `claimed:{redis_key}` for locking (e.g. `claimed:ai_signal:BTCUSDT`) — scoped to Redis signal key, not `decision_id` |

### Stage 4: Bar Processor Selects and Calls Buy Execution

| Item | Reference |
|------|-----------|
| **Loop** | `_bar_processor_loop` |
| **File** | `backend/services/portfolio_engine_integration.py` (line 1064) |
| **Calls** | `engine.process_bar_candidates(current_bar)` |
| **Engine** | `portfolio_engine.process_bar_candidates` (line 5733) → ranks by `BuyCandidate.composite_score` → `execute_buy_from_signal` → `execute_buy_fifo` |

### Stage 5: Order Placement (Paper vs Live)

| Item | Reference |
|------|-----------|
| **Function** | `PortfolioEngine.execute_buy_fifo` |
| **File** | `backend/services/portfolio_engine.py` (line 3815) |
| **Mode gate** | `buy_mode = "live" if is_live_execution_allowed_sync() else "paper"` (line 4029) |
| **Live order gate** | `if self._live_execution_enabled and self._live_service and is_live_execution_allowed_sync()` (line 4085) |
| **Live path** | `self._live_service.place_order(...)` → `LiveTradingService.place_order` (`backend/services/live_trading_service.py` line 560) |
| **Paper path** | `self._paper_service.create_buy_order(...)` → `PaperTradingService.create_buy_order` (`backend/services/paper_trading_service.py` line 553) |
| **Ledger mode** | `paper_trades.mode` = `buy_mode` (line 4049) |

### Stage 6: Cooldowns and Positions

| Item | Reference |
|------|-----------|
| **BUY cooldown** | `BUY_COOLDOWN_SEC` applied (line 4076) |
| **Positions** | `open_positions` updated; paper service sync in `execute_buy_fifo` |
| **Cooldown recording** | `record_sell_cooldown` after sells; `POST_SELL_COOLDOWN_BARS`, `GLOBAL_SELL_COOLDOWN_BARS` (lines 7645, 7648) |

---

## 2. HOLD Behavior

| Claim | Reference |
|-------|-----------|
| HOLD signals are skipped by integration | `_process_ai_signal`: when `extract_canonical_action` returns `hold` → `GateReason.SKIP`, no `add_buy_candidate`, no `set_ai_sell_intent` (line 496–502). |
| No hidden "HOLD means exit intent" | `set_ai_sell_intent` only called when `side == "sell"` (line 484, 825). |
| Caveat | HOLD in `ai_signal:*` for a symbol is ignored by integration. Other producers (ai_decision:*, ai_signal_hot:*) can still publish BUY/SELL for that symbol; highest-priority key wins per symbol. |

**File:** `backend/services/portfolio_engine_integration.py` lines 479–502.

---

## 3. SELL Flow — Call Graph and Gating

### Exit Authorities

| Authority | Status | Reference |
|-----------|--------|-----------|
| `portfolio_engine.monitor_all_positions` → `_check_exit_conditions` | **ACTIVE** | `portfolio_engine.py` line 5190 |
| `exit_executor` | **LEGACY / NOT STARTED** | `app_factory.py` line 330; `exit_executor.py` docstring |
| `automated_paper_selling_service` | **LEGACY** | Replaced by portfolio_engine exits |

### AI SELL Intent

| Item | Reference |
|------|-----------|
| **Set intent** | `engine.set_ai_sell_intent(ccxt_symbol, confidence)` in `_process_ai_signal` (line 484) and `_signal_consumption_loop` SELL branch (line 825) |
| **File** | `portfolio_engine_integration.py` |
| **Engine** | `portfolio_engine.set_ai_sell_intent` (line 3704) sets `pos.ai_exit_recommended = True` |
| **Evaluate** | `_check_exit_conditions` checks `position.ai_exit_recommended` (line 5422, 5547) |
| **Gate** | Min-hold bars, `ESTIMATED_ROUNDTRIP_COST`, `MIN_NET_PROFIT_TO_SELL*` |

### Exit Priority (in `_check_exit_conditions`, SCALPER mode)

Actual code order (`portfolio_engine.py` lines 5223–5413):

1. **Entry grace** — Block TP/TRAIL/TIME within `min_hold_bars`; allow STOP_LOSS if `ENTRY_GRACE_ALLOW_STOP_LOSS_ONLY`
2. **TAKE_PROFIT** — `pnl_pct >= coin_tp`, net gate `MIN_NET_PROFIT_TO_SELL` (line 5300)
3. **STOP_LOSS** — `pnl_pct < -coin_sl`, net gate `MIN_NET_LOSS_TO_CUT` (line 5335)
4. **TRAILING_STOP** — `MIN_NET_PROFIT_TO_SELL_TRAIL` (line 5365)
5. **SIGNAL_EXIT (AI)** — When `ai_exit_recommended`; same net gate as TIME (`MIN_NET_PROFIT_TO_SELL_TIME`, net ≥ 0). Runs **after TRAIL, before TIME** (line 5421)
6. **TIME_EXIT** — `hold_seconds >= max_hold_seconds`, net gate `MIN_NET_PROFIT_TO_SELL_TIME` (line 5455)

Design: AI cannot cut a losing trade early; only SL/trail can. AI exit is discretionary (risk-off, take me out if not losing).

### SELL Execution Path

| Item | Reference |
|------|-----------|
| **Function** | `execute_sell_fifo` |
| **File** | `backend/services/portfolio_engine.py` (line 4253) |
| **Mode** | `sell_mode = "live" if is_live_execution_allowed_sync() else "paper"` (line 4408) |
| **Live gate** | `if self._live_execution_enabled and self._live_service and is_live_execution_allowed_sync()` (line 4503) |
| **Dust logic** | Quantize, dust check; if dust → writeoff without `place_order` |
| **Ledger** | `paper_trades` row with `mode`, `exit_type`, `sell_status` |

---

## 4. Paper vs Live Parity Truth Table

| execution_mode | live_trades_allowed | effective_mode | real_orders_enabled | Does router place Binance orders? |
|----------------|---------------------|----------------|---------------------|-----------------------------------|
| paper | false | PAPER | false | No |
| live | false | PAPER (live-disabled) | false | No — decision logic identical; only adapter execution blocked |
| paper | true | PAPER | false | No |
| live | true | LIVE | true | Yes |

**Where each field is computed:**

| Field | File | Function/Line |
|-------|------|---------------|
| `execution_mode` | `execution_mode_service.py` | `get_execution_mode_sync` (48–55), Redis key `execution_mode` |
| `live_trades_allowed` | `execution_mode_service.py` | `get_live_trades_allowed_sync` (61–70), Redis key `live_trades_allowed` |
| `effective_mode` | `execution_mode_service.py` | `get_execution_status` line 146: `"LIVE" if effective_live else "PAPER"` |
| `real_orders_enabled` | `execution_mode_service.py` | `get_execution_status` line 149: `effective_live = mode == "live" and allowed` |
| **Hard gate (BUY)** | `portfolio_engine.py` | Line 4085: `is_live_execution_allowed_sync()` |
| **Hard gate (SELL)** | `portfolio_engine.py` | Line 4503: same |
| **Ledger mode (BUY)** | `portfolio_engine.py` | Line 4029: `buy_mode = "live" if is_live_execution_allowed_sync() else "paper"` |
| **Ledger mode (SELL)** | `portfolio_engine.py` | Line 4408: `sell_mode = "live" if ...` |

**Same funnel:** Both paper and live use `execute_buy_fifo` / `execute_sell_fifo`. Decision logic is identical; only the adapter differs. Mode determines which adapter is invoked: paper (`create_buy_order` for buys, `place_order` for sells) vs live (`place_order` for both). When live-disabled (mode=live, allowed=false), execution uses paper adapter — no behavioral change beyond blocked Binance orders.

---

## 5. Weights Registry

### A) Live-Decision Weights

| Weight | Value(s) | File:Symbol/Function | Live Path? | Influences |
|--------|----------|----------------------|------------|------------|
| **Ensemble (RF)** | 0.30 | `ai_signal_generator.py` line 161: `"random_forest": 0.30` | Yes | Signal action |
| **Ensemble (LSTM)** | 0.25 | `ai_signal_generator.py` line 162: `"lstm": 0.25` | Yes | Signal action |
| **Ensemble (Transformer)** | 0.20 | `ai_signal_generator.py` line 163: `"transformer": 0.20` | Yes | Signal action |
| **Ensemble (Chart)** | 0.15 | `ai_signal_generator.py` line 164: `"chart_pattern": 0.15` | Yes | Signal action |
| **Ensemble (FearGreed)** | 0.10 | `ai_signal_generator.py` line 165: `"fear_greed": 0.10` | Yes | Signal action |
| **Volatility boost** | Per-symbol | `ai_signal_generator.py` 665–681: `VOLATILITY_CONFIG` e.g. DOGE (0.12, 0.55), default (0.30, 0.50) | Yes | HOLD→BUY override |
| **BuyCandidate.composite_score** | confidence 0.35, trend 0.20, coin_edge 0.20, chop 0.10, vol 0.10, spread 0.05 | `portfolio_engine.py` lines 447–453 | Yes | Ranking |
| **Coin priority** | BTC 0.6, ETH 0.7, LTC/BCH 0.85, SOL 1.0, XRP/ADA/LINK 1.1, DOGE 1.2, AVAX 1.15 | `portfolio_engine.py` lines 470–480 | Yes | Ranking multiplier |
| **hot_signal_min_score** | 65 (env: `HOT_SIGNAL_MIN_SCORE`) | `portfolio_engine_integration.py` line 144 | Yes | Hot bridge filter |
| **ESTIMATED_ROUNDTRIP_COST** | 0.0035 (0.35%) | `portfolio_engine.py` line 151 | Yes | Exit net gates |
| **MIN_NET_PROFIT_TO_SELL** | 0.0025 (TP) | `portfolio_engine.py` line 152 | Yes | TP exit gate |
| **MIN_NET_PROFIT_TO_SELL_TRAIL** | 0.0015 (trail) | `portfolio_engine.py` line 153 | Yes | Trail exit gate |
| **MIN_NET_PROFIT_TO_SELL_TIME** | 0.0 (time exit) | `portfolio_engine.py` line 154 | Yes | Time exit gate |

### B) Training-Only Weights

| Weight | Value(s) | File | Influences |
|--------|----------|------|------------|
| **Health score factors** | [0.3, 0.25, 0.2, 0.15, 0.1] | `realtime_model_trainer.py` line 522 | Model health, retrain triggers |
| **ModelConfig.weight** | 1.0 default | `advanced_model_ensemble.py` line 59 | Ensemble training |
| **advanced_model_ensemble** | dynamic_weighting, meta_learning, etc. | `advanced_model_ensemble.py` | Training only (LEGACY: "Not used" per LEGACY_CODE_PROTECTION.md) |
| **ensemble_predictor** | base 0.35, deep 0.30, onchain 0.10, ob 0.10, social 0.15 | `ensemble_predictor.py` lines 255–260 | Legacy; ai_live_engine disabled |

### C) Other Relevant Constants

| Constant | Value | File | Influences |
|----------|-------|------|------------|
| **ENTRY_GRACE_BARS** | 2 | `portfolio_engine.py` line 159 | Min-hold before TP/TRAIL/TIME |
| **MIN_HOLD_BARS** | 2 | `portfolio_engine.py` line 160 | Min hold |
| **POST_SELL_COOLDOWN_BARS** | 20 | `portfolio_engine.py` line 251 | Same-symbol cooldown |
| **GLOBAL_SELL_COOLDOWN_BARS** | 5 | `portfolio_engine.py` line 252 | Global buy block |
| **ConfidenceNormalizer.MIN_CONFIDENCE** | 0.50 | `confidence_normalizer.py` line 32 | Clamp |
| **ConfidenceNormalizer.MAX_CONFIDENCE** | 0.95 | `confidence_normalizer.py` line 33 | Clamp |

---

## 6. Learning Pipeline

### Data Stored

| Location | Content |
|----------|---------|
| `pipeline_decisions` | `decision_id`, `symbol`, `model_class`, `model_probs_json`, `gate_result`, `gate_reason`, `execution_result`, `execution_reason` |
| `paper_trades` | trade rows with `mode`, `decision_id`, `exit_type` |
| `portfolio_engine_audit` | Immutable audit trail |
| Redis `ai_signal:*`, `ai_decision:*` | Signal payloads with TTL |

### Retraining Triggers

| Component | File | Trigger |
|-----------|------|---------|
| **RealtimeModelTrainer** | `realtime_model_trainer.py` | Health score < 0.5 → `_trigger_retraining` (line 578) |
| **AdvancedModelEnsemble** | `advanced_model_ensemble.py` | Training tasks; `model_ensemble_service` used by realtime trainer |
| **ai_multimodal_learning** | `ai_multimodal_learning.py` | SentimentLearner; initialized via `startup_initializer` |

### Models in Live vs Training

| Model | Live prediction | Training |
|-------|-----------------|----------|
| **ai_signal_generator** (RF, LSTM, Transformer, Chart, FearGreed) | Yes | `realtime_model_trainer` + `advanced_model_ensemble` |
| **risk_adjusted_signals** | Yes (hot bridge) | No |
| **ai_live_engine** | No (disabled) | — |
| **ensemble_predictor** | Legacy path only | — |

### Confidence Normalization Coverage

| Location | Uses ConfidenceNormalizer |
|----------|---------------------------|
| `ai_signal_generator` | Yes (line 711) |
| `portfolio_engine_integration` (hot bridge) | Yes (line 982) |
| `paper_trading_endpoints` | Via signal processing |
| `realtime_model_trainer` | Yes (line 541) |

---

## Appendix A: Redis Key Schema (Live Control Plane)

| Pattern | Writer | Consumer | TTL/Notes |
|---------|--------|----------|-----------|
| `ai_signal:{symbol}` | ai_signal_generator | portfolio_engine_integration | Writer lock |
| `ai_signal_hot:{symbol}` | portfolio_engine_integration | _signal_consumption_loop | 25s |
| `ai_decision:{symbol}` | ai_autobuy_orchestrator (legacy), profit_target_service | portfolio_engine_integration | Various |
| `execution_mode` | execution_mode_service | execution_mode_service | — |
| `live_trades_allowed` | execution_mode_service | execution_mode_service | — |
| `market_data:last_update` | Market data service | _signal_consumption_loop (freshness gate) | — |
| `claimed:{redis_key}` | Claim lock (e.g. `claimed:ai_signal:BTCUSDT`) | _signal_consumption_loop | 30s TTL; scoped to Redis signal key, not decision_id |
| `exec_lock:*` | portfolio_engine | — | Single execution authority |

---

## Appendix B: DB Tables/Columns Touched by Buy/Sell

| Table | Columns (key) | When |
|-------|---------------|------|
| `paper_trades` | trade_id, mode, symbol, side, quantity, price, entry_price, pnl, pnl_pct, exit_type, decision_id, explainability_json | BUY/SELL inserts |
| `portfolio_engine_ledger` | principal, cash_balance, positions_value, realized_pnl, total_equity | After trades |
| `portfolio_engine_positions` | symbol, quantity, entry_price | Position updates |
| `portfolio_engine_audit` | Append-only audit | After trades |
| `pipeline_decisions` | decision_id, stage, gate_result, execution_result | Pipeline tracking |
| `dust_writeoffs` | symbol, quantity, reason | Dust writeoffs |

---

## Appendix C: Endpoint List for Verification

| Endpoint | Purpose |
|----------|---------|
| `GET /api/portfolio-engine/execution-mode` | Get EXECUTION_MODE + LIVE_TRADES_ALLOWED |
| `POST /api/portfolio-engine/execution-mode` | Set mode and live_trades_allowed |
| `GET /api/portfolio-engine/operator-status` | Operator dashboard status |
| `GET /autobuy/signals` | Hot-signal source (used by hot bridge fallback) |

---

*Report generated from codebase audit. No code changes.*
