"""
Admin Endpoints - Authenticated control endpoints for system operators

These endpoints require ADMIN_TOKEN authentication.
"""

import logging
import os
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from backend.middleware.security import AdminAuthMiddleware

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/admin", tags=["Admin"])


class KillSwitchRequest(BaseModel):
    """Request model for kill switch control"""

    enabled: bool
    reason: str | None = None


class KillSwitchResponse(BaseModel):
    """Response model for kill switch status"""

    success: bool
    enabled: bool
    reason: str | None
    timestamp: str


def require_admin(request: Request) -> None:
    """
    Dependency to require admin authentication.

    Raises:
        HTTPException: 401 if authentication fails
    """
    if not AdminAuthMiddleware.verify_admin_token(request):
        raise HTTPException(status_code=401, detail="Unauthorized - valid ADMIN_TOKEN required", headers={"WWW-Authenticate": "Bearer"})


@router.post("/kill-switch", response_model=KillSwitchResponse)
async def set_kill_switch(request: Request, kill_switch_request: KillSwitchRequest) -> KillSwitchResponse:
    """
    Set global kill switch to pause/resume all trading.

    **Authentication Required**: ADMIN_TOKEN in Authorization header

    Request Body:
    - `enabled`: true to enable kill switch (pause trading), false to disable
    - `reason`: Optional reason for enabling kill switch

    Examples:
    ```bash
    # Enable kill switch (pause all trading)
    curl -X POST http://localhost:8000/api/admin/kill-switch \
      -H "Authorization: Bearer YOUR_ADMIN_TOKEN" \
      -H "Content-Type: application/json" \
      -d '{"enabled": true, "reason": "Emergency stop - investigating issue"}'

    # Disable kill switch (resume trading)
    curl -X POST http://localhost:8000/api/admin/kill-switch \
      -H "Authorization: Bearer YOUR_ADMIN_TOKEN" \
      -H "Content-Type: application/json" \
      -d '{"enabled": false}'
    ```
    """
    # Require admin authentication
    require_admin(request)

    try:
        import redis.asyncio as redis

        redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
        client = redis.from_url(redis_url, decode_responses=True)

        # Set kill switch in Redis
        if kill_switch_request.enabled:
            await client.set("kill_switch", "1")

            # Store reason if provided
            if kill_switch_request.reason:
                await client.set("kill_switch:reason", kill_switch_request.reason, ex=86400)  # 24h TTL

            logger.critical(f"🔴 KILL SWITCH ENABLED by admin: {kill_switch_request.reason or 'No reason provided'}")
        else:
            await client.set("kill_switch", "0")
            await client.delete("kill_switch:reason")
            logger.info("🟢 KILL SWITCH DISABLED by admin - trading resumed")

        await client.aclose()

        # --- Route through portfolio engine so the enforcement layer is notified ---
        # BLOCKER-FIX: admin kill_switch Redis key was written but never read by portfolio
        # engine. Now we route the signal to the authoritative engine.set_kill_switch().
        try:
            from backend.services.portfolio_engine import get_portfolio_engine

            engine = get_portfolio_engine()
            if engine is not None:
                pe_mode = "PAUSE_ALL" if kill_switch_request.enabled else "RESUME"
                await engine.set_kill_switch(pe_mode, kill_switch_request.reason or "admin_endpoint")
        except Exception as pe_err:
            logger.warning("admin kill_switch: portfolio engine routing failed: %s", pe_err)

        return KillSwitchResponse(success=True, enabled=kill_switch_request.enabled, reason=kill_switch_request.reason, timestamp=datetime.now(timezone.utc).isoformat())

    except Exception as e:
        logger.exception(f"Failed to set kill switch: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/kill-switch", response_model=KillSwitchResponse)
async def get_kill_switch(request: Request) -> KillSwitchResponse:
    """
    Get current kill switch status.

    **Authentication Required**: ADMIN_TOKEN in Authorization header

    Example:
    ```bash
    curl -X GET http://localhost:8000/api/admin/kill-switch \
      -H "Authorization: Bearer YOUR_ADMIN_TOKEN"
    ```
    """
    # Require admin authentication
    require_admin(request)

    try:
        import redis.asyncio as redis

        redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
        client = redis.from_url(redis_url, decode_responses=True)

        # Get kill switch status
        kill_switch_value = await client.get("kill_switch")
        kill_switch_reason = await client.get("kill_switch:reason")

        await client.aclose()

        enabled = kill_switch_value == "1"

        return KillSwitchResponse(success=True, enabled=enabled, reason=kill_switch_reason, timestamp=datetime.now(timezone.utc).isoformat())

    except Exception as e:
        logger.exception(f"Failed to get kill switch status: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/symbol-kill-switch")
async def set_symbol_kill_switch(request: Request, symbol: str, enabled: bool, reason: str | None = None) -> dict[str, Any]:
    """
    Set per-symbol kill switch.

    **Authentication Required**: ADMIN_TOKEN in Authorization header

    Args:
        symbol: Trading symbol (e.g., "BTC/USDT" or "BTCUSDT")
        enabled: true to pause symbol, false to resume
        reason: Optional reason

    Example:
    ```bash
    curl -X POST "http://localhost:8000/api/admin/symbol-kill-switch?symbol=BTCUSDT&enabled=true&reason=High+volatility" \
      -H "Authorization: Bearer YOUR_ADMIN_TOKEN"
    ```
    """
    # Require admin authentication
    require_admin(request)

    try:
        import redis.asyncio as redis

        # Normalize symbol
        symbol_normalized = symbol.replace("/", "")

        redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
        client = redis.from_url(redis_url, decode_responses=True)

        # Set symbol kill switch
        key = f"kill:{symbol_normalized}"

        if enabled:
            await client.set(key, "1")
            if reason:
                await client.set(f"{key}:reason", reason, ex=86400)
            logger.warning(f"🔴 Symbol kill switch enabled for {symbol_normalized}: {reason or 'No reason'}")
        else:
            await client.set(key, "0")
            await client.delete(f"{key}:reason")
            logger.info(f"🟢 Symbol kill switch disabled for {symbol_normalized}")

        await client.aclose()

        return {"success": True, "symbol": symbol_normalized, "enabled": enabled, "reason": reason, "timestamp": datetime.now(timezone.utc).isoformat()}

    except Exception as e:
        logger.exception(f"Failed to set symbol kill switch: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/health")
async def admin_health_check(request: Request) -> dict[str, Any]:
    """
    Admin health check endpoint.

    **Authentication Required**: ADMIN_TOKEN in Authorization header

    Returns comprehensive system health status.
    """
    # Require admin authentication
    require_admin(request)

    try:
        from backend.utils.health_checks import run_all_health_checks

        health_status = await run_all_health_checks()

        return {"success": True, "health": health_status, "timestamp": datetime.now(timezone.utc).isoformat()}

    except Exception as e:
        logger.exception(f"Failed to run health checks: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e
