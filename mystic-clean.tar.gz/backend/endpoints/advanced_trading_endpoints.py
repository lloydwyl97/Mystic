#!/usr/bin/env python3
"""
Advanced Trading Endpoints - All Live Data, No Fallback/Hardcoded Data

This module provides API endpoints for advanced trading operations (backend port 8000).
All endpoints:
- Serve live API requests on backend (port 8000)
- Handle live order management (bracket orders, trailing stops, iceberg orders)
- Perform live portfolio optimization and rebalancing
- Execute backtests on live market data
- No fallback/hardcoded data - all endpoints use live data

Live Data Sources:
- Order management: Live orders on Binance.US via backend services
- Portfolio operations: Live portfolio data from backend (port 8000)
- Backtesting: Uses live market data from Binance.US for historical analysis
- All endpoint responses from live operations - no mock/test data

Endpoint References:
- Backend API: Port 8000 (all endpoints serve live requests)
- Binance.US API: Live exchange API for order execution and market data
- All endpoints use live connections - no fallback/hardcoded data
"""

import inspect
import logging
from datetime import datetime
from decimal import Decimal
from typing import Any

from fastapi import APIRouter, BackgroundTasks, HTTPException
from pydantic import BaseModel, Field

from backend.services.advanced_order_manager import (
    cancel_order,
    create_bracket_order,
    create_iceberg_order,
    create_trailing_stop_order,
    get_order_status,
)

# Import smart order routing for TWAP/VWAP execution
try:
    from backend.services.smart_order_routing import smart_order_routing

    SMART_ROUTING_AVAILABLE = True
except (ImportError, ModuleNotFoundError, AttributeError):
    SMART_ROUTING_AVAILABLE = False
    smart_order_routing = None

# Import advanced trading service for strategy orchestration
try:
    from backend.services.advanced_trading import AdvancedTradingService

    ADVANCED_TRADING_AVAILABLE = True
except (ImportError, ModuleNotFoundError, AttributeError):
    ADVANCED_TRADING_AVAILABLE = False
    AdvancedTradingService = None

from backend.services.enhanced_backtesting_engine import (
    BacktestConfig,
    backtesting_service,
    get_backtest_result,
    run_backtest,
    run_monte_carlo_simulation,
    run_walk_forward_analysis,
)
from backend.services.portfolio_optimizer import (
    create_portfolio,
    get_portfolio,
    get_portfolio_performance,
    optimize_portfolio,
    rebalance_portfolio,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/advanced", tags=["Advanced Trading"])


# Pydantic models for request/response (live trading operations - backend port 8000)


class BracketOrderRequest(BaseModel):
    """Request model for bracket order creation (live trading operations)."""

    symbol: str = Field(..., description="Trading symbol (from live Binance.US Top-10)")
    side: str = Field(..., description="Order side: BUY or SELL")
    quantity: float = Field(..., description="Order quantity")
    entry_price: float | None = Field(None, description="Entry price (optional, uses live market price if None)")
    profit_target: float | None = Field(None, description="Profit target price")
    stop_loss_percentage: float | None = Field(None, description="Stop loss percentage")
    stop_loss_amount: float | None = Field(None, description="Stop loss amount")
    user_id: str | None = Field(None, description="User ID")


class TrailingStopRequest(BaseModel):
    """Request model for trailing stop order creation (live trading operations)."""

    symbol: str = Field(..., description="Trading symbol (from live Binance.US Top-10)")
    side: str = Field(..., description="Order side: BUY or SELL")
    quantity: float = Field(..., description="Order quantity")
    activation_price: float | None = Field(None, description="Activation price")
    trail_percentage: float | None = Field(None, description="Trail percentage")
    trail_amount: float | None = Field(None, description="Trail amount")
    user_id: str | None = Field(None, description="User ID")


class IcebergOrderRequest(BaseModel):
    """Request model for iceberg order creation (live trading operations)."""

    symbol: str = Field(..., description="Trading symbol (from live Binance.US Top-10)")
    side: str = Field(..., description="Order side: BUY or SELL")
    total_quantity: float = Field(..., description="Total order quantity")
    chunk_size: float = Field(..., description="Size of each chunk")
    chunk_delay: float = Field(1.0, description="Delay between chunks in seconds")
    price: float | None = Field(None, description="Order price (optional, uses live market price if None)")
    user_id: str | None = Field(None, description="User ID")


class PortfolioRequest(BaseModel):
    """Request model for portfolio creation (live portfolio operations)."""

    portfolio_id: str = Field(..., description="Portfolio ID")
    name: str = Field(..., description="Portfolio name")
    assets: dict[str, float] = Field(..., description="Asset symbol -> weight mapping (from live Binance.US Top-10)")
    total_value: float = Field(..., description="Total portfolio value")
    user_id: str | None = Field(None, description="User ID")


class OptimizationRequest(BaseModel):
    """Request model for portfolio optimization (live portfolio operations)."""

    portfolio_id: str = Field(..., description="Portfolio ID")
    strategy: str = Field("mpt", description="Optimization strategy: mpt, risk_parity, min_variance")
    target_return: float | None = Field(None, description="Target return for MPT")
    target_volatility: float | None = Field(None, description="Target volatility")
    max_weight: float = Field(0.3, description="Maximum weight per asset")


class RebalanceRequest(BaseModel):
    """Request model for portfolio rebalancing (live portfolio operations)."""

    portfolio_id: str = Field(..., description="Portfolio ID")
    target_weights: dict[str, float] = Field(..., description="Target asset weights (from live Binance.US Top-10)")
    transaction_cost: float = Field(0.001, description="Transaction cost per trade")


class BacktestRequest(BaseModel):
    """Request model for backtesting (uses live market data)."""

    strategy_name: str = Field(..., description="Strategy name")
    symbols: list[str] = Field(..., description="List of symbols to trade (from live Binance.US Top-10)")
    start_date: str = Field(..., description="Start date (ISO format)")
    end_date: str = Field(..., description="End date (ISO format)")
    initial_capital: float = Field(10000.0, description="Initial capital")
    commission_per_trade: float = Field(0.001, description="Commission per trade")
    slippage: float = Field(0.0005, description="Slippage")


class WalkForwardRequest(BaseModel):
    """Request model for walk-forward analysis (uses live market data)."""

    strategy_name: str = Field(..., description="Strategy name")
    symbols: list[str] = Field(..., description="List of symbols (from live Binance.US Top-10)")
    start_date: str = Field(..., description="Start date (ISO format)")
    end_date: str = Field(..., description="End date (ISO format)")
    training_window: int = Field(252, description="Training window in days")
    testing_window: int = Field(21, description="Testing window in days")
    step_size: int = Field(21, description="Step size in days")


class MonteCarloRequest(BaseModel):
    """Request model for Monte Carlo simulation (uses live market data)."""

    strategy_name: str = Field(..., description="Strategy name")
    symbols: list[str] = Field(..., description="List of symbols (from live Binance.US Top-10)")
    start_date: str = Field(..., description="Start date (ISO format)")
    end_date: str = Field(..., description="End date (ISO format)")
    num_simulations: int = Field(1000, description="Number of simulations")
    confidence_level: float = Field(0.95, description="Confidence level")


async def _maybe_await(obj):
    if inspect.isawaitable(obj):
        return await obj
    return obj


# Advanced Order Management Endpoints (Live Trading Operations - Backend Port 8000)


@router.post("/orders/bracket", response_model=dict[str, Any])
async def create_bracket_order_endpoint(request: BracketOrderRequest) -> dict[str, Any]:
    """
    Create a bracket order with entry, profit target, and stop loss (live trading operations).

    Creates a live bracket order on Binance.US via backend services (port 8000).
    All order data is from live market operations - no fallback/hardcoded data.
    """
    try:
        order_id = await create_bracket_order(
            symbol=request.symbol,
            side=request.side,
            quantity=Decimal(str(request.quantity)),
            entry_price=Decimal(str(request.entry_price)) if request.entry_price is not None else None,
            profit_target=Decimal(str(request.profit_target)) if request.profit_target is not None else None,
            stop_loss_percentage=request.stop_loss_percentage,
            stop_loss_amount=request.stop_loss_amount,
            user_id=request.user_id,
        )
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Create bracket order failed (live trading operation)")
        error_message = f"Failed to create bracket order: {e!s}"
        raise HTTPException(status_code=500, detail=error_message) from e
    else:
        return {
            "success": True,
            "order_id": order_id,
            "message": "Bracket order created successfully",
        }


@router.post("/orders/trailing-stop", response_model=dict[str, Any])
async def create_trailing_stop_endpoint(request: TrailingStopRequest) -> dict[str, Any]:
    """
    Create a trailing stop order (live trading operations).

    Creates a live trailing stop order on Binance.US via backend services (port 8000).
    All order data is from live market operations - no fallback/hardcoded data.
    """
    try:
        order_id = await create_trailing_stop_order(
            symbol=request.symbol,
            side=request.side,
            quantity=Decimal(str(request.quantity)),
            activation_price=Decimal(str(request.activation_price)) if request.activation_price is not None else None,
            trail_percentage=request.trail_percentage,
            trail_amount=request.trail_amount,
            user_id=request.user_id,
        )
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Create trailing stop order failed (live trading operation)")
        error_message = f"Failed to create trailing stop order: {e!s}"
        raise HTTPException(status_code=500, detail=error_message) from e
    else:
        return {
            "success": True,
            "order_id": order_id,
            "message": "Trailing stop order created successfully",
        }


@router.post("/orders/iceberg", response_model=dict[str, Any])
async def create_iceberg_order_endpoint(request: IcebergOrderRequest) -> dict[str, Any]:
    """
    Create an iceberg order (live trading operations).

    Creates a live iceberg order on Binance.US via backend services (port 8000).
    All order data is from live market operations - no fallback/hardcoded data.
    """
    try:
        await create_iceberg_order(
            symbol=request.symbol,
            side=request.side,
            total_quantity=Decimal(str(request.total_quantity)),
            chunk_size=Decimal(str(request.chunk_size)),
            chunk_delay=request.chunk_delay,
            price=Decimal(str(request.price)) if request.price is not None else None,
            user_id=request.user_id,
        )
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Create iceberg order failed (live trading operation)")
        error_message = f"Failed to create iceberg order: {e!s}"
        raise HTTPException(status_code=500, detail=error_message) from e


@router.get("/orders/{order_id}", response_model=dict[str, Any])
async def get_order_status_endpoint(order_id: str) -> dict[str, Any]:
    """
    Get order status (live trading operations).

    Retrieves live order status from Binance.US via backend services (port 8000).
    All order data is from live operations - no fallback/hardcoded data.
    """
    try:
        status = get_order_status(order_id)
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Get order status failed (live trading operation)")
        error_message = f"Failed to get order status: {e!s}"
        raise HTTPException(status_code=500, detail=error_message) from e

    # Validate order status outside try to avoid TRY301
    if not status:
        raise HTTPException(status_code=404, detail="Order not found")

    return {
        "success": True,
        "order": status,
        "message": "Order status retrieved successfully",
    }


@router.delete("/orders/{order_id}", response_model=dict[str, Any])
async def cancel_order_endpoint(order_id: str) -> dict[str, Any]:
    """
    Cancel an order (live trading operations).

    Cancels a live order on Binance.US via backend services (port 8000).
    All order operations use live data - no fallback/hardcoded data.
    """
    try:
        result = cancel_order(order_id)
        cancelled = await _maybe_await(result)
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Cancel order failed (live trading operation)")
        error_message = f"Failed to cancel order: {e!s}"
        raise HTTPException(status_code=500, detail=error_message) from e

    # Validate cancellation result outside try to avoid TRY301
    if not cancelled:
        raise HTTPException(status_code=404, detail="Order not found or could not be cancelled")

    return {
        "success": True,
        "order_id": order_id,
        "message": "Order cancelled successfully",
    }


@router.post("/portfolio", response_model=dict[str, Any])
async def create_portfolio_endpoint(request: PortfolioRequest) -> dict[str, Any]:
    """
    Create a new portfolio (live portfolio operations).

    Creates a portfolio with live asset data from Binance.US Top-10 via backend (port 8000).
    All portfolio data is from live operations - no fallback/hardcoded data.
    """
    try:
        result = create_portfolio(
            portfolio_id=request.portfolio_id,
            name=request.name,
            assets=request.assets,
            total_value=Decimal(str(request.total_value)),
            user_id=request.user_id,
        )
        await _maybe_await(result)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Create portfolio failed (live portfolio operation)")
        error_message = f"Failed to create portfolio: {e!s}"
        raise HTTPException(status_code=500, detail=error_message) from e


@router.post("/portfolio/optimize", response_model=dict[str, Any])
async def optimize_portfolio_endpoint(request: OptimizationRequest) -> dict[str, Any]:
    """
    Optimize a portfolio (live portfolio operations).

    Optimizes portfolio using live market data from Binance.US via backend (port 8000).
    All optimization uses live data - no fallback/hardcoded data.
    """
    try:
        portfolio = get_portfolio(request.portfolio_id)
        result = optimize_portfolio(
            portfolio_id=request.portfolio_id,
            strategy=request.strategy,
            target_return=request.target_return,
            target_volatility=request.target_volatility,
            max_weight=request.max_weight,
        )
        result = await _maybe_await(result)

    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Optimize portfolio failed (live portfolio operation)")
        error_message = f"Failed to optimize portfolio: {e!s}"
        raise HTTPException(status_code=500, detail=error_message) from e

    # Validate portfolio exists outside try to avoid TRY301
    if not portfolio:
        raise HTTPException(status_code=404, detail="Portfolio not found")

    return {
        "success": True,
        "optimization_result": {
            "optimal_weights": getattr(result, "optimal_weights", None),
            "expected_return": getattr(result, "expected_return", None),
            "expected_volatility": getattr(result, "expected_volatility", None),
            "sharpe_ratio": getattr(result, "sharpe_ratio", None),
            "optimization_status": getattr(result, "optimization_status", None),
        },
        "message": "Portfolio optimized successfully",
    }


@router.post("/portfolio/rebalance", response_model=dict[str, Any])
async def rebalance_portfolio_endpoint(request: RebalanceRequest) -> dict[str, Any]:
    """
    Rebalance a portfolio (live portfolio operations).

    Rebalances portfolio using live market data from Binance.US via backend (port 8000).
    All rebalancing uses live data - no fallback/hardcoded data.
    """
    try:
        await rebalance_portfolio(
            portfolio_id=request.portfolio_id,
            target_weights=request.target_weights,
            transaction_cost=request.transaction_cost,
        )
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Rebalance portfolio failed (live portfolio operation)")
        error_message = f"Failed to rebalance portfolio: {e!s}"
        raise HTTPException(status_code=500, detail=error_message) from e


@router.get("/portfolio/{portfolio_id}", response_model=dict[str, Any])
async def get_portfolio_endpoint(portfolio_id: str) -> dict[str, Any]:
    """
    Get portfolio details (live portfolio operations).

    Retrieves live portfolio data from backend (port 8000).
    All portfolio data is from live operations - no fallback/hardcoded data.
    """
    try:
        portfolio = get_portfolio(portfolio_id)
        performance = get_portfolio_performance(portfolio_id)
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Get portfolio failed (live portfolio operation)")
        error_message = f"Failed to get portfolio: {e!s}"
        raise HTTPException(status_code=500, detail=error_message) from e

    # Validate portfolio exists outside try to avoid TRY301
    if not portfolio:
        raise HTTPException(status_code=404, detail="Portfolio not found")

    return {
        "success": True,
        "portfolio": {
            "portfolio_id": getattr(portfolio, "portfolio_id", None),
            "name": getattr(portfolio, "name", None),
            "assets": getattr(portfolio, "assets", None),
            "total_value": float(getattr(portfolio, "total_value", 0)),
            "expected_return": getattr(portfolio, "expected_return", None),
            "volatility": getattr(portfolio, "volatility", None),
            "sharpe_ratio": getattr(portfolio, "sharpe_ratio", None),
            "created_at": getattr(portfolio, "created_at", None),
            "updated_at": getattr(portfolio, "updated_at", None),
        },
        "performance": performance,
        "message": "Portfolio retrieved successfully",
    }


# Backtesting Endpoints (Uses Live Market Data from Binance.US)


@router.post("/backtest/run", response_model=dict[str, Any])
async def run_backtest_endpoint(request: BacktestRequest, _background_tasks: BackgroundTasks) -> dict[str, Any]:
    """
    Run a backtest (uses live market data from Binance.US).

    Runs backtest using live historical market data from Binance.US via backend (port 8000).
    All backtest data is from live market data - no fallback/hardcoded data.
    """
    try:
        start_date = datetime.fromisoformat(request.start_date.replace("Z", "+00:00"))
        end_date = datetime.fromisoformat(request.end_date.replace("Z", "+00:00"))

        config = BacktestConfig(
            initial_capital=Decimal(str(request.initial_capital)),
            commission_per_trade=Decimal(str(request.commission_per_trade)),
            slippage=Decimal(str(request.slippage)),
        )

        backtest_id = await run_backtest(
            strategy_name=request.strategy_name,
            symbols=request.symbols,
            start_date=start_date,
            end_date=end_date,
            config=config,
        )
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Run backtest failed (live market data operation)")
        error_message = f"Failed to start backtest: {e!s}"
        raise HTTPException(status_code=500, detail=error_message) from e
    else:
        return {
            "success": True,
            "backtest_id": backtest_id,
            "message": "Backtest started successfully",
            "status": "running",
        }


@router.post("/backtest/walk-forward", response_model=dict[str, Any])
async def run_walk_forward_endpoint(request: WalkForwardRequest, _background_tasks: BackgroundTasks) -> dict[str, Any]:
    """
    Run walk-forward analysis (uses live market data from Binance.US).

    Runs walk-forward analysis using live historical market data from Binance.US via backend (port 8000).
    All analysis data is from live market data - no fallback/hardcoded data.
    """
    try:
        start_date = datetime.fromisoformat(request.start_date.replace("Z", "+00:00"))
        end_date = datetime.fromisoformat(request.end_date.replace("Z", "+00:00"))

        backtest_id = await run_walk_forward_analysis(
            strategy_name=request.strategy_name,
            symbols=request.symbols,
            start_date=start_date,
            end_date=end_date,
        )
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Run walk-forward analysis failed (live market data operation)")
        error_message = f"Failed to start walk-forward analysis: {e!s}"
        raise HTTPException(status_code=500, detail=error_message) from e
    else:
        return {
            "success": True,
            "backtest_id": backtest_id,
            "message": "Walk-forward analysis started successfully",
            "status": "running",
        }


@router.post("/backtest/monte-carlo", response_model=dict[str, Any])
async def run_monte_carlo_endpoint(request: MonteCarloRequest, _background_tasks: BackgroundTasks) -> dict[str, Any]:
    """
    Run Monte Carlo simulation (uses live market data from Binance.US).

    Runs Monte Carlo simulation using live historical market data from Binance.US via backend (port 8000).
    All simulation data is from live market data - no fallback/hardcoded data.
    """
    try:
        start_date = datetime.fromisoformat(request.start_date.replace("Z", "+00:00"))
        end_date = datetime.fromisoformat(request.end_date.replace("Z", "+00:00"))

        backtest_id = await run_monte_carlo_simulation(
            strategy_name=request.strategy_name,
            symbols=request.symbols,
            start_date=start_date,
            end_date=end_date,
            num_simulations=request.num_simulations,
        )
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Run Monte Carlo simulation failed (live market data operation)")
        error_message = f"Failed to start Monte Carlo simulation: {e!s}"
        raise HTTPException(status_code=500, detail=error_message) from e
    else:
        return {
            "success": True,
            "backtest_id": backtest_id,
            "message": "Monte Carlo simulation started successfully",
            "status": "running",
        }


@router.get("/backtest/{backtest_id}", response_model=dict[str, Any])
async def get_backtest_result_endpoint(backtest_id: str) -> dict[str, Any]:
    """
    Get backtest result (uses live market data from Binance.US).

    Retrieves backtest results computed from live historical market data from Binance.US.
    All results are from live market data - no fallback/hardcoded data.
    """
    try:
        result = get_backtest_result(backtest_id)
        if not result:
            return {
                "success": True,
                "backtest_id": backtest_id,
                "status": "running",
                "message": "Backtest is still running",
            }

        return {
            "success": True,
            "backtest_id": backtest_id,
            "status": "completed",
            "result": {
                "total_return": getattr(result, "total_return", None),
                "annualized_return": getattr(result, "annualized_return", None),
                "volatility": getattr(result, "volatility", None),
                "sharpe_ratio": getattr(result, "sharpe_ratio", None),
                "max_drawdown": getattr(result, "max_drawdown", None),
                "win_rate": getattr(result, "win_rate", None),
                "profit_factor": getattr(result, "profit_factor", None),
                "total_trades": getattr(result, "total_trades", None),
                "calmar_ratio": getattr(result, "calmar_ratio", None),
                "sortino_ratio": getattr(result, "sortino_ratio", None),
            },
            "equity_curve": [{"timestamp": ts.isoformat() if hasattr(ts, "isoformat") else ts, "equity": eq} for ts, eq in getattr(result, "equity_curve", [])],
            "message": "Backtest result retrieved successfully",
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Get backtest result failed (live market data operation)")
        error_message = f"Failed to get backtest result: {e!s}"
        raise HTTPException(status_code=500, detail=error_message) from e


@router.get("/backtest/active", response_model=dict[str, Any])
async def get_active_backtests_endpoint() -> dict[str, Any]:
    """
    Get list of active backtests (uses live market data from Binance.US).

    Retrieves list of active backtests running on live market data from Binance.US.
    All backtest data is from live market data - no fallback/hardcoded data.
    """
    try:
        active_backtests = backtesting_service.get_active_backtests()

        return {
            "success": True,
            "active_backtests": active_backtests,
            "count": len(active_backtests),
            "message": "Active backtests retrieved successfully",
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Get active backtests failed (live market data operation)")
        error_message = f"Failed to get active backtests: {e!s}"
        raise HTTPException(status_code=500, detail=error_message) from e


@router.delete("/backtest/{backtest_id}", response_model=dict[str, Any])
async def cancel_backtest_endpoint(backtest_id: str) -> dict[str, Any]:
    """
    Cancel a running backtest (uses live market data from Binance.US).

    Cancels a running backtest that uses live market data from Binance.US.
    All backtest operations use live data - no fallback/hardcoded data.
    """
    try:
        cancelled = await backtesting_service.cancel_backtest(backtest_id)
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error cancelling backtest: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e

    # Validate cancellation result outside try to avoid TRY301
    if not cancelled:
        raise HTTPException(status_code=404, detail="Backtest not found or not running")

    return {
        "success": True,
        "backtest_id": backtest_id,
        "message": "Backtest cancelled successfully",
    }
