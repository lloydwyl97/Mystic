"""
AI Learning Endpoints
Provides real-time AI learning progress, model training status, and learning metrics.
"""

import inspect
import logging
import time
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException

# Import ai_learning_service for real learning data
from backend.services.ai_learning_service import get_ai_learning_service
from backend.services.canonical_cache import canonical_cache as get_shared_cache

# Lazy import for optional training pipeline (may not be available in all deployments)
try:
    from ai_training_pipeline import AITrainingPipeline
except ImportError:
    AITrainingPipeline = None  # type: ignore[assignment, misc]

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/ai/learning", tags=["ai-learning"])

# Initialize learning service
learning_service = get_ai_learning_service()


class AITrainingPipelineUnavailableError(ImportError):
    """AI training pipeline not available"""

    def __init__(self) -> None:
        super().__init__("AI training pipeline not available")


@router.get("/progress")
async def get_ai_learning_progress() -> dict[str, Any]:
    """Get real-time AI learning progress and training status from learning service"""
    try:
        # Get real learning status from learning service
        learning_status = await learning_service.get_learning_status()

        # Return real learning progress data
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "learning_active": learning_status.get("learning_active", False),
            "learning_stats": learning_status.get("learning_stats", {}),
            "performance_summary": learning_status.get("performance_summary", {}),
            "training_status": {
                "active": learning_status.get("learning_active", False),
                "status": "TRAINING" if learning_status.get("learning_active", False) else "READY",
                "total_sessions": learning_status.get("learning_stats", {}).get("total_training_sessions", 0),
                "successful": learning_status.get("learning_stats", {}).get("successful_trainings", 0),
                "failed": learning_status.get("learning_stats", {}).get("failed_trainings", 0),
                "last_training": learning_status.get("learning_stats", {}).get("last_training"),
            },
            "live_data": True,
        }

    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting AI learning progress: {e}")
        raise HTTPException(status_code=500, detail=f"AI learning progress failed: {e!s}") from e


@router.get("/models")
async def get_ai_models_status() -> dict[str, Any]:
    """Get real-time AI model status and training information from learning service"""
    try:
        # Get comprehensive stats from learning service
        comprehensive_stats = await learning_service.get_comprehensive_stats()

        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "learning_service": comprehensive_stats.get("learning_service", {}),
            "training_pipeline": comprehensive_stats.get("training_pipeline", {}),
            "enhanced_trainer": comprehensive_stats.get("enhanced_trainer", {}),
            "is_learning_active": comprehensive_stats.get("is_learning_active", False),
            "live_data": True,
        }

    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting AI models status: {e}")
        raise HTTPException(status_code=500, detail=f"AI models status failed: {e!s}") from e


@router.get("/insights")
async def get_ai_learning_insights() -> dict[str, Any]:
    """Get AI learning insights and discoveries"""
    try:
        current_time = time.time()

        # Get real AI insights from the training pipeline
        try:
            if AITrainingPipeline is None:
                raise AITrainingPipelineUnavailableError()

            cache = get_shared_cache()
            pipeline = AITrainingPipeline(cache)

            # Support both sync and async implementations of get_insights
            real_insights = pipeline.get_insights()
            if inspect.isawaitable(real_insights):
                real_insights = await real_insights

            # Ensure it's a dict-like object
            if not isinstance(real_insights, dict):
                real_insights = {}

            insights = {
                "timestamp": datetime.fromtimestamp(current_time, timezone.utc).isoformat(),
                "recent_discoveries": real_insights.get("discoveries", []),
                "learning_trends": real_insights.get("trends", {}),
                "live_data": True,
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Failed to get real AI insights: {e}")
            # Return empty structure - no hardcoded fallback
            insights = {
                "timestamp": datetime.fromtimestamp(current_time, timezone.utc).isoformat(),
                "recent_discoveries": [],
                "learning_trends": {},
                "live_data": False,
            }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting AI learning insights: {e}")
        raise HTTPException(status_code=500, detail=f"AI learning insights failed: {e!s}") from e
    else:
        return insights
