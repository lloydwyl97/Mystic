"""
AI AutoBuy Orchestrator Endpoints

API endpoints for monitoring and controlling the orchestrator service that
manages transitions between paper and live trading based on AI accuracy.
"""

import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException

from backend.services.ai_autobuy_orchestrator import get_orchestrator

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/autobuy/orchestrator", tags=["AutoBuy Orchestrator"])


@router.get("/status")
async def get_orchestrator_status() -> dict[str, Any]:
    """Get current orchestrator status and AI accuracy"""
    try:
        orchestrator = get_orchestrator()
        status = await orchestrator.get_status()

        return {
            "status": "success",
            "orchestrator": status,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:
        logger.exception(f"Error getting orchestrator status: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/transition-to-live")
async def force_transition_to_live() -> dict[str, Any]:
    """Manually force transition from paper to live trading"""

    def _raise_transition_error(error: str) -> None:
        raise HTTPException(status_code=400, detail=error)

    try:
        orchestrator = get_orchestrator()
        result = await orchestrator.force_transition_to_live()

        if not result["success"]:
            _raise_transition_error(result.get("error", "Transition failed"))

        return {
            "status": "success",
            "message": "Transitioned to live trading",
            "state": result["state"],
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error forcing transition to live: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/rollback-to-paper")
async def force_rollback_to_paper() -> dict[str, Any]:
    """Manually force rollback from live to paper trading"""

    def _raise_rollback_error(error: str) -> None:
        raise HTTPException(status_code=400, detail=error)

    try:
        orchestrator = get_orchestrator()
        result = await orchestrator.force_rollback_to_paper()

        if not result["success"]:
            _raise_rollback_error(result.get("error", "Rollback failed"))

        return {
            "status": "success",
            "message": "Rolled back to paper trading",
            "state": result["state"],
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error forcing rollback to paper: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/history")
async def get_transition_history() -> dict[str, Any]:
    """Get history of state transitions"""
    try:
        orchestrator = get_orchestrator()

        return {
            "status": "success",
            "transitions": orchestrator.transition_history,
            "count": len(orchestrator.transition_history),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:
        logger.exception(f"Error getting transition history: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e
