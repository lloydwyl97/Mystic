"""
AI Endpoints
Provides AI-related API endpoints for the dashboard
"""

import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/ai", tags=["ai"])

# Initialize AI service - Use ai_prediction_service for unified predictions
ai_service = None
ai_prediction_service = None
try:
    from backend.services.ai_prediction_service import ai_prediction_service as _pred_svc
    from backend.services.ai_service import get_ai_service

    ai_service = get_ai_service()
    ai_prediction_service = _pred_svc
    logger.info("AIService and AIPredictionService initialized successfully")
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
    logger.exception(f"Failed to initialize AI services: {e}")
    ai_service = None
    ai_prediction_service = None


def _safe_get(obj: Any, key: str, default: Any = None) -> Any:
    """Safely get a value from a dict-like or object-like response."""
    try:
        if isinstance(obj, dict):
            return obj.get(key, default)
        if hasattr(obj, key):
            return getattr(obj, key, default)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        pass
    return default


def _predictions_list(predictions: Any):
    """Return a list of predictions from the service response, handling multiple shapes."""
    if isinstance(predictions, dict):
        return predictions.get("predictions", []) or []
    if isinstance(predictions, list):
        return predictions
    return []


@router.get("/status")
async def get_ai_status():
    """Get AI service status"""
    try:
        if ai_service:
            status = await ai_service.get_status()
            return {
                "status": "online",
                "service": status,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        return {
            "error": "AI service not available",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting AI status: {e}")
        return {
            "status": "error",
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }


@router.get("/predictions")
async def get_ai_predictions():
    """Get AI predictions using unified prediction service"""
    try:
        # Use ai_prediction_service for unified, cached predictions
        if ai_prediction_service:
            result = await ai_prediction_service.get_predictions(limit=50)
            return {
                "predictions": result.get("predictions", []),
                "count": len(result.get("predictions", [])),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        # Fallback to ai_service if prediction service unavailable
        if ai_service:
            predictions = await ai_service.get_predictions()
            preds_list = _predictions_list(predictions)
            return {
                "predictions": predictions,
                "count": len(preds_list),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        return {
            "error": "AI prediction service not available",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting AI predictions: {e}")
        return {
            "predictions": [],
            "count": 0,
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }


@router.get("/models")
async def get_ai_models():
    """Get AI models list from actual AI service"""
    try:
        if ai_service:
            status = await ai_service.get_status()
            status_models = _safe_get(status, "models", "unknown")
            status_accuracy = _safe_get(status, "accuracy", 0.0)
            status_timestamp = _safe_get(status, "timestamp", datetime.now(timezone.utc).isoformat())
            models = [
                {
                    "id": "ai_model_1",
                    "name": "Live AI Engine",
                    "status": status_models,
                    "accuracy": status_accuracy,
                    "last_trained": status_timestamp,
                },
            ]
            return {
                "models": models,
                "total_models": len(models),
                "active_models": len([m for m in models if m.get("status") == "active"]),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        return {
            "error": "AI service not available",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting AI models: {e}")
        return {"error": str(e), "timestamp": datetime.now(timezone.utc).isoformat()}


@router.get("/performance")
async def get_ai_performance():
    """Get AI performance metrics from actual AI service"""
    try:
        if ai_service:
            # Use predictions to create performance info since get_performance_metrics doesn't exist
            predictions = await ai_service.get_predictions()
            preds_list = _predictions_list(predictions)
            performance = {
                "total_predictions": len(preds_list),
                "accuracy": _safe_get(predictions, "confidence", 0.0),
                "last_updated": _safe_get(predictions, "timestamp", datetime.now(timezone.utc).isoformat()),
                "model_version": _safe_get(predictions, "model_version", "v1.0.0"),
            }
            return {
                "performance": performance,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        return {
            "error": "AI service not available",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting AI performance: {e}")
        return {"error": str(e), "timestamp": datetime.now(timezone.utc).isoformat()}


@router.get("/insights")
async def get_ai_insights():
    """Get AI insights from actual AI service"""
    try:
        if ai_service:
            # Use predictions to create insights since get_insights doesn't exist
            predictions = await ai_service.get_predictions()
            preds_list = _predictions_list(predictions)
            insights = [
                {
                    "type": "prediction_analysis",
                    "message": f"AI generated {len(preds_list)} predictions",
                    "confidence": _safe_get(predictions, "confidence", 0.0),
                    "timestamp": _safe_get(predictions, "timestamp", datetime.now(timezone.utc).isoformat()),
                },
            ]
            return {
                "insights": insights,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        return {
            "error": "AI service not available",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting AI insights: {e}")
        return {"error": str(e), "timestamp": datetime.now(timezone.utc).isoformat()}
