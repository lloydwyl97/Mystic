"""
AI Explain Endpoints
Expose attribution results for AI explainability features.
"""

from __future__ import annotations

import inspect
import logging
from typing import Any

from fastapi import APIRouter, HTTPException, Query

from backend.services.ai_attribution import load_attribution

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/ai/explain", tags=["ai"])


@router.get("/attribution")
async def attribution(
    symbol: str = Query(..., description="Symbol, e.g. BTCUSDT"),
) -> dict[str, Any]:
    """Return model attribution data for a given symbol."""
    try:
        result = load_attribution(symbol)
        # support both sync and async load_attribution implementations
        data: dict[str, Any]
        if inspect.isawaitable(result):
            data = await result  # type: ignore[assignment]
        else:
            data = result  # type: ignore[assignment]

        return {
            "ok": True,
            "symbol": symbol.upper(),
            "attribution": data,
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Attribution error for {symbol}: {e!s}")
        raise HTTPException(status_code=500, detail=f"Attribution failed: {e!s}") from e

    # Validate data type outside try to avoid TRY301
    if not isinstance(data, dict):
        msg = "Attribution did not return a dict"
        raise TypeError(msg)

    return {
        "ok": True,
        "symbol": symbol.upper(),
        "attribution": data,
    }
