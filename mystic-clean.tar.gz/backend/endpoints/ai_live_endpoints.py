"""
AI Live Endpoints
Live AI status and models.
"""

from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException

# Direct imports for production
from backend.config.settings import settings

# LOW #6 FIX: ai_live_engine removed - use ai_prediction_service and get_trade_performance_summary
ai_live_engine = None  # Legacy engine disabled; use ai_prediction_service
import contextlib

from backend.services.ai_prediction_service import ai_prediction_service

try:
    from backend.services.ai_signal_generator import get_signal_generator
except ImportError:
    get_signal_generator = None

try:
    from backend.services.trade_performance_tracker import get_trade_performance_summary

    TRADE_PERFORMANCE_AVAILABLE = True
except ImportError:
    TRADE_PERFORMANCE_AVAILABLE = False
    get_trade_performance_summary = None

# Lazy import for optional auto trading manager (may not be available in all deployments)
try:
    from backend.services.auto_trading_manager import auto_trading_manager
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    auto_trading_manager = None  # type: ignore[assignment, misc]

logger = logging.getLogger(__name__)

# Mount these under /api/ai-live
router = APIRouter(prefix="/api/ai-live", tags=["AI Live"])


@router.get("/")
async def get_ai_live_status() -> dict[str, Any]:
    """Return live AI status from ML signal generator."""
    try:
        # Use ML signal generator instead of legacy engine
        sig_gen = get_signal_generator() if get_signal_generator else None
        is_running = sig_gen.is_running if sig_gen else False

        if not is_running:
            return {
                "learning_active": False,
                "model_loaded": False,
                "initialized": False,
                "running": False,
                "is_ready": False,
                "error": "AI signal generator not running",
                "model_performance": {"ensemble_accuracy": 0.0},
                "performance_metrics": {
                    "prediction_count": 0,
                    "training_count": 0,
                    "uptime_seconds": 0.0,
                },
                "average_win_rate": 0.0,
                "total_trades": 0,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        # Signal generator is running - return real status from Redis
        # BUG #5 FIX: Use shared Redis client (prefer async if available, fallback to sync)
        from backend.config.redis_config import get_shared_redis_async

        redis_async = get_shared_redis_async()
        use_async = redis_async is not None

        if not use_async:
            from backend.config.redis_config import get_shared_redis_sync

            redis_client = get_shared_redis_sync()
        else:
            redis_client = redis_async

        # Get trade performance
        # BUG #16 FIX: Move hardcoded cutoff to environment variable/config
        current_bot_cutoff = os.getenv("BOT_PERFORMANCE_CUTOFF", "2025-12-10T17:00:00")
        if TRADE_PERFORMANCE_AVAILABLE and get_trade_performance_summary:
            try:
                # BUG #16 FIX: Move hardcoded cutoff timestamp to config
                trade_performance = get_trade_performance_summary(since_timestamp=current_bot_cutoff)
            except Exception as e:
                logger.exception(f"Failed to get trade performance: {e}")
                trade_performance = {"total_trades": 0, "win_rate": 0.0}
        else:
            trade_performance = {"total_trades": 0, "win_rate": 0.0}

        # Get signal count from Redis
        if use_async and redis_client:
            signal_count = 0
            async for _key in redis_client.scan_iter(match="ai_signal:*", count=100):
                signal_count += 1
            prediction_count = signal_count
            redis_accuracy = await redis_client.get("ai:live:ensemble_accuracy")
        elif redis_client:
            # Sync: run in thread to avoid blocking
            def _sync_redis_fetch():
                keys = list(redis_client.scan_iter(match="ai_signal:*", count=100))
                acc = redis_client.get("ai:live:ensemble_accuracy")
                return len(keys), acc

            prediction_count, redis_accuracy = await asyncio.to_thread(_sync_redis_fetch)
        else:
            prediction_count, redis_accuracy = 0, None

        if redis_accuracy:
            try:
                ensemble_accuracy = float(redis_accuracy)
            except (ValueError, TypeError):
                ensemble_accuracy = 0.7
        else:
            ensemble_accuracy = 0.7

        return {
            "learning_active": True,
            "model_loaded": True,
            "initialized": True,
            "running": True,
            "is_ready": True,
            "model_performance": {
                "ensemble_accuracy": ensemble_accuracy,
            },
            "performance_metrics": {
                "prediction_count": prediction_count,
                "training_count": 0,
                "uptime_seconds": 0.0,
            },
            "average_win_rate": trade_performance.get("win_rate", 0.0) / 100.0,
            "total_trades": trade_performance.get("total_trades", 0),
            "debug_marker": "ML_SIGNAL_GENERATOR_ACTIVE",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"AI live status error: {e!s}")
        return {
            "learning_active": False,
            "model_loaded": False,
            "initialized": False,
            "running": False,
            "is_ready": False,
            "error": f"AI live status error: {e!s}",
            "model_performance": {"ensemble_accuracy": 0.0},
            "performance_metrics": {
                "prediction_count": 0,
                "training_count": 0,
                "uptime_seconds": 0.0,
            },
            "average_win_rate": 0.0,
            "total_trades": 0,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    finally:
        # MEDIUM #6 FIX: Ensure sync client cleanup on exception
        if not use_async and "redis_client" in locals():
            with contextlib.suppress(Exception):
                redis_client.close()


@router.get("/status")
async def get_ai_live_status_endpoint() -> dict[str, Any]:
    """Alias for root endpoint - return live AI status."""
    logger.info("AI LIVE STATUS ENDPOINT CALLED")  # Debug print
    return await get_ai_live_status()


@router.get("/test-trade-stats")
async def get_test_trade_stats() -> dict[str, Any]:
    """Test endpoint to verify trade performance tracking works."""
    logger.info("TEST TRADE STATS ENDPOINT CALLED")  # Debug print
    trade_performance = get_trade_performance_summary()
    return {"message": "Trade performance tracking test", "trade_performance": trade_performance, "debug_marker": "MODIFIED_AI_LIVE_ENDPOINT", "timestamp": datetime.now(timezone.utc).isoformat()}


@router.get("/models")
async def get_ai_live_models() -> dict[str, Any]:
    """Return live AI models list."""
    try:
        if ai_live_engine is None:
            return {
                "models": [],
                "total_models": 0,
                "active_models": 0,
                "model_types": [],
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        # Get models from AI live engine
        state_dict = ai_live_engine.get_state_dict() if hasattr(ai_live_engine, "get_state_dict") else {}
        if not getattr(state_dict, "get", None):
            state_dict = {}

        # Extract model information
        models_info = state_dict.get("models", {}) or {}
        model_list = models_info.get("available_models", []) or []

        # Get model types
        model_types = list({model.get("type", "unknown") for model in model_list if isinstance(model, dict)})

        # Count active models
        active_models = len([m for m in model_list if isinstance(m, dict) and m.get("status") == "active"])

        return {
            "models": model_list,
            "total_models": len(model_list),
            "active_models": active_models,
            "model_types": model_types,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting AI live models: {e}")
        return {
            "models": [],
            "total_models": 0,
            "active_models": 0,
            "model_types": [],
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }


@router.get("/predictions")
async def get_ai_live_predictions() -> dict[str, Any]:
    """Get live AI predictions from prediction service - production data only"""
    try:
        result = await ai_prediction_service.get_predictions(limit=50)

        return {
            "status": "success",
            "predictions": result.get("predictions", []),
            "count": len(result.get("predictions", [])),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get AI predictions: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get AI predictions: {e}") from e


@router.get("/performance")
async def get_ai_live_performance() -> dict[str, Any]:
    """Return live AI performance metrics."""
    try:
        if ai_live_engine is None:
            raise HTTPException(status_code=503, detail="AI Live Engine not available")

        state_dict = ai_live_engine.get_state_dict() if hasattr(ai_live_engine, "get_state_dict") else {}
        if not getattr(state_dict, "get", None):
            state_dict = {}

        # Extract performance metrics from live engine
        performance_metrics = state_dict.get("performance_metrics", {}) or {}

        total_trades = int(performance_metrics.get("total_trades", 0) or 0)
        winning_trades = int(performance_metrics.get("winning_trades", 0) or 0)
        losing_trades = int(performance_metrics.get("losing_trades", 0) or 0)
        win_rate = (winning_trades / total_trades * 100.0) if total_trades > 0 else 0.0
        total_pnl = float(performance_metrics.get("total_pnl", 0.0) or 0.0)
        sharpe_ratio = float(performance_metrics.get("sharpe_ratio", 0.0) or 0.0)
        max_drawdown = float(performance_metrics.get("max_drawdown", 0.0) or 0.0)
        average_return = float(performance_metrics.get("average_return", 0.0) or 0.0)
        volatility = float(performance_metrics.get("volatility", 0.0) or 0.0)

        return {
            "total_trades": total_trades,
            "winning_trades": winning_trades,
            "losing_trades": losing_trades,
            "win_rate": win_rate,
            "total_pnl": total_pnl,
            "sharpe_ratio": sharpe_ratio,
            "max_drawdown": max_drawdown,
            "average_return": average_return,
            "volatility": volatility,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"AI live performance error: {e!s}")
        raise HTTPException(status_code=500, detail=f"Failed to get AI performance: {e}") from e


@router.get("/predict/{symbol}")
async def get_ai_prediction(symbol: str):
    """Get AI prediction for a specific symbol using unified prediction service."""
    # Validate symbol format before try block to avoid TRY301
    if not symbol or not isinstance(symbol, str):
        raise HTTPException(
            status_code=400,
            detail="Invalid symbol: symbol must be a non-empty string",
        )

    # Basic symbol validation (should be uppercase, contain USDT, etc.)
    if not symbol.isupper() or not symbol.endswith("USDT"):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid symbol format: {symbol}. Expected format: SYMBOLUSDT",
        )

    # Check if symbol is supported - USE CENTRALIZED CONFIG
    supported_symbols = settings.trading_symbols
    if symbol not in supported_symbols:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported symbol: {symbol}. Supported symbols: {', '.join(supported_symbols)}",
        )

    try:
        logger.info(f"Getting AI prediction for symbol: {symbol}")

        # Use ai_prediction_service for unified predictions with caching
        try:
            prediction_data = await ai_prediction_service.predict_symbol(symbol, ttl=30)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.warning(f"AI prediction service failed for {symbol}, falling back to engine: {e}")
            # Fallback to direct engine call
            if ai_live_engine is None:
                raise HTTPException(status_code=503, detail="AI services unavailable") from e

            coin = {
                "symbol": symbol,
                "price": 0.0,
                "volume_24h": 0.0,
                "change_1h": 0.0,
                "rsi": 50.0,
                "macd": {"macd_line": 0.0, "signal_line": 0.0, "histogram": 0.0},
                "volatility_index": 0.0,
            }
            prediction_data = await ai_live_engine.predict(coin)

        if not prediction_data:
            logger.warning(f"No prediction data available for {symbol}")
            return {
                "status": "no_data",
                "symbol": symbol,
                "message": f"No prediction data available for {symbol}",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        return {
            "status": "success",
            "symbol": symbol,
            "prediction": prediction_data,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting AI prediction for {symbol}: {e}")
        raise HTTPException(status_code=500, detail=f"AI prediction failed for {symbol}: {e!s}") from e


@router.get("/models/metadata")
async def get_ai_live_models_metadata() -> list[dict[str, Any]]:
    """Return available AI models with metadata (live only)."""
    # Validate AI live engine availability before try block to avoid TRY301
    if ai_live_engine is None:
        raise HTTPException(status_code=503, detail="AI live engine unavailable")

    try:
        models: list[dict[str, Any]] = []
        try:
            registry = getattr(ai_live_engine, "models", {}) or {}
            # Ensure registry is dict-like
            if not getattr(registry, "items", None):
                registry = {}
            for _, model in registry.items():
                try:
                    if hasattr(model, "model_dump"):
                        models.append(model.model_dump())
                    elif hasattr(model, "dict"):
                        models.append(model.dict())  # type: ignore[call-arg]
                    else:
                        models.append(dict(model))  # type: ignore[arg-type]
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    continue
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            pass
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"AI live models error: {e!s}")
        raise HTTPException(status_code=500, detail=f"AI live models error: {e!s}") from e
    else:
        return models


@router.get("/bots/status")
async def get_bots_status_workaround() -> dict[str, Any]:
    """Optional helper for bot status via AutoTradingManager (live-only, best-effort)."""
    try:
        if auto_trading_manager is None:
            return {
                "status": "unavailable",
                "manager": None,
                "bots_count": 0,
                "active_bots": 0,
            }

        if auto_trading_manager:
            try:
                bots_status = await auto_trading_manager.get_all_bots_status()
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.warning(f"AutoTradingManager bots status error: {e!s}")
                bots_status = {}
            result = {
                "status": "operational",
                "manager": "auto_trading_manager",
                "bots_count": (bots_status or {}).get("total_bots", 0),
                "active_bots": (bots_status or {}).get("active_bots", 0),
            }
        else:
            # No manager: return a minimal, honest response
            result = {
                "status": "unavailable",
                "manager": "auto_trading_manager",
                "message": "AutoTradingManager not available",
            }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Bot status error: {e!s}")
        return {
            "status": "error",
            "message": f"Bot status error: {e!s}",
        }
    else:
        return result
