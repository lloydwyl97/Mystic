"""
AI Strategies Endpoints Package
Contains AI strategy management endpoints
"""

# Import from the correct location (ai/ directory)
from backend.endpoints.ai.ai_strategy_endpoints import router

__all__ = ["router"]
