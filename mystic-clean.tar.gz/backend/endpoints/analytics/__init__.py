"""
Analytics Endpoints Module
Handles analytics, reporting, and data visualization endpoints
"""

from fastapi import APIRouter

router = APIRouter(tags=["Analytics"])

__all__ = ["router"]
