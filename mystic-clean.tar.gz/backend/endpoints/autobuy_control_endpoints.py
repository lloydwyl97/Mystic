"""
AutoBuy Engine Control Endpoints - Use Portfolio Engine (LEGACY runtime_autobuy removed)
"""

import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends

from backend.modules.ai.ai_signals import risk_adjusted_signals
from backend.services.admin_auth import require_admin_key

logger = logging.getLogger(__name__)
router = APIRouter(tags=["AutoBuy"])


def _get_portfolio_engine_snapshot() -> dict[str, Any]:
    """Get portfolio engine snapshot if initialized."""
    try:
        from backend.services.portfolio_engine import get_portfolio_engine, is_portfolio_engine_initialized

        if not is_portfolio_engine_initialized():
            return {}
        engine = get_portfolio_engine()
        return {
            "cash_balance": getattr(engine, "cash_balance", 0),
            "positions_count": len(getattr(engine, "open_positions", [])),
            "total_equity": getattr(engine, "_total_equity", 0),
        }
    except Exception:
        return {}


@router.post("/api/autobuy/start")
async def start_autobuy_engine(_key: None = Depends(require_admin_key)) -> dict[str, Any]:
    """AutoBuy is handled by portfolio_engine_integration (separate process). Start that process via start_mystic.sh or start_portfolio_engine_integration.py."""
    return {
        "status": "deprecated",
        "message": "AutoBuy runs via portfolio_engine_integration. Use start_portfolio_engine_integration.py or start_mystic.sh all",
        "canonical": "/api/portfolio-engine/ledger",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@router.post("/api/autobuy/stop")
async def stop_autobuy_engine(_key: None = Depends(require_admin_key)) -> dict[str, Any]:
    """AutoBuy is handled by portfolio_engine_integration. Stop that process to halt execution."""
    return {
        "status": "deprecated",
        "message": "Stop portfolio_engine_integration process to halt AutoBuy execution",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@router.post("/api/autobuy/enable")
async def enable_autobuy(live: bool = False, _key: None = Depends(require_admin_key)) -> dict[str, Any]:
    """Mode controlled by portfolio engine. Use /api/portfolio-engine endpoints for configuration."""
    return {
        "status": "deprecated",
        "message": "Use /api/portfolio-engine endpoints for trading configuration",
        "live": live,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@router.get("/api/autobuy/detailed-status")
async def get_detailed_autobuy_status() -> dict[str, Any]:
    """Get status from portfolio engine (canonical). Signals from risk_adjusted_signals."""
    try:
        pe = _get_portfolio_engine_snapshot()
        signals = risk_adjusted_signals()

        return {
            "status": "success",
            "engine": {
                "source": "portfolio_engine",
                "running": bool(pe),
                "cash_balance": pe.get("cash_balance", 0),
                "positions_count": pe.get("positions_count", 0),
                "total_equity": pe.get("total_equity", 0),
            },
            "signals": {"count": len(signals), "buy_signals": sum(1 for s in signals if s.get("recommendation") == "BUY"), "top_signal": signals[0] if signals else None},
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:
        logger.exception(f"Detailed status error: {e}")
        return {"status": "error", "error": str(e), "timestamp": datetime.now(timezone.utc).isoformat()}
