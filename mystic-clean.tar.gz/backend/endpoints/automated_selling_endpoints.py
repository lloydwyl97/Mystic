"""
Automated Paper Selling Endpoints

API endpoints for monitoring and controlling the automated selling service.
"""

import logging
from typing import Any

from fastapi import APIRouter, HTTPException

from backend.services.automated_paper_selling_service import get_automated_selling_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/automated-selling", tags=["Automated Selling"])


@router.get("/status")
async def get_automated_selling_status() -> dict[str, Any]:
    """Get automated selling service status"""
    try:
        service = get_automated_selling_service()
        return {"status": "success", "service_status": service.get_status()}
    except Exception as e:
        logger.exception(f"Error getting automated selling status: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/check-positions")
async def check_positions_manually() -> dict[str, Any]:
    """Manually trigger position checking and potential sells"""
    try:
        service = get_automated_selling_service()
        # Note: This would need to be implemented as a public method
        # For now, just return status
        return {"status": "success", "message": "Position check triggered", "service_status": service.get_status()}
    except Exception as e:
        logger.exception(f"Error triggering position check: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/config")
async def get_selling_config() -> dict[str, Any]:
    """Get current selling configuration"""
    try:
        service = get_automated_selling_service()
        status = service.get_status()
        return {
            "status": "success",
            "config": {
                "take_profit_pct": status.get("take_profit_pct", 0.03),
                "stop_loss_pct": status.get("stop_loss_pct", 0.06),
                "trail_stop_pct": status.get("trail_stop_pct", 0.05),
                "check_interval_sec": status.get("check_interval_sec", 60),
            },
            "environment_variables": {
                "TAKE_PROFIT_PCT": "0.03 (3% profit target)",
                "STOP_LOSS_PCT": "0.06 (6% stop loss)",
                "TRAIL_STOP_PCT": "0.05 (5% trailing stop)",
                "SELL_CHECK_INTERVAL": "60 (seconds between checks)",
            },
        }
    except Exception as e:
        logger.exception(f"Error getting selling config: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e
