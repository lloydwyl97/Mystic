"""
Binance.US Real Account Endpoints - LIVE DATA ONLY
Direct access to real Binance US account data
"""

import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException

from backend.services.binance_trading import get_binance_trading_service
from backend.services.paper_trading_service import get_paper_trading_service

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Binance"])


@router.get("/api/binance/account")
async def get_binance_account() -> dict[str, Any]:
    """Get REAL Binance.US account balance and info"""
    try:
        service = get_binance_trading_service()
        logger.info(f"Binance service API key present: {bool(service.api_key)}")
        logger.info(f"Binance service secret key present: {bool(service.secret_key)}")
        account_info = await service.get_account_info()

        if "error" in account_info:
            return {"status": "error", "error": account_info["error"], "message": "Failed to fetch Binance account data", "timestamp": datetime.now(timezone.utc).isoformat()}

        return {"status": "success", "account": account_info, "timestamp": datetime.now(timezone.utc).isoformat(), "source": "live_binance_us"}
    except Exception as e:
        logger.exception(f"Binance account error: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/api/binance/balance")
async def get_binance_balance() -> dict[str, Any]:
    """Get REAL Binance.US account balance summary"""
    try:
        service = get_binance_trading_service()
        account_info = await service.get_account_info()

        if "error" in account_info:
            return {"status": "error", "error": account_info["error"], "total_usdt": 0.0, "timestamp": datetime.now(timezone.utc).isoformat()}

        balances = account_info.get("balances", [])
        total_usdt = account_info.get("total_balance_usdt", 0.0)

        # Extract just the key balance info
        balance_summary = {asset["asset"]: {"free": asset["free"], "locked": asset["locked"], "total": asset["total"]} for asset in balances if asset["total"] > 0}

        return {"status": "success", "total_usdt": total_usdt, "balances": balance_summary, "timestamp": datetime.now(timezone.utc).isoformat(), "source": "live_binance_us"}
    except Exception as e:
        logger.exception(f"Binance balance error: {e}")
        return {"status": "error", "error": str(e), "total_usdt": 0.0, "timestamp": datetime.now(timezone.utc).isoformat()}


@router.post("/api/binance/sync-to-paper")
async def sync_binance_to_paper() -> dict[str, Any]:
    """Sync REAL Binance balance to paper trading account"""
    try:
        # Get real Binance balance
        binance_service = get_binance_trading_service()
        account_info = await binance_service.get_account_info()

        if "error" in account_info:
            return {"status": "error", "error": "Failed to fetch Binance balance", "timestamp": datetime.now(timezone.utc).isoformat()}

        real_balance = account_info.get("total_balance_usdt", 0.0)

        # Sync to paper trading
        paper_service = get_paper_trading_service()
        paper_service.current_balance = real_balance
        paper_service.initial_balance = real_balance

        return {
            "status": "success",
            "message": "Synced real Binance balance to paper trading",
            "real_balance": real_balance,
            "paper_balance": paper_service.current_balance,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:
        logger.exception(f"Sync error: {e}")
        return {"status": "error", "error": str(e), "timestamp": datetime.now(timezone.utc).isoformat()}
