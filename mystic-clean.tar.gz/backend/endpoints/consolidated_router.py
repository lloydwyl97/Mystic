"""
Consolidated Router - WORKING ENDPOINT SUITE
Loads proven working endpoints for mystic_ui compatibility (live-only)
"""

from __future__ import annotations

import logging
from collections.abc import Iterable

from fastapi import APIRouter

logger = logging.getLogger(__name__)

# Create main consolidated router
consolidated_router = APIRouter()

# Track (module_path, prefix) to avoid accidental double-includes
_included: set[tuple[str, str | None]] = set()


def _include_if_available(
    import_path: str,
    attr: str = "router",
    prefixes: Iterable[str | None] = (None,),
    display_name: str = "",
    critical: bool = False,
) -> None:
    """Best-effort import and include of a router with optional prefix aliases.

    - critical=True logs as error if missing; otherwise warning
    - prefixes can include None for root-mount and strings like "/api"
    - Creates separate router instances for multiple prefixes to avoid FastAPI deduplication
    """
    name = display_name or import_path
    try:
        module = __import__(import_path, fromlist=[attr])
        source_router = getattr(module, attr, None)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError, ImportError, ModuleNotFoundError) as e:
        msg = f"Error importing router from {import_path}: {e}"
        if critical:
            logger.exception(f"[ERROR] {msg}")
            raise
        else:
            # Check if this is a canonical_cache availability issue (non-critical, router will work at runtime)
            if "canonical_cache not available" in str(e):
                logger.info(f"[SKIP] Router {import_path} skipped due to canonical_cache not initialized yet (will work at runtime)")
            else:
                logger.warning(f"[SKIP] {msg}")
            return

    # Validate router exists outside try to avoid TRY301
    if source_router is None:
        msg = f"Module {import_path} missing attribute '{attr}'"
        raise AttributeError(msg)

    try:
        prefix_list = list(prefixes)
        for _idx, p in enumerate(prefix_list):
            key = (import_path, p or "")
            if key in _included:
                continue

            # For multiple prefixes, create separate router instances to avoid FastAPI deduplication
            if len(prefix_list) > 1:
                new_router = APIRouter(tags=getattr(source_router, "tags", None))
                # Copy all routes from source router
                for route in source_router.routes:
                    new_router.routes.append(route)
                consolidated_router.include_router(new_router, prefix=p or "")
            else:
                # Single prefix - use original router directly
                consolidated_router.include_router(source_router, prefix=p or "")

            _included.add(key)
        logger.info(f"[OK] Loaded {name} ({', '.join([p or 'root' for p in prefix_list])})")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        msg = f"Failed to load {name}: {e}"
        if critical:
            logger.exception(f"[ERROR] {msg}")
        else:
            logger.warning(f"[WARN] {msg}")


def load_all_endpoints() -> None:
    """Load ONLY proven working endpoints (live-only; no simulated providers)."""

    # ---------------------------------------------------------------------
    # CORE SYSTEM - DISABLED (contains health endpoints)
    # ---------------------------------------------------------------------
    # _include_if_available(
    #     "backend.endpoints.core.system_endpoints",
    #     prefixes=(None, "/api"),
    #     display_name="core system endpoints",
    #     critical=True,
    # )

    # Exchange endpoints (for exchange status)
    _include_if_available(
        "backend.routes.exchange",
        prefixes=(None, "/api"),
        display_name="exchange endpoints (ADDED)",
        critical=False,  # Made non-critical to allow app to start if REDIS_URL is not configured
    )

    # ---------------------------------------------------------------------
    # AUTO TRADING
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.routes.auto_trading",
        prefixes=(None,),  # Remove the /api/autobuy prefix since it's already in the router
        display_name="auto trading endpoints",
        critical=True,
    )

    # ---------------------------------------------------------------------
    # MARKET DATA (essential)
    # ---------------------------------------------------------------------
    # Market Data endpoints (live cache + Binance.US fetcher)
    # Original complex version - DISABLED (causing 500 errors)
    # _include_if_available(
    #     "backend.endpoints.market.market_data_endpoints",
    #     prefixes=(None,),
    #     display_name="market data endpoints",
    # )
    # NEW SIMPLE VERSION - LIVE DATA
    _include_if_available(
        "backend.endpoints.market_live_endpoints",
        prefixes=(None,),
        display_name="market data endpoints (LIVE, simple)",
        critical=False,
    )
    # _include_if_available(
    #     "backend.endpoints.enhanced_market_data_endpoints",
    #     prefixes=("/api",),
    #     display_name="enhanced market data endpoints",
    # )

    # ---------------------------------------------------------------------
    # AUTOBUY - Using routes/auto_trading.py only (consolidation complete)
    # ---------------------------------------------------------------------
    # REMOVED: Duplicate autobuy endpoints - consolidated into routes/auto_trading.py
    # - backend.endpoints.trading.autobuy_endpoints (REMOVED)
    # - backend.endpoints.autobuy_endpoints (REMOVED)
    # - backend.endpoints.runtime_autobuy_endpoints (REMOVED)
    # All autobuy functionality now in: backend/routes/auto_trading.py

    # UI ROUTES removed - dashboard cleanup

    # ---------------------------------------------------------------------
    # AI EXPLAIN (critical for mystic_ui market tab)
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.endpoints.ai_explain_endpoints",
        prefixes=(None,),
        display_name="AI explain endpoints (CRITICAL)",
        critical=True,
    )

    # ---------------------------------------------------------------------
    # AI ENDPOINTS
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.endpoints.ai_endpoints",
        prefixes=("/api/ai",),
        display_name="AI endpoints",
        critical=True,
    )

    # ---------------------------------------------------------------------

    # Metrics dashboard endpoints - DELETED (duplicate functionality)

    _include_if_available(
        "backend.endpoints.ai.ai_strategy_endpoints",
        prefixes=("/api/ai/strategies",),
        display_name="AI strategy endpoints",
        critical=True,
    )

    _include_if_available(
        "backend.endpoints.ai.ai_learning_endpoints",
        prefixes=("/api/ai",),
        display_name="AI learning endpoints",
        critical=True,
    )

    # ---------------------------------------------------------------------
    # AI LIVE ENDPOINTS (for dashboard AI page)
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.endpoints.ai_live_endpoints",
        prefixes=(None,),
        display_name="AI live endpoints",
        critical=True,
    )

    # ---------------------------------------------------------------------
    # SIGNALS ENDPOINTS
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.routes.signals",
        prefixes=(None,),
        display_name="signals endpoints",
        critical=True,
    )

    # ---------------------------------------------------------------------
    # LIVE TRADING (Binance US only)
    # ---------------------------------------------------------------------
    # COMMENTED OUT: Live trading endpoints causing hdrs warning
    # _include_if_available(
    #     "backend.endpoints.live_trading_endpoints",
    #     prefixes=(None, "/api"),
    #     display_name="live trading endpoints",
    # )

    # ---------------------------------------------------------------------
    # LIVE DATA ENDPOINTS (system status, data sources)
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.endpoints.live_endpoints.live_endpoints",
        prefixes=("/api/live",),
        display_name="live endpoints",
    )

    # ---------------------------------------------------------------------
    # ORDERS
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.routes.orders",
        prefixes=(None,),
        display_name="orders endpoints",
        critical=True,
    )

    # Trading backtest endpoints
    _include_if_available(
        "backend.endpoints.trading.backtest_endpoints",
        prefixes=(None, "/api"),
        display_name="trading backtest endpoints",
    )

    # Trading notifications endpoints
    _include_if_available(
        "backend.endpoints.trading.notifications_endpoints",
        prefixes=(None, "/api"),
        display_name="trading notifications endpoints",
    )

    # ---------------------------------------------------------------------
    # PAPER TRADING (live-only semantics; 204 when empty)
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.endpoints.paper_trading_endpoints",
        prefixes=(None,),
        display_name="paper trading endpoints",
    )

    # Automated Selling endpoints
    _include_if_available(
        "backend.endpoints.automated_selling_endpoints",
        prefixes=(None,),
        display_name="automated selling endpoints",
    )

    # AI AutoBuy Orchestrator endpoints
    _include_if_available(
        "backend.endpoints.ai_autobuy_orchestrator_endpoints",
        prefixes=(None,),
        display_name="AI autobuy orchestrator endpoints",
    )

    # ---------------------------------------------------------------------
    # PERFORMANCE / RISK (live-only)
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.endpoints.performance_endpoints",
        prefixes=(None,),  # exposes /api/performance/*
        display_name="performance analytics endpoints",
    )
    _include_if_available(
        "backend.endpoints.risk_endpoints",
        prefixes=(None, "/api"),  # /risk/* and /api/risk/*
        display_name="risk endpoints",
    )

    # ---------------------------------------------------------------------

    # Dashboard API endpoints - REMOVED (dashboard cleanup)

    # ---------------------------------------------------------------------
    # WEBSOCKET (real-time)
    # ---------------------------------------------------------------------
    # Mount the comprehensive WebSocket routes (routes/websocket.py)
    _include_if_available(
        "backend.routes.websocket",
        prefixes=(None,),
        display_name="WebSocket routes (comprehensive)",
    )

    # Note: websocket_endpoints.py is not mounted to avoid conflicts

    # ---------------------------------------------------------------------
    # LIVE DATA & MARKET ROUTES
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.routes.live_data",
        prefixes=(None,),
        display_name="live data endpoints",
    )
    _include_if_available(
        "backend.routes.market_routes",
        prefixes=(None,),
        display_name="market routes",
    )

    # ---------------------------------------------------------------------
    # AI ROUTES (AI trading, predictions, evaluation, decision history)
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.routes.ai_trading",
        prefixes=(None,),
        display_name="AI trading endpoints",
    )

    # ---------------------------------------------------------------------
    # ALL INDICATORS (social, whale, patterns, news, learning)
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.endpoints.indicators_endpoints",
        prefixes=(None,),
        display_name="All indicators endpoints (124+)",
        critical=False,
    )

    # ---------------------------------------------------------------------
    # BINANCE REAL ACCOUNT (live balance, sync to paper)
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.endpoints.binance_endpoints",
        prefixes=(None,),
        display_name="Binance real account endpoints",
        critical=False,
    )

    # ---------------------------------------------------------------------
    # AUTOBUY CONTROL (start/stop/enable engine)
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.endpoints.autobuy_control_endpoints",
        prefixes=(None,),
        display_name="AutoBuy engine control",
        critical=False,
    )

    # ---------------------------------------------------------------------
    # STABLECOIN PARKING (USDT management, portfolio allocation)
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.endpoints.stablecoin_endpoints",
        prefixes=(None,),
        display_name="Stablecoin parking and allocation",
        critical=False,
    )
    _include_if_available(
        "backend.routes.ai_predictions",
        prefixes=(None,),
        display_name="AI predictions endpoints",
    )
    _include_if_available(
        "backend.routes.ai_eval",
        prefixes=(None,),
        display_name="AI evaluation endpoints",
    )
    _include_if_available(
        "backend.routes.ai_decision_history",
        prefixes=(None,),
        display_name="AI decision history endpoints",
    )

    # ---------------------------------------------------------------------
    # BOT ROUTES
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.routes.bot_routes",
        prefixes=(None,),
        display_name="bot control routes",
    )
    _include_if_available(
        "backend.routes.bot_management",
        prefixes=(None,),
        display_name="bot management routes",
    )

    # ---------------------------------------------------------------------
    # MOBILE & NOTIFICATIONS
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.routes.mobile",
        prefixes=(None,),
        display_name="mobile/PWA routes",
    )
    _include_if_available(
        "backend.routes.notifications",
        prefixes=(None,),
        display_name="notification routes",
    )

    # ---------------------------------------------------------------------
    # SOCIAL / TRADING SIGNALS / ADVANCED SIGNALS
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.endpoints.social_trading_endpoints",
        prefixes=(None,),
        display_name="social trading endpoints",
    )
    _include_if_available(
        "backend.endpoints.trading_endpoints",
        prefixes=(None,),
        display_name="trading endpoints",
    )
    # Advanced signal endpoints - DISABLED (contains health endpoint)
    # _include_if_available(
    #     "backend.endpoints.advanced_signal_endpoints",
    #     prefixes=(None,),
    #     display_name="advanced signal endpoints",
    # )
    _include_if_available(
        "backend.endpoints.signals.whale_alerts_endpoints",
        prefixes=(None,),
        display_name="whale alerts endpoints",
    )

    # ---------------------------------------------------------------------
    # OBSERVABILITY / METRICS
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.observability.metrics",
        attr="metrics_router",
        prefixes=(None, "/api"),
        display_name="observability metrics endpoints",
    )

    # ---------------------------------------------------------------------
    # SECURITY / HEALTH
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.endpoints.security_endpoints",
        prefixes=("/security",),  # already namespaced; avoid double-mounting at /
        display_name="security endpoints",
    )
    # Health routes removed - use /healthz, /health/ready, /performance from app_factory.py only
    # _include_if_available(
    #     "backend.routes.health_routes",
    #     prefixes=(None, "/api"),
    #     display_name="health routes",
    # )
    # _include_if_available(
    #     "backend.endpoints.system_health_endpoints",
    #     prefixes=(None, "/api"),
    #     display_name="system health endpoints",
    # )

    # ---------------------------------------------------------------------
    # EXPORTS
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.endpoints.export_endpoints",
        prefixes=(None,),
        display_name="export endpoints",
    )

    # ---------------------------------------------------------------------
    # NEW DASHBOARD ENDPOINTS (missing files)
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.endpoints.autonomous_endpoints",
        prefixes=(None, "/api"),
        display_name="autonomous endpoints",
    )
    # Wallet endpoints - DELETED (wallet views removed from dashboard)

    # Metrics dashboard endpoints - DELETED (duplicate functionality)

    _include_if_available(
        "backend.endpoints.advanced_trading_endpoints",
        prefixes=(None,),
        critical=False,
        display_name="advanced trading endpoints",
    )

    # Strategy Generation Endpoints - OPPORTUNITY #13
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.endpoints.strategy.strategy_endpoints",
        prefixes=(None,),
        critical=False,
        display_name="strategy generation endpoints",
    )

    # Social trading endpoints - REMOVED: Already registered above (line 346)

    _include_if_available(
        "backend.endpoints.profit_maximization_endpoints",
        prefixes=(None,),
        critical=True,  # MUST load; fail fast if missing/errored
        display_name="profit maximization endpoints",
    )

    # ---------------------------------------------------------------------
    # PORTFOLIO ENGINE (Mystic Pro - disciplined trading)
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.endpoints.portfolio_engine_endpoints",
        prefixes=(None,),
        display_name="Portfolio Engine endpoints (Mystic Pro)",
        critical=False,
    )

    # ---------------------------------------------------------------------
    # LIVE TRADING READINESS
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.endpoints.live_readiness_endpoints",
        prefixes=(None,),
        display_name="Live Trading Readiness endpoints",
        critical=False,
    )

    # ---------------------------------------------------------------------
    # EXPERIMENTAL (optional)
    # ---------------------------------------------------------------------
    _include_if_available(
        "backend.endpoints.experimental_endpoints",
        prefixes=(None, "/api"),
        display_name="experimental endpoints",
    )
    _include_if_available(
        "backend.endpoints.experimental.advanced_tech_endpoints",
        prefixes=(None,),
        display_name="advanced tech endpoints",
    )

    # ---------------------------------------------------------------------
    # SHARED ENDPOINTS - DELETED
    # ---------------------------------------------------------------------
    # Shared endpoints (fake fallbacks) removed - all endpoints must be real
    # Fake data is dangerous in production - if an endpoint fails, we want to know!

    # ---------------------------------------------------------------------

    logger.info(f"[TARGET] CORE ENDPOINTS LOADED: {len(consolidated_router.routes)} working routes")


# load_all_endpoints() is now called from app_factory after canonical_cache initialization

# Export the router
router = consolidated_router
