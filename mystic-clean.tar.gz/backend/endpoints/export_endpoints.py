from __future__ import annotations

import csv
import io
from collections.abc import Iterable, Iterator, Mapping
from contextlib import contextmanager
from datetime import datetime
from typing import Any

from fastapi import APIRouter, HTTPException, Response

from backend.services.backtester import BacktestTrade
from backend.services.backtester import SessionLocal as BTSession
from backend.services.shadow_inference import SessionLocal as ShadowSession
from backend.services.shadow_inference import ShadowPnL
from backend.services.trade_store import FillRow, OrderRow
from backend.services.trade_store import SessionLocal as TradeSession

router = APIRouter(prefix="/export", tags=["Export"])

# -----------------------------
# Helpers
# -----------------------------


def _iso(ts: Any) -> str | None:
    try:
        if ts is None:
            return None
        if isinstance(ts, datetime):
            return ts.isoformat()
        # fallback: attempt to parse/repr
        return str(ts)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        return None


def _num(v: Any) -> Any:
    # normalize common numeric-ish values to float; leave None as None
    try:
        if v is None:
            return None
        # Decimal, numpy numbers, etc.
        return float(v)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        return v


def _union_keys(rows: Iterable[Mapping[str, Any]]) -> list[str]:
    keys: set[str] = set()
    for r in rows:
        try:
            keys.update(r.keys())
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            continue
    # keep a stable order: id-like first, then alphabetic
    priority = [
        "id",
        "ts",
        "timestamp",
        "client_order_id",
        "exchange_order_id",
        "trade_id",
        "symbol",
        "side",
    ]
    front = [k for k in priority if k in keys]
    rest = sorted(k for k in keys if k not in set(front))
    return front + rest


def _csv_response(rows: list[dict[str, Any]], filename: str) -> Response:
    # Build fieldnames from union of keys (handles heterogeneous rows)
    fieldnames = _union_keys(rows) if rows else []
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=fieldnames, extrasaction="ignore")
    writer.writeheader()
    for r in rows:
        try:
            writer.writerow({k: r.get(k, None) for k in fieldnames})
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            # Skip a malformed row rather than failing the whole export
            continue
    data = output.getvalue().encode("utf-8")
    headers = {
        "Content-Disposition": f'attachment; filename="{filename}"',
        "Content-Type": "text/csv; charset=utf-8",
    }
    return Response(content=data, headers=headers, media_type="text/csv")


@contextmanager
def _sess(session_factory) -> Iterator:
    """
    Helper context manager that works whether the session object returned by
    session_factory() is itself a context manager or a plain session requiring close().
    """
    s = session_factory()
    try:
        if hasattr(s, "__enter__") and hasattr(s, "__exit__"):
            # session is a context manager itself
            with s as inner:
                yield inner
        else:
            yield s
    finally:
        try:
            if not (hasattr(s, "__enter__") and hasattr(s, "__exit__")):
                # attempt to close plain session objects
                close = getattr(s, "close", None)
                if callable(close):
                    close()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            pass


# -----------------------------
# Endpoints
# -----------------------------


@router.get("/trades")
async def export_trades() -> Response:
    try:
        out: list[dict[str, Any]] = []
        with _sess(TradeSession) as s:
            orders = s.query(OrderRow).order_by(OrderRow.submitted_ts.asc()).all()
            for o in orders:
                try:
                    out.append(
                        {
                            "id": getattr(o, "id", None),
                            "client_order_id": getattr(o, "client_order_id", None),
                            "exchange_order_id": getattr(o, "exchange_order_id", None),
                            "exchange": getattr(o, "exchange", None),
                            "symbol": getattr(o, "symbol", None),
                            "side": getattr(o, "side", None),
                            "type": getattr(o, "order_type", None),
                            "amount": _num(getattr(o, "amount", None)),
                            "price": _num(getattr(o, "price", None)),
                            "status": getattr(o, "status", None),
                            "submitted_ts": _iso(getattr(o, "submitted_ts", None)),
                            "ack_ts": _iso(getattr(o, "ack_ts", None)),
                        },
                    )
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    continue
        return _csv_response(out, "orders.csv")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        raise HTTPException(status_code=500, detail=f"Failed to export trades: {e!s}") from e


@router.get("/fills")
async def export_fills() -> Response:
    try:
        out: list[dict[str, Any]] = []
        with _sess(TradeSession) as s:
            fills = s.query(FillRow).order_by(FillRow.ts.asc()).all()
            for f in fills:
                try:
                    out.append(
                        {
                            "id": getattr(f, "id", None),
                            "client_order_id": getattr(f, "client_order_id", None),
                            "exchange_order_id": getattr(f, "exchange_order_id", None),
                            "trade_id": getattr(f, "trade_id", None),
                            "exchange": getattr(f, "exchange", None),
                            "symbol": getattr(f, "symbol", None),
                            "side": getattr(f, "side", None),
                            "price": _num(getattr(f, "price", None)),
                            "qty": _num(getattr(f, "qty", None)),
                            "fee": _num(getattr(f, "fee", None)),
                            "fee_currency": getattr(f, "fee_currency", None),
                            "ts": _iso(getattr(f, "ts", None)),
                        },
                    )
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    continue
        return _csv_response(out, "fills.csv")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        raise HTTPException(status_code=500, detail=f"Failed to export fills: {e!s}") from e


@router.get("/shadow-pnl")
async def export_shadow_pnl() -> Response:
    try:
        out: list[dict[str, Any]] = []
        with _sess(ShadowSession) as s:
            rows = s.query(ShadowPnL).order_by(ShadowPnL.ts.asc()).all()
            for r in rows:
                try:
                    out.append(
                        {
                            "id": getattr(r, "id", None),
                            "model": getattr(r, "model_name", None),
                            "symbol": getattr(r, "symbol", None),
                            "pnl": _num(getattr(r, "pnl", None)),
                            "ts": _iso(getattr(r, "ts", None)),
                        },
                    )
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    continue
        return _csv_response(out, "shadow_pnl.csv")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        raise HTTPException(status_code=500, detail=f"Failed to export shadow pnl: {e!s}") from e


@router.get("/backtests/{run_id}")
async def export_backtest_trades(run_id: int) -> Response:
    try:
        out: list[dict[str, Any]] = []
        with _sess(BTSession) as s:
            rows = s.query(BacktestTrade).filter_by(run_id=int(run_id)).order_by(BacktestTrade.ts.asc()).all()
            for r in rows:
                try:
                    out.append(
                        {
                            "ts": _iso(getattr(r, "ts", None)),
                            "symbol": getattr(r, "symbol", None),
                            "side": getattr(r, "side", None),
                            "price": _num(getattr(r, "price", None)),
                            "size": _num(getattr(r, "size", None)),
                            "pnl": _num(getattr(r, "pnl", None)),
                        },
                    )
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    continue
        return _csv_response(out, f"backtest_{run_id}.csv")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        raise HTTPException(status_code=500, detail=f"Failed to export backtest: {e!s}") from e
