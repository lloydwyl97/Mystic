"""
Live Endpoints Module - All Live Data, No Mock Data

This module provides all endpoints with live data from real APIs.
All endpoints use live data sources - no mock data.

Rules additionally enforced:
- Binance.US Top-10 spot USD/USDT universe (when a Binance-style symbol is used)
- Binance.US request weight limit (1200 per minute best-effort, shared in-process)
"""

from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime, timezone
from typing import Any

import httpx
from fastapi import APIRouter, HTTPException

from backend.endpoints.ai.ai_strategy_endpoints import get_live_strategies
from backend.endpoints.ai.ai_strategy_endpoints import get_trading_signals as get_live_trading_signals
from backend.modules.ai.trade_tracker import get_orders, get_trade_history
from backend.modules.notifications.alert_manager import AlertManager
from backend.services.analytics_service import analytics_service
from backend.services.bot_manager import get_bots_status

# Direct imports for production
from backend.services.service_manager import service_manager

# get_ai_predictions not available - using ai_prediction_service instead
get_ai_predictions = None

# get_leaderboard not available - using social_trading_service instead
get_leaderboard = None

# SystemMonitor not available - using performance monitor instead
SystemMonitor = None

# portfolio manager removed
portfolio_manager = None

alert_manager = AlertManager()
system_monitor = None  # SystemMonitor not available

logger = logging.getLogger(__name__)
router = APIRouter()

# ============================================================================
# Shared helpers: Binance.US Top-10 universe + request-weight limiter
# ============================================================================


class _Top10Universe:
    """Discovers Top-10 Binance.US USD/USDT spot pairs by 24h quote volume."""

    def __init__(self) -> None:
        self._symbols: list[str] = []
        self._last_fetch: float = 0.0
        self._ttl_s: int = 300
        self._lock = asyncio.Lock()
        self._fallback = [
            "BTCUSDT",
            "ETHUSDT",
            "ADAUSDT",
            "SOLUSDT",
            "DOGEUSDT",
            "XRPUSDT",
            "BCHUSDT",
            "LTCUSDT",
            "AVAXUSDT",
            "LINKUSDT",
        ]

    @staticmethod
    def _is_usd_pair(sym: str) -> bool:
        return sym.endswith(("USDT", "USD"))

    async def _refresh(self) -> None:
        url = "https://api.binance.us/api/v3/ticker/24hr"
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                r = await client.get(url)
                r.raise_for_status()
                data: Any = r.json()

            vols: list[tuple[str, float]] = []
            if isinstance(data, list):
                for t in data:
                    try:
                        sym = str(t.get("symbol", ""))
                        if not self._is_usd_pair(sym):
                            continue
                        qv = float(t.get("quoteVolume") or t.get("q") or 0.0)
                        vols.append((sym, qv))
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        continue

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            self._symbols = list(self._fallback)
            self._last_fetch = time.time()
            logger.warning("Top-10 discovery failed, using fallback: %s", e)
            vols = []

        # Validate vols outside try to avoid TRY301
        if not vols:
            msg = "No USD/USDT tickers found"
            raise RuntimeError(msg)

        vols.sort(key=lambda kv: kv[1], reverse=True)
        self._symbols = [s for s, _ in vols[:10]]
        self._last_fetch = time.time()
        logger.info("Top-10 Binance.US refreshed: %s", self._symbols)

    async def get(self) -> list[str]:
        async with self._lock:
            if (time.time() - self._last_fetch) > self._ttl_s or not self._symbols:
                await self._refresh()
            return list(self._symbols)


_TOP10 = _Top10Universe()


class _WeightLimiter:
    """Best-effort in-process limiter to stay within Binance 1200 request-weight/min."""

    def __init__(self, cap_per_min: int = 1200) -> None:
        self.cap = cap_per_min
        self._lock = asyncio.Lock()
        self._window_start = time.monotonic()
        self._used = 0

    def _maybe_reset(self) -> None:
        if time.monotonic() - self._window_start >= 60.0:
            self._window_start = time.monotonic()
            self._used = 0

    @staticmethod
    def _weight_for(endpoint: str, **kwargs: Any) -> int:
        """
        Rough weights (heuristics) for common endpoints:
        - /api/v3/klines: scale by limit
        - /api/v3/ticker/price and /api/v3/ticker/bookTicker are light
        """
        if endpoint.endswith("/klines"):
            limit = int(kwargs.get("limit", 500))
            if limit <= 100:
                return 1
            if limit <= 500:
                return 5
            if limit <= 1000:
                return 10
            return 15
        # default lightweight
        return 1

    async def try_consume(self, endpoint: str, **kwargs: Any) -> bool:
        w = self._weight_for(endpoint, **kwargs)
        async with self._lock:
            self._maybe_reset()
            if self._used + w > self.cap:
                return False
            self._used += w
            return True

    async def usage(self) -> tuple[int, int]:
        async with self._lock:
            self._maybe_reset()
            return self._used, self.cap


_WEIGHT = _WeightLimiter()


def _normalize_to_binance_symbol(sym: str) -> str:
    """
    Accepts BTC/USDT, BTC-USDT, BTC_USDT, btcusdt, btc → BTCUSDT (default USDT if quote omitted).
    """
    s = (sym or "").strip().upper().replace("-", "").replace("_", "").replace("/", "")
    if s.endswith(("USDT", "USD")):
        return s
    # if the user gave a coin id like 'btc', assume USDT quote on Binance
    return f"{s}USDT"


def _looks_like_binance_pair(sym: str) -> bool:
    s = sym.strip().upper()
    # crude detection: contains a quote suffix or has a separator format
    return any(
        (
            s.endswith("USDT"),
            s.endswith("USD"),
            "/" in s,
            "-" in s,
            "_" in s,
        ),
    )


# ============================================================================
# LIVE MARKET DATA ENDPOINTS
# ============================================================================

# ============================================================================
# LIVE TRADING SIGNALS
# ============================================================================


@router.get("/api/live/trading/signals")
async def get_live_trading_signals_endpoint():
    """Get live trading signals from market data analysis (live)"""
    try:
        if get_live_trading_signals:
            signals = await get_live_trading_signals()
        elif analytics_service and hasattr(analytics_service, "get_trading_signals"):
            signals = await analytics_service.get_trading_signals()  # type: ignore[union-attr]
        else:
            raise HTTPException(status_code=503, detail="No live trading signals data source available.")
        return {
            "status": "success",
            "data": {
                "signals": signals,
                "total_signals": len(signals),
                "last_updated": datetime.now(timezone.utc).isoformat(),
                "source": "market_analysis",
            },
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting live trading signals: {e!s}")
        raise HTTPException(status_code=500, detail=f"Error getting signals: {e!s}") from e


# ============================================================================
# LIVE PORTFOLIO
# ============================================================================


@router.get("/api/live/portfolio/positions")
async def get_live_portfolio_positions():
    """Get live portfolio positions from exchange APIs (live)"""
    try:
        if portfolio_manager and hasattr(portfolio_manager, "get_live_portfolio_positions"):
            positions = await portfolio_manager.get_live_portfolio_positions()  # type: ignore[union-attr]
        elif portfolio_manager and hasattr(portfolio_manager, "get_live_portfolio_data"):
            data = await portfolio_manager.get_live_portfolio_data()  # type: ignore[union-attr]
            positions = data.get("positions", [])
        else:
            raise HTTPException(
                status_code=503,
                detail="No live portfolio positions data source available.",
            )
        return {
            "status": "success",
            "data": {
                "positions": positions,
                "total_positions": len(positions),
                "last_updated": datetime.now(timezone.utc).isoformat(),
                "source": "exchange_api",
            },
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting live portfolio positions: {e!s}")
        raise HTTPException(status_code=500, detail=f"Error getting positions: {e!s}") from e


@router.get("/api/live/portfolio/summary")
async def get_live_portfolio_summary():
    """Get live portfolio summary from exchange APIs (live)"""
    try:
        if portfolio_manager and hasattr(portfolio_manager, "get_portfolio_summary"):
            summary = await portfolio_manager.get_portfolio_summary()  # type: ignore[union-attr]
        elif portfolio_manager and hasattr(portfolio_manager, "get_live_portfolio_data"):
            summary = await portfolio_manager.get_live_portfolio_data()  # type: ignore[union-attr]
        else:
            raise HTTPException(
                status_code=503,
                detail="No live portfolio summary data source available.",
            )
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting live portfolio summary: {e!s}")
        raise HTTPException(status_code=500, detail=f"Error getting summary: {e!s}") from e
    else:
        return {"status": "success", "data": summary}


# ============================================================================
# LIVE AI PREDICTIONS
# ============================================================================


@router.get("/api/live/ai/predictions")
async def get_live_ai_predictions():
    """Get live AI predictions from market data analysis (live)"""
    try:
        if get_ai_predictions:
            predictions = await get_ai_predictions()
        elif analytics_service and hasattr(analytics_service, "get_ai_predictions"):
            predictions = await analytics_service.get_ai_predictions()  # type: ignore[union-attr]
        else:
            raise HTTPException(status_code=503, detail="No live AI predictions data source available.")
        return {
            "status": "success",
            "data": {
                "predictions": predictions,
                "total_predictions": len(predictions),
                "model_version": None,
            },
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting live AI predictions: {e!s}")
        raise HTTPException(status_code=500, detail=f"Error getting predictions: {e!s}") from e


# ============================================================================
# LIVE SOCIAL TRADING
# ============================================================================


@router.get("/api/live/social/leaderboard")
async def get_live_social_leaderboard():
    """Get live social trading leaderboard (live)"""
    try:
        if get_leaderboard:
            leaderboard = await get_leaderboard()
        else:
            raise HTTPException(
                status_code=503,
                detail="No live social leaderboard data source available.",
            )
        return {
            "status": "success",
            "data": {
                "leaderboard": leaderboard,
                "total_traders": len(leaderboard),
                "last_updated": datetime.now(timezone.utc).isoformat(),
                "source": "social_platforms",
            },
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting live social leaderboard: {e!s}")
        raise HTTPException(status_code=500, detail=f"Error getting leaderboard: {e!s}") from e


# ============================================================================
# LIVE BOT STATUS
# ============================================================================


@router.get("/api/live/bots/status")
async def get_live_bot_status():
    """Get live bot status and performance (live)"""
    try:
        if get_bots_status:
            bots = await get_bots_status()
        else:
            raise HTTPException(status_code=503, detail="No live bot status data source available.")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting live bot status: {e!s}")
        raise HTTPException(status_code=500, detail=f"Error getting bot status: {e!s}") from e
    else:
        return {"status": "success", "data": bots}


# ============================================================================
# LIVE ANALYTICS
# ============================================================================


@router.get("/api/live/analytics/performance")
async def get_live_analytics_performance():
    """Get live performance analytics (live)"""
    try:
        if analytics_service and hasattr(analytics_service, "get_performance_metrics"):
            performance_metrics = await analytics_service.get_performance_metrics()  # type: ignore[union-attr]
        else:
            raise HTTPException(
                status_code=503,
                detail="No live analytics performance data source available.",
            )
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting live analytics: {e!s}")
        raise HTTPException(status_code=500, detail=f"Error getting analytics: {e!s}") from e
    else:
        return {"status": "success", "data": performance_metrics}


# ============================================================================
# LIVE ORDERS & TRADE HISTORY
# ============================================================================


@router.get("/api/live/orders")
async def get_live_orders():
    """Get live orders from exchange APIs (live)"""
    try:
        if get_orders:
            orders = await get_orders()
        else:
            raise HTTPException(status_code=503, detail="No live orders data source available.")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting live orders: {e!s}")
        raise HTTPException(status_code=500, detail=f"Error getting orders: {e!s}") from e
    else:
        return {"status": "success", "data": orders}


@router.get("/api/live/trades/history")
async def get_live_trade_history():
    """Get live trade history from exchange APIs (live)"""
    try:
        if get_trade_history:
            trades = await get_trade_history()
        else:
            raise HTTPException(status_code=503, detail="No live trade history data source available.")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting live trade history: {e!s}")
        raise HTTPException(status_code=500, detail=f"Error getting trade history: {e!s}") from e
    else:
        return {"status": "success", "data": trades}


# ============================================================================
# LIVE STRATEGY ENGINE
# ============================================================================


@router.get("/api/live/strategies")
async def get_live_strategies_endpoint():
    """Get live strategy performance (live)"""
    try:
        if get_live_strategies:
            strategies = await get_live_strategies()
        else:
            raise HTTPException(status_code=503, detail="No live strategies data source available.")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting live strategies: {e!s}")
        raise HTTPException(status_code=500, detail=f"Error getting strategies: {e!s}") from e
    else:
        return {"status": "success", "data": strategies}


# ============================================================================
# SYSTEM STATUS & SOURCES
# ============================================================================


@router.get("/api/live/system/status")
async def get_live_system_status():
    """Get live system status and health (live)"""
    try:
        if system_monitor:
            status = await system_monitor.get_system_status()  # type: ignore[union-attr]
        else:
            raise HTTPException(status_code=503, detail="No live system status data source available.")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting live system status: {e!s}")
        raise HTTPException(status_code=500, detail=f"Error getting system status: {e!s}") from e
    else:
        return {"status": "success", "data": status}


@router.get("/api/live/sources")
async def get_live_data_sources():
    """Get available live data sources and their status (live)"""
    try:
        sources: list[dict[str, Any]] = []
        if service_manager:
            sources = await service_manager.get_data_source_status()  # type: ignore[attr-defined]
        elif system_monitor:
            sources = await system_monitor.get_data_source_status()  # type: ignore[union-attr]
        else:
            raise HTTPException(status_code=503, detail="No live data sources status available.")
        return {
            "status": "success",
            "data": {
                "sources": sources,
                "total_sources": len(sources),
                "active_sources": len([s for s in sources if s.get("status") == "active"]),
                "last_updated": datetime.now(timezone.utc).isoformat(),
            },
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting live data sources: {e!s}")
        raise HTTPException(status_code=500, detail=f"Error getting data sources: {e!s}") from e
