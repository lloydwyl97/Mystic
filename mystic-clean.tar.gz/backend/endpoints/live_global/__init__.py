"""
Live Global Endpoints Package
Contains live global market data endpoints
"""

from .live_global_endpoints import router

__all__ = ["router"]
