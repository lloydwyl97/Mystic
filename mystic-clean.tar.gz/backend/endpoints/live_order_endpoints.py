#!/usr/bin/env python3
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Body, Depends, Header, HTTPException

from backend.services import binance_signed as bs
from backend.services.admin_auth import require_admin_key

# Lazy import for optional security middleware (may not be available in all deployments)
try:
    from backend.security_enhancements import security_middleware
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    security_middleware = None  # type: ignore[assignment, misc]

router = APIRouter(prefix="/api/trading", tags=["live-orders"])

# Module-level dependencies to avoid function calls in default arguments
_body_required = Body(...)
_require_admin_dep = Depends(require_admin_key)


def _require_api_key(x_api_key: str | None = Header(None)) -> None:
    if not x_api_key:
        raise HTTPException(status_code=401, detail="Missing X-API-Key")


@router.post("/execute_live_market_buy")
async def execute_live_market_buy(payload: dict[str, Any] = _body_required, _: None = _require_admin_dep) -> dict[str, Any]:
    symbol = str(payload.get("symbol") or "").upper()
    quote_usd = float(payload.get("quote_usd") or 0)
    if not symbol or quote_usd <= 0:
        raise HTTPException(status_code=400, detail="symbol and positive quote_usd required")
    try:
        order = await bs.place_market_buy(symbol, quote_order_qty=quote_usd)
        _audit("live_market_buy", {"symbol": symbol, "quote_usd": quote_usd})
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        _audit(
            "live_market_buy_fail",
            {"symbol": symbol, "quote_usd": quote_usd, "error": str(e)},
            success=False,
        )
        raise HTTPException(status_code=502, detail=f"order failed: {e}") from e
    else:
        return {"status": "success", "order": order}


@router.post("/execute_live_market_sell")
async def execute_live_market_sell(payload: dict[str, Any] = _body_required, _: None = _require_admin_dep) -> dict[str, Any]:
    symbol = str(payload.get("symbol") or "").upper()
    quantity = float(payload.get("quantity") or 0)
    if not symbol or quantity <= 0:
        raise HTTPException(status_code=400, detail="symbol and positive quantity required")
    try:
        order = await bs.place_market_sell(symbol, quantity=quantity)
        _audit("live_market_sell", {"symbol": symbol, "quantity": quantity})
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        _audit(
            "live_market_sell_fail",
            {"symbol": symbol, "quantity": quantity, "error": str(e)},
            success=False,
        )
        raise HTTPException(status_code=502, detail=f"order failed: {e}") from e
    else:
        return {"status": "success", "order": order}


def _audit(event: str, details: dict[str, Any], success: bool = True) -> None:
    try:
        # security_middleware is optional; use if available
        if security_middleware is not None:
            security_middleware.audit_logger.log_event(
                event_type=event,
                user_id="api",
                ip_address="127.0.0.1",
                endpoint=f"/api/trading/{event}",
                method="POST",
                details=details,
                severity="high",
                status="success" if success else "failure",
            )
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        pass
