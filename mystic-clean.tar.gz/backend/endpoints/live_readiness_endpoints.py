"""
Live Trading Readiness Endpoints

Provides readiness checks and dry-run capabilities before enabling live trading.
Does NOT enable live trading - only provides pre-flight checks.
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from datetime import datetime, timezone
from typing import Any

from dotenv import load_dotenv
from fastapi import APIRouter

# Load .env file from project root
load_dotenv()

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/live", tags=["Live Trading"])


@router.get("/readiness")
async def get_live_readiness() -> dict[str, Any]:
    """
    Get live trading readiness checklist.

    Returns pass/fail for each requirement:
    - api_keys_present
    - exchange_time_sync_ok
    - symbol_filters_loaded
    - rounding_ok
    - reconciliation_ok
    - slippage_model_ok
    - dry_run_supported
    """
    checks = {}
    all_pass = True

    # Check 1: API keys present (check multiple env var names)
    api_key = os.getenv("BINANCE_US_API_KEY", "") or os.getenv("BINANCEUS_API_KEY", "")
    api_secret = os.getenv("BINANCE_US_SECRET_KEY", "") or os.getenv("BINANCE_US_API_SECRET", "") or os.getenv("BINANCEUS_API_SECRET", "")
    api_keys_ok = len(api_key) > 10 and len(api_secret) > 10
    checks["api_keys_present"] = {
        "pass": api_keys_ok,
        "detail": f"API keys configured (key: {api_key[:8]}...)" if api_keys_ok else "Missing Binance US API keys in environment",
    }
    if not api_keys_ok:
        all_pass = False

    # Check 2: Exchange time sync (Binance rejects signed requests if drift > ~1s)
    try:
        from backend.services.portfolio_engine import get_portfolio_engine

        engine = get_portfolio_engine()
        if engine._live_service and getattr(engine._live_service, "binance", None):
            exchange_ms = await asyncio.to_thread(engine._live_service.binance.fetch_time)
            local_ms = int(time.time() * 1000)
            drift_ms = abs(exchange_ms - local_ms)
            time_sync_ok = drift_ms < 5000  # 5s tolerance; Binance -1021 at ~1s
            engine.exchange_time_offset_ms = exchange_ms - local_ms
            if not time_sync_ok:
                all_pass = False
            checks["exchange_time_sync_ok"] = {
                "pass": time_sync_ok,
                "detail": f"Exchange vs local drift: {drift_ms}ms",
            }
        else:
            checks["exchange_time_sync_ok"] = {
                "pass": True,
                "detail": "Live service not initialized; skip exchange time check",
            }
    except Exception as e:
        checks["exchange_time_sync_ok"] = {
            "pass": False,
            "detail": f"Failed to check: {str(e)[:80]}",
        }
        all_pass = False

    # Check 3: Symbol filters loaded
    try:
        from backend.services.portfolio_engine import get_portfolio_engine

        engine = get_portfolio_engine()
        filters_loaded = len(engine._symbol_constraints) >= 10
        checks["symbol_filters_loaded"] = {
            "pass": filters_loaded,
            "detail": f"{len(engine._symbol_constraints)} symbols configured",
            "symbols": list(engine._symbol_constraints.keys()),
        }
        if not filters_loaded:
            all_pass = False
    except Exception as e:
        checks["symbol_filters_loaded"] = {
            "pass": False,
            "detail": f"Failed to load: {str(e)[:50]}",
        }
        all_pass = False

    # Check 4: Rounding OK (test calculation)
    try:
        from backend.services.portfolio_engine import get_portfolio_engine

        engine = get_portfolio_engine()
        test_qty, valid = engine._apply_exchange_constraints("BTC/USDT", 0.001234, 95000)
        rounding_ok = valid and test_qty > 0
        checks["rounding_ok"] = {
            "pass": rounding_ok,
            "detail": f"Test: 0.001234 BTC rounds to {test_qty:.8f}",
        }
        if not rounding_ok:
            all_pass = False
    except Exception as e:
        checks["rounding_ok"] = {
            "pass": False,
            "detail": f"Failed: {str(e)[:50]}",
        }
        all_pass = False

    # Check 5: Reconciliation OK (engine vs exchange)
    # In paper mode, just check engine ledger consistency
    try:
        from backend.services.portfolio_engine import get_portfolio_engine

        engine = get_portfolio_engine()
        invariants = engine.get_invariants_status()
        recon_ok = invariants["all_ok"]
        checks["reconciliation_ok"] = {
            "pass": recon_ok,
            "detail": "Engine invariants pass" if recon_ok else f"Violations: {invariants.get('total_violations', 'unknown')}",
        }
        if not recon_ok:
            all_pass = False
    except Exception as e:
        checks["reconciliation_ok"] = {
            "pass": False,
            "detail": f"Failed: {str(e)[:50]}",
        }
        all_pass = False

    # Check 6: Slippage model OK
    try:
        from backend.services.portfolio_engine import SLIPPAGE_PCT

        slippage_ok = 0 < SLIPPAGE_PCT < 0.01  # Between 0 and 1%
        checks["slippage_model_ok"] = {
            "pass": slippage_ok,
            "detail": f"Slippage estimate: {SLIPPAGE_PCT * 100:.3f}%",
        }
        if not slippage_ok:
            all_pass = False
    except Exception as e:
        checks["slippage_model_ok"] = {
            "pass": False,
            "detail": f"Failed: {str(e)[:50]}",
        }
        all_pass = False

    # Check 7: Dry run supported
    dry_run_ok = api_keys_ok  # Can only dry run if we have keys
    checks["dry_run_supported"] = {
        "pass": dry_run_ok,
        "detail": "Ready for dry run" if dry_run_ok else "Need API keys for dry run",
    }
    if not dry_run_ok:
        all_pass = False

    return {
        "success": True,
        "all_pass": all_pass,
        "checks": checks,
        "ready_for_live": all_pass,
        "mode": "PAPER",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@router.post("/dry-run")
async def execute_dry_run() -> dict[str, Any]:
    """
    Execute dry-run test (place then cancel order).

    Tests:
    - Order accepted by exchange
    - Min notional/step compliance
    - Rate limit status
    - Cancel success
    - Latency metrics

    NOTE: Requires API keys. Does NOT execute actual trades.
    """
    results = {
        "success": False,
        "tests": {},
        "errors": [],
    }

    # Check API keys first
    api_key = os.getenv("BINANCE_US_API_KEY", "")
    api_secret = os.getenv("BINANCE_US_API_SECRET", "")

    if not api_key or not api_secret or len(api_key) < 10:
        return {
            "success": False,
            "error": "API keys not configured. Cannot perform dry run.",
            "detail": "Set BINANCE_US_API_KEY and BINANCE_US_API_SECRET environment variables.",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    # For now, return a simulated dry-run result since we're in paper mode
    # In production, this would actually place/cancel a test order

    results["tests"]["api_connection"] = {
        "pass": True,
        "detail": "API keys present (actual connection test pending)",
        "latency_ms": 0,
    }

    results["tests"]["order_placement"] = {
        "pass": True,
        "detail": "Simulated - would test limit order placement",
        "symbol": "BTC/USDT",
        "test_qty": 0.0001,
        "test_price": 1.00,  # Far from market, would never fill
    }

    results["tests"]["order_cancel"] = {
        "pass": True,
        "detail": "Simulated - would cancel immediately after placement",
        "cancel_latency_ms": 0,
    }

    results["tests"]["rate_limit"] = {
        "pass": True,
        "detail": "Rate limits not checked in paper mode",
    }

    results["success"] = True
    results["mode"] = "PAPER_SIMULATION"
    results["note"] = "Dry run simulated in paper mode. Enable live mode to test actual exchange connection."
    results["timestamp"] = datetime.now(timezone.utc).isoformat()

    return results


@router.get("/status")
async def get_live_status() -> dict[str, Any]:
    """
    Get current live trading status.
    BUG #29 FIX: Read actual mode from environment/service instead of hardcoding
    """
    try:
        # Check environment variable for trading mode
        trading_mode = os.getenv("TRADING_MODE", "PAPER").upper()

        # Try to get actual service state
        live_enabled = False
        reason = "Live trading not yet enabled. Complete readiness checks first."

        try:
            from backend.services.live_trading_service import get_live_trading_service

            live_service = get_live_trading_service()
            if live_service and live_service.is_initialized:
                trading_mode = "LIVE"
                live_enabled = True
                reason = "Live trading enabled and active"
        except Exception:
            pass  # Fall back to env variable

        return {
            "success": True,
            "mode": trading_mode,
            "live_enabled": live_enabled,
            "reason": reason,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:
        logger.exception(f"Error getting status: {e}")
        return {
            "success": False,
            "mode": "UNKNOWN",
            "live_enabled": False,
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
