"""
Market Candles Endpoint
Provides OHLCV data in a normalized format for UI consumption (Binance.US only).
"""

from __future__ import annotations

import asyncio
import logging
import random
from typing import Any, TypedDict, cast

import httpx
from fastapi import APIRouter, Response

from backend.services.constants import _to_ccxt_symbol
from backend.utils.binance_weight_limiter import BinanceWeightLimiter

router = APIRouter(prefix="/api/market", tags=["market"])
logger = logging.getLogger(__name__)

# Module-level singletons for rate limiting
_candles_limiter: BinanceWeightLimiter | None = None
_candles_sem = asyncio.Semaphore(2)
_candles_client: httpx.AsyncClient | None = None
_candles_init_lock = asyncio.Lock()


class Candle(TypedDict):
    timestamp: int
    open_price: float
    high: float
    low: float
    close: float
    volume: float


async def _fetch_binanceus_klines(symbol: str, interval: str, limit: int) -> list[list[Any]]:
    global _candles_limiter, _candles_client

    # Binance.US expects MARKET=BASEQUOTE (no slash)
    sym_ccxt = _to_ccxt_symbol(symbol)
    base, quote = sym_ccxt.split("/", 1)
    market = f"{base}{quote}"

    url = "https://api.binance.us/api/v3/klines"
    params = {"symbol": market, "interval": interval, "limit": max(1, min(limit, 1000))}

    # Initialize limiter and client once
    async with _candles_init_lock:
        if _candles_limiter is None:
            _candles_limiter = await BinanceWeightLimiter.create()
        if _candles_client is None:
            _candles_client = httpx.AsyncClient(timeout=httpx.Timeout(10))

    # Rate limit with retries and backoff
    last_exc: Exception | None = None
    for attempt in range(3):
        try:
            await _candles_limiter.consume("/api/v3/klines", weight=1, wait=True, timeout=10.0)
            async with _candles_sem:
                response = await _candles_client.get(url, params=params)
                if response.status_code == 429:
                    retry_after = response.headers.get("Retry-After")
                    base_sleep = float(retry_after) if retry_after else (2.0**attempt)
                    await asyncio.sleep(base_sleep + random.random() * 0.5)
                    continue
                if response.status_code == 200:
                    data: Any = response.json()
                    if isinstance(data, list):
                        return cast("list[list[Any]]", data)
                else:
                    body = response.text
                    logger.warning("BinanceUS klines HTTP %s: %s", response.status_code, body[:200])
                    if response.status_code >= 500:
                        await asyncio.sleep(min(8.0, (2.0**attempt)) + random.random() * 0.5)
                        continue
                    break
        except Exception as e:
            last_exc = e
            await asyncio.sleep(min(8.0, (2.0**attempt)) + random.random() * 0.5)
            continue

    if last_exc:
        logger.warning("Error fetching BinanceUS klines for %s: %s", sym_ccxt, last_exc)
    return []


def _map_klines_to_ohlcv(items: list[list[Any]]) -> list[Candle]:
    out: list[Candle] = []
    for k in items:
        try:
            # [ openTime, open, high, low, close, volume, closeTime, ... ]
            out.append(
                {
                    "timestamp": int(k[0]),
                    "open": float(k[1]),
                    "high": float(k[2]),
                    "low": float(k[3]),
                    "close": float(k[4]),
                    "volume": float(k[5]),
                },
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            continue
    return out


@router.get("/candles")
async def get_candles(symbol: str, response: Response, interval: str = "1h", limit: int = 200) -> list[Candle]:
    """
    Return normalized OHLCV list for a symbol. Always 200 with a list (possibly empty).
    """
    try:
        allowed = {"1m", "5m", "15m", "1h", "4h", "1d"}
        if interval not in allowed:
            interval = "1h"
        response.headers["Cache-Control"] = "public, max-age=15"

        klines = await _fetch_binanceus_klines(symbol=symbol, interval=interval, limit=limit)
        if not klines:
            return []
        return _map_klines_to_ohlcv(klines)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.warning("/api/market/candles error for %s: %s", symbol, e)
        return []
