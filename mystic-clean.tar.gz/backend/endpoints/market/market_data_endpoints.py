"""
Market Data Endpoints
Consolidated market data, live prices, and market analysis
All endpoints return live data from live_market_data_service and canonical_cache
No simulated or stub data
"""

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any, Protocol, TypedDict, cast, runtime_checkable

from fastapi import APIRouter, HTTPException, Query, Response

from backend.ai_training_pipeline import get_ai_training_pipeline

# Move all imports to top-level
from backend.config.binance_allowlist import AllowlistGuard
from backend.config.settings import settings

# from backend.services.binanceus_top10_fetcher import Top10DataService  # Lazy import
# canonical_cache imported lazily in functions to avoid import-time issues
from backend.services.live_market_data import live_market_data_service

# Initialize logger first
from backend.services.market_data import MarketDataService
from backend.utils.cache_guard import CacheGuard

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID, TRADING_SYMBOLS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

logger = logging.getLogger(__name__)

logger.info("Live market data service imported successfully")
router = APIRouter()

# No static fallbacks allowed - all data must be live


@runtime_checkable
class MarketDataServiceProtocol(Protocol):
    async def get_live_data(self) -> dict[str, Any]: ...

    async def get_market_trends(self) -> dict[str, Any]: ...

    async def get_prices(self, symbols: list[str]) -> dict[str, Any]: ...

    async def get_price_history(self, symbols: list[str]) -> dict[str, Any]: ...

    async def get_technical_analysis(self) -> dict[str, Any]: ...

    async def get_market_sentiment(self) -> dict[str, Any]: ...

    async def get_volume_data(self) -> dict[str, Any]: ...

    async def get_volume_trends(self) -> dict[str, Any]: ...

    async def get_market_cap_data(self) -> dict[str, Any]: ...

    async def get_top_movers(self) -> dict[str, Any]: ...

    async def get_exchange_data(self) -> dict[str, Any]: ...

    async def get_trading_pairs(self) -> dict[str, Any]: ...


class PriceEntry(TypedDict, total=False):
    price: float
    exchange: str
    bid: float
    ask: float
    timestamp: str
    volume_24h: float
    change_24h: float


# Initialize real services
try:
    market_data_service: MarketDataServiceProtocol = MarketDataService.shared()  # type: ignore[assignment]
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
    logger.warning(f"Could not initialize some market data services: {e}")


async def _fetch_json(session: Any, url: str, timeout: int = 10) -> dict[str, Any] | None:
    try:
        async with session.get(url, timeout=timeout) as resp:
            if resp.status == 200:
                return await resp.json()
            return None
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        return None


def _to_binanceus_symbol(symbol_dash: str) -> str:
    # BTC-USD -> BTCUSDT, ETH-USD -> ETHUSDT, ADA-USD -> ADAUSDT, etc.
    base, quote = symbol_dash.split("-")
    if quote.upper() == "USD":
        quote = "USDT"
    return f"{base.upper()}{quote.upper()}"


async def _fetch_symbol_prices_from_exchanges(_session: Any, symbols_dash: list[str]) -> dict[str, PriceEntry]:
    """Fetch prices from Binance US cache only - no external API calls"""
    results: dict[str, PriceEntry] = {}

    for symbol_dash in symbols_dash:
        symbol_entry: PriceEntry = {}

        # Binance US (cache-only) - ONLY source
        try:
            cg = await CacheGuard.create()
            bsym = _to_binanceus_symbol(symbol_dash)
            price_cached = await cg.get_price_cached(bsym)
            if price_cached is not None:
                symbol_entry = {
                    "price": price_cached,
                    "exchange": EXCHANGE_ID,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            pass

        # Ensure we always have some data for each symbol
        if symbol_entry:
            results[symbol_dash] = symbol_entry
        else:
            # Skip symbols that failed to fetch - no fallback data
            logger.warning(f"Failed to fetch price for {symbol_dash} from Binance US")
            continue

    return results


@router.get("/api/market/live")
async def get_market_live() -> dict[str, Any]:
    """Get live market data - full Binance.US universe (cache-only)."""
    try:
        # Lazy import canonical_cache to avoid import-time issues
        from backend.services.canonical_cache import canonical_cache

        # Initialize cache if not already initialized
        if not getattr(canonical_cache, "redis_client", None):
            await canonical_cache.initialize()
            logger.info("Initialized canonical_cache for market/live endpoint")

        # Ensure cache is warmed up
        try:
            await canonical_cache.warm_cache()
            logger.info("Warmed up canonical_cache for market/live endpoint")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as warm_error:
            logger.warning(f"Cache warming failed but continuing: {warm_error}")

        # Get data from binanceus_top10_fetcher - this is our real data source
        backup_data = None
        try:
            from backend.services.binanceus_top10_fetcher import Top10DataService

            backup_data = await Top10DataService().get_top10_24h()
            logger.info(f"Loaded live data with {len(backup_data) if backup_data else 0} symbols")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as backup_error:
            logger.warning(f"Failed to load live data: {backup_error}")
            backup_data = []

        # Only process symbols that have real data
        rows: list[dict[str, Any]] = []

        # Process each symbol with real data
        for item in backup_data:
            try:
                sym = item["symbol"]
                price = float(item["lastPrice"])
                change_24h = float(item["priceChangePercent"])
                volume_24h = float(item["volume"])
                high_24h = float(item["highPrice"])
                low_24h = float(item["lowPrice"])

                rows.append(
                    {
                        "symbol": sym,
                        "price": price,
                        "change_24h": change_24h,
                        "volume_24h": volume_24h,
                        "high_24h": high_24h,
                        "low_24h": low_24h,
                    }
                )
                logger.info(f"Added data for {sym} with price {price}")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception(f"Error processing symbol {item.get('symbol', 'unknown')}")
                continue

        # Log the result
        result_count = len(rows)
        logger.info(f"Returning {result_count} symbols for market/live endpoint")

        if result_count == 0:
            logger.warning("No market data available from any source")

        return {
            "symbols": rows,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": "canonical_cache" if result_count > 0 else "error",
            "count": result_count,
        }

    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Error in get_market_live")
        return {
            "symbols": [],
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": "error",
            "count": 0,
            "error": str(e),
        }


@router.get("/market/prices")
async def get_market_prices(symbols: str | None = None) -> dict[str, Any]:
    """Get current market prices - BINANCE-US ALLOWLIST ONLY, CACHE-ONLY READS"""
    try:
        # Parse and validate symbols against allowlist
        symbol_list = []
        if symbols:
            symbol_list = [s.strip().upper() for s in symbols.split(",")]

        # Enforce allowlist - reject non-allowed symbols
        valid_symbols, status = AllowlistGuard.filter_request_symbols(symbol_list)

        # Lazy import canonical_cache to avoid import-time issues
        from backend.services.canonical_cache import canonical_cache

        # Use canonical_cache for prices
        cache = canonical_cache
        prices_data = {}

        # Get prices for valid symbols
        for symbol in valid_symbols:
            try:
                price = await cache.get_latest_price(EXCHANGE_ID, symbol)
                if price:
                    prices_data[symbol] = float(price)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.warning(f"Failed to get price for {symbol}: {e}")

        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "prices": prices_data,
            "price_history": {},  # Not implemented in cache-only mode
            "symbols": valid_symbols,
            "status": status,
            "allowlist_enforced": True,
            "cache_only": True,
            "requested_symbols": symbol_list,
            "hydrated_count": len(prices_data),
            "version": "2.0.0",
        }

    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Market prices error")
        return {
            "error": "Market prices failed",
            "reason": str(e),
            "allowlist_enforced": True,
            "cache_only": True,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "prices": {},
            "symbols": [],
            "hydrated_count": 0,
        }


@router.get("/market/trends")
async def get_market_trends() -> dict[str, Any]:
    """Get market trends and analysis"""
    try:
        # Get real market trends
        trends = {}
        try:
            if market_data_service:
                trends = await market_data_service.get_market_trends()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error getting market trends")
            trends = {"error": "Market trends unavailable"}

        # Get technical analysis
        technical_analysis = {}
        try:
            if market_data_service:
                technical_analysis = await market_data_service.get_technical_analysis()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error getting technical analysis")
            technical_analysis = {"error": "Technical analysis unavailable"}

        # Get market sentiment
        sentiment = {}
        try:
            if market_data_service:
                sentiment = await market_data_service.get_market_sentiment()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error getting market sentiment")
            sentiment = {"error": "Market sentiment unavailable"}

        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "trends": trends,
            "technical_analysis": technical_analysis,
            "sentiment": sentiment,
            "version": "1.0.0",
        }

    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Error getting market trends")
        raise HTTPException(status_code=500, detail=f"Market trends failed: {e!s}") from e


@router.get("/market/volume")
async def get_market_volume() -> dict[str, Any]:
    """Get market volume data"""
    try:
        # Get real volume data from cache
        volume_data = {}
        volume_trends = {}

        try:
            # Lazy import canonical_cache to avoid import-time issues
            from backend.services.canonical_cache import canonical_cache

            cache = canonical_cache

            # Get volume data for top 10 coins - USE CENTRALIZED CONFIG
            symbols = settings.trading_symbols

            for symbol in symbols:
                try:
                    ticker = await cache.get_latest_ticker_24h(EXCHANGE_ID, symbol)
                    if ticker and isinstance(ticker, dict):
                        volume = ticker.get("volume", 0)
                        if volume > 0:
                            volume_data[symbol] = volume
                            volume_trends[symbol] = {
                                "value": volume,
                                "change_24h": ticker.get("priceChangePercent", 0),
                                "timestamp": datetime.now(timezone.utc).isoformat(),
                            }
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.debug(f"Failed to get volume for {symbol}: {e}")
                    continue

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.warning(f"Error getting volume data from cache: {e}")
            # No fallback data - return empty volume data

        # Create profile array for charts
        profile = []
        for symbol, data in volume_data.items():
            if isinstance(data, dict) and "volume_24h" in data:
                profile.append(
                    {
                        "bucket": symbol,
                        "label": symbol,
                        "volume": float(data.get("volume_24h", 0)),
                    }
                )

        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "volume_data": volume_data,
            "volume_trends": volume_trends,
            "profile": profile,  # Chart data structure
            "version": "1.0.0",
        }

    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Error getting market volume")
        # Return empty data with proper structure for charts
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "volume_data": {},
            "volume_trends": {},
            "profile": [],  # Chart expects this array
            "version": "1.0.0",
            "error": str(e),
        }


@router.get("/market/exchanges")
async def get_exchange_data() -> dict[str, Any]:
    """Get exchange data and trading pairs"""
    try:
        # Get real exchange data
        exchange_data = {}
        try:
            if market_data_service:
                exchange_data = await market_data_service.get_exchange_data()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error getting exchange data")
            exchange_data = {"error": "Exchange data unavailable"}

        # Get trading pairs
        trading_pairs = {}
        try:
            if market_data_service:
                trading_pairs = await market_data_service.get_trading_pairs()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error getting trading pairs")
            trading_pairs = {"error": "Trading pairs unavailable"}

        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "exchanges": exchange_data,
            "trading_pairs": trading_pairs,
            "version": "1.0.0",
        }

    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Error getting exchange data")
        raise HTTPException(status_code=500, detail=f"Exchange data failed: {e!s}") from e


# =============================
# Tier-2 Market Microstructure
# =============================


def _to_pair(symbol: str) -> str:
    s = (symbol or "").strip().upper()
    # Accept BTC, BTCUSDT, BTC-USD, BTC/USDT → BTC/USDT
    if "/" in s:
        base, quote = s.split("/", 1)
        quote = "USDT" if quote in {"USD", "USDT"} else quote
        return f"{base}/{quote}"
    if "-" in s:
        base, quote = s.split("-", 1)
        quote = "USDT" if quote == "USD" else quote
        return f"{base}/{quote}"
    if s.endswith("USDT"):
        return f"{s[:-4]}/USDT"
    if s.endswith("USD"):
        return f"{s[:-3]}/USDT"
    return f"{s}/USDT"


@router.get("/market/trades")
async def get_market_trades(
    _response: Response,
    symbol: str = Query(default=TRADING_SYMBOLS[0] if TRADING_SYMBOLS else "", description="Symbol, e.g. BTC, BTCUSDT, BTC-USD"),
    _limit: int = Query(200, ge=1, le=1000, description="Number of recent trades"),
) -> dict[str, Any]:
    """Recent trade prints with price, qty, side and ts. Uses exchange live data."""
    try:
        # Get recent trades from cache
        pair = _to_pair(symbol)
        if not pair or "/" not in pair:
            raise HTTPException(status_code=400, detail="Invalid symbol format")

        # Live trades data from cache - no mock data
        try:
            # Lazy import canonical_cache to avoid import-time issues
            from backend.services.canonical_cache import canonical_cache

            cache = canonical_cache

            # Get live trade data from cache
            trades_data = cache.get_market_data("trades")
            # If no cached trades, return empty instead of mock
            result = {"trades": trades_data[symbol]} if trades_data and symbol in trades_data else {"trades": [], "message": "No live trade data available"}
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            return {"trades": [], "error": str(e)}
        else:
            return result
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("trades error")
        raise HTTPException(status_code=500, detail="Failed to fetch trades") from e


@router.get("/market/orderbook")
async def get_market_orderbook(
    response: Response,
    symbol: str = Query(default=TRADING_SYMBOLS[0] if TRADING_SYMBOLS else "", description="Symbol, e.g. BTC, BTCUSDT, BTC-USD"),
    depth: int = Query(50, ge=1, le=500, description="Order book depth"),
) -> dict[str, Any]:
    """L2 orderbook snapshot with timestamps."""
    try:
        pair = _to_pair(symbol)
        if not pair or "/" not in pair:
            raise HTTPException(status_code=400, detail="Invalid symbol format")

        if not live_market_data_service:
            raise HTTPException(status_code=503, detail="Live market data service not available")

        ob = await live_market_data_service.get_order_book(pair, limit=depth)
        response.headers["Cache-Control"] = "public, max-age=1, stale-while-revalidate=5"
        return {
            "symbol": pair,
            "bids": ob.get("bids", []),
            "asks": ob.get("asks", []),
            "server_ts": datetime.now(timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Orderbook error for {symbol}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch orderbook: {e!s}") from e


# NOTE: /autobuy/stats endpoint moved to auto_trading router to avoid duplicates


@router.get("/technical/indicators")
async def get_technical_indicators(
    symbol: str = Query(default=TRADING_SYMBOLS[0] if TRADING_SYMBOLS else "", description="Symbol, e.g. BTC, BTCUSDT, BTC-USD"),
    interval: str = Query("1h", description="Interval: 1m,5m,15m,30m,1h,4h,1d,1w,1M"),
    limit: int = Query(100, ge=1, le=1000, description="Number of data points"),
) -> dict[str, Any]:
    """Get technical indicators for a symbol"""
    try:
        pair = _to_pair(symbol)
        if not pair or "/" not in pair:
            return {"error": "Invalid symbol format", "indicators": {}}

        # Use canonical_cache for technical data
        try:
            # Lazy import canonical_cache to avoid import-time issues
            from backend.services.canonical_cache import canonical_cache

            cache = canonical_cache

            # Get price history for calculations (async method)
            price_history = await cache.get_price_history(EXCHANGE_ID, pair, limit=limit)

            # Calculate basic technical indicators
            indicators = {}
            if price_history and isinstance(price_history, list) and len(price_history) > 0:
                # Extract prices from history data (can be dict with 'price' key or direct values)
                prices = []
                for p in price_history:
                    if isinstance(p, dict):
                        # Extract from dict (e.g., {'price': 90000, 'timestamp': ...})
                        price_val = p.get("price") or p.get("close") or p.get("value")
                        if price_val and float(price_val) > 0:
                            prices.append(float(price_val))
                    elif isinstance(p, (int, float)) and p > 0:
                        # Direct numeric value
                        prices.append(float(p))

                if len(prices) >= 14:  # Minimum for RSI calculation
                    # Simple Moving Averages
                    sma_20 = sum(prices[-20:]) / min(20, len(prices))
                    sma_50 = sum(prices[-50:]) / min(50, len(prices))

                    # RSI calculation (simplified)
                    gains = []
                    losses = []
                    for i in range(1, min(14, len(prices))):
                        change = prices[i] - prices[i - 1]
                        if change > 0:
                            gains.append(change)
                        else:
                            losses.append(abs(change))

                    avg_gain = sum(gains) / len(gains) if gains else 0
                    avg_loss = sum(losses) / len(losses) if losses else 0
                    rs = avg_gain / avg_loss if avg_loss > 0 else 0
                    rsi = 100 - (100 / (1 + rs))

                    indicators = {
                        "sma_20": round(sma_20, 2),
                        "sma_50": round(sma_50, 2),
                        "rsi": round(rsi, 2),
                        "current_price": prices[-1],
                        "price_change_24h": round(((prices[-1] - prices[0]) / prices[0]) * 100, 2) if len(prices) > 1 else 0,
                        "volatility": round((max(prices) - min(prices)) / min(prices) * 100, 2) if prices else 0,
                    }
                else:
                    indicators = {
                        "current_price": prices[-1] if prices else 0,
                        "error": "Insufficient data for technical indicators",
                    }
            else:
                indicators = {"error": "No price data available"}

            return {
                "symbol": pair,
                "interval": interval,
                "indicators": indicators,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "source": "cache",
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as cache_error:
            logger.warning(f"Cache-based technical indicators failed: {cache_error}")
            return {
                "error": f"Failed to get technical indicators: {cache_error}",
                "indicators": {},
            }

    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Technical indicators error")
        return {"error": f"Failed to get technical indicators: {e}", "indicators": {}}


@router.get("/ai/training/status")
async def get_ai_training_status():
    """Get AI training pipeline status"""
    try:
        # Lazy import canonical_cache to avoid import-time issues
        from backend.services.canonical_cache import canonical_cache

        pipeline = get_ai_training_pipeline(canonical_cache)
        if pipeline:
            status = pipeline.get_training_status()
            return {
                "status": "success",
                "data": status,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "source": "ai_training_pipeline",
            }
        return {
            "status": "error",
            "data": {},
            "error": "AI training pipeline not available",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("AI training status error")
        return {
            "status": "error",
            "data": {},
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }


@router.get("/market/top10")
async def get_market_top10() -> list[dict[str, Any]]:
    """Alias for /coins/top10 - return exactly the Binance-US-10 allowlist."""
    return await get_coins_top10()


@router.get("/market/data")
async def get_market_data_endpoint() -> dict[str, Any]:
    """Get comprehensive market data for all top 10 coins."""
    try:
        # Use the working top10 service instead of cache
        from backend.services.binanceus_top10_fetcher import Top10DataService

        top10_service = Top10DataService()
        top10_data = await top10_service.get_comprehensive_data()

        if top10_data and "symbols" in top10_data and "prices" in top10_data:
            symbols_data = []
            total_volume = 0

            for symbol_ccxt in top10_data["symbols"]:
                # Convert CCXT format (BTC/USDT) to exchange format (BTCUSDT)
                symbol_exchange = symbol_ccxt.replace("/", "")

                # Get price from prices data
                price = top10_data["prices"].get(symbol_ccxt, 0)

                # Get 24h stats
                stats = top10_data.get("stats", [])
                symbol_stats = None
                for stat in stats:
                    if stat.get("symbol") == symbol_exchange:
                        symbol_stats = stat
                        break

                if price > 0:
                    symbols_data.append(
                        {
                            "symbol": symbol_exchange,
                            "price": price,
                            "volume_24h": symbol_stats.get("volume", 0) if symbol_stats else 0,
                            "change_24h": symbol_stats.get("priceChangePercent", 0) if symbol_stats else 0,
                            "high_24h": symbol_stats.get("highPrice", 0) if symbol_stats else 0,
                            "low_24h": symbol_stats.get("lowPrice", 0) if symbol_stats else 0,
                            "timestamp": top10_data.get("timestamp", datetime.now(timezone.utc).isoformat()),
                        },
                    )
                    total_volume += float(symbol_stats.get("volume", 0)) if symbol_stats else 0

            return {
                "symbols": symbols_data,
                "summary": {
                    "total_symbols": len(top10_data["symbols"]),
                    "active_symbols": len(symbols_data),
                    "total_volume_24h": total_volume,
                    "timestamp": top10_data.get("timestamp", datetime.now(timezone.utc).isoformat()),
                },
            }
        logger.warning("Top10 service returned empty data")
        return {
            "symbols": [],
            "summary": {
                "total_symbols": 10,
                "active_symbols": 0,
                "total_volume_24h": None,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "error": "No data from top10 service",
            },
        }

    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Error in get_market_data_endpoint")
        return {
            "symbols": [],
            "summary": {
                "total_symbols": 0,
                "active_symbols": 0,
                "total_volume_24h": None,
                "error": str(e),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        }


@router.get("/market/ticker/{symbol}")
async def get_ticker(symbol: str) -> dict[str, Any]:
    """Get ticker data for a specific symbol."""
    try:
        # Use the working top10 service
        from backend.services.binanceus_top10_fetcher import Top10DataService

        top10_service = Top10DataService()
        top10_data = await top10_service.get_comprehensive_data()
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting ticker for {symbol}")
        raise HTTPException(status_code=500, detail=f"Error getting ticker data: {e}") from e

    # Process top10_data outside try to avoid TRY301
    if top10_data and "stats" in top10_data:
        # Look for the symbol in stats
        symbol_upper = symbol.upper()
        for stat in top10_data["stats"]:
            if stat.get("symbol", "").upper() == symbol_upper:
                return {
                    "symbol": stat.get("symbol"),
                    "price": stat.get("lastPrice", 0),
                    "volume_24h": stat.get("volume", 0),
                    "change_24h": stat.get("priceChangePercent", 0),
                    "high_24h": stat.get("highPrice", 0),
                    "low_24h": stat.get("lowPrice", 0),
                    "timestamp": top10_data.get("timestamp", datetime.now(timezone.utc).isoformat()),
                }

        # If not found in stats, try to get from prices
        if "prices" in top10_data:
            symbol_ccxt = f"{symbol_upper.removesuffix('USDT')}/USDT"
            price = top10_data["prices"].get(symbol_ccxt, 0)
            if price > 0:
                return {
                    "symbol": symbol_upper,
                    "price": price,
                    "volume_24h": 0,
                    "change_24h": 0,
                    "high_24h": 0,
                    "low_24h": 0,
                    "timestamp": top10_data.get("timestamp", datetime.now(timezone.utc).isoformat()),
                }

    # Validate symbol not found outside try to avoid TRY301
    raise HTTPException(status_code=404, detail=f"Symbol {symbol} not found")


@router.get("/coins/top10")
async def get_coins_top10() -> list[dict[str, Any]]:
    """Return exactly the Binance-US-10 allowlist - with live data from service."""
    try:
        # Lazy import canonical_cache to avoid import-time issues
        from backend.services.canonical_cache import canonical_cache

        # USE CENTRALIZED CONFIG ONLY
        TOP_10_COINS = settings.trading_symbols

        live_coins = []

        # Try to get live market data service
        try:
            market_service_available = live_market_data_service is not None
            logger.info(f"Market service available: {market_service_available}")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            market_service_available = False
            logger.exception("Market service import failed")

        # Get cached data from binanceus_top10_fetcher (faster than individual API calls)
        cached_data = {}
        try:
            # Try to get the cached top10 data that's already being refreshed
            top10_cache_data = await canonical_cache.get_market_data("top10_data")
            if top10_cache_data and "data" in top10_cache_data:
                cache_content = top10_cache_data["data"]
                # The data is stored as {"prices": {...}, "stats": [...]}
                if "prices" in cache_content:
                    cached_data = cache_content["prices"]
                    logger.info(f"Using cached top10 prices with {len(cached_data)} symbols")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.debug(f"Could not get cached data: {e}")

        # Get all ticker data concurrently for speed
        ticker_tasks = []
        if market_service_available:
            for symbol in TOP_10_COINS:
                base_symbol = symbol.replace("USDT", "")
                ccxt_symbol = f"{base_symbol}/USDT"
                ticker_tasks.append(live_market_data_service.get_ticker(ccxt_symbol))

        # Wait for all ticker data concurrently
        ticker_results = []
        if ticker_tasks:
            ticker_results = await asyncio.gather(*ticker_tasks, return_exceptions=True)

        # Always return all 10 symbols from allowlist
        for i, symbol in enumerate(TOP_10_COINS):
            try:
                # Convert to display format
                base_symbol = symbol.replace("USDT", "")
                display_symbol = f"{base_symbol}-USD"

                # Get live data from concurrent results
                price = None
                volume_24h = None
                change_24h = None
                high_24h = None
                low_24h = None
                is_live = False

                if i < len(ticker_results) and ticker_results[i] and not isinstance(ticker_results[i], Exception):
                    ticker_data = ticker_results[i]
                    price = float(ticker_data.get("price", 0))
                    volume_24h = float(ticker_data.get("volume_24h", 0))
                    change_24h = float(ticker_data.get("change_24h", 0))
                    high_24h = float(ticker_data.get("high", 0))
                    low_24h = float(ticker_data.get("low", 0))
                    is_live = True

                # ALLOWLIST ENFORCED - return coin data
                live_coins.append(
                    {
                        "id": symbol.lower(),
                        "symbol": display_symbol,
                        "name": base_symbol,
                        "price": price,
                        "volume_24h": volume_24h,
                        "change_24h": change_24h,
                        "high_24h": high_24h,
                        "low_24h": low_24h,
                        "market_cap": None,
                        "logo_url": f"https://cryptologos.cc/logos/{base_symbol.lower()}-logo.png",
                        "exchange": EXCHANGE_ID,
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "live": is_live,
                        "allowlist_enforced": True,
                    },
                )
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                # Include symbol with error state - maintain stable 10-item list
                base_symbol = symbol.replace("USDT", "")
                live_coins.append(
                    {
                        "id": symbol.lower(),
                        "symbol": f"{base_symbol}-USD",
                        "name": base_symbol,
                        "price": None,
                        "volume_24h": None,
                        "change_24h": None,
                        "high_24h": None,
                        "low_24h": None,
                        "market_cap": None,
                        "logo_url": f"https://cryptologos.cc/logos/{base_symbol.lower()}-logo.png",
                        "exchange": EXCHANGE_ID,
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "live": False,
                        "error": str(e),
                        "allowlist_enforced": True,
                    },
                )
                logger.debug(f"Error fetching {symbol}: {e}")

        logger.info(f"Top 10 coins from allowlist: {len(live_coins)}/10 symbols")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("/coins/top10 error")
        raise HTTPException(
            status_code=500,
            detail={
                "error": "Failed to fetch top 10 coins",
                "reason": str(e),
                "allowlist_enforced": True,
                "cache_only": True,
            },
        ) from e
    else:
        return live_coins


@router.get("/market/ui-data")
async def get_ui_market_data():
    """Get market data formatted for UI consumption"""
    try:
        # Get market summary from live market data service
        market_summary = await live_market_data_service.get_market_summary()

        return {
            "status": "success",
            "data": market_summary,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": "live_market_data_service",
        }

    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("UI market data error")
        return {
            "status": "error",
            "data": {},
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }


@router.get("/data/replay")
async def get_data_replay(
    response: Response,
    symbol: str = Query(..., description="Symbol, e.g. BTC, BTCUSDT, BTC-USD"),
    from_ts: int = Query(..., alias="from", description="Start epoch ms"),
    to_ts: int = Query(..., alias="to", description="End epoch ms"),
    interval: str = Query("1m", description="Interval for OHLCV: 1m/5m/15m/1h/4h/1d"),
    max_limit: int = Query(1000, ge=1, le=5000, description="Max rows to return"),
) -> dict[str, Any]:
    """Batch pull OHLCV for training windows. Returns list[dict] candles in range.
    Uses exchange data via ccxt to avoid mock data.
    """
    # Validate time range before try block to avoid TRY301
    if to_ts <= from_ts:
        raise HTTPException(status_code=400, detail="Invalid time range")

    try:
        pair = _to_pair(symbol)
        # Compute limit for ccxt; guard by max_limit
        # Approx candles estimate by interval
        sec_map = {
            "1m": 60,
            "5m": 300,
            "15m": 900,
            "30m": 1800,
            "1h": 3600,
            "4h": 14400,
            "1d": 86400,
            "1w": 604800,
            "1M": 2592000,
        }
        step = sec_map.get(interval, 60)
        est = int(((to_ts - from_ts) / 1000) / step) + 1
        limit = max(1, min(est, max_limit))
        rows: list[list[Any]] = []

        # Use live market data service to get OHLCV data
        if live_market_data_service:
            try:
                rows_any: Any = await live_market_data_service.get_ohlcv(pair, timeframe=interval, limit=limit)
                rows = cast("list[list[Any]]", rows_any) if isinstance(rows_any, list) else []
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.warning(f"Failed to get live OHLCV data for replay: {e}")
        candles: list[dict[str, Any]] = []
        for r in rows or []:
            if len(r) >= 6:
                ts = int(r[0])
                if from_ts <= ts <= to_ts:
                    candles.append(
                        {
                            "timestamp": r[0],
                            "open": r[1],
                            "high": r[2],
                            "low": r[3],
                            "close": r[4],
                            "volume": r[5],
                        },
                    )
        response.headers["Cache-Control"] = "public, max-age=1, stale-while-revalidate=5"
        return {
            "symbol": pair,
            "interval": interval,
            "candles": candles[:max_limit],
            "server_ts": datetime.now(timezone.utc).isoformat(),
        }
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("replay error")
        raise HTTPException(status_code=500, detail="Failed to fetch replay data") from e
