"""
Market Data Endpoints - LIVE DATA ONLY
Simple wrappers around MarketDataService that's already working
"""

import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter

from backend.services.market_data import MarketDataService

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Market"])


@router.get("/api/market/overview")
async def get_market_overview() -> dict[str, Any]:
    """Market overview from LIVE Binance data"""
    try:
        mds = MarketDataService.shared()

        if not mds or not mds.cache:
            return {"status": "no_data", "message": "Market data not available"}

        total_symbols = len(mds.cache)
        gainers = [s for s, d in mds.cache.items() if float(d.get("change_24h", 0)) > 0]
        losers = [s for s, d in mds.cache.items() if float(d.get("change_24h", 0)) < 0]

        avg_change = sum(float(d.get("change_24h", 0)) for d in mds.cache.values()) / total_symbols if total_symbols > 0 else 0
        total_volume = sum(float(d.get("volume_24h", 0)) for d in mds.cache.values())

        return {
            "status": "live",
            "total_symbols": total_symbols,
            "gainers": len(gainers),
            "losers": len(losers),
            "avg_change_24h": round(avg_change, 2),
            "total_volume_24h": round(total_volume, 2),
            "market_trend": "bullish" if avg_change > 1 else "bearish" if avg_change < -1 else "neutral",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": "live_binance_us",
        }
    except Exception as e:
        logger.exception(f"Market overview error: {e}")
        return {"status": "error", "error": str(e)}


@router.get("/api/market/live")
async def get_market_live() -> dict[str, Any]:
    """Live market data for all symbols"""
    try:
        mds = MarketDataService.shared()

        if not mds or not mds.cache:
            return {"status": "no_data", "symbols": []}

        symbols_data = []
        for symbol, data in mds.cache.items():
            symbols_data.append(
                {
                    "symbol": symbol,
                    "price": float(data.get("price", 0)),
                    "change_24h": float(data.get("change_24h", 0)),
                    "volume_24h": float(data.get("volume_24h", 0)),
                    "timestamp": data.get("timestamp", datetime.now(timezone.utc).isoformat()),
                }
            )

        return {"status": "live", "symbols": symbols_data, "count": len(symbols_data), "timestamp": datetime.now(timezone.utc).isoformat(), "source": "live_binance_us"}
    except Exception as e:
        logger.exception(f"Market live error: {e}")
        return {"status": "error", "error": str(e), "symbols": []}


@router.get("/api/market/prices")
@router.get("/market/prices")
async def get_market_prices() -> dict[str, Any]:
    """Current prices for all symbols"""
    try:
        mds = MarketDataService.shared()

        if not mds or not mds.cache:
            return {"status": "no_data", "prices": {}}

        prices = {symbol: float(data.get("price", 0)) for symbol, data in mds.cache.items()}

        return {"status": "live", "prices": prices, "count": len(prices), "timestamp": datetime.now(timezone.utc).isoformat(), "source": "live_binance_us"}
    except Exception as e:
        logger.exception(f"Market prices error: {e}")
        return {"status": "error", "error": str(e), "prices": {}}


@router.get("/api/status")
async def get_api_status() -> dict[str, Any]:
    """API and system status"""
    try:
        mds = MarketDataService.shared()

        market_data_ok = bool(mds and mds.cache and len(mds.cache) > 0)

        return {
            "status": "online",
            "api_version": "2.0.0",
            "services": {"market_data": "online" if market_data_ok else "offline", "trading": "online", "indicators": "online"},
            "symbols_tracked": len(mds.cache) if mds and mds.cache else 0,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "data_source": "live_binance_us",
        }
    except Exception as e:
        logger.exception(f"API status error: {e}")
        return {"status": "error", "error": str(e)}


@router.get("/api/market/status")
async def get_market_status() -> dict[str, Any]:
    """Market data service status"""
    try:
        mds = MarketDataService.shared()

        if not mds:
            return {"status": "unavailable", "message": "Market data service not initialized"}

        market_data_ok = bool(mds.cache and len(mds.cache) > 0)

        return {
            "status": "online" if market_data_ok else "degraded",
            "service": "market_data",
            "symbols_tracked": len(mds.cache) if mds.cache else 0,
            "last_update": getattr(mds, "last_update", None),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "data_source": "live_binance_us",
        }
    except Exception as e:
        logger.exception(f"Market status error: {e}")
        return {"status": "error", "error": str(e)}
