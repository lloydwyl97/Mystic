"""
Notifications Endpoints - Live notification management
"""

import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException

# Direct imports for production
from backend.services.notification_service import get_notification_service

router = APIRouter()
logger = logging.getLogger(__name__)


@router.get("/api/notifications/recent")
async def get_recent_notifications() -> dict[str, Any]:
    """Get recent notifications."""
    try:
        service = get_notification_service()
        recent_notifications = await service.get_recent_notifications()

        return {"notifications": recent_notifications, "count": len(recent_notifications), "timestamp": datetime.now(timezone.utc).isoformat()}
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get recent notifications: {e}")
        raise HTTPException(status_code=500, detail=f"Recent notifications unavailable: {e!s}") from e


@router.get("/api/notifications/subscribe")
async def get_notification_subscription() -> dict[str, Any]:
    """Get notification subscription status."""
    try:
        service = get_notification_service()
        subscription_status = await service.get_subscription_status()

        return {"subscription": subscription_status, "timestamp": datetime.now(timezone.utc).isoformat()}
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get notification subscription: {e}")
        raise HTTPException(status_code=500, detail=f"Notification subscription unavailable: {e!s}") from e


@router.get("/api/notifications/vapid-key")
async def get_vapid_key() -> dict[str, Any]:
    """Get VAPID key for push notifications."""
    try:
        service = get_notification_service()
        vapid_key = await service.get_vapid_key()

        return {"vapid_key": vapid_key, "timestamp": datetime.now(timezone.utc).isoformat()}
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get VAPID key: {e}")
        raise HTTPException(status_code=500, detail=f"VAPID key unavailable: {e!s}") from e
