"""
Orchestrator Status Endpoint
Real-time orchestrator data for dashboard
"""

from __future__ import annotations

import ast
import asyncio
import json
import logging
import os
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["Orchestrator"])


def _parse_status(raw: str | None) -> dict[str, Any] | None:
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except Exception:
        try:
            return ast.literal_eval(raw)
        except Exception:
            return None


async def _get_status_payload() -> dict[str, Any]:
    try:
        from backend.config.redis_config import get_shared_redis_sync

        client = get_shared_redis_sync()
        if client is None:
            return {
                "status": "error",
                "running": False,
                "state": "error",
                "current_accuracy": 0.0,
                "error": "Redis unavailable",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        orch_status = await asyncio.to_thread(client.get, "orchestrator:status")
        parsed = _parse_status(orch_status)

        if parsed:
            return {
                "status": "success",
                "running": parsed.get("is_running", False),
                "state": parsed.get("state", "unknown"),
                "current_accuracy": parsed.get("current_accuracy", 0.0),
                "accuracy_threshold": parsed.get("accuracy_threshold", 0.45),
                "go_live_thresholds": parsed.get("go_live_thresholds", {}),
                "last_accuracy_check": parsed.get("last_accuracy_check"),
                "timestamp": parsed.get("timestamp", datetime.now(timezone.utc).isoformat()),
            }

        return {
            "status": "not_found",
            "running": False,
            "state": "unknown",
            "current_accuracy": 0.0,
            "error": "Orchestrator status not found in Redis",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:
        logger.exception(f"Failed to get orchestrator status: {e}")
        return {
            "status": "error",
            "running": False,
            "state": "error",
            "current_accuracy": 0.0,
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }


@router.get("/orchestrator/status")
async def get_orchestrator_status() -> dict[str, Any]:
    return await _get_status_payload()


@router.get("/autobuy/orchestrator/status")
async def get_autobuy_orchestrator_status() -> dict[str, Any]:
    return await _get_status_payload()


@router.post("/autobuy/orchestrator/force-start-paper-service")
async def force_start_paper_service() -> dict[str, Any]:
    """Force start the paper autobuy service - diagnostic endpoint"""
    try:
        from backend.services.ai_autobuy_orchestrator import get_orchestrator

        orch = get_orchestrator()

        logger.info(f"[FORCE START] Current state: {orch.state}, running: {orch.is_running}")
        logger.info(f"[FORCE START] paper_service_instance: {orch.paper_service_instance}")

        if orch.paper_service_instance:
            is_running = getattr(orch.paper_service_instance, "is_running", False)
            logger.info(f"[FORCE START] paper_service_instance.is_running: {is_running}")
            if is_running:
                return {
                    "status": "already_running",
                    "message": "Paper service is already running",
                    "is_running": True,
                }

        # Force start the paper service
        logger.info("[FORCE START] Calling _start_paper_service()...")
        await orch._start_paper_service()

        # Verify it started
        if orch.paper_service_instance and getattr(orch.paper_service_instance, "is_running", False):
            logger.info("[FORCE START] Paper service started successfully")
            return {
                "status": "started",
                "message": "Paper service started successfully",
                "is_running": True,
            }
        else:
            logger.error("[FORCE START] Paper service failed to start")
            return {
                "status": "failed",
                "message": "Paper service failed to start",
                "is_running": False,
            }
    except Exception as e:
        logger.exception(f"[FORCE START] Error: {e}")
        return {
            "status": "error",
            "message": str(e),
            "is_running": False,
        }


@router.get("/autobuy/orchestrator/diagnostics")
async def get_orchestrator_diagnostics() -> dict[str, Any]:
    """Get detailed orchestrator diagnostics"""
    try:
        from backend.services.ai_autobuy_orchestrator import get_orchestrator

        orch = get_orchestrator()

        paper_service_info = None
        if orch.paper_service_instance:
            paper_service_info = {
                "exists": True,
                "is_running": getattr(orch.paper_service_instance, "is_running", False),
                "redis": str(getattr(orch.paper_service_instance, "redis", None)),
                "type": str(type(orch.paper_service_instance)),
            }

        # Check Redis for paper service activity
        from backend.config.redis_config import get_shared_redis_sync

        client = get_shared_redis_sync()
        last_check = None
        is_running_redis = None
        if client is not None:
            last_check = client.get("paper_autobuy:last_check_time")
            is_running_redis = client.get("paper_autobuy:is_running")

        return {
            "status": "success",
            "orchestrator": {
                "state": orch.state.value,
                "is_running": orch.is_running,
                "paper_service": str(orch.paper_service),
                "live_service": str(orch.live_service),
                "paper_service_instance": paper_service_info,
            },
            "redis": {
                "paper_autobuy:last_check_time": last_check,
                "paper_autobuy:is_running": is_running_redis,
            },
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:
        logger.exception(f"Diagnostics error: {e}")
        return {
            "status": "error",
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
