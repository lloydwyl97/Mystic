"""
Paper Trading Endpoints
FastAPI endpoints for paper trading functionality

MEDIUM #4 FIX: Confidence threshold now centralized via MIN_CONFIDENCE env var
Used consistently in both paper endpoint and portfolio engine
"""

import asyncio
import json
import logging
import os
import sqlite3
import time
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from backend.config.redis_config import get_redis_client, get_shared_redis_async
from backend.config.signal_thresholds import MIN_CONFIDENCE_BUY
from backend.database_schema import DATABASE_PATH
from backend.services.confidence_normalizer import ConfidenceNormalizer
from backend.services.gate_reason_codes import GateReason
from backend.services.paper_trading_service import get_paper_trading_service

_sleeve_cutover_epoch_cache: int | None = None


def _get_sleeve_cutover_epoch() -> int | None:
    global _sleeve_cutover_epoch_cache
    if _sleeve_cutover_epoch_cache is not None:
        return _sleeve_cutover_epoch_cache
    try:
        conn = sqlite3.connect(DATABASE_PATH, timeout=2)
        row = conn.execute("SELECT value_json FROM operational_state WHERE key='sleeve_cutover'").fetchone()
        conn.close()
        if row:
            data = json.loads(row[0])
            _sleeve_cutover_epoch_cache = data.get("epoch")
            return _sleeve_cutover_epoch_cache
    except Exception:
        pass
    return None


def _ts_after_cutover(ts: str | None, cutover_epoch: int) -> bool:
    if not ts:
        return False
    try:
        dt = datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
        return dt.timestamp() >= cutover_epoch
    except Exception:
        return False


# Optional imports - services may not be available
try:
    from backend.services.ai_autobuy_orchestrator import get_orchestrator
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    get_orchestrator = None  # type: ignore[assignment]

try:
    from backend.services.ai_paper_autobuy_service import AIPaperAutoBuyService
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    AIPaperAutoBuyService = None  # type: ignore[assignment]

try:
    from backend.services.paper_trading_feedback_service import paper_trading_feedback_service
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    paper_trading_feedback_service = None  # type: ignore[assignment]

try:
    from backend.utils.redis_helpers import WRITER_ROLES, verify_writer_payload
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    verify_writer_payload = None  # type: ignore[assignment]
    WRITER_ROLES = None  # type: ignore[assignment]

try:
    from backend.services.portfolio_engine import (
        get_portfolio_engine,
        is_portfolio_engine_initialized,
    )
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    get_portfolio_engine = None  # type: ignore[assignment]

    def is_portfolio_engine_initialized() -> bool:
        return False


try:
    from backend.utils.symbols import to_exchange_symbol
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):

    def to_exchange_symbol(s: str) -> str:
        return s


logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/paper-trading", tags=["Paper Trading"])


def _validate_data_integrity_sync(positions_value: float, principal: float, realized_pnl: float, cash_balance: float) -> tuple[bool, float]:
    """BUG #6 FIX: Sync DB helper for data integrity check. Runs in thread."""
    conn = None
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()

        # Get sum of all realized P&L across all runs (only fully closed positions)
        # This matches the cumulative realized_pnl_total in memory
        cursor.execute("""
            SELECT COALESCE(SUM(pnl), 0)
            FROM paper_trades
            WHERE UPPER(side) = 'SELL' AND remaining_position = 0 AND pnl IS NOT NULL
        """)

        sqlite_realized_pnl = cursor.fetchone()[0]

        # When no positions are open, cash should equal principal + realized P&L
        if float(positions_value or 0.0) == 0.0:
            expected_cash = float(principal or 0.0) + float(sqlite_realized_pnl)
            data_integrity_diff = float(cash_balance or 0.0) - expected_cash
            data_integrity_ok = abs(data_integrity_diff) < 0.01  # $0.01 tolerance for floating point
        else:
            # When positions exist, just validate that realized P&L matches SQLite
            data_integrity_diff = float(realized_pnl or 0.0) - float(sqlite_realized_pnl)
            data_integrity_ok = abs(data_integrity_diff) < 0.01

        if not data_integrity_ok:
            logger.warning(f"Data integrity check failed: cash={cash_balance}, principal={principal}, realized_pnl={realized_pnl}, sqlite_sum={sqlite_realized_pnl}, diff={data_integrity_diff}")

        return data_integrity_ok, data_integrity_diff

    except Exception as e:
        logger.exception(f"Data integrity validation failed: {e}")
        return False, -999.0  # Error indicator
    finally:
        if conn:
            conn.close()


async def _validate_data_integrity_async(positions_value: float, principal: float, realized_pnl: float, cash_balance: float) -> tuple[bool, float]:
    """BUG #6 FIX: Async wrapper that offloads DB work to thread."""
    return await asyncio.to_thread(_validate_data_integrity_sync, positions_value, principal, realized_pnl, cash_balance)


def _get_initial_balance_from_ledger_sync() -> float:
    """Read principal from portfolio_engine_ledger (live data). No hardcoded default. SYNC version."""
    conn = None
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='portfolio_engine_ledger'")
        if not cursor.fetchone():
            return 0.0
        cursor.execute("SELECT principal FROM portfolio_engine_ledger WHERE id=1")
        row = cursor.fetchone()
        if row and row[0] is not None:
            return float(row[0])
    except Exception as e:
        logger.debug("Ledger principal read failed: %s", e)
    finally:
        if conn:
            conn.close()
    return 0.0


async def _get_initial_balance_from_ledger() -> float:
    """BUG #7 FIX: Read principal from ledger using offloaded thread for async contexts."""
    # If called from async context, offload to thread to keep event loop responsive
    return await asyncio.to_thread(_get_initial_balance_from_ledger_sync)


async def _positions_from_paper_trades() -> list[dict[str, Any]]:
    """
    Fallback: derive open positions from paper_trades when portfolio_engine_positions is empty.
    Uses BUY - SELL net quantity per symbol. Needed when BUYs exist in paper_trades but
    portfolio_engine_positions was cleared (e.g. cleanup) or never synced.
    """

    def _sync_load():
        conn = sqlite3.connect(DATABASE_PATH)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT symbol,
                       SUM(CASE WHEN side = 'BUY' THEN quantity ELSE 0 END) -
                       SUM(CASE WHEN side = 'SELL' THEN quantity ELSE 0 END) AS net_qty,
                       SUM(CASE WHEN side = 'BUY' THEN quantity * price ELSE 0 END) /
                       NULLIF(SUM(CASE WHEN side = 'BUY' THEN quantity ELSE 0 END), 0) AS avg_entry
                FROM paper_trades
                GROUP BY symbol
                HAVING net_qty > 0
            """)
            rows = cursor.fetchall()
            return rows
        finally:
            conn.close()

    loop = asyncio.get_running_loop()
    rows = await loop.run_in_executor(None, _sync_load)
    if not rows:
        return []

    redis_client = get_shared_redis_async()
    out: list[dict[str, Any]] = []
    for symbol, net_qty, avg_entry in rows:
        norm = to_exchange_symbol(symbol) if symbol else symbol or ""
        base = (norm or str(symbol or "")).replace("USDT", "").replace("/", "").strip()
        cache_key = f"market:{base}"
        current_price = float(avg_entry or 0)
        try:
            if redis_client:
                cached = await redis_client.get(cache_key)
                if cached:
                    data = json.loads(cached) if isinstance(cached, str) else cached
                    current_price = float(data["price"]) if isinstance(data, dict) and "price" in data else float(cached)
                    if current_price <= 0:
                        current_price = float(avg_entry or 0)
        except Exception as ex:
            logger.debug("Could not fetch cached price: %s", ex)
        entry_price = float(avg_entry or 0)
        unrealized_pnl = (current_price - entry_price) * net_qty
        # Use original symbol (ccxt format ADA/USDT) for display; norm used only for cache key
        display_symbol = str(symbol or "") if symbol else (norm or "")
        out.append(
            {
                "symbol": display_symbol,
                "quantity": float(net_qty),
                "average_price": entry_price,
                "current_price": current_price,
                "unrealized_pnl": unrealized_pnl,
                "realized_pnl": 0.0,
                "total_pnl": unrealized_pnl,
                "market_value": net_qty * current_price,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "last_updated": datetime.now(timezone.utc).isoformat(),
            }
        )
    return out


async def _positions_from_sqlite() -> list[dict[str, Any]]:
    """
    Return open positions from authoritative SQLite (portfolio_engine_positions).
    Dashboard/API may run in a different process from integration—SQLite is the shared source of truth.
    """

    def _sync_load():
        conn = sqlite3.connect(DATABASE_PATH)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT symbol, quantity, entry_price, entry_time, last_updated,
                       COALESCE(sleeve, 'ACTIVE')
                FROM portfolio_engine_positions
                WHERE quantity > 0
                ORDER BY symbol
            """)
            return cursor.fetchall()
        finally:
            conn.close()

    loop = asyncio.get_running_loop()
    rows = await loop.run_in_executor(None, _sync_load)
    if not rows:
        return []

    redis_client = get_shared_redis_async()
    out: list[dict[str, Any]] = []
    for row in rows:
        symbol, quantity, entry_price, entry_time, last_updated = row[0], row[1], row[2], row[3], row[4]
        sleeve = row[5] if len(row) > 5 else "ACTIVE"
        base_symbol = (symbol or "").replace("/USDT", "").replace("USDT", "").strip()
        cache_key = f"market:{base_symbol}"
        current_price = float(entry_price or 0)
        try:
            if redis_client:
                cached = await redis_client.get(cache_key)
                if cached:
                    data = json.loads(cached) if isinstance(cached, str) else cached
                    current_price = float(data["price"]) if isinstance(data, dict) and "price" in data else float(cached)
                    if current_price <= 0:
                        current_price = float(entry_price or 0)
        except Exception as e:
            logger.debug("Redis price for %s: %s", symbol, e)
        entry_price_f = float(entry_price or 0)
        unrealized_pnl = (current_price - entry_price_f) * float(quantity or 0)
        out.append(
            {
                "symbol": symbol,
                "quantity": float(quantity or 0),
                "average_price": entry_price_f,
                "current_price": current_price,
                "unrealized_pnl": unrealized_pnl,
                "realized_pnl": 0.0,
                "total_pnl": unrealized_pnl,
                "market_value": float(quantity or 0) * current_price,
                "created_at": datetime.fromtimestamp(float(entry_time or 0), tz=timezone.utc).isoformat() if entry_time else datetime.now(timezone.utc).isoformat(),
                "last_updated": last_updated or datetime.now(timezone.utc).isoformat(),
                "sleeve": sleeve,
            }
        )
    return out


async def _positions_from_portfolio_engine() -> list[dict[str, Any]] | None:
    """Return open positions from portfolio engine in-memory. Used as fallback when SQLite unavailable."""
    if get_portfolio_engine is None:
        return None
    try:
        engine = get_portfolio_engine()
        # LIVE mode: refresh from SQLite (integration may run in external process)
        if getattr(engine, "_live_execution_enabled", False) and hasattr(engine, "_load_positions_from_sqlite"):
            await engine._load_positions_from_sqlite()
        if not engine.open_positions:
            return []
        out: list[dict[str, Any]] = []
        redis_client = get_shared_redis_async()
        for symbol, pos in engine.open_positions.items():
            base_symbol = to_exchange_symbol(symbol).replace("USDT", "")
            cache_key = f"market:{base_symbol}"
            current_price = pos.entry_price
            try:
                cached = await redis_client.get(cache_key)
                if cached:
                    data = json.loads(cached) if isinstance(cached, str) else cached
                    current_price = float(data["price"]) if isinstance(data, dict) and "price" in data else float(cached)
                    if current_price <= 0:
                        current_price = pos.entry_price
            except Exception as e:
                logger.debug("Redis price for %s: %s", symbol, e)
            unrealized_pnl = (current_price - pos.entry_price) * pos.quantity
            entry_dt = datetime.fromtimestamp(pos.entry_time, tz=timezone.utc) if pos.entry_time else datetime.now(timezone.utc)
            out.append(
                {
                    "symbol": symbol,
                    "quantity": pos.quantity,
                    "average_price": pos.entry_price,
                    "current_price": current_price,
                    "unrealized_pnl": unrealized_pnl,
                    "realized_pnl": 0.0,
                    "total_pnl": unrealized_pnl,
                    "market_value": pos.quantity * current_price,
                    "created_at": entry_dt.isoformat(),
                    "last_updated": datetime.now(timezone.utc).isoformat(),
                    "sleeve": getattr(pos, "sleeve", "ACTIVE"),
                }
            )
    except Exception as e:
        logger.debug("Positions from portfolio engine failed: %s", e)
        return None
    else:
        return out


@router.get("/status")
async def get_paper_trading_status() -> dict[str, Any]:
    """Get paper trading status - production data only"""
    try:
        import time

        paper_service = get_paper_trading_service()
        enabled = paper_service.is_enabled()
        running = paper_service._running  # Check if service loop is actually running

        # ================================================================
        # PHASE 4 FIX #5: CHECK CACHE STALENESS AND RETURN FLAG
        # ================================================================
        # Get balance with staleness detection
        # If cache is older than 5 seconds, consider it stale
        # Return stale flag so client knows to refresh
        balance = await paper_service.get_account_balance(use_cache_only=True)  # Dashboard: no exchange weight

        # Add cache age information
        current_time = time.time()
        cache_age_seconds = 0  # Estimate from balance timestamp if available
        balance_timestamp = balance.get("timestamp")
        if balance_timestamp and isinstance(balance_timestamp, str):
            try:
                from datetime import datetime

                ts = datetime.fromisoformat(balance_timestamp)
                cache_age_seconds = current_time - ts.timestamp()
            except Exception as ex:
                logger.debug("balance timestamp parse failed: %s", ex)
                cache_age_seconds = 0

        # Add staleness flag
        is_cache_stale = cache_age_seconds > 5.0  # 5 second threshold
        if "status" not in balance:
            balance["status"] = "success"
        balance["cache_age_seconds"] = cache_age_seconds
        balance["is_cache_stale"] = is_cache_stale
        if is_cache_stale:
            balance["_warning"] = f"Balance cache is {cache_age_seconds:.1f}s old"

        # MINIMAL FIX: Start AI trading system on first status call
        try:
            if AIPaperAutoBuyService is not None and not hasattr(get_paper_trading_status, "_ai_started"):
                ai_service = AIPaperAutoBuyService()
                await asyncio.wait_for(ai_service.start(), timeout=10.0)
                get_paper_trading_status._ai_started = True
                logger.info("AI Paper AutoBuy Service started successfully")

                # Try orchestrator too
                try:
                    if get_orchestrator is not None:
                        orchestrator = get_orchestrator()
                        initialized = await orchestrator.initialize()
                        if initialized:
                            await orchestrator.start()
                            logger.info("AI AutoBuy Orchestrator started successfully")
                except Exception as orch_e:
                    logger.warning(f"Orchestrator failed: {orch_e}")
        except asyncio.TimeoutError:
            logger.warning("AI service start timed out")
        except Exception as e:
            logger.exception(f"AI service start failed: {e}")

        # IMPROVED DATA INTEGRITY VALIDATION
        # Now that run_id continuity is fixed, we can do proper reconciliation
        positions_value = balance.get("positions_value", 0.0)
        principal = balance.get("principal", 0.0)
        realized_pnl = balance.get("realized_pnl", 0.0)
        cash_balance = balance.get("cash_balance", 0.0)

        try:
            # BUG #6 FIX: Use async offload for DB work
            data_integrity_ok, data_integrity_diff = await _validate_data_integrity_async(positions_value, principal, realized_pnl, cash_balance)

        except Exception as e:
            logger.exception(f"Data integrity validation failed: {e}")
            data_integrity_ok = False
            data_integrity_diff = -999.0  # Error indicator

        return {
            "status": "success",
            "enabled": enabled,
            "running": running,
            "balance": balance.get("total_balance_usd", balance.get("total_value", 0)),
            "details": balance,
            "paper_run_id": paper_service.paper_run_id,
            "data_integrity_ok": data_integrity_ok,
            "data_integrity_diff": data_integrity_diff,
            "data_source": "sqlite_canonical",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get paper trading status: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


async def _get_signal_keys_async() -> list[str]:
    """BUG #4 FIX: Use async Redis client with SCAN instead of sync KEYS."""
    try:
        redis_async = get_shared_redis_async()
        if not redis_async:
            # Fall back to sync client if async not available (L1: use SCAN not KEYS)
            def _sync_scan_keys() -> list[str]:
                redis_sync = get_redis_client()
                ai_decision_keys = list(redis_sync.scan_iter(match="ai_decision:*", count=100))
                ai_signal_keys = list(redis_sync.scan_iter(match="ai_signal:*", count=100))
                return ai_decision_keys + ai_signal_keys

            return await asyncio.to_thread(_sync_scan_keys)

        all_keys: list[str] = []

        # Scan ai_decision:* pattern
        async for key in redis_async.scan_iter(match="ai_decision:*", count=100):
            all_keys.append(key)

        # Scan ai_signal:* pattern
        async for key in redis_async.scan_iter(match="ai_signal:*", count=100):
            all_keys.append(key)

        return all_keys
    except Exception as e:
        logger.warning("Failed to get signal keys with async SCAN: %s, falling back to sync SCAN", e)

        def _sync_scan_keys_fallback() -> list[str]:
            redis_client = get_redis_client()
            ai_decision_keys = list(redis_client.scan_iter(match="ai_decision:*", count=100))
            ai_signal_keys = list(redis_client.scan_iter(match="ai_signal:*", count=100))
            return ai_decision_keys + ai_signal_keys

        return await asyncio.to_thread(_sync_scan_keys_fallback)


@router.post("/process-signals")
async def process_signals() -> dict[str, Any]:
    """Process all pending AI signals into trades via Portfolio Engine (same pipeline as live)."""
    try:
        # Get Redis client - prefer async if available
        redis_async = get_shared_redis_async()
        use_async = redis_async is not None
        redis_client = redis_async if use_async else get_redis_client()

        # Ensure portfolio engine is initialized (paper mode selected by existing config)
        if get_portfolio_engine is not None and not is_portfolio_engine_initialized():
            try:
                from backend.services.portfolio_engine import initialize_portfolio_engine

                await initialize_portfolio_engine()
            except Exception as init_err:
                logger.warning("Could not initialize portfolio engine for process-signals: %s", init_err)

        # Process all pending signals from BOTH patterns:
        # 1. ai_decision:* - Real AI engine decisions (primary)
        # 2. ai_signal:* - Signal generator (fallback)
        # BUG #4 FIX: Use async SCAN instead of blocking KEYS
        all_keys = await _get_signal_keys_async()

        processed = 0
        trades_executed = 0
        blocked_by_cooldown = 0

        for key in all_keys:
            try:
                # Extract symbol from either pattern (e.g., "ai_decision:BTCUSDT" -> "BTCUSDT")
                symbol = key.replace("ai_decision:", "") if key.startswith("ai_decision:") else key.replace("ai_signal:", "")

                # CRITICAL #3 FIX: Use async Redis client for hgetall
                if use_async:
                    signal_data = await redis_async.hgetall(key)
                else:
                    signal_data = await asyncio.to_thread(redis_client.hgetall, key)

                # WRITER VALIDATION: Verify payload comes from expected writer
                if signal_data and verify_writer_payload and WRITER_ROLES:
                    expected_role = WRITER_ROLES["DECISION_ROUTER"] if key.startswith("ai_decision:") else WRITER_ROLES["AI_SIGNALS"]
                    if use_async:
                        valid = verify_writer_payload(expected_role, signal_data, redis_client)
                    else:
                        valid = await asyncio.to_thread(verify_writer_payload, expected_role, signal_data, redis_client)
                    if not valid:
                        logger.warning(f"[WRITER-VALIDATION] Rejected signal from {key} - invalid writer role")
                        continue  # Skip this signal

                # Extract decision_id for pipeline tracking
                decision_id = signal_data.get("decision_id") if signal_data else None

                # BUG #3 FIX: Use centralized MIN_CONFIDENCE threshold; normalize confidence (0-1 or 0-100)
                min_confidence = float(os.getenv("MIN_CONFIDENCE", "0.50"))
                raw_gate_conf = signal_data.get("confidence", 0) if signal_data else 0
                gate_conf = ConfidenceNormalizer.normalize(float(raw_gate_conf) if raw_gate_conf is not None else 0.0)
                if signal_data and signal_data.get("side") == "buy" and gate_conf >= min_confidence:
                    # Get current price - FIX: Convert BTCUSDT to BTC for market key lookup
                    # Market keys are stored as "market:BTC" not "market:BTCUSDT"
                    base_symbol = symbol.replace("USDT", "") if symbol.endswith("USDT") else symbol
                    price_key = f"market:{base_symbol}"

                    # CRITICAL #3 FIX: Use async Redis client for get
                    if use_async:
                        price_data = await redis_async.get(price_key)
                    else:
                        price_data = await asyncio.to_thread(redis_client.get, price_key)

                    if price_data:
                        price_info = json.loads(price_data) if isinstance(price_data, str) else price_data

                        current_price = float(price_info.get("price", 0))

                        if current_price > 0:
                            # Route through Portfolio Engine (same pipeline as live). No endpoint-level gates.
                            execution_result = "NOT_EXECUTED"
                            execution_reason = None
                            gate_result = GateReason.PASS
                            gate_reason = None

                            engine = get_portfolio_engine() if get_portfolio_engine else None
                            if engine is None:
                                execution_reason = GateReason.ENGINE_UNAVAILABLE
                                logger.warning("process-signals: Portfolio engine not available")
                            else:
                                balance = await get_paper_trading_service().get_balance()
                                if balance < 10.0:
                                    execution_reason = f"INSUFFICIENT_BALANCE: {balance:.2f} < 10.0"
                                else:
                                    trade_size = min(balance * 0.01, 25.0)  # 1% or $25 max
                                    quantity = trade_size / current_price
                                    raw_conf = signal_data.get("confidence", 0.5)
                                    confidence = ConfidenceNormalizer.normalize(float(raw_conf) if raw_conf is not None else 0.5)
                                    decision = dict(signal_data) if signal_data else None

                                    result = await engine.execute_buy_from_signal(
                                        symbol=symbol,
                                        quantity=quantity,
                                        price=current_price,
                                        confidence=confidence,
                                        decision=decision,
                                    )
                                    if result is not None:
                                        execution_result = "EXECUTED_BUY"
                                        trades_executed += 1
                                        exec_qty = result.get("quantity", quantity)
                                        logger.info(f"PAPER_BUY_EXECUTED: {symbol} {exec_qty:.4f} @ ${current_price:.2f} (via portfolio engine)")
                                        if use_async:
                                            await redis_async.delete(key)
                                        else:
                                            await asyncio.to_thread(redis_client.delete, key)
                                    else:
                                        execution_reason = GateReason.ENGINE_BLOCKED
                                        blocked_by_cooldown += 1

                            if decision_id:
                                await _update_pipeline_decision(decision_id, {"stage": "GATES", "gate_result": gate_result, "gate_reason": gate_reason})
                                await _update_pipeline_decision(decision_id, {"stage": "EXECUTION", "execution_result": execution_result, "execution_reason": execution_reason})

                processed += 1

            except Exception as e:
                logger.warning(f"Signal processing error for {key}: {e}")

        return {
            "status": "success",
            "message": f"Processed {processed} signals, executed {trades_executed} trades, blocked {blocked_by_cooldown} by cooldowns",
            "signals_processed": processed,
            "trades_executed": trades_executed,
            "blocked_by_cooldown": blocked_by_cooldown,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    except Exception as e:
        logger.exception(f"Signal processing failed: {e}")
        return {
            "status": "error",
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }


async def _update_pipeline_decision(decision_id: str, updates: dict[str, Any]) -> None:
    """
    LOW #5 FIX: Update existing pipeline decision with new stage data.
    Delegates to unified service to avoid code duplication.
    """
    from backend.services.pipeline_decision_service import update_pipeline_decision

    await update_pipeline_decision(decision_id, updates)


@router.get("/portfolio")
async def get_paper_trading_portfolio() -> dict[str, Any]:
    """Get paper trading portfolio data from paper trading service"""
    try:
        paper_service = get_paper_trading_service()
        portfolio_data = await paper_service.get_account_balance(use_cache_only=True)  # Dashboard: no exchange weight

        if portfolio_data.get("error"):
            raise HTTPException(status_code=500, detail=portfolio_data["error"])

        # FIX: Read cash directly from Redis for accurate display
        try:
            redis_client = get_shared_redis_async()
            redis_cash = await redis_client.get("paper_trading:cash_balance")
            if redis_cash:
                paper_cash = float(redis_cash)
                positions_value = portfolio_data.get("positions_value", 0)
                # Override with correct cash from Redis
                portfolio_data["cash_balance"] = paper_cash
                portfolio_data["available_balance"] = paper_cash
                portfolio_data["total_balance"] = paper_cash
                portfolio_data["total_value"] = paper_cash + positions_value
                portfolio_data["total_balance_usd"] = paper_cash + positions_value
        except Exception as e:
            logger.warning(f"Failed to read cash from Redis: {e}")

        return {
            "status": "success",
            "portfolio": portfolio_data,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": "paper_trading",
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting paper trading portfolio: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/balance")
async def get_paper_trading_balance() -> dict[str, Any]:
    """Get paper trading account balance"""
    try:
        paper_service = get_paper_trading_service()
        balance_data = await paper_service.get_account_balance()

        if balance_data.get("error"):
            raise HTTPException(status_code=500, detail=balance_data["error"])

        return {
            "status": "success",
            "balance": balance_data,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": "paper_trading",
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting paper trading balance: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/positions")
async def get_paper_trading_positions() -> dict[str, Any]:
    """Get open positions from canonical source (SQLite portfolio_engine_positions). Fallback to paper_trades, then paper_trading Redis."""
    try:
        # 1) Prefer SQLite portfolio_engine_positions (authoritative; shared by API + integration processes)
        positions_data = await _positions_from_sqlite()
        source = "portfolio_engine_positions"
        # 2) If empty, try paper_trades (BUY - SELL net) - handles orphaned BUYs
        if len(positions_data) == 0:
            fallback = await _positions_from_paper_trades()
            if fallback:
                positions_data = fallback
                source = "paper_trades"
        # 3) If still empty, try engine in-memory then Redis
        if len(positions_data) == 0:
            engine_pos = await _positions_from_portfolio_engine()
            if engine_pos:
                positions_data = engine_pos
                source = "portfolio_engine"
        if len(positions_data) == 0:
            paper_service = get_paper_trading_service()
            try:
                positions_data = await paper_service.get_positions()
            except AttributeError:
                positions_data = []
            if positions_data:
                source = "paper_trading"

        return {
            "status": "success",
            "positions": positions_data,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": source,
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Error getting paper trading positions: %s", e)
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/performance")
async def get_paper_trading_performance(include_history: bool = True) -> dict[str, Any]:
    """Get trading performance metrics. Default: full history (all runs, paper+live). Set include_history=false for current run only."""
    try:
        paper_service = get_paper_trading_service()
        trade_history = await paper_service.get_trade_history(limit=None, include_history=include_history)

        # Get portfolio for unrealized P&L
        portfolio_response = await get_paper_trading_portfolio()
        portfolio = portfolio_response.get("portfolio", {})
        unrealized_pnl = portfolio.get("unrealized_pnl", 0.0)

        # Initial balance from live ledger (no hardcoded value)
        initial_balance = await _get_initial_balance_from_ledger()  # BUG #7 FIX: Now awaits async offload
        current_balance = portfolio.get("total_balance_usd", 0.0) or 0.0
        if initial_balance == 0 and current_balance:
            initial_balance = current_balance  # No history: treat current as baseline
        total_return = ((current_balance - initial_balance) / initial_balance * 100) if initial_balance > 0 else 0.0

        # Calculate REALIZED performance (completed trade cycles only)
        total_realized_trades = len(trade_history)
        winning_trades = 0
        losing_trades = 0
        realized_pnl = 0.0

        for trade in trade_history:
            pnl = float(trade.get("pnl", 0.0) or 0.0)
            realized_pnl += pnl
            if pnl > 0:
                winning_trades += 1
            elif pnl < 0:
                losing_trades += 1

        realized_win_rate = (winning_trades / total_realized_trades * 100) if total_realized_trades > 0 else 0.0
        avg_trade_pnl = (realized_pnl / total_realized_trades) if total_realized_trades > 0 else 0.0

        # Calculate TOTAL performance (realized + unrealized)
        total_pnl = realized_pnl + unrealized_pnl

        return {
            "status": "success",
            "performance": {
                "total_trades": total_realized_trades,
                "winning_trades": winning_trades,
                "losing_trades": losing_trades,
                "win_rate": realized_win_rate,
                "total_pnl": realized_pnl,
                "avg_trade_pnl": avg_trade_pnl,
                # NEW: Show unrealized and total performance
                "unrealized_pnl": unrealized_pnl,
                "total_pnl_including_unrealized": total_pnl,
                "total_return_pct": total_return,
                "initial_balance": initial_balance,
                "current_balance": current_balance,
            },
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": "paper_trading",
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting paper trading performance: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/orders")
async def get_paper_trading_orders() -> dict[str, Any]:
    """Get paper trading orders"""
    try:
        paper_service = get_paper_trading_service()
        orders_data = await paper_service.get_orders()

        return {
            "status": "success",
            "orders": orders_data,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": "paper_trading",
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting paper trading orders: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


class PlaceOrderRequest(BaseModel):
    symbol: str
    side: str
    order_type: str
    quantity: float
    price: float | None = None
    stop_price: float | None = None
    take_profit_price: float | None = None
    # Optional attribution / admission (same pipeline as signals; omitted when unknown)
    decision_id: str | None = None
    sleeve: str | None = None
    spread_pct: float | None = None
    # Optional explicit confidence for manual paper orders (default: MIN_CONFIDENCE_BUY)
    confidence: float | None = None
    # Local harness only: requires ALLOW_PROOF_TRADE_BYPASS_PROFITABILITY_G3G4=true; skips G3/G4 for lifecycle proof
    proof_trade: bool = False


@router.post("/orders")
async def place_paper_order(request: PlaceOrderRequest) -> dict[str, Any]:
    """Place a paper trading order via Portfolio Engine (same pipeline as live)."""
    try:
        if get_portfolio_engine is None or not is_portfolio_engine_initialized():
            try:
                from backend.services.portfolio_engine import initialize_portfolio_engine

                await initialize_portfolio_engine()
            except Exception as init_err:
                logger.warning("Could not initialize portfolio engine for place_order: %s", init_err)

        engine = get_portfolio_engine() if get_portfolio_engine else None
        if engine is None:
            raise HTTPException(status_code=503, detail="Portfolio engine not available")

        price = float(request.price or 0)
        if price <= 0:
            raise HTTPException(status_code=400, detail="Price required and must be > 0")

        side_upper = str(request.side).strip().upper()
        symbol = request.symbol.strip()

        if side_upper == "BUY":
            decision: dict[str, Any] | None = None
            if request.decision_id or request.sleeve or request.spread_pct is not None or request.proof_trade:
                decision = {}
                if request.decision_id:
                    decision["decision_id"] = str(request.decision_id).strip()
                if request.sleeve:
                    decision["sleeve"] = str(request.sleeve).strip()
                if request.spread_pct is not None:
                    decision["spread_pct"] = float(request.spread_pct)
                if request.proof_trade:
                    decision["proof_trade"] = True
            buy_conf = float(request.confidence) if request.confidence is not None else float(os.getenv("MIN_CONFIDENCE_OVERRIDE") or os.getenv("MIN_CONFIDENCE") or MIN_CONFIDENCE_BUY)
            buy_conf = max(0.0, min(1.0, buy_conf))
            result = await engine.execute_buy_from_signal(
                symbol=symbol,
                quantity=request.quantity,
                price=price,
                confidence=buy_conf,
                decision=decision,
            )
        elif side_upper == "SELL":
            result = await engine.execute_sell_from_signal(
                symbol=symbol,
                quantity=request.quantity,
                price=price,
                exit_reason="MANUAL",
            )
        else:
            raise HTTPException(status_code=400, detail=f"Unsupported side: {request.side}")

        return {
            "status": "success" if result is not None else "error",
            "result": result if result is not None else {"success": False, "reason": "ENGINE_BLOCKED"},
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error placing paper order: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.delete("/orders/{order_id}")
async def cancel_paper_order(order_id: str) -> dict[str, Any]:
    """Cancel a paper trading order"""
    try:
        paper_service = get_paper_trading_service()
        result = await paper_service.cancel_order(order_id)

        return {
            "status": "success" if (isinstance(result, dict) and result.get("success")) else "error",
            "result": result,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error canceling paper order: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/trades")
async def get_paper_trading_trades(limit: int | None = None, run_id: str | None = None, since: str | None = None, include_history: bool = True) -> dict[str, Any]:
    """Get paper trading trade history from SQLite canonical storage. Default include_history=True so dashboard sees full canonical set."""
    try:
        paper_service = get_paper_trading_service()
        effective_include_history = include_history or (since is not None)
        trades_data = await paper_service.get_trade_history(limit=limit, run_id=run_id, since=since, include_history=effective_include_history)

        cutover_epoch = _get_sleeve_cutover_epoch()
        if cutover_epoch:
            for t in trades_data:
                t["sleeve_era"] = "post" if _ts_after_cutover(t.get("timestamp"), cutover_epoch) else "legacy"

        return {
            "status": "success",
            "trades": trades_data,
            "run_id": run_id or paper_service.paper_run_id,
            "include_history": effective_include_history,
            "total_trades_returned": len(trades_data),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": "sqlite_canonical",
            "sleeve_cutover_epoch": cutover_epoch,
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting paper trading trades: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/reset")
async def reset_paper_account() -> dict[str, Any]:
    """Reset paper trading account"""
    try:
        paper_service = get_paper_trading_service()
        result = await paper_service.reset_account()

        return {
            "status": "success" if (isinstance(result, dict) and result.get("success")) else "error",
            "result": result,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error resetting paper account: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/enable")
async def enable_paper_trading() -> dict[str, Any]:
    """Enable paper trading"""
    try:
        paper_service = get_paper_trading_service()
        result = await paper_service.enable_paper_trading()

        return {
            "status": "success" if (isinstance(result, dict) and result.get("success")) else "error",
            "result": result,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error enabling paper trading: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/disable")
async def disable_paper_trading() -> dict[str, Any]:
    """Disable paper trading"""
    try:
        paper_service = get_paper_trading_service()
        result = await paper_service.disable_paper_trading()

        return {
            "status": "success" if (isinstance(result, dict) and result.get("success")) else "error",
            "result": result,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error disabling paper trading: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/analytics")
async def get_paper_trading_analytics() -> dict[str, Any]:
    """Get paper trading performance analytics (alias for general analytics)"""
    try:
        paper_service = get_paper_trading_service()

        # Calculate stats from trade history (same logic as _update_stats_to_redis)
        trade_history = paper_service.trade_history
        total_trades = len(trade_history)
        winning_trades = sum(1 for t in trade_history if t.get("pnl", 0) > 0)
        losing_trades = sum(1 for t in trade_history if t.get("pnl", 0) < 0)
        total_pnl = sum(t.get("pnl", 0) for t in trade_history)
        win_rate = (winning_trades / total_trades) if total_trades > 0 else 0.0

        # Calculate advanced metrics
        sharpe_ratio = paper_service._calculate_sharpe_ratio()
        max_drawdown_pct, max_drawdown_usd = paper_service._calculate_max_drawdown()

        stats = {
            "total_trades": total_trades,
            "winning_trades": winning_trades,
            "losing_trades": losing_trades,
            "total_pnl": total_pnl,
            "win_rate": win_rate,
            "sharpe_ratio": sharpe_ratio,
            "max_drawdown_pct": max_drawdown_pct,
            "max_drawdown_usd": max_drawdown_usd,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        return {
            "status": "success",
            "stats": stats,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": "paper_trading",
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting paper trading analytics: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/analytics/by-symbol")
async def get_performance_by_symbol() -> dict[str, Any]:
    """Get performance metrics broken down by symbol (live data only)"""
    try:
        paper_service = get_paper_trading_service()
        symbol_performance = paper_service.get_performance_by_symbol()

        # Convert dict to list and sort by total_pnl
        symbols_list = list(symbol_performance.values())
        symbols_list.sort(key=lambda x: x["total_pnl"], reverse=True)

        return {
            "status": "success",
            "symbols": symbols_list,
            "total_symbols": len(symbols_list),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": "paper_trading",
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting per-symbol performance: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/feedback/stats")
async def get_paper_trading_feedback_stats() -> dict[str, Any]:
    """Get paper trading feedback service statistics including AI accuracy metrics"""

    def _raise_service_unavailable() -> None:
        raise HTTPException(status_code=503, detail="Paper trading feedback service not available")

    try:
        if paper_trading_feedback_service is None:
            _raise_service_unavailable()

        stats = await paper_trading_feedback_service.get_feedback_stats()

        return {
            "status": "success",
            "feedback_stats": stats.get("feedback_stats", {}),
            "accuracy_metrics": stats.get("accuracy_metrics", {}),
            "sentiment_metrics": stats.get("sentiment_metrics", {}),
            "active_trades": stats.get("active_trades", 0),
            "closed_trades_count": stats.get("closed_trades_count", 0),
            "samples_until_retrain": stats.get("samples_until_retrain", 0),
            "enabled": stats.get("enabled", False),
            "learning_enabled": stats.get("learning_enabled", False),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting paper trading feedback stats: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e
