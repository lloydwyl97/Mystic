"""
Portfolio Endpoints Package

Provides portfolio-related API endpoints including risk metrics.
All data is live - no fallback or hardcoded values.
"""
