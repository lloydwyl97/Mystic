"""
Portfolio Risk Metrics Endpoints

Provides live portfolio risk metrics from PortfolioService.
All data is live - no fallback or hardcoded values.
"""

from __future__ import annotations

import logging
import statistics
from typing import Any

from backend.services.portfolio_service import PortfolioService

logger = logging.getLogger(__name__)


async def get_risk_metrics() -> dict[str, Any]:
    """
    Get live portfolio risk metrics from PortfolioService.

    Returns:
        Dictionary with 'risk_metrics' key containing live risk metrics data.
        Format: {"risk_metrics": {...}}

    Raises:
        RuntimeError: If PortfolioService is unavailable or fails to get metrics.
    """
    try:
        # Get portfolio service instance
        portfolio_service = PortfolioService.shared()

        # Get live risk metrics from portfolio service
        risk_metrics = await portfolio_service.get_risk_metrics()
    except (ImportError, ModuleNotFoundError, AttributeError) as e:
        msg = f"PortfolioService not available: {e}"
        logger.exception(msg)
        raise RuntimeError(msg) from e
    except (ValueError, TypeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get portfolio risk metrics: {e}")
        msg = f"Portfolio risk metrics unavailable: {e}"
        raise RuntimeError(msg) from e
    else:
        # Ensure we have valid data
        if not isinstance(risk_metrics, dict):
            msg = "PortfolioService.get_risk_metrics() returned invalid data type"
            raise TypeError(msg)

        # Calculate additional metrics from portfolio overview if needed
        try:
            overview = await portfolio_service.get_portfolio_overview()
            total_value = float(overview.get("total_value", 0.0))
            holdings = overview.get("holdings", {})
            num_positions = len([h for h in holdings.values() if float(h.get("quantity", 0.0)) > 0.0])

            # Add portfolio-level metrics if not present
            if "total_value" not in risk_metrics:
                risk_metrics["total_value"] = total_value
            if "num_positions" not in risk_metrics:
                risk_metrics["num_positions"] = num_positions

            # Calculate position weights if needed
            if holdings and total_value > 0:
                position_values = [float(h.get("current_value", 0.0)) for h in holdings.values()]
                if position_values:
                    max_position_value = max(position_values)
                    largest_position_pct = (max_position_value / total_value * 100.0) if total_value > 0 else 0.0
                    if "largest_position_pct" not in risk_metrics:
                        risk_metrics["largest_position_pct"] = largest_position_pct

                    # Calculate weights standard deviation
                    weights = [v / total_value * 100.0 for v in position_values if total_value > 0]
                    if weights:
                        weights_stddev = statistics.stdev(weights) if len(weights) > 1 else 0.0
                        if "weights_stddev_pct" not in risk_metrics:
                            risk_metrics["weights_stddev_pct"] = weights_stddev
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as overview_error:
            logger.warning(f"Failed to get portfolio overview for additional metrics: {overview_error}")

        # Return in expected format
        return {"risk_metrics": risk_metrics}
