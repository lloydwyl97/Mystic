"""
Profit Maximization Endpoints for $1/Minute Goal

API endpoints for:
- Capital allocation engine status and control
- Performance tracker monitoring
- $1/minute goal progress visualization
- Profit reinvestment management
"""

import logging
import os
from collections.abc import Iterable
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

import backend.services.capital_allocation_engine as cae_module
import backend.services.market_timing_system as mts_module
from backend.services.advanced_metrics_dashboard import advanced_metrics_dashboard
from backend.services.performance_analytics_service import PerformanceAnalyticsService

# Services are initialized globally in app_factory
# Import will be done dynamically to avoid circular imports

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/profit-maximization", tags=["profit-maximization"])


def get_capital_allocation_engine():
    """Get the capital allocation engine instance"""
    try:
        return getattr(cae_module, "capital_allocation_engine", None)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get capital allocation engine: {e}")
        return None


def get_performance_tracker():
    """Get the performance analytics service instance (replaces deleted performance_tracker)"""
    try:
        # Use performance_analytics_service instead of deleted performance_tracker
        return PerformanceAnalyticsService()
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get performance analytics service: {e}")
        return None


def get_market_timing_system():
    """Get the market timing system instance"""
    try:
        return getattr(mts_module, "market_timing_system", None)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get market timing system: {e}")
        return None


def _get_attr_or_key(obj: Any, key: str, default: Any = None):
    """
    Helper to retrieve attribute or dict key from obj
    """
    if obj is None:
        return default
    # Try attribute
    try:
        return getattr(obj, key)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        pass
    # Try dict-like access
    try:
        if isinstance(obj, dict):
            return obj.get(key, default)
        # Some objects implement mapping protocol
        return obj[key]  # type: ignore[index]
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        return default


# Pydantic models for API responses
class AllocationSummary(BaseModel):
    """Capital allocation summary response"""

    allocation_engine: dict[str, Any]
    performance: dict[str, Any]
    recent_allocations: list[dict[str, Any]]
    target_progress: dict[str, Any]


class PerformanceReport(BaseModel):
    """Performance report response"""

    current_performance: dict[str, Any]
    targets: dict[str, Any]
    runtime: dict[str, Any]
    milestones: dict[str, Any]
    streaks: dict[str, Any]
    analytics: dict[str, Any]
    rolling_performance: dict[str, Any]


class GoalProgress(BaseModel):
    """Goal progress visualization data"""

    current_progress: float
    target: float
    progress_percent: float
    milestones_achieved: int
    next_milestone_value: float
    estimated_completion: float
    performance_trend: list[dict[str, Any]]


class PositionAllocationRequest(BaseModel):
    """Request for position allocation calculation"""

    symbol: str = Field(..., description="Trading symbol (e.g., BTCUSDT)")
    signal_confidence: float = Field(..., ge=0.0, le=1.0, description="AI signal confidence (0.0-1.0)")
    market_volatility: float = Field(..., ge=0.0, le=1.0, description="Market volatility measure (0.0-1.0)")
    current_price: float = Field(..., gt=0.0, description="Current asset price")
    available_balance: float | None = Field(None, gt=0.0, description="Available balance override")


class PerformanceUpdateRequest(BaseModel):
    """Request for performance update"""

    pnl: float = Field(..., description="Profit/Loss from trade")
    trade_count: int = Field(1, ge=1, description="Number of trades")
    is_win: bool | None = Field(None, description="Override win/loss detection")


@router.get("/allocation/summary", response_model=AllocationSummary)
async def get_allocation_summary():
    """
    Get comprehensive capital allocation summary

    Returns:
        Current allocation status, performance metrics, and strategy recommendations
    """
    try:
        capital_allocation_engine = get_capital_allocation_engine()
        if not capital_allocation_engine:
            raise HTTPException(status_code=503, detail="Capital allocation engine not initialized")

        summary = capital_allocation_engine.get_allocation_summary()
        # If summary is already a dict-like or object compatible, Pydantic will validate when returned
        return AllocationSummary(**summary) if isinstance(summary, dict) else AllocationSummary(**dict(summary))
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get allocation summary: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get allocation summary: {e!s}") from e


@router.post("/allocation/calculate")
async def calculate_position_allocation(request: PositionAllocationRequest):
    """
    Calculate optimal position size for a trade signal

    Returns:
        Recommended position allocation with reasoning
    """
    try:
        capital_allocation_engine = get_capital_allocation_engine()
        if not capital_allocation_engine:
            raise HTTPException(status_code=503, detail="Capital allocation engine not initialized")

        allocation = await capital_allocation_engine.calculate_position_size(
            symbol=request.symbol,
            signal_confidence=request.signal_confidence,
            market_volatility=request.market_volatility,
            current_price=request.current_price,
            available_balance=request.available_balance,
        )

        # Support allocation being either an object with attributes or a dict-like
        symbol = _get_attr_or_key(allocation, "symbol", request.symbol)
        position_size = _get_attr_or_key(allocation, "position_size", 0.0)
        confidence = _get_attr_or_key(allocation, "confidence", request.signal_confidence)
        volatility = _get_attr_or_key(allocation, "volatility", request.market_volatility)
        allocation_strategy = _get_attr_or_key(allocation, "allocation_strategy", None)
        # If allocation_strategy is an Enum, get its value
        if allocation_strategy is not None and not isinstance(allocation_strategy, (str, int, float)):
            allocation_strategy = getattr(allocation_strategy, "value", str(allocation_strategy))
        profit_multiplier = _get_attr_or_key(allocation, "profit_multiplier", None)
        risk_multiplier = _get_attr_or_key(allocation, "risk_multiplier", None)
        timestamp = _get_attr_or_key(allocation, "timestamp", datetime.now(timezone.utc).isoformat())
        reasoning = _get_attr_or_key(allocation, "reasoning", "")

        asset_quantity = (position_size / request.current_price) if request.current_price and request.current_price > 0 else 0.0

        allocation_engine_status_raw = capital_allocation_engine.get_allocation_summary()
        allocation_engine_status = _get_attr_or_key(
            allocation_engine_status_raw, "allocation_engine", allocation_engine_status_raw.get("allocation_engine") if isinstance(allocation_engine_status_raw, dict) else None
        )

        result = {
            "allocation": {
                "symbol": symbol,
                "position_size": position_size,
                "asset_quantity": asset_quantity,
                "confidence": confidence,
                "volatility": volatility,
                "strategy": allocation_strategy,
                "profit_multiplier": profit_multiplier,
                "risk_multiplier": risk_multiplier,
                "timestamp": timestamp,
            },
            "reasoning": reasoning,
            "allocation_engine_status": allocation_engine_status,
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to calculate position allocation: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to calculate position allocation: {e!s}") from e
    else:
        return result


@router.get("/allocation/recommendations")
async def get_allocation_recommendations():
    """
    Get AI recommendations for allocation strategy improvement

    Returns:
        List of strategy recommendations
    """
    try:
        capital_allocation_engine = get_capital_allocation_engine()
        if not capital_allocation_engine:
            raise HTTPException(status_code=503, detail="Capital allocation engine not initialized")

        recommendations = capital_allocation_engine.get_strategy_recommendations()
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get allocation recommendations: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get allocation recommendations: {e!s}") from e
    else:
        return {"recommendations": recommendations}


@router.post("/allocation/update-performance")
async def update_allocation_performance(request: PerformanceUpdateRequest):
    """
    Update capital allocation engine with trade performance

    This triggers profit milestone checks and strategy evolution
    """
    try:
        capital_allocation_engine = get_capital_allocation_engine()
        if not capital_allocation_engine:
            raise HTTPException(status_code=503, detail="Capital allocation engine not initialized")

        # Update performance
        performance = await capital_allocation_engine.update_portfolio_performance(pnl=request.pnl, trade_count=request.trade_count)

        allocation_summary_raw = capital_allocation_engine.get_allocation_summary()
        allocation_engine_status = _get_attr_or_key(allocation_summary_raw, "allocation_engine", allocation_summary_raw.get("allocation_engine") if isinstance(allocation_summary_raw, dict) else None)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to update allocation performance: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to update allocation performance: {e!s}") from e
    else:
        return {"updated_performance": performance, "allocation_status": allocation_engine_status, "milestone_check": "performed"}


@router.get("/performance/report", response_model=PerformanceReport)
async def get_performance_report():
    """
    Get comprehensive performance report

    Returns:
        Current performance metrics, targets, milestones, and analytics
    """
    try:
        performance_tracker = get_performance_tracker()
        if not performance_tracker:
            raise HTTPException(status_code=503, detail="Performance tracker not initialized")

        report = await performance_tracker.generate_performance_report()
        return PerformanceReport(**report) if isinstance(report, dict) else PerformanceReport(**dict(report))
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get performance report: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get performance report: {e!s}") from e


@router.post("/performance/update")
async def update_performance(request: PerformanceUpdateRequest):
    """
    Update performance tracker with new trade results

    Returns:
        Updated performance snapshot
    """
    try:
        performance_tracker = get_performance_tracker()
        if not performance_tracker:
            raise HTTPException(status_code=503, detail="Performance tracker not initialized")

        snapshot = await performance_tracker.update_performance(pnl=request.pnl, trade_count=request.trade_count, is_win=request.is_win)

        # Support snapshot being object or dict-like
        snapshot_dict = {}
        for key in ("timestamp", "capital", "total_pnl", "dollar_per_minute", "dollar_per_hour", "dollar_per_day", "dollar_per_year", "win_rate", "profit_ratio", "target_achievement_percent"):
            snapshot_dict[key] = _get_attr_or_key(snapshot, key)

        return {
            "snapshot": snapshot_dict,
            "goal_progress": performance_tracker.get_goal_progress_visualization(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to update performance: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to update performance: {e!s}") from e


@router.get("/performance/history")
async def get_performance_history(hours: int = Query(24, ge=1, le=168, description="Hours of history (1-168)")):
    """
    Get performance history for specified time period

    Args:
        hours: Number of hours of history to retrieve (1-168)

    Returns:
        Performance history data points
    """
    try:
        performance_tracker = get_performance_tracker()
        if not performance_tracker:
            raise HTTPException(status_code=503, detail="Performance tracker not initialized")

        history = performance_tracker.get_performance_history(hours=hours)
        # Ensure history is a list for safe consumption
        history_list = list(history) if isinstance(history, Iterable) and not isinstance(history, (str, bytes, dict)) else history
        # If it's still not a list, try to coerce
        if not isinstance(history_list, list):
            try:
                history_list = list(history)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                history_list = [history]

        return {"hours_requested": hours, "data_points": len(history_list), "history": history_list}
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get performance history: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get performance history: {e!s}") from e


@router.get("/goal/progress", response_model=GoalProgress)
async def get_goal_progress():
    """
    Get $1/minute goal progress visualization data

    Returns:
        Goal progress metrics and trend data for charts
    """
    try:
        performance_tracker = get_performance_tracker()
        if not performance_tracker:
            raise HTTPException(status_code=503, detail="Performance tracker not initialized")

        progress = performance_tracker.get_goal_progress_visualization()
        return GoalProgress(**progress) if isinstance(progress, dict) else GoalProgress(**dict(progress))
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get goal progress: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get goal progress: {e!s}") from e


@router.get("/status")
async def get_profit_maximization_status():
    """
    Get overall profit maximization system status

    Returns:
        Combined status of all profit maximization components
    """
    try:
        capital_allocation_engine = get_capital_allocation_engine()
        performance_tracker = get_performance_tracker()

        status = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "services": {
                "capital_allocation_engine": capital_allocation_engine is not None,
                "performance_tracker": performance_tracker is not None,
                "market_timing_system": get_market_timing_system() is not None,
            },
            "goal": {"target_dollar_per_minute": 1.0, "description": "$1/minute 24/7/365 profit generation"},
        }

        if capital_allocation_engine:
            allocation_summary_raw = capital_allocation_engine.get_allocation_summary()
            status["allocation_engine"] = _get_attr_or_key(
                allocation_summary_raw, "allocation_engine", allocation_summary_raw.get("allocation_engine") if isinstance(allocation_summary_raw, dict) else None
            )

        if performance_tracker:
            perf_report = await performance_tracker.generate_performance_report()
            current_perf = _get_attr_or_key(perf_report, "current_performance", perf_report.get("current_performance") if isinstance(perf_report, dict) else None) or {}
            status["current_performance"] = current_perf
            status["goal_progress"] = performance_tracker.get_goal_progress_visualization()
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get profit maximization status: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get profit maximization status: {e!s}") from e
    else:
        return status


@router.post("/reset")
async def reset_profit_maximization(password: str = Query(..., description="Admin password for reset")):
    """
    Reset all profit maximization statistics (ADMIN ONLY)

    WARNING: This will reset all performance tracking and allocation history

    Args:
        password: Admin password (would be properly secured in production)
    """
    # Validate password before try block to avoid TRY301
    admin_password = os.getenv("ADMIN_RESET_PASSWORD", "")
    if not admin_password or password != admin_password:  # Password from environment
        raise HTTPException(status_code=403, detail="Invalid password")

    try:
        capital_allocation_engine = get_capital_allocation_engine()
        performance_tracker = get_performance_tracker()

        if capital_allocation_engine:
            # Some implementations may provide sync reset; support both
            reset_fn = getattr(capital_allocation_engine, "reset_daily_limits", None)
            if reset_fn:
                if callable(reset_fn):
                    result = reset_fn()
                    if hasattr(result, "__await__"):
                        await result
                logger.warning("Capital allocation engine daily limits reset")

        if performance_tracker:
            reset_fn = getattr(performance_tracker, "reset_statistics", None)
            if reset_fn:
                if callable(reset_fn):
                    result = reset_fn()
                    if hasattr(result, "__await__"):
                        await result
                logger.warning("Performance tracker statistics reset")

        return {"status": "reset_complete", "message": "Profit maximization system has been reset", "timestamp": datetime.now(timezone.utc).isoformat()}
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to reset profit maximization system: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to reset profit maximization system: {e!s}") from e


@router.get("/metrics")
async def get_metrics():
    """
    Get key metrics using advanced metrics

    Returns:
        Essential metrics for monitoring
    """
    try:
        # Use advanced_metrics if available
        try:
            metrics_data = await advanced_metrics_dashboard.get_comprehensive_metrics()
            return {"timestamp": datetime.now(timezone.utc).isoformat(), "metrics": metrics_data, "source": "advanced_metrics"}
        except (ImportError, ModuleNotFoundError, AttributeError) as e:
            logger.warning(f"Advanced metrics not available, using fallback: {e}")

        # Fallback to original logic
        capital_allocation_engine = get_capital_allocation_engine()
        performance_tracker = get_performance_tracker()

        metrics = {"timestamp": datetime.now(timezone.utc).isoformat(), "goal_target": "$1/minute", "key_metrics": {}}

        if performance_tracker:
            report = await performance_tracker.generate_performance_report()
            current_perf = _get_attr_or_key(report, "current_performance", report.get("current_performance") if isinstance(report, dict) else None) or {}

            metrics["key_metrics"].update(
                {
                    "current_capital": _get_attr_or_key(current_perf, "capital"),
                    "dollar_per_minute": _get_attr_or_key(current_perf, "dollar_per_minute"),
                    "dollar_per_hour": _get_attr_or_key(current_perf, "dollar_per_hour"),
                    "dollar_per_day": _get_attr_or_key(current_perf, "dollar_per_day"),
                    "profit_ratio": _get_attr_or_key(current_perf, "profit_ratio"),
                    "win_rate": _get_attr_or_key(current_perf, "win_rate"),
                    "total_trades": _get_attr_or_key(current_perf, "total_trades"),
                    "progress_to_goal": _get_attr_or_key(current_perf, "target_achievement_percent"),
                }
            )

        if capital_allocation_engine:
            summary = capital_allocation_engine.get_allocation_summary()
            alloc_engine = _get_attr_or_key(summary, "allocation_engine", summary.get("allocation_engine") if isinstance(summary, dict) else None) or {}

            metrics["key_metrics"].update(
                {
                    "allocation_strategy": _get_attr_or_key(alloc_engine, "current_strategy"),
                    "available_capital": _get_attr_or_key(alloc_engine, "available_capital"),
                    "parked_profits": _get_attr_or_key(alloc_engine, "parked_profits"),
                    "profit_milestones": _get_attr_or_key(alloc_engine, "profit_milestones"),
                    "base_allocation_percent": _get_attr_or_key(alloc_engine, "base_allocation_percent"),
                }
            )
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get metrics: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get metrics: {e!s}") from e
    else:
        return metrics
