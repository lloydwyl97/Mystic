"""
Risk Endpoints

Provides a real /risk/summary endpoint (mounted at root and /api) with strict
status policy:
- 200 with live-derived metrics when available
- 204 when no data exists yet
- 503 on upstream/service failure
"""

from __future__ import annotations

import inspect
import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException

from backend.endpoints.portfolio.risk_metrics_endpoints import (  # type: ignore[import-not-found]
    get_risk_metrics,
)
from backend.modules.ai.risk_ai_optimizer import risk_ai_optimizer
from backend.services.portfolio_manager import portfolio_manager
from backend.services.risk_management_service import risk_management_service

logger = logging.getLogger(__name__)

# This router is mounted at root and /api from app_factory
router = APIRouter(prefix="/risk", tags=["risk"])


async def _maybe_await(func_or_val, *args, **kwargs):
    """Call a possibly-async or sync function/value and return its result."""
    # If it's already an awaitable (coroutine object/future), await it directly.
    if inspect.isawaitable(func_or_val):
        return await func_or_val
    if inspect.iscoroutinefunction(func_or_val):
        return await func_or_val(*args, **kwargs)
    if callable(func_or_val):
        res = func_or_val(*args, **kwargs)
        if inspect.isawaitable(res):
            return await res
        return res
    return func_or_val


def _as_float(v: Any, default: float = 0.0) -> float:
    try:
        return float(v)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        return default


def _as_int(v: Any, default: int = 0) -> int:
    try:
        return int(v)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        return default


async def _fetch_live_risk_metrics() -> dict[str, Any]:
    """
    Fetch live risk metrics via existing portfolio risk endpoint/service.
    Expected shape from get_risk_metrics(): {"risk_metrics": {...}}.
    Returns the inner dict or {}.
    """
    try:
        # Prefer the portfolio risk metrics endpoint to avoid duplication
        data = await _maybe_await(get_risk_metrics)
        if isinstance(data, dict):
            inner = data.get("risk_metrics")
            result = inner if isinstance(inner, dict) else {}
        else:
            result = {}
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        # Treat any upstream failure as service unavailable per policy
        raise HTTPException(status_code=503, detail=f"Risk metrics upstream failure: {e}") from e
    else:
        return result


@router.get("/summary")
async def get_risk_summary() -> Any:
    """
    Return concise portfolio risk summary with strict status policy.

    - 200 with metrics when data exists
    - 204 when conceptually no data yet
    - 503 on upstream/service failure
    """
    try:
        metrics = await _fetch_live_risk_metrics()

        # Determine if we have meaningful data
        total_value = _as_float(metrics.get("total_value"), 0.0)
        num_positions = _as_int(metrics.get("num_positions"), 0)

        # Always return meaningful risk summary data (never 204)
        # Provide defaults for new portfolios
        if total_value <= 0.0 and num_positions == 0:
            # New portfolio with no positions - provide baseline risk metrics
            return {
                "status": "success",
                "portfolio_risk_level": "low",
                "total_exposure_usd": 0.0,
                "daily_pnl": 0.0,
                "risk_limits_status": "within_limits",
                "largest_position_pct": 0.0,
                "portfolio_var_95": 0.0,
                "diversification_ratio": 1.0,
                "weights_stddev_pct": 0.0,
                "last_updated": datetime.now(timezone.utc).isoformat(),
                "data_source": "default_baseline",
            }

        # Return live portfolio risk summary with real data
        return {
            "status": "success",
            "portfolio_risk_level": _calculate_risk_level(metrics),
            "total_exposure_usd": total_value,
            "daily_pnl": metrics.get("daily_pnl", 0.0),
            "risk_limits_status": "within_limits",  # Could be calculated from risk limits
            "largest_position_pct": metrics.get("largest_position_pct", 0.0),
            "portfolio_var_95": metrics.get("portfolio_var_95", 0.0),
            "diversification_ratio": metrics.get("diversification_ratio", 1.0),
            "weights_stddev_pct": metrics.get("weights_stddev_pct", 0.0),
            "last_updated": datetime.now(timezone.utc).isoformat(),
            "data_source": "live_portfolio",
        }

    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Risk summary failed: {e}") from e


@router.get("/comprehensive")
async def get_risk_comprehensive() -> dict[str, Any]:
    """
    Comprehensive risk management with AI-powered insights.

    Returns complete risk assessment including:
    - Portfolio risk metrics (VaR, CVaR, diversification)
    - Individual position risk analysis
    - AI-powered risk predictions and alerts
    - Stress test scenarios
    - Dynamic risk thresholds
    """
    try:
        # Get portfolio data
        portfolio_positions = await portfolio_manager.update_portfolio_positions({})
        portfolio_metrics = await portfolio_manager.calculate_portfolio_metrics(portfolio_positions)

        # Get risk management data
        portfolio_risk = await risk_management_service.calculate_portfolio_risk(portfolio_positions)

        # Get AI risk insights
        ai_dashboard = risk_ai_optimizer.get_risk_data()

        # Get correlation matrix
        # Note: Would need symbols data for full correlation analysis

        dashboard = {
            "timestamp": ai_dashboard["timestamp"],
            "portfolio": {
                "total_value": portfolio_metrics.total_value,
                "total_pnl": portfolio_metrics.total_pnl,
                "sharpe_ratio": portfolio_metrics.sharpe_ratio,
                "sortino_ratio": portfolio_metrics.sortino_ratio,
                "max_drawdown": portfolio_metrics.max_drawdown,
                "win_rate": portfolio_metrics.win_rate,
                "diversification_ratio": portfolio_metrics.diversification_ratio,
            },
            "risk_metrics": {
                "portfolio_var_95": portfolio_risk.portfolio_var_95,
                "portfolio_cvar_95": portfolio_risk.portfolio_cvar_95,
                "concentration_risk": portfolio_risk.concentration_risk,
                "liquidity_risk": portfolio_risk.liquidity_risk,
            },
            "positions": {},
            "ai_insights": {
                "risk_predictions": ai_dashboard["risk_predictions"],
                "stress_scenarios": ai_dashboard["stress_scenarios"],
                "dynamic_thresholds": ai_dashboard["dynamic_thresholds"],
                "model_performance": ai_dashboard["model_performance"],
                "alerts": ai_dashboard["alerts"],
            },
            "recommendations": _generate_risk_recommendations(portfolio_metrics, portfolio_risk, ai_dashboard),
        }

        # Add position details
        for symbol, position in portfolio_positions.items():
            dashboard["positions"][symbol] = {
                "quantity": position.quantity,
                "current_value": position.current_value,
                "weight": position.weight,
                "volatility": position.volatility,
                "beta": position.beta,
                "unrealized_pnl": position.unrealized_pnl,
            }

    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Risk dashboard error: {e}") from e
    else:
        return dashboard


@router.get("/portfolio/analysis")
async def get_portfolio_risk_analysis() -> dict[str, Any]:
    """
    Detailed portfolio risk analysis with optimization recommendations.

    Returns:
    - Current portfolio composition and risk metrics
    - Optimization suggestions
    - Rebalancing recommendations
    - Risk-adjusted performance analysis
    """
    try:
        # Get current portfolio
        portfolio_positions = await portfolio_manager.update_portfolio_positions({})
        portfolio_metrics = await portfolio_manager.calculate_portfolio_metrics(portfolio_positions)

        # Check if rebalancing is needed
        portfolio_risk = await risk_management_service.calculate_portfolio_risk(portfolio_positions)
        rebalance_needed, adjustments = await portfolio_manager.check_rebalance_needed(portfolio_positions)

        analysis = {
            "current_portfolio": {
                "total_value": portfolio_metrics.total_value,
                "total_positions": len(portfolio_positions),
                "diversification_score": portfolio_metrics.diversification_ratio,
                "sharpe_ratio": portfolio_metrics.sharpe_ratio,
                "max_drawdown": portfolio_metrics.max_drawdown,
            },
            "risk_assessment": {
                "portfolio_var_95": portfolio_risk.portfolio_var_95,
                "concentration_risk": portfolio_risk.concentration_risk,
                "overall_risk_level": _assess_overall_risk_level(portfolio_risk),
            },
            "rebalancing": {
                "needed": rebalance_needed,
                "adjustments": adjustments,
                "target_weights": portfolio_manager.target_weights,
            },
            "positions_analysis": {},
        }

        # Analyze individual positions
        for symbol, position in portfolio_positions.items():
            position_analysis = {
                "current_weight": position.weight,
                "target_weight": portfolio_manager.target_weights.get(symbol, 0.0),
                "deviation": abs(position.weight - portfolio_manager.target_weights.get(symbol, position.weight)),
                "volatility_contribution": position.volatility * position.weight,
                "beta_contribution": position.beta * position.weight,
                "risk_adjusted_return": position.unrealized_pnl / (position.volatility + 0.001),  # Avoid division by zero
            }
            analysis["positions_analysis"][symbol] = position_analysis

    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Portfolio analysis error: {e}") from e
    else:
        return analysis


@router.post("/portfolio/optimize")
async def optimize_portfolio(symbols: list[str] | None = None, constraints: dict[str, Any] | None = None) -> dict[str, Any]:
    """
    Optimize portfolio using Modern Portfolio Theory with live market data.

    Args:
        symbols: List of symbols to consider (optional, uses all available if not provided)
        constraints: Optimization constraints (min/max weights, etc.)

    Returns:
        Portfolio optimization results with recommended weights and expected performance
    """
    try:
        if not symbols:
            # Use default symbols if not specified
            symbols = ["BTCUSDT", "ETHUSDT", "ADAUSDT", "SOLUSDT", "DOGEUSDT", "XRPUSDT", "BCHUSDT", "LTCUSDT", "AVAXUSDT", "LINKUSDT"]

        # Get live market data for optimization
        market_data = {}  # Would need to fetch live data from market service

        # Note: This is a placeholder - would need actual market data integration
        # For now, return a basic optimization result
        result = await portfolio_manager.optimize_portfolio(symbols, market_data, constraints)

        return {
            "optimization_result": {
                "optimal_weights": result.optimal_weights,
                "expected_return": result.expected_return,
                "expected_volatility": result.expected_volatility,
                "sharpe_ratio": result.sharpe_ratio,
                "status": result.optimization_status,
            },
            "recommendations": _generate_optimization_recommendations(result),
        }

    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Portfolio optimization error: {e}") from e


@router.post("/stress-test")
async def run_stress_test(num_scenarios: int = 5) -> dict[str, Any]:
    """
    Run AI-powered stress test scenarios on current portfolio.

    Args:
        num_scenarios: Number of stress scenarios to generate

    Returns:
        Stress test results with scenario impacts and recommendations
    """
    try:
        # Get current portfolio
        portfolio_positions = await portfolio_manager.update_portfolio_positions({})

        # Convert positions to required format
        portfolio_data = {}
        for symbol, position in portfolio_positions.items():
            portfolio_data[symbol] = {
                "size": position.weight,
                "current_value": position.current_value,
                "volatility": position.volatility,
            }

        # Generate stress scenarios
        scenarios = await risk_ai_optimizer.generate_stress_scenarios(portfolio_data, num_scenarios)

        stress_results = {
            "scenarios": [],
            "portfolio_impact_summary": {
                "worst_case_impact": min((s.portfolio_impact for s in scenarios), default=0.0),
                "average_impact": sum(s.portfolio_impact for s in scenarios) / len(scenarios) if scenarios else 0.0,
                "high_probability_scenarios": len([s for s in scenarios if s.probability > 0.1]),
            },
        }

        # Format scenarios for API response
        for scenario in scenarios:
            stress_results["scenarios"].append(
                {
                    "name": scenario.scenario_name,
                    "description": scenario.description,
                    "portfolio_impact": scenario.portfolio_impact,
                    "probability": scenario.probability,
                    "shock_magnitudes": scenario.shock_magnitudes,
                    "recommended_actions": scenario.recommended_actions,
                }
            )

    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Stress test error: {e}") from e
    else:
        return stress_results


@router.get("/alerts")
async def get_risk_alerts() -> dict[str, Any]:
    """
    Get current risk alerts and warnings.

    Returns:
        Active risk alerts with severity levels and recommended actions
    """
    try:
        ai_dashboard = risk_ai_optimizer.get_risk_dashboard_data()

        alerts = {
            "timestamp": ai_dashboard["timestamp"],
            "alerts": ai_dashboard["alerts"],
            "alert_summary": {
                "total_alerts": len(ai_dashboard["alerts"]),
                "high_severity": len([a for a in ai_dashboard["alerts"] if a.get("severity") == "high"]),
                "medium_severity": len([a for a in ai_dashboard["alerts"] if a.get("severity") == "medium"]),
                "low_severity": len([a for a in ai_dashboard["alerts"] if a.get("severity") == "low"]),
            },
        }

    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Risk alerts error: {e}") from e
    else:
        return alerts


@router.post("/position/sizing")
async def calculate_position_size(symbol: str, account_balance: float, _risk_tolerance: float = 0.02) -> dict[str, Any]:
    """
    Calculate optimal position size using advanced risk management.

    Args:
        symbol: Trading symbol
        account_balance: Current account balance
        risk_tolerance: Maximum risk per trade (as % of account)

    Returns:
        Position sizing recommendations with risk analysis
    """
    try:
        # Get symbol risk metrics
        risk_metrics = await risk_management_service.calculate_symbol_risk_metrics(symbol, {})

        # Get portfolio risk for context
        portfolio_positions = await portfolio_manager.update_portfolio_positions({})
        portfolio_risk = await risk_management_service.calculate_portfolio_risk(portfolio_positions)

        # Calculate optimal position size
        optimal_size = await risk_management_service.calculate_optimal_position_size(symbol, account_balance, risk_metrics, portfolio_risk)

        # Assess trade risk
        trade_risk = await risk_management_service.assess_trade_risk(symbol, optimal_size, "buy", portfolio_positions)

        return {
            "symbol": symbol,
            "recommended_size": optimal_size,
            "recommended_value": optimal_size * account_balance,
            "risk_metrics": {
                "volatility": risk_metrics.volatility_1d,
                "var_95": risk_metrics.value_at_risk_95,
                "expected_loss": risk_metrics.expected_shortfall_95,
            },
            "portfolio_context": {
                "current_risk": portfolio_risk.portfolio_var_95,
                "diversification": portfolio_risk.diversification_ratio,
                "concentration": portfolio_risk.concentration_risk,
            },
            "trade_assessment": trade_risk,
        }

    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Position sizing error: {e}") from e


# ===== HELPER FUNCTIONS =====


def _calculate_risk_level(metrics: dict[str, Any]) -> str:
    """Calculate overall risk level from metrics."""
    try:
        portfolio_var = metrics.get("portfolio_var_95", 0.0)
        concentration = metrics.get("concentration_risk", 0.0)
        diversification = metrics.get("diversification_ratio", 1.0)

        # Risk scoring
        risk_score = 0.0

        if portfolio_var > 0.05:  # >5% daily VaR
            risk_score += 0.4
        elif portfolio_var > 0.03:
            risk_score += 0.2

        if concentration > 0.25:  # >25% in single position
            risk_score += 0.3
        elif concentration > 0.15:
            risk_score += 0.15

        if diversification < 0.6:  # Poor diversification
            risk_score += 0.3
        elif diversification < 0.8:
            risk_score += 0.15

        # Determine risk level
        if risk_score > 0.6:
            return "high"
        elif risk_score > 0.3:
            return "medium"
        else:
            return "low"

    except Exception:
        return "unknown"


def _generate_risk_recommendations(portfolio_metrics, portfolio_risk, ai_dashboard) -> list[str]:
    """Generate risk management recommendations."""
    recommendations = []

    try:
        # Portfolio-level recommendations
        if portfolio_risk.portfolio_var_95 > 0.05:
            recommendations.append("Consider reducing position sizes to lower portfolio VaR below 5%")

        if portfolio_risk.diversification_ratio < 0.6:
            recommendations.append("Increase diversification by adding more uncorrelated assets")

        if portfolio_risk.concentration_risk > 0.25:
            recommendations.append("Reduce concentration risk by decreasing largest position sizes")

        # AI-based recommendations
        alerts = ai_dashboard.get("alerts", [])
        for alert in alerts:
            if alert.get("severity") in ["high", "medium"]:
                recommendations.append(f"{alert.get('type', 'Risk')}: {alert.get('recommended_action', 'Monitor closely')}")

        # Sharpe ratio recommendations
        if portfolio_metrics.sharpe_ratio < 1.0:
            recommendations.append("Consider adjusting strategy to improve risk-adjusted returns")

        # Maximum recommendations
        return recommendations[:5]  # Limit to top 5

    except Exception:
        return ["Monitor portfolio risk metrics regularly", "Consider consulting risk management guidelines"]


def _assess_overall_risk_level(portfolio_risk) -> str:
    """Assess overall portfolio risk level."""
    try:
        risk_score = 0.0

        if portfolio_risk.portfolio_var_95 > 0.05:
            risk_score += 0.4
        if portfolio_risk.concentration_risk > 0.2:
            risk_score += 0.3
        if portfolio_risk.diversification_ratio < 0.7:
            risk_score += 0.3

        if risk_score > 0.6:
            return "high"
        elif risk_score > 0.3:
            return "medium"
        else:
            return "low"

    except Exception:
        return "unknown"


def _generate_optimization_recommendations(optimization_result) -> list[str]:
    """Generate recommendations based on optimization results."""
    recommendations = []

    try:
        if optimization_result.optimization_status == "success":
            sharpe = optimization_result.sharpe_ratio
            if sharpe > 2.0:
                recommendations.append("Excellent risk-adjusted returns expected")
            elif sharpe > 1.0:
                recommendations.append("Good risk-adjusted returns expected")
            else:
                recommendations.append("Consider adjusting constraints for better risk-return profile")

            # Check concentration
            weights = optimization_result.optimal_weights
            max_weight = max(weights.values()) if weights else 0.0
            if max_weight > 0.3:
                recommendations.append("High concentration in single asset - consider diversification constraints")

        else:
            recommendations.append("Optimization completed with constraints - review results carefully")

    except Exception:
        return ["Review optimization results with risk management guidelines"]
    else:
        return recommendations


@router.get("/limits")
async def get_risk_limits() -> dict[str, Any]:
    """
    Get current risk limits and thresholds.

    Returns position limits, loss limits, and risk thresholds.
    """
    try:
        # Get risk limits from risk management service
        limits_data = {}

        if risk_management_service is not None:
            try:
                # Try to get position limits
                position_limits = await risk_management_service.get_position_limits()
                limits_data["position_limits"] = position_limits or {}
            except Exception as e:
                logger.warning(f"Could not get position limits: {e}")
                limits_data["position_limits"] = {}

            try:
                # Try to get loss limits
                loss_limits = await risk_management_service.get_loss_limits()
                limits_data["loss_limits"] = loss_limits or {}
            except Exception as e:
                logger.warning(f"Could not get loss limits: {e}")
                limits_data["loss_limits"] = {}
        else:
            limits_data["position_limits"] = {}
            limits_data["loss_limits"] = {}

        # Add default limits if none available
        if not limits_data["position_limits"]:
            limits_data["position_limits"] = {"max_position_size_usd": 1000.0, "max_single_asset_pct": 20.0, "max_portfolio_risk_pct": 5.0}

        if not limits_data["loss_limits"]:
            limits_data["loss_limits"] = {"max_daily_loss_pct": 2.0, "max_total_loss_pct": 10.0, "stop_loss_trigger_pct": 1.0}

        return {"status": "success", "limits": limits_data, "timestamp": datetime.now(timezone.utc).isoformat(), "source": "risk_management_service"}

    except Exception as e:
        logger.exception(f"Failed to get risk limits: {e}")
        # Return default limits on error
        return {
            "status": "error",
            "limits": {
                "position_limits": {"max_position_size_usd": 1000.0, "max_single_asset_pct": 20.0, "max_portfolio_risk_pct": 5.0},
                "loss_limits": {"max_daily_loss_pct": 2.0, "max_total_loss_pct": 10.0, "stop_loss_trigger_pct": 1.0},
            },
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }


@router.get("/exposure")
async def get_risk_exposure() -> dict[str, Any]:
    """
    Get current portfolio risk exposure.

    Returns position exposure, risk metrics, and exposure analysis.
    """
    try:
        # Get risk exposure from risk management service
        exposure_data = {}

        if risk_management_service is not None:
            try:
                # Try to get portfolio exposure
                portfolio_exposure = await risk_management_service.get_portfolio_exposure()
                exposure_data["portfolio_exposure"] = portfolio_exposure or {}
            except Exception as e:
                logger.warning(f"Could not get portfolio exposure: {e}")
                exposure_data["portfolio_exposure"] = {}

            try:
                # Try to get risk metrics
                risk_metrics = await risk_management_service.get_risk_metrics()
                exposure_data["risk_metrics"] = risk_metrics or {}
            except Exception as e:
                logger.warning(f"Could not get risk metrics: {e}")
                exposure_data["risk_metrics"] = {}
        else:
            exposure_data["portfolio_exposure"] = {}
            exposure_data["risk_metrics"] = {}

        # Add default exposure data if none available
        if not exposure_data["portfolio_exposure"]:
            exposure_data["portfolio_exposure"] = {"total_exposure_usd": 0.0, "largest_position_usd": 0.0, "concentration_risk_pct": 0.0, "currency_exposure": {}}

        if not exposure_data["risk_metrics"]:
            exposure_data["risk_metrics"] = {"var_95": 0.0, "expected_shortfall": 0.0, "beta_to_market": 1.0, "sharpe_ratio": 0.0}

        # Calculate risk level
        risk_level = "low"
        if exposure_data["portfolio_exposure"].get("concentration_risk_pct", 0) > 30:
            risk_level = "high"
        elif exposure_data["portfolio_exposure"].get("concentration_risk_pct", 0) > 15:
            risk_level = "medium"

        return {"status": "success", "exposure": exposure_data, "risk_level": risk_level, "timestamp": datetime.now(timezone.utc).isoformat(), "source": "risk_management_service"}

    except Exception as e:
        logger.exception(f"Failed to get risk exposure: {e}")
        # Return default exposure data on error
        return {
            "status": "error",
            "exposure": {
                "portfolio_exposure": {"total_exposure_usd": 0.0, "largest_position_usd": 0.0, "concentration_risk_pct": 0.0, "currency_exposure": {}},
                "risk_metrics": {"var_95": 0.0, "expected_shortfall": 0.0, "beta_to_market": 1.0, "sharpe_ratio": 0.0},
            },
            "risk_level": "unknown",
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
