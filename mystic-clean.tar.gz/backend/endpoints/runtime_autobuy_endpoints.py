#!/usr/bin/env python3
"""
Runtime Autobuy Endpoints

Exposes secure toggle_live, status, paper step, take_profits, metrics, and profit parking.
Uses API-key auth via backend.backend.security_enhancements.SecurityMiddleware-compatible header X-API-Key.
"""

from __future__ import annotations

import inspect
import logging
import os
from time import time
from typing import Any

logger = logging.getLogger(__name__)

from fastapi import APIRouter, Depends, Header, HTTPException

from backend.security_enhancements import security_middleware
from backend.services import risk_limits as rl
from backend.services.admin_auth import require_admin_key
from backend.services.profit_parking import (
    park_profit_usd,
)
from backend.services.runtime_autobuy import get_engine
from backend.services.slack_notify import send_slack
from backend.services.totp import verify_totp

router = APIRouter(prefix="/api/runtime", tags=["runtime-autobuy"])


def _require_api_key(x_api_key: str = Header(None)) -> None:
    # Minimal check: rely on upstream SecurityMiddleware for full validation when globally enabled.
    if not x_api_key:
        raise HTTPException(status_code=401, detail="Missing X-API-Key")


@router.get("/status")
async def runtime_status() -> dict[str, Any]:
    eng = get_engine()
    return {
        "live": eng.settings.live,
        "allocation_pct": eng.settings.allocation_pct,
        "paper_metrics": eng.paper.metrics(),
        "last_signals": getattr(eng, "last_signals", []),
        "last_executed": getattr(eng, "last_executed", []),
    }


_dual_toggle_state: dict[str, Any] = {"pending": None, "expires": 0}


@router.post("/toggle_live")
async def toggle_live(
    payload: dict[str, Any],
    x_api_key: str = Header(None),
    _: None = Depends(require_admin_key),
) -> dict[str, Any]:
    """Securely toggle live trading on/off.
    Body: {"live": true|false, "confirm": bool}
    Requires two separate calls with different API keys within a short window if enabling live.
    """
    eng = get_engine()
    if not isinstance(payload, dict) or "live" not in payload:
        raise HTTPException(status_code=400, detail="Missing 'live' boolean field")
    val = bool(payload.get("live"))
    confirm = bool(payload.get("confirm", False))

    if val:
        # dual-control arm then confirm within 5 minutes by a second key
        now = int(time())
        if not confirm:
            _dual_toggle_state["pending"] = {"key": x_api_key}
            _dual_toggle_state["expires"] = now + 300
            return {
                "ok": True,
                "message": "Pending confirmation required from a different API key within 5 minutes",
            }
        # confirm path
        if now > int(_dual_toggle_state.get("expires", 0)):
            raise HTTPException(status_code=409, detail="Toggle confirmation window expired")
        if not _dual_toggle_state.get("pending"):
            raise HTTPException(status_code=409, detail="No pending toggle to confirm")
        first_key = _dual_toggle_state["pending"]["key"]
        if not x_api_key or x_api_key == first_key:
            raise HTTPException(status_code=403, detail="Second distinct API key required to confirm")
        # optional TOTP requirement
        totp_secret = os.getenv("LIVE_TOGGLE_TOTP_SECRET", "")
        if totp_secret:
            code = payload.get("totp")
            if not code or not verify_totp(code, totp_secret, window=1, period=30, digits=6):
                raise HTTPException(status_code=401, detail="Invalid TOTP code")
        # success
        _dual_toggle_state["pending"] = None
        _dual_toggle_state["expires"] = 0
        eng.settings.live = True
        try:
            res = send_slack(":white_check_mark: LIVE ENABLED", {"blocks": []})
            if inspect.isawaitable(res):
                await res
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Slack notify failed on live enable: %s", e)
            raise
    else:
        # disable live immediately
        eng.settings.live = False
        _dual_toggle_state["pending"] = None
        _dual_toggle_state["expires"] = 0
    # Audit log to security system if available
    try:
        ev = security_middleware.audit_logger.log_event(
            event_type="toggle_live",
            user_id="api",
            ip_address="127.0.0.1",
            endpoint="/api/runtime/toggle_live",
            method="POST",
            details={"live": val, "pending": bool(_dual_toggle_state.get("pending"))},
            severity="high" if val else "medium",
            status="success",
        )
        if inspect.isawaitable(ev):
            await ev
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Audit log failed on toggle_live: %s", e)
        raise
    return {"ok": True, "live": eng.settings.live}


@router.post("/paper/step")
async def paper_step() -> dict[str, Any]:
    eng = get_engine()
    return await eng.step()


@router.get("/signals/preview")
async def signals_preview(top_n: int = 10) -> dict[str, Any]:
    eng = get_engine()
    sigs = await eng.preview_signals(top_n=top_n)
    return {"signals": sigs, "count": len(sigs)}


@router.post("/paper/take_profits")
async def paper_take_profits() -> dict[str, Any]:
    eng = get_engine()
    return {"results": await eng.try_take_profits()}


@router.get("/paper/metrics")
async def paper_metrics() -> dict[str, Any]:
    eng = get_engine()
    return eng.paper.metrics()


@router.get("/risk/status")
async def risk_status() -> dict[str, Any]:
    try:
        return {
            "caps": {
                "MAX_DAILY_NOTIONAL_USD": rl.MAX_DAILY_NOTIONAL_USD,
                "MAX_PER_TRADE_USD": rl.MAX_PER_TRADE_USD,
                "MAX_SYMBOL_EXPOSURE_PCT": rl.MAX_SYMBOL_EXPOSURE_PCT,
                "MAX_SLIPPAGE_PCT": rl.MAX_SLIPPAGE_PCT,
                "MAX_DAILY_DRAWDOWN_PCT": rl.MAX_DAILY_DRAWDOWN_PCT,
            },
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/park_profit")
async def park_profit(payload: dict[str, Any], _: None = Depends(_require_api_key)) -> dict[str, Any]:
    if not isinstance(payload, dict):
        payload = {}
    amt = float(payload.get("amount_usd", 0) or 0)
    if amt <= 0:
        raise HTTPException(status_code=400, detail="amount_usd must be positive")

    # Use park_profit_usd function (imported at top level)
    res = park_profit_usd(amt)
    return res if isinstance(res, dict) else {"success": False, "error": "unexpected"}
