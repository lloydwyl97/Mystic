from __future__ import annotations

import contextlib
import ipaddress
import os
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

import jwt
from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import Boolean, DateTime, Integer, String, Text
from sqlalchemy.orm import Mapped, declarative_base, mapped_column

from backend.services.db import get_engine, get_sessionmaker

# -----------------------------
# Config
# -----------------------------

JWT_SECRET = os.getenv("JWT_SECRET", "dev-secret-change-me")
JWT_ALGO = "HS256"

# Cap session durations to avoid runaway tokens
MIN_SESSION_HOURS = 1
MAX_SESSION_HOURS = int(os.getenv("SECURITY_MAX_SESSION_HOURS", "168") or "168")  # <= 7 days default

# -----------------------------
# DB setup
# -----------------------------

Base = declarative_base()
ENGINE = get_engine()
SessionLocal = get_sessionmaker(ENGINE)


class IPWhitelist(Base):
    __tablename__ = "ip_whitelist"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ip: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    description: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))


class SessionToken(Base):
    __tablename__ = "session_tokens"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[str] = mapped_column(String(128), index=True)
    token: Mapped[str] = mapped_column(Text, unique=True, index=True)
    valid: Mapped[bool] = mapped_column(Boolean, default=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))


class SecurityLog(Base):
    __tablename__ = "security_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    event: Mapped[str] = mapped_column(String(64))
    detail: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)


def _init_tables() -> None:
    # Safe/idempotent; OK to call on import and per-request as fallback
    Base.metadata.create_all(ENGINE)


# Initialize tables at import (keeps first-hit latencies down)
with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
    # Non-fatal; endpoints will attempt again
    _init_tables()

# -----------------------------
# Helpers
# -----------------------------


def _log(event: str, detail: str = "") -> None:
    try:
        with SessionLocal() as s:
            s.add(SecurityLog(event=event, detail=detail))
            s.commit()
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        # Logging must never break endpoints
        pass


def _create_jwt(user_id: str, expires_at: datetime) -> str:
    payload = {
        "sub": user_id,
        "exp": int(expires_at.timestamp()),
        "iat": int(datetime.now(timezone.utc).timestamp()),
        "jti": uuid.uuid4().hex,
    }
    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGO)
    # PyJWT may return bytes in some versions; ensure str
    if isinstance(token, bytes):
        token = token.decode("utf-8")
    return token


def _verify_jwt(token: str) -> bool:
    try:
        jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGO])
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        return False
    else:
        return True


def _normalize_ip(raw: str) -> tuple[str, str]:
    """
    Normalize and validate an IP or CIDR.
    Returns (normalized_ip, type_str) where type_str in {"ip", "cidr"}.
    Raises HTTPException 400 on invalid input.
    """
    ip_s = (raw or "").strip()
    if not ip_s:
        raise HTTPException(status_code=400, detail="ip is required")

    # Try exact IP first (IPv4/IPv6)
    try:
        ip_obj = ipaddress.ip_address(ip_s)
        # Use compressed form for IPv6; str() is already normalized
        return (str(ip_obj), "ip")
    except ValueError:
        pass

    # Try CIDR network (IPv4/IPv6)
    try:
        net_obj = ipaddress.ip_network(ip_s, strict=False)
        return (str(net_obj), "cidr")
    except ValueError as e:
        raise HTTPException(
            status_code=400,
            detail="ip must be a valid IP address or CIDR (e.g., 192.0.2.0/24)",
        ) from e


def _cap_session_hours(h: int) -> int:
    if h < MIN_SESSION_HOURS:
        return MIN_SESSION_HOURS
    if h > MAX_SESSION_HOURS:
        return MAX_SESSION_HOURS
    return h


router = APIRouter(prefix="/security", tags=["Security"])

# -----------------------------
# IP Whitelist
# -----------------------------


@router.get("/ip-whitelist")
async def get_ip_whitelist(ip: str | None = Query(None)) -> Any:
    """
    If 'ip' query param provided, return {"whitelisted": bool}.
    Else, return a list of whitelist entries with metadata.
    """
    try:
        _init_tables()
        with SessionLocal() as s:
            if ip:
                try:
                    norm, _ = _normalize_ip(ip)
                except HTTPException:
                    # If invalid IP, it's certainly not whitelisted
                    return {"whitelisted": False}

                exists = s.query(IPWhitelist).filter(IPWhitelist.ip == norm).first() is not None
                return {"whitelisted": bool(exists)}

            # Return all entries (most recent first)
            rows = s.query(IPWhitelist).order_by(IPWhitelist.created_at.desc()).all()
            return [
                {
                    "ip": r.ip,
                    "description": r.description,
                    "created_at": r.created_at.isoformat(),
                }
                for r in rows
            ]
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        raise HTTPException(status_code=500, detail=f"Failed to get whitelist: {e}") from e


@router.post("/ip-whitelist")
async def add_ip_whitelist(payload: dict[str, Any]) -> dict[str, Any]:
    """
    Add an IP or CIDR to the whitelist.
    Body: {"ip": "...", "description": "..."}.
    """
    try:
        _init_tables()
        ip_raw = str(payload.get("ip", "")).strip()
        description = str(payload.get("description", "")).strip()
        norm_ip, _ = _normalize_ip(ip_raw)

        with SessionLocal() as s:
            existing = s.query(IPWhitelist).filter(IPWhitelist.ip == norm_ip).one_or_none()
            if existing is None:
                s.add(IPWhitelist(ip=norm_ip, description=description))
                s.commit()
        _log("ip_add", norm_ip)
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        raise HTTPException(status_code=500, detail=f"Failed to add IP: {e}") from e
    else:
        return {"success": True}


@router.delete("/ip-whitelist/{ip:path}")
async def delete_ip_whitelist(ip: str) -> dict[str, Any]:
    """
    Remove an IP or CIDR from the whitelist.
    Path param must match the normalized stored form (this function normalizes it).
    """
    try:
        _init_tables()
        norm_ip, _ = _normalize_ip(ip)
        with SessionLocal() as s:
            s.query(IPWhitelist).filter(IPWhitelist.ip == norm_ip).delete()
            s.commit()
        _log("ip_remove", norm_ip)
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        raise HTTPException(status_code=500, detail=f"Failed to remove IP: {e}") from e
    else:
        return {"success": True}


# -----------------------------
# Sessions (JWT + DB tracking)
# -----------------------------


@router.post("/session")
async def create_session(payload: dict[str, Any]) -> dict[str, Any]:
    """
    Create a session token for a given user_id.
    Body: {"user_id": "...", "duration_hours": 24}
    """
    # Validate user_id before try block to avoid TRY301
    user_id = str(payload.get("user_id", "")).strip()
    if not user_id:
        raise HTTPException(status_code=400, detail="user_id is required")

    try:
        _init_tables()

        # duration clamp
        try:
            duration_hours = int(payload.get("duration_hours", 24))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            duration_hours = 24
        duration_hours = _cap_session_hours(duration_hours)

        expires_at = datetime.now(timezone.utc) + timedelta(hours=duration_hours)
        token = _create_jwt(user_id, expires_at)

        with SessionLocal() as s:
            s.add(SessionToken(user_id=user_id, token=token, valid=True, expires_at=expires_at))
            s.commit()

        _log("session_create", user_id)
        return {"token": token, "expires_at": expires_at.isoformat()}
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        raise HTTPException(status_code=500, detail=f"Failed to create session: {e}") from e


@router.delete("/session")
async def invalidate_session(payload: dict[str, Any]) -> dict[str, Any]:
    """
    Invalidate a session token (soft delete).
    Body: {"token": "..."}
    """
    # Validate token before try block to avoid TRY301
    token = str(payload.get("token", "")).strip()
    if not token:
        raise HTTPException(status_code=400, detail="token is required")

    try:
        _init_tables()

        with SessionLocal() as s:
            row = s.query(SessionToken).filter(SessionToken.token == token).one_or_none()
            if row:
                row.valid = False
                s.commit()

        _log("session_invalidate", token[:8])
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        raise HTTPException(status_code=500, detail=f"Failed to invalidate session: {e}") from e
    else:
        return {"success": True}


@router.post("/verify-session")
async def verify_session(payload: dict[str, Any]) -> dict[str, Any]:
    """
    Verify a session token against both JWT validity and DB 'valid' flag + expiry.
    Body: {"token": "..."}
    """
    try:
        _init_tables()
        token = str(payload.get("token", "")).strip()
        if not token or not _verify_jwt(token):
            return {"valid": False}

        now = datetime.now(timezone.utc)
        with SessionLocal() as s:
            row = s.query(SessionToken).filter(SessionToken.token == token, SessionToken.valid.is_(True)).one_or_none()
            if not row or row.expires_at <= now:
                return {"valid": False}
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        # Never leak decode errors or DB errors here
        return {"valid": False}
    else:
        return {"valid": True}


@router.get("/sessions")
async def list_sessions() -> list[dict[str, Any]]:
    """List active (valid & unexpired) sessions (token not included)."""
    try:
        _init_tables()
        now = datetime.now(timezone.utc)
        with SessionLocal() as s:
            rows = s.query(SessionToken).filter(SessionToken.valid.is_(True), SessionToken.expires_at > now).order_by(SessionToken.created_at.desc()).all()
            return [
                {
                    "user_id": r.user_id,
                    "token_start": r.created_at.isoformat(),
                    "expires_at": r.expires_at.isoformat(),
                }
                for r in rows
            ]
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        raise HTTPException(status_code=500, detail=f"Failed to list sessions: {e}") from e


# -----------------------------
# Logs & Metrics
# -----------------------------


@router.get("/logs")
async def get_logs(days: int = Query(7)) -> list[dict[str, Any]]:
    """Fetch recent security logs (max 500)."""
    try:
        _init_tables()
        cutoff = datetime.now(timezone.utc) - timedelta(days=max(1, days))
        with SessionLocal() as s:
            rows = s.query(SecurityLog).filter(SecurityLog.created_at >= cutoff).order_by(SecurityLog.created_at.desc()).limit(500).all()
            return [{"event": r.event, "detail": r.detail, "ts": r.created_at.isoformat()} for r in rows]
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch logs: {e}") from e


@router.get("/metrics")
async def get_metrics() -> dict[str, Any]:
    """Aggregate counts: whitelist entries, active sessions, total logs."""
    try:
        _init_tables()
        now = datetime.now(timezone.utc)
        with SessionLocal() as s:
            total_whitelist = s.query(IPWhitelist).count()
            active_sessions = s.query(SessionToken).filter(SessionToken.valid.is_(True), SessionToken.expires_at > now).count()
            total_logs = s.query(SecurityLog).count()
        return {
            "total_whitelist": int(total_whitelist),
            "active_sessions": int(active_sessions),
            "total_logs": int(total_logs),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch metrics: {e}") from e
