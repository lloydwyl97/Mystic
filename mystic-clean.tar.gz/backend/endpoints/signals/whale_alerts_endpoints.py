"""
Whale Alerts Endpoints

Provides live whale alerts with ingest endpoints, backed by in-memory TTL service.
Patched with:
- UTF-8 stdout/stderr safety (Windows emoji-safe)
- IPv4-only DNS resolver (helps with httpx/binance quirks)
- Resilient import + safe in-memory fallback for whale_alert_service
"""

from __future__ import annotations

# --- Windows-safe stdout/stderr (avoid emoji crashes) ---
import sys

try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
    pass

# --- Force IPv4 DNS resolution early (httpx/httpcore + OS sockets) ---
try:
    import socket as _socket

    _orig_getaddrinfo = getattr(_socket, "getaddrinfo", None)

    def _ipv4_getaddrinfo(host, port, family=0, sock_type=0, proto=0, flags=0):  # type: ignore[override]
        try:
            return _orig_getaddrinfo(host, port, _socket.AF_INET, sock_type, proto, flags)  # type: ignore[misc]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            return _orig_getaddrinfo(host, port, family, sock_type, proto, flags)  # type: ignore[misc]

    if callable(_orig_getaddrinfo):
        _socket.getaddrinfo = _ipv4_getaddrinfo
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
    pass

import logging
from collections import deque
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException, Query

# Try real service; otherwise provide a minimal in-memory fallback
try:
    from backend.services.whale_alert_service import whale_alert_service  # type: ignore[import-not-found]

    _HAS_REAL_SERVICE = True
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
    _HAS_REAL_SERVICE = False

    class _WhaleAlertServiceFallback:
        """Simple in-memory whale alert store with bounded history."""

        def __init__(self, maxlen: int = 2000) -> None:
            self._alerts: deque[dict[str, Any]] = deque(maxlen=maxlen)

        def get_alerts(self, limit: int = 200) -> list[dict[str, Any]]:
            limit = max(1, min(int(limit), 1000))
            # Return newest first
            return list(self._alerts)[-limit:][::-1]

        def ingest(self, alert: dict[str, Any]) -> None:
            if not isinstance(alert, dict):
                return
            a = dict(alert)
            a.setdefault("timestamp", datetime.now(timezone.utc).isoformat())
            a.setdefault("source", "fallback")
            self._alerts.append(a)

        def bulk_ingest(self, alerts: list[dict[str, Any]]) -> int:
            count = 0
            if not isinstance(alerts, list):
                return 0
            for item in alerts:
                if isinstance(item, dict):
                    self.ingest(item)
                    count += 1
            return count

    whale_alert_service = _WhaleAlertServiceFallback()  # type: ignore[assignment]

router = APIRouter(prefix="/api/whale", tags=["signals"])
logger = logging.getLogger(__name__)


@router.get("/alerts")
async def get_whale_alerts(limit: int = Query(200, ge=1, le=1000)) -> dict[str, Any]:
    """
    Return most recent whale alerts (newest first).
    """
    try:
        alerts = whale_alert_service.get_alerts(limit=limit)  # type: ignore[attr-defined]
        # Normalize to list[dict]
        if not isinstance(alerts, list):
            alerts = []
        ts = datetime.now(timezone.utc).isoformat()
        return {
            "alerts": alerts,
            "count": len(alerts),
            "timestamp": ts,
            "backend": "real" if _HAS_REAL_SERVICE else "fallback",
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.warning(f"/api/whale/alerts error: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch whale alerts") from e


@router.post("/alerts/ingest")
async def ingest_whale_alert(alert: dict[str, Any]) -> dict[str, Any]:
    """
    Ingest a single whale alert (opaque dict). Adds timestamp if missing.
    """
    # Validate alert type before try block to avoid TRY301
    if not isinstance(alert, dict):
        raise HTTPException(status_code=400, detail="Invalid alert payload")

    try:
        # Ensure a timestamp exists
        alert = dict(alert)
        alert.setdefault("timestamp", datetime.now(timezone.utc).isoformat())
        whale_alert_service.ingest(alert)  # type: ignore[attr-defined]
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"whale alert ingest failed: {e}")
        raise HTTPException(status_code=500, detail="Failed to ingest alert") from e
    else:
        return {"ok": True, "backend": "real" if _HAS_REAL_SERVICE else "fallback"}


@router.post("/alerts/ingest_bulk")
async def ingest_bulk_whale_alerts(payload: dict[str, Any]) -> dict[str, Any]:
    """
    Ingest multiple whale alerts in one call.

    Body:
    {
      "alerts": [ { ... }, { ... }, ... ]
    }
    """
    # Validate payload type before try block to avoid TRY301
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Invalid payload")

    try:
        alerts_any: Any | None = payload.get("alerts")
        alerts: list[dict[str, Any]] = alerts_any if isinstance(alerts_any, list) else []
        # Ensure timestamps
        now_iso = datetime.now(timezone.utc).isoformat()
        prepared: list[dict[str, Any]] = []
        for a in alerts:
            if isinstance(a, dict):
                d = dict(a)
                d.setdefault("timestamp", now_iso)
                prepared.append(d)
        count = whale_alert_service.bulk_ingest(prepared)  # type: ignore[attr-defined]
        return {
            "ok": True,
            "ingested": int(count),
            "backend": "real" if _HAS_REAL_SERVICE else "fallback",
        }
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"whale alert bulk ingest failed: {e}")
        raise HTTPException(status_code=500, detail="Failed to bulk ingest alerts") from e
