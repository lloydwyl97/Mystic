#!/usr/bin/env python3
"""
Social Trading API Endpoints
REST API for social trading features
"""

import logging
from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from backend.auth import get_current_user
from backend.services.social_trading_service import get_social_trading_service

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/social", tags=["social-trading"])

# Module-level dependency to avoid function call in default argument
_get_current_user_dep = Depends(get_current_user)


# Pydantic models for request/response
class UserCreateRequest(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: str = Field(..., pattern=r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
    display_name: str | None = Field(None, max_length=100)
    bio: str = ""
    avatar_url: str | None = None


class UserStatsUpdateRequest(BaseModel):
    total_trades: int | None = None
    win_rate: float | None = None
    total_pnl: float | None = None
    total_pnl_percentage: float | None = None
    best_trade: float | None = None
    worst_trade: float | None = None
    avg_trade_duration: float | None = None
    sharpe_ratio: float | None = None
    max_drawdown: float | None = None


class StrategyCreateRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    description: str = Field(..., max_length=1000)
    strategy_type: str = Field(..., pattern=r"^(manual|ai|hybrid)$")
    symbol: str = Field(..., min_length=1, max_length=20)
    timeframe: str = Field(..., pattern=r"^(1m|5m|15m|1h|4h|1D)$")
    config: dict[str, Any] = Field(default_factory=dict)
    indicators: list[str] = Field(default_factory=list)
    entry_conditions: dict[str, Any] = Field(default_factory=dict)
    exit_conditions: dict[str, Any] = Field(default_factory=dict)
    is_public: bool = True


class StrategyPerformanceUpdateRequest(BaseModel):
    total_trades: int | None = None
    win_rate: float | None = None
    total_pnl: float | None = None
    total_pnl_percentage: float | None = None
    sharpe_ratio: float | None = None
    max_drawdown: float | None = None
    calmar_ratio: float | None = None


class CopyTradeCreateRequest(BaseModel):
    leader_id: int = Field(..., gt=0)
    strategy_id: int = Field(..., gt=0)
    allocation_percentage: float = Field(100.0, ge=0.1, le=100.0)
    max_position_size: float | None = Field(None, gt=0)


class PostCreateRequest(BaseModel):
    content: str = Field(..., min_length=1, max_length=5000)
    post_type: str = Field("insight", pattern=r"^(insight|analysis|strategy|market_update)$")
    symbol: str | None = Field(None, max_length=20)
    strategy_id: int | None = Field(None, gt=0)


# User endpoints
@router.post("/users", response_model=dict[str, Any])
async def create_user(request: UserCreateRequest):
    """Create a new user profile"""
    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    user: dict[str, Any] | None = await service.create_user(username=request.username, email=request.email, display_name=request.display_name, bio=request.bio, avatar_url=request.avatar_url)

    if not user:
        raise HTTPException(status_code=409, detail="User already exists or creation failed")

    return user


@router.get("/users/{user_id}", response_model=dict[str, Any])
async def get_user(user_id: int):
    """Get user profile by ID"""
    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    user = await service.get_user_by_id(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    return user


@router.get("/users/by-username/{username}", response_model=dict[str, Any])
async def get_user_by_username(username: str):
    """Get user profile by username"""
    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    user = await service.get_user_by_username(username)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    return user


@router.put("/users/{user_id}/stats", response_model=dict[str, bool])
async def update_user_stats(user_id: int, request: UserStatsUpdateRequest):
    """Update user trading statistics"""
    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    stats = request.dict(exclude_unset=True)
    success = await service.update_user_stats(user_id, stats)

    if not success:
        raise HTTPException(status_code=404, detail="User not found or update failed")

    return {"success": True}


# Strategy endpoints
@router.post("/strategies", response_model=dict[str, Any])
async def create_strategy(request: StrategyCreateRequest, current_user: dict = _get_current_user_dep):
    """Create a new trading strategy"""
    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    # Get authenticated user ID from JWT token
    author_id = current_user.get("user_id")
    if not author_id:
        raise HTTPException(status_code=401, detail="User ID not found in token")

    strategy: dict[str, Any] | None = await service.create_strategy(
        author_id=author_id,
        name=request.name,
        description=request.description,
        strategy_type=request.strategy_type,
        symbol=request.symbol,
        timeframe=request.timeframe,
        config=request.config,
        indicators=request.indicators,
        entry_conditions=request.entry_conditions,
        exit_conditions=request.exit_conditions,
        is_public=request.is_public,
    )

    if not strategy:
        raise HTTPException(status_code=400, detail="Strategy creation failed")

    return strategy


@router.get("/strategies/{strategy_id}", response_model=dict[str, Any])
async def get_strategy(strategy_id: int):
    """Get strategy by ID"""
    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    strategy = await service.get_strategy_by_id(strategy_id)
    if not strategy:
        raise HTTPException(status_code=404, detail="Strategy not found")

    return strategy


@router.get("/strategies", response_model=list[dict[str, Any]])
async def get_public_strategies(
    limit: int = Query(50, ge=1, le=100), offset: int = Query(0, ge=0), sort_by: str = Query("created_at", pattern=r"^(created_at|likes_count|win_rate|total_pnl_percentage)$")
):
    """Get public strategies with pagination"""
    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    return await service.get_public_strategies(limit=limit, offset=offset, sort_by=sort_by)


@router.put("/strategies/{strategy_id}/performance", response_model=dict[str, bool])
async def update_strategy_performance(strategy_id: int, request: StrategyPerformanceUpdateRequest):
    """Update strategy performance metrics"""
    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    performance = request.dict(exclude_unset=True)
    success = await service.update_strategy_performance(strategy_id, performance)

    if not success:
        raise HTTPException(status_code=404, detail="Strategy not found or update failed")

    return {"success": True}


# Social interaction endpoints
@router.post("/users/{user_id}/follow", response_model=dict[str, bool])
async def follow_user(user_id: int, target_user_id: int = Body(..., embed=True)):
    """Follow a user"""
    if user_id == target_user_id:
        raise HTTPException(status_code=400, detail="Cannot follow yourself")

    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    success = await service.follow_user(user_id, target_user_id)
    if not success:
        raise HTTPException(status_code=400, detail="Follow failed")

    return {"success": True}


@router.delete("/users/{user_id}/follow/{target_user_id}", response_model=dict[str, bool])
async def unfollow_user(user_id: int, target_user_id: int):
    """Unfollow a user"""
    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    success = await service.unfollow_user(user_id, target_user_id)
    if not success:
        raise HTTPException(status_code=400, detail="Unfollow failed")

    return {"success": True}


@router.post("/strategies/{strategy_id}/like", response_model=dict[str, bool])
async def like_strategy(strategy_id: int, user_id: int = Body(..., embed=True)):
    """Like a strategy"""
    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    success = await service.like_strategy(user_id, strategy_id)
    if not success:
        raise HTTPException(status_code=400, detail="Like failed")

    return {"success": True}


@router.post("/strategies/{strategy_id}/follow", response_model=dict[str, bool])
async def follow_strategy(strategy_id: int, user_id: int = Body(..., embed=True)):
    """Follow a strategy for updates"""
    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    success = await service.follow_strategy(user_id, strategy_id)
    if not success:
        raise HTTPException(status_code=400, detail="Follow failed")

    return {"success": True}


# Leaderboard and traders endpoints
# DISABLED: Conflicting with routes/social.py leaderboard endpoint
# @router.get("/leaderboard", response_model=list[dict[str, Any]])
# async def get_leaderboard(
#     *,
#     period: str = Query(
#         "monthly",
#         pattern=r"^(daily|weekly|monthly|all_time)$",
#     ),
#     category: str = Query(
#         "pnl",
#         pattern=r"^(pnl|win_rate|sharpe_ratio|followers)$",
#     ),
#     limit: int = Query(100, ge=1, le=500),
# ):
#     """Get leaderboard rankings"""
#     service = get_social_trading_service()
#     if not service:
#         raise HTTPException(status_code=503, detail="Social trading service not available")
#
#     return await service.get_leaderboard(_period=period, category=category, limit=limit)


# DISABLED: Conflicting with routes/social.py traders endpoint
# @router.get("/traders", response_model=list[dict[str, Any]])
# async def get_traders(limit: int = Query(50, ge=1, le=500)):
#     """Get top traders for dashboard"""
#     service = get_social_trading_service()
#     if not service:
#         raise HTTPException(status_code=503, detail="Social trading service not available")
#
#     return await service.get_leaderboard(_period="all_time", category="pnl", limit=limit)


@router.get("/performance", response_model=dict[str, Any])
async def get_social_performance():
    """Get overall social trading performance metrics"""
    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    leaderboard = await service.get_leaderboard(_period="monthly", category="pnl", limit=100)

    return {
        "total_traders": len(leaderboard),
        "total_strategies": len(leaderboard),
        "top_performers": leaderboard[:10],
        "average_performance": sum(t.get("pnl", 0) for t in leaderboard) / len(leaderboard) if leaderboard else 0,
    }


# Copy trading endpoints
@router.get("/copy-trades", response_model=list[dict[str, Any]])
async def get_copy_trades():
    """Get all active copy trading relationships for dashboard"""
    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    try:
        trades = await service.get_copy_trades(active_only=True)
    except Exception as exc:
        logger.exception("Failed to fetch copy trading relationships: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to fetch copy trades") from exc

    return trades


@router.post("/copy-trading", response_model=dict[str, Any])
async def start_copy_trading(request: CopyTradeCreateRequest, current_user: dict = _get_current_user_dep):
    """Start copy trading relationship"""
    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    # Get authenticated user ID from JWT token
    follower_id = current_user.get("user_id")
    if not follower_id:
        raise HTTPException(status_code=401, detail="User ID not found in token")

    copy_trade = await service.start_copy_trading(
        follower_id=follower_id, leader_id=request.leader_id, strategy_id=request.strategy_id, allocation_percentage=request.allocation_percentage, max_position_size=request.max_position_size
    )

    if not copy_trade:
        raise HTTPException(status_code=409, detail="Copy trading relationship already exists or creation failed")

    return copy_trade


@router.delete("/copy-trading/{copy_trade_id}", response_model=dict[str, bool])
async def stop_copy_trading(copy_trade_id: int):
    """Stop copy trading relationship"""
    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    success = await service.stop_copy_trading(copy_trade_id)
    if not success:
        raise HTTPException(status_code=404, detail="Copy trading relationship not found")

    return {"success": True}


# Social posts endpoints
@router.post("/posts", response_model=dict[str, Any])
async def create_post(request: PostCreateRequest, current_user: dict = _get_current_user_dep):
    """Create a social post"""
    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    # Get authenticated user ID from JWT token
    author_id = current_user.get("user_id")
    if not author_id:
        raise HTTPException(status_code=401, detail="User ID not found in token")

    post = await service.create_post(author_id=author_id, content=request.content, post_type=request.post_type, symbol=request.symbol, strategy_id=request.strategy_id)

    if not post:
        raise HTTPException(status_code=400, detail="Post creation failed")

    return post


@router.get("/feed", response_model=list[dict[str, Any]])
async def get_feed(user_id: int | None = Query(None, gt=0), limit: int = Query(50, ge=1, le=100), offset: int = Query(0, ge=0)):
    """Get social feed (posts from followed users)"""
    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    return await service.get_feed(user_id=user_id, limit=limit, offset=offset)


@router.get("/posts", response_model=list[dict[str, Any]])
async def get_posts(limit: int = Query(50, ge=1, le=100), offset: int = Query(0, ge=0)):
    """Get social trading posts (alias for feed)"""
    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    return await service.get_feed(user_id=None, limit=limit, offset=offset)


@router.get("/stats", response_model=dict[str, Any])
async def get_social_stats():
    """Get social trading statistics"""
    service = get_social_trading_service()
    if not service:
        raise HTTPException(status_code=503, detail="Social trading service not available")

    try:
        # Try to get stats from service, fallback to basic stats if not available
        stats = await service.get_stats()
    except AttributeError:
        # Fallback: provide basic social trading stats
        stats = {
            "total_users": 0,
            "total_strategies": 0,
            "total_posts": 0,
            "active_traders": 0,
            "total_follows": 0,
            "total_likes": 0,
        }
    else:
        return stats

    return stats


# Health endpoint DELETED - use /healthz from app_factory.py

# Export the router
social_trading_router = router
