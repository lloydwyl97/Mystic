"""
Stablecoin Parking/Portfolio Management - LIVE DATA
Manages USDT allocation and stable parking
"""

import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter

from backend.services.market_data import MarketDataService
from backend.services.paper_trading_service import get_paper_trading_service

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Stablecoin"])


@router.get("/api/stablecoin/balance")
async def get_stablecoin_balance() -> dict[str, Any]:
    """Get current stablecoin (USDT) balance"""
    try:
        # Try paper trading first
        paper = get_paper_trading_service()
        account = await paper.get_account_balance()

        usdt_balance = account.get("cash_balance", 0.0)
        positions_value = account.get("positions_value", 0.0)
        total_value = account.get("total_value", 0.0)

        # Calculate allocation percentages
        cash_pct = (usdt_balance / total_value * 100) if total_value > 0 else 100
        position_pct = (positions_value / total_value * 100) if total_value > 0 else 0

        return {
            "status": "success",
            "usdt_balance": usdt_balance,
            "positions_value": positions_value,
            "total_value": total_value,
            "allocation": {"cash_percent": round(cash_pct, 2), "positions_percent": round(position_pct, 2), "in_stablecoin": usdt_balance, "in_positions": positions_value},
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "source": "paper_trading",
        }
    except Exception as e:
        logger.exception(f"Stablecoin balance error: {e}")
        return {"status": "error", "error": str(e), "timestamp": datetime.now(timezone.utc).isoformat()}


@router.post("/api/stablecoin/park")
async def park_to_stablecoin(amount: float) -> dict[str, Any]:
    """Park funds in stablecoin (sell positions, increase USDT)"""
    try:
        if amount <= 0:
            return {"status": "error", "error": "Amount must be positive", "timestamp": datetime.now(timezone.utc).isoformat()}

        # For now, this is a placeholder for parking logic
        # In real implementation, would sell positions to reach target USDT amount
        _ = get_paper_trading_service()  # Future: use for selling positions

        return {"status": "success", "message": f"Parking ${amount} to USDT (placeholder - implement sell logic)", "target_amount": amount, "timestamp": datetime.now(timezone.utc).isoformat()}
    except Exception as e:
        logger.exception(f"Park error: {e}")
        return {"status": "error", "error": str(e), "timestamp": datetime.now(timezone.utc).isoformat()}


@router.get("/api/stablecoin/recommendation")
async def get_parking_recommendation() -> dict[str, Any]:
    """Get AI recommendation for stablecoin parking based on market conditions"""
    try:
        mds = MarketDataService.shared()
        paper = get_paper_trading_service()

        if not mds or not mds.cache:
            return {"status": "no_data", "recommendation": "hold", "confidence": 0}

        # Calculate market sentiment
        negative = sum(1 for d in mds.cache.values() if float(d.get("change_24h", 0)) < -3)
        total = len(mds.cache)
        bearish_pct = (negative / total * 100) if total > 0 else 0

        # Get current allocation
        account = await paper.get_account_balance()
        cash_balance = account.get("cash_balance", 0.0)
        total_value = account.get("total_value", 0.0)
        cash_pct = (cash_balance / total_value * 100) if total_value > 0 else 100

        # Recommendation logic
        if bearish_pct > 60 and cash_pct < 50:
            recommendation = "park_more"
            reason = f"Market is {bearish_pct:.0f}% bearish, increase stable allocation"
            target_cash_pct = 70
        elif bearish_pct < 30 and cash_pct > 70:
            recommendation = "deploy_more"
            reason = "Market improving, deploy more capital from stable"
            target_cash_pct = 40
        else:
            recommendation = "hold"
            reason = "Current allocation is appropriate for market conditions"
            target_cash_pct = cash_pct

        return {
            "status": "success",
            "recommendation": recommendation,
            "current_cash_percent": round(cash_pct, 2),
            "target_cash_percent": target_cash_pct,
            "market_sentiment": "bearish" if bearish_pct > 50 else "bullish",
            "bearish_coins_percent": round(bearish_pct, 2),
            "reason": reason,
            "confidence": 75,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:
        logger.exception(f"Parking recommendation error: {e}")
        return {"status": "error", "error": str(e), "timestamp": datetime.now(timezone.utc).isoformat()}
