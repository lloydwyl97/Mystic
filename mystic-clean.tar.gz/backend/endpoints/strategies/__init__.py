"""
Strategy Endpoints Package
Contains API endpoints for strategy management and execution.
"""

from fastapi import APIRouter

router = APIRouter(tags=["Strategies"])

__all__ = ["router"]
