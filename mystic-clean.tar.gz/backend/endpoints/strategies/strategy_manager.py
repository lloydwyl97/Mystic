"""
Strategy Manager
Manages all strategy controllers.
"""

from __future__ import annotations

import logging
from typing import Any

from backend.crypto_autoengine_config import get_config
from backend.services.ai_live_engine import (  # type: ignore[import-not-found]
    AILiveEngine,
    enable_ai_live_engine_for_strategy_stack,
)
from backend.services.ai_monitoring_service import AIMonitoringService  # type: ignore[import-not-found]
from backend.services.ai_processor_service import AIProcessorService  # type: ignore[import-not-found]
from backend.services.ai_strategy_generator_service import (
    AIStrategyGeneratorService,
)  # type: ignore[import-not-found]
from backend.services.data_collector import DataCollector  # type: ignore[import-not-found]
from backend.services.data_storage import DataStorage  # type: ignore[import-not-found]
from backend.services.data_validator import DataValidator  # type: ignore[import-not-found]
from backend.utils.exceptions import StrategyError

from .strategy_controller import StrategyController  # type: ignore[import-not-found]

logger = logging.getLogger(__name__)

logger = logging.getLogger(__name__)


def _safe_running(obj: Any) -> bool:
    try:
        return bool(getattr(obj, "running", False))
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        return False


class StrategyManager:
    """Manages all strategy controllers."""

    def __init__(
        self,
        cache=None,
        data_collector: Any | None = None,
        data_validator: Any | None = None,
        data_storage: Any | None = None,
        live_engine: Any | None = None,
        strategy_service: Any | None = None,
        processor_service: Any | None = None,
        config: Any | None = None,
    ) -> None:
        self.cache = cache
        self.config: Any = config or get_config()
        if self.config is None:
            msg = "AI config is not available (config is None)."
            raise RuntimeError(msg)

        # Build AI plumbing with graceful fallbacks
        self.data_collector = data_collector or (DataCollector(config=self.config) if DataCollector else None)
        self.data_validator = data_validator or (DataValidator(config=self.config) if DataValidator else None)
        self.data_storage = data_storage or (DataStorage(config=self.config) if DataStorage else None)

        if live_engine is not None:
            self.live_engine = live_engine
        elif AILiveEngine and enable_ai_live_engine_for_strategy_stack():
            self.live_engine = AILiveEngine(
                data_collector=self.data_collector,
                data_validator=self.data_validator,
                data_storage=self.data_storage,
                config=self.config,
            )
        else:
            self.live_engine = None

        if strategy_service is not None:
            self.strategy_service = strategy_service
        elif AIStrategyGeneratorService:
            self.strategy_service = AIStrategyGeneratorService(
                data_collector=self.data_collector,
                data_validator=self.data_validator,
                data_storage=self.data_storage,
                live_engine=self.live_engine,
                config=self.config,
            )
        else:
            self.strategy_service = None

        if processor_service is not None:
            self.processor_service = processor_service
        elif AIProcessorService:
            self.processor_service = AIProcessorService(
                cache=self.cache,
                data_collector=self.data_collector,
                data_validator=self.data_validator,
                data_storage=self.data_storage,
                live_engine=self.live_engine,
                strategy_service=self.strategy_service,
                config=self.config,
            )
        else:
            self.processor_service = None

        if AIMonitoringService:
            self.monitoring_service = AIMonitoringService(
                cache=self.cache,
                data_collector=self.data_collector,
                data_validator=self.data_validator,
                data_storage=self.data_storage,
                live_engine=self.live_engine,
                strategy_service=self.strategy_service,
                processor_service=self.processor_service,
                config=self.config,
            )
        else:
            self.monitoring_service = None

        # Controllers
        self.controllers: dict[str, StrategyController] = {}
        try:
            coins = list(self.config.get_enabled_coins())  # type: ignore[attr-defined]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            # Fallback if config doesn't expose .get_enabled_coins()
            coins = getattr(self.config, "coins", []) or []

        for coin_cfg in coins:
            try:
                symbol = getattr(coin_cfg, "symbol", None) or getattr(coin_cfg, "ticker", None)
                if not symbol:
                    continue
                self.controllers[symbol] = StrategyController(
                    symbol=symbol,
                    cache=self.cache,
                    ai_generator=self.strategy_service,
                    config=self.config,
                )
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.warning(f"Failed to create StrategyController for coin: {e}")

        logger.info(f"Strategy manager initialized with {len(self.controllers)} controllers")
        # Back-compat attribute expected by tests
        self.ai_generator = self.strategy_service

    # --- Lifecycle ----------------------------------------------------------

    async def start(self) -> None:
        """Start the manager and underlying services."""
        logger.info("[START] Starting strategy manager...")
        try:
            # Start order: engine -> strategy generator -> processor -> monitoring
            if self.live_engine and hasattr(self.live_engine, "initialize"):
                await self.live_engine.initialize()

            if self.strategy_service and hasattr(self.strategy_service, "start"):
                await self.strategy_service.start()

            if self.processor_service and hasattr(self.processor_service, "start"):
                await self.processor_service.start()

            if self.monitoring_service and hasattr(self.monitoring_service, "start"):
                await self.monitoring_service.start()

            logger.info("[OK] Strategy manager started")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as error:
            logger.exception(f"[ERROR] Failed to start strategy manager: {error}")
            raise

    async def stop(self) -> None:
        """Stop the manager and underlying services."""
        logger.info("[STOP] Stopping strategy manager...")
        errors: list[str] = []
        try:
            # Stop order: processor -> strategy generator -> engine -> monitoring (if long-running)
            try:
                if self.processor_service and hasattr(self.processor_service, "stop"):
                    await self.processor_service.stop()
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                errors.append(f"processor_service.stop: {e}")

            try:
                if self.strategy_service and hasattr(self.strategy_service, "stop"):
                    await self.strategy_service.stop()
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                errors.append(f"strategy_service.stop: {e}")

            try:
                if self.live_engine and hasattr(self.live_engine, "shutdown"):
                    await self.live_engine.shutdown()
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                errors.append(f"live_engine.shutdown: {e}")

            try:
                # Some monitoring services might be long-running tasks; stop if supported
                if self.monitoring_service and hasattr(self.monitoring_service, "stop"):
                    await self.monitoring_service.stop()  # type: ignore[attr-defined]
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                errors.append(f"monitoring_service.stop: {e}")

            if errors:
                logger.warning("Strategy manager stopped with warnings: " + " | ".join(errors))
                raise StrategyError("; ".join(errors))
            logger.info("[OK] Strategy manager stopped")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as error:
            logger.exception(f"[ERROR] Failed to stop strategy manager: {error}")
            raise

    # --- Execution ----------------------------------------------------------

    async def run_all_strategies(self) -> dict[str, Any]:
        """Run strategies for all coins and update cache with signal data."""
        # Ensure generator is running for tests that call without explicit start
        try:
            if self.strategy_service and not _safe_running(self.strategy_service) and hasattr(self.strategy_service, "start"):
                await self.strategy_service.start()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            pass
        results: dict[str, Any] = {}
        for symbol, controller in self.controllers.items():
            try:
                coin_data = self.cache.get_coin_cache(symbol)
                if not coin_data:
                    continue

                result = await controller.apply_ai_strategy(coin_data)
                if not result:
                    continue

                signals = [s.model_dump() for s in result]
                timestamp = result[0].timestamp if result else None
                payload = {
                    "signals": signals,
                    "timestamp": timestamp,
                    "ai_strategy_loaded": True,
                    "ai_signals_count": len(result),
                }
                results[symbol] = payload

                # Cache update (guarded)
                try:
                    if hasattr(self.cache, "update_strategy_signals"):
                        self.cache.update_strategy_signals(symbol, payload)  # type: ignore[attr-defined]
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.debug(f"Cache update failed for {symbol}: {e}")

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as error:
                logger.exception(f"Error running strategies for {symbol}: {error}")

        return results

    async def run_coin_strategies(self, symbol: str) -> dict[str, Any] | None:
        """Run strategies for a specific coin and update cache."""
        # Ensure generator is running when invoked directly
        try:
            if self.strategy_service and not _safe_running(self.strategy_service) and hasattr(self.strategy_service, "start"):
                await self.strategy_service.start()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            pass
        controller = self.controllers.get(symbol)
        if not controller:
            return None

        try:
            coin_data = self.cache.get_coin_cache(symbol)
            if not coin_data:
                return None

            result = await controller.apply_ai_strategy(coin_data)
            if not result:
                return None

            signals = [s.model_dump() for s in result]
            timestamp = result[0].timestamp if result else None
            payload = {
                "signals": signals,
                "timestamp": timestamp,
                "ai_strategy_loaded": True,
                "ai_signals_count": len(result),
            }

            try:
                if hasattr(self.cache, "update_strategy_signals"):
                    self.cache.update_strategy_signals(symbol, payload)  # type: ignore[attr-defined]
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.debug(f"Cache update failed for {symbol}: {e}")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as error:
            logger.exception(f"Error running strategies for {symbol}: {error}")
            return None
        else:
            return payload

    # --- Status -------------------------------------------------------------

    def get_strategy_status(self) -> dict[str, Any]:
        """Get status across all strategy components and controllers."""
        status = {
            "total_controllers": len(self.controllers),
            "active_controllers": sum(1 for _ in self.controllers.values()),
            "symbols": list(self.controllers.keys()),
            "live_engine_running": _safe_running(self.live_engine),
            "strategy_service_running": _safe_running(self.strategy_service),
            "processor_service_running": _safe_running(self.processor_service),
            "monitoring_service_running": _safe_running(self.monitoring_service),
        }
        # Include alias key expected by tests
        status["ai_generator_running"] = status["strategy_service_running"]
        return status
