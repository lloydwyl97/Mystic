from __future__ import annotations

import contextlib
import json
import logging
import os
import shutil
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np

logger = logging.getLogger(__name__)

# Strategy reaper constants
REAPER_MIN_NAP = 1.0  # Minimum sleep time between iterations (seconds)
REAPER_INTERVAL = 300.0  # Full cycle interval (5 minutes)

# === Configuration ===
REAPER_DB = Path(os.getenv("STRATEGY_REAPER_DB", "./data/strategy_reaper.db"))
STRATEGY_DIR = Path("./strategies")
GENERATED_DIR = Path("./generated_modules")
BACKUP_DIR = Path("./strategy_backups")

PERFORMANCE_THRESHOLD = 0.10  # 10% minimum performance
MAX_STRATEGIES = 50  # Max number of strategies to keep
MIN_TRADES = 5  # Minimum trades for evaluation

# === Helpers ===


def _utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _parse_iso_dt(value: str) -> datetime | None:
    try:
        # Handles 'YYYY-MM-DDTHH:MM:SS[.ffffff][+HH:MM or Z]'
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        return None


# === Database Layer ===


class ReaperDatabase:
    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.init_database()

    @contextlib.contextmanager
    def _connect(self):
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.execute("PRAGMA synchronous=NORMAL;")
            yield conn
        finally:
            conn.close()

    def init_database(self) -> None:
        """Initialize reaper database and tables if they don't exist."""
        with self._connect() as conn:
            cur = conn.cursor()

            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS strategy_performance (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    strategy_name TEXT NOT NULL,
                    strategy_type TEXT NOT NULL,
                    total_trades INTEGER NOT NULL,
                    win_rate REAL NOT NULL,
                    avg_profit REAL NOT NULL,
                    total_profit REAL NOT NULL,
                    max_drawdown REAL NOT NULL,
                    sharpe_ratio REAL NOT NULL,
                    last_trade_date TEXT,
                    created_date TEXT NOT NULL,
                    status TEXT NOT NULL,
                    performance_score REAL NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
                """,
            )

            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS reaper_actions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    action_type TEXT NOT NULL,
                    strategy_name TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    performance_data TEXT NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
                """,
            )

            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS strategy_lifecycle (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    strategy_name TEXT NOT NULL,
                    phase TEXT NOT NULL,
                    start_date TEXT NOT NULL,
                    end_date TEXT,
                    performance_metrics TEXT NOT NULL,
                    notes TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
                """,
            )

            conn.commit()

    def save_strategy_performance(self, performance: dict[str, Any]) -> None:
        """Save strategy performance to database."""
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(
                """
                INSERT INTO strategy_performance
                (strategy_name, strategy_type, total_trades, win_rate, avg_profit, total_profit,
                 max_drawdown, sharpe_ratio, last_trade_date, created_date, status, performance_score)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    performance["strategy_name"],
                    performance["strategy_type"],
                    int(performance["total_trades"]),
                    float(performance["win_rate"]),
                    float(performance["avg_profit"]),
                    float(performance["total_profit"]),
                    float(performance["max_drawdown"]),
                    float(performance["sharpe_ratio"]),
                    performance.get("last_trade_date"),
                    performance["created_date"],
                    performance["status"],
                    float(performance["performance_score"]),
                ),
            )
            conn.commit()

    def save_reaper_action(self, action: dict[str, Any]) -> None:
        """Save reaper action to database."""
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(
                """
                INSERT INTO reaper_actions
                (timestamp, action_type, strategy_name, reason, performance_data)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    action["timestamp"],
                    action["action_type"],
                    action["strategy_name"],
                    action["reason"],
                    json.dumps(action["performance_data"]),
                ),
            )
            conn.commit()

    def save_lifecycle_event(self, lifecycle: dict[str, Any]) -> None:
        """Save strategy lifecycle event."""
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(
                """
                INSERT INTO strategy_lifecycle
                (strategy_name, phase, start_date, end_date, performance_metrics, notes)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    lifecycle["strategy_name"],
                    lifecycle["phase"],
                    lifecycle["start_date"],
                    lifecycle.get("end_date"),
                    json.dumps(lifecycle["performance_metrics"]),
                    lifecycle.get("notes"),
                ),
            )
            conn.commit()

    def get_latest_strategy_performance(self, strategy_name: str) -> dict[str, Any] | None:
        """Fetch the most recent performance row for a strategy by created_at (or id) DESC."""
        with self._connect() as conn:
            cur = conn.cursor()
            # NOTE: the original query ordered by a non-existent 'timestamp' column.
            # Use created_at (or id) instead for recency.
            cur.execute(
                """
                SELECT strategy_name, total_trades, win_rate, avg_profit, total_profit,
                       max_drawdown, sharpe_ratio, performance_score, status, created_date, created_at
                FROM strategy_performance
                WHERE strategy_name = ?
                ORDER BY datetime(created_at) DESC, id DESC
                LIMIT 1
                """,
                (strategy_name,),
            )
            row = cur.fetchone()
            if row:
                return {
                    "strategy_name": row[0],
                    "total_trades": row[1],
                    "win_rate": row[2],
                    "avg_profit": row[3],
                    "total_profit": row[4],
                    "max_drawdown": row[5],
                    "sharpe_ratio": row[6],
                    "performance_score": row[7],
                    "status": row[8],
                    "created_date": row[9],
                    "created_at": row[10],
                }
            return None


# === Strategy File Discovery ===


def get_strategy_files() -> list[Path]:
    """Get all strategy files (.json in strategies, .py in generated modules)."""
    files: list[Path] = []
    if STRATEGY_DIR.exists():
        files.extend([p for p in STRATEGY_DIR.iterdir() if p.is_file() and p.suffix == ".json"])
    if GENERATED_DIR.exists():
        files.extend([p for p in GENERATED_DIR.iterdir() if p.is_file() and p.suffix == ".py"])
    return files


# === Performance Analysis ===


def analyze_strategy_performance(strategy_file: Path) -> dict[str, Any] | None:
    """Analyze strategy performance by reading the latest DB entry for this strategy."""
    strategy_name = strategy_file.name
    db = ReaperDatabase(REAPER_DB)
    return db.get_latest_strategy_performance(strategy_name)


def calculate_adaptive_thresholds(performances: list[dict[str, Any]]) -> dict[str, Any]:
    """Calculate adaptive thresholds based on current performance distribution."""
    if not performances:
        return {
            "performance_threshold": PERFORMANCE_THRESHOLD,
            "min_trades": MIN_TRADES,
            "max_strategies": MAX_STRATEGIES,
        }

    # Stats
    scores = [float(p["performance_score"]) for p in performances]
    trades = [int(p["total_trades"]) for p in performances]

    # Adaptive
    performance_threshold = max(PERFORMANCE_THRESHOLD, float(np.percentile(scores, 25)))
    min_trades = max(MIN_TRADES, int(np.percentile(trades, 10)))
    max_strategies = min(MAX_STRATEGIES, len(performances) + 10)

    return {
        "performance_threshold": performance_threshold,
        "min_trades": min_trades,
        "max_strategies": max_strategies,
    }


def evaluate_strategy_lifecycle(performance: dict[str, Any]) -> str:
    """Evaluate strategy lifecycle phase."""
    score = float(performance["performance_score"])
    trades = int(performance["total_trades"])

    # Prefer created_date; fallback to created_at; fallback to "now - 0"
    created_iso = performance.get("created_date") or performance.get("created_at") or _utcnow_iso()
    created_dt = _parse_iso_dt(created_iso) or datetime.now(timezone.utc)
    age_days = (datetime.now(timezone.utc) - created_dt).days

    if score > 0.8 and trades > 20:
        return "mature"
    if score > 0.6 and trades > 10:
        return "developing"
    if score > 0.4 and trades > 5:
        return "testing"
    if age_days > 30 and score < 0.3:
        return "declining"
    return "new"


def should_reap_strategy(performance: dict[str, Any], thresholds: dict[str, Any]) -> tuple[bool, str]:
    """Determine if a strategy should be reaped and why."""
    reasons: list[str] = []
    score = float(performance["performance_score"])
    total_trades = int(performance["total_trades"])
    win_rate = float(performance["win_rate"])
    max_dd = float(performance["max_drawdown"])

    if score < float(thresholds["performance_threshold"]):
        reasons.append(f"Low performance score: {score:.3f}")

    if total_trades < int(thresholds["min_trades"]):
        reasons.append(f"Insufficient trades: {total_trades}")

    if win_rate < 0.20 and total_trades > 10:
        reasons.append(f"Very low win rate: {win_rate:.3f}")

    if max_dd > 0.50:
        reasons.append(f"Excessive drawdown: {max_dd:.3f}")

    # Age gate for underperformance
    created_iso = performance.get("created_date") or performance.get("created_at") or _utcnow_iso()
    created_dt = _parse_iso_dt(created_iso) or datetime.now(timezone.utc)
    age_days = (datetime.now(timezone.utc) - created_dt).days
    if age_days > 60 and score < 0.40:
        reasons.append(f"Old and underperforming: {age_days} days")

    if reasons:
        return True, "; ".join(reasons)
    return False, "Strategy performing well"


def reap_strategy(strategy_file: Path, reason: str, _performance: dict[str, Any]) -> bool:
    """Reap (backup + delete) an underperforming strategy file."""
    try:
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        backup_file = BACKUP_DIR / f"reaped_{strategy_file.name}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"

        shutil.copy2(strategy_file, backup_file)
        strategy_file.unlink()

        logger.info(f"[Reaper] Reaped strategy: {strategy_file.name}")
        logger.info(f"[Reaper] Reason: {reason}")
        logger.info(f"[Reaper] Backup saved: {backup_file}")
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"[Reaper] Error reaping strategy {strategy_file.name}: {e}")
        return False
    else:
        return True


def optimize_strategy_count(performances: list[dict[str, Any]], max_strategies: int) -> list[str]:
    """Return strategy names to reap so only the top max_strategies remain."""
    if len(performances) <= max_strategies:
        return []
    sorted_perfs = sorted(performances, key=lambda x: float(x["performance_score"]), reverse=True)
    # Keep top max_strategies; reap the rest
    to_reap = sorted_perfs[max_strategies:]
    return [p["strategy_name"] for p in to_reap]


# === Main Reaping Pass ===


def reap_strategies_enhanced() -> None:
    """Enhanced strategy reaping with adaptive thresholds and lifecycle logging."""
    try:
        db = ReaperDatabase(REAPER_DB)

        # 1) Gather strategies
        strategy_files = get_strategy_files()
        logger.info(f"[Reaper] Found {len(strategy_files)} strategy files")

        # 2) Fetch recent performance for each
        performances: list[dict[str, Any]] = []
        for f in strategy_files:
            perf = analyze_strategy_performance(f)
            if perf:
                # Ensure required keys are present and typed
                perf["strategy_name"] = perf.get("strategy_name") or f.name
                perf["total_trades"] = int(perf.get("total_trades") or 0)
                perf["performance_score"] = float(perf.get("performance_score") or 0.0)
                perf["win_rate"] = float(perf.get("win_rate") or 0.0)
                perf["max_drawdown"] = float(perf.get("max_drawdown") or 0.0)
                perf["avg_profit"] = float(perf.get("avg_profit") or 0.0)
                perf["total_profit"] = float(perf.get("total_profit") or 0.0)
                perf["created_date"] = perf.get("created_date") or perf.get("created_at") or _utcnow_iso()
                perf["status"] = perf.get("status") or "unknown"
                performances.append(perf)

        if not performances:
            logger.info("[Reaper] No strategies with performance data to evaluate")
            return

        # 3) Compute adaptive thresholds
        thresholds = calculate_adaptive_thresholds(performances)
        logger.info(f"[Reaper] Adaptive thresholds: Performance≥{thresholds['performance_threshold']:.3f}, Min trades≥{thresholds['min_trades']}, Max keep={thresholds['max_strategies']}")

        # Map from name to file for quick lookup
        file_map = {f.name: f for f in strategy_files}
        reaped_count = 0

        # 4) Evaluate each strategy against thresholds
        for perf in performances:
            fname = perf["strategy_name"]
            strategy_file = file_map.get(fname)
            if not strategy_file:
                continue

            # Lifecycle determination (informational)
            evaluate_strategy_lifecycle(perf)

            should_reap, reason = should_reap_strategy(perf, thresholds)
            if should_reap and reap_strategy(strategy_file, reason, perf):
                reaped_count += 1

                # Record action
                db.save_reaper_action(
                    {
                        "timestamp": _utcnow_iso(),
                        "action_type": "reap",
                        "strategy_name": fname,
                        "reason": reason,
                        "performance_data": perf,
                    },
                )

                # Record lifecycle event
                db.save_lifecycle_event(
                    {
                        "strategy_name": fname,
                        "phase": "reaped",
                        "start_date": perf["created_date"],
                        "end_date": _utcnow_iso(),
                        "performance_metrics": perf,
                        "notes": f"Reaped due to: {reason}",
                    },
                )

        # 5) Enforce max strategy count (keep the best)
        if len(performances) - reaped_count > thresholds["max_strategies"]:
            to_reap_names = optimize_strategy_count(
                [p for p in performances if (file_map.get(p["strategy_name"]) and file_map[p["strategy_name"]].exists())],
                thresholds["max_strategies"],
            )
            logger.info(f"[Reaper] Optimizing strategy count: {len(to_reap_names)} additional strategies to reap")
            for name in to_reap_names:
                f = file_map.get(name)
                if not f or not f.exists():
                    continue
                # The "rank" note is approximate; you can compute an exact rank if desired.
                reason = "Strategy count optimization (beyond top performers)"
                perf = next((p for p in performances if p["strategy_name"] == name), None)
                if perf and reap_strategy(f, reason, perf):
                    reaped_count += 1
                    db.save_reaper_action(
                        {
                            "timestamp": _utcnow_iso(),
                            "action_type": "optimize",
                            "strategy_name": name,
                            "reason": reason,
                            "performance_data": perf,
                        },
                    )

        # 6) Summary
        logger.info(f"[Reaper] Reaping complete: {reaped_count} strategies reaped")
        remaining = sum(1 for f in strategy_files if f.exists())
        logger.info(f"[Reaper] Remaining strategies: {remaining}")

        # 7) Aggregate stats (for visibility)
        if performances:
            avg_score = float(np.mean([p["performance_score"] for p in performances]))
            avg_trades = float(np.mean([p["total_trades"] for p in performances]))
            logger.info(f"[Reaper] Average performance score: {avg_score:.3f}")
            logger.info(f"[Reaper] Average trades per strategy: {avg_trades:.1f}")

    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"[Reaper] Enhanced reaping error: {e}")


# === Main Loop (guarded) ===


def main() -> None:
    logger.info("[Reaper] Starting enhanced strategy reaper loop")
    while True:
        start = time.time()
        reap_strategies_enhanced()
        # Sleep the remaining time in the interval (simple pacing)
        elapsed = time.time() - start
        nap = max(REAPER_MIN_NAP, REAPER_INTERVAL - elapsed)
        try:
            time.sleep(nap)  # Sync sleep OK - this is a standalone CLI script
        except KeyboardInterrupt:
            logger.info("[Reaper] Stopping by user request")
            break


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logger.info("[Reaper] Exited")
