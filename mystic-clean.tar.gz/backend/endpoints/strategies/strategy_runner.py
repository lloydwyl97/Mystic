from __future__ import annotations

# --- Windows-safe stdout (avoid character crashes) ---
import sys

try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
    pass

# --- Force IPv4 DNS resolution (Binance US quirk) ---
try:
    import socket as _socket

    _orig_getaddrinfo = getattr(_socket, "getaddrinfo", None)

    def _ipv4_getaddrinfo(host, port, family=0, sock_type=0, proto=0, flags=0):  # type: ignore[override]
        try:
            return _orig_getaddrinfo(host, port, _socket.AF_INET, sock_type, proto, flags)  # type: ignore[misc]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            return _orig_getaddrinfo(host, port, family, sock_type, proto, flags)  # type: ignore[misc]

    if callable(_orig_getaddrinfo):
        _socket.getaddrinfo = _ipv4_getaddrinfo
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
    pass

import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import ccxt
import numpy as np
import pandas as pd

from backend.config.redis_config import get_redis_client

try:
    from backend.config import settings

    BINANCE_KEY = settings.exchange.binance_us_api_key
    BINANCE_SECRET = settings.exchange.binance_us_secret_key
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
    # Fallback to env vars
    BINANCE_KEY = os.getenv("BINANCE_US_API_KEY", "")
    BINANCE_SECRET = os.getenv("BINANCE_US_SECRET", "")

# ---------------- Logging ----------------
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("strategy_runner")

# Strategy error recovery constant
STRATEGY_ERROR_RECOVERY_DELAY = 60  # 60 seconds


# ---------------- Helpers ----------------
def utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def timeframe_seconds(tf: str) -> int:
    tf = (tf or "1h").strip().lower()
    return {
        "1m": 60,
        "3m": 180,
        "5m": 300,
        "15m": 900,
        "30m": 1800,
        "1h": 3600,
        "2h": 7200,
        "4h": 14400,
        "6h": 21600,
        "12h": 43200,
        "1d": 86400,
        "1w": 604800,
    }.get(tf, 3600)


# ---------------- Strategy Runner ----------------
class StrategyRunner:
    def __init__(self, strategy_name: str) -> None:
        self.strategy_name = strategy_name
        self.config = self.load_config()

        # Modes
        self.paper = os.getenv("STRATEGY_PAPER", "1") == "1"
        self.real_trading = os.getenv("REAL_TRADING", "0") == "1" and not self.paper

        # Redis - use shared pool
        self.redis_client = None  # Will be initialized lazily

        # CCXT (Binance US)
        # Note: Binance US does NOT have a testnet. We default to paper=true to avoid live orders.
        self.exchange = ccxt.binanceus(
            {
                "apiKey": BINANCE_KEY,
                "secret": BINANCE_SECRET,
                "enableRateLimit": True,
                "options": {
                    "defaultType": "spot",
                    "adjustForTimeDifference": True,
                },
            },
        )

        # State
        self.leaderboard_key = "strategy_leaderboard"
        self.heartbeat_key = f"strategy_runner:{self.strategy_name}:heartbeat"
        self.trades: list[dict[str, Any]] = []
        self.positions: dict[str, dict[str, float]] = {}  # symbol -> {"qty": float, "avg_price": float}
        self.initial_capital = float(self.config.get("capital", 1000.0))
        self.cash = self.initial_capital

    # ------------- Config -------------
    def load_config(self) -> dict[str, Any]:
        try:
            config_path = os.getenv("STRATEGY_CONFIG", "/app/agent/config.json")
            config_path_obj = Path(config_path)
            with config_path_obj.open(encoding="utf-8") as f:
                cfg = json.load(f)
            cfg.setdefault("strategy_name", self.strategy_name)
            cfg.setdefault("capital", 1000.0)
            cfg.setdefault("timeframe", "1h")
            cfg.setdefault("symbols", ["BTC/USDT"])
            cfg.setdefault("risk_per_trade", 0.02)
            cfg.setdefault("max_positions", 5)
            cfg.setdefault("stop_loss", 0.05)  # 5%
            cfg.setdefault("take_profit", 0.15)  # 15%
            cfg.setdefault("strategy_type", "momentum")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.warning(f"Config load failed ({e}); using defaults.")
            return {
                "strategy_name": self.strategy_name,
                "capital": 1000.0,
                "timeframe": "1h",
                "symbols": ["BTC/USDT"],
                "risk_per_trade": 0.02,
                "max_positions": 5,
                "stop_loss": 0.05,
                "take_profit": 0.15,
                "strategy_type": "momentum",
            }
        else:
            return cfg

    # ------------- Market Data -------------
    def fetch_market_data(self, symbol: str, timeframe: str, limit: int = 200) -> pd.DataFrame:
        try:
            ohlcv = self.exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
            df = pd.DataFrame(ohlcv, columns=["timestamp", "open", "high", "low", "close", "volume"])
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Data fetch failed for {symbol}@{timeframe}: {e}")
            return pd.DataFrame()
        else:
            return df

    # ------------- Indicators -------------
    def calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        if df.empty:
            return df.copy()

        strategy_type = self.config.get("strategy_type", "momentum")
        df = df.copy()

        if strategy_type == "momentum":
            # RSI
            delta = df["close"].diff()
            gain = delta.clip(lower=0).rolling(14).mean()
            loss = (-delta.clip(upper=0)).rolling(14).mean()
            rs = gain / (loss.replace(0, np.nan))
            df["rsi"] = 100 - (100 / (1 + rs)).fillna(50)

            # MACD
            exp1 = df["close"].ewm(span=12, adjust=False).mean()
            exp2 = df["close"].ewm(span=26, adjust=False).mean()
            df["macd"] = exp1 - exp2
            df["signal"] = df["macd"].ewm(span=9, adjust=False).mean()

        elif strategy_type == "mean_reversion":
            df["sma"] = df["close"].rolling(20).mean()
            df["std"] = df["close"].rolling(20).std()
            df["upper_band"] = df["sma"] + (df["std"] * 2)
            df["lower_band"] = df["sma"] - (df["std"] * 2)

        elif strategy_type == "breakout":
            df["high_20"] = df["high"].rolling(20).max()
            df["low_20"] = df["low"].rolling(20).min()

        elif strategy_type == "volatility":
            tr1 = (df["high"] - df["low"]).abs()
            tr2 = (df["high"] - df["close"].shift()).abs()
            tr3 = (df["low"] - df["close"].shift()).abs()
            df["tr"] = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
            df["atr"] = df["tr"].rolling(14).mean()

        return df

    # ------------- Signals -------------
    def generate_signals(self, df: pd.DataFrame) -> dict[str, Any]:
        if df.empty or len(df) < 50:
            return {}

        strategy_type = self.config.get("strategy_type", "momentum")
        price = float(df["close"].iloc[-1])

        if strategy_type == "momentum":
            rsi = float(df["rsi"].iloc[-1])
            macd = float(df["macd"].iloc[-1])
            sig = float(df["signal"].iloc[-1])
            if rsi < 30 and macd > sig:
                return {
                    "action": "BUY",
                    "reason": f"RSI {rsi:.1f} oversold & MACD bullish",
                }
            if rsi > 70 and macd < sig:
                return {
                    "action": "SELL",
                    "reason": f"RSI {rsi:.1f} overbought & MACD bearish",
                }

        elif strategy_type == "mean_reversion":
            upper = float(df["upper_band"].iloc[-1])
            lower = float(df["lower_band"].iloc[-1])
            if price <= lower:
                return {
                    "action": "BUY",
                    "reason": f"Price {price:.2f} at lower band {lower:.2f}",
                }
            if price >= upper:
                return {
                    "action": "SELL",
                    "reason": f"Price {price:.2f} at upper band {upper:.2f}",
                }

        elif strategy_type == "breakout":
            hi = float(df["high_20"].iloc[-1])
            lo = float(df["low_20"].iloc[-1])
            if price > hi:
                return {"action": "BUY", "reason": f"Breakout {price:.2f} > {hi:.2f}"}
            if price < lo:
                return {"action": "SELL", "reason": f"Breakdown {price:.2f} < {lo:.2f}"}

        elif strategy_type == "volatility":
            atr = float(df["atr"].iloc[-1])
            atr_pct = 100.0 * atr / price if price > 0 else 0
            if atr_pct > 5:
                return {"action": "HOLD", "reason": f"High volatility {atr_pct:.2f}%"}
            return {"action": "BUY", "reason": f"Low volatility {atr_pct:.2f}%"}

        return {}

    # ------------- Portfolio & PnL (Paper) -------------
    def _ensure_position(self, symbol: str) -> dict[str, float]:
        if symbol not in self.positions:
            self.positions[symbol] = {"qty": 0.0, "avg_price": 0.0}
        return self.positions[symbol]

    def _paper_fill(self, symbol: str, side: str, qty: float, price: float) -> dict[str, Any]:
        pos = self._ensure_position(symbol)
        if side == "BUY":
            cost = qty * price
            if cost > self.cash:
                msg = "Insufficient cash for paper BUY"
                raise RuntimeError(msg)
            new_qty = pos["qty"] + qty
            new_avg = (pos["avg_price"] * pos["qty"] + cost) / (new_qty if new_qty > 0 else 1)
            pos["qty"] = new_qty
            pos["avg_price"] = new_avg
            self.cash -= cost
        else:  # SELL
            if qty > pos["qty"]:
                msg = "Insufficient position for paper SELL"
                raise RuntimeError(msg)
            proceeds = qty * price
            # realized PnL on this slice
            pnl = (price - pos["avg_price"]) * qty
            pos["qty"] -= qty
            if pos["qty"] == 0:
                pos["avg_price"] = 0.0
            self.cash += proceeds
            return {"realized_pnl": pnl}
        return {"realized_pnl": 0.0}

    # ------------- Execution -------------
    def execute_trade(self, symbol: str, action: str, reason: str) -> bool:
        try:
            # Sizing by risk
            risk_amt = float(self.cash) * float(self.config.get("risk_per_trade", 0.02))
            # Live price
            ticker = self.exchange.fetch_ticker(symbol)
            price = float(ticker.get("last") or ticker.get("close") or 0.0)
            qty = risk_amt / price if price > 0 else 0.0
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error fetching market data: {e}")
            raise

        # Validate price and quantity outside try to avoid TRY301
        if price <= 0:
            msg = "No valid market price"
            raise RuntimeError(msg)

        if qty <= 0:
            msg = "Computed quantity is zero"
            raise RuntimeError(msg)

        try:
            order_id = f"paper-{int(time.time())}"
            realized_pnl = 0.0

            if self.paper or not self.real_trading:
                # PAPER
                fill = self._paper_fill(symbol, action, qty, price)
                realized_pnl = float(fill.get("realized_pnl", 0.0))
            else:
                # LIVE (dangerous; only if REAL_TRADING=1 and you have keys)
                order = self.exchange.create_market_buy_order(symbol, qty) if action == "BUY" else self.exchange.create_market_sell_order(symbol, qty)
                order_id = order.get("id", order_id)

            trade = {
                "ts": utcnow_iso(),
                "symbol": symbol,
                "action": action,
                "qty": qty,
                "price": price,
                "reason": reason,
                "order_id": order_id,
                "paper": self.paper or not self.real_trading,
                "realized_pnl": realized_pnl,
                "cash": self.cash,
            }
            self.trades.append(trade)
            logger.info(f"EXEC {action} {qty:.6f} {symbol} @ {price:.2f} | PnL {realized_pnl:.2f} | CASH {self.cash:.2f}")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Trade execution failed: {e}")
            return False
        else:
            return True

    # ------------- Leaderboard & Heartbeat -------------
    def _portfolio_value(self) -> float:
        total = self.cash
        for sym, pos in self.positions.items():
            if pos["qty"] > 0:
                try:
                    price = float(self.exchange.fetch_ticker(sym).get("last") or 0.0)
                    total += pos["qty"] * price
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    pass
        return total

    def _returns_series(self) -> list[float]:
        """Approx per-trade returns for Sharpe (very rough)."""
        returns = []
        for t in self.trades:
            # treat realized pnl relative to notional of the trade
            notional = t["qty"] * t["price"]
            r = (t.get("realized_pnl", 0.0) / notional) if notional > 0 else 0.0
            returns.append(r)
        return returns

    async def update_leaderboard(self) -> None:
        try:
            total_trades = len(self.trades)
            if total_trades == 0:
                return

            # Get Redis client from shared pool
            if self.redis_client is None:
                self.redis_client = get_redis_client()

            equity = self._portfolio_value()
            profit = equity - self.initial_capital

            # win = positive realized pnl trades
            wins = sum(1 for t in self.trades if t.get("realized_pnl", 0.0) > 0)
            win_rate = 100.0 * wins / total_trades

            rets = self._returns_series()
            sharpe = float(np.mean(rets) / np.std(rets)) if len(rets) > 1 and np.std(rets) > 0 else 0.0

            payload = {
                "equity": equity,
                "profit": profit,
                "trades": total_trades,
                "win_rate": win_rate,
                "sharpe_ratio": sharpe,
                "positions": self.positions,
                "cash": self.cash,
                "paper": self.paper or not self.real_trading,
                "last_update": time.time(),
            }
            await self.redis_client.hset(self.leaderboard_key, self.strategy_name, json.dumps(payload))
            # heartbeat
            await self.redis_client.set(self.heartbeat_key, utcnow_iso(), ex=300)
            logger.info(f"LEADERBOARD profit=${profit:.2f} win_rate={win_rate:.1f}% sharpe={sharpe:.3f} equity=${equity:.2f}")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Leaderboard update failed: {e}")

    # ------------- Main Loop -------------
    def run_strategy(self) -> None:
        logger.info(f"Starting strategy: {self.strategy_name} | paper={self.paper or not self.real_trading}")
        tf = str(self.config.get("timeframe", "1h"))
        sleep_s = timeframe_seconds(tf)
        symbols = list(self.config.get("symbols", ["BTC/USDT"]))

        while True:
            try:
                for symbol in symbols:
                    df = self.fetch_market_data(symbol, tf, limit=200)
                    if df.empty:
                        continue
                    df = self.calculate_indicators(df)
                    signal = self.generate_signals(df)
                    if not signal:
                        continue

                    action = signal.get("action")
                    reason = signal.get("reason", "")
                    if action in {"BUY", "SELL"}:
                        # Max concurrent positions guard (only counts long qty > 0)
                        open_positions = sum(1 for p in self.positions.values() if p.get("qty", 0) > 0)
                        if action == "BUY" and open_positions >= int(self.config.get("max_positions", 5)):
                            logger.info("Skip BUY: max_positions reached")
                        else:
                            ok = self.execute_trade(symbol, action, reason)
                            if ok:
                                # Note: update_leaderboard is async, but we are in sync context
                                # Note: update_leaderboard is async, but we are in sync context
                                # Skip leaderboard update in sync loop (would need asyncio.run)
                                pass
                # Sleep for configured interval - sync sleep OK for standalone strategy process
                time.sleep(sleep_s)

            except KeyboardInterrupt:
                logger.info("Strategy stopped by user")
                break
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception(f"Strategy loop error: {e}")
                # Error recovery delay to prevent rapid failure loops
                time.sleep(STRATEGY_ERROR_RECOVERY_DELAY)


# ---------------- CLI ----------------
def main() -> None:
    if len(sys.argv) < 2:
        logger.error("Usage: python strategy_runner.py <strategy_name>")
        sys.exit(1)
    name = sys.argv[1]
    StrategyRunner(name).run_strategy()


if __name__ == "__main__":
    main()
