#!/usr/bin/env python3
"""
Strategy System Manager for Mystic Trading Platform

Manages strategy execution and signal generation with resilient imports,
Windows-safe UTF-8 streams, and IPv4-only DNS patch (Binance US quirk).
"""

from __future__ import annotations

# --- Windows-safe stdout/stderr (avoid emoji crashes) ---
import sys

try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
    pass

# --- Force IPv4 DNS resolution early (httpx/httpcore + OS sockets) ---
try:
    import socket as _socket

    _orig_getaddrinfo = getattr(_socket, "getaddrinfo", None)

    def _ipv4_getaddrinfo(host, port, family=0, sock_type=0, proto=0, flags=0):  # type: ignore[override]
        try:
            return _orig_getaddrinfo(host, port, _socket.AF_INET, sock_type, proto, flags)  # type: ignore[misc]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            return _orig_getaddrinfo(host, port, family, sock_type, proto, flags)  # type: ignore[misc]

    if callable(_orig_getaddrinfo):
        _socket.getaddrinfo = _ipv4_getaddrinfo
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
    pass

import logging
import time
from typing import Any

from backend.services.task_manager import task_manager

# --- Logging ---
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# Direct imports for production
try:
    from backend.crypto_autoengine_config import get_config
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
    logger.exception(f"CRITICAL: Cannot import crypto_autoengine_config: {e}")
    logger.exception("This is the single source of truth for configuration - system cannot start")
    msg = f"CRITICAL: Required config module not available: {e}"
    raise RuntimeError(msg) from e

# --- Using working cache systems instead of deleted shared cache ---

# --- WebSocket manager import (resilient) ---
try:
    from backend.services.websocket_manager import websocket_manager  # type: ignore[import-not-found]
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):

    class _WSStub:
        async def broadcast_json(self, *_args, **_kwargs):  # type: ignore[misc]
            return None

    websocket_manager = _WSStub()  # type: ignore[assignment]

# --------------------------------------------------------------------------------------


class StrategySignal:
    """Individual strategy signal"""

    def __init__(
        self,
        name: str,
        signal: str,
        confidence: float,
        strength: float,
        description: str,
    ) -> None:
        self.name = name
        self.signal = signal
        raw = float(confidence) if confidence is not None else 0.0
        try:
            from backend.services.confidence_normalizer import ConfidenceNormalizer

            self.confidence = ConfidenceNormalizer.normalize(raw)
        except Exception:
            self.confidence = raw
        self.strength = float(strength)
        self.description = description
        self.timestamp = time.strftime("%Y-%m-%dT%H:%M:%S")


class StrategyController:
    """Controller for individual coin strategies"""

    def __init__(self, symbol: str, cache=None) -> None:
        self.symbol = symbol
        self.cache = cache
        self.config = get_config()
        try:
            self.coin_config = self.config.get_coin_by_symbol(symbol)  # type: ignore[attr-defined]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            # fallback: assume enabled
            self.coin_config = {"symbol": symbol, "enabled": True}

    def run_all_strategies(self) -> dict[str, Any]:
        """Run a bundle of strategies for this coin (price/volume/tech/momentum/volatility/cosmic)."""
        if not self.coin_config:
            return {}

        coin_data = self.cache.get_coin_cache(self.symbol)
        if not coin_data:
            return {}

        signals: list[StrategySignal] = []
        # Price-based strategies
        signals.extend(self._price_based_strategies(coin_data))
        # Volume-based strategies
        signals.extend(self._volume_based_strategies(coin_data))
        # Technical indicator strategies
        signals.extend(self._technical_indicator_strategies(coin_data))
        # Momentum strategies
        signals.extend(self._momentum_strategies(coin_data))
        # Volatility strategies
        signals.extend(self._volatility_strategies(coin_data))
        # Mystic fun
        signals.extend(self._cosmic_strategies(coin_data))

        aggregated = self._aggregate_signals(signals)

        return {
            "signals": [self._signal_to_dict(s) for s in signals],
            "aggregated": aggregated,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
        }

    # -------- Strategy groups --------
    def _price_based_strategies(self, coin_data: dict) -> list[StrategySignal]:
        signals: list[StrategySignal] = []
        price = float(getattr(coin_data, "price", 0.0) or 0.0)
        history = getattr(coin_data, "price_history", None)

        if not history or len(history) < 10:
            return signals

        # Breakout / Breakdown (20 lookback)
        if len(history) >= 20:
            recent_high = max(float(h["price"]) for h in history[-20:])
            recent_low = min(float(h["price"]) for h in history[-20:])
            if price > recent_high * 1.02:
                signals.append(
                    StrategySignal(
                        "Price Breakout",
                        "buy",
                        0.8,
                        0.7,
                        f"{price} > recent high {recent_high}",
                    )
                )
            if price < recent_low * 0.98:
                signals.append(
                    StrategySignal(
                        "Price Breakdown",
                        "sell",
                        0.8,
                        0.7,
                        f"{price} < recent low {recent_low}",
                    )
                )

        # Momentum (10 lookback)
        recent_prices = [float(h["price"]) for h in history[-10:]]
        if len(recent_prices) >= 10:
            mom = (recent_prices[-1] - recent_prices[0]) / max(recent_prices[0], 1e-12)
            if mom > 0.05:
                signals.append(StrategySignal("Price Momentum", "buy", 0.7, 0.6, f"Momentum +{mom:.2%}"))
            elif mom < -0.05:
                signals.append(StrategySignal("Price Momentum", "sell", 0.7, 0.6, f"Momentum {mom:.2%}"))

        # Reversal (15 vs 5)
        if len(history) >= 15:
            p15 = [float(h["price"]) for h in history[-15:]]
            p5 = [float(h["price"]) for h in history[-5:]]
            t15 = (p15[-1] - p15[0]) / max(p15[0], 1e-12)
            t5 = (p5[-1] - p5[0]) / max(p5[0], 1e-12)
            if t15 < -0.03 and t5 > 0.02:
                signals.append(StrategySignal("Price Reversal", "buy", 0.75, 0.65, "15 down then 5 up"))
            elif t15 > 0.03 and t5 < -0.02:
                signals.append(StrategySignal("Price Reversal", "sell", 0.75, 0.65, "15 up then 5 down"))

        # Support/Resistance (30)
        if len(history) >= 30:
            ap = [float(h["price"]) for h in history[-30:]]
            support = min(ap)
            resistance = max(ap)
            if price <= support * 1.01:
                signals.append(StrategySignal("Support Level", "buy", 0.8, 0.7, f"Near support {support}"))
            elif price >= resistance * 0.99:
                signals.append(
                    StrategySignal(
                        "Resistance Level",
                        "sell",
                        0.8,
                        0.7,
                        f"Near resistance {resistance}",
                    )
                )

        return signals

    def _volume_based_strategies(self, coin_data: dict) -> list[StrategySignal]:
        signals: list[StrategySignal] = []
        vol24 = float(getattr(coin_data, "volume_24h", 0.0) or 0.0)
        history = getattr(coin_data, "price_history", None)
        if not history or len(history) < 10:
            return signals

        # Simple proxy signal using current price change as volume proxy
        px_now = float(history[-1]["price"])
        px_prev = float(history[-2]["price"])
        direction = "buy" if px_now >= px_prev else "sell"
        if vol24 > 0:
            signals.append(StrategySignal("Volume Analysis", direction, 0.6, 0.5, f"24h volume {vol24:.0f}"))

        # Price move magnitude
        if len(history) >= 10:
            base = float(history[-10]["price"])
            chg = (px_now - base) / max(base, 1e-12)
            if chg > 0.05:
                signals.append(
                    StrategySignal(
                        "Price-Volume Correlation",
                        "buy",
                        0.6,
                        0.5,
                        f"Strong move {chg:.1%}",
                    )
                )
            elif chg < -0.05:
                signals.append(
                    StrategySignal(
                        "Price-Volume Correlation",
                        "sell",
                        0.6,
                        0.5,
                        f"Strong move {chg:.1%}",
                    )
                )
        return signals

    def _technical_indicator_strategies(self, coin_data: dict) -> list[StrategySignal]:
        signals: list[StrategySignal] = []
        history = getattr(coin_data, "price_history", None)
        if not history or len(history) < 20:
            return signals
        prices = [float(h["price"]) for h in history]

        # RSI
        rsi = self._calculate_rsi(prices)
        if rsi < 30:
            signals.append(StrategySignal("RSI Oversold", "buy", 0.8, 0.7, f"RSI {rsi:.1f}"))
        elif rsi > 70:
            signals.append(StrategySignal("RSI Overbought", "sell", 0.8, 0.7, f"RSI {rsi:.1f}"))

        # MACD
        macd_data = self._calculate_macd(prices)
        if macd_data["macd"] > macd_data["signal"] and macd_data["histogram"] > 0:
            signals.append(
                StrategySignal(
                    "MACD Bullish",
                    "buy",
                    0.7,
                    0.6,
                    f"MACD {macd_data['macd']:.4f} > signal {macd_data['signal']:.4f}",
                )
            )
        elif macd_data["macd"] < macd_data["signal"] and macd_data["histogram"] < 0:
            signals.append(
                StrategySignal(
                    "MACD Bearish",
                    "sell",
                    0.7,
                    0.6,
                    f"MACD {macd_data['macd']:.4f} < signal {macd_data['signal']:.4f}",
                )
            )
        return signals

    def _momentum_strategies(self, coin_data: dict) -> list[StrategySignal]:
        signals: list[StrategySignal] = []
        history = getattr(coin_data, "price_history", None)
        if not history or len(history) < 26:
            return signals
        prices = [float(h["price"]) for h in history]
        ema12 = self._calculate_ema(prices, 12)
        ema26 = self._calculate_ema(prices, 26)
        if ema12 > ema26:
            signals.append(
                StrategySignal(
                    "EMA Bullish Crossover",
                    "buy",
                    0.7,
                    0.6,
                    f"EMA12 {ema12:.2f} > EMA26 {ema26:.2f}",
                )
            )
        else:
            signals.append(
                StrategySignal(
                    "EMA Bearish Crossover",
                    "sell",
                    0.7,
                    0.6,
                    f"EMA12 {ema12:.2f} < EMA26 {ema26:.2f}",
                )
            )
        return signals

    def _volatility_strategies(self, coin_data: dict) -> list[StrategySignal]:
        signals: list[StrategySignal] = []
        history = getattr(coin_data, "price_history", None)
        if not history or len(history) < 20:
            return signals
        prices = [float(h["price"]) for h in history[-20:]]
        vol = self._calculate_volatility(prices)
        if vol > 0.05:
            signals.append(StrategySignal("High Volatility", "hold", 0.6, 0.5, f"Volatility {vol:.2%}"))
        return signals

    def _cosmic_strategies(self, _coin_data: dict) -> list[StrategySignal]:
        signals: list[StrategySignal] = []
        hour = time.localtime().tm_hour
        if hour in (0, 6, 12, 18):
            signals.append(StrategySignal("Cosmic Alignment", "buy", 0.5, 0.4, f"Alignment hour {hour}"))
        return signals

    # -------- Indicators --------
    def _calculate_rsi(self, prices: list[float], period: int = 14) -> float:
        if len(prices) < period + 1:
            return 50.0
        deltas = [prices[i] - prices[i - 1] for i in range(1, len(prices))]
        gains = [d if d > 0 else 0.0 for d in deltas]
        losses = [-d if d < 0 else 0.0 for d in deltas]
        avg_gain = sum(gains[-period:]) / period
        avg_loss = sum(losses[-period:]) / period
        if avg_loss == 0:
            return 100.0
        rs = avg_gain / avg_loss
        return 100 - (100 / (1 + rs))

    def _calculate_macd(self, prices: list[float]) -> dict[str, float]:
        if len(prices) < 26:
            return {"macd": 0.0, "signal": 0.0, "histogram": 0.0}
        ema12 = self._calculate_ema(prices, 12)
        ema26 = self._calculate_ema(prices, 26)
        macd = ema12 - ema26
        signal = macd * 0.8  # simplified
        hist = macd - signal
        return {"macd": macd, "signal": signal, "histogram": hist}

    def _calculate_ema(self, prices: list[float], period: int) -> float:
        if len(prices) < period:
            return prices[-1] if prices else 0.0
        multiplier = 2.0 / (period + 1.0)
        ema = prices[0]
        for p in prices[1:]:
            ema = (p * multiplier) + (ema * (1.0 - multiplier))
        return ema

    def _calculate_volatility(self, prices: list[float]) -> float:
        if len(prices) < 2:
            return 0.0
        returns = [(prices[i] - prices[i - 1]) / max(prices[i - 1], 1e-12) for i in range(1, len(prices))]
        mean_r = sum(returns) / len(returns)
        var = sum((r - mean_r) ** 2 for r in returns) / len(returns)
        return var**0.5

    # -------- Aggregation & serialization --------
    def _aggregate_signals(self, signals: list[StrategySignal]) -> dict[str, Any]:
        if not signals:
            return {
                "signal": "hold",
                "confidence": 0.0,
                "strength": 0.0,
                "description": "No signals generated",
                "signal_counts": {"buy": 0, "sell": 0, "hold": 0},
            }
        buys = [s for s in signals if s.signal == "buy"]
        sells = [s for s in signals if s.signal == "sell"]
        holds = [s for s in signals if s.signal == "hold"]

        def score(xs: list[StrategySignal]) -> float:
            return sum(s.confidence * s.strength for s in xs)

        b, s, h = score(buys), score(sells), score(holds)
        if b > s and b > h:
            final = "buy"
            final_score = b
        elif s > b and s > h:
            final = "sell"
            final_score = s
        else:
            final = "hold"
            final_score = h

        total = max(len(signals), 1)
        conf = min(final_score / total, 1.0)
        denom = max(b, s, h, 1e-12)
        strength = min(final_score / denom, 1.0)

        return {
            "signal": final,
            "confidence": conf,
            "strength": strength,
            "description": f"Based on {len(signals)} strategies: {len(buys)} buy, {len(sells)} sell, {len(holds)} hold",
            "signal_counts": {"buy": len(buys), "sell": len(sells), "hold": len(holds)},
        }

    def _signal_to_dict(self, s: StrategySignal) -> dict[str, Any]:
        return {
            "name": s.name,
            "signal": s.signal,
            "confidence": s.confidence,
            "strength": s.strength,
            "description": s.description,
            "timestamp": s.timestamp,
        }


# --------------------------------------------------------------------------------------


class StrategySystemManager:
    """Manager for the entire strategy system"""

    def __init__(self, cache=None) -> None:
        self.cache = cache
        self.config = get_config()
        self._strategy_controllers: dict[str, StrategyController] = {}

    def get_strategy_controller(self, symbol: str) -> StrategyController:
        if symbol not in self._strategy_controllers:
            self._strategy_controllers[symbol] = StrategyController(symbol, self.cache)
        return self._strategy_controllers[symbol]

    def run_all_strategies(self) -> dict[str, Any]:
        """Run all strategies for all configured coins."""
        results: dict[str, Any] = {}
        try:
            symbols = self.config.get_all_symbols()  # type: ignore[attr-defined]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            symbols = ["BTC-USDT", "ETH-USDT"]

        for symbol in symbols:
            try:
                controller = self.get_strategy_controller(symbol)
                result = controller.run_all_strategies()
                if result:
                    results[symbol] = result
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception(f"Error running strategies for {symbol}: {e}")

        return {
            "results": results,
            "total_coins": len(symbols),
            "successful_coins": len(results),
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
        }

    def run_coin_strategies(self, symbol: str) -> dict[str, Any] | None:
        try:
            return self.get_strategy_controller(symbol).run_all_strategies()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error running strategies for {symbol}: {e}")
            return None

    def get_strategy_status(self) -> dict[str, Any]:
        try:
            cache_status = self.cache.get_cache_stats()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            cache_status = {}
        return {
            "total_controllers": len(self._strategy_controllers),
            "active_symbols": list(self._strategy_controllers.keys()),
            "cache_status": cache_status,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
        }

    def clear_strategy_cache(self, symbol: str | None = None) -> None:
        if symbol:
            self._strategy_controllers.pop(symbol, None)
        else:
            self._strategy_controllers.clear()

    def get_strategy_performance(self) -> dict[str, Any]:
        """Compute and broadcast performance snapshot (best-effort)."""
        performance: dict[str, Any] = {
            "total_signals_generated": 0,
            "buy_signals": 0,
            "sell_signals": 0,
            "hold_signals": 0,
            "average_confidence": 0.0,
            "average_strength": 0.0,
            "active_strategies": len(self._strategy_controllers),
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
        }

        total_conf, total_str, n = 0.0, 0.0, 0

        for controller in self._strategy_controllers.values():
            try:
                result = controller.run_all_strategies()
                if not result or "signals" not in result:
                    continue
                sigs = result["signals"]
                performance["total_signals_generated"] = int(performance["total_signals_generated"]) + len(sigs)
                for s in sigs:
                    sig = s.get("signal", "hold")
                    if sig == "buy":
                        performance["buy_signals"] = int(performance["buy_signals"]) + 1
                    elif sig == "sell":
                        performance["sell_signals"] = int(performance["sell_signals"]) + 1
                    else:
                        performance["hold_signals"] = int(performance["hold_signals"]) + 1
                    raw_c = float(s.get("confidence", 0.0) or 0.0)
                    try:
                        from backend.services.confidence_normalizer import ConfidenceNormalizer

                        c = ConfidenceNormalizer.normalize(raw_c)
                    except Exception:
                        c = raw_c
                    st = float(s.get("strength", 0.0) or 0.0)
                    total_conf += c
                    total_str += st
                    n += 1
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception(f"Error calculating performance: {e}")

        if n > 0:
            performance["average_confidence"] = total_conf / n
            performance["average_strength"] = total_str / n

        # Broadcast (non-blocking)
        try:
            task = task_manager.create_task_sync(websocket_manager.broadcast_json({"type": "strategy_performance", "data": performance}), name="strategy_system:broadcast_performance")
            # Store reference if websocket manager has task tracking
            if hasattr(websocket_manager, "_tasks"):
                websocket_manager._tasks.append(task)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            pass

        return performance
