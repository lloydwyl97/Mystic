"""
Strategy Endpoints - Advanced Strategy Generation API
All Live Data, No Hardcoded Values

API endpoints for strategy discovery, management, and analytics.
All operations use live market data from Binance.US API.

Features:
- Strategy generation and evolution
- Strategy backtesting with live data
- Strategy performance analytics
- Market regime analysis
- Strategy allocation management

All endpoints serve live operations - no simulation mode.

Endpoint References:
- Backend API: Port 8000 (/strategy/* endpoints)
- Strategy Manager: Live strategy allocation and performance
- Market Regime Analyzer: Live regime classification
- Strategy Generator: Live strategy evolution
- All data live from Binance.US API
"""

import asyncio
import logging
from datetime import datetime
from typing import Any

from fastapi import APIRouter, BackgroundTasks, HTTPException
from pydantic import BaseModel, Field

from backend.config.trading_universe import TOP10_COINS
from backend.modules.ai.market_regime_analyzer import market_regime_analyzer
from backend.modules.ai.strategy_generator import EvolvedStrategy, strategy_generator
from backend.services.enhanced_backtesting_engine import RegimeAwareBacktestConfig, enhanced_backtesting_engine
from backend.services.market_data import market_data_service
from backend.services.strategy_manager import strategy_manager

logger = logging.getLogger(__name__)

# Create router
router = APIRouter(prefix="/strategy", tags=["strategy"])


# ===== REQUEST/RESPONSE MODELS =====


class StrategyGenerationRequest(BaseModel):
    """Request model for strategy generation"""

    symbols: list[str] = Field(default_factory=lambda: TOP10_COINS[:3])
    generations: int = Field(default=10, ge=1, le=50)
    population_size: int = Field(default=50, ge=10, le=200)
    target_regime: str | None = Field(None, description="Target market regime for optimization")


class StrategyBacktestRequest(BaseModel):
    """Request model for strategy backtesting"""

    strategy_id: str
    symbols: list[str] = Field(default_factory=lambda: TOP10_COINS[:3])
    start_date: datetime
    end_date: datetime
    regime_aware: bool = Field(default=True)
    initial_capital: float = Field(default=10000.0, gt=0)


class StrategyOptimizationRequest(BaseModel):
    """Request model for strategy optimization"""

    base_strategy_id: str
    symbols: list[str] = Field(default_factory=lambda: TOP10_COINS[:3])
    start_date: datetime
    end_date: datetime
    optimization_generations: int = Field(default=10, ge=1, le=20)


class MonteCarloRequest(BaseModel):
    """Request model for Monte Carlo simulation"""

    strategy_id: str
    symbols: list[str] = Field(default_factory=lambda: TOP10_COINS[:3])
    start_date: datetime
    end_date: datetime
    num_simulations: int = Field(default=1000, ge=100, le=5000)
    regime_modeling: bool = Field(default=True)


class StrategyResponse(BaseModel):
    """Response model for strategy information"""

    strategy_id: str
    strategy_type: str
    market_regime: str
    fitness_score: float
    parameters: dict[str, Any]
    generation: int
    created_at: float
    performance_metrics: dict[str, Any]


class BacktestResultResponse(BaseModel):
    """Response model for backtest results"""

    backtest_id: str
    strategy_id: str
    total_return: float
    sharpe_ratio: float
    max_drawdown: float
    win_rate: float
    total_trades: int
    start_date: datetime
    end_date: datetime
    regime_context: dict[str, Any] | None = None


class OptimizationResultResponse(BaseModel):
    """Response model for optimization results"""

    optimization_id: str
    base_strategy_id: str
    optimized_strategy_id: str
    optimization_score: float
    improvement_percentage: float
    backtest_results: list[BacktestResultResponse]
    regime_performance: dict[str, float]
    robustness_score: float
    completed_at: float


class MonteCarloResultResponse(BaseModel):
    """Response model for Monte Carlo results"""

    simulation_id: str
    strategy_id: str
    simulations_completed: int
    expected_return: float
    volatility: float
    sharpe_ratio: float
    value_at_risk_95: float
    max_drawdown_95: float
    probability_of_loss: float
    regime_stress_test: dict[str, Any]
    completed_at: float


class RegimeAnalysisResponse(BaseModel):
    """Response model for regime analysis"""

    current_regime: str
    confidence: float
    secondary_regime: str | None
    transition_probability: float
    timeframe_agreement: dict[str, str]
    volatility: float
    expected_duration: int
    last_updated: float


class StrategyAllocationResponse(BaseModel):
    """Response model for strategy allocations"""

    enabled: bool
    current_regime: dict[str, Any] | None
    total_strategies: int
    allocations: dict[str, dict[str, Any]]
    timestamp: float


# ===== STRATEGY GENERATION ENDPOINTS =====


@router.post("/generate", response_model=list[StrategyResponse])
async def generate_strategies(request: StrategyGenerationRequest, background_tasks: BackgroundTasks):
    """
    Generate new trading strategies using genetic algorithms.

    Uses live market data to evolve strategies optimized for current market conditions.
    All strategies are validated on live Binance.US data.
    """

    def _raise_no_market_data() -> None:
        raise HTTPException(status_code=503, detail="No market data available for strategy generation")

    try:
        logger.info(f"Generating strategies: {request.generations} generations, population {request.population_size}")

        # Get live market data for strategy generation
        market_data = {}
        for symbol in request.symbols:
            try:
                data = await market_data_service.get_market_data(symbol, timeframe="1h", limit=500)
                if data and "price_history" in data:
                    market_data[symbol] = {"price_history": data["price_history"], "volume_history": data.get("volume_history", [])}
            except Exception as e:
                logger.warning(f"Failed to get data for {symbol}: {e}")

        if not market_data:
            _raise_no_market_data()

        # Generate strategies in background if large request
        if request.generations > 20 or request.population_size > 100:
            background_tasks.add_task(_generate_strategies_background, market_data, request.generations, request.population_size, request.target_regime)
            return [{"message": "Strategy generation started in background", "status": "processing"}]

        # Generate strategies synchronously
        evolved_strategies = await strategy_generator.evolve_strategies(market_data, generations=request.generations)

        # Convert to response format
        strategies = []
        for i, strategy in enumerate(evolved_strategies[:10]):  # Return top 10
            strategy_data = StrategyResponse(
                strategy_id=f"gen_{int(asyncio.get_event_loop().time())}_{i}",
                strategy_type=strategy.dna.strategy_type,
                market_regime=strategy.dna.market_regime,
                fitness_score=strategy.fitness.overall_score,
                parameters=strategy.dna.parameters,
                generation=strategy.generation,
                created_at=strategy.created_at,
                performance_metrics={
                    "total_return": strategy.fitness.total_return,
                    "sharpe_ratio": strategy.fitness.sharpe_ratio,
                    "win_rate": strategy.fitness.win_rate,
                    "max_drawdown": strategy.fitness.max_drawdown,
                    "profit_factor": strategy.fitness.profit_factor,
                    "validation_trades": strategy.validation_results.get("total_trades", 0),
                },
            )
            strategies.append(strategy_data)

        logger.info(f"Generated {len(strategies)} strategies successfully")
    except Exception as e:
        logger.exception(f"Error generating strategies: {e}")
        raise HTTPException(status_code=500, detail=f"Strategy generation failed: {e}") from e
    else:
        return strategies


async def _generate_strategies_background(market_data: dict[str, Any], generations: int, _population_size: int, _target_regime: str | None):
    """Background task for strategy generation"""
    try:
        # This would store results in database/cache for later retrieval
        evolved_strategies = await strategy_generator.evolve_strategies(market_data, generations=generations)
        logger.info(f"Background strategy generation completed: {len(evolved_strategies)} strategies")
    except Exception as e:
        logger.exception(f"Background strategy generation failed: {e}")


@router.get("/strategies", response_model=list[StrategyResponse])
async def get_available_strategies(limit: int = 20, strategy_type: str | None = None):
    """Get list of available evolved strategies"""
    try:
        # Get strategies from strategy generator
        available_strategies = strategy_generator.get_best_strategies(top_n=limit)

        strategies = []
        for i, strategy in enumerate(available_strategies):
            if strategy_type and strategy.dna.strategy_type != strategy_type:
                continue

            strategy_data = StrategyResponse(
                strategy_id=f"available_{i}",
                strategy_type=strategy.dna.strategy_type,
                market_regime=strategy.dna.market_regime,
                fitness_score=strategy.fitness.overall_score,
                parameters=strategy.dna.parameters,
                generation=strategy.generation,
                created_at=strategy.created_at,
                performance_metrics={
                    "total_return": strategy.fitness.total_return,
                    "sharpe_ratio": strategy.fitness.sharpe_ratio,
                    "win_rate": strategy.fitness.win_rate,
                    "max_drawdown": strategy.fitness.max_drawdown,
                    "profit_factor": strategy.fitness.profit_factor,
                    "validation_trades": strategy.validation_results.get("total_trades", 0),
                },
            )
            strategies.append(strategy_data)

    except Exception as e:
        logger.exception(f"Error getting available strategies: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to retrieve strategies: {e}") from e
    else:
        return strategies


# ===== STRATEGY BACKTESTING ENDPOINTS =====


@router.post("/backtest", response_model=BacktestResultResponse)
async def backtest_strategy(request: StrategyBacktestRequest, _background_tasks: BackgroundTasks):
    """Backtest a strategy on live historical data"""

    def _raise_invalid_date_range() -> None:
        raise HTTPException(status_code=400, detail="End date must be after start date")

    def _raise_period_too_long() -> None:
        raise HTTPException(status_code=400, detail="Backtest period cannot exceed 1 year")

    try:
        logger.info(f"Backtesting strategy {request.strategy_id} from {request.start_date} to {request.end_date}")

        # Validate date range
        if request.end_date <= request.start_date:
            _raise_invalid_date_range()

        if (request.end_date - request.start_date).days > 365:
            _raise_period_too_long()

        # Get strategy (this would normally retrieve from storage)
        # For now, create a sample evolved strategy
        sample_strategy = EvolvedStrategy(
            dna=strategy_generator.strategy_templates["momentum_base"].__class__(
                strategy_type="momentum",
                entry_conditions=["rsi_oversold", "macd_crossover"],
                exit_conditions=["take_profit", "trailing_stop"],
                position_sizing="kelly",
                risk_management="trailing_stop",
                timeframe="1h",
                market_regime="bull",
                parameters={
                    "rsi_threshold": 30.0,
                    "macd_fast": 12,
                    "macd_slow": 26,
                    "take_profit_pct": 5.0,
                    "stop_loss_pct": 2.0,
                    "trailing_stop_pct": 1.0,
                },
            ),
            fitness=strategy_generator.strategy_templates["momentum_base"].__class__(),
            generation=1,
            validation_results={},
            created_at=asyncio.get_event_loop().time(),
        )

        # Run backtest
        if request.regime_aware:
            regime_config = RegimeAwareBacktestConfig()
            result = await enhanced_backtesting_engine.run_regime_aware_backtest(sample_strategy, request.symbols, request.start_date, request.end_date, regime_config)
        else:
            result = await enhanced_backtesting_engine.run_backtest("evolved_strategy", request.symbols, request.start_date, request.end_date)

        # Convert to response format
        response = BacktestResultResponse(
            backtest_id=result.backtest_id,
            strategy_id=request.strategy_id,
            total_return=result.total_return,
            sharpe_ratio=result.sharpe_ratio,
            max_drawdown=result.max_drawdown,
            win_rate=result.win_rate,
            total_trades=result.total_trades,
            start_date=result.start_date,
            end_date=result.end_date,
            regime_context={"regime_aware": request.regime_aware, "analysis_available": request.regime_aware} if request.regime_aware else None,
        )

        logger.info(f"Backtest completed: {result.total_return:.2%} return")
    except Exception as e:
        logger.exception(f"Error backtesting strategy: {e}")
        raise HTTPException(status_code=500, detail=f"Backtest failed: {e}") from e
    else:
        return response


@router.post("/optimize", response_model=OptimizationResultResponse)
async def optimize_strategy(request: StrategyOptimizationRequest, _background_tasks: BackgroundTasks):
    """Optimize strategy parameters using genetic algorithms"""
    try:
        logger.info(f"Optimizing strategy {request.base_strategy_id}")

        # Create sample base strategy
        base_strategy = EvolvedStrategy(
            dna=strategy_generator.strategy_templates["momentum_base"].__class__(
                strategy_type="momentum",
                entry_conditions=["rsi_oversold", "macd_crossover"],
                exit_conditions=["take_profit", "trailing_stop"],
                position_sizing="kelly",
                risk_management="trailing_stop",
                timeframe="1h",
                market_regime="bull",
                parameters={
                    "rsi_threshold": 30.0,
                    "macd_fast": 12,
                    "macd_slow": 26,
                    "take_profit_pct": 5.0,
                    "stop_loss_pct": 2.0,
                    "trailing_stop_pct": 1.0,
                },
            ),
            fitness=strategy_generator.strategy_templates["momentum_base"].__class__(),
            generation=1,
            validation_results={},
            created_at=asyncio.get_event_loop().time(),
        )

        # Run optimization
        optimization_result = await enhanced_backtesting_engine.optimize_strategy_with_genetics(base_strategy, request.symbols, request.start_date, request.end_date, request.optimization_generations)

        # Convert backtest results
        backtest_responses = []
        for result in optimization_result.backtest_results:
            backtest_resp = BacktestResultResponse(
                backtest_id=result.backtest_id,
                strategy_id=request.base_strategy_id,
                total_return=result.total_return,
                sharpe_ratio=result.sharpe_ratio,
                max_drawdown=result.max_drawdown,
                win_rate=result.win_rate,
                total_trades=result.total_trades,
                start_date=result.start_date,
                end_date=result.end_date,
            )
            backtest_responses.append(backtest_resp)

        # Calculate improvement
        base_return = optimization_result.backtest_results[0].total_return if optimization_result.backtest_results else 0.0
        optimized_return = optimization_result.optimized_strategy.fitness.total_return
        improvement = ((optimized_return - base_return) / abs(base_return)) * 100 if base_return != 0 else 0.0

        response = OptimizationResultResponse(
            optimization_id=f"opt_{int(asyncio.get_event_loop().time())}",
            base_strategy_id=request.base_strategy_id,
            optimized_strategy_id=f"opt_{request.base_strategy_id}",
            optimization_score=optimization_result.optimization_score,
            improvement_percentage=improvement,
            backtest_results=backtest_responses,
            regime_performance=optimization_result.regime_performance,
            robustness_score=optimization_result.robustness_score,
            completed_at=optimization_result.optimization_timestamp,
        )

        logger.info(f"Strategy optimization completed: {improvement:.1f}% improvement")
    except Exception as e:
        logger.exception(f"Error optimizing strategy: {e}")
        raise HTTPException(status_code=500, detail=f"Optimization failed: {e}") from e
    else:
        return response


@router.post("/monte-carlo", response_model=MonteCarloResultResponse)
async def run_monte_carlo_simulation(request: MonteCarloRequest, _background_tasks: BackgroundTasks):
    """Run Monte Carlo simulation for strategy risk analysis"""

    def _raise_monte_carlo_error(error_msg: str) -> None:
        raise HTTPException(status_code=500, detail=f"Monte Carlo simulation failed: {error_msg}")

    try:
        logger.info(f"Running Monte Carlo simulation for strategy {request.strategy_id}")

        # Create sample strategy
        sample_strategy = EvolvedStrategy(
            dna=strategy_generator.strategy_templates["momentum_base"].__class__(
                strategy_type="momentum",
                entry_conditions=["rsi_oversold", "macd_crossover"],
                exit_conditions=["take_profit", "trailing_stop"],
                position_sizing="kelly",
                risk_management="trailing_stop",
                timeframe="1h",
                market_regime="bull",
                parameters={
                    "rsi_threshold": 30.0,
                    "macd_fast": 12,
                    "macd_slow": 26,
                    "take_profit_pct": 5.0,
                    "stop_loss_pct": 2.0,
                    "trailing_stop_pct": 1.0,
                },
            ),
            fitness=strategy_generator.strategy_templates["momentum_base"].__class__(),
            generation=1,
            validation_results={},
            created_at=asyncio.get_event_loop().time(),
        )

        # Run Monte Carlo simulation
        analysis = await enhanced_backtesting_engine.run_regime_based_monte_carlo(
            sample_strategy, request.symbols, request.start_date, request.end_date, request.num_simulations, request.regime_modeling
        )

        if "error" in analysis:
            error_msg = analysis["error"]
            _raise_monte_carlo_error(error_msg)

        response = MonteCarloResultResponse(
            simulation_id=f"mc_{int(asyncio.get_event_loop().time())}",
            strategy_id=request.strategy_id,
            simulations_completed=analysis.get("simulations_completed", 0),
            expected_return=analysis.get("returns", {}).get("mean", 0.0),
            volatility=analysis.get("volatility", {}).get("mean", 0.0),
            sharpe_ratio=analysis.get("sharpe_ratio", {}).get("mean", 0.0),
            value_at_risk_95=analysis.get("returns", {}).get("var_95", 0.0),
            max_drawdown_95=analysis.get("max_drawdown", {}).get("percentile_95", 0.0),
            probability_of_loss=analysis.get("probability_of_loss", 0.0),
            regime_stress_test=analysis.get("regime_stress_test", {}),
            completed_at=asyncio.get_event_loop().time(),
        )

        logger.info(f"Monte Carlo simulation completed: {response.simulations_completed} simulations")
    except Exception as e:
        logger.exception(f"Error running Monte Carlo simulation: {e}")
        raise HTTPException(status_code=500, detail=f"Monte Carlo simulation failed: {e}") from e
    else:
        return response


# ===== MARKET REGIME ENDPOINTS =====


@router.get("/regime/current", response_model=RegimeAnalysisResponse)
async def get_current_regime():
    """Get current market regime analysis"""

    def _raise_regime_unavailable() -> None:
        raise HTTPException(status_code=503, detail="Regime analysis temporarily unavailable")

    try:
        regime_classification = await market_regime_analyzer.classify_regime()

        if regime_classification.primary_regime == "error":
            _raise_regime_unavailable()

        response = RegimeAnalysisResponse(
            current_regime=regime_classification.primary_regime,
            confidence=regime_classification.confidence,
            secondary_regime=regime_classification.secondary_regime,
            transition_probability=regime_classification.transition_probability,
            timeframe_agreement=regime_classification.timeframe_agreement,
            volatility=regime_classification.regime_volatility,
            expected_duration=regime_classification.regime_duration_expectation,
            last_updated=regime_classification.classification_time,
        )

    except Exception as e:
        logger.exception(f"Error getting current regime: {e}")
        raise HTTPException(status_code=500, detail=f"Regime analysis failed: {e}") from e
    else:
        return response


@router.get("/regime/analytics")
async def get_regime_analytics():
    """Get comprehensive regime analytics"""
    try:
        analytics = await market_regime_analyzer.get_regime_analytics()
    except Exception as e:
        logger.exception(f"Error getting regime analytics: {e}")
        raise HTTPException(status_code=500, detail=f"Regime analytics failed: {e}") from e
    else:
        return analytics


@router.get("/regime/predict")
async def predict_regime_transition(hours_ahead: int = 24):
    """Predict regime transitions over specified time horizon"""

    def _raise_horizon_too_long() -> None:
        raise HTTPException(status_code=400, detail="Prediction horizon cannot exceed 168 hours")

    try:
        if hours_ahead > 168:  # Max 1 week
            _raise_horizon_too_long()

        prediction = await market_regime_analyzer.predict_regime_transition(hours_ahead)
    except Exception as e:
        logger.exception(f"Error predicting regime transition: {e}")
        raise HTTPException(status_code=500, detail=f"Regime prediction failed: {e}") from e
    else:
        return prediction


# ===== STRATEGY MANAGEMENT ENDPOINTS =====


@router.get("/allocation", response_model=StrategyAllocationResponse)
async def get_strategy_allocations():
    """Get current strategy allocations and performance"""
    try:
        allocations = await strategy_manager.get_strategy_allocations()

        response = StrategyAllocationResponse(
            enabled=strategy_manager.enabled,
            current_regime=allocations.get("current_regime"),
            total_strategies=allocations.get("total_strategies", 0),
            allocations=allocations.get("allocations", {}),
            timestamp=allocations.get("timestamp", asyncio.get_event_loop().time()),
        )

    except Exception as e:
        logger.exception(f"Error getting strategy allocations: {e}")
        raise HTTPException(status_code=500, detail=f"Allocation retrieval failed: {e}") from e
    else:
        return response


@router.post("/allocation/enable")
async def enable_strategy_management():
    """Enable automated strategy management"""

    def _raise_enable_failed() -> None:
        raise HTTPException(status_code=500, detail="Failed to enable strategy management")

    try:
        success = await strategy_manager.enable_strategy_management()

        if success:
            return {"message": "Strategy management enabled", "status": "active"}
        else:
            _raise_enable_failed()

    except Exception as e:
        logger.exception(f"Error enabling strategy management: {e}")
        raise HTTPException(status_code=500, detail=f"Enable failed: {e}") from e


@router.post("/allocation/disable")
async def disable_strategy_management():
    """Disable automated strategy management"""

    def _raise_disable_failed() -> None:
        raise HTTPException(status_code=500, detail="Failed to disable strategy management")

    try:
        success = await strategy_manager.disable_strategy_management()

        if success:
            return {"message": "Strategy management disabled", "status": "inactive"}
        else:
            _raise_disable_failed()

    except Exception as e:
        logger.exception(f"Error disabling strategy management: {e}")
        raise HTTPException(status_code=500, detail=f"Disable failed: {e}") from e


# ===== UTILITY ENDPOINTS =====


@router.get("/health")
async def strategy_service_health():
    """Check strategy service health"""
    try:
        # Check all components
        health_status = {
            "strategy_generator": "healthy" if strategy_generator else "unavailable",
            "strategy_manager": "enabled" if strategy_manager.enabled else "disabled",
            "market_regime_analyzer": "enabled" if market_regime_analyzer.enabled else "disabled",
            "backtesting_engine": "available" if enhanced_backtesting_engine else "unavailable",
            "timestamp": asyncio.get_event_loop().time(),
        }

        # Check market data availability
        try:
            sample_data = await market_data_service.get_market_data("BTCUSDT", timeframe="1h", limit=10)
            health_status["market_data"] = "available" if sample_data else "unavailable"
        except Exception:
            health_status["market_data"] = "error"

    except Exception as e:
        logger.exception(f"Error checking strategy service health: {e}")
        return {"status": "error", "error": str(e), "timestamp": asyncio.get_event_loop().time()}
    else:
        return health_status


@router.get("/symbols")
async def get_available_symbols():
    """Get list of available trading symbols"""
    return {"symbols": TOP10_COINS, "default_symbols": TOP10_COINS[:3], "total_symbols": len(TOP10_COINS), "last_updated": asyncio.get_event_loop().time()}
