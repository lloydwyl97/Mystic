"""
Backtest API endpoints for the dashboard
All endpoints return live data only - no mocks or placeholders
"""

import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter

from backend.endpoints.backtest.backtest_service import backtest_service

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/trading/backtest", tags=["backtest"])

logger.info("Backtest service imported successfully")


@router.get("/results")
async def get_backtest_results() -> dict[str, Any]:
    """Get backtest results"""
    try:
        if backtest_service:
            return await backtest_service.get_results()

        # Return structured empty response if service not available
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "results": [],
            "summary": {
                "total_trades": 0,
                "win_rate": 0,
                "profit_factor": 0,
                "sharpe_ratio": 0,
            },
            "error": "Backtest service not available",
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting backtest results: {e}")
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "results": [],
            "summary": {
                "total_trades": 0,
                "win_rate": 0,
                "profit_factor": 0,
                "sharpe_ratio": 0,
            },
            "error": str(e),
        }


@router.get("/config")
async def get_backtest_config() -> dict[str, Any]:
    """Get backtest configuration"""
    try:
        if backtest_service:
            return await backtest_service.get_config()

        # Return structured empty response if service not available
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "config": {
                "start_date": "",
                "end_date": "",
                "initial_capital": 10000,
                "symbols": [],
            },
            "error": "Backtest service not available",
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting backtest config: {e}")
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "config": {
                "start_date": "",
                "end_date": "",
                "initial_capital": 10000,
                "symbols": [],
            },
            "error": str(e),
        }


@router.get("/performance")
async def get_backtest_performance() -> dict[str, Any]:
    """Get backtest performance metrics"""
    try:
        if backtest_service:
            return await backtest_service.get_performance()

        # Return structured empty response if service not available
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "performance": {"equity_curve": [], "drawdowns": [], "monthly_returns": []},
            "error": "Backtest service not available",
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting backtest performance: {e}")
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "performance": {"equity_curve": [], "drawdowns": [], "monthly_returns": []},
            "error": str(e),
        }


@router.get("/history")
async def get_backtest_history() -> dict[str, Any]:
    """Get backtest trade history"""
    try:
        if backtest_service:
            return await backtest_service.get_history()

        # Return structured empty response if service not available
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "trades": [],
            "error": "Backtest service not available",
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting backtest history: {e}")
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "trades": [],
            "error": str(e),
        }
