"""
Trading notifications API endpoints for the dashboard
All endpoints return live data only - no mocks or placeholders
"""

import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter

# Import notification_service instead of non-existent notifications_service
try:
    from backend.services.notification_service import NotificationService

    notification_service_instance = NotificationService()
    NOTIFICATION_SERVICE_AVAILABLE = True
except (ImportError, ModuleNotFoundError, AttributeError):
    NOTIFICATION_SERVICE_AVAILABLE = False
    notification_service_instance = None

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/trading/notifications", tags=["notifications"])

logger.info("Notification service import attempted")


@router.get("/active")
async def get_active_notifications() -> dict[str, Any]:
    """Get active trading notifications"""
    try:
        if NOTIFICATION_SERVICE_AVAILABLE and notification_service_instance:
            # Get unread notifications (active)
            result = await notification_service_instance.get_notifications(unread_only=True, limit=50)
            return {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "notifications": result.get("notifications", []),
                "count": result.get("total", 0),
                "status": "success",
            }

        # Return structured empty response if service not available
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "notifications": [],
            "count": 0,
            "error": "Notifications service not available",
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting active notifications: {e}")
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "notifications": [],
            "count": 0,
            "error": str(e),
        }


@router.get("/settings")
async def get_notification_settings() -> dict[str, Any]:
    """Get notification settings"""
    try:
        if NOTIFICATION_SERVICE_AVAILABLE and notification_service_instance:
            settings = await notification_service_instance.get_settings()
            return {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "settings": settings.get("settings", {}),
                "status": "success",
            }

        # Return structured empty response if service not available
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "settings": {"enabled": False, "channels": [], "types": []},
            "error": "Notifications service not available",
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting notification settings: {e}")
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "settings": {"enabled": False, "channels": [], "types": []},
            "error": str(e),
        }


@router.get("/history")
async def get_notification_history() -> dict[str, Any]:
    """Get notification history"""
    try:
        if NOTIFICATION_SERVICE_AVAILABLE and notification_service_instance:
            # Get all notifications (not just unread)
            result = await notification_service_instance.get_notifications(limit=100)
            return {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "history": result.get("notifications", []),
                "count": result.get("total", 0),
                "status": "success",
            }

        # Return structured empty response if service not available
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "history": [],
            "count": 0,
            "error": "Notifications service not available",
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error getting notification history: {e}")
        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "history": [],
            "count": 0,
            "error": str(e),
        }
