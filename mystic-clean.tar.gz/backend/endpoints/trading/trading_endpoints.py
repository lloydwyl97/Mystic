"""
Trading Endpoints - Live trading operations and management
"""

import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException, Query

from backend.services.alerts_service import alerts_service
from backend.services.auto_trader_mode_manager import get_auto_trader_mode_manager
from backend.services.profit_siphon import get_profit_siphon
from backend.services.trading_execution_service import TradingExecutionService

# Import live services
# Trading service imports handled in endpoint functions

router = APIRouter()
logger = logging.getLogger(__name__)


@router.get("/api/trading/alerts")
async def get_trading_alerts() -> dict[str, Any]:
    """Get trading alerts and notifications from unified alerts service."""
    try:
        # Use alerts_service for comprehensive alert management
        alerts = await alerts_service.get_active_alerts()

        return {"alerts": alerts.get("alerts", []), "count": len(alerts.get("alerts", [])), "timestamp": datetime.now(timezone.utc).isoformat(), "source": "alerts_service"}
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Alerts service failed, trying fallback: {e}")
        # Fallback to trading execution service
        try:
            trading_service = TradingExecutionService()
            alerts = await trading_service.get_alerts()

            return {"alerts": alerts, "count": len(alerts), "timestamp": datetime.now(timezone.utc).isoformat(), "source": "fallback"}
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as fallback_e:
            logger.exception(f"Fallback also failed: {fallback_e}")
            raise HTTPException(status_code=500, detail=f"Trading alerts unavailable: {e!s}") from fallback_e


@router.get("/api/trading/notifications/active")
async def get_active_notifications() -> dict[str, Any]:
    """Get active trading notifications."""
    try:
        trading_service = TradingExecutionService()
        notifications = await trading_service.get_active_notifications()

        return {"notifications": notifications, "count": len(notifications), "timestamp": datetime.now(timezone.utc).isoformat()}
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get active notifications: {e}")
        raise HTTPException(status_code=500, detail=f"Active notifications unavailable: {e!s}") from e


@router.get("/api/trading/notifications/history")
async def get_notification_history(limit: int = Query(100, ge=1, le=1000, description="Number of notifications")) -> dict[str, Any]:
    """Get trading notification history."""
    try:
        trading_service = TradingExecutionService()
        history = await trading_service.get_notification_history(limit)

        return {"notifications": history, "limit": limit, "count": len(history), "timestamp": datetime.now(timezone.utc).isoformat()}
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get notification history: {e}")
        raise HTTPException(status_code=500, detail=f"Notification history unavailable: {e!s}") from e


@router.get("/api/trading/notifications/settings")
async def get_notification_settings() -> dict[str, Any]:
    """Get trading notification settings."""
    try:
        trading_service = TradingExecutionService()
        settings = await trading_service.get_notification_settings()

        return {"settings": settings, "timestamp": datetime.now(timezone.utc).isoformat()}
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get notification settings: {e}")
        raise HTTPException(status_code=500, detail=f"Notification settings unavailable: {e!s}") from e


@router.get("/api/trading/paper/controls")
async def get_paper_trading_controls() -> dict[str, Any]:
    """Get paper trading controls and settings."""
    try:
        trading_service = TradingExecutionService()
        controls = await trading_service.get_paper_trading_controls()

        return {"controls": controls, "timestamp": datetime.now(timezone.utc).isoformat()}
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get paper trading controls: {e}")
        raise HTTPException(status_code=500, detail=f"Paper trading controls unavailable: {e!s}") from e


@router.get("/api/trading/paper/history")
async def get_paper_trading_history(limit: int = Query(500, ge=1, le=10000, description="Number of trades")) -> dict[str, Any]:
    """Get paper trading history."""
    try:
        trading_service = TradingExecutionService()
        history = await trading_service.get_paper_trading_history(limit)

        return {"trades": history, "limit": limit, "count": len(history), "timestamp": datetime.now(timezone.utc).isoformat()}
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get paper trading history: {e}")
        raise HTTPException(status_code=500, detail=f"Paper trading history unavailable: {e!s}") from e


@router.get("/api/trading/paper/performance")
async def get_paper_trading_performance() -> dict[str, Any]:
    """Get paper trading performance metrics."""
    try:
        trading_service = TradingExecutionService()
        performance = await trading_service.get_paper_trading_performance()

        return {"performance": performance, "timestamp": datetime.now(timezone.utc).isoformat()}
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get paper trading performance: {e}")
        raise HTTPException(status_code=500, detail=f"Paper trading performance unavailable: {e!s}") from e


@router.get("/api/trading/paper/portfolio")
async def get_paper_trading_portfolio() -> dict[str, Any]:
    """Get paper trading portfolio status."""
    try:
        trading_service = TradingExecutionService()
        portfolio = await trading_service.get_paper_trading_portfolio()

        return {"portfolio": portfolio, "timestamp": datetime.now(timezone.utc).isoformat()}
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get paper trading portfolio: {e}")
        raise HTTPException(status_code=500, detail=f"Paper trading portfolio unavailable: {e!s}") from e


@router.get("/api/trading/backtest/config")
async def get_backtest_config() -> dict[str, Any]:
    """Get backtesting configuration."""
    try:
        trading_service = TradingExecutionService()
        config = await trading_service.get_backtest_config()

        return {"config": config, "timestamp": datetime.now(timezone.utc).isoformat()}
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get backtest config: {e}")
        raise HTTPException(status_code=500, detail=f"Backtest config unavailable: {e!s}") from e


@router.get("/api/trading/backtest/history")
async def get_backtest_history(limit: int = Query(50, ge=1, le=500, description="Number of backtests")) -> dict[str, Any]:
    """Get backtesting history."""
    try:
        trading_service = TradingExecutionService()
        history = await trading_service.get_backtest_history(limit)

        return {"backtests": history, "limit": limit, "count": len(history), "timestamp": datetime.now(timezone.utc).isoformat()}
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get backtest history: {e}")
        raise HTTPException(status_code=500, detail=f"Backtest history unavailable: {e!s}") from e


@router.get("/api/trading/backtest/performance")
async def get_backtest_performance() -> dict[str, Any]:
    """Get backtesting performance metrics."""
    try:
        trading_service = TradingExecutionService()
        performance = await trading_service.get_backtest_performance()

        return {"performance": performance, "timestamp": datetime.now(timezone.utc).isoformat()}
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get backtest performance: {e}")
        raise HTTPException(status_code=500, detail=f"Backtest performance unavailable: {e!s}") from e


@router.get("/api/trading/backtest/results")
async def get_backtest_results(backtest_id: str = Query(..., description="Backtest ID")) -> dict[str, Any]:
    """Get detailed backtest results."""
    try:
        trading_service = TradingExecutionService()
        results = await trading_service.get_backtest_results(backtest_id)

        return {"backtest_id": backtest_id, "results": results, "timestamp": datetime.now(timezone.utc).isoformat()}
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get backtest results for {backtest_id}: {e}")
        raise HTTPException(status_code=500, detail=f"Backtest results unavailable: {e!s}") from e


@router.get("/api/autotrader/mode")
async def get_autotrader_mode() -> dict[str, Any]:
    """Get current auto-trader mode and settings for verification."""
    try:
        mode_manager = get_auto_trader_mode_manager()
        mode_info = mode_manager.get_current_mode_info()

        return {
            "mode": mode_info["mode"],
            "tp": mode_info["tp"],
            "sl": mode_info["sl"],
            "trail": mode_info["trail"],
            "symbol_delay": mode_info["symbol_delay"],
            "strategy_delay": mode_info["strategy_delay"],
            "global_delay": mode_info["global_delay"],
            "max_daily_orders": mode_info["max_daily_orders"],
            "last_switch": mode_info["last_switch"],
            "switch_count": mode_info["switch_count"],
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get autotrader mode: {e}")
        raise HTTPException(status_code=500, detail=f"Autotrader mode unavailable: {e!s}") from e


@router.get("/api/profit-siphon/status")
async def get_profit_siphon_status() -> dict[str, Any]:
    """Get profit siphon status and locked reserve information."""
    try:
        siphon = get_profit_siphon()
        status = siphon.get_siphon_status()

        return {
            "enabled": status["enabled"],
            "siphon_percent": status["siphon_percent"],
            "trigger_threshold": status["trigger_threshold"],
            "total_locked": status["total_locked"],
            "siphon_count": status["siphon_count"],
            "last_siphon": status["last_siphon"],
            "created_at": status["created_at"],
            "description": status["description"],
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Failed to get profit siphon status: {e}")
        raise HTTPException(status_code=500, detail=f"Profit siphon status unavailable: {e!s}") from e
