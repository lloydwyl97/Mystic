"""
Trading Endpoints

Handles all trading-related API endpoints including signals, orders, and portfolio management.
"""

import inspect
import logging
from typing import Any, Literal

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field, field_validator, model_validator

logger = logging.getLogger("trading_endpoints")

# -----------------------------
# Pydantic models (Pydantic v2)
# -----------------------------


class TradingSignal(BaseModel):
    symbol: str = Field(..., description="Base symbol, e.g., BTC")
    signal_type: str = Field(..., description="buy|sell|hold|custom")
    strength: float = Field(..., ge=0.0, le=1.0)
    timestamp: float = Field(..., description="Unix timestamp (seconds)")
    strategy: str = Field(..., min_length=1, max_length=128)
    confidence: float = Field(..., ge=0.0, le=1.0)
    model_config = {"protected_namespaces": ("settings_",)}

    @field_validator("symbol", mode="before")
    @classmethod
    def _normalize_symbol(cls, v: str) -> str:
        v = (v or "").strip().upper()
        if not v:
            msg = "symbol is required"
            raise ValueError(msg)
        return v

    @field_validator("signal_type", mode="before")
    @classmethod
    def _validate_signal_type(cls, v: str) -> str:
        allowed = {"buy", "sell", "hold", "long", "short", "custom"}
        vv = (v or "").strip().lower()
        if vv not in allowed:
            msg = f"signal_type must be one of {sorted(allowed)}"
            raise ValueError(msg)
        return vv


class OrderRequest(BaseModel):
    symbol: str = Field(..., description="Base symbol, e.g., BTC")
    side: Literal["buy", "sell"]
    quantity: float = Field(..., gt=0)
    order_type: Literal["market", "limit"] = Field(..., description="Order type")
    price: float | None = Field(None, gt=0, description="Required for limit orders")
    model_config = {"protected_namespaces": ("settings_",)}

    @field_validator("symbol", mode="before")
    @classmethod
    def _normalize_symbol(cls, v: str) -> str:
        v = (v or "").strip().upper()
        if not v:
            msg = "symbol is required"
            raise ValueError(msg)
        return v

    @model_validator(mode="after")
    def _require_price_for_limit(self):
        # After full model validation, ensure price is provided for limit orders
        order_type = (self.order_type or "").lower()
        if order_type == "limit" and self.price is None:
            msg = "price is required for limit orders"
            raise ValueError(msg)
        return self


# -----------------------------
# Global service references
# (injected by main.py at startup)
# -----------------------------
# Trading services state - using dict to avoid global keyword
_trading_services_state: dict[str, Any] = {
    "signal_manager": None,
    "trade_engine": None,
    "portfolio_service": None,
}


def set_services(sm: Any, te: Any, ps: Any) -> None:
    """Set service references from main.py"""
    _trading_services_state["signal_manager"] = sm
    _trading_services_state["trade_engine"] = te
    _trading_services_state["portfolio_service"] = ps


router = APIRouter()

# -----------------------------
# Helpers
# -----------------------------


async def _maybe_await(func_or_coro, *args, **kwargs):
    """
    Call a possibly-sync or async function safely and return its result.
    """
    if inspect.iscoroutinefunction(func_or_coro):
        return await func_or_coro(*args, **kwargs)
    result = func_or_coro(*args, **kwargs) if callable(func_or_coro) else func_or_coro
    if inspect.isawaitable(result):
        return await result
    return result


def _require_service(service: Any, name: str):
    if not service:
        raise HTTPException(status_code=503, detail=f"{name} not available")


# -----------------------------
# Routes
# -----------------------------


@router.post("/signal")
async def create_trading_signal(signal: TradingSignal) -> dict[str, Any]:
    """
    Create a new trading signal.
    Forwards to signal_manager.create_signal(dict).
    """
    # Validate service and method before try block to avoid TRY301
    _require_service(_trading_services_state["signal_manager"], "Signal manager")
    if not hasattr(_trading_services_state["signal_manager"], "create_signal"):
        raise HTTPException(status_code=503, detail="Signal manager missing create_signal()")

    try:
        result: dict[str, Any] = await _maybe_await(_trading_services_state["signal_manager"].create_signal, signal.model_dump())
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error creating trading signal: {e}")
        raise HTTPException(status_code=500, detail="Failed to create trading signal") from e
    else:
        return {"status": "success", "signal": result}


@router.get("/signals")
async def get_trading_signals() -> dict[str, Any]:
    """
    Get all trading signals.
    Forwards to signal_manager.get_signals() -> list[dict].
    """
    # Validate service and method before try block to avoid TRY301
    _require_service(_trading_services_state["signal_manager"], "Signal manager")
    if not hasattr(_trading_services_state["signal_manager"], "get_signals"):
        raise HTTPException(status_code=503, detail="Signal manager missing get_signals()")

    try:
        signals: list[dict[str, Any]] = await _maybe_await(_trading_services_state["signal_manager"].get_signals)
        return {"signals": signals, "count": len(signals)}
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error fetching trading signals: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch trading signals") from e


@router.post("/order")
async def place_order(order: OrderRequest) -> dict[str, Any]:
    """
    Place a new trading order.
    Forwards to trade_engine.place_order(dict).
    - Ensures limit orders carry a price (validated by model).
    """
    # Validate service and method before try block to avoid TRY301
    _require_service(_trading_services_state["trade_engine"], "Trade engine")
    if not hasattr(_trading_services_state["trade_engine"], "place_order"):
        raise HTTPException(status_code=503, detail="Trade engine missing place_order()")

    try:
        payload = order.model_dump()
        # Normalize keys expected by downstream engines if needed
        payload["symbol"] = payload["symbol"].upper()
        payload["side"] = payload["side"].lower()
        payload["order_type"] = payload["order_type"].lower()

        result = await _maybe_await(_trading_services_state["trade_engine"].place_order, payload)
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error placing order: {e}")
        raise HTTPException(status_code=500, detail="Failed to place order") from e
    else:
        return {"status": "success", "order": result}


@router.get("/orders")
async def get_orders() -> dict[str, Any]:
    """
    Get all trading orders.
    Forwards to trade_engine.get_orders() -> list[dict].
    """
    # Validate service and method before try block to avoid TRY301
    _require_service(_trading_services_state["trade_engine"], "Trade engine")
    if not hasattr(_trading_services_state["trade_engine"], "get_orders"):
        raise HTTPException(status_code=503, detail="Trade engine missing get_orders()")

    try:
        orders: list[dict[str, Any]] = await _maybe_await(_trading_services_state["trade_engine"].get_orders)
        return {"orders": orders, "count": len(orders)}
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error fetching orders: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch orders") from e


@router.get("/portfolio/overview")
async def get_portfolio_overview() -> Any:
    """
    Get portfolio overview.
    Forwards to portfolio_service.get_overview().
    """
    # Validate service and method before try block to avoid TRY301
    _require_service(_trading_services_state["portfolio_service"], "Portfolio service")
    if not hasattr(_trading_services_state["portfolio_service"], "get_overview"):
        raise HTTPException(status_code=503, detail="Portfolio service missing get_overview()")

    try:
        overview: Any = await _maybe_await(_trading_services_state["portfolio_service"].get_overview)
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error fetching portfolio overview: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch portfolio overview") from e
    else:
        return overview


@router.get("/portfolio/positions")
async def get_portfolio_positions() -> dict[str, Any]:
    """
    Get portfolio positions.
    Forwards to portfolio_service.get_positions() -> list[Any].
    """
    # Validate service and method before try block to avoid TRY301
    _require_service(_trading_services_state["portfolio_service"], "Portfolio service")
    if not hasattr(_trading_services_state["portfolio_service"], "get_positions"):
        raise HTTPException(status_code=503, detail="Portfolio service missing get_positions()")

    try:
        positions: list[Any] = await _maybe_await(_trading_services_state["portfolio_service"].get_positions)
        return {"positions": positions, "count": len(positions)}
    except HTTPException:
        raise
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception(f"Error fetching portfolio positions: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch portfolio positions") from e
