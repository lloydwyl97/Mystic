#!/usr/bin/env python3
"""
Exchange Router - Binance.US ONLY, Top-10 universe enforced
Python 3.12 compatible. No hardcoded data, no placeholders. Live-only.

Fixed for production reliability:
- Graceful fallback on unsupported exchange env
- Centralized Top-10 allowlist (no duplication)
- Unified symbol normalization and validation
- Structured decision responses for UI error handling
- Readiness status exposure for health pages
- Tolerant environment parsing with common synonyms
- USDT-only constraint documentation
"""

import logging
import os
from dataclasses import dataclass
from typing import Any

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID, TRADING_SYMBOLS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

# Use TRADING_SYMBOLS from trading_universe (live data)
TOP10_USDT_PAIRS = list(TRADING_SYMBOLS)

logger = logging.getLogger("mystic.trading.exchange_router")


@dataclass
class SymbolDecision:
    """Structured decision for symbol support"""

    supported: bool
    reason: str
    normalized_symbol: str
    original_symbol: str
    exchange: str


class ExchangeRouter:
    """Exchange router with graceful fallbacks and structured responses"""

    def __init__(self) -> None:
        """Initialize with graceful fallback on unsupported exchange"""
        # All Live Data, No Fallback/Hardcoded Data
        env_val = os.getenv("EXCHANGE")
        if not env_val:
            env_val = EXCHANGE_ID  # Use EXCHANGE_ID from trading_universe (single source of truth)
        env_val = env_val.strip().lower()

        # Tolerant mapping for common synonyms (all map to EXCHANGE_ID from trading_universe)
        exchange_mapping = {
            "binance.us": EXCHANGE_ID,
            "binance_us": EXCHANGE_ID,
            "binanceus": EXCHANGE_ID,
            "binance": EXCHANGE_ID,
            "binance us": EXCHANGE_ID,
            "binance-us": EXCHANGE_ID,
        }

        # Determine if we need to fallback
        fallback_used = env_val not in exchange_mapping

        if fallback_used:
            logger.warning(
                "Unsupported exchange '%s' requested, falling back to %s",
                env_val,
                EXCHANGE_ID,
            )
            self._exchange = EXCHANGE_ID
        else:
            self._exchange = exchange_mapping[env_val]

        self._initialization_status = {
            "exchange": self._exchange,
            "requested_exchange": env_val,
            "fallback_used": fallback_used,
            "supported_symbols_count": len(TOP10_USDT_PAIRS),
            "allowlist_source": "trading_universe",
        }

        logger.info("Exchange router initialized: %s", self._exchange)

    def get_active_exchange(self) -> str:
        """Get the active exchange identifier"""
        return self._exchange

    def get_coin_list(self) -> list[str]:
        """Get supported coin list"""
        return TOP10_USDT_PAIRS[:]

    def get_status(self) -> dict[str, Any]:
        """Get router status for health pages"""
        return {
            "active_exchange": self._exchange,
            "supported_symbols": TOP10_USDT_PAIRS,
            "symbols_count": len(TOP10_USDT_PAIRS),
            "initialization_status": self._initialization_status,
            "usdt_only": True,
            "normalization_rules": {
                "removes": ["-", "/", "_", " "],
                "enforces_usdt_suffix": True,
                "case_sensitive": False,
            },
        }

    def format_symbol(self, base: str, quote: str = "USDT") -> str:
        """Format symbol from base and quote"""
        if quote.upper() != "USDT":
            msg = f"Only USDT quote supported, got: {quote}"
            raise ValueError(msg)
        return f"{base.upper()}{quote.upper()}"

    def format_ccxt_symbol(self, base: str, quote: str = "USDT") -> str:
        """Format symbol in CCXT format"""
        if quote.upper() != "USDT":
            msg = f"Only USDT quote supported, got: {quote}"
            raise ValueError(msg)
        return f"{base.upper()}/{quote.upper()}"

    def normalize_symbol(self, symbol: str) -> str:
        """Unified symbol normalization with comprehensive cleaning"""
        if not symbol:
            msg = "Empty symbol provided"
            raise ValueError(msg)

        # Comprehensive cleaning
        s = symbol.strip().replace("-", "").replace("/", "").replace("_", "").replace(" ", "").upper()

        # Enforce USDT suffix if not present
        if not s.endswith("USDT"):
            if len(s) <= 5:  # Assume it's a base currency
                s = s + "USDT"
            else:
                # Try to extract base and add USDT
                bases = [pair[:-4] for pair in TOP10_USDT_PAIRS]
                for base_len in range(3, 6):  # Common base lengths
                    if s[:base_len] in bases:
                        s = s[:base_len] + "USDT"
                        break

        return s

    def is_supported_pair(self, symbol: str) -> SymbolDecision:
        """Check if symbol is supported with structured response"""
        try:
            normalized = self.normalize_symbol(symbol)

            if normalized in TOP10_USDT_PAIRS:
                return SymbolDecision(
                    supported=True,
                    reason="Symbol is in Top-10 Binance.US allowlist",
                    normalized_symbol=normalized,
                    original_symbol=symbol,
                    exchange=self._exchange,
                )
            return SymbolDecision(
                supported=False,
                reason=f"Symbol '{normalized}' not in Top-10 Binance.US allowlist. Supported: {TOP10_USDT_PAIRS}",
                normalized_symbol=normalized,
                original_symbol=symbol,
                exchange=self._exchange,
            )

        except ValueError as e:
            return SymbolDecision(
                supported=False,
                reason=f"Invalid symbol format: {e}",
                normalized_symbol="",
                original_symbol=symbol,
                exchange=self._exchange,
            )

    def validate_and_format_symbol(self, symbol: str) -> tuple[str, str]:
        """Validate symbol and return both exchange and CCXT formats"""
        decision = self.is_supported_pair(symbol)

        if not decision.supported:
            raise ValueError(decision.reason)

        # Extract base from normalized symbol
        base = decision.normalized_symbol[:-4]  # Remove USDT

        return (
            decision.normalized_symbol,  # Exchange format: BTCUSDT
            f"{base}/USDT",  # CCXT format: BTC/USDT
        )

    def get_supported_bases(self) -> list[str]:
        """Get list of supported base currencies"""
        return [pair[:-4] for pair in TOP10_USDT_PAIRS]

    def is_binance_us(self) -> bool:
        """Check if active exchange is Binance.US"""
        return self._exchange == EXCHANGE_ID

    def get_exchange_info(self) -> dict[str, Any]:
        """Get detailed exchange information"""
        return {
            "exchange_id": self._exchange,
            "is_binance_us": self.is_binance_us(),
            "supported_pairs": TOP10_USDT_PAIRS,
            "supported_bases": self.get_supported_bases(),
            "quote_currency": "USDT",
            "quote_only": True,
            "normalization_examples": {
                "btc-usdt": "BTCUSDT",
                "ETH/USDT": "ETHUSDT",
                "ada_usdt": "ADAUSDT",
                "SOL ": "SOLUSDT",
                "doge": "DOGEUSDT",
            },
        }
