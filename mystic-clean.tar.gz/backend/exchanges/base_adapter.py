"""
Base Exchange Adapter - All Live Data, No Fallback/Hardcoded Data

This module provides abstract interfaces for live exchange adapters (backend port 8000).
All adapters:
- Connect to live exchange APIs (Binance.US via backend port 8000)
- Return live market data (tickers, orderbooks, trades, OHLCV)
- Execute live orders on exchange APIs
- No fallback/hardcoded data - all operations use live exchange APIs
- Abstract interfaces define contracts for live exchange operations

Live Data Sources:
- Ticker data: Live market prices from exchange APIs (Binance.US)
- Orderbook data: Live orderbook depth from exchange APIs (Binance.US)
- Trade data: Live recent trades from exchange APIs (Binance.US)
- OHLCV data: Live candlestick data from exchange APIs (Binance.US)
- Balance data: Live account balances from exchange APIs (Binance.US)
- Order execution: Live order placement on exchange APIs (Binance.US)
- All operations use live exchange APIs - no mock/test data

Endpoint References:
- Backend API: Port 8000 (exchange adapters used by backend services)
- Binance.US API: Live exchange API (via exchange adapters)
- All adapters connect to live endpoints - no fallback/hardcoded data

This module defines abstract interfaces - concrete implementations handle live connections.
"""

from __future__ import annotations

import abc
from typing import Literal, Protocol, runtime_checkable

from backend.models.market_types import OHLCV, OrderBook, OrderResult, Ticker, Trade  # type: ignore[import-not-found]


@runtime_checkable
class BaseExchangeAdapter(Protocol):
    """
    Protocol for live exchange adapters.

    Defines the interface for live exchange operations (Binance.US via backend port 8000).
    All methods return live data from exchange APIs - no fallback/hardcoded data.
    """

    name: str

    async def get_ticker(self, symbol: str) -> Ticker:
        """
        Get live ticker data for a symbol (from live exchange API).

        Args:
            symbol: Trading symbol (from live Binance.US Top-10)

        Returns:
            Live ticker data from exchange API
        """

    async def get_orderbook(self, symbol: str, depth: int = 50) -> OrderBook:
        """
        Get live orderbook data for a symbol (from live exchange API).

        Args:
            symbol: Trading symbol (from live Binance.US Top-10)
            depth: Orderbook depth (default: 50, configuration default not fallback data)

        Returns:
            Live orderbook data from exchange API
        """

    async def get_trades(self, symbol: str, limit: int = 100) -> list[Trade]:
        """
        Get live recent trades for a symbol (from live exchange API).

        Args:
            symbol: Trading symbol (from live Binance.US Top-10)
            limit: Maximum number of trades (default: 100, configuration default not fallback data)

        Returns:
            List of live trade data from exchange API
        """

    async def get_ohlcv(self, symbol: str, interval: str, limit: int = 500) -> list[OHLCV]:
        """
        Get live OHLCV data for a symbol (from live exchange API).

        Args:
            symbol: Trading symbol (from live Binance.US Top-10)
            interval: Candlestick interval (e.g., "1m", "5m", "1h", "1d")
            limit: Maximum number of candles (default: 500, configuration default not fallback data)

        Returns:
            List of live OHLCV candles from exchange API
        """

    async def get_balance(self) -> dict[str, float]:
        """
        Get live account balance (from live exchange API).

        Returns:
            Dictionary of live account balances from exchange API
        """

    async def create_order(
        self,
        symbol: str,
        side: Literal["buy", "sell"],
        qty: float,
        order_type: Literal["market", "limit"] = "market",
        price: float | None = None,
    ) -> OrderResult:
        """
        Create live order on exchange (via live exchange API).

        Args:
            symbol: Trading symbol (from live Binance.US Top-10)
            side: Order side ("buy" or "sell")
            qty: Order quantity
            order_type: Order type ("market" or "limit", default: "market", configuration default not fallback data)
            price: Limit price (required for limit orders)

        Returns:
            Live order result from exchange API
        """


class AbstractExchangeAdapter(abc.ABC):
    """
    Abstract base class for live exchange adapters.

    Defines abstract methods for live exchange operations (Binance.US via backend port 8000).
    All methods must be implemented to return live data from exchange APIs - no fallback/hardcoded data.
    """

    name: str

    @abc.abstractmethod
    async def get_ticker(self, symbol: str) -> Ticker:
        """
        Get live ticker data for a symbol (from live exchange API).

        Args:
            symbol: Trading symbol (from live Binance.US Top-10)

        Returns:
            Live ticker data from exchange API
        """

    @abc.abstractmethod
    async def get_orderbook(self, symbol: str, depth: int = 50) -> OrderBook:
        """
        Get live orderbook data for a symbol (from live exchange API).

        Args:
            symbol: Trading symbol (from live Binance.US Top-10)
            depth: Orderbook depth (default: 50, configuration default not fallback data)

        Returns:
            Live orderbook data from exchange API
        """

    @abc.abstractmethod
    async def get_trades(self, symbol: str, limit: int = 100) -> list[Trade]:
        """
        Get live recent trades for a symbol (from live exchange API).

        Args:
            symbol: Trading symbol (from live Binance.US Top-10)
            limit: Maximum number of trades (default: 100, configuration default not fallback data)

        Returns:
            List of live trade data from exchange API
        """

    @abc.abstractmethod
    async def get_ohlcv(self, symbol: str, interval: str, limit: int = 500) -> list[OHLCV]:
        """
        Get live OHLCV data for a symbol (from live exchange API).

        Args:
            symbol: Trading symbol (from live Binance.US Top-10)
            interval: Candlestick interval (e.g., "1m", "5m", "1h", "1d")
            limit: Maximum number of candles (default: 500, configuration default not fallback data)

        Returns:
            List of live OHLCV candles from exchange API
        """

    @abc.abstractmethod
    async def get_balance(self) -> dict[str, float]:
        """
        Get live account balance (from live exchange API).

        Returns:
            Dictionary of live account balances from exchange API
        """

    @abc.abstractmethod
    async def create_order(
        self,
        symbol: str,
        side: Literal["buy", "sell"],
        qty: float,
        order_type: Literal["market", "limit"] = "market",
        price: float | None = None,
    ) -> OrderResult:
        """
        Create live order on exchange (via live exchange API).

        Args:
            symbol: Trading symbol (from live Binance.US Top-10)
            side: Order side ("buy" or "sell")
            qty: Order quantity
            order_type: Order type ("market" or "limit", default: "market", configuration default not fallback data)
            price: Limit price (required for limit orders)

        Returns:
            Live order result from exchange API
        """
