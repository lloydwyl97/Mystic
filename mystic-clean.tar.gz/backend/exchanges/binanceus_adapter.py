"""
Binance.US Exchange Adapter - All Live Data, No Fallback/Hardcoded Data

This module provides live Binance.US exchange adapter implementation (backend port 8000).
All operations:
- Connect to live Binance.US API (https://api.binance.us)
- Return live market data (tickers, orderbooks, trades, OHLCV)
- No fallback/hardcoded data - all operations use live Binance.US API
- Used by backend services on port 8000 for live trading operations

Live Data Sources:
- Ticker data: Live market prices from Binance.US API
- Orderbook data: Live orderbook depth from Binance.US API
- Trade data: Live recent trades from Binance.US API
- OHLCV data: Live candlestick data from Binance.US API
- All operations use live Binance.US API - no mock/test data

Endpoint References:
- Binance.US API: https://api.binance.us (live exchange API)
- Backend API: Port 8000 (adapter used by backend services)
- All operations connect to live endpoints - no fallback/hardcoded data

Note: get_balance() and create_order() are minimal implementations for interface compliance.
Full balance retrieval and order execution functionality is available via:
- backend.services.live_trading_service.LiveTradingService (get_account_balance, place_order)
- backend.services.binanceus_live_client.BinanceUSLiveClient (fetch_balance, create_market_order)
"""

from __future__ import annotations

import logging
import os
from datetime import datetime, timezone
from typing import Literal

from backend.models.market_types import OHLCV, OrderBook, OrderResult, Ticker, Trade  # type: ignore[import-not-found]
from backend.services.binance_rest_client import BinanceREST
from backend.utils.binance_weight_limiter import BinanceWeightLimiter
from backend.utils.symbols import (
    normalize_symbol_to_dash,
    to_ccxt_symbol,
    to_exchange_symbol,
)  # type: ignore[import-not-found]

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

from .base_adapter import AbstractExchangeAdapter

logger = logging.getLogger(__name__)


class BinanceUSAdapter(AbstractExchangeAdapter):
    """
    Live Binance.US exchange adapter implementation.

    Provides live market data and trading operations via Binance.US API.
    All operations use live data - no fallback/hardcoded data.
    """

    # Use EXCHANGE_ID from trading_universe (single source of truth)
    # Note: "binanceus" format is used for to_exchange_symbol() compatibility
    # EXCHANGE_ID is "binance_us", but to_exchange_symbol expects "binanceus" format
    name = EXCHANGE_ID.replace("_", "") if EXCHANGE_ID else "binanceus"

    def __init__(self) -> None:
        """Initialize Binance.US adapter with live API connection."""
        # Use BINANCEUS_BASE environment variable or default to Binance.US API URL
        self.api_base = os.getenv("BINANCEUS_BASE", "https://api.binance.us")  # Live Binance.US API endpoint
        self._rest: BinanceREST | None = None

    async def _rest_client(self) -> BinanceREST:
        """
        Get or create live Binance.US REST client.

        Returns:
            Live BinanceREST client for Binance.US API operations
        """
        if self._rest is None:
            limiter = await BinanceWeightLimiter.create()
            self._rest = BinanceREST(limiter)
        return self._rest

    async def get_ticker(self, symbol: str) -> Ticker:
        """
        Get live ticker data for a symbol from Binance.US API.

        Args:
            symbol: Trading symbol (from live Binance.US Top-10)

        Returns:
            Live ticker data from Binance.US API
        """
        # Convert symbol to exchange format: normalize -> ccxt -> exchange
        dash_symbol = normalize_symbol_to_dash(symbol)
        ccxt_symbol = to_ccxt_symbol(dash_symbol)
        pair = to_exchange_symbol(ccxt_symbol)
        client = await self._rest_client()
        # Get live 24h ticker data from Binance.US API
        data = await client.ticker_24h(pair)
        if not data:
            # If live API returns no data, raise error (not fallback data)
            error_msg = f"Live ticker data not available for {symbol}"
            raise RuntimeError(error_msg)
        price = float((data or {}).get("lastPrice", 0) or 0)
        if price <= 0:
            error_msg = f"Invalid zero/negative price for {symbol}"
            raise RuntimeError(error_msg)
        bid = float((data or {}).get("bidPrice", 0) or 0) if (data or {}).get("bidPrice") else None
        ask = float((data or {}).get("askPrice", 0) or 0) if (data or {}).get("askPrice") else None
        ts = int(datetime.now(timezone.utc).timestamp() * 1000)
        return Ticker(
            exchange=self.name,
            symbol=normalize_symbol_to_dash(symbol),
            price=price,  # Live price from Binance.US API
            bid=bid,  # Live bid price from Binance.US API
            ask=ask,  # Live ask price from Binance.US API
            ts=ts,
        )

    async def get_orderbook(self, symbol: str, depth: int = 50) -> OrderBook:
        """
        Get live orderbook data for a symbol from Binance.US API.

        Args:
            symbol: Trading symbol (from live Binance.US Top-10)
            depth: Orderbook depth (default: 50, configuration default not fallback data)

        Returns:
            Live orderbook data from Binance.US API
        """
        # Convert symbol to exchange format: normalize -> ccxt -> exchange
        dash_symbol = normalize_symbol_to_dash(symbol)
        ccxt_symbol = to_ccxt_symbol(dash_symbol)
        pair = to_exchange_symbol(ccxt_symbol)
        client = await self._rest_client()
        # Get live orderbook data from Binance.US API
        data = await client._request(
            "GET",
            "/api/v3/depth",
            params={"symbol": pair, "limit": min(max(depth, 5), 100)},
        )
        if not data:
            # If live API returns no data, raise error (not fallback data)
            error_msg = f"Live orderbook data not available for {symbol}"
            raise RuntimeError(error_msg)
        bids = [(float(p), float(q)) for p, q in data.get("bids", [])][:depth]
        asks = [(float(p), float(q)) for p, q in data.get("asks", [])][:depth]
        ts = int(datetime.now(timezone.utc).timestamp() * 1000)
        return OrderBook(
            exchange=self.name,
            symbol=normalize_symbol_to_dash(symbol),
            bids=bids,  # Live bids from Binance.US API
            asks=asks,  # Live asks from Binance.US API
            ts=ts,
        )

    async def get_trades(self, symbol: str, limit: int = 100) -> list[Trade]:
        """
        Get live recent trades for a symbol from Binance.US API.

        Args:
            symbol: Trading symbol (from live Binance.US Top-10)
            limit: Maximum number of trades (default: 100, configuration default not fallback data)

        Returns:
            List of live trade data from Binance.US API
        """
        # Convert symbol to exchange format: normalize -> ccxt -> exchange
        dash_symbol = normalize_symbol_to_dash(symbol)
        ccxt_symbol = to_ccxt_symbol(dash_symbol)
        pair = to_exchange_symbol(ccxt_symbol)
        client = await self._rest_client()
        # Get live recent trades from Binance.US API
        data = await client._request("GET", "/api/v3/trades", params={"symbol": pair, "limit": min(limit, 1000)})
        if not data:
            # If live API returns no data, return empty list (error response, not fallback data)
            logger.warning("Live trades data not available for %s from Binance.US API", symbol)
            return []
        out: list[Trade] = []
        for t in data:
            ts = int(t.get("time", 0))
            out.append(
                Trade(
                    exchange=self.name,
                    symbol=normalize_symbol_to_dash(symbol),
                    price=float(t.get("price", 0)),  # Live trade price from Binance.US API
                    qty=float(t.get("qty", 0)),  # Live trade quantity from Binance.US API
                    side="buy" if not t.get("isBuyerMaker", False) else "sell",  # Live trade side from Binance.US API
                    ts=ts,
                ),
            )
        return out[:limit]

    async def get_ohlcv(self, symbol: str, interval: str, limit: int = 500) -> list[OHLCV]:
        """
        Get live OHLCV data for a symbol from Binance.US API.

        Args:
            symbol: Trading symbol (from live Binance.US Top-10)
            interval: Candlestick interval (e.g., "1m", "5m", "1h", "1d")
            limit: Maximum number of candles (default: 500, configuration default not fallback data)

        Returns:
            List of live OHLCV candles from Binance.US API
        """
        # Convert symbol to exchange format: normalize -> ccxt -> exchange
        dash_symbol = normalize_symbol_to_dash(symbol)
        ccxt_symbol = to_ccxt_symbol(dash_symbol)
        pair = to_exchange_symbol(ccxt_symbol)
        client = await self._rest_client()
        # Get live OHLCV data from Binance.US API
        data = await client.klines(pair, interval=interval, limit=min(limit, 1000)) or []
        if not data:
            # If live API returns no data, return empty list (error response, not fallback data)
            logger.warning("Live OHLCV data not available for %s from Binance.US API", symbol)
            return []
        candles: list[OHLCV] = []
        for k in data:
            open_time = int(k[0])
            candles.append(
                OHLCV(
                    exchange=self.name,
                    symbol=normalize_symbol_to_dash(symbol),
                    ts=open_time,
                    open=float(k[1]),  # Live open price from Binance.US API
                    high=float(k[2]),  # Live high price from Binance.US API
                    low=float(k[3]),  # Live low price from Binance.US API
                    close=float(k[4]),  # Live close price from Binance.US API
                    volume=float(k[5]),  # Live volume from Binance.US API
                ),
            )
        return candles

    async def get_balance(self) -> dict[str, float]:
        """
        Get live account balance from Binance.US API.

        NOTE: This is a minimal implementation for interface compliance.
        For full balance retrieval functionality, use:
        - backend.services.live_trading_service.LiveTradingService.get_account_balance()
        - backend.services.binanceus_live_client.BinanceUSLiveClient.fetch_balance()

        Returns:
            Dictionary of live account balances (empty dict for minimal implementation)
        """
        # Full balance functionality available via LiveTradingService or BinanceUSLiveClient
        # This method provides minimal interface compliance only
        return {}  # Minimal implementation - use LiveTradingService for full functionality

    async def create_order(
        self,
        symbol: str,
        side: Literal["buy", "sell"],
        qty: float,
        order_type: Literal["market", "limit"] = "market",
        _price: float | None = None,
    ) -> OrderResult:
        """
        Create live order on Binance.US API.

        NOTE: This is a minimal implementation for interface compliance.
        For full order execution functionality, use:
        - backend.services.live_trading_service.LiveTradingService.place_order()
        - backend.services.binanceus_live_client.BinanceUSLiveClient.create_market_order()
        - backend.services.order_manager_service.OrderManagerService (for advanced order management)

        Args:
            symbol: Trading symbol (from live Binance.US Top-10)
            side: Order side ("buy" or "sell")
            qty: Order quantity
            order_type: Order type ("market" or "limit", default: "market", configuration default not fallback data)
            _price: Limit price (required for limit orders, ignored for market orders - unused in minimal implementation)

        Returns:
            OrderResult with minimal status (use LiveTradingService for full order execution)
        """
        raise NotImplementedError("Use LiveTradingService.place_order() for real orders")
