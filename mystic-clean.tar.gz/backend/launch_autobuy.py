#!/usr/bin/env python3
"""
Binance US Autobuy Launcher
Main launcher for the BTC/ETH/ADA/SOL/DOGE/XRP/BCH/LTC/AVAX/LINK USDT autobuy system
"""

import asyncio
import contextlib
import logging
import os
import signal
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import uvicorn
from autobuy_dashboard import app as dashboard_app
from binance_us_autobuy import autobuy_system

from backend.services.task_manager import task_manager

# Import from single source of truth
try:
    from backend.config.trading_universe import TRADING_SYMBOLS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

from backend.endpoints.autobuy.autobuy_config import (
    get_config,
    validate_and_load_config,
)

# Configure logging (ASCII only)
Path("logs").mkdir(parents=True, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(name)s %(levelname)s %(message)s",
    handlers=[
        logging.FileHandler("logs/autobuy_launcher.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("autobuy_launcher")

# Use TRADING_SYMBOLS from trading_universe (live data)
TOP10_USDT_PAIRS = list(TRADING_SYMBOLS)


class AutobuyLauncher:
    """Main launcher for the Binance US autobuy system"""

    def __init__(self) -> None:
        self.config = get_config()
        self.autobuy_task: asyncio.Task | None = None
        self.dashboard_task: asyncio.Task | None = None
        self.is_running = False
        self.start_time = datetime.now(timezone.utc)
        self._stop_event = asyncio.Event()

    async def start_autobuy_system(self) -> None:
        """Start the autobuy system"""
        try:
            logger.info("Starting Binance US Autobuy System")
            await autobuy_system.run()
        except asyncio.CancelledError:
            logger.info("Autobuy task cancelled")
            raise
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Autobuy system error: %s", e, exc_info=False)

    async def start_dashboard(self) -> None:
        """Start the dashboard server on port 8000"""
        try:
            logger.info("Starting Autobuy Dashboard on http://localhost:8000")
            config = uvicorn.Config(
                dashboard_app,
                host="127.0.0.1",
                port=8000,
                log_level="info",
                access_log=True,
            )
            server = uvicorn.Server(config)
            await server.serve()
        except asyncio.CancelledError:
            logger.info("Dashboard task cancelled")
            raise
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Dashboard error: %s", e, exc_info=False)

    async def run_system(self) -> None:
        """Run the complete autobuy system"""
        try:
            if not validate_and_load_config():
                logger.error("Configuration validation failed")
                return

            logger.info("Configuration validated successfully")
            logger.info("Trading pairs: %s", ", ".join(TOP10_USDT_PAIRS))

            self.autobuy_task = await task_manager.create_task(self.start_autobuy_system(), name="launch_autobuy:autobuy_system")
            self.dashboard_task = await task_manager.create_task(self.start_dashboard(), name="launch_autobuy:dashboard")
            self.is_running = True

            await self._wait_for_stop()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("System error: %s", e, exc_info=False)
        finally:
            await self.shutdown()

    async def _wait_for_stop(self) -> None:
        """Wait until stop event or any task exits unexpectedly"""
        tasks = [t for t in (self.autobuy_task, self.dashboard_task) if t is not None]
        if not tasks:
            return

        stop_task = await task_manager.create_task(self._stop_event.wait(), name="launch_autobuy:stop_waiter")
        pending = {*tasks, stop_task}
        try:
            done, pending = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED)
            for d in done:
                # If any worker task ended (i.e., a done task that is not the stop waiter),
                # trigger shutdown by setting the stop event.
                if d is not stop_task:
                    self._stop_event.set()
        finally:
            for p in pending:
                p.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await p

    async def shutdown(self) -> None:
        """Shutdown the system gracefully"""
        logger.info("Shutting down autobuy system")
        self.is_running = False

        if self.autobuy_task:
            self.autobuy_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self.autobuy_task

        if self.dashboard_task:
            self.dashboard_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self.dashboard_task

        try:
            await autobuy_system.cleanup()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.warning("Cleanup error: %s", e, exc_info=False)

        logger.info("System shutdown complete")

    def get_status(self) -> dict[str, Any]:
        """Get system status"""
        uptime = datetime.now(timezone.utc) - self.start_time
        return {
            "is_running": self.is_running,
            "uptime": str(uptime),
            "start_time": self.start_time.isoformat(),
            "autobuy_task_running": bool(self.autobuy_task and not self.autobuy_task.done()),
            "dashboard_task_running": bool(self.dashboard_task and not self.dashboard_task.done()),
            "config": self.config.to_dict() if self.config is not None else None,
            "trading_pairs": TOP10_USDT_PAIRS,
        }

    def request_stop(self) -> None:
        """Signal the launcher to stop"""
        self._stop_event.set()


# Lazy import for contextlib to keep top ASCII-only imports neat

# Global launcher instance
launcher = AutobuyLauncher()


def _install_signal_handlers(loop: asyncio.AbstractEventLoop) -> None:
    """Install signal handlers (best-effort; Windows supports limited signals)"""

    def _handler(signum, _frame):
        logger.info("Received signal %s, initiating shutdown", signum)
        launcher.request_stop()

    for sig in (getattr(signal, "SIGINT", None), getattr(signal, "SIGTERM", None)):
        if sig is not None:
            try:
                # On Unix, prefer add_signal_handler; on Windows, fallback to signal.signal
                if hasattr(loop, "add_signal_handler"):
                    loop.add_signal_handler(sig, launcher.request_stop)
                else:
                    signal.signal(sig, _handler)  # type: ignore[arg-type]
            except (NotImplementedError, ValueError):
                with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    signal.signal(sig, _handler)  # type: ignore[arg-type]


async def main() -> None:
    """Main entrypoint coroutine"""
    # Environment checks (API keys required)
    missing = [v for v in ("BINANCE_US_API_KEY", "BINANCE_US_SECRET_KEY") if not os.getenv(v)]
    if missing:
        logger.error("Missing required environment variables: %s", ", ".join(missing))
        sys.exit(1)

    loop = asyncio.get_running_loop()
    _install_signal_handlers(loop)

    logger.info("Binance US Autobuy Launcher Starting")
    logger.info("Dashboard: http://localhost:8000")
    logger.info("Backend expected on port 8000 if used")
    await launcher.run_system()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Shutdown requested by user")
    except SystemExit:
        pass
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        logger.exception("Fatal error: %s", e, exc_info=False)
        sys.exit(1)
