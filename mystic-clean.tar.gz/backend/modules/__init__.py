"""
Backend Modules Package - All Live Data, No Fallback/Hardcoded Data

Lightweight aggregator for backend.modules (backend port 8000).
All submodules handle live data operations:
- AI modules: Live AI models, predictions, and learning (backend port 8000)
- Data modules: Live market data from Binance.US API
- Trading modules: Live trading operations and order management (backend port 8000)
- Signals modules: Live signal generation and processing (backend port 8000)
- Strategy modules: Live strategy execution and analysis (backend port 8000)
- Metrics modules: Live performance metrics collection (backend port 8000)
- Notifications modules: Live notification services (backend port 8000)
- API modules: Live API endpoints and routers (backend port 8000)
- Market modules: Live market data fetching from Binance.US
- All modules use live connections - no fallback/hardcoded data

Endpoint References:
- Backend API: Port 8000 (all modules serve live operations)
- Binance.US API: Live market data and trading operations
- All submodules handle live data - no mock/test data
"""

from importlib import import_module

__all__: list[str] = []
# Add likely subpackages here; missing ones are skipped cleanly.
# All subpackages handle live data operations (backend port 8000)
# Error handling for missing dependencies - IMPORT ERROR IS ESCALATED. ALL DATA MUST BE LIVE. NO FALLBACK.
for _name in [
    "ai",  # Live AI models, predictions, learning
    "data",  # Live market data from Binance.US
    "trading",  # Live trading operations
    "signals",  # Live signal generation
    "strategy",  # Live strategy execution
    "metrics",  # Live performance metrics
    "notifications",  # Live notification services
    "api",  # Live API endpoints
    "market",  # Live market data fetching
]:
    try:
        globals()[_name] = import_module(f"{__name__}.{_name}")
        __all__.append(_name)
    except (ImportError, ModuleNotFoundError):
        # Skip missing modules gracefully - they may not exist in all deployments
        pass
