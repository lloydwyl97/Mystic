"""
AI Module for Mystic Trading Platform - All Live Data, No Fallback/Hardcoded Data

Contains all AI-related functionality for live trading operations (backend port 8000):
- AI strategies: Live AI-driven trading strategies using live market data
- Signals: Live signal generation from live market analysis
- Pattern recognition: Live pattern recognition on live Binance.US market data
- Live trading: Live trading execution via Binance.US API
- All AI operations use live data - no fallback/hardcoded data

Endpoint References:
- Backend API: Port 8000 (AI modules serve live operations)
- Binance.US API: Live market data for AI analysis and trading
- All AI functionality uses live connections - no mock/test data
"""

from __future__ import annotations

# Core brain (live AI operations)
from .ai_brains import AIBrain

# Direct imports for production (live signal generation)
from .ai_signals import (
    get_trade_summary,
    get_trading_status,
    market_strength_signals,
    mystic_oracle,
    risk_adjusted_signals,
    signal_scorer,
    technical_signals,
    trend_analysis,
)

__all__: list[str] = [
    "AIBrain",  # Live AI brain operations
    "get_trade_summary",  # Live trade summary generation
    "get_trading_status",  # Live trading status
    "market_strength_signals",  # Live market strength signals
    "mystic_oracle",  # Live oracle predictions
    "risk_adjusted_signals",  # Live risk-adjusted signals
    "signal_scorer",  # Live signal scoring
    "technical_signals",  # Live technical signals
    "trend_analysis",  # Live trend analysis
]
