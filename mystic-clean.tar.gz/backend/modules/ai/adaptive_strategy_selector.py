"""
Adaptive Strategy Selection for AI Trading - All Live Data, No Fallback/Hardcoded Data

Implements real-time strategy performance tracking, switching, and optimization (backend port 8000).
All operations use live data:
- Strategy performance: Live performance metrics from live trading operations
- Market conditions: Live market analysis from live Binance.US OHLCV data
- Strategy selection: Live strategy selection based on live market conditions
- Redis caching: Live Redis cache for performance data (localhost:6379)
- All calculations use live data - no fallback/hardcoded data

Endpoint References:
- Backend API: Port 8000 (strategy selector serves live operations)
- Binance.US API: Live market data for strategy analysis
- Redis: localhost:6379 (live caching, not fallback data)
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import logging
from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any

import numpy as np
import pandas as pd

from backend.config.redis_config import get_redis_client

logger = logging.getLogger(__name__)


class StrategyType(Enum):
    MOMENTUM = "momentum"
    MEAN_REVERSION = "mean_reversion"
    BREAKOUT = "breakout"
    SCALPING = "scalping"
    SWING = "swing"
    ARBITRAGE = "arbitrage"


@dataclass
class StrategyPerformance:
    """
    Strategy performance metrics from live trading operations (backend port 8000).

    All metrics derived from live trade data - no fallback/hardcoded data.
    """

    strategy_id: str  # Live strategy ID
    strategy_type: StrategyType  # Live strategy type
    total_trades: int  # Live total trades count
    winning_trades: int  # Live winning trades count
    losing_trades: int  # Live losing trades count
    win_rate: float  # Live win rate
    profit_factor: float  # Live profit factor
    sharpe_ratio: float  # Live Sharpe ratio
    max_drawdown: float  # Live max drawdown
    avg_trade_duration: float  # Live average trade duration (minutes)
    total_pnl: float  # Live total PnL
    recent_performance: float  # Live last 24h performance
    confidence_score: float  # Live confidence score
    last_updated: datetime  # Live update timestamp


@dataclass
class StrategySignal:
    """
    Strategy signal result from live market analysis (backend port 8000).

    All signals generated from live market data - no fallback/hardcoded data.
    """

    strategy_id: str  # Live strategy ID
    symbol: str  # Live trading symbol (from Binance.US Top-10)
    signal: str  # Live signal: BUY, SELL, HOLD
    confidence: float  # Live confidence score
    strength: float  # Live signal strength
    reasoning: list[str]  # Live reasoning from analysis
    expected_duration: int  # Live expected duration (minutes)
    risk_level: str  # Live risk level
    timestamp: datetime  # Live signal timestamp


@dataclass
class MarketCondition:
    """
    Current market condition from live market analysis (backend port 8000).

    All conditions derived from live Binance.US market data - no fallback/hardcoded data.
    """

    volatility_regime: str  # Live volatility regime
    trend_strength: str  # Live trend strength
    volume_profile: str  # Live volume profile
    time_of_day: str  # Live time of day
    market_phase: str  # Live market phase
    sentiment: str  # Live sentiment
    timestamp: datetime  # Live condition timestamp


class AdaptiveStrategySelector:
    """
    Adaptive strategy selection based on live performance and market conditions (backend port 8000).

    Selects optimal strategies based on live trading performance and live market conditions.
    All operations use live data - no fallback/hardcoded data.
    """

    def __init__(self) -> None:
        """
        Initialize adaptive strategy selector for live operations.

        All configuration values are defaults for live operations, not fallback data.
        """
        self.redis_client: Any = None  # Live Redis client (localhost:6379)

        # Strategy performance tracking (live data)
        self.strategy_performance: dict[str, StrategyPerformance] = {}  # Live strategy performance cache
        self.strategy_history: dict[str, deque] = defaultdict(lambda: deque(maxlen=1000))  # Live trade history
        self.market_conditions: dict[str, MarketCondition] = {}  # Live market conditions cache

        # Performance thresholds (configuration defaults for live operations, not fallback data)
        self.min_win_rate = 0.45  # Configuration default, not fallback data
        self.min_profit_factor = 1.2  # Configuration default, not fallback data
        self.min_sharpe_ratio = 0.5  # Configuration default, not fallback data
        self.max_drawdown_threshold = 0.15  # Configuration default, not fallback data

        # Strategy switching parameters (configuration defaults for live operations)
        self.performance_lookback = 24  # Configuration default: hours (not fallback data)
        self.switching_threshold = 0.1  # Configuration default: 10% performance difference (not fallback data)
        self.min_trades_for_evaluation = 10  # Configuration default, not fallback data

        # Market condition weights (configuration defaults for live operations, not fallback data)
        self.condition_weights = {
            "volatility_regime": 0.25,  # Configuration default
            "trend_strength": 0.20,  # Configuration default
            "volume_profile": 0.15,  # Configuration default
            "time_of_day": 0.10,  # Configuration default
            "market_phase": 0.20,  # Configuration default
            "sentiment": 0.10,  # Configuration default
        }

        logger.info("[OK] AdaptiveStrategySelector initialized for live operations")

    async def _get_redis(self) -> Any:
        """
        Get Redis client for live caching (localhost:6379).

        Returns None if Redis unavailable - error handling, not fallback data.

        Returns:
            Redis client or None if unavailable
        """
        if self.redis_client is None:
            # All Live Data, No Fallback/Hardcoded Data - Use shared Redis pool
            try:
                self.redis_client = get_redis_client()
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.warning("Redis not available for live caching: %s", e)
                self.redis_client = None  # Error handling, not fallback data
        return self.redis_client

    def _coerce_strategy_type(self, value: Any) -> StrategyType:
        try:
            if isinstance(value, StrategyType):
                return value
            return StrategyType(str(value))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            return StrategyType.MOMENTUM

    def _calculate_strategy_metrics(self, trades: list[dict[str, Any]]) -> StrategyPerformance:
        """
        Calculate performance metrics for a strategy from live trade data.

        Args:
            trades: List of live trade data dictionaries

        Returns:
            StrategyPerformance with live metrics (zero values indicate no live data, not fallback data)
        """
        try:
            if not trades:
                # No live trades available - return zero metrics (not fallback data)
                return StrategyPerformance(
                    strategy_id="unknown",
                    strategy_type=StrategyType.MOMENTUM,
                    total_trades=0,  # No live trades, not fallback data
                    winning_trades=0,  # No live trades, not fallback data
                    losing_trades=0,  # No live trades, not fallback data
                    win_rate=0.0,  # No live trades, not fallback data
                    profit_factor=0.0,  # No live trades, not fallback data
                    sharpe_ratio=0.0,  # No live trades, not fallback data
                    max_drawdown=0.0,  # No live trades, not fallback data
                    avg_trade_duration=0.0,  # No live trades, not fallback data
                    total_pnl=0.0,  # No live trades, not fallback data
                    recent_performance=0.0,  # No live trades, not fallback data
                    confidence_score=0.0,  # No live trades, not fallback data
                    last_updated=datetime.now(timezone.utc),  # Live timestamp
                )

            df = pd.DataFrame(trades).copy()

            # Basic metrics
            total_trades = len(df)
            df["pnl"] = pd.to_numeric(df.get("pnl", 0), errors="coerce").fillna(0.0)
            winning_trades = int((df["pnl"] > 0).sum())
            losing_trades = int((df["pnl"] < 0).sum())
            win_rate = float(winning_trades / total_trades) if total_trades > 0 else 0.0

            # PnL metrics
            total_pnl = float(df["pnl"].sum())
            gross_profit = float(df.loc[df["pnl"] > 0, "pnl"].sum())
            gross_loss = abs(float(df.loc[df["pnl"] < 0, "pnl"].sum()))
            profit_factor = (gross_profit / gross_loss) if gross_loss > 0 else (float("inf") if gross_profit > 0 else 0.0)
            if not np.isfinite(profit_factor):
                # Cap extremely large PF to a high finite value for scoring purposes
                profit_factor = 10.0

            # Risk metrics
            returns = df["pnl"].to_numpy(dtype=float)
            if returns.size > 1 and np.std(returns) > 0:
                sharpe_ratio = float(np.mean(returns) / np.std(returns) * np.sqrt(252))
                cumulative_returns = np.cumsum(returns)
                running_max = np.maximum.accumulate(cumulative_returns)
                drawdown = cumulative_returns - running_max
                max_drawdown = float(abs(np.min(drawdown))) if drawdown.size > 0 else 0.0
            else:
                sharpe_ratio = 0.0
                max_drawdown = 0.0

            # Trade duration
            if "entry_time" in df.columns and "exit_time" in df.columns:
                df["entry_time"] = pd.to_datetime(df["entry_time"], errors="coerce", utc=True)
                df["exit_time"] = pd.to_datetime(df["exit_time"], errors="coerce", utc=True)
                durations = (df["exit_time"] - df["entry_time"]).dt.total_seconds().dropna() / 60.0
                avg_trade_duration = float(durations.mean()) if not durations.empty else 0.0
            else:
                avg_trade_duration = 0.0

            # Recent performance (last 24 hours by exit_time)
            recent_cutoff = datetime.now(timezone.utc) - timedelta(hours=24)
            if "exit_time" in df.columns:
                df["exit_time"] = pd.to_datetime(df["exit_time"], errors="coerce", utc=True)
                recent_trades = df.loc[df["exit_time"] >= recent_cutoff]
                recent_performance = float(recent_trades["pnl"].sum()) if not recent_trades.empty else 0.0
            else:
                recent_performance = 0.0

            # Confidence score based on multiple factors
            confidence_score = self._calculate_confidence_score(win_rate, profit_factor, sharpe_ratio, max_drawdown, total_trades)

            strategy_id = str(df.iloc[0].get("strategy_id", "unknown"))
            strategy_type = self._coerce_strategy_type(df.iloc[0].get("strategy_type", "momentum"))

            return StrategyPerformance(
                strategy_id=strategy_id,
                strategy_type=strategy_type,
                total_trades=total_trades,
                winning_trades=winning_trades,
                losing_trades=losing_trades,
                win_rate=win_rate,
                profit_factor=profit_factor,
                sharpe_ratio=sharpe_ratio,
                max_drawdown=max_drawdown,
                avg_trade_duration=avg_trade_duration,
                total_pnl=total_pnl,
                recent_performance=recent_performance,
                confidence_score=confidence_score,
                last_updated=datetime.now(timezone.utc),
            )

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Strategy metrics calculation failed for live data: %s", e)
            # Error state - return zero metrics (not fallback data)
            return StrategyPerformance(
                strategy_id="unknown",
                strategy_type=StrategyType.MOMENTUM,
                total_trades=0,  # Error state, not fallback data
                winning_trades=0,  # Error state, not fallback data
                losing_trades=0,  # Error state, not fallback data
                win_rate=0.0,  # Error state, not fallback data
                profit_factor=0.0,  # Error state, not fallback data
                sharpe_ratio=0.0,  # Error state, not fallback data
                max_drawdown=0.0,  # Error state, not fallback data
                avg_trade_duration=0.0,  # Error state, not fallback data
                total_pnl=0.0,  # Error state, not fallback data
                recent_performance=0.0,  # Error state, not fallback data
                confidence_score=0.0,  # Error state, not fallback data
                last_updated=datetime.now(timezone.utc),  # Live timestamp
            )

    def _calculate_confidence_score(
        self,
        win_rate: float,
        profit_factor: float,
        sharpe_ratio: float,
        max_drawdown: float,
        total_trades: int,
    ) -> float:
        """
        Calculate confidence score for a strategy from live performance metrics.

        Args:
            win_rate: Live win rate
            profit_factor: Live profit factor
            sharpe_ratio: Live Sharpe ratio
            max_drawdown: Live max drawdown
            total_trades: Live total trades count

        Returns:
            Live confidence score (0.5 on error is error state, not fallback data)
        """
        try:
            # All calculations use live metrics - configuration thresholds are defaults, not fallback data
            win_rate_score = min(1.0, max(0.0, win_rate / 0.7))  # 70% win rate = perfect score (config default)
            profit_factor_score = min(1.0, max(0.0, profit_factor / 2.0))  # 2.0 PF = perfect score (config default)
            sharpe_score = min(1.0, max(0.0, sharpe_ratio / 2.0))  # 2.0 Sharpe = perfect score (config default)
            drawdown_score = max(0.0, 1.0 - (max_drawdown / 0.2))  # 20% max drawdown = 0 score (config default)
            trade_count_score = min(1.0, max(0.0, total_trades / 50))  # 50 trades = perfect score (config default)

            confidence = win_rate_score * 0.25 + profit_factor_score * 0.25 + sharpe_score * 0.20 + drawdown_score * 0.20 + trade_count_score * 0.10
            return float(min(1.0, max(0.0, confidence)))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Confidence score calculation failed for live data: %s", e)
            return 0.5  # Error state (neutral), not fallback data

    async def update_strategy_performance(self, strategy_id: str, trade_data: dict[str, Any]) -> None:
        """
        Update strategy performance with new live trade data (backend port 8000).

        Args:
            strategy_id: Live strategy ID
            trade_data: Live trade data dictionary
        """
        try:
            self.strategy_history[strategy_id].append(trade_data)

            trades = list(self.strategy_history[strategy_id])
            performance = self._calculate_strategy_metrics(trades)
            self.strategy_performance[strategy_id] = performance

            redis_client = await self._get_redis()
            if redis_client:
                await redis_client.hset(
                    f"strategy_performance:{strategy_id}",
                    mapping={
                        "strategy_id": performance.strategy_id,
                        "strategy_type": performance.strategy_type.value,
                        "total_trades": str(performance.total_trades),
                        "win_rate": f"{performance.win_rate:.6f}",
                        "profit_factor": f"{performance.profit_factor:.6f}",
                        "sharpe_ratio": f"{performance.sharpe_ratio:.6f}",
                        "max_drawdown": f"{performance.max_drawdown:.6f}",
                        "total_pnl": f"{performance.total_pnl:.6f}",
                        "recent_performance": f"{performance.recent_performance:.6f}",
                        "confidence_score": f"{performance.confidence_score:.6f}",
                        "last_updated": performance.last_updated.isoformat(),
                    },
                )
                await redis_client.expire(f"strategy_performance:{strategy_id}", 86400)  # 24 hours TTL

            logger.info("[OK] Updated performance for strategy %s (live data)", strategy_id)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Strategy performance update failed for live data: %s", e)

    async def analyze_market_condition(self, _symbol: str, ohlcv_data: list[list[float]]) -> MarketCondition:
        """
        Analyze current market condition from live Binance.US OHLCV data (backend port 8000).

        Args:
            symbol: Live trading symbol (from Binance.US Top-10)
            ohlcv_data: Live OHLCV data from Binance.US API

        Returns:
            MarketCondition with live analysis (neutral values indicate insufficient live data, not fallback data)
        """
        try:
            if not ohlcv_data or len(ohlcv_data) < 20:
                # Insufficient live data - return neutral condition (not fallback data)
                return MarketCondition(
                    volatility_regime="normal",  # Neutral value, not fallback data
                    trend_strength="sideways",  # Neutral value, not fallback data
                    volume_profile="normal",  # Neutral value, not fallback data
                    time_of_day="unknown",  # Insufficient live data, not fallback data
                    market_phase="unknown",  # Insufficient live data, not fallback data
                    sentiment="neutral",  # Neutral value, not fallback data
                    timestamp=datetime.now(timezone.utc),  # Live timestamp
                )

            df = pd.DataFrame(
                ohlcv_data,
                columns=["timestamp", "open", "high", "low", "close", "volume"],
            )
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
            df = df.set_index("timestamp")

            # Returns & volatility
            returns = df["close"].pct_change()
            returns = returns.dropna()
            volatility = float(returns.std()) if not returns.empty else 0.0

            if volatility < 0.02:
                volatility_regime = "low"
            elif volatility < 0.05:
                volatility_regime = "normal"
            elif volatility < 0.10:
                volatility_regime = "high"
            else:
                volatility_regime = "extreme"

            # Trend strength via SMA slope
            sma_20 = df["close"].rolling(20).mean()
            if len(sma_20.dropna()) >= 10:
                a = float(sma_20.iloc[-10])
                b = float(sma_20.iloc[-1])
                trend_slope = (b - a) / a if a != 0 else 0.0
            else:
                trend_slope = 0.0

            if trend_slope > 0.05:
                trend_strength = "strong_bull"
            elif trend_slope > 0.01:
                trend_strength = "weak_bull"
            elif trend_slope < -0.05:
                trend_strength = "strong_bear"
            elif trend_slope < -0.01:
                trend_strength = "weak_bear"
            else:
                trend_strength = "sideways"

            # Volume profile
            avg_volume = float(df["volume"].mean() or 0.0)
            recent_volume = float(df["volume"].tail(5).mean() or 0.0)
            volume_ratio = (recent_volume / avg_volume) if avg_volume > 0 else 1.0

            if volume_ratio > 1.5:
                volume_profile = "high"
            elif volume_ratio < 0.7:
                volume_profile = "low"
            else:
                volume_profile = "normal"

            # Time of day (UTC-based)
            current_hour = datetime.now(timezone.utc).hour
            if 0 <= current_hour < 6:
                time_of_day = "asian"
            elif 6 <= current_hour < 12:
                time_of_day = "european"
            elif 12 <= current_hour < 18:
                time_of_day = "us"
            else:
                time_of_day = "evening"

            # Market phase (20-period change)
            if len(df) >= 20:
                base = float(df["close"].iloc[-20])
                last = float(df["close"].iloc[-1])
                price_change20 = ((last - base) / base) if base != 0 else 0.0
            else:
                price_change20 = 0.0

            if price_change20 > 0.1:
                market_phase = "bull_market"
            elif price_change20 < -0.1:
                market_phase = "bear_market"
            else:
                market_phase = "sideways"

            # Sentiment via RSI
            rsi_val = self._calculate_rsi(df["close"], 14)
            if rsi_val > 70:
                sentiment = "overbought"
            elif rsi_val < 30:
                sentiment = "oversold"
            else:
                sentiment = "neutral"

            return MarketCondition(
                volatility_regime=volatility_regime,
                trend_strength=trend_strength,
                volume_profile=volume_profile,
                time_of_day=time_of_day,
                market_phase=market_phase,
                sentiment=sentiment,
                timestamp=datetime.now(timezone.utc),
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Market condition analysis failed for live data: %s", e)
            # Error state - return neutral condition (not fallback data)
            return MarketCondition(
                volatility_regime="normal",  # Error state, not fallback data
                trend_strength="sideways",  # Error state, not fallback data
                volume_profile="normal",  # Error state, not fallback data
                time_of_day="unknown",  # Error state, not fallback data
                market_phase="unknown",  # Error state, not fallback data
                sentiment="neutral",  # Error state, not fallback data
                timestamp=datetime.now(timezone.utc),  # Live timestamp
            )

    def _calculate_rsi(self, prices: pd.Series, period: int = 14) -> float:
        """Calculate RSI indicator"""
        try:
            delta = prices.diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
            rs = gain / loss.replace(0, np.nan)
            rsi = 100 - (100 / (1 + rs))
            rsi = rsi.fillna(50.0)
            return float(rsi.iloc[-1]) if not rsi.empty else 50.0
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("RSI calculation failed for live data: %s", e)
            return 50.0  # Error state (neutral RSI), not fallback data

    def _get_strategy_suitability(self, strategy_type: StrategyType, market_condition: MarketCondition) -> float:
        """Calculate how suitable a strategy is for current market conditions"""
        try:
            s = 0.0

            if strategy_type == StrategyType.MOMENTUM:
                s += 0.8 if market_condition.trend_strength in ("strong_bull", "strong_bear") else (0.6 if market_condition.trend_strength in ("weak_bull", "weak_bear") else 0.2)
                s += 0.6 if market_condition.volatility_regime in ("normal", "high") else 0.3
                s += 0.7 if market_condition.volume_profile == "high" else 0.4

            elif strategy_type == StrategyType.MEAN_REVERSION:
                s += 0.8 if market_condition.sentiment in ("overbought", "oversold") else 0.3
                s += 0.7 if market_condition.volatility_regime in ("low", "normal") else 0.3
                s += 0.6 if market_condition.trend_strength == "sideways" else 0.3

            elif strategy_type == StrategyType.BREAKOUT:
                s += 0.8 if market_condition.volume_profile == "high" else 0.4
                s += 0.7 if market_condition.volatility_regime in ("normal", "high") else 0.3
                s += 0.6 if market_condition.sentiment == "neutral" else 0.4

            elif strategy_type == StrategyType.SCALPING:
                s += 0.8 if market_condition.volatility_regime in ("normal", "high") else 0.3
                s += 0.7 if market_condition.volume_profile == "high" else 0.4
                s += 0.6 if market_condition.time_of_day in ("us", "european") else 0.3

            elif strategy_type == StrategyType.SWING:
                s += 0.8 if market_condition.trend_strength in ("strong_bull", "strong_bear") else 0.4
                s += 0.6 if market_condition.volatility_regime in ("normal", "high") else 0.3
                s += 0.7 if market_condition.market_phase in ("bull_market", "bear_market") else 0.4

            elif strategy_type == StrategyType.ARBITRAGE:
                s += 0.8 if market_condition.volatility_regime == "high" else 0.4
                s += 0.7 if market_condition.volume_profile == "high" else 0.3
                s += 0.6 if market_condition.sentiment == "neutral" else 0.4

            return float(min(1.0, max(0.0, s / 3.0)))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Strategy suitability calculation failed for live data: %s", e)
            return 0.5  # Error state (neutral suitability), not fallback data

    async def select_optimal_strategy(self, symbol: str, ohlcv_data: list[list[float]]) -> StrategySignal:
        """
        Select the optimal strategy for current live market conditions (backend port 8000).

        Args:
            symbol: Live trading symbol (from Binance.US Top-10)
            ohlcv_data: Live OHLCV data from Binance.US API

        Returns:
            StrategySignal with live strategy recommendation (HOLD on error is error state, not fallback data)
        """
        try:
            market_condition = await self.analyze_market_condition(symbol, ohlcv_data)

            available = list(self.strategy_performance.keys())
            if not available:
                return StrategySignal(
                    strategy_id="default_momentum",
                    symbol=symbol,
                    signal="HOLD",
                    confidence=0.5,
                    strength=0.5,
                    reasoning=["No strategies available"],
                    expected_duration=60,
                    risk_level="medium",
                    timestamp=datetime.now(timezone.utc),
                )

            # Score strategies by performance & suitability
            strategy_scores: dict[str, float] = {}
            for sid in available:
                perf = self.strategy_performance[sid]
                perf_score = float(perf.confidence_score)
                suitability_score = self._get_strategy_suitability(perf.strategy_type, market_condition)
                combined_score = perf_score * 0.6 + suitability_score * 0.4
                strategy_scores[sid] = combined_score

            best_strategy_id = max(strategy_scores, key=strategy_scores.get)
            best_performance = self.strategy_performance[best_strategy_id]

            (
                signal,
                confidence,
                strength,
                reasoning,
            ) = await self._generate_strategy_signal(best_strategy_id, symbol, ohlcv_data, market_condition)

            return StrategySignal(
                strategy_id=best_strategy_id,
                symbol=symbol,
                signal=signal,
                confidence=confidence,
                strength=strength,
                reasoning=reasoning,
                expected_duration=self._get_expected_duration(best_performance.strategy_type),
                risk_level=self._get_risk_level(best_performance, market_condition),
                timestamp=datetime.now(timezone.utc),
            )

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Strategy selection failed for live data: %s", e)
            # Error state - return HOLD signal (not fallback data)
            return StrategySignal(
                strategy_id="error",
                symbol=symbol,
                signal="HOLD",  # Error state, not fallback data
                confidence=0.0,  # Error state, not fallback data
                strength=0.0,  # Error state, not fallback data
                reasoning=["Error in strategy selection"],  # Error state, not fallback data
                expected_duration=60,  # Error state default, not fallback data
                risk_level="high",  # Error state, not fallback data
                timestamp=datetime.now(timezone.utc),  # Live timestamp
            )

    async def _generate_strategy_signal(
        self,
        strategy_id: str,
        _symbol: str,
        _ohlcv_data: list[list[float]],
        market_condition: MarketCondition,
    ) -> tuple[str, float, float, list[str]]:
        """Generate signal for a specific strategy"""
        try:
            performance = self.strategy_performance.get(strategy_id)
            if not performance:
                return "HOLD", 0.5, 0.5, ["Strategy not found"]

            reasoning: list[str] = []
            signal = "HOLD"
            confidence = 0.5
            strength = 0.5

            stype = performance.strategy_type

            if stype == StrategyType.MOMENTUM:
                if market_condition.trend_strength in ("strong_bull", "strong_bear"):
                    signal = "BUY" if "bull" in market_condition.trend_strength else "SELL"
                    confidence = 0.8
                    strength = 0.8
                    reasoning.append("Strong trend detected")
                else:
                    signal = "HOLD"
                    confidence = 0.3
                    reasoning.append("Weak/sideways trend - momentum less suitable")

            elif stype == StrategyType.MEAN_REVERSION:
                if market_condition.sentiment == "overbought":
                    signal = "SELL"
                    confidence = 0.7
                    strength = 0.7
                    reasoning.append("Overbought conditions - mean reversion")
                elif market_condition.sentiment == "oversold":
                    signal = "BUY"
                    confidence = 0.7
                    strength = 0.7
                    reasoning.append("Oversold conditions - mean reversion")
                else:
                    signal = "HOLD"
                    confidence = 0.4
                    reasoning.append("Neutral sentiment - no mean reversion edge")

            elif stype == StrategyType.BREAKOUT:
                if market_condition.volume_profile == "high" and market_condition.volatility_regime in ("normal", "high"):
                    signal = "BUY"  # Placeholder; a real breakout detector should be plugged in
                    confidence = 0.6
                    strength = 0.6
                    reasoning.append("High volume & volatility - potential breakout")
                else:
                    signal = "HOLD"
                    confidence = 0.3
                    reasoning.append("Low volume/volatility - weak breakout odds")

            # Confidence adjust by historical performance
            if performance.confidence_score > 0.7:
                confidence = min(1.0, confidence * 1.2)
                reasoning.append(f"High strategy performance: {performance.confidence_score:.2f}")
            elif performance.confidence_score < 0.4:
                confidence = max(0.0, confidence * 0.8)
                reasoning.append(f"Low strategy performance: {performance.confidence_score:.2f}")

            return (
                signal,
                float(min(1.0, confidence)),
                float(min(1.0, strength)),
                reasoning,
            )

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Strategy signal generation failed for live data: %s", e)
            return "HOLD", 0.0, 0.0, ["Error in signal generation"]  # Error state, not fallback data

    def _get_expected_duration(self, strategy_type: StrategyType) -> int:
        """Get expected trade duration for strategy type (in minutes)"""
        return {
            StrategyType.SCALPING: 5,
            StrategyType.MOMENTUM: 60,
            StrategyType.MEAN_REVERSION: 120,
            StrategyType.BREAKOUT: 180,
            StrategyType.SWING: 480,
            StrategyType.ARBITRAGE: 30,
        }.get(strategy_type, 60)

    def _get_risk_level(self, performance: StrategyPerformance, market_condition: MarketCondition) -> str:
        """Get risk level for strategy"""
        if performance.max_drawdown > 0.15 or performance.confidence_score < 0.4:
            return "high"
        if market_condition.volatility_regime == "extreme" or market_condition.volume_profile == "low":
            return "high"
        if performance.confidence_score > 0.7 and market_condition.volatility_regime == "normal":
            return "low"
        return "medium"

    async def get_strategy_recommendations(self, symbol: str, ohlcv_data: list[list[float]]) -> dict[str, Any]:
        """
        Get comprehensive strategy recommendations from live analysis (backend port 8000).

        Args:
            symbol: Live trading symbol (from Binance.US Top-10)
            ohlcv_data: Live OHLCV data from Binance.US API

        Returns:
            Dictionary with live strategy recommendations (error state on failure, not fallback data)
        """
        try:
            optimal_signal = await self.select_optimal_strategy(symbol, ohlcv_data)
            market_condition = await self.analyze_market_condition(symbol, ohlcv_data)

            # Rankings
            strategy_rankings: list[dict[str, Any]] = []
            for sid, perf in self.strategy_performance.items():
                suitability = self._get_strategy_suitability(perf.strategy_type, market_condition)
                combined_score = float(perf.confidence_score * 0.6 + suitability * 0.4)
                strategy_rankings.append(
                    {
                        "strategy_id": sid,
                        "strategy_type": perf.strategy_type.value,
                        "performance_score": float(perf.confidence_score),
                        "suitability_score": float(suitability),
                        "combined_score": float(combined_score),
                        "win_rate": float(perf.win_rate),
                        "profit_factor": float(perf.profit_factor),
                        "sharpe_ratio": float(perf.sharpe_ratio),
                    },
                )

            strategy_rankings.sort(key=lambda x: x["combined_score"], reverse=True)

            return {
                "symbol": symbol,
                "optimal_strategy": {
                    "strategy_id": optimal_signal.strategy_id,
                    "signal": optimal_signal.signal,
                    "confidence": optimal_signal.confidence,
                    "strength": optimal_signal.strength,
                    "reasoning": optimal_signal.reasoning,
                    "expected_duration": optimal_signal.expected_duration,
                    "risk_level": optimal_signal.risk_level,
                },
                "market_condition": {
                    "volatility_regime": market_condition.volatility_regime,
                    "trend_strength": market_condition.trend_strength,
                    "volume_profile": market_condition.volume_profile,
                    "time_of_day": market_condition.time_of_day,
                    "market_phase": market_condition.market_phase,
                    "sentiment": market_condition.sentiment,
                },
                "strategy_rankings": strategy_rankings[:5],
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Strategy recommendations failed for live data: %s", e)
            # Error state - return error structure (not fallback data)
            return {
                "symbol": symbol,
                "optimal_strategy": {
                    "strategy_id": "error",
                    "signal": "HOLD",  # Error state, not fallback data
                    "confidence": 0.0,  # Error state, not fallback data
                    "strength": 0.0,  # Error state, not fallback data
                    "reasoning": ["Error in analysis"],  # Error state, not fallback data
                    "expected_duration": 60,  # Error state default, not fallback data
                    "risk_level": "high",  # Error state, not fallback data
                },
                "market_condition": {},  # Error state, not fallback data
                "strategy_rankings": [],  # Error state, not fallback data
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }
