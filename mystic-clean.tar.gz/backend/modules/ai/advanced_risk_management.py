"""
Advanced Risk Management for AI Trading - All Live Data, No Fallback/Hardcoded Data

Implements VaR, CVaR, Monte Carlo analysis, and real-time risk monitoring (backend port 8000).
All operations use live data:
- Risk metrics: Calculated from live Binance.US market data
- Portfolio risk: Analyzed from live portfolio positions
- BTC returns: Fetched from live Binance.US API for beta calculation
- Redis caching: Live Redis cache for risk data (localhost:6379)
- All calculations use live data - no fallback/hardcoded data

Endpoint References:
- Backend API: Port 8000 (risk manager serves live operations)
- Binance.US API: Live market data for risk calculations
- Redis: localhost:6379 (live caching, not fallback data)
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import json
import logging
import warnings
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats

from backend.config.redis_config import get_redis_client
from backend.modules.constants import EXCHANGE_ID  # single source of truth
from backend.utils.symbols import to_ccxt_symbol as _to_ccxt_symbol

# Optional import for BTC data fetching
try:
    from backend.exchanges.binanceus_adapter import BinanceUSAdapter  # type: ignore[import-not-found]
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    BinanceUSAdapter = None  # type: ignore[assignment, misc]

warnings.filterwarnings("ignore")

logger = logging.getLogger(__name__)


@dataclass
class RiskMetrics:
    """
    Risk metrics calculation result from live market data (backend port 8000).

    All metrics derived from live Binance.US market data - no fallback/hardcoded data.
    """

    symbol: str  # Live trading symbol (from Binance.US Top-10)
    var_1d: float  # Live 1-day Value at Risk
    var_5d: float  # Live 5-day Value at Risk
    cvar_1d: float  # Live 1-day Conditional VaR
    cvar_5d: float  # Live 5-day Conditional VaR
    sharpe_ratio: float  # Live Sharpe ratio
    max_drawdown: float  # Live max drawdown
    volatility: float  # Live volatility
    beta: float  # Live beta (vs market)
    correlation_matrix: dict[str, float]  # Live correlation data
    monte_carlo_scenarios: list[float]  # Live Monte Carlo scenarios
    risk_score: float  # Live risk score
    timestamp: datetime  # Live metrics timestamp


@dataclass
class PortfolioRisk:
    """
    Portfolio-level risk analysis from live portfolio data (backend port 8000).

    All metrics calculated from live portfolio positions and market data - no fallback/hardcoded data.
    """

    total_var: float  # Live portfolio VaR
    total_cvar: float  # Live portfolio Conditional VaR
    portfolio_volatility: float  # Live portfolio volatility
    portfolio_sharpe: float  # Live portfolio Sharpe ratio
    diversification_ratio: float  # Live diversification ratio
    concentration_risk: float  # Live concentration risk
    tail_risk: float  # Live tail risk
    stress_test_results: dict[str, float]  # Live stress test results
    timestamp: datetime  # Live analysis timestamp


class AdvancedRiskManager:
    """
    Advanced risk management with VaR, CVaR, and Monte Carlo analysis (backend port 8000).

    Calculates risk metrics from live market data and portfolio positions.
    All operations use live data - no fallback/hardcoded data.
    """

    def __init__(self) -> None:
        """
        Initialize advanced risk manager for live operations.

        All configuration values are defaults for live operations, not fallback data.
        """
        self.redis_client: Any = None  # Live Redis client (localhost:6379)
        self._binance_adapter: BinanceUSAdapter | None = None  # Live Binance.US adapter for BTC data

        # Risk parameters (configuration defaults for live operations, not fallback data)
        self.confidence_levels = [0.95, 0.99]  # Configuration default: 95% and 99% VaR
        self.time_horizons = [1, 5]  # Configuration default: 1 day and 5 days
        self.monte_carlo_analyses = 10_000  # Configuration default: Monte Carlo simulations
        self.lookback_period = 252  # Configuration default: 1 year of daily data

        # Risk thresholds (configuration defaults for live operations, not fallback data)
        self.max_var_threshold = 0.05  # Configuration default: 5% max daily VaR
        self.max_drawdown_threshold = 0.15  # Configuration default: 15% max drawdown
        self.min_sharpe_threshold = 1.0  # Configuration default: Minimum Sharpe ratio

        # BTC returns cache settings (configuration defaults, not fallback data)
        self.btc_returns_cache_ttl = 3600  # Cache BTC returns for 1 hour (seconds)

        logger.info("AdvancedRiskManager initialized for live operations")

    async def _get_redis(self) -> Any:
        """
        Get Redis client for live caching (localhost:6379).

        Returns None if Redis unavailable - error handling, not fallback data.

        Returns:
            Redis client or None if unavailable
        """
        if self.redis_client is None:
            # All Live Data, No Fallback/Hardcoded Data - Use shared Redis pool
            try:
                self.redis_client = get_redis_client()
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.warning("Redis not available for live caching: %s", e)
                self.redis_client = None  # Error handling, not fallback data
        return self.redis_client

    # ----------------------------- Metrics -----------------------------

    def calculate_var(self, returns: pd.Series, confidence_level: float = 0.95) -> float:
        """
        Calculate Value at Risk (VaR) from live returns data.

        Args:
            returns: Live returns series from Binance.US
            confidence_level: Confidence level (configuration default 0.95, not fallback data)

        Returns:
            VaR value (0.0 if insufficient live data, not fallback data)
        """
        try:
            r = pd.Series(pd.to_numeric(returns, errors="coerce")).dropna()
            if r.size < 30:
                return 0.0  # Insufficient live data, not fallback data

            var_hist = float(np.percentile(r.values, (1 - confidence_level) * 100))
            mean_r, std_r = float(r.mean()), float(r.std(ddof=0))
            var_param = mean_r + std_r * float(stats.norm.ppf(1 - confidence_level))

            var = min(var_hist, var_param)  # more conservative (more negative)
            return abs(var)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("VaR calculation failed on live data: %s", e)
            return 0.0  # Error state, not fallback data

    def calculate_cvar(self, returns: pd.Series, confidence_level: float = 0.95) -> float:
        """
        Calculate Conditional VaR (expected tail loss) from live returns data.

        Args:
            returns: Live returns series from Binance.US
            confidence_level: Confidence level (configuration default 0.95, not fallback data)

        Returns:
            CVaR value (0.0 if insufficient live data, not fallback data)
        """
        try:
            r = pd.Series(pd.to_numeric(returns, errors="coerce")).dropna()
            if r.size < 30:
                return 0.0  # Insufficient live data, not fallback data

            var_abs = self.calculate_var(r, confidence_level)  # positive
            threshold = -var_abs
            tail = r[r <= threshold]
            if tail.empty:
                return var_abs
            return abs(float(tail.mean()))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("CVaR calculation failed on live data: %s", e)
            return 0.0  # Error state, not fallback data

    def calculate_sharpe_ratio(self, returns: pd.Series, risk_free_rate: float = 0.02) -> float:
        """
        Calculate annualized Sharpe ratio from live returns data.

        Args:
            returns: Live returns series from Binance.US
            risk_free_rate: Risk-free rate (configuration default 0.02, not fallback data)

        Returns:
            Sharpe ratio (0.0 if insufficient live data, not fallback data)
        """
        try:
            r = pd.Series(pd.to_numeric(returns, errors="coerce")).dropna()
            if r.size < 30:
                return 0.0  # Insufficient live data, not fallback data
            excess = r - (risk_free_rate / 252.0)
            denom = float(excess.std(ddof=0))
            if denom == 0.0:
                return 0.0
            return float(excess.mean()) / denom * np.sqrt(252.0)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Sharpe ratio calculation failed on live data: %s", e)
            return 0.0  # Error state, not fallback data

    def calculate_max_drawdown(self, prices: pd.Series) -> float:
        """
        Calculate maximum drawdown from live price data.

        Args:
            prices: Live price series from Binance.US

        Returns:
            Max drawdown (0.0 if insufficient live data, not fallback data)
        """
        try:
            p = pd.Series(pd.to_numeric(prices, errors="coerce")).dropna()
            if p.size < 30:
                return 0.0  # Insufficient live data, not fallback data
            roll_max = p.cummax()
            dd = (p - roll_max) / roll_max
            return abs(float(dd.min()))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Max drawdown calculation failed on live data: %s", e)
            return 0.0  # Error state, not fallback data

    def calculate_volatility(self, returns: pd.Series, annualized: bool = True) -> float:
        """
        Calculate volatility from live returns data.

        Args:
            returns: Live returns series from Binance.US
            annualized: Whether to annualize (configuration default True, not fallback data)

        Returns:
            Volatility (0.0 if insufficient live data, not fallback data)
        """
        try:
            r = pd.Series(pd.to_numeric(returns, errors="coerce")).dropna()
            if r.size < 30:
                return 0.0  # Insufficient live data, not fallback data
            vol = float(r.std(ddof=0))
            return float(vol * np.sqrt(252.0)) if annualized else vol
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Volatility calculation failed on live data: %s", e)
            return 0.0  # Error state, not fallback data

    def calculate_beta(self, asset_returns: pd.Series, market_returns: pd.Series) -> float:
        """
        Calculate beta vs market from live returns data.

        Args:
            asset_returns: Live asset returns from Binance.US
            market_returns: Live market returns (BTC proxy)

        Returns:
            Beta value (1.0 if insufficient live data, not fallback data)
        """
        try:
            a = pd.Series(pd.to_numeric(asset_returns, errors="coerce")).dropna()
            m = pd.Series(pd.to_numeric(market_returns, errors="coerce")).dropna()
            n = min(a.size, m.size)
            if n < 30:
                return 1.0  # Insufficient live data (neutral beta), not fallback data
            a = a.tail(n).to_numpy()
            m = m.tail(n).to_numpy()
            cov = float(np.cov(a, m)[0, 1])
            var_m = float(np.var(m))
            return 1.0 if var_m == 0.0 else cov / var_m
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Beta calculation failed on live data: %s", e)
            return 1.0  # Error state (neutral beta), not fallback data

    def monte_carlo_analysis(self, returns: pd.Series, days: int = 30, analyses: int = 10_000) -> list[float]:
        """
        Simulate cumulative returns from live data using Monte Carlo analysis.

        Args:
            returns: Live returns series from Binance.US
            days: Projection days (configuration default 30, not fallback data)
            analyses: Number of simulations (configuration default 10000, not fallback data)

        Returns:
            List of simulated scenarios (zeros if insufficient live data, not fallback data)
        """
        try:
            r = pd.Series(pd.to_numeric(returns, errors="coerce")).dropna()
            if r.size < 30:
                return [0.0] * analyses  # Insufficient live data, not fallback data
            mu, sigma = float(r.mean()), float(r.std(ddof=0))
            # vectorized
            rand = self.rng.normal(mu, sigma, (analyses, days))
            cum = np.prod(1.0 + rand, axis=1) - 1.0
            return cum.astype(float).tolist()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Monte Carlo analysis failed on live data: %s", e)
            return [0.0] * analyses  # Error state, not fallback data

    # ----------------------------- Symbol Risk -----------------------------

    async def calculate_risk_metrics(self, symbol: str, ohlcv_data: list[list[float]]) -> RiskMetrics:
        """
        Calculate comprehensive risk metrics from live Binance.US OHLCV data (backend port 8000).

        Args:
            symbol: Live trading symbol (from Binance.US Top-10)
            ohlcv_data: Live OHLCV data from Binance.US API

        Returns:
            RiskMetrics with live calculations (zero/neutral values indicate insufficient live data, not fallback data)
        """
        try:
            if not ohlcv_data or len(ohlcv_data) < 30:
                # Insufficient live data - return zero metrics (not fallback data)
                return RiskMetrics(
                    symbol=_to_ccxt_symbol(symbol),
                    var_1d=0.0,  # Insufficient live data, not fallback data
                    var_5d=0.0,  # Insufficient live data, not fallback data
                    cvar_1d=0.0,  # Insufficient live data, not fallback data
                    cvar_5d=0.0,  # Insufficient live data, not fallback data
                    sharpe_ratio=0.0,  # Insufficient live data, not fallback data
                    max_drawdown=0.0,  # Insufficient live data, not fallback data
                    volatility=0.0,  # Insufficient live data, not fallback data
                    beta=1.0,  # Insufficient live data (neutral beta), not fallback data
                    correlation_matrix={},  # Insufficient live data, not fallback data
                    monte_carlo_scenarios=[],  # Insufficient live data, not fallback data
                    risk_score=0.5,  # Insufficient live data (neutral risk), not fallback data
                    timestamp=datetime.now(timezone.utc),  # Live timestamp
                )

            df = pd.DataFrame(
                ohlcv_data,
                columns=["timestamp", "open", "high", "low", "close", "volume"],
            )
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
            df = df.set_index("timestamp")

            # returns
            ret = df["close"].pct_change().dropna()
            if ret.size < 30:
                # Insufficient live returns data - return zero metrics (not fallback data)
                return RiskMetrics(
                    symbol=_to_ccxt_symbol(symbol),
                    var_1d=0.0,  # Insufficient live data, not fallback data
                    var_5d=0.0,  # Insufficient live data, not fallback data
                    cvar_1d=0.0,  # Insufficient live data, not fallback data
                    cvar_5d=0.0,  # Insufficient live data, not fallback data
                    sharpe_ratio=0.0,  # Insufficient live data, not fallback data
                    max_drawdown=0.0,  # Insufficient live data, not fallback data
                    volatility=0.0,  # Insufficient live data, not fallback data
                    beta=1.0,  # Insufficient live data (neutral beta), not fallback data
                    correlation_matrix={},  # Insufficient live data, not fallback data
                    monte_carlo_scenarios=[],  # Insufficient live data, not fallback data
                    risk_score=0.5,  # Insufficient live data (neutral risk), not fallback data
                    timestamp=datetime.now(timezone.utc),  # Live timestamp
                )

            var_1d = self.calculate_var(ret, 0.95)
            var_5d = var_1d * np.sqrt(5.0)
            cvar_1d = self.calculate_cvar(ret, 0.95)
            cvar_5d = cvar_1d * np.sqrt(5.0)
            sharpe_ratio = self.calculate_sharpe_ratio(ret)
            max_drawdown = self.calculate_max_drawdown(df["close"])
            volatility = self.calculate_volatility(ret)

            # Market proxy returns (live data from Binance.US API)
            btc_returns = await self._get_btc_returns()
            beta = self.calculate_beta(ret, btc_returns) if btc_returns is not None else 1.0

            scenarios = self.monte_carlo_analysis(ret, days=30, analyses=self.monte_carlo_analyses)
            sym_ccxt = _to_ccxt_symbol(symbol)

            risk_score = self._calculate_risk_score(
                var=var_1d,
                max_dd=max_drawdown,
                volatility=volatility,
                sharpe=sharpe_ratio,
            )

            return RiskMetrics(
                symbol=sym_ccxt,
                var_1d=var_1d,
                var_5d=var_5d,
                cvar_1d=cvar_1d,
                cvar_5d=cvar_5d,
                sharpe_ratio=sharpe_ratio,
                max_drawdown=max_drawdown,
                volatility=volatility,
                beta=beta,
                correlation_matrix={sym_ccxt: 1.0},
                monte_carlo_scenarios=scenarios,
                risk_score=risk_score,
                timestamp=datetime.now(timezone.utc),
            )

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Risk metrics calculation failed for %s on live data: %s", symbol, e)
            # Error state - return zero metrics (not fallback data)
            return RiskMetrics(
                symbol=_to_ccxt_symbol(symbol),
                var_1d=0.0,  # Error state, not fallback data
                var_5d=0.0,  # Error state, not fallback data
                cvar_1d=0.0,  # Error state, not fallback data
                cvar_5d=0.0,  # Error state, not fallback data
                sharpe_ratio=0.0,  # Error state, not fallback data
                max_drawdown=0.0,  # Error state, not fallback data
                volatility=0.0,  # Error state, not fallback data
                beta=1.0,  # Error state (neutral beta), not fallback data
                correlation_matrix={},  # Error state, not fallback data
                monte_carlo_scenarios=[],  # Error state, not fallback data
                risk_score=0.5,  # Error state (neutral risk), not fallback data
                timestamp=datetime.now(timezone.utc),  # Live timestamp
            )

    async def _get_binance_adapter(self) -> BinanceUSAdapter | None:
        """
        Get or create Binance.US adapter for fetching live BTC data.

        Returns:
            BinanceUSAdapter instance or None if unavailable
        """
        if BinanceUSAdapter is None:
            return None
        if self._binance_adapter is None:
            try:
                self._binance_adapter = BinanceUSAdapter()
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.warning("Failed to initialize BinanceUSAdapter: %s", e)
                return None
        return self._binance_adapter

    async def _get_btc_returns(self) -> pd.Series | None:
        """
        Get BTC returns for beta calculation from live Binance.US API.

        Fetches historical BTC/USDT daily price data and calculates returns.
        All data is from live Binance.US API - no fallback/hardcoded data.
        Results are cached in Redis for 1 hour to reduce API calls.

        Returns:
            BTC returns series (pandas Series) or None if unavailable
        """
        try:
            # Check Redis cache first
            r = await self._get_redis()
            cache_key = "risk:btc_returns"
            if r:
                try:
                    cached = await r.get(cache_key)
                    if cached:
                        # Parse cached returns from JSON
                        cached_data = json.loads(cached)
                        returns_list = [float(x) for x in cached_data.get("returns", [])]
                        if returns_list and len(returns_list) >= 30:  # Minimum 30 days for beta calculation
                            logger.debug("Using cached BTC returns (%d days)", len(returns_list))
                            return pd.Series(returns_list)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.debug("Cache read failed, fetching fresh data: %s", e)

            # Fetch live BTC data from Binance.US API
            adapter = await self._get_binance_adapter()
            if adapter is None:
                logger.warning("BinanceUSAdapter not available - cannot fetch live BTC returns")
                return None

            # Fetch BTC/USDT daily OHLCV data (252 days = ~1 year)
            btc_symbol = "BTC/USDT"  # Use standard format
            ohlcv_data = await adapter.get_ohlcv(btc_symbol, interval="1d", limit=self.lookback_period)

            if not ohlcv_data or len(ohlcv_data) < 30:
                logger.warning(
                    "Insufficient BTC OHLCV data for returns calculation: %d candles (need at least 30)",
                    len(ohlcv_data) if ohlcv_data else 0,
                )
                return None

            # Extract close prices and calculate returns
            # Returns = (price[t] - price[t-1]) / price[t-1]
            close_prices = [float(candle.close) for candle in ohlcv_data]
            if len(close_prices) < 2:
                logger.warning("Insufficient close prices for returns calculation")
                return None

            # Calculate daily returns from live close prices
            returns = []
            for i in range(1, len(close_prices)):
                prev_price = close_prices[i - 1]
                curr_price = close_prices[i]
                if prev_price > 0:
                    daily_return = (curr_price - prev_price) / prev_price
                    returns.append(daily_return)
                else:
                    logger.warning("Invalid price data at index %d: prev_price=%.8f", i - 1, prev_price)

            if len(returns) < 30:
                logger.warning(
                    "Insufficient returns calculated: %d (need at least 30 for beta calculation)",
                    len(returns),
                )
                return None

            # Create pandas Series from live returns
            returns_series = pd.Series(returns)

            # Cache results in Redis for 1 hour
            if r:
                try:
                    cache_data = {"returns": [float(x) for x in returns], "timestamp": datetime.now(timezone.utc).isoformat()}
                    await r.setex(cache_key, self.btc_returns_cache_ttl, json.dumps(cache_data))
                    logger.info("Cached BTC returns (%d days) for %d seconds", len(returns), self.btc_returns_cache_ttl)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.debug("Cache write failed: %s", e)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Failed to get live BTC returns from Binance.US API: %s", e)
            return None  # Error handling, not fallback data
        else:
            # Return successful result only if no exception was raised
            logger.info("Fetched live BTC returns: %d days from Binance.US API", len(returns))
            return returns_series

    def _calculate_risk_score(self, var: float, max_dd: float, volatility: float, sharpe: float) -> float:
        """
        Combine live risk metrics into a 0..1 risk score (higher is riskier).

        Args:
            var: Live VaR value
            max_dd: Live max drawdown
            volatility: Live volatility
            sharpe: Live Sharpe ratio

        Returns:
            Risk score (0.5 on error is error state, not fallback data)
        """
        try:
            # All thresholds are configuration defaults, not fallback data
            var_score = min(1.0, var / 0.10)  # Configuration default: cap at 10% daily VaR
            dd_score = min(1.0, max_dd / 0.20)  # Configuration default: cap at 20% drawdown
            vol_score = min(1.0, volatility / 0.50)  # Configuration default: cap at 50% annual vol
            sharpe_score = max(0.0, 1.0 - (sharpe / 2.0))  # Configuration default
            return float(
                min(
                    1.0,
                    max(
                        0.0,
                        var_score * 0.3 + dd_score * 0.3 + vol_score * 0.2 + sharpe_score * 0.2,  # Config weights
                    ),
                )
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Risk score calculation failed on live data: %s", e)
            return 0.5  # Error state (neutral risk), not fallback data

    # ----------------------------- Portfolio Risk -----------------------------

    async def calculate_portfolio_risk(
        self,
        symbols: list[str],
        weights: list[float],
        ohlcv_data: dict[str, list[list[float]]],
    ) -> PortfolioRisk:
        """
        Calculate portfolio-level risk metrics from live portfolio data (backend port 8000).

        Args:
            symbols: Live trading symbols (from Binance.US Top-10)
            weights: Live portfolio weights
            ohlcv_data: Live OHLCV data dictionary from Binance.US API

        Returns:
            PortfolioRisk with live calculations (zero values indicate insufficient live data, not fallback data)
        """
        try:
            if not symbols or len(symbols) != len(weights):
                # Invalid portfolio data - return zero metrics (not fallback data)
                return PortfolioRisk(
                    total_var=0.0,  # Invalid data, not fallback data
                    total_cvar=0.0,  # Invalid data, not fallback data
                    portfolio_volatility=0.0,  # Invalid data, not fallback data
                    portfolio_sharpe=0.0,  # Invalid data, not fallback data
                    diversification_ratio=0.0,  # Invalid data, not fallback data
                    concentration_risk=0.0,  # Invalid data, not fallback data
                    tail_risk=0.0,  # Invalid data, not fallback data
                    stress_test_results={},  # Invalid data, not fallback data
                    timestamp=datetime.now(timezone.utc),  # Live timestamp
                )

            metrics_map: dict[str, RiskMetrics] = {}
            for raw_sym in symbols:
                if raw_sym in ohlcv_data:
                    metrics_map[raw_sym] = await self.calculate_risk_metrics(raw_sym, ohlcv_data[raw_sym])

            if not metrics_map:
                # No live metrics available - return zero metrics (not fallback data)
                return PortfolioRisk(
                    total_var=0.0,  # No live data, not fallback data
                    total_cvar=0.0,  # No live data, not fallback data
                    portfolio_volatility=0.0,  # No live data, not fallback data
                    portfolio_sharpe=0.0,  # No live data, not fallback data
                    diversification_ratio=0.0,  # No live data, not fallback data
                    concentration_risk=0.0,  # No live data, not fallback data
                    tail_risk=0.0,  # No live data, not fallback data
                    stress_test_results={},  # No live data, not fallback data
                    timestamp=datetime.now(timezone.utc),  # Live timestamp
                )

            ordered = [metrics_map[s] for s in symbols if s in metrics_map]

            total_var = float(sum(m.var_1d * w for m, w in zip(ordered, weights, strict=False)))
            total_cvar = float(sum(m.cvar_1d * w for m, w in zip(ordered, weights, strict=False)))
            portfolio_volatility = float(sum(m.volatility * w for m, w in zip(ordered, weights, strict=False)))
            portfolio_shpe = float(sum(m.sharpe_ratio * w for m, w in zip(ordered, weights, strict=False)))

            weighted_vol = float(sum(m.volatility * w for m, w in zip(ordered, weights, strict=False)))
            portfolio_vol = portfolio_volatility if portfolio_volatility > 0 else 1e-9
            diversification_ratio = float(weighted_vol / portfolio_vol)

            concentration_risk = float(sum((w**2) for w in weights))
            tail_risk = float(sum(m.cvar_1d * w for m, w in zip(ordered, weights, strict=False)))

            stress_test_results = {
                "market_crash": total_var * 2.0,
                "volatility_spike": total_var * 1.5,
                "correlation_breakdown": total_var * 1.8,
            }

            return PortfolioRisk(
                total_var=total_var,
                total_cvar=total_cvar,
                portfolio_volatility=portfolio_volatility,
                portfolio_sharpe=portfolio_shpe,
                diversification_ratio=diversification_ratio,
                concentration_risk=concentration_risk,
                tail_risk=tail_risk,
                stress_test_results=stress_test_results,
                timestamp=datetime.now(timezone.utc),
            )

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Portfolio risk calculation failed on live data: %s", e)
            # Error state - return zero metrics (not fallback data)
            return PortfolioRisk(
                total_var=0.0,  # Error state, not fallback data
                total_cvar=0.0,  # Error state, not fallback data
                portfolio_volatility=0.0,  # Error state, not fallback data
                portfolio_sharpe=0.0,  # Error state, not fallback data
                diversification_ratio=0.0,  # Error state, not fallback data
                concentration_risk=0.0,  # Error state, not fallback data
                tail_risk=0.0,  # Error state, not fallback data
                stress_test_results={},  # Error state, not fallback data
                timestamp=datetime.now(timezone.utc),  # Live timestamp
            )

    # ----------------------------- Recommendations -----------------------------

    async def get_risk_recommendation(self, risk_metrics: RiskMetrics) -> dict[str, Any]:
        """
        Create a risk recommendation from live risk metrics (backend port 8000).

        Args:
            risk_metrics: Live risk metrics from market analysis

        Returns:
            Dictionary with live risk recommendations (error state on failure, not fallback data)
        """
        try:
            rec: dict[str, Any] = {
                "exchange": EXCHANGE_ID,
                "symbol": risk_metrics.symbol,
                "risk_level": "medium",
                "position_size_multiplier": 1.0,
                "recommendation": "HOLD",
                "reasoning": [],
                "timestamp": risk_metrics.timestamp.isoformat(),
            }

            if risk_metrics.var_1d > self.max_var_threshold:
                rec["risk_level"] = "high"
                rec["position_size_multiplier"] = 0.5
                rec["reasoning"].append(f"High VaR: {risk_metrics.var_1d:.3f}")
            elif risk_metrics.var_1d < self.max_var_threshold * 0.5:
                rec["risk_level"] = "low"
                rec["position_size_multiplier"] = 1.2
                rec["reasoning"].append(f"Low VaR: {risk_metrics.var_1d:.3f}")

            if risk_metrics.max_drawdown > self.max_drawdown_threshold:
                rec["risk_level"] = "high"
                rec["position_size_multiplier"] *= 0.7
                rec["reasoning"].append(f"High drawdown: {risk_metrics.max_drawdown:.3f}")

            if risk_metrics.sharpe_ratio > self.min_sharpe_threshold:
                rec["reasoning"].append(f"Good Sharpe ratio: {risk_metrics.sharpe_ratio:.3f}")
            else:
                rec["position_size_multiplier"] *= 0.8
                rec["reasoning"].append(f"Low Sharpe ratio: {risk_metrics.sharpe_ratio:.3f}")

            if risk_metrics.volatility > 0.30:
                rec["position_size_multiplier"] *= 0.8
                rec["reasoning"].append(f"High volatility: {risk_metrics.volatility:.3f}")

            if risk_metrics.risk_score > 0.7:
                rec["risk_level"] = "high"
                rec["recommendation"] = "REDUCE_POSITION"
            elif risk_metrics.risk_score < 0.3:
                rec["risk_level"] = "low"
                rec["recommendation"] = "INCREASE_POSITION"
            else:
                rec["recommendation"] = "MAINTAIN_POSITION"
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Risk recommendation failed on live data: %s", e)
            # Error state - return conservative recommendation (not fallback data)
            return {
                "exchange": EXCHANGE_ID,
                "symbol": risk_metrics.symbol,
                "risk_level": "high",  # Error state (conservative), not fallback data
                "position_size_multiplier": 0.5,  # Error state (conservative), not fallback data
                "recommendation": "HOLD",  # Error state, not fallback data
                "reasoning": ["Error in risk analysis"],  # Error state, not fallback data
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }
        else:
            return rec
