"""
AI Brains Module - All Live Data, No Fallback/Hardcoded Data

Core AI brain used to turn live market inputs into lightweight predictions and signals (backend port 8000).
All operations use live data:
- Predictions: Generated from live Binance.US market data
- Market sentiment: Analyzed from live 24h price changes
- Trading signals: Generated from live predictions
- Performance metrics: Tracked from live prediction outcomes
- All operations process live data - no fallback/hardcoded data

Design:
- Single source of truth for exchange ID via backend.modules.constants
- Symbol normalization via a single helper: backend.utils.symbols.to_ccxt_symbol
- No network calls; pure data-in/data-out (receives live data from upstream)

Endpoint References:
- Backend API: Port 8000 (AI brain serves live operations)
- Binance.US API: Live market data processed by AI brain
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import statistics as _stats
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from backend.modules.constants import EXCHANGE_ID  # Live exchange ID: "binance_us"
from backend.services.confidence_normalizer import ConfidenceNormalizer
from backend.utils.exceptions import AIException
from backend.utils.symbols import to_ccxt_symbol as _to_ccxt_symbol


@dataclass
class Prediction:
    """
    AI prediction from live market data (backend port 8000).

    All fields derived from live Binance.US market data - no fallback/hardcoded data.
    """

    exchange: str  # Live exchange ID (from Binance.US)
    symbol: str  # Live trading symbol (ccxt format BASE/QUOTE, from Binance.US Top-10)
    prediction: str  # Live prediction: "buy" | "sell" | "hold"
    confidence: float  # Live confidence score: 0..1
    reasoning: str  # Live reasoning from market analysis
    price: float | None  # Live current price
    volume: float | None  # Live trading volume
    change_24h: float | None  # Live 24h price change


class AIBrain:
    """
    Core AI brain for live trading predictions (backend port 8000).

    Generates predictions and signals from live Binance.US market data.
    All operations use live data - no fallback/hardcoded data.
    """

    def __init__(self) -> None:
        """
        Initialize AI brain for live operations.

        All initial values are configuration defaults, not fallback data.
        """
        self.model_version: str = "v1.0"  # Configuration default: model version
        self.is_active: bool = True  # Configuration default: active status
        self.prediction_history: list[Prediction] = []  # Live prediction history
        self.performance_metrics: dict[str, Any] = {
            "accuracy": 0.0,  # Configuration default: initial accuracy (not fallback data)
            "total_predictions": 0,  # Live predictions count
            "correct_predictions": 0,  # Live correct predictions count
        }

    # ----------------------------- Lifecycle -----------------------------

    def get_status(self) -> dict[str, Any]:
        """
        Get current status of AI brain (live operations).

        Returns:
            Dictionary with live status information
        """
        return {
            "active": self.is_active,
            "model_version": self.model_version,
            "predictions_made": len(self.prediction_history),  # Live prediction count
            "accuracy": float(self.performance_metrics.get("accuracy", 0.0)),  # Live accuracy
        }

    def activate(self) -> None:
        """Activate AI brain for live operations."""
        self.is_active = True

    def deactivate(self) -> None:
        """Deactivate AI brain (stops processing live data)."""
        self.is_active = False

    def update_model_version(self, version: str) -> None:
        """
        Update model version for live operations.

        Args:
            version: New model version string
        """
        if not isinstance(version, str) or not version.strip():
            msg = "Model version must be a non-empty string"
            raise AIException(msg)
        self.model_version = version.strip()

    # ----------------------------- Core Logic -----------------------------

    def get_predictions(self, market_data: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
        """
        Generate per-symbol predictions from live market data (backend port 8000).

        Uses simple heuristics based on live 24h price changes from Binance.US.
        All predictions generated from live data - no fallback/hardcoded data.

        Args:
            market_data: Live market data dictionary { symbol: { price, volume, change_24h, ... }, ... }
                         All symbols normalized to ccxt BASE/QUOTE via _to_ccxt_symbol

        Returns:
            Dictionary of live predictions per symbol

        Raises:
            AIException: If AI is inactive or market data is invalid
        """
        if not self.is_active:
            msg = "AI is inactive"
            raise AIException(msg)
        if not market_data or not isinstance(market_data, dict):
            msg = "No market data provided"
            raise AIException(msg)

        # Validate and normalize
        cleaned: dict[str, dict[str, Any]] = {}
        for raw_sym, data in market_data.items():
            if not isinstance(data, dict):
                msg = f"Invalid market data format for {raw_sym}"
                raise AIException(msg)
            price = data.get("price", None)
            volume = data.get("volume", None)
            change_24h = data.get("change_24h", None)

            if price is not None and not isinstance(price, (int, float)):
                msg = f"Invalid price data for {raw_sym}"
                raise AIException(msg)
            if volume is not None and not isinstance(volume, (int, float)):
                msg = f"Invalid volume data for {raw_sym}"
                raise AIException(msg)
            if change_24h is not None and not isinstance(change_24h, (int, float)):
                msg = f"Invalid change_24h data for {raw_sym}"
                raise AIException(msg)

            sym = _to_ccxt_symbol(raw_sym)
            cleaned[sym] = {
                "price": float(price) if price is not None else None,
                "volume": float(volume) if volume is not None else None,
                "change_24h": float(change_24h) if change_24h is not None else 0.0,
            }

        # Heuristic predictions
        out: dict[str, dict[str, Any]] = {}
        for sym, d in cleaned.items():
            change = d.get("change_24h", 0.0) or 0.0
            price = d.get("price", None)
            volume = d.get("volume", None)

            # Simple heuristics based on live 24h price changes (configuration thresholds, not fallback data):
            # - > +5% day: likely mean-reversion -> "sell" (threshold is config default, not fallback data)
            # - < -5% day: potential bounce -> "buy" (threshold is config default, not fallback data)
            # - otherwise "hold"
            if change > 5.0:  # Configuration default threshold, not fallback data
                prediction = "sell"
                confidence = min(0.8, abs(change) / 10.0)  # Config default max confidence
                reasoning = f"Strong upward movement ({change:.2f}%) suggests potential mean reversion"
            elif change < -5.0:  # Configuration default threshold, not fallback data
                prediction = "buy"
                confidence = min(0.8, abs(change) / 10.0)  # Config default max confidence
                reasoning = f"Significant decline ({change:.2f}%) indicates possible rebound"
            else:
                prediction = "hold"
                confidence = 0.6  # Configuration default confidence, not fallback data
                reasoning = f"Stable movement ({change:.2f}%), maintain position"

            pred = Prediction(
                exchange=EXCHANGE_ID,
                symbol=sym,
                prediction=prediction,
                confidence=confidence,
                reasoning=reasoning,
                price=price,
                volume=volume,
                change_24h=change,
            )
            self.prediction_history.append(pred)
            out[sym] = {
                "prediction": prediction,
                "confidence": confidence,
                "reasoning": reasoning,
                "price": price,
                "volume": volume,
                "change_24h": change,
            }

        return out

    def analyze_market_sentiment(self, market_data: dict[str, dict[str, Any]]) -> dict[str, Any]:
        """
        Derive market sentiment from live 24h price changes (backend port 8000).

        Analyzes average 24h change across live Binance.US symbols.
        All sentiment derived from live data - no fallback/hardcoded data.

        Args:
            market_data: Live market data dictionary with 24h changes

        Returns:
            Dictionary with live sentiment analysis (neutral if no live data, not fallback data)
        """
        if not market_data:
            # No live data - return neutral sentiment (not fallback data)
            return {"overall_sentiment": "neutral", "confidence": 0.5, "factors": []}

        changes: list[float] = []
        for _raw_sym, d in market_data.items():
            try:
                # sym = _to_ccxt_symbol(raw_sym)  # Unused
                val = d.get("change_24h", 0)
                if isinstance(val, (int, float)):
                    changes.append(float(val))
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                continue

        if not changes:
            # No live changes data - return neutral sentiment (not fallback data)
            return {"overall_sentiment": "neutral", "confidence": 0.5, "factors": []}

        avg = sum(changes) / len(changes)  # Live average from live data
        # Configuration thresholds for sentiment (not fallback data)
        if avg > 2.0:  # Configuration default threshold
            sentiment, conf = "bullish", min(0.9, avg / 10.0 + 0.5)  # Config default max confidence
        elif avg < -2.0:  # Configuration default threshold
            sentiment, conf = "bearish", min(0.9, abs(avg) / 10.0 + 0.5)  # Config default max confidence
        else:
            sentiment, conf = "neutral", 0.6  # Configuration default confidence

        return {
            "overall_sentiment": sentiment,
            "confidence": conf,
            "factors": [{"metric": "avg_change_24h", "value": avg}],
        }

    def calculate_risk_score(self, market_data: dict[str, dict[str, Any]]) -> float:
        """
        Calculate risk score from live 24h price change dispersion (backend port 8000).

        Higher dispersion of live 24h changes -> higher risk.
        All risk scores calculated from live data - no fallback/hardcoded data.

        Args:
            market_data: Live market data dictionary with 24h changes

        Returns:
            Risk score 0..1 (0.5 if no live data, not fallback data)
        """
        changes: list[float] = []
        for raw_sym, d in market_data.items():
            try:
                _ = _to_ccxt_symbol(raw_sym)
                val = d.get("change_24h", 0)
                if isinstance(val, (int, float)):
                    changes.append(float(val))  # Live 24h change data
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                continue

        if not changes:
            return 0.5  # No live data (neutral risk), not fallback data

        # Normalize by configuration scale (20% std caps risk near 1) - config default, not fallback data
        std = 0.0
        if len(changes) > 1:
            try:
                std = float(_stats.pstdev(changes))  # Live standard deviation
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                std = 0.0
        # 0..1 cap (20% threshold is config default, not fallback data)
        return max(0.0, min(1.0, std / 20.0))

    def generate_trading_signals(self, market_data: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
        """
        Generate trading signals from live predictions (backend port 8000).

        Converts live predictions into standardized trading signals.
        All signals generated from live market data - no fallback/hardcoded data.

        Args:
            market_data: Live market data dictionary

        Returns:
            List of live trading signals
        """
        preds = self.get_predictions(market_data)
        now = datetime.now(timezone.utc).isoformat()
        signals: list[dict[str, Any]] = []
        for sym, p in preds.items():
            action = {"buy": "BUY", "sell": "SELL"}.get(p["prediction"], "HOLD")
            signals.append(
                {
                    "exchange": EXCHANGE_ID,
                    "symbol": sym,
                    "action": action,
                    "confidence": ConfidenceNormalizer.normalize(float(p.get("confidence", 0.0) or 0.0)),
                    "timestamp": now,
                },
            )
        return signals

    # ----------------------------- Performance / State -----------------------------

    def update_performance_metrics(self, correct_increment: int = 0, total_increment: int = 0) -> None:
        """
        Update performance metrics from live prediction outcomes (backend port 8000).

        Updates accuracy and counts based on realized live trading outcomes.
        All metrics from live operations - no fallback/hardcoded data.

        Args:
            correct_increment: Number of correct predictions (live outcome)
            total_increment: Total predictions to add (live outcome)
        """
        total = int(self.performance_metrics.get("total_predictions", 0)) + int(total_increment)
        correct = int(self.performance_metrics.get("correct_predictions", 0)) + int(correct_increment)
        acc = float(correct / total) if total > 0 else 0.0
        self.performance_metrics.update(
            {
                "accuracy": acc,
                "total_predictions": total,
                "correct_predictions": correct,
                "last_update": datetime.now(timezone.utc).isoformat(),
            },
        )

    def get_performance_report(self) -> dict[str, Any]:
        """
        Get performance report from live metrics (backend port 8000).

        Returns:
            Dictionary with live performance summary
        """
        return {
            "summary": {
                "accuracy": float(self.performance_metrics.get("accuracy", 0.0)),  # Live accuracy
                "total_predictions": int(self.performance_metrics.get("total_predictions", 0)),  # Live count
                "correct_predictions": int(self.performance_metrics.get("correct_predictions", 0)),  # Live count
            },
            "detailed_metrics": {},  # Placeholder for future detailed metrics
            "recommendations": [],  # Placeholder for future recommendations
        }

    def save_model_state(self) -> dict[str, Any]:
        """
        Save model state for live operations (backend port 8000).

        Returns:
            Dictionary with live model state (last 500 predictions)
        """
        return {
            "model_version": self.model_version,
            "performance_metrics": self.performance_metrics,  # Live performance metrics
            "prediction_history": [p.__dict__ for p in self.prediction_history][-500:],  # Live history (capped, not fallback data)
            "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
        }

    def load_model_state(self, state: dict[str, Any]) -> None:
        """
        Load model state for live operations (backend port 8000).

        Args:
            state: Model state dictionary to load

        Raises:
            AIException: If state payload is invalid
        """
        if not isinstance(state, dict):
            msg = "Invalid state payload"
            raise AIException(msg)
        self.model_version = state.get("model_version", self.model_version)
        self.performance_metrics = state.get("performance_metrics", {}) or {}
        # Best-effort reconstruction of history (non-critical)
        hist: list[Prediction] = []
        for item in state.get("prediction_history", []) or []:
            try:
                hist.append(
                    Prediction(
                        exchange=str(item.get("exchange", EXCHANGE_ID)),
                        symbol=str(item.get("symbol", "")),
                        prediction=str(item.get("prediction", "hold")),
                        confidence=ConfidenceNormalizer.normalize(float(item.get("confidence", 0.0))),
                        reasoning=str(item.get("reasoning", "")),
                        price=None if item.get("price") is None else float(item.get("price")),
                        volume=None if item.get("volume") is None else float(item.get("volume")),
                        change_24h=None if item.get("change_24h") is None else float(item.get("change_24h")),
                    ),
                )
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                continue
        self.prediction_history = hist[-500:]

    def reset_model(self) -> None:
        """
        Reset model state (clears live prediction history and metrics).

        Resets to initial configuration defaults, not fallback data.
        """
        self.prediction_history = []  # Clear live history
        self.performance_metrics = {
            "accuracy": 0.0,  # Reset to config default, not fallback data
            "total_predictions": 0,  # Reset to config default, not fallback data
            "correct_predictions": 0,  # Reset to config default, not fallback data
        }
