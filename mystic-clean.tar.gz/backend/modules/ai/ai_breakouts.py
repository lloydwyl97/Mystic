"""
AI Breakouts Module - All Live Data, No Fallback/Hardcoded Data

Detects price breakouts (up/down) from live Binance.US market data using Donchian channels,
ATR filters, and volume confirmation (backend port 8000).
All operations use live data:
- Breakout detection: Analyzes live OHLCV data from Binance.US
- Signal generation: Generates breakout signals from live market data
- Volume confirmation: Uses live volume data for signal validation
- All calculations use live data - no fallback/hardcoded data

Design:
- Data-in/data-out: Receives live OHLCV data from upstream (no direct network calls)
- Single source of truth for exchange ID via backend.modules.constants
- Symbol normalization via a single helper: backend.utils.symbols.to_ccxt_symbol
- Pass live OHLCV arrays per timeframe and receive breakout signals

Endpoint References:
- Backend API: Port 8000 (breakout detector serves live operations)
- Binance.US API: Live OHLCV data processed by breakout detector
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

import numpy as np
import pandas as pd

# Centralized constants & helpers (live exchange ID)
from backend.modules.constants import (
    EXCHANGE_ID,  # Live exchange ID: "binance_us" (single source of truth)
)
from backend.services.confidence_normalizer import ConfidenceNormalizer
from backend.utils.symbols import (
    to_ccxt_symbol as _to_ccxt_symbol,  # Single helper to normalize symbols
)

logger = logging.getLogger(__name__)


@dataclass
class BreakoutSignal:
    """
    Breakout signal from live market analysis (backend port 8000).

    All fields derived from live Binance.US OHLCV data - no fallback/hardcoded data.
    """

    exchange: str  # Live exchange ID (from Binance.US)
    symbol: str  # Live trading symbol (ccxt style "BASE/QUOTE", from Binance.US Top-10)
    timeframe: str  # Live timeframe (e.g., "1m", "5m", "15m", "1h", "4h", "1d")
    signal: str  # Live signal: "BREAKOUT_BUY" | "BREAKOUT_SELL" | "NONE"
    confidence: float  # Live confidence score (0..1)
    breakout_level: float | None  # Live breakout level price
    price: float | None  # Live current price
    atr: float | None  # Live Average True Range
    volume_spike: bool  # Live volume spike detection
    timestamp: str  # Live signal timestamp
    context: dict[str, Any]  # Live breakout context data


class BreakoutDetector:
    """
    Detects breakouts from live market data using Donchian channels with ATR and volume confirmation (backend port 8000).

    Analyzes live Binance.US OHLCV data to detect price breakouts.
    All operations use live data - no fallback/hardcoded data.

    Inputs (all live data):
    - symbol: Live trading symbol (any format; normalized to ccxt "BASE/QUOTE")
    - timeframe: Live timeframe (e.g., "1m", "5m", "15m", "1h", "4h", "1d")
    - ohlcv: Live OHLCV list of lists with: [timestamp(ms), open, high, low, close, volume]

    Outputs:
    - BreakoutSignal dataclass with live breakout detection results
    """

    def __init__(
        self,
        donchian_period_short: int = 20,  # Configuration default: short Donchian period (not fallback data)
        donchian_period_long: int = 55,  # Configuration default: long Donchian period (not fallback data)
        atr_period: int = 14,  # Configuration default: ATR period (not fallback data)
        volume_ma_period: int = 20,  # Configuration default: volume MA period (not fallback data)
        min_atr_pct_of_price: float = 0.005,  # Configuration default: 0.5% ATR floor vs price (not fallback data)
        min_break_distance_atr: float = 0.5,  # Configuration default: close must clear channel by >= 0.5 * ATR (not fallback data)
        volume_spike_ratio: float = 1.3,  # Configuration default: volume > 1.3 * SMA(volume) counts as spike (not fallback data)
    ) -> None:
        """
        Initialize breakout detector for live operations.

        Args:
            donchian_period_short: Short Donchian period (configuration default, not fallback data)
            donchian_period_long: Long Donchian period (configuration default, not fallback data)
            atr_period: ATR calculation period (configuration default, not fallback data)
            volume_ma_period: Volume moving average period (configuration default, not fallback data)
            min_atr_pct_of_price: Minimum ATR percentage of price (configuration default, not fallback data)
            min_break_distance_atr: Minimum breakout distance in ATR multiples (configuration default, not fallback data)
            volume_spike_ratio: Volume spike ratio threshold (configuration default, not fallback data)
        """
        self.donchian_period_short = int(donchian_period_short)
        self.donchian_period_long = int(donchian_period_long)
        self.atr_period = int(atr_period)
        self.volume_ma_period = int(volume_ma_period)
        self.min_atr_pct_of_price = float(min_atr_pct_of_price)
        self.min_break_distance_atr = float(min_break_distance_atr)
        self.volume_spike_ratio = float(volume_spike_ratio)

    # ----------------------------- Public API -----------------------------

    def analyze(
        self,
        symbol: str,
        timeframe: str,
        ohlcv: list[list[float]],
    ) -> BreakoutSignal:
        """
        Analyze live OHLCV data for breakout signals (backend port 8000).

        Args:
            symbol: Live trading symbol (from Binance.US Top-10)
            timeframe: Live timeframe (e.g., "1m", "5m", "15m", "1h", "4h", "1d")
            ohlcv: Live OHLCV data from Binance.US API

        Returns:
            BreakoutSignal with live breakout detection (NONE if insufficient live data or no breakout, not fallback data)
        """
        try:
            sym = _to_ccxt_symbol(symbol)
            df = self._to_df(ohlcv)  # Convert live OHLCV to DataFrame
            if df.shape[0] < max(self.donchian_period_long, self.volume_ma_period, self.atr_period) + 2:
                # Insufficient live bars - return NONE signal (not fallback data)
                return self._none(sym, timeframe, "insufficient_bars")

            # Calculate indicators from live data
            don_s_hi, don_s_lo = self._donchian(df, self.donchian_period_short)  # Live short Donchian channels
            don_l_hi, don_l_lo = self._donchian(df, self.donchian_period_long)  # Live long Donchian channels
            atr = self._atr(df, self.atr_period)  # Live Average True Range
            vol_ma = df["volume"].rolling(self.volume_ma_period, min_periods=1).mean()  # Live volume MA

            last_close = float(df["close"].iloc[-1])
            # last_high = float(df["high"].iloc[-1])  # Unused
            # last_low = float(df["low"].iloc[-1])  # Unused
            last_don_s_hi = float(don_s_hi.iloc[-1])
            last_don_s_lo = float(don_s_lo.iloc[-1])
            last_don_l_hi = float(don_l_hi.iloc[-1])
            last_don_l_lo = float(don_l_lo.iloc[-1])
            last_atr = float(atr.iloc[-1])
            last_vol = float(df["volume"].iloc[-1])
            last_vol_ma = float(vol_ma.iloc[-1])

            # ATR floor vs price
            min_atr = max(last_close * self.min_atr_pct_of_price, 1e-9)
            effective_atr = max(last_atr, min_atr)

            # Volume spike filter
            vol_spike = last_vol > (self.volume_spike_ratio * last_vol_ma if last_vol_ma > 0 else np.inf)

            # Breakout conditions:
            # BUY: close > long-channel-high and distance >= threshold
            # SELL: close < long-channel-low and distance >= threshold
            buy_break_dist = last_close - last_don_l_hi
            sell_break_dist = last_don_l_lo - last_close

            buy_cond = last_close > last_don_l_hi and buy_break_dist >= self.min_break_distance_atr * effective_atr
            sell_cond = last_close < last_don_l_lo and sell_break_dist >= self.min_break_distance_atr * effective_atr

            # Confidence scoring (0..1)
            confidence = 0.0
            signal = "NONE"
            breakout_level: float | None = None

            if buy_cond and not sell_cond:
                # Additional confirmation: short channel also broken, recent highs near
                confirmations = 0
                if last_close > last_don_s_hi:
                    confirmations += 1
                if vol_spike:
                    confirmations += 1
                # distance factor
                dist_factor = np.tanh(buy_break_dist / (effective_atr + 1e-12))
                confidence = ConfidenceNormalizer.normalize(float(min(1.0, 0.5 + 0.25 * confirmations + 0.25 * dist_factor)))
                signal = "BREAKOUT_BUY"
                breakout_level = last_don_l_hi
            elif sell_cond and not buy_cond:
                confirmations = 0
                if last_close < last_don_s_lo:
                    confirmations += 1
                if vol_spike:
                    confirmations += 1
                dist_factor = np.tanh(sell_break_dist / (effective_atr + 1e-12))
                confidence = ConfidenceNormalizer.normalize(float(min(1.0, 0.5 + 0.25 * confirmations + 0.25 * dist_factor)))
                signal = "BREAKOUT_SELL"
                breakout_level = last_don_l_lo
            else:
                return self._none(
                    sym,
                    timeframe,
                    "no_breakout",
                    context={
                        "close": last_close,
                        "donchian_long_hi": last_don_l_hi,
                        "donchian_long_lo": last_don_l_lo,
                        "atr": last_atr,
                        "volume_spike": vol_spike,
                    },
                )

            return BreakoutSignal(
                exchange=EXCHANGE_ID,
                symbol=sym,
                timeframe=timeframe,
                signal=signal,
                confidence=confidence,
                breakout_level=breakout_level,
                price=last_close,
                atr=last_atr,
                volume_spike=vol_spike,
                timestamp=datetime.now(timezone.utc).isoformat(),
                context={
                    "donchian_short_hi": last_don_s_hi,
                    "donchian_short_lo": last_don_s_lo,
                    "donchian_long_hi": last_don_l_hi,
                    "donchian_long_lo": last_don_l_lo,
                    "atr_effective": effective_atr,
                    "volume": last_vol,
                    "volume_ma": last_vol_ma,
                    "buy_break_distance": buy_break_dist,
                    "sell_break_distance": sell_break_dist,
                },
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Breakout analysis failed on live data: %s", e)
            # Error state - return NONE signal (not fallback data)
            return self._none(_to_ccxt_symbol(symbol), timeframe, "error", {"error": str(e)})

    def analyze_many(
        self,
        symbols: list[str],
        timeframe: str,
        ohlcv_map: dict[str, list[list[float]]],
    ) -> list[BreakoutSignal]:
        """
        Analyze multiple symbols for breakout signals from live data (backend port 8000).

        Args:
            symbols: List of live trading symbols (from Binance.US Top-10)
            timeframe: Live timeframe (e.g., "1m", "5m", "15m", "1h", "4h", "1d")
            ohlcv_map: Dictionary of live OHLCV data (keys can be any symbol format; normalized)

        Returns:
            List of BreakoutSignal with live breakout detection for each symbol
        """
        results: list[BreakoutSignal] = []
        for raw_sym in symbols:
            # sym_key = raw_sym  # Unused
            # find OHLCV by any matching key (normalized)
            norm = _to_ccxt_symbol(raw_sym)
            ohlcv = ohlcv_map.get(raw_sym) or ohlcv_map.get(norm) or ohlcv_map.get(raw_sym.replace("/", ""))
            if not ohlcv:
                # Missing live data - return NONE signal (not fallback data)
                results.append(self._none(norm, timeframe, "missing_data"))
                continue
            results.append(self.analyze(raw_sym, timeframe, ohlcv))
        return results

    # ----------------------------- Internals -----------------------------

    @staticmethod
    def _to_df(ohlcv: list[list[float]]) -> pd.DataFrame:
        """
        Convert live OHLCV list to DataFrame.

        Args:
            ohlcv: Live OHLCV data from Binance.US API

        Returns:
            DataFrame with columns ['timestamp','open','high','low','close','volume'] and datetime index
        """
        df = pd.DataFrame(ohlcv, columns=["timestamp", "open", "high", "low", "close", "volume"])
        # normalize types
        for c in ["open", "high", "low", "close", "volume"]:
            df[c] = pd.to_numeric(df[c], errors="coerce")
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
        df = df.dropna(subset=["open", "high", "low", "close", "volume"])
        return df.set_index("timestamp")

    @staticmethod
    def _donchian(df: pd.DataFrame, period: int) -> tuple[pd.Series, pd.Series]:
        """
        Calculate Donchian channel high/low from live data.

        Args:
            df: Live OHLCV DataFrame
            period: Rolling window period (configuration default, not fallback data)

        Returns:
            Tuple of (high, low) series from live data
        """
        high = df["high"].rolling(window=period, min_periods=1).max()
        low = df["low"].rolling(window=period, min_periods=1).min()
        return high, low

    @staticmethod
    def _atr(df: pd.DataFrame, period: int) -> pd.Series:
        """
        Calculate Average True Range from live data.

        Args:
            df: Live OHLCV DataFrame
            period: Rolling window period (configuration default, not fallback data)

        Returns:
            ATR series calculated from live data
        """
        high = df["high"]
        low = df["low"]
        close = df["close"]
        prev_close = close.shift(1)

        tr1 = high - low
        tr2 = (high - prev_close).abs()
        tr3 = (low - prev_close).abs()
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

        return tr.rolling(window=period, min_periods=1).mean()

    @staticmethod
    def _none(symbol: str, timeframe: str, reason: str, context: dict[str, Any] | None = None) -> BreakoutSignal:
        """
        Create NONE breakout signal (no breakout detected or insufficient live data).

        Args:
            symbol: Live trading symbol
            timeframe: Live timeframe
            reason: Reason for NONE signal (e.g., "insufficient_bars", "no_breakout", "missing_data", "error")
            context: Optional context dictionary

        Returns:
            BreakoutSignal with NONE signal (not fallback data - indicates no breakout or insufficient live data)
        """
        return BreakoutSignal(
            exchange=EXCHANGE_ID,
            symbol=symbol,
            timeframe=timeframe,
            signal="NONE",  # No breakout detected (not fallback data)
            confidence=0.0,  # Zero confidence for NONE (not fallback data)
            breakout_level=None,  # No breakout level (not fallback data)
            price=None,  # No price if insufficient data (not fallback data)
            atr=None,  # No ATR if insufficient data (not fallback data)
            volume_spike=False,  # No volume spike (not fallback data)
            timestamp=datetime.now(timezone.utc).isoformat(),  # Live timestamp
            context=context or {"reason": reason},  # Context reason (not fallback data)
        )
