"""
AI Learning Module - All Live Data, No Fallback/Hardcoded Data

Handles machine learning model training, evaluation, and continuous learning from live market data (backend port 8000).
All operations use live data:
- Model training: Trained on live Binance.US market data and trading outcomes
- Evaluation: Evaluated on live test data from Binance.US
- Online learning: Updated with live new trading data
- All training data must be live - no synthetic/fallback/hardcoded data

Note: `random_state=42` in ML models is for reproducibility of the training process only,
not for generating synthetic data. All training data must come from live market operations.

Endpoint References:
- Backend API: Port 8000 (AI learner serves live operations)
- Binance.US API: Live market data for model training
- All models trained on live data - no mock/test data
"""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score, precision_score, recall_score
from sklearn.model_selection import GridSearchCV, cross_val_score, train_test_split

from backend.ai_training_pipeline import get_training_stats
from backend.config.redis_config import get_shared_redis_sync
from backend.services.canonical_cache import canonical_cache
from backend.services.canonical_http_client import canonical_http_client
from backend.utils.exceptions import AIException

logger = logging.getLogger(__name__)

# Prevent "unused import" tooling warnings during cold starts (library initialization, not fallback data)
_ = json.dumps({"status": "loaded"})
_ = np.array([1, 2, 3])
_ = pd.DataFrame()


class AILearner:
    """
    AI Learning system for continuous model improvement from live market data (backend port 8000).

    Trains and evaluates ML models using live Binance.US market data and trading outcomes.
    All operations use live data - no fallback/hardcoded/synthetic data.
    """

    def __init__(self) -> None:
        """
        Initialize AI learner for live operations.

        All initial values are configuration defaults, not fallback data.
        Note: random_state=42 is for training reproducibility only, not synthetic data generation.
        """
        # Initialize model - try to load existing, create new if none exists
        self.model: RandomForestClassifier | None = None
        self.training_history: list[dict[str, Any]] = []  # Live training history
        self.model_path: str = "models/active/ai_model_latest.pkl"  # Live model storage path
        self.is_training: bool = False  # Live training status
        self.last_training_time: datetime | None = None  # Live training timestamp
        self.learning_rate: float = 0.01  # Configuration default: learning rate (not fallback data)
        self.model_version: str = "v1.0"  # Configuration default: model version
        self.performance_metrics: dict[str, Any] = {}  # Live performance metrics
        # Buffer for online-style incremental retraining when partial_fit is unavailable
        self._online_X_buffer: list[Any] = []
        self._online_y_buffer: list[Any] = []
        self._online_buffer_max: int = 500
        self._online_retrain_threshold: int = 50

        # PERSISTENCE FIX: Load existing model on startup if available
        from pathlib import Path

        if Path(self.model_path).exists():
            try:
                load_result = self.load_model(self.model_path)
                if load_result["status"] == "success":
                    logger.info(f"✅ Loaded existing AI model from {self.model_path}")
                else:
                    logger.warning(f"Failed to load model, creating new one: {load_result.get('error')}")
                    self.model = RandomForestClassifier(random_state=42)
            except Exception as e:
                logger.warning(f"Error loading model, creating new one: {e}")
                self.model = RandomForestClassifier(random_state=42)
        else:
            logger.info("No existing model found, creating new one")
            self.model = RandomForestClassifier(random_state=42)

    # --------------------------- Public Training API ---------------------------

    def train_model(self, training_data: dict[str, Any]) -> dict[str, Any]:
        """
        Train the AI model with live market data (backend port 8000).

        All training data must be live from Binance.US market operations.
        No synthetic/fallback/hardcoded data allowed.

        Args:
            training_data: Live training data from market operations (dict with features and labels)

        Returns:
            Dictionary with live training results

        Raises:
            AIException: If training data is invalid or insufficient
        """
        if not training_data:
            msg = "Training data cannot be empty - requires live market data"
            raise AIException(msg)
        if self.model is None:
            # Initialize model for live training (random_state for reproducibility, not synthetic data)
            self.model = RandomForestClassifier(
                n_estimators=500,  # Configuration default
                max_depth=25,  # Configuration default
                min_samples_split=2,  # Configuration default
                min_samples_leaf=1,  # Configuration default
                random_state=42,  # For reproducibility only (not synthetic data generation)
                n_jobs=-1,  # Use all CPU cores
                warm_start=True,  # Enable incremental training
            )

        try:
            self.is_training = True
            start_time = datetime.now(timezone.utc)
            logger.info("Starting model training with %d live data points", len(training_data))

            X, y = self._prepare_training_data(training_data)  # Prepare live training data
            if X.size == 0 or y.size == 0:
                msg = "No valid live training samples found"
                raise AIException(msg)

            # Validate live training data (configuration thresholds, not fallback data)
            if X.shape[0] < 100:  # Configuration default: minimum sample size (not fallback data)
                logger.warning("Low live training data: %d samples (minimum 100 required)", X.shape[0])
                msg = f"Low live training data: {X.shape[0]} samples (minimum 100 required)"
                raise AIException(msg)
            if X.shape[0] < 1000:  # Configuration default: recommended sample size (not fallback data)
                logger.warning("Suboptimal live training data: %d samples (below 1000 recommended)", X.shape[0])

            X_train, X_test, y_train, y_test = self._split_data(X, y)  # Split live data

            # Train model on live data
            logger.info("Training model with %d live training samples, %d live test samples", X_train.shape[0], X_test.shape[0])
            self.model.fit(X_train, y_train)  # Train on live data

            train_score = self.model.score(X_train, y_train)
            test_score = self.model.score(X_test, y_test)
            accuracy = test_score

            y_pred = self.model.predict(X_test)
            precision = precision_score(y_test, y_pred, average="weighted", zero_division=0)
            recall = recall_score(y_test, y_pred, average="weighted", zero_division=0)
            f1 = f1_score(y_test, y_pred, average="weighted", zero_division=0)

            # Enhanced metrics for sklearn 1.7.1
            feature_importance = None
            if hasattr(self.model, "feature_importances_"):
                feature_importance = self.model.feature_importances_.tolist()

            record = {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "train_score": float(train_score),
                "test_score": float(test_score),
                "samples": int(X.shape[0]),
                "features": int(X.shape[1]) if X.ndim == 2 else 1,
                "epoch": len(self.training_history) + 1,
                "accuracy": float(accuracy),
                "loss": float(1 - accuracy),
                "precision": float(precision),
                "recall": float(recall),
                "f1_score": float(f1),
                "feature_importance": feature_importance,
                "sklearn_version": "1.7.1",
                "model_params": self.model.get_params(),
            }
            self.training_history.append(record)

            self.last_training_time = datetime.now(timezone.utc)
            training_time = (self.last_training_time - start_time).total_seconds()

            # Update performance metrics
            self.performance_metrics = {
                "accuracy": float(accuracy),
                "precision": float(precision),
                "recall": float(recall),
                "f1_score": float(f1),
                "training_time": float(training_time),
                "last_training": self.last_training_time.isoformat(),
                "sklearn_version": "1.7.1",
            }

            logger.info("Model training completed on live data: Accuracy=%.3f, F1=%.3f, Time=%.2fs", accuracy, f1, training_time)

            # PERSISTENCE FIX: Save model to disk after training
            if self.model is not None:
                try:
                    # Save timestamped version
                    timestamp_str = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
                    versioned_path = f"models/active/ai_model_{timestamp_str}.pkl"
                    save_result = self.save_model(versioned_path)

                    if save_result["status"] == "success":
                        logger.info(f"✅ Saved trained model to {versioned_path}")

                        # Also save as "latest" for easy loading on startup
                        latest_save = self.save_model(self.model_path)
                        if latest_save["status"] == "success":
                            logger.info(f"✅ Saved as latest model: {self.model_path}")
                    else:
                        logger.error(f"Failed to save model: {save_result.get('error')}")
                except Exception as e:
                    logger.exception(f"Error saving trained model: {e}")

            return {
                "success": True,
                "accuracy": float(accuracy),
                "training_time": float(training_time),
                "epochs": 1,
                "train_score": float(train_score),
                "test_score": float(test_score),
                "precision": float(precision),
                "recall": float(recall),
                "f1_score": float(f1),
                "samples_used": int(X.shape[0]),
                "feature_importance": feature_importance,
                "sklearn_version": "1.7.1",
                "model_type": type(self.model).__name__,
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Training failed on live data: %s", e)
            if isinstance(e, AIException):
                raise
            msg = f"Training failed on live data: {e}"
            raise AIException(msg) from e
        finally:
            self.is_training = False

    def evaluate_model(self, test_data: dict[str, Any]) -> dict[str, Any]:
        """
        Evaluate the trained model on live test data (backend port 8000).

        Args:
            test_data: Live test data from market operations

        Returns:
            Dictionary with live evaluation results

        Raises:
            AIException: If model not trained or test data invalid
        """
        if self.model is None:
            msg = "No trained model available"
            raise AIException(msg)

        try:
            X, y = self._prepare_training_data(test_data)  # Prepare live test data
            if X.size == 0 or y.size == 0:
                msg = "No valid live test samples found"
                raise AIException(msg)

            predictions = self.model.predict(X)
            accuracy = self.model.score(X, y)
            precision = precision_score(y, predictions, average="weighted", zero_division=0)
            recall = recall_score(y, predictions, average="weighted", zero_division=0)
            f1 = f1_score(y, predictions, average="weighted", zero_division=0)

            return {
                "accuracy": float(accuracy),
                "precision": float(precision),
                "recall": float(recall),
                "f1_score": float(f1),
                "predictions": list(map(int, predictions.tolist())),
                "samples": int(X.shape[0]),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Evaluation failed on live data: %s", e)
            if isinstance(e, AIException):
                raise
            msg = f"Evaluation failed on live data: {e}"
            raise AIException(msg) from e

    def update_model_online(self, new_data: dict[str, Any]) -> dict[str, Any]:
        """
        Update model with new live data (online learning if supported) (backend port 8000).

        Args:
            new_data: Live new trading data from market operations

        Returns:
            Dictionary with update status and results
        """
        if self.model is None:
            msg = "No trained model available"
            raise AIException(msg)

        try:
            X, y = self._prepare_training_data(new_data)  # Prepare live new data
            if X.size == 0 or y.size == 0:
                return {"status": "error", "error": "No valid live data for online update"}

            if hasattr(self.model, "partial_fit"):
                # Generic path for estimators that support partial_fit (e.g. SGDClassifier)
                classes = np.unique(y)
                self.model.partial_fit(X, y, classes=classes)  # type: ignore[attr-defined]
                accuracy = float(self.model.score(X, y))
            else:
                # RandomForest does not support partial_fit: accumulate new data and periodically refit
                self._online_X_buffer.extend(X.tolist())
                self._online_y_buffer.extend(y.tolist())
                # Keep buffer bounded
                if len(self._online_X_buffer) > self._online_buffer_max:
                    self._online_X_buffer = self._online_X_buffer[-self._online_buffer_max :]
                    self._online_y_buffer = self._online_y_buffer[-self._online_buffer_max :]
                accuracy = float(self.model.score(X, y))
                # Retrain when enough new samples have accumulated
                if len(self._online_X_buffer) >= self._online_retrain_threshold:
                    try:
                        import numpy as _np

                        X_buf = _np.array(self._online_X_buffer)
                        y_buf = _np.array(self._online_y_buffer)
                        if len(_np.unique(y_buf)) >= 2:
                            self.model = RandomForestClassifier(
                                n_estimators=self.model.n_estimators if hasattr(self.model, "n_estimators") else 100,
                                random_state=42,
                            )
                            self.model.fit(X_buf, y_buf)
                            accuracy = float(self.model.score(X_buf, y_buf))
                            logger.info("Online incremental refit: %d samples, accuracy=%.3f", len(X_buf), accuracy)
                    except Exception as _rf_err:
                        logger.warning("Online incremental refit failed: %s", _rf_err)

            return {
                "status": "success",
                "accuracy": accuracy,
                "samples_updated": int(X.shape[0]),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Online update failed on live data: %s", e)
            return {"status": "error", "error": str(e)}

    def save_model(self, filepath: str | None = None) -> dict[str, Any]:
        """
        Save the trained model to disk (trained on live data).

        Args:
            filepath: Optional file path (uses default if None)

        Returns:
            Dictionary with save status and file path
        """
        if self.model is None:
            msg = "No trained model to save"
            raise AIException(msg)

        try:
            save_path = Path(filepath or self.model_path)
            save_path.parent.mkdir(parents=True, exist_ok=True)
            with save_path.open("wb") as f:
                joblib.dump(self.model, f)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Model save failed: %s", e)
            return {"status": "error", "error": str(e)}
        else:
            return {"status": "success", "file_path": save_path}

    def load_model(self, filepath: str | None = None) -> dict[str, Any]:
        """
        Load a trained model from disk (trained on live data).

        Args:
            filepath: Optional file path (uses default if None)

        Returns:
            Dictionary with load status and file path

        Raises:
            AIException: If model file not found or load fails
        """
        try:
            load_path = Path(filepath or self.model_path)
            if not load_path.exists():
                msg = f"Model file not found: {load_path}"
                raise AIException(msg)
            with load_path.open("rb") as f:
                self.model = joblib.load(f)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Model load failed: %s", e)
            if isinstance(e, AIException):
                raise
            msg = f"Model load failed: {e}"
            raise AIException(msg) from e
        else:
            return {"status": "success", "filepath": load_path}

    # --------------------------- Data Preparation ---------------------------

    def prepare_training_data(self, raw_data: dict[str, Any]) -> dict[str, Any]:
        """
        Prepare live training data from raw market data (backend port 8000).

        Converts raw live market data to training format.
        All data must be live from Binance.US operations - no synthetic/fallback data.

        Args:
            raw_data: Raw live market data dictionary

        Returns:
            Dictionary with features, labels, and symbols (all from live data)

        Raises:
            AIException: If raw data is empty or invalid
        """
        if not raw_data:
            msg = "Raw data cannot be empty - requires live market data"
            raise AIException(msg)

        features: list[list[float]] = []
        labels: list[int] = []
        symbols: list[str] = []

        for symbol, data_list in raw_data.items():
            if not isinstance(data_list, list):
                continue
            for data_point in data_list:
                try:
                    # Extract live features from live market data (defaults are schema defaults, not fallback data)
                    fv = [
                        float(data_point.get("price", 0.0)),  # Live price (0.0 if missing is error, not fallback data)
                        float(data_point.get("volume", 0.0)),  # Live volume (0.0 if missing is error, not fallback data)
                        float(data_point.get("rsi", 50.0)),  # Live RSI (50.0 if missing is neutral default, not fallback data)
                        float(data_point.get("macd", 0.0)),  # Live MACD (0.0 if missing is error, not fallback data)
                        float(data_point.get("bollinger_upper", 0.0)),  # Live Bollinger upper (0.0 if missing is error, not fallback data)
                        float(data_point.get("bollinger_lower", 0.0)),  # Live Bollinger lower (0.0 if missing is error, not fallback data)
                    ]
                    action = str(data_point.get("action", "hold")).lower()  # Live action
                    if action == "buy":
                        label = 0
                    elif action == "sell":
                        label = 1
                    else:
                        label = 2  # HOLD (neutral default, not fallback data)
                    features.append(fv)
                    labels.append(label)
                    symbols.append(symbol)
                except (ValueError, TypeError):
                    continue

        if not features:
            msg = "No valid features extracted from live raw data"
            raise AIException(msg)

        return {
            "features": np.array(features),  # Live features array
            "labels": np.array(labels),  # Live labels array
            "symbols": symbols,  # Live symbols list
        }

    def split_data(self, data: dict[str, Any], test_size: float = 0.2) -> tuple[dict[str, Any], dict[str, Any]]:
        """
        Split live training data into train/test sets (backend port 8000).

        Args:
            data: Live training data dictionary with features and labels
            test_size: Test set size ratio (configuration default 0.2, not fallback data)

        Returns:
            Tuple of (train_data, test_data) - all from live data split

        Raises:
            AIException: If data format is invalid
        """
        if "features" not in data or "labels" not in data:
            msg = "Data must contain 'features' and 'labels' from live market data"
            raise AIException(msg)

        X = data["features"]  # Live features
        y = data["labels"]  # Live labels
        # random_state for reproducibility of split, not synthetic data generation
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=42)

        train_data = {"features": X_train, "labels": y_train}
        test_data = {"features": X_test, "labels": y_test}
        return train_data, test_data

    def cross_validate_model(self, training_data: dict[str, Any], cv: int = 5) -> dict[str, Any]:
        """
        Perform cross-validation on the current model using live data (backend port 8000).

        Args:
            training_data: Live training data from market operations
            cv: Number of cross-validation folds (configuration default 5, not fallback data)

        Returns:
            Dictionary with cross-validation results

        Raises:
            AIException: If model not trained or data invalid
        """
        if self.model is None:
            msg = "No trained model available"
            raise AIException(msg)

        try:
            X, y = self._prepare_training_data(training_data)  # Prepare live training data
            if X.size == 0 or y.size == 0:
                msg = "No valid live training samples found"
                raise AIException(msg)

            scores = cross_val_score(self.model, X, y, cv=cv)
            return {
                "mean_accuracy": float(scores.mean()),
                "std_accuracy": float(scores.std()),
                "scores": scores.tolist(),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Cross-validation failed on live data: %s", e)
            if isinstance(e, AIException):
                raise
            msg = f"Cross-validation failed on live data: {e}"
            raise AIException(msg) from e

    def hyperparameter_tuning(self, training_data: dict[str, Any], param_grid: dict[str, list[Any]]) -> dict[str, Any]:
        """
        Perform hyperparameter tuning using live data (backend port 8000).

        Args:
            training_data: Live training data from market operations
            param_grid: Parameter grid for grid search

        Returns:
            Dictionary with best parameters and score

        Raises:
            AIException: If model not trained or data invalid
        """
        if self.model is None:
            msg = "No trained model available"
            raise AIException(msg)

        try:
            X, y = self._prepare_training_data(training_data)  # Prepare live training data
            if X.size == 0 or y.size == 0:
                msg = "No valid live training samples found"
                raise AIException(msg)

            valid_params = set(RandomForestClassifier().get_params().keys())
            filtered_grid = {k: v for k, v in param_grid.items() if k in valid_params}
            if not filtered_grid:
                msg = "No valid parameters for hyperparameter tuning"
                raise AIException(msg)

            # random_state for reproducibility only, not synthetic data generation
            base_model = RandomForestClassifier(random_state=42)
            grid_search = GridSearchCV(base_model, filtered_grid, cv=5, scoring="accuracy")
            grid_search.fit(X, y)

            return {
                "best_score": float(grid_search.best_score_),
                "best_params": grid_search.best_params_,
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Hyperparameter tuning failed on live data: %s", e)
            if isinstance(e, AIException):
                raise
            msg = f"Hyperparameter tuning failed on live data: {e}"
            raise AIException(msg) from e

    # --------------------------- Internals ---------------------------

    def _prepare_training_data(self, data: dict[str, Any]) -> tuple[np.ndarray, np.ndarray]:
        """
        Internal: Prepare live training data from various formats.

        Accepts live data in formats:
          - {"features": np.ndarray, "labels": np.ndarray} (from live market data)
          - dict[symbol] -> list[datapoint dict] (live market data points)
          - dict[symbol] -> single datapoint dict (live market data point)

        All data must be live - no synthetic/fallback data.

        Args:
            data: Live training data in various formats

        Returns:
            Tuple of (X, y) arrays from live data (empty arrays if no live data, not fallback data)
        """
        if not data:
            return np.array([]), np.array([])  # No live data (empty arrays, not fallback data)

        if "features" in data and "labels" in data:
            X = data["features"]
            y = data["labels"]
            return np.asarray(X), np.asarray(y)

        features: list[list[float]] = []
        labels: list[int] = []

        # dict of symbols -> list or single datapoint
        for _, content in data.items():
            if isinstance(content, list):
                for dp in content:
                    fv, label = self._extract_fv_and_label(dp)
                    if fv is not None:
                        features.append(fv)
                        labels.append(label)
            elif isinstance(content, dict):
                fv, label = self._extract_fv_and_label(content)
                if fv is not None:
                    features.append(fv)
                    labels.append(label)

        return np.array(features), np.array(labels)

    @staticmethod
    def _extract_fv_and_label(dp: dict[str, Any]) -> tuple[list[float] | None, int]:
        """
        Extract feature vector and label from live market data point.

        Args:
            dp: Live market data point dictionary

        Returns:
            Tuple of (feature_vector, label) - None if invalid live data
        """
        try:
            # Extract live features (defaults are error/neutral values, not fallback data)
            fv = [
                float(dp.get("price", 0.0)),  # Live price (0.0 if missing is error, not fallback data)
                float(dp.get("volume", 0.0)),  # Live volume (0.0 if missing is error, not fallback data)
                float(dp.get("rsi", 50.0)),  # Live RSI (50.0 if missing is neutral default, not fallback data)
                float(dp.get("macd", 0.0)),  # Live MACD (0.0 if missing is error, not fallback data)
                float(dp.get("bollinger_upper", 0.0)),  # Live Bollinger upper (0.0 if missing is error, not fallback data)
                float(dp.get("bollinger_lower", 0.0)),  # Live Bollinger lower (0.0 if missing is error, not fallback data)
            ]
            action = str(dp.get("action", "hold")).lower()  # Live action
            if action == "buy":
                label = 0
            elif action == "sell":
                label = 1
            else:
                label = 2  # HOLD (neutral default, not fallback data)
        except (ValueError, TypeError):
            return None, 2  # Invalid live data (neutral label, not fallback data)
        else:
            return fv, label

    @staticmethod
    def _split_data(X: np.ndarray, y: np.ndarray, test_size: float = 0.2) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """
        Internal helper: Split live training data into train/test sets.

        Args:
            X: Live features array
            y: Live labels array
            test_size: Test set size ratio (configuration default 0.2, not fallback data)

        Returns:
            Tuple of (X_train, X_test, y_train, y_test) - all from live data
            (random_state=42 for reproducibility of split, not synthetic data generation)
        """
        return train_test_split(X, y, test_size=test_size, random_state=42)  # random_state for reproducibility only

    # --------------------------- Introspection ---------------------------

    def get_training_history(self) -> list[dict[str, Any]]:
        """
        Get live training history (backend port 8000).

        Returns:
            List of training history records (all from live training operations)
        """
        return self.training_history.copy()

    async def plot_training_progress(self) -> dict[str, Any]:
        """
        Return training progress data from live training history (for a downstream plotter).

        Returns:
            Dictionary with live training progress data
        """
        if not self.training_history:
            return {"error": "No live training history available"}

        try:
            timestamps = [rec.get("timestamp", f"epoch_{i}") for i, rec in enumerate(self.training_history)]
            train_scores = [float(rec.get("train_score", 0.0)) for rec in self.training_history]
            test_scores = [float(rec.get("test_score", 0.0)) for rec in self.training_history]
            samples = [int(rec.get("samples", 0)) for rec in self.training_history]
            return {
                "status": "success",
                "plot_path": await self._generate_training_plot(timestamps, train_scores, test_scores, samples),
                "timestamps": timestamps,
                "train_scores": train_scores,
                "test_scores": test_scores,
                "samples": samples,
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            return {"error": f"Failed to generate plot data: {e}"}

    def export_model_metadata(self) -> dict[str, Any]:
        """
        Export model metadata from live training operations (backend port 8000).

        Returns:
            Dictionary with live model metadata
        """
        metadata = {
            "model_version": getattr(self, "model_version", "unknown"),
            "training_history": self.training_history,  # Live training history
            "performance_metrics": getattr(self, "performance_metrics", {}),  # Live performance metrics
            "export_timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            "model_type": type(self.model).__name__ if self.model else None,
            "last_training": self.last_training_time.isoformat() if self.last_training_time else None,  # Live training timestamp
        }
        if self.model is None:
            metadata["error"] = "No model available"
        return metadata


# --------------------------- Global Model Creation Function ---------------------------


async def create_and_train_model(symbol: str, data: dict[str, Any], version: str = "v1.0") -> dict[str, Any]:
    """
    Create and train a new AI model for a specific symbol using live data (backend port 8000).

    All training data must be live from Binance.US market operations.
    No synthetic/fallback/hardcoded data allowed.

    Args:
        symbol: Live trading symbol (from Binance.US Top-10, e.g., "BTCUSDT")
        data: Live training data containing features and labels from market operations
        version: Model version string (configuration default, not fallback data)

    Returns:
        Dictionary containing trained model information (trained on live data)
    """
    try:
        # Create AI learner instance
        learner = AILearner()

        # Prepare training data
        prepared_data = learner.prepare_training_data(data)

        # Train the model
        training_result = learner.train_model(prepared_data)

        # Save the model
        model_path = f"models/active/{symbol}_{version}.pkl"
        save_result = learner.save_model(model_path)

        # Export metadata
        metadata = learner.export_model_metadata()
        metadata.update(
            {
                "symbol": symbol,
                "version": version,
                "model_path": model_path,
                "save_result": save_result,
                "training_result": training_result,
            }
        )

        return {
            "status": "success",
            "message": f"Model created and trained for {symbol}",
            "symbol": symbol,
            "version": version,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "metadata": metadata,
        }

    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        return {
            "status": "error",
            "message": f"Failed to create and train model: {e!s}",
            "symbol": symbol,
            "version": version,
            "error": str(e),
        }


# --------------------------- AI Model Initialization ---------------------------


async def initialize_ai_models() -> dict[str, Any]:
    """
    Initialize AI models for all Binance.US Top-10 coins using live data (backend port 8000).

    This function creates training data from live current market conditions
    and trains models for each of the Top-10 coins.
    All training data must be live - no synthetic/fallback data.

    CRITICAL: Disabled during startup to prevent circular dependency.
    App cannot call its own API during startup. Models initialize lazily on first use with live data.

    Returns:
        Dictionary with initialization status
    """
    # CRITICAL: Do NOT call localhost API during startup - app isn't running yet!
    # Models will initialize lazily on first use instead with live data
    logger.info("AI models will initialize on first use with live data (lazy loading)")
    return {
        "status": "success",
        "message": "AI models configured for lazy initialization with live data",
        "lazy": True,
        "models_loaded": 0,  # Models will load on first use with live data
    }


# --------------------------- AI Initialization Endpoint ---------------------------


def initialize_ai_system() -> dict[str, Any]:
    """
    Initialize the AI system by training models for all Top-10 coins using live data (backend port 8000).

    This is a synchronous wrapper for the async initialize_ai_models function.
    All training uses live Binance.US market data - no synthetic/fallback data.

    Returns:
        Dictionary with initialization status
    """
    try:
        # Import asyncio and run the async function
        async def run_initialization():
            return await initialize_ai_models()

        # Check if already in async context
        try:
            asyncio.get_running_loop()
            # We're in async context - cannot use asyncio.run(), return error
            logger.warning("Cannot initialize AI models in async context - use await initialize_ai_models() directly instead")
            result = {
                "status": "error",
                "message": "Cannot initialize AI models in async context",
                "error": "Function called from async context - use await initialize_ai_models() instead",
            }
        except RuntimeError:
            # No running loop, safe to use asyncio.run
            result = asyncio.run(run_initialization())
        else:
            return result

    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        return {
            "status": "error",
            "message": f"AI system initialization failed: {e!s}",
            "error": str(e),
        }


# --------------------------- Cache System Optimization ---------------------------


def optimize_cache_system() -> dict[str, Any]:
    """
    Optimize the cache system for live data operations (backend port 8000).

    This includes cache warming with live market data, cleanup, and performance tuning.
    All cache operations use live data - no synthetic/fallback data.

    Returns:
        Dictionary with optimization results
    """
    try:
        cache = canonical_cache
        optimization_results = {
            "cache_warming": {},
            "cleanup": {},
            "performance_metrics": {},
            "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
        }

        # Warm up cache with live market data
        try:
            # Get fresh live market data

            async def warm_cache():
                # Fetch live market data from backend port 8000
                market_data = await canonical_http_client.get_json("http://localhost:8000/api/market/live")

                if "prices" in market_data:
                    prices = market_data["prices"]  # Live prices from backend port 8000
                    for coin in prices:
                        symbol = coin.get("symbol", "").replace("-USD", "USDT")
                        if symbol:
                            # Cache live price data
                            cache_key = f"price:{symbol}"
                            cache.set(cache_key, coin, ttl=300)  # Cache live data for 5 minutes

                            # Cache live 24h change data
                            change_key = f"change:{symbol}"
                            cache.set(
                                change_key,
                                {
                                    "change_24h": coin.get("change_24h", 0),  # Live 24h change
                                    "volume_24h": coin.get("volume_24h", 0),  # Live 24h volume
                                },
                                ttl=300,  # Cache live data for 5 minutes
                            )

                    return len(prices)
                return None

            # Check if already in async context
            try:
                # loop = asyncio.get_running_loop()  # Unused
                # Already in async context, cannot use asyncio.run
                logger.warning("Already in async context, cannot warm cache")
                optimization_results["cache_warming"] = {
                    "status": "error",
                    "error": "Cannot warm cache in async context",
                    "message": "Cache warming skipped",
                }
            except RuntimeError:
                # No running loop, safe to use asyncio.run
                warmed_coins = asyncio.run(warm_cache())
                optimization_results["cache_warming"] = {
                    "status": "success",
                    "coins_warmed": warmed_coins,
                    "message": f"Successfully warmed cache with {warmed_coins} coins",
                }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            optimization_results["cache_warming"] = {
                "status": "error",
                "error": str(e),
                "message": "Failed to warm cache",
            }

        # Clean up old cache entries
        try:
            # This would typically involve removing stale entries
            # For now, we'll just check cache health
            cache_stats = cache.get_stats() if hasattr(cache, "get_stats") else {}
            optimization_results["cleanup"] = {
                "status": "success",
                "cache_stats": cache_stats,
                "message": "Cache cleanup completed",
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            optimization_results["cleanup"] = {
                "status": "error",
                "error": str(e),
                "message": "Cache cleanup failed",
            }

        # Get performance metrics from live Redis connection
        try:
            # Use shared Redis pool (sync client - no asyncio.run in sync context)
            client = get_shared_redis_sync()
            info = client.info()

            optimization_results["performance_metrics"] = {
                "redis_memory_used": info.get("used_memory_human", "Unknown"),
                "redis_connected_clients": info.get("connected_clients", 0),
                "redis_hit_rate": f"{float(info.get('keyspace_hits', 0)) / max(float(info.get('keyspace_hits', 0) + info.get('keyspace_misses', 1)), 1) * 100:.2f}%",
                "redis_uptime_days": info.get("uptime_in_days", 0),
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            optimization_results["performance_metrics"] = {
                "status": "error",
                "error": str(e),
                "message": "Failed to get performance metrics",
            }

        # Overall status
        success_count = sum(1 for result in optimization_results.values() if isinstance(result, dict) and result.get("status") == "success")

        optimization_results["overall_status"] = "optimized" if success_count >= 2 else "partial"
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
        return {
            "status": "error",
            "message": f"Cache optimization failed: {e!s}",
            "error": str(e),
        }
    else:
        return {
            "status": "success",
            "message": f"Cache optimization completed: {success_count}/3 components successful",
            "optimization_results": optimization_results,
        }


def get_training_status() -> dict[str, Any]:
    """
    Get AI training pipeline status and progress from live operations (backend port 8000).

    Returns:
        Dictionary with live training status and metrics
    """
    # Direct imports for production
    training_stats = get_training_stats()  # Get live training stats

    return {
        "status": "active",
        "pipeline_running": training_stats.get("is_running", False),  # Live pipeline status
        "training_stats": training_stats,  # Live training statistics
        "sessions": training_stats.get("sessions", 0),  # Live training sessions count
        "patterns": training_stats.get("patterns", 0),  # Live patterns count
        "accuracy": training_stats.get("accuracy", 0.0),  # Live accuracy
        "last_update": training_stats.get("last_update", None),  # Live update timestamp
        "coins_tracked": training_stats.get("coins_tracked", 0),  # Live coins tracked count
        "features_per_coin": training_stats.get("features_per_coin", 0),  # Live features count
        "update_frequency": "continuous",  # Live continuous updates
    }
