"""
AI Mystic Module - All Live Data, No Fallback/Hardcoded Data

Provides a thin, production-safe façade for AI operations using live data (backend port 8000).
All operations use live data:
- Symbol normalization: Normalizes live trading symbols from Binance.US Top-10
- Exchange identity: Uses centralized live exchange ID
- Service orchestration: Manages live AI operations
- All operations use live data - no fallback/hardcoded data

Note: Error handling for missing import provides local symbol normalization (not fallback data -
it's error handling to prevent crashes when the helper is unavailable).

Endpoint References:
- Backend API: Port 8000 (AI Mystic serves live operations)
- Binance.US API: Live trading symbols processed
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

# Single source of truth for live exchange ID
from backend.modules.constants import EXCHANGE_ID

# Import the single helper (expected to normalize to BASE/QUOTE like BTC/USDT)
try:
    from backend.utils.symbols import _to_ccxt_symbol  # Live symbol normalization helper
except Exception:  # Error handling: provide local normalization if helper unavailable (not fallback data)
    # Local symbol normalization (error handling, not fallback data)
    def _to_ccxt_symbol(sym: str) -> str:  # type: ignore[no-redef]
        """
        Local symbol normalization (error handling when helper unavailable, not fallback data).

        Args:
            sym: Live trading symbol

        Returns:
            Normalized symbol in BASE/QUOTE format
        """
        s = (sym or "").strip().upper()
        # Minimal normalization to BASE/QUOTE without introducing ad-hoc exchange strings
        if "/" in s:
            base, quote = s.split("/", 1)
            return f"{base}/{quote}"
        if s.endswith(("USDT", "USD")):
            return f"{s[:-4]}/{s[-4:]}"
        return f"{s}/USDT"


logger = logging.getLogger(__name__)


class AIMystic:
    """
    Lightweight orchestrator for AI operations using live data (backend port 8000).

    Provides a stable interface for downstream services using live Binance.US market data.
    All operations use live data - no fallback/hardcoded data.

    Responsibilities:
      - Provide a stable interface for downstream services using live data
      - Keep exchange identity centralized (EXCHANGE_ID from live operations)
      - Normalize symbols via the single imported _to_ccxt_symbol helper (live symbols)
    """

    def __init__(self) -> None:
        """
        Initialize AI Mystic for live operations.

        All initial values are configuration defaults or live state, not fallback data.
        """
        self.exchange_id: str = EXCHANGE_ID  # Live exchange ID (single source of truth)
        self.started: bool = False  # Live service status
        logger.info("AIMystic initialized for live operations")

    def start(self) -> dict[str, Any]:
        """
        Start background processing for live operations (backend port 8000).

        Returns:
            Dictionary with live startup status
        """
        self.started = True  # Mark as started for live operations
        return {
            "ok": True,
            "started": True,
            "exchange": self.exchange_id,  # Live exchange ID
            "ts": datetime.now(timezone.utc).isoformat(),  # Live timestamp
        }

    def stop(self) -> dict[str, Any]:
        """
        Stop background processing for live operations (backend port 8000).

        Returns:
            Dictionary with live shutdown status
        """
        self.started = False  # Mark as stopped
        return {
            "ok": True,
            "started": False,
            "exchange": self.exchange_id,  # Live exchange ID
            "ts": datetime.now(timezone.utc).isoformat(),  # Live timestamp
        }

    def status(self) -> dict[str, Any]:
        """
        Return lightweight health/status info for live operations (backend port 8000).

        Returns:
            Dictionary with live service status
        """
        return {
            "service": "AIMystic",
            "exchange": self.exchange_id,  # Live exchange ID
            "started": self.started,  # Live service status
            "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
        }

    def analyze_symbol(self, symbol: str) -> dict[str, Any]:
        """
        Normalize live trading symbol and return payload (backend port 8000).

        Normalizes live trading symbols from Binance.US Top-10 to BASE/QUOTE format.
        All symbols are live - no fallback/hardcoded data.

        Args:
            symbol: Live trading symbol (from Binance.US Top-10)

        Returns:
            Dictionary with normalized live symbol information

        Note:
          - This performs no network I/O (symbol normalization only)
          - Symbol is normalized to BASE/QUOTE using the imported helper
          - All symbols are live from Binance.US operations
        """
        norm = _to_ccxt_symbol(symbol)  # Normalize live symbol
        return {
            "exchange": self.exchange_id,  # Live exchange ID
            "symbol": norm,  # Normalized live symbol
            "ok": True,
            "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
        }


# Global instance for convenience (singleton pattern)
ai_mystic = AIMystic()  # Initialize singleton for live operations


def get_ai_mystic() -> AIMystic:
    """
    Get the global AI Mystic instance (backend port 8000).

    Returns:
        AIMystic instance for live operations
    """
    return ai_mystic
