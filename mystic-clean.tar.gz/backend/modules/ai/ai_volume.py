"""
AI Volume Analyzer Module - All Live Data, No Fallback/Hardcoded Data

Live-only volume analytics for Binance.US Top-10 spot symbols (backend port 8000).
All operations use live data:
- Volume analysis: Analyzes live volume data from Binance.US API
- Volume signals: Generates trading signals from live volume patterns
- OHLCV fetching: Retrieves live OHLCV data from Binance.US
- All calculations use live data - no fallback/hardcoded data

Design:
- Single source of truth for exchange ID (EXCHANGE_ID)
- ccxt-style symbols strictly as BASE/QUOTE
- Symbols from Binance.US Top-10 (imported from trading_universe when available)

Endpoint References:
- Backend API: Port 8000 (volume analyzer serves live operations)
- Binance.US API: Live OHLCV and ticker data via BinanceUSLiveClient
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from statistics import mean
from typing import Any

from backend.services.binanceus_live_client import BinanceUSLiveClient
from backend.utils.symbols import _to_ccxt_symbol

# EXCHANGE_ID is now imported from trading_universe above

logger = logging.getLogger(__name__)

# Configuration constants (not fallback data)
MIN_OHLCV_BARS = 5  # Minimum bars required for volume analysis
VOLUME_SPIKE_THRESHOLD = 2.0  # Volume spike threshold ratio
DEFAULT_VWAP_WINDOW = 20  # Default VWAP window
DEFAULT_VOL_SMA_WINDOW = 20  # Default volume SMA window

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID, TRADING_SYMBOLS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

# Top-10 symbols (ccxt format: BASE/QUOTE) - use TRADING_SYMBOLS from trading_universe (live data)
TOP10_CCXT_SYMBOLS = [f"{s[:-4]}/USDT" for s in TRADING_SYMBOLS]  # Convert BTCUSDT -> BTC/USDT


@dataclass(frozen=True)
class VolumeSnapshot:
    """
    Volume snapshot from live market data (backend port 8000).

    All fields derived from live Binance.US OHLCV data - no fallback/hardcoded data.
    """

    symbol: str  # Live trading symbol (ccxt format)
    timeframe: str  # Live timeframe
    last_close: float  # Live last close price
    last_volume: float  # Live last volume
    vol_sma_20: float  # Live volume SMA (20 period)
    vol_spike_ratio: float  # Live volume spike ratio
    vwap: float  # Live VWAP
    price_change_5: float  # Live 5-period price change
    price_change_20: float  # Live 20-period price change
    timestamp: datetime  # Live snapshot timestamp


class AIVolumeAnalyzer:
    """
    Live volume analytics for Binance.US via a ccxt-compatible client (backend port 8000).

    Analyzes live volume patterns and generates trading signals from Binance.US Top-10 symbols.
    All operations use live data - no fallback/hardcoded data.

    Guarantees:
    - Only uses EXCHANGE_ID from a single source of truth (live exchange ID)
    - Symbols always normalized to ccxt BASE/QUOTE (live symbols)
    - No ad-hoc exchange strings
    - ccxt calls only receive BASE/QUOTE (live symbols)
    """

    def __init__(self) -> None:
        """
        Initialize volume analyzer for live operations.

        All initial values are configuration defaults or live state, not fallback data.
        """
        self._exchange_id = EXCHANGE_ID  # Live exchange ID (single source of truth)
        self._client = BinanceUSLiveClient()  # Live client for Binance.US API
        self._markets_loaded = False  # Live market load status

    # ---------------- Lifecycle ----------------

    async def ensure_markets(self) -> None:
        """
        Ensure live markets are loaded from Binance.US API (backend port 8000).

        Loads live market data if not already loaded.
        """
        if not self._markets_loaded:
            try:
                await self._client.load_markets()  # Load live markets
                self._markets_loaded = True
                logger.info("Live markets loaded for %s", self._exchange_id)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to load live markets for %s", self._exchange_id)
                self._markets_loaded = False

    # ---------------- Fetchers ----------------

    async def fetch_recent_ohlcv(
        self,
        symbol: str,
        timeframe: str = "1m",  # Configuration default: timeframe
        limit: int = 200,  # Configuration default: limit
    ) -> list[list[float]]:
        """
        Fetch recent live OHLCV from Binance.US API (backend port 8000).

        Args:
            symbol: Live trading symbol (ccxt BASE/QUOTE format)
            timeframe: Live timeframe (configuration default "1m", not fallback data)
            limit: Number of bars to fetch (configuration default 200, not fallback data)

        Returns:
            List of [ts, open, high, low, close, volume] from live data
            (empty list if fetch fails or invalid data, not fallback data)
        """
        await self.ensure_markets()
        ccxt_symbol = _to_ccxt_symbol(symbol)  # Normalize live symbol
        self._validate_symbol(ccxt_symbol)
        try:
            data = await self._client.fetch_ohlcv(ccxt_symbol, timeframe=timeframe, limit=limit)  # Fetch live OHLCV
            [] if not isinstance(data, list) else data  # Invalid live data (empty list, not fallback data) or Return live OHLCV data
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception(
                "fetch_recent_ohlcv failed on live data (%s %s %s)",
                self._exchange_id,
                ccxt_symbol,
                timeframe,
            )
            return []  # Error fetching live data (empty list, not fallback data)

    async def fetch_ticker_price(self, symbol: str) -> float | None:
        """
        Fetch live price from ticker (backend port 8000).

        Args:
            symbol: Live trading symbol (ccxt BASE/QUOTE format)

        Returns:
            Live price from ticker, or None if unavailable (not fallback data)
        """
        await self.ensure_markets()
        ccxt_symbol = _to_ccxt_symbol(symbol)  # Normalize live symbol
        self._validate_symbol(ccxt_symbol)
        try:
            t = await self._client.fetch_ticker(ccxt_symbol)  # Fetch live ticker
            # Prefer 'last', then 'close' from live ticker data
            for key in ("last", "close"):
                v = t.get(key)
                if v not in (None, False, True):
                    return float(v)  # Return live price
            # Try info dictionary from live ticker
            info = t.get("info") if isinstance(t, dict) else None
            if isinstance(info, dict):
                for k in ("lastPrice", "close", "c"):
                    v = info.get(k)
                    if v is not None:
                        return float(v)  # Return live price from info
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception(
                "fetch_ticker_price failed on live data (%s %s)",
                self._exchange_id,
                ccxt_symbol,
            )
        return None  # No live price available (not fallback data)

    # ---------------- Calculations ----------------

    @staticmethod
    def _vol_sma(volumes: list[float], window: int = DEFAULT_VOL_SMA_WINDOW) -> float:
        """
        Calculate volume SMA from live volume data (backend port 8000).

        Args:
            volumes: Live volume list
            window: SMA window (configuration default, not fallback data)

        Returns:
            Volume SMA from live data (0.0 if no volumes, not fallback data)
        """
        if len(volumes) < window:
            return mean(volumes) if volumes else 0.0  # Use available live data or 0.0 if none (not fallback data)
        return mean(volumes[-window:])  # Calculate SMA from live data

    @staticmethod
    def _vwap(ohlcv: list[list[float]], window: int = DEFAULT_VWAP_WINDOW) -> float:
        """
        Calculate VWAP from live OHLCV data (backend port 8000).

        Args:
            ohlcv: Live OHLCV data
            window: VWAP window (configuration default, not fallback data)

        Returns:
            VWAP from live data (0.0 if no data, not fallback data)
        """
        if not ohlcv:
            return 0.0  # No live data (0.0, not fallback data)
        sample = ohlcv[-window:] if len(ohlcv) >= window else ohlcv  # Use available live data
        pv = 0.0
        vv = 0.0
        for _, _o, _h, _l, _c, _v in sample:
            typical = (_h + _l + _c) / 3.0  # Typical price from live data
            pv += typical * _v  # Price * volume from live data
            vv += _v  # Volume from live data
        return (pv / vv) if vv > 0 else 0.0  # VWAP from live data (0.0 if no volume, not fallback data)

    @staticmethod
    def _pct_change(values: list[float], lookback: int) -> float:
        if len(values) <= lookback:
            return 0.0
        a = values[-(lookback + 1)]
        b = values[-1]
        if a == 0:
            return 0.0
        return (b - a) / a

    def _compute_snapshot(self, symbol: str, timeframe: str, ohlcv: list[list[float]]) -> VolumeSnapshot | None:
        """
        Compute volume snapshot from live OHLCV data (backend port 8000).

        Args:
            symbol: Live trading symbol
            timeframe: Live timeframe
            ohlcv: Live OHLCV data

        Returns:
            VolumeSnapshot from live data, or None if insufficient data (not fallback data)
        """
        if len(ohlcv) < MIN_OHLCV_BARS:  # Configuration constant: minimum bars required
            return None  # Insufficient live data (None, not fallback data)

        closes = [float(x[4]) for x in ohlcv]
        vols = [float(x[5]) for x in ohlcv]

        last_close = closes[-1]  # Latest live close price
        last_volume = vols[-1]  # Latest live volume
        vol_sma_20 = self._vol_sma(vols, window=DEFAULT_VOL_SMA_WINDOW)  # Volume SMA from live data
        vol_spike_ratio = (last_volume / vol_sma_20) if vol_sma_20 > 0 else 0.0  # Spike ratio from live data
        vwap_val = self._vwap(ohlcv, window=DEFAULT_VWAP_WINDOW)  # VWAP from live data
        pchg_5 = self._pct_change(closes, 5)  # 5-period change from live data
        pchg_20 = self._pct_change(closes, 20)  # 20-period change from live data

        return VolumeSnapshot(
            symbol=symbol,
            timeframe=timeframe,
            last_close=last_close,
            last_volume=last_volume,
            vol_sma_20=vol_sma_20,
            vol_spike_ratio=vol_spike_ratio,
            vwap=vwap_val,
            price_change_5=pchg_5,
            price_change_20=pchg_20,
            timestamp=datetime.now(timezone.utc),
        )

    # ---------------- Signals ----------------

    @staticmethod
    def _volume_signal(snapshot: VolumeSnapshot) -> tuple[str, float, str]:
        """
        Generate volume-based signal from live volume snapshot (backend port 8000).

        Simple volume-based signal from live data:
          - If spike_ratio >= VOLUME_SPIKE_THRESHOLD and price above VWAP and momentum positive -> BUY
          - If spike_ratio >= VOLUME_SPIKE_THRESHOLD and price below VWAP and momentum negative -> SELL
          - Else HOLD
        Confidence scales with spike size and alignment from live data.

        Args:
            snapshot: Live volume snapshot from market data

        Returns:
            Tuple of (action, confidence, reason) from live volume analysis
        """
        spike = snapshot.vol_spike_ratio  # Live spike ratio
        above_vwap = snapshot.last_close >= snapshot.vwap if snapshot.vwap > 0 else False  # Price vs VWAP from live data
        momentum = (snapshot.price_change_5 + snapshot.price_change_20) / 2.0  # Momentum from live data

        if spike >= VOLUME_SPIKE_THRESHOLD and above_vwap and momentum > 0:  # Configuration constant: spike threshold
            # Confidence: clamp in [0.6, 0.95] based on live data
            conf = max(0.6, min(0.95, 0.45 + 0.1 * (spike - VOLUME_SPIKE_THRESHOLD) + min(0.2, momentum)))
            return "BUY", conf, "Volume spike with positive momentum above VWAP"
        if spike >= VOLUME_SPIKE_THRESHOLD and (not above_vwap) and momentum < 0:  # Configuration constant: spike threshold
            conf = max(0.6, min(0.95, 0.45 + 0.1 * (spike - VOLUME_SPIKE_THRESHOLD) + min(0.2, abs(momentum))))
            return "SELL", conf, "Volume spike with negative momentum below VWAP"

        return "HOLD", 0.5, "No qualified volume imbalance"

    # ---------------- Public API ----------------

    async def analyze_symbol(
        self,
        symbol: str,
        timeframe: str = "1m",  # Configuration default: timeframe
        limit: int = 200,  # Configuration default: limit
    ) -> dict[str, Any]:
        """
        Analyze a single symbol for volume signals from live data (backend port 8000).

        Args:
            symbol: Live trading symbol (ccxt BASE/QUOTE format)
            timeframe: Live timeframe (configuration default "1m", not fallback data)
            limit: Number of bars to fetch (configuration default 200, not fallback data)

        Returns:
            Dictionary with live snapshot metrics and suggested action
            (status "no_data" or "insufficient_data" if live data unavailable, not fallback data)
        """
        await self.ensure_markets()
        ccxt_symbol = _to_ccxt_symbol(symbol)  # Normalize live symbol
        self._validate_symbol(ccxt_symbol)

        ohlcv = await self.fetch_recent_ohlcv(ccxt_symbol, timeframe=timeframe, limit=limit)  # Fetch live OHLCV
        if not ohlcv:
            # No live data available (not fallback data)
            return {
                "exchange": self._exchange_id,  # Live exchange ID
                "symbol": ccxt_symbol,  # Live symbol
                "timeframe": timeframe,
                "status": "no_data",  # No live data available (not fallback data)
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

        snap = self._compute_snapshot(ccxt_symbol, timeframe, ohlcv)  # Compute from live data
        if not snap:
            # Insufficient live data (not fallback data)
            return {
                "exchange": self._exchange_id,  # Live exchange ID
                "symbol": ccxt_symbol,  # Live symbol
                "timeframe": timeframe,
                "status": "insufficient_data",  # Insufficient live data (not fallback data)
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

        action, confidence, reason = self._volume_signal(snap)  # Generate signal from live snapshot

        return {
            "exchange": self._exchange_id,  # Live exchange ID
            "symbol": ccxt_symbol,  # Live symbol
            "timeframe": timeframe,
            "action": action,  # Live signal action
            "confidence": confidence,  # Live confidence
            "reason": reason,  # Live signal reason
            "metrics": {
                "last_close": snap.last_close,  # Live close price
                "last_volume": snap.last_volume,  # Live volume
                "vol_sma_20": snap.vol_sma_20,  # Live volume SMA
                "vol_spike_ratio": snap.vol_spike_ratio,  # Live spike ratio
                "vwap": snap.vwap,  # Live VWAP
                "price_change_5": snap.price_change_5,  # Live 5-period change
                "price_change_20": snap.price_change_20,  # Live 20-period change
            },
            "timestamp": snap.timestamp.isoformat(),  # Live timestamp
        }

    async def analyze_top10(
        self,
        timeframe: str = "1m",  # Configuration default: timeframe
        limit: int = 200,  # Configuration default: limit
        concurrency: int = 4,  # Configuration default: concurrency
    ) -> list[dict[str, Any]]:
        """
        Analyze the Top-10 universe concurrently from live data (backend port 8000).

        Args:
            timeframe: Live timeframe (configuration default "1m", not fallback data)
            limit: Number of bars to fetch per symbol (configuration default 200, not fallback data)
            concurrency: Maximum concurrent requests (configuration default 4, not fallback data)

        Returns:
            List of analysis results from live data for all Top-10 symbols
        """
        await self.ensure_markets()
        sem = asyncio.Semaphore(concurrency)  # Rate limiting for live API

        async def _task(sym: str) -> dict[str, Any]:
            async with sem:
                return await self.analyze_symbol(sym, timeframe=timeframe, limit=limit)  # Analyze live symbol

        tasks = [_task(s) for s in TOP10_CCXT_SYMBOLS]  # Create tasks for all live symbols
        results = await asyncio.gather(*tasks, return_exceptions=True)  # Fetch live data concurrently

        output: list[dict[str, Any]] = []
        for r in results:
            if isinstance(r, Exception):
                logger.exception("analyze_top10 task error on live data")
                continue
            output.append(r)  # Add live analysis result
        return output  # Return all live analysis results

    # ---------------- Internal ----------------

    @staticmethod
    def _validate_symbol(symbol: str) -> None:
        """
        Validate live trading symbol format (backend port 8000).

        Args:
            symbol: Live trading symbol to validate

        Raises:
            ValueError: If symbol format is invalid
        """
        if not isinstance(symbol, str) or "/" not in symbol:
            error_msg = "symbol must be ccxt-style 'BASE/QUOTE' for live operations"
            raise ValueError(error_msg)

    # ---------------- Convenience ----------------

    async def quick_signal(self, symbol: str) -> dict[str, Any]:
        """
        Convenience method: Get quick volume signal from live data (backend port 8000).

        Uses 1m timeframe with default limit for fast analysis.

        Args:
            symbol: Live trading symbol (ccxt BASE/QUOTE format)

        Returns:
            Dictionary with live volume signal (quick analysis)
        """
        return await self.analyze_symbol(symbol, timeframe="1m", limit=200)  # Quick analysis from live data


# Global instance (singleton pattern)
ai_volume_analyzer = AIVolumeAnalyzer()  # Initialize singleton for live operations


# Simple manual test harness (optional, uses live data)
async def _self_test() -> None:
    """Test harness using live data (backend port 8000)."""
    svc = AIVolumeAnalyzer()
    await svc.ensure_markets()  # Load live markets
    _ = await svc.analyze_symbol("BTCUSDT", timeframe="1m", limit=200)  # Analyze live symbol


if __name__ == "__main__":
    asyncio.run(_self_test())
