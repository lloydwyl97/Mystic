"""
Analytics Engine Module - All Live Data, No Fallback/Hardcoded Data

Provides analytics and metrics tracking functionality for live AI operations (backend port 8000).
All operations use live data:
- Event tracking: Tracks live events from AI operations
- Metrics tracking: Stores live metrics from trading operations
- All timestamps use live UTC time
- All data is from live operations - no fallback/hardcoded data

Endpoint References:
- Backend API: Port 8000 (analytics engine serves live operations)
- All events and metrics are from live operations - no mock/test data
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

# Maximum events to retain for AI learning (prevent unbounded growth)
MAX_ANALYTICS_EVENTS = int(os.getenv("MAX_ANALYTICS_EVENTS", "10000"))


@dataclass(frozen=True)
class AnalyticsEvent:
    """
    Analytics event from live operations (backend port 8000).

    All fields represent live data from AI operations - no fallback/hardcoded data.
    """

    name: str  # Live event name
    data: dict[str, Any]  # Live event data
    timestamp: str  # Live timestamp in ISO 8601 UTC format


class AnalyticsEngine:
    """
    Lightweight in-memory analytics/metrics tracker for live operations (backend port 8000).

    Tracks live events and metrics from AI trading operations.
    All data is from live operations - no fallback/hardcoded data.

    Features:
    - Stores live metrics as key/value pairs
    - Stores live events as an append-only list (in-memory)
    - Timestamps are recorded in UTC ISO 8601 format from live time
    """

    def __init__(self) -> None:
        """
        Initialize analytics engine for live operations.

        All initial values are empty collections ready for live data, not fallback data.
        """
        self._metrics: dict[str, Any] = {}  # Live metrics storage
        self._events: list[AnalyticsEvent] = []  # Live events storage

    # --------------------- Events ---------------------

    def track_event(self, name: str, data: dict[str, Any]) -> AnalyticsEvent:
        """
        Track a live analytics event (backend port 8000).

        Args:
            name: Live event name
            data: Live event data dictionary

        Returns:
            AnalyticsEvent created from live data
        """
        event = AnalyticsEvent(name=name, data=dict(data or {}), timestamp=self._utc_now())  # Create live event
        self._events.append(event)  # Store live event

        # Ring buffer: Keep only MAX_ANALYTICS_EVENTS for AI learning
        if len(self._events) > MAX_ANALYTICS_EVENTS:
            # Keep most recent events (AI learns from recent patterns)
            self._events = self._events[-MAX_ANALYTICS_EVENTS:]

        return event

    def get_events(self, limit: int | None = None) -> list[AnalyticsEvent]:
        """
        Get recent live events (backend port 8000).

        Args:
            limit: Optional limit on number of events (configuration default, not fallback data)

        Returns:
            List of live events (most recent last)
        """
        if limit is not None and limit >= 0:
            return self._events[-limit:]  # Return limited live events
        return list(self._events)  # Return all live events

    def clear_events(self) -> None:
        """
        Clear all live events (backend port 8000).

        Clears the in-memory event store. All events are from live operations.
        """
        self._events.clear()  # Clear live events

    # --------------------- Metrics ---------------------

    def get_metrics(self) -> dict[str, Any]:
        """
        Get all live metrics (backend port 8000).

        Returns:
            Shallow copy of all live metrics dictionary
        """
        return dict(self._metrics)  # Return copy of live metrics

    def set_metric(self, key: str, value: Any) -> None:
        """
        Set a live metric value (backend port 8000).

        Args:
            key: Metric key
            value: Live metric value from operations
        """
        self._metrics[key] = value  # Store live metric

    def get_metric(self, key: str, default: Any = None) -> Any:
        """
        Get a live metric value (backend port 8000).

        Args:
            key: Metric key
            default: Default value if metric not found (configuration default, not fallback data)

        Returns:
            Live metric value, or default if not found (not fallback data)
        """
        return self._metrics.get(key, default)  # Get live metric (default if not found, not fallback data)

    def clear_metrics(self) -> None:
        """
        Clear all live metrics (backend port 8000).

        Clears the in-memory metrics store. All metrics are from live operations.
        """
        self._metrics.clear()  # Clear live metrics

    # --------------------- Time ---------------------

    @staticmethod
    def _utc_now() -> str:
        """
        Get current UTC time in ISO 8601 format (backend port 8000).

        Returns:
            Live UTC timestamp in ISO 8601 format
        """
        return datetime.now(timezone.utc).isoformat()  # Live UTC timestamp
