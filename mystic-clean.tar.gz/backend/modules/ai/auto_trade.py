"""
Auto Trade Service Module - All Live Data, No Fallback/Hardcoded Data

Live-only trading helpers for Binance.US Top-10 spot symbols (backend port 8000).
All operations use live data:
- Market orders: Places live market orders on Binance.US
- Trade execution: Executes live trades based on live signals
- Signal evaluation: Evaluates live trading signals
- All orders use live market data - no fallback/hardcoded data

Design:
- Single source of truth for exchange ID (EXCHANGE_ID)
- ccxt-style symbols strictly as BASE/QUOTE
- Symbols from Binance.US Top-10 (imported from trading_universe when available)

Endpoint References:
- Backend API: Port 8000 (auto trade service serves live operations)
- Binance.US API: Live order execution via BinanceUSLiveClient
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from backend.services.binanceus_live_client import BinanceUSLiveClient
from backend.services.confidence_normalizer import ConfidenceNormalizer
from backend.services.constants import EXCHANGE_ID
from backend.utils.symbols import _to_ccxt_symbol

logger = logging.getLogger(__name__)

# Configuration constants (not fallback data)
MIN_CONFIDENCE_THRESHOLD = 0.55  # Minimum confidence for live order execution - quality over quantity

# Top-10 symbols (ccxt format: BASE/QUOTE) - configuration defaults
# NOTE: Should import from backend.config.trading_universe when available
TOP10_CCXT_SYMBOLS = [
    "BTC/USDT",
    "ETH/USDT",
    "ADA/USDT",
    "SOL/USDT",
    "DOGE/USDT",
    "XRP/USDT",
    "BCH/USDT",
    "LTC/USDT",
    "AVAX/USDT",
    "LINK/USDT",
]


@dataclass(frozen=True)
class TradeIntent:
    """
    Trade intent for live operations (backend port 8000).

    All fields represent live trading parameters - no fallback/hardcoded data.
    """

    symbol: str  # Live trading symbol (ccxt: BASE/QUOTE)
    side: str  # Live order side ("buy" | "sell")
    quantity: float  # Live base asset amount
    type: str = "market"  # Order type (configuration default "market", not fallback data)
    client_order_id: str | None = None  # Optional client order ID


class AutoTradeService:
    """
    Thin live trading utility for Binance.US via a ccxt-compatible client (backend port 8000).

    Executes live market orders based on live trading signals.
    All operations use live data - no fallback/hardcoded data.

    Guarantees:
    - Only uses EXCHANGE_ID from a single source of truth (live exchange ID)
    - Symbols always normalized to ccxt BASE/QUOTE (live symbols)
    - No ad-hoc exchange strings
    - All orders are live market orders on Binance.US
    """

    def __init__(self) -> None:
        """
        Initialize auto trade service for live operations.

        All initial values are configuration defaults or live state, not fallback data.
        """
        self._exchange_id = EXCHANGE_ID  # Live exchange ID (single source of truth)
        self._client = BinanceUSLiveClient()  # Live client for Binance.US API
        self._markets_loaded = False  # Live market load status

    # ---------------- Lifecycle ----------------

    async def ensure_markets(self) -> None:
        """
        Ensure live markets are loaded from Binance.US API (backend port 8000).

        Loads live market data if not already loaded.
        """
        if not self._markets_loaded:
            try:
                await self._client.load_markets()  # Load live markets
                self._markets_loaded = True
                logger.info("Live markets loaded for %s", self._exchange_id)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to load live markets for %s", self._exchange_id)
                self._markets_loaded = False

    # ---------------- Public API ----------------

    async def market_buy(
        self,
        symbol: str,
        quantity: float,
        client_order_id: str | None = None,  # Optional client order ID
    ) -> dict[str, Any]:
        """
        Place a live market BUY order (backend port 8000).

        Args:
            symbol: Live trading symbol (any format; normalized to BASE/QUOTE)
            quantity: Live base asset amount
            client_order_id: Optional client order ID

        Returns:
            Dictionary with live order result
        """
        await self.ensure_markets()
        ccxt_symbol = _to_ccxt_symbol(symbol)  # Normalize live symbol
        self._validate_symbol(ccxt_symbol)

        intent = TradeIntent(
            symbol=ccxt_symbol,  # Live symbol
            side="buy",  # Live buy side
            quantity=float(quantity),  # Live quantity
            client_order_id=client_order_id,
        )
        return await self._execute_market_order(intent)  # Execute live order

    async def market_sell(
        self,
        symbol: str,
        quantity: float,
        client_order_id: str | None = None,  # Optional client order ID
    ) -> dict[str, Any]:
        """
        Place a live market SELL order (backend port 8000).

        Args:
            symbol: Live trading symbol (any format; normalized to BASE/QUOTE)
            quantity: Live base asset amount
            client_order_id: Optional client order ID

        Returns:
            Dictionary with live order result
        """
        await self.ensure_markets()
        ccxt_symbol = _to_ccxt_symbol(symbol)  # Normalize live symbol
        self._validate_symbol(ccxt_symbol)

        intent = TradeIntent(
            symbol=ccxt_symbol,  # Live symbol
            side="sell",  # Live sell side
            quantity=float(quantity),  # Live quantity
            client_order_id=client_order_id,
        )
        return await self._execute_market_order(intent)  # Execute live order

    async def evaluate_and_trade(self, signal: dict[str, Any]) -> dict[str, Any]:
        """
        Evaluate a live BUY/SELL/HOLD signal and optionally place a market order (backend port 8000).

        Expected fields in `signal` (all from live operations):
          - symbol: str (any format; normalized to BASE/QUOTE)
          - signal: "BUY" | "SELL" | "HOLD"
          - confidence: float in [0,1] (from live analysis)
          - quantity: float (base asset amount, required for BUY/SELL)

        Args:
            signal: Live trading signal dictionary

        Returns:
            Dictionary with evaluation result and live order (if executed)
        """
        try:
            await self.ensure_markets()

            raw_symbol = str(signal.get("symbol", ""))  # Get live symbol
            ccxt_symbol = _to_ccxt_symbol(raw_symbol)  # Normalize live symbol
            self._validate_symbol(ccxt_symbol)

            decision = str(signal.get("signal", "HOLD")).upper()  # Live decision
            confidence = ConfidenceNormalizer.normalize(float(signal.get("confidence", 0.0) or 0.0))  # Live confidence
            qty = signal.get("quantity")  # Live quantity
            now = datetime.now(timezone.utc).isoformat()  # Live timestamp

            result: dict[str, Any] = {
                "exchange": self._exchange_id,  # Live exchange ID
                "symbol": ccxt_symbol,  # Live symbol
                "decision": decision,  # Live decision
                "confidence": confidence,  # Live confidence
                "timestamp": now,  # Live timestamp
                "status": "skipped",  # Default: HOLD or low confidence (not fallback data)
            }

            # Basic gating: require at least MIN_CONFIDENCE_THRESHOLD and qty for live orders
            if decision == "BUY" and confidence >= MIN_CONFIDENCE_THRESHOLD:  # Configuration constant: confidence threshold
                if qty is None:
                    result["error"] = "quantity required for BUY"
                    return result
                order = await self.market_buy(ccxt_symbol, float(qty))  # Execute live buy order
                result["order"] = order
                result["status"] = "executed"
                return result
            if decision == "SELL" and confidence >= MIN_CONFIDENCE_THRESHOLD:  # Configuration constant: confidence threshold
                if qty is None:
                    result["error"] = "quantity required for SELL"
                    return result
                order = await self.market_sell(ccxt_symbol, float(qty))  # Execute live sell order
                result["order"] = order
                result["status"] = "executed"
                return result
            # HOLD or low confidence: no order (status already "skipped", not fallback data)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("evaluate_and_trade error on live signal")
            error_msg = str(signal.get("symbol", ""))
            signal_decision = str(signal.get("signal", "HOLD")).upper()
            signal_confidence = ConfidenceNormalizer.normalize(float(signal.get("confidence", 0.0) or 0.0))
            return {
                "exchange": self._exchange_id,  # Live exchange ID
                "symbol": _to_ccxt_symbol(error_msg),  # Normalized live symbol
                "decision": signal_decision,  # Live decision
                "confidence": signal_confidence,  # Live confidence
                "status": "error",  # Error status (not fallback data)
                "error": "Error processing live signal",  # Error message
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

    # ---------------- Internal ----------------

    async def _execute_market_order(self, intent: TradeIntent) -> dict[str, Any]:
        """
        Execute a live market order using the live client (backend port 8000).

        Only BASE/QUOTE symbols are passed to the client. All operations use live data.

        Args:
            intent: Live trade intent

        Returns:
            Dictionary with live order result
        """
        try:
            params: dict[str, Any] = {}
            if intent.client_order_id:
                params["clientOrderId"] = intent.client_order_id

            order = await self._client.create_order(  # Execute live order on Binance.US
                symbol=intent.symbol,  # Live symbol
                type=intent.type,  # Live order type
                side=intent.side,  # Live side
                amount=intent.quantity,  # Live quantity
                price=None,  # Market order (no price)
                params=params or None,
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception(
                "Live order failed (%s %s %s)",
                self._exchange_id,
                intent.symbol,
                intent.side,
            )
            return {
                "success": False,  # Live order failure
                "exchange": self._exchange_id,  # Live exchange ID
                "symbol": intent.symbol,  # Live symbol
                "side": intent.side,  # Live side
                "quantity": intent.quantity,  # Live quantity
                "error": "Error executing live order",  # Error message (not fallback data)
            }
        else:
            # Order executed successfully
            return {
                "success": True,  # Live order success
                "exchange": self._exchange_id,  # Live exchange ID
                "symbol": intent.symbol,  # Live symbol
                "side": intent.side,  # Live side
                "quantity": intent.quantity,  # Live quantity
                "order": order,  # Live order result
            }

    @staticmethod
    def _validate_symbol(symbol: str) -> None:
        """
        Validate live trading symbol format (backend port 8000).

        Args:
            symbol: Live trading symbol to validate

        Raises:
            ValueError: If symbol format is invalid
        """
        if not isinstance(symbol, str) or "/" not in symbol:
            error_msg = "symbol must be ccxt-style 'BASE/QUOTE' for live operations"
            raise ValueError(error_msg)

    # ---------------- Convenience ----------------

    async def top10_ready(self) -> bool:
        """
        Quick sanity check: ensure live markets contain all Top-10 symbols (backend port 8000).

        Returns:
            True if all Top-10 symbols are available in live markets, False otherwise (not fallback data)
        """
        try:
            await self.ensure_markets()
            markets = getattr(self._client, "markets", {}) or {}  # Get live markets
            return all(s in markets for s in TOP10_CCXT_SYMBOLS)  # Check all live symbols
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            return False  # Markets not ready (False, not fallback data)


# Global instance (singleton pattern)
auto_trade_service = AutoTradeService()  # Initialize singleton for live operations


# Simple manual test harness (optional, uses live data)
async def _self_test() -> None:
    """Test harness using live data (backend port 8000)."""
    svc = AutoTradeService()
    await svc.ensure_markets()  # Load live markets
    _ = await svc.evaluate_and_trade({"symbol": "BTCUSDT", "signal": "HOLD", "confidence": 0.7, "quantity": 0.001})  # Test with live signal


if __name__ == "__main__":
    asyncio.run(_self_test())
