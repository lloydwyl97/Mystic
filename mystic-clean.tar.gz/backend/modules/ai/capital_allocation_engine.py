"""
Capital Allocation Engine Module - All Live Data, No Fallback/Hardcoded Data

Calculates optimal USD allocation per symbol based on live risk, confidence, and diversification
for Binance.US Top-10 spot symbols (backend port 8000).
All operations use live data:
- Signal confidence: From live SignalEngine signals via canonical cache
- Overlord decisions: From live GlobalOverlord decisions via canonical cache
- Time optimization: From live TimeAwareTradeOptimizer via canonical cache
- Price history: From live price data via canonical cache
- All calculations use live data - no fallback/hardcoded data

Endpoint References:
- Backend API: Port 8000 (capital allocation engine serves live operations)
- Canonical Cache: Live signals and price history from trading operations
- All operations handle live data - no mock/test data
"""

import logging
from datetime import datetime, timezone
from typing import Any

import numpy as np

from backend.services.canonical_cache import canonical_cache

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID, TRADING_SYMBOLS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

logger = logging.getLogger(__name__)

# Configuration constants (not fallback data)
DEFAULT_ERROR_CONFIDENCE = 0.5  # Neutral confidence when live data unavailable (error state, not fallback)
DEFAULT_ERROR_VOLATILITY = 0.03  # Neutral volatility when live data unavailable (error state, not fallback)
DEFAULT_ERROR_RISK_SCORE = 0.5  # Neutral risk score when live data unavailable (error state, not fallback)
MIN_VOLATILITY_CLAMP = 0.01  # Minimum volatility clamp (1%)
MAX_VOLATILITY_CLAMP = 0.10  # Maximum volatility clamp (10%)
MIN_RISK_SCORE_CLAMP = 0.1  # Minimum risk score clamp
MAX_RISK_SCORE_CLAMP = 1.0  # Maximum risk score clamp
MIN_PRICE_HISTORY_LENGTH = 10  # Minimum price history bars required
SIGNAL_HISTORY_LIMIT = 5  # Number of recent signals to retrieve
PRICE_HISTORY_LIMIT = 30  # Number of price history bars to retrieve
ANNUALIZATION_FACTOR = 365  # Days per year for volatility annualization
NORMALIZATION_VOLATILITY = 0.05  # 5% volatility normalization base


class CapitalAllocationEngine:
    """
    Capital allocation engine for live trading operations (backend port 8000).

    Calculates optimal USD allocation per symbol based on live risk, confidence, and diversification.
    All operations use live data from canonical cache - no fallback/hardcoded data.
    """

    def __init__(self) -> None:
        """
        Initialize capital allocation engine with risk parameters for live operations.

        All parameters are configuration defaults for live risk management, not fallback data.
        """
        self.cache = canonical_cache  # Live cache for signals and price data

        # Risk management parameters (configuration defaults, not fallback data)
        self.max_allocation_per_symbol = 0.4  # 40% max per symbol
        self.min_allocation_per_symbol = 0.05  # 5% min per symbol
        self.max_portfolio_risk = 0.25  # 25% max portfolio risk
        self.diversification_target = 0.8  # 80% diversification target

        # Confidence weighting parameters (configuration defaults, not fallback data)
        self.confidence_weight = 0.4  # 40% weight for confidence
        self.volatility_weight = 0.3  # 30% weight for volatility
        self.diversification_weight = 0.3  # 30% weight for diversification

        # Volatility thresholds (configuration defaults, not fallback data)
        self.low_volatility_threshold = 0.02  # 2% daily volatility
        self.high_volatility_threshold = 0.05  # 5% daily volatility

        # Top symbols for allocation - use TRADING_SYMBOLS from trading_universe (live data)
        self.top_symbols = list(TRADING_SYMBOLS)

        # Exchange diversification - use EXCHANGE_ID from trading_universe (live data)
        self.exchanges = [EXCHANGE_ID]

        logger.info("[OK] CapitalAllocationEngine initialized for live operations")

    def _get_signal_confidence(self, symbol: str) -> float:
        """
        Get live signal confidence score from SignalEngine (backend port 8000).

        Args:
            symbol: Live trading symbol

        Returns:
            Live confidence score from SignalEngine, or neutral value if unavailable (error state, not fallback data)
        """
        try:
            # Get recent live signals from cache
            signals = self.cache.get_signals_by_type("SIGNAL_ENGINE", limit=SIGNAL_HISTORY_LIMIT)

            # Filter by live symbol
            symbol_signals = [signal for signal in signals if signal.get("symbol") == symbol]

            if symbol_signals:
                # Use average confidence from live signals
                confidences = [signal.get("confidence", 0.0) for signal in symbol_signals]
                result = float(np.mean(confidences))  # Return live confidence average
            else:
                # No live signals available (neutral value, not fallback data)
                result = DEFAULT_ERROR_CONFIDENCE
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live signal confidence for %s", symbol)
            return DEFAULT_ERROR_CONFIDENCE  # Error state (not fallback data)
        else:
            return result

    def _get_overlord_decision(self, symbol: str) -> dict[str, Any]:
        """
        Get live final decision from GlobalOverlord (backend port 8000).

        Args:
            symbol: Live trading symbol

        Returns:
            Live overlord decision dictionary, or neutral decision if unavailable (error state, not fallback data)
        """
        try:
            # Get recent live overlord decisions from cache
            signals = self.cache.get_signals_by_type("OVERLORD_DECISION", limit=SIGNAL_HISTORY_LIMIT)

            # Filter by live symbol
            symbol_decisions = [signal for signal in signals if signal.get("symbol") == symbol]

            if symbol_decisions:
                latest_decision = symbol_decisions[0]  # Get latest live decision
                return {
                    "decision": latest_decision.get("metadata", {}).get("decision", "HOLD"),  # Live decision
                    "confidence": latest_decision.get("confidence", 0.0),  # Live confidence
                    "timestamp": latest_decision.get("timestamp"),  # Live timestamp
                }

            # No live decisions available (neutral decision, not fallback data)
            return {
                "decision": "HOLD",  # Neutral decision (not fallback data)
                "confidence": 0.0,  # No confidence (not fallback data)
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live overlord decision for %s", symbol)
            return {
                "decision": "HOLD",  # Error state decision (not fallback data)
                "confidence": 0.0,  # Error state confidence (not fallback data)
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

    def _get_time_optimization(self, symbol: str) -> dict[str, Any]:
        """
        Get live time optimization from TimeAwareTradeOptimizer (backend port 8000).

        Args:
            symbol: Live trading symbol

        Returns:
            Live time optimization dictionary, or neutral values if unavailable (error state, not fallback data)
        """
        try:
            # Get recent live time optimizations from cache
            signals = self.cache.get_signals_by_type("TIME_OPTIMIZATION", limit=SIGNAL_HISTORY_LIMIT)

            # Filter by live symbol
            symbol_optimizations = [signal for signal in signals if signal.get("symbol") == symbol]

            if symbol_optimizations:
                latest_optimization = symbol_optimizations[0]  # Get latest live optimization
                return {
                    "confidence": latest_optimization.get("confidence", 0.0),  # Live confidence
                    "best_entry": latest_optimization.get("metadata", {}).get("best_entry", "14:00 UTC"),  # Live best entry
                    "best_exit": latest_optimization.get("metadata", {}).get("best_exit", "21:00 UTC"),  # Live best exit
                    "timestamp": latest_optimization.get("timestamp"),  # Live timestamp
                }

            # No live optimizations available (neutral values, not fallback data)
            return {
                "confidence": DEFAULT_ERROR_CONFIDENCE,  # Neutral confidence (not fallback data)
                "best_entry": "14:00 UTC",  # Configuration default entry time (not fallback data)
                "best_exit": "21:00 UTC",  # Configuration default exit time (not fallback data)
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live time optimization for %s", symbol)
            return {
                "confidence": DEFAULT_ERROR_CONFIDENCE,  # Error state confidence (not fallback data)
                "best_entry": "14:00 UTC",  # Configuration default (not fallback data)
                "best_exit": "21:00 UTC",  # Configuration default (not fallback data)
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

    def _calculate_volatility(self, symbol: str) -> float:
        """
        Calculate live volatility for a symbol from price history (backend port 8000).

        Args:
            symbol: Live trading symbol

        Returns:
            Live volatility from price history, or neutral value if insufficient data (error state, not fallback data)
        """
        try:
            # Get recent live price history
            price_history = self.cache.get_price_history("aggregated", symbol, limit=PRICE_HISTORY_LIMIT)

            if not price_history or len(price_history) < MIN_PRICE_HISTORY_LENGTH:
                # Insufficient live price history (neutral volatility, not fallback data)
                return DEFAULT_ERROR_VOLATILITY

            # Calculate daily returns from live price history
            prices = [float(data["price"]) for data in price_history]  # Live prices
            returns = []

            for i in range(1, len(prices)):
                daily_return = (prices[i] - prices[i - 1]) / prices[i - 1]  # Calculate from live data
                returns.append(daily_return)

            # Calculate volatility from live returns
            volatility = float(np.std(returns) * np.sqrt(ANNUALIZATION_FACTOR))  # Annualized from live data

            return max(MIN_VOLATILITY_CLAMP, min(MAX_VOLATILITY_CLAMP, volatility))  # Clamp volatility

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to calculate live volatility for %s", symbol)
            return DEFAULT_ERROR_VOLATILITY  # Error state (not fallback data)

    def _calculate_risk_score(self, symbol: str) -> float:
        """
        Calculate live risk score for a symbol (backend port 8000).

        Args:
            symbol: Live trading symbol

        Returns:
            Live risk score, or neutral value if unavailable (error state, not fallback data)
        """
        try:
            # Get live volatility
            volatility = self._calculate_volatility(symbol)

            # Get live overlord decision
            overlord_decision = self._get_overlord_decision(symbol)

            # Calculate risk score based on live volatility and decision
            base_risk = volatility / NORMALIZATION_VOLATILITY  # Normalize to 5% volatility

            # Adjust risk based on live overlord decision (configuration defaults, not fallback data)
            decision_risk = {
                "BUY": 0.8,  # Lower risk for buy signals
                "SELL": 0.9,  # Higher risk for sell signals
                "HOLD": 1.0,  # Normal risk for hold
            }

            decision_multiplier = decision_risk.get(overlord_decision["decision"], 1.0)  # From live decision

            risk_score = base_risk * decision_multiplier  # Calculate from live data

            return max(MIN_RISK_SCORE_CLAMP, min(MAX_RISK_SCORE_CLAMP, risk_score))  # Clamp risk score

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to calculate live risk score for %s", symbol)
            return DEFAULT_ERROR_RISK_SCORE  # Error state (not fallback data)

    def _calculate_allocation_score(self, symbol: str) -> float:
        """
        Calculate live allocation score for a symbol (backend port 8000).

        Args:
            symbol: Live trading symbol

        Returns:
            Live allocation score, or neutral value if unavailable (error state, not fallback data)
        """
        try:
            # Get live confidence from signal engine
            signal_confidence = self._get_signal_confidence(symbol)

            # Get live overlord confidence
            overlord_decision = self._get_overlord_decision(symbol)
            overlord_confidence = overlord_decision.get("confidence", 0.0)  # Live confidence

            # Get live time optimization confidence
            time_optimization = self._get_time_optimization(symbol)
            time_confidence = time_optimization.get("confidence", 0.0)  # Live confidence

            # Calculate weighted confidence from live data (configuration weights, not fallback data)
            weighted_confidence = signal_confidence * self.confidence_weight + overlord_confidence * self.confidence_weight + time_confidence * (1 - self.confidence_weight * 2)

            # Get live risk score
            risk_score = self._calculate_risk_score(symbol)

            # Calculate allocation score from live data (higher confidence, lower risk = higher allocation)
            allocation_score = weighted_confidence * (1 - risk_score * 0.5)

            return max(0.0, min(1.0, allocation_score))  # Clamp allocation score

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to calculate live allocation score for %s", symbol)
            return DEFAULT_ERROR_CONFIDENCE  # Error state (not fallback data)

    def _apply_diversification_constraints(self, allocations: dict[str, float], portfolio_balance: float) -> dict[str, float]:
        """
        Apply diversification constraints to live allocations (backend port 8000).

        Args:
            allocations: Live allocation dictionary
            portfolio_balance: Live portfolio balance

        Returns:
            Adjusted allocations with diversification constraints applied
        """
        try:
            # Sort symbols by allocation score from live data
            sorted_symbols = sorted(allocations.items(), key=lambda x: x[1], reverse=True)

            # Apply maximum allocation per symbol constraints
            adjusted_allocations = {}
            remaining_balance = portfolio_balance  # Live balance

            for symbol, allocation in sorted_symbols:
                # Calculate maximum allowed allocation (configuration constraints, not fallback data)
                max_allocation = portfolio_balance * self.max_allocation_per_symbol
                min_allocation = portfolio_balance * self.min_allocation_per_symbol

                # Apply constraints to live allocation
                adjusted_allocation = max(min_allocation, min(max_allocation, allocation))

                # Ensure we don't exceed live portfolio balance
                adjusted_allocation = min(adjusted_allocation, remaining_balance)

                if adjusted_allocation > 0:
                    adjusted_allocations[symbol] = adjusted_allocation
                    remaining_balance -= adjusted_allocation

                if remaining_balance <= 0:
                    break
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to apply diversification constraints to live allocations")
            return allocations  # Return original allocations on error
        else:
            return adjusted_allocations

    def get_allocation_plan(self, portfolio_balance: float) -> dict[str, Any]:
        """
        Get optimal allocation plan for live portfolio (backend port 8000).

        Args:
            portfolio_balance: Live portfolio balance in USD

        Returns:
            Live allocation plan dictionary with allocations for all symbols
        """
        try:
            logger.info(
                "[CALCULATING] Calculating live allocation plan for $%.2f portfolio",
                portfolio_balance,
            )

            # Calculate live allocation scores for all symbols
            allocation_scores = {}
            for symbol in self.top_symbols:
                score = self._calculate_allocation_score(symbol)  # Get live score
                allocation_scores[symbol] = score

            # Convert live scores to dollar amounts
            total_score = sum(allocation_scores.values())
            if total_score > 0:
                # Distribute based on live scores
                allocations = {}
                for symbol, score in allocation_scores.items():
                    allocation = (score / total_score) * portfolio_balance  # Calculate from live data
                    allocations[symbol] = allocation
            else:
                # Equal distribution if no live scores (neutral allocation, not fallback data)
                equal_allocation = portfolio_balance / len(self.top_symbols)
                allocations = dict.fromkeys(self.top_symbols, equal_allocation)

            # Apply diversification constraints to live allocations
            final_allocations = self._apply_diversification_constraints(allocations, portfolio_balance)

            # Calculate allocation statistics from live data
            total_allocated = sum(final_allocations.values())
            allocation_percentage = (total_allocated / portfolio_balance) * 100 if portfolio_balance > 0 else 0.0

            # Create live allocation plan
            allocation_plan = {
                "portfolio_balance": portfolio_balance,  # Live balance
                "allocations": final_allocations,  # Live allocations
                "total_allocated": total_allocated,  # Live total
                "allocation_percentage": allocation_percentage,  # Live percentage
                "unallocated_balance": portfolio_balance - total_allocated,  # Live unallocated
                "diversification_score": len(final_allocations) / len(self.top_symbols),  # Live diversification
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

            # Store live allocation plan in cache
            plan_id = f"allocation_plan_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
            self.cache.store_signal(
                signal_id=plan_id,
                symbol="PORTFOLIO",
                signal_type="CAPITAL_ALLOCATION",
                confidence=allocation_percentage / 100.0,  # Live confidence
                strategy="risk_based_allocation",
                metadata=allocation_plan,
            )

            logger.info(
                "[OK] Live allocation plan complete: $%.2f allocated across %d symbols",
                total_allocated,
                len(final_allocations),
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live allocation plan")
            # Error state return (not fallback data)
            return {
                "portfolio_balance": portfolio_balance,
                "allocations": {},  # No allocations on error
                "total_allocated": 0.0,
                "allocation_percentage": 0.0,
                "unallocated_balance": portfolio_balance,
                "diversification_score": 0.0,
                "error": "Error calculating live allocation plan",
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

    def allocate_for_symbol(self, symbol: str, balance: float) -> dict[str, Any]:
        """
        Get live allocation recommendation for a specific symbol (backend port 8000).

        Args:
            symbol: Live trading symbol
            balance: Live balance available for allocation

        Returns:
            Live allocation recommendation dictionary
        """
        try:
            logger.info(
                "[CALCULATING] Calculating live allocation for %s with $%.2f",
                symbol,
                balance,
            )

            # Calculate live allocation score
            allocation_score = self._calculate_allocation_score(symbol)

            # Get live risk assessment
            risk_score = self._calculate_risk_score(symbol)

            # Get live overlord decision
            overlord_decision = self._get_overlord_decision(symbol)

            # Get live time optimization
            time_optimization = self._get_time_optimization(symbol)

            # Calculate recommended allocation from live data
            max_allocation = balance * self.max_allocation_per_symbol  # Configuration constraint
            recommended_allocation = balance * allocation_score  # From live score

            # Apply constraints to live allocation
            final_allocation = max(
                balance * self.min_allocation_per_symbol,  # Configuration minimum
                min(max_allocation, recommended_allocation),
            )

            # Create live allocation recommendation
            recommendation = {
                "symbol": symbol,  # Live symbol
                "balance": balance,  # Live balance
                "recommended_allocation": final_allocation,  # Live recommendation
                "allocation_percentage": ((final_allocation / balance) * 100 if balance > 0 else 0.0),  # Live percentage
                "allocation_score": allocation_score,  # Live score
                "risk_score": risk_score,  # Live risk
                "overlord_decision": overlord_decision,  # Live decision
                "time_optimization": time_optimization,  # Live optimization
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

            # Store live recommendation in cache
            recommendation_id = f"allocation_{symbol}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
            self.cache.store_signal(
                signal_id=recommendation_id,
                symbol=symbol,
                signal_type="SYMBOL_ALLOCATION",
                confidence=allocation_score,  # Live confidence
                strategy="risk_based_allocation",
                metadata=recommendation,
            )

            logger.info(
                "[OK] Live allocation recommendation: $%.2f (%.1f%%)",
                final_allocation,
                recommendation["allocation_percentage"],
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to allocate for live symbol %s", symbol)
            # Error state return (not fallback data)
            return {
                "symbol": symbol,
                "balance": balance,
                "recommended_allocation": 0.0,  # No allocation on error
                "allocation_percentage": 0.0,
                "allocation_score": 0.0,
                "risk_score": DEFAULT_ERROR_RISK_SCORE,  # Error state risk
                "error": "Error calculating live allocation",
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

    def get_allocation_history(self, limit: int = 10) -> list[dict[str, Any]]:
        """
        Get live capital allocation history (backend port 8000).

        Args:
            limit: Number of historical allocations to retrieve (configuration default, not fallback data)

        Returns:
            List of live allocation signals from cache
        """
        try:
            # Get recent live allocation signals from cache
            return self.cache.get_signals_by_type("CAPITAL_ALLOCATION", limit=limit)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live allocation history")
            return []  # Empty list on error (not fallback data)

    def get_engine_status(self) -> dict[str, Any]:
        """
        Get current live allocation engine status (backend port 8000).

        Returns:
            Dictionary with live engine status and configuration parameters
        """
        try:
            return {
                "service": "CapitalAllocationEngine",
                "status": "active",  # Live status
                "risk_parameters": {
                    "max_allocation_per_symbol": self.max_allocation_per_symbol,  # Configuration
                    "min_allocation_per_symbol": self.min_allocation_per_symbol,  # Configuration
                    "max_portfolio_risk": self.max_portfolio_risk,  # Configuration
                    "diversification_target": self.diversification_target,  # Configuration
                },
                "weighting_parameters": {
                    "confidence_weight": self.confidence_weight,  # Configuration
                    "volatility_weight": self.volatility_weight,  # Configuration
                    "diversification_weight": self.diversification_weight,  # Configuration
                },
                "volatility_thresholds": {
                    "low_volatility": self.low_volatility_threshold,  # Configuration
                    "high_volatility": self.high_volatility_threshold,  # Configuration
                },
                "monitored_symbols": self.top_symbols,  # Configuration
                "exchanges": self.exchanges,  # Configuration
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live engine status")
            return {"success": False, "error": "Error getting live engine status"}


# Global capital allocation engine instance
capital_allocation_engine = CapitalAllocationEngine()  # Initialize singleton for live operations


def get_capital_allocation_engine() -> CapitalAllocationEngine:
    """
    Get the global capital allocation engine instance (backend port 8000).

    Returns:
        Global capital allocation engine instance for live operations
    """
    return capital_allocation_engine


if __name__ == "__main__":
    # Test harness using live data (backend port 8000)
    engine = CapitalAllocationEngine()
    logger.info("[OK] CapitalAllocationEngine initialized: %s", engine)

    # Test live allocation plan
    plan = engine.get_allocation_plan(1000.0)  # Test with live portfolio balance
    logger.info("Live allocation plan: %s", plan)

    # Test live symbol allocation
    recommendation = engine.allocate_for_symbol("BTCUSDT", 1000.0)  # Test with live symbol and balance
    logger.info("Live symbol allocation: %s", recommendation)

    # Test live status
    status = engine.get_engine_status()
    logger.info("Live engine status: %s", status.get("status"))
