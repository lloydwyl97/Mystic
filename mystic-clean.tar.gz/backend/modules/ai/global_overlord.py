"""
Global Overlord Module - All Live Data, No Fallback/Hardcoded Data

Orchestrates AI decisions from multiple agents using weighted voting and confidence scoring
for Binance.US Top-10 spot symbols (backend port 8000).
All operations use live data:
- Signal collection: Collects live signals from SignalEngine and SelfReplicationEngine
- Agent signals: Generates signals from live agent population and live price data
- Weighted voting: Applies weighted voting across live signals
- All decisions use live data - no fallback/hardcoded data

Endpoint References:
- Backend API: Port 8000 (global overlord serves live operations)
- Canonical Cache: Live signals and price data from trading operations
- Signal Engine: Live signals from AI analysis
- Self-Replication Engine: Live agent population data
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any

from backend.modules.ai.self_replication_engine import SelfReplicationEngine
from backend.modules.ai.signal_engine import SignalEngine
from backend.services.canonical_cache import canonical_cache
from backend.services.confidence_normalizer import ConfidenceNormalizer

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

try:
    from backend.modules.market.binance_data_fetcher import _to_ccxt_symbol  # type: ignore[import-not-found]
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
    msg = f"Failed to import _to_ccxt_symbol from binance_data_fetcher: {e}"
    raise RuntimeError(msg) from e


logger = logging.getLogger(__name__)

# Configuration constants (not fallback data)
DEFAULT_ERROR_CONFIDENCE = 0.5  # Neutral confidence when live data unavailable (error state, not fallback)
COSMIC_NEUTRAL_VALUE = 1.0  # Neutral cosmic factor value (configuration default, not fallback data)
MIN_RSI_BUY = 30  # RSI threshold for BUY signal (configuration default)
MAX_RSI_SELL = 70  # RSI threshold for SELL signal (configuration default)
MIN_AGENTS_LIMIT = 10  # Maximum agents to process (configuration default)
PRICE_HISTORY_LIMIT = 50  # Number of price history points needed (configuration default)
RSI_PERIOD = 14  # RSI calculation period (configuration default)
EMA_SHORT_PERIOD = 20  # Short EMA period (configuration default)
EMA_LONG_PERIOD = 50  # Long EMA period (configuration default)


class CosmicPatternRecognizer:
    """
    Cosmic pattern recognizer for optional cosmic overlays (backend port 8000).

    Provides cosmic factors as configuration defaults for signal adjustment.
    All values are neutral configuration defaults, not fallback data.
    """

    def __init__(self) -> None:
        """Initialize cosmic pattern recognizer for live operations."""
        self.cache = canonical_cache  # Live cache for operations
        # Cosmic weights (configuration defaults, not fallback data)
        self.cosmic_weights: dict[str, float] = {
            "moon_phase": 0.1,
            "solar_activity": 0.05,
            "cosmic_rays": 0.03,
            "planetary_alignment": 0.02,
        }

    def get_cosmic_factors(self, symbol: str) -> dict[str, float]:
        """
        Return cosmic factors for live symbol (backend port 8000).

        Args:
            symbol: Live trading symbol

        Returns:
            Dictionary with cosmic factors (neutral configuration defaults, not fallback data)
        """
        try:
            # Return neutral cosmic factors (configuration defaults, not fallback data)
            return {
                "moon_phase": COSMIC_NEUTRAL_VALUE,  # Neutral value (configuration default)
                "solar_activity": COSMIC_NEUTRAL_VALUE,  # Neutral value (configuration default)
                "cosmic_rays": COSMIC_NEUTRAL_VALUE,  # Neutral value (configuration default)
                "planetary_alignment": COSMIC_NEUTRAL_VALUE,  # Neutral value (configuration default)
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get cosmic factors for live symbol %s", symbol)
            return {
                "moon_phase": COSMIC_NEUTRAL_VALUE,  # Error state (not fallback data)
                "solar_activity": COSMIC_NEUTRAL_VALUE,
                "cosmic_rays": COSMIC_NEUTRAL_VALUE,
                "planetary_alignment": COSMIC_NEUTRAL_VALUE,
            }

    def adjust_confidence(self, base_confidence: float, symbol: str) -> float:
        """
        Adjust confidence using a multiplicative blend of cosmic factors (backend port 8000).

        Args:
            base_confidence: Live base confidence from signals
            symbol: Live trading symbol

        Returns:
            Adjusted confidence from live base confidence and cosmic factors
        """
        try:
            cosmic_factors = self.get_cosmic_factors(symbol)  # Get cosmic factors
            adjustment = 1.0
            for factor, weight in self.cosmic_weights.items():
                adjustment *= (cosmic_factors.get(factor, COSMIC_NEUTRAL_VALUE) * weight) + (1.0 - weight)
            return max(0.0, min(1.0, base_confidence * adjustment))  # Adjust live confidence
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to adjust confidence for live symbol %s", symbol)
            return base_confidence  # Return original live confidence on error


class GlobalOverlord:
    """
    Orchestrates AI decisions from multiple agents using weighted voting and confidence scoring (backend port 8000).

    All operations use live data from SignalEngine, SelfReplicationEngine, and canonical cache.
    No fallback/hardcoded data.
    """

    def __init__(self) -> None:
        """
        Initialize Global Overlord for live operations.

        All initial values are configuration defaults or live state, not fallback data.
        """
        self.cache = canonical_cache  # Live cache for signals and price data
        self.signal_engine = SignalEngine()  # Live signal engine
        self.self_replication_engine = SelfReplicationEngine()  # Live self-replication engine

        # Decision weights for different sources (configuration defaults, not fallback data)
        self.signal_weights: dict[str, float] = {
            "signal_engine": 0.4,
            "self_replication_agents": 0.5,
            "cosmic_patterns": 0.1,
        }

        # Confidence thresholds (configuration defaults, not fallback data)
        self.min_confidence = 0.6
        self.high_confidence = 0.8

        # Voting parameters (configuration defaults, not fallback data)
        self.min_agents_for_decision = 3
        self.consensus_threshold = 0.7  # as fraction

        # Optional cosmic overlay
        try:
            self.cosmic_recognizer = CosmicPatternRecognizer()
            self.cosmic_available = True
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.warning("Cosmic pattern recognizer not available for live operations")
            self.cosmic_available = False

        logger.info("GlobalOverlord initialized for live operations")

    def _collect_signal_engine_signals(self, _exchange: str, symbol: str) -> list[dict[str, Any]]:
        """
        Collect live signals from the signal engine (backend port 8000).

        Args:
            exchange: Live exchange ID
            symbol: Live trading symbol

        Returns:
            List of live signals from SignalEngine
        """
        try:
            signals: list[dict[str, Any]] = []

            # Prefer SignalEngine API if present (live signals)
            signal_records: list[dict[str, Any]] = []
            try:
                if hasattr(self.signal_engine, "get_recent_signals"):
                    signal_records = self.signal_engine.get_recent_signals(symbol, limit=5)  # Get live signals  # type: ignore[attr-defined]
                else:
                    # Get live signals from cache (not fallback, this is live data source)
                    cached = self.cache.get_signals(symbol=symbol, limit=5)  # Live signals from cache
                    # Expect fields: signal_type, confidence, metadata
                    signal_records = [
                        {
                            "signal_type": s.get("signal_type", "HOLD"),  # Live signal type
                            "confidence": ConfidenceNormalizer.normalize(float(s.get("confidence", DEFAULT_ERROR_CONFIDENCE) or DEFAULT_ERROR_CONFIDENCE)),  # Live confidence canonical 0-1
                            "metadata": s.get("metadata", {}),  # Live metadata
                        }
                        for s in cached
                    ]
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                # Error state: neutral HOLD (not fallback data)
                signal_records = [{"signal_type": "HOLD", "confidence": DEFAULT_ERROR_CONFIDENCE, "metadata": {}}]

            for s in signal_records:
                base_conf = ConfidenceNormalizer.normalize(float(s.get("confidence", 0.0) or 0.0))  # Live base confidence canonical 0-1
                adjusted_conf = self.cosmic_recognizer.adjust_confidence(base_conf, symbol) if self.cosmic_available else base_conf
                signals.append(
                    {
                        "source": "signal_engine",  # Live source
                        "signal": s.get("signal_type", "HOLD"),  # Live signal
                        "confidence": adjusted_conf,  # Live adjusted confidence
                        "weight": self.signal_weights["signal_engine"],  # Configuration weight
                        "metadata": s.get("metadata", {}),  # Live metadata
                    },
                )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to collect live signal engine signals for %s", symbol)
            return []  # Empty list on error (not fallback data)
        else:
            return signals

    def _collect_agent_data(self, _exchange: str, symbol: str) -> list[dict[str, Any]]:
        """
        Collect live agent data from the self-replication engine's agent population (backend port 8000).

        Args:
            exchange: Live exchange ID
            symbol: Live trading symbol

        Returns:
            List of live agent data dictionaries for signal generation
        """
        try:
            agent_data_list: list[dict[str, Any]] = []
            # Build from live available population stats
            population = self.self_replication_engine.get_agent_population()  # Get live population
            if not population or not population.get("success"):
                return agent_data_list  # No live population (empty list, not fallback data)

            agents = population.get("agents", [])  # Live agents
            for agent in agents[:MIN_AGENTS_LIMIT]:  # Process up to limit
                agent_id = agent.get("agent_id", "unknown")
                perf = agent.get("performance", {}) or {}
                # performance_score proxy: blend fitness and win_rate from live data
                fitness = float(agent.get("fitness", 0.0) or 0.0)  # Live fitness
                win_rate = float(perf.get("win_rate", 0.0) or 0.0)  # Live win rate
                performance_score = max(0.0, min(1.0, 0.7 * fitness + 0.3 * win_rate))  # Calculate from live data

                agent_data_list.append(
                    {
                        "agent_id": agent_id,
                        "performance_score": performance_score,  # Live performance score
                    }
                )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to collect live agent data for %s", symbol)
            return []  # Empty list on error (not fallback data)
        else:
            return agent_data_list

    async def _generate_agent_signal(self, agent_data: dict[str, Any], symbol: str) -> dict[str, Any] | None:
        """
        Create an agent signal from lightweight TA over live prices (backend port 8000).

        Args:
            agent_data: Live agent data dictionary
            symbol: Live trading symbol

        Returns:
            Dictionary with live agent signal, or None if insufficient data
        """
        try:
            # Get live prices from cache (CRITICAL: must use live data, not hardcoded)
            try:
                price_history = await self.cache.get_price_history(exchange=EXCHANGE_ID, symbol=symbol, limit=PRICE_HISTORY_LIMIT)
                if not price_history or len(price_history) < PRICE_HISTORY_LIMIT:
                    # Insufficient live price data
                    logger.warning("Insufficient live price data for %s: got %d points, need %d", symbol, len(price_history) if price_history else 0, PRICE_HISTORY_LIMIT)
                    return None
                # Extract prices from live price history
                prices = [float(data.get("price", 0.0)) for data in price_history if data.get("price") is not None]
                if not prices or len(prices) < PRICE_HISTORY_LIMIT:
                    # Insufficient live prices extracted
                    return None
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.exception("Failed to get live price history for %s", symbol)
                return None  # Cannot generate signal without live prices

            rsi_values = self._calculate_rsi(prices)  # Calculate from live prices
            ema_20 = self._calculate_ema(prices, EMA_SHORT_PERIOD)  # Calculate from live prices
            ema_50 = self._calculate_ema(prices, EMA_LONG_PERIOD)  # Calculate from live prices
            if not rsi_values or not ema_20 or not ema_50:
                return None  # Insufficient live indicators

            current_rsi = rsi_values[-1]  # Latest RSI from live data
            current_ema_20 = ema_20[-1]  # Latest EMA20 from live data
            current_ema_50 = ema_50[-1]  # Latest EMA50 from live data

            signal = "HOLD"  # Default signal (configuration value)
            confidence = DEFAULT_ERROR_CONFIDENCE  # Default confidence (error state)

            # Generate signal from live RSI data
            if current_rsi < MIN_RSI_BUY:
                signal = "BUY"
                confidence = 0.7  # Configuration confidence
            elif current_rsi > MAX_RSI_SELL:
                signal = "SELL"
                confidence = 0.7  # Configuration confidence

            # Adjust signal from live EMA data
            if current_ema_20 > current_ema_50:
                if signal == "BUY":
                    confidence = min(1.0, confidence + 0.1)  # Increase confidence
                elif signal == "HOLD":
                    signal = "BUY"
                    confidence = 0.6  # Configuration confidence
            elif current_ema_20 < current_ema_50:
                if signal == "SELL":
                    confidence = min(1.0, confidence + 0.1)  # Increase confidence
                elif signal == "HOLD":
                    signal = "SELL"
                    confidence = 0.6  # Configuration confidence

            raw_agent_conf = float(agent_data.get("performance_score", DEFAULT_ERROR_CONFIDENCE) or DEFAULT_ERROR_CONFIDENCE)
            agent_confidence = ConfidenceNormalizer.normalize(raw_agent_conf)  # Live agent confidence
            confidence = max(0.0, min(1.0, (confidence + agent_confidence) / 2.0))  # Blend from live data

            return {
                "source": f"agent_{agent_data.get('agent_id', 'unknown')}",  # Live agent ID
                "signal": signal,  # Live signal
                "confidence": confidence,  # Live confidence
                "weight": self.signal_weights["self_replication_agents"],  # Configuration weight
                "metadata": {
                    "agent_id": agent_data.get("agent_id"),  # Live agent ID
                    "performance_score": agent_confidence,  # Live performance score
                    "rsi": current_rsi,  # Live RSI
                    "ema_20": current_ema_20,  # Live EMA20
                    "ema_50": current_ema_50,  # Live EMA50
                },
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to generate live agent signal for %s", symbol)
            return None

    def _calculate_rsi(self, prices: list[float], period: int = RSI_PERIOD) -> list[float]:
        """
        Compute RSI from live prices (backend port 8000).

        Args:
            prices: Live price list
            period: RSI period (configuration default, not fallback data)

        Returns:
            List of RSI values calculated from live prices
        """
        try:
            if len(prices) < period + 1:
                return []  # Insufficient live data (empty list, not fallback data)
            gains: list[float] = []
            losses: list[float] = []
            for i in range(1, len(prices)):
                change = prices[i] - prices[i - 1]  # Calculate from live prices
                gains.append(max(change, 0.0))
                losses.append(max(-change, 0.0))

            rsi_values: list[float] = []
            for i in range(period, len(prices)):
                avg_gain = sum(gains[i - period : i]) / period  # From live data
                avg_loss = sum(losses[i - period : i]) / period  # From live data
                if avg_loss == 0:
                    rsi = 100.0
                else:
                    rs = avg_gain / avg_loss
                    rsi = 100.0 - (100.0 / (1.0 + rs))
                rsi_values.append(rsi)  # Calculate from live data
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to calculate RSI from live prices")
            return []  # Error state (empty list, not fallback data)
        else:
            return rsi_values

    def _calculate_ema(self, prices: list[float], period: int) -> list[float]:
        """
        Compute EMA from live prices (backend port 8000).

        Args:
            prices: Live price list
            period: EMA period (configuration default, not fallback data)

        Returns:
            List of EMA values calculated from live prices
        """
        try:
            if len(prices) < period:
                return []  # Insufficient live data (empty list, not fallback data)
            ema_values: list[float] = []
            multiplier = 2.0 / (period + 1.0)
            sma = sum(prices[:period]) / period  # Initial SMA from live prices
            ema_values.append(sma)
            for i in range(period, len(prices)):
                ema = (prices[i] * multiplier) + (ema_values[-1] * (1.0 - multiplier))  # Calculate from live prices
                ema_values.append(ema)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to calculate EMA from live prices")
            return []  # Error state (empty list, not fallback data)
        else:
            return ema_values

    def _apply_weighted_voting(self, signals: list[dict[str, Any]]) -> dict[str, Any]:
        """
        Apply weighted voting across live signals (backend port 8000).

        Args:
            signals: List of live signals to vote on

        Returns:
            Dictionary with voting result from live signals
        """
        try:
            if not signals:
                return {
                    "decision": "HOLD",  # No live signals (neutral decision, not fallback data)
                    "confidence": 0.0,  # No confidence (error state, not fallback data)
                    "source_agents": [],
                    "reason": "No live signals available",
                    "vote_breakdown": {
                        "buy_percentage": 0.0,
                        "sell_percentage": 0.0,
                        "hold_percentage": 100.0,
                        "total_agents": 0,
                    },
                }

            buy_votes = 0.0
            sell_votes = 0.0
            hold_votes = 0.0
            total_weight = 0.0
            source_agents: list[dict[str, Any]] = []

            for s in signals:  # Process live signals
                weight = float(s.get("weight", 1.0) or 1.0)  # Signal weight
                total_weight += weight
                sig = s.get("signal", "HOLD")  # Live signal
                if sig == "BUY":
                    buy_votes += weight
                elif sig == "SELL":
                    sell_votes += weight
                else:
                    hold_votes += weight
                source_agents.append(
                    {
                        "source": s.get("source"),  # Live source
                        "signal": sig,  # Live signal
                        "confidence": ConfidenceNormalizer.normalize(float(s.get("confidence", 0.0) or 0.0)),  # Live confidence canonical 0-1
                        "weight": weight,
                        "metadata": s.get("metadata", {}),  # Live metadata
                    },
                )

            if total_weight > 0.0:
                buy_pct = (buy_votes / total_weight) * 100.0  # Calculate from live votes
                sell_pct = (sell_votes / total_weight) * 100.0  # Calculate from live votes
                hold_pct = (hold_votes / total_weight) * 100.0  # Calculate from live votes
            else:
                buy_pct = sell_pct = 0.0
                hold_pct = 100.0

            decision = "HOLD"  # Default decision
            top_pct = max(buy_pct, sell_pct, hold_pct)
            if top_pct == buy_pct:
                decision = "BUY"
            elif top_pct == sell_pct:
                decision = "SELL"
            else:
                decision = "HOLD"

            if len(signals) < self.min_agents_for_decision or (top_pct / 100.0) < self.consensus_threshold:
                decision = "HOLD"  # Insufficient consensus from live signals
                top_pct = 0.0

            return {
                "decision": decision,  # Live decision
                "confidence": top_pct,  # Live confidence percentage 0..100
                "source_agents": source_agents,  # Live source agents
                "vote_breakdown": {
                    "buy_percentage": buy_pct,  # Live buy percentage
                    "sell_percentage": sell_pct,  # Live sell percentage
                    "hold_percentage": hold_pct,  # Live hold percentage
                    "total_agents": len(signals),  # Live total agents
                },
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to apply weighted voting on live signals")
            return {
                "decision": "HOLD",  # Error state decision (not fallback data)
                "confidence": 0.0,  # Error state confidence (not fallback data)
                "source_agents": [],
                "error": "Error processing live signals",
            }

    async def decide_trade(self, exchange: str, symbol: str) -> dict[str, Any]:
        """
        Make a final decision for symbol using weighted voting on live signals (backend port 8000).

        Args:
            exchange: Live exchange ID
            symbol: Live trading symbol

        Returns:
            Dictionary with live final decision and confidence
        """
        try:
            logger.info("GlobalOverlord deciding for live symbol %s on %s", symbol, exchange)

            se_signals = self._collect_signal_engine_signals(exchange, symbol)  # Get live signal engine signals
            agent_data_list = self._collect_agent_data(exchange, symbol)  # Get live agent data

            # Generate agent signals with live price data (async operation)
            agent_signals = []
            for agent_data in agent_data_list:
                agent_signal = await self._generate_agent_signal(agent_data, symbol)
                if agent_signal:
                    agent_signals.append(agent_signal)

            all_signals = se_signals + agent_signals  # Combine live signals

            decision_result = self._apply_weighted_voting(all_signals)  # Vote on live signals

            decision_payload = {
                "exchange": exchange,  # Live exchange ID
                "symbol": symbol,  # Live symbol
                "decision": decision_result.get("decision", "HOLD"),  # Live decision
                "confidence": float(decision_result.get("confidence", 0.0)) / 100.0,  # Normalize 0..1
                "source_agents": decision_result.get("source_agents", []),  # Live source agents
                "vote_breakdown": decision_result.get("vote_breakdown", {}),  # Live vote breakdown
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
                "cosmic_available": self.cosmic_available,
            }

            decision_id = f"overlord_{symbol}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
            self.cache.store_signal(
                signal_id=decision_id,
                symbol=symbol,  # Live symbol
                signal_type="OVERLORD_DECISION",
                confidence=decision_payload["confidence"],  # Live confidence
                strategy="weighted_voting",
                metadata=decision_payload,
            )

            logger.info(
                "Overlord decision for live symbol %s: %s at %.1f%% confidence",
                symbol,
                decision_payload["decision"],
                decision_result.get("confidence", 0.0),
            )
            return decision_payload
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to decide trade for live symbol %s", symbol)
            return {
                "exchange": exchange,
                "symbol": symbol,
                "decision": "HOLD",  # Error state decision (not fallback data)
                "confidence": 0.0,  # Error state confidence (not fallback data)
                "source_agents": [],
                "error": "Error making live decision",
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

    def get_decision_history(self, symbol: str, limit: int = 10) -> list[dict[str, Any]]:
        """
        Fetch recent live overlord decisions from cache (backend port 8000).

        Args:
            symbol: Live trading symbol
            limit: Number of decisions to retrieve (configuration default, not fallback data)

        Returns:
            List of live decisions from cache
        """
        try:
            signals = self.cache.get_signals_by_type("OVERLORD_DECISION", limit=limit)  # Get live decisions
            return [s for s in signals if s.get("symbol") == symbol]  # Filter by live symbol
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live decision history for %s", symbol)
            return []  # Empty list on error (not fallback data)

    def get_consensus_metrics(self) -> dict[str, Any]:
        """
        Aggregate consensus metrics from recent live decisions (backend port 8000).

        Returns:
            Dictionary with consensus metrics from live decisions
        """
        try:
            recent = self.cache.get_signals_by_type("OVERLORD_DECISION", limit=100)  # Get live recent decisions
            if not recent:
                return {
                    "total_decisions": 0,
                    "consensus_rate": 0.0,  # No decisions (0.0, not fallback data)
                    "average_confidence": 0.0,  # No decisions (0.0, not fallback data)
                    "decision_distribution": {},
                    "recent_decisions": [],
                }

            total = len(recent)  # Count of live decisions
            # confidences stored normalized 0..1 in metadata
            confs = [float(d.get("metadata", {}).get("confidence", 0.0) or 0.0) for d in recent]  # Live confidences
            avg_conf = sum(confs) / total if total > 0 else 0.0  # Average from live data

            consensus = [c for c in confs if c >= self.consensus_threshold]  # Filter from live data
            consensus_rate = (len(consensus) / total) * 100.0 if total > 0 else 0.0  # Calculate from live data

            dist: dict[str, int] = {}
            for d in recent:  # Process live decisions
                dtype = d.get("metadata", {}).get("decision", "UNKNOWN")  # Live decision type
                dist[dtype] = dist.get(dtype, 0) + 1

            return {
                "total_decisions": total,  # Live total
                "consensus_rate": consensus_rate,  # Live consensus rate
                "average_confidence": avg_conf,  # Live average confidence
                "decision_distribution": dist,  # Live distribution
                "recent_decisions": recent[:10],  # Live recent decisions
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to compute consensus metrics from live decisions")
            return {
                "total_decisions": 0,
                "consensus_rate": 0.0,  # Error state (not fallback data)
                "average_confidence": 0.0,  # Error state (not fallback data)
                "decision_distribution": {},
                "recent_decisions": [],
            }

    def get_overlord_status(self) -> dict[str, Any]:
        """
        Return active configuration and health for live operations (backend port 8000).

        Returns:
            Dictionary with live overlord status and configuration
        """
        try:
            return {
                "service": "GlobalOverlord",
                "status": "active",  # Live status
                "signal_weights": dict(self.signal_weights),  # Configuration weights
                "confidence_thresholds": {
                    "min_confidence": self.min_confidence,  # Configuration threshold
                    "high_confidence": self.high_confidence,  # Configuration threshold
                },
                "voting_parameters": {
                    "min_agents_for_decision": self.min_agents_for_decision,  # Configuration parameter
                    "consensus_threshold": self.consensus_threshold,  # Configuration parameter
                },
                "cosmic_available": self.cosmic_available,
                "components": {
                    "signal_engine": "active",  # Live component
                    "self_replication_engine": "active",  # Live component
                    "persistent_cache": "active",  # Live component
                },
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live overlord status")
            return {"success": False, "error": "Error getting live overlord status"}


# Global overlord instance
global_overlord = GlobalOverlord()  # Initialize singleton for live operations


def get_global_overlord() -> GlobalOverlord:
    """
    Return the global overlord instance (backend port 8000).

    Returns:
        Global overlord instance for live operations
    """
    return global_overlord


if __name__ == "__main__":
    # Simple smoke test using live data (backend port 8000)
    overlord = GlobalOverlord()
    logger.info("GlobalOverlord initialized: %s", overlord)

    test_symbol = _to_ccxt_symbol("BTC", "USDT")
    decision = asyncio.run(overlord.decide_trade(EXCHANGE_ID, test_symbol))  # Run async decision
    logger.info("Overlord decision: %s", decision)

    status = overlord.get_overlord_status()
    logger.info("Overlord status: %s", status.get("status"))
    logger.info("Cosmic available: %s", status.get("cosmic_available"))
