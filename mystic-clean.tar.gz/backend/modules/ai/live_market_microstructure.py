"""
Live Market Microstructure Analyzer Module - All Live Data, No Fallback/Hardcoded Data

Analyzes live order book depth, bid-ask spreads, and market impact for optimal entry points
for Binance.US Top-10 spot symbols (backend port 8000).
All operations use live data:
- Order book depth: Analyzes live order book data from Binance.US API
- Market impact: Estimates impact using live order book depth
- Entry points: Determines optimal entry points from live microstructure
- All calculations use live data - no fallback/hardcoded data

Endpoint References:
- Backend API: Port 8000 (microstructure analyzer serves live operations)
- Binance.US API: Live order book data via LiveMarketDataService
- Redis: Live caching of order book analysis (localhost:6379)
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any

from backend.config.redis_config import get_shared_redis_async

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

try:
    pass  # type: ignore[import-not-found]
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
    msg = f"Failed to import _to_ccxt_symbol from binance_data_fetcher: {e}"
    raise RuntimeError(msg) from e

logger = logging.getLogger(__name__)

# Lazy imports for optional dependencies
try:
    from backend.services.live_market_data import live_market_data_service
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    live_market_data_service = None  # type: ignore[assignment]

# Configuration constants (not fallback data)
DEFAULT_ERROR_SPREAD = 0.001  # Neutral spread when live data unavailable (error state, not fallback)
DEFAULT_ERROR_CONFIDENCE = 0.5  # Neutral confidence when live data unavailable (error state, not fallback)
DEFAULT_SPREAD_THRESHOLD = 0.002  # Max acceptable spread ratio (0.2%)
DEPTH_NORMALIZATION_FACTOR = 100_000.0  # Depth normalization factor for liquidity score
IMPACT_MULTIPLIER = 10.0  # Impact ratio multiplier
MIN_LIQUIDITY_SCORE_THRESHOLD = 0.3  # Minimum liquidity score for safe entry
ORDER_BOOK_CACHE_TTL = 30  # Cache TTL in seconds


class LiveMarketMicrostructureAnalyzer:
    """
    Analyzes live market microstructure for optimal trading entry points (backend port 8000).

    All operations use live order book data from Binance.US API.
    No fallback/hardcoded data.
    """

    def __init__(self) -> None:
        """
        Initialize live market microstructure analyzer for live operations.

        All initial values are configuration defaults or live state, not fallback data.
        """
        self.redis_client: Any = None  # Live Redis client
        self.order_book_cache: dict[str, Any] = {}  # Live order book cache
        self.spread_cache: dict[str, Any] = {}  # Live spread cache

        # Microstructure thresholds (configuration defaults, not fallback data)
        self.min_liquidity_threshold = 10_000.0  # Minimum combined depth (USD-equiv) to consider safe
        self.max_spread_threshold = DEFAULT_SPREAD_THRESHOLD  # Max acceptable spread ratio (0.2%)
        self.volume_impact_threshold = 0.01  # Max order-size/total-depth ratio (1%)

        logger.info("LiveMarketMicrostructureAnalyzer initialized for live operations")

    async def _get_redis(self) -> Any:
        """
        Get Redis client for live caching (backend port 8000).

        Returns:
            Redis client instance, or None if unavailable (error state, not fallback data)
        """
        if self.redis_client is None:
            # All Live Data, No Fallback/Hardcoded Data - Use shared async Redis pool
            try:
                self.redis_client = get_shared_redis_async()
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.warning("Live Redis not available for caching")
                self.redis_client = None
        return self.redis_client

    async def _get_live_order_book(self, symbol: str) -> dict[str, Any] | None:
        """
        Get live order book data from Binance.US API (backend port 8000).

        Args:
            symbol: Live trading symbol

        Returns:
            Live order book dictionary with bids and asks, or None if unavailable
        """
        try:
            if live_market_data_service is None:
                logger.warning("Live market data service not available for %s", symbol)
                return None

            # Get live order book from Binance.US API
            order_book = await live_market_data_service.get_order_book(symbol, limit=50)  # Get live depth

            if not order_book or not order_book.get("bids") or not order_book.get("asks"):
                logger.warning("No live order book data available for %s", symbol)
                result = None
            else:
                result = order_book  # Return live order book
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live order book for %s", symbol)
            return None  # Error state (None, not fallback data)
        else:
            return result

    def _calculate_depth_from_order_book(self, order_book: dict[str, Any]) -> dict[str, float]:
        """
        Calculate depth metrics from live order book data (backend port 8000).

        Args:
            order_book: Live order book dictionary with bids and asks

        Returns:
            Dictionary with calculated depth metrics from live data
        """
        try:
            bids = order_book.get("bids", [])  # Live bids
            asks = order_book.get("asks", [])  # Live asks

            # Calculate bid depth from live order book (price * quantity)
            sum(float(price) * float(qty) for price, qty in bids[:20] if price and qty)

            # Calculate ask depth from live order book (price * quantity)
            sum(float(price) * float(qty) for price, qty in asks[:20] if price and qty)

            # Calculate spread from live order book
            best_bid = float(bids[0][0]) if bids and bids[0] else 0.0  # Live best bid
            best_ask = float(asks[0][0]) if asks and asks[0] else 0.0  # Live best ask

            (best_ask - best_bid) / best_bid if best_bid > 0 and best_ask > 0 else DEFAULT_ERROR_SPREAD
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to calculate depth from live order book")
            return {
                "bid_depth": 0.0,  # Error state (not fallback data)
                "ask_depth": 0.0,  # Error state (not fallback data)
                "spread_ratio": DEFAULT_ERROR_SPREAD,  # Error state (not fallback data)
            }

    async def analyze_order_book_depth(self, symbol: str) -> dict[str, Any]:
        """
        Analyze live order book depth for liquidity assessment (backend port 8000).

        Args:
            symbol: Live trading symbol

        Returns:
            Dictionary with live order book depth analysis
        """
        try:
            cache_key = f"orderbook:{symbol.upper()}"
            redis_client = await self._get_redis()

            # Check live Redis cache first
            result = None
            if redis_client:
                cached = await redis_client.get(cache_key)
                if cached:
                    try:
                        cached_data = json.loads(cached)
                        logger.debug("Using cached live order book analysis for %s", symbol)
                        result = cached_data
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        logger.warning("Failed to parse cached order book for %s", symbol)

            # Get live order book data from Binance.US API if not cached
            if result is None:
                order_book = await self._get_live_order_book(symbol)

                if not order_book:
                    # No live order book data available (error state, not fallback data)
                    result = {
                        "symbol": symbol.upper(),
                        "bid_depth": 0.0,  # Error state (not fallback data)
                        "ask_depth": 0.0,  # Error state (not fallback data)
                        "total_depth": 0.0,  # Error state (not fallback data)
                        "bid_ask_spread": DEFAULT_ERROR_SPREAD,  # Error state (not fallback data)
                        "liquidity_score": 0.0,  # Error state (not fallback data)
                        "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
                        "source": "order_book_analysis",
                        "error": "No live order book data available",
                    }
                else:
                    # Calculate depth metrics from live order book
                    depth_metrics = self._calculate_depth_from_order_book(order_book)

                    bid_depth = depth_metrics["bid_depth"]  # Live bid depth
                    ask_depth = depth_metrics["ask_depth"]  # Live ask depth
                    spread_ratio = depth_metrics["spread_ratio"]  # Live spread ratio

                    total_depth = bid_depth + ask_depth  # Calculate from live data
                    liquidity_score = min(1.0, total_depth / DEPTH_NORMALIZATION_FACTOR)  # Calculate from live data

                    result = {
                        "symbol": symbol.upper(),  # Live symbol
                        "bid_depth": float(bid_depth),  # Live bid depth
                        "ask_depth": float(ask_depth),  # Live ask depth
                        "total_depth": float(total_depth),  # Live total depth
                        "bid_ask_spread": float(spread_ratio),  # Live spread ratio
                        "liquidity_score": float(liquidity_score),  # Live liquidity score
                        "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
                        "source": "order_book_analysis",  # Live source
                    }

                    # Cache live result in Redis
                    if redis_client:
                        await redis_client.setex(cache_key, ORDER_BOOK_CACHE_TTL, json.dumps(result))  # Cache live analysis
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error analyzing live order book depth for %s", symbol)
            return {
                "symbol": symbol.upper(),
                "bid_depth": 0.0,  # Error state (not fallback data)
                "ask_depth": 0.0,  # Error state (not fallback data)
                "total_depth": 0.0,  # Error state (not fallback data)
                "bid_ask_spread": DEFAULT_ERROR_SPREAD,  # Error state (not fallback data)
                "liquidity_score": 0.0,  # Error state (not fallback data)
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
                "source": "order_book_analysis",
                "error": "Error analyzing live order book",
            }

    async def analyze_market_impact(self, symbol: str, order_size: float) -> dict[str, Any]:
        """
        Estimate potential market impact given an order_size using live order book (backend port 8000).

        Args:
            symbol: Live trading symbol
            order_size: Order size in USD-equivalent

        Returns:
            Dictionary with live market impact analysis
        """
        try:
            order_book = await self.analyze_order_book_depth(symbol)  # Get live order book analysis
            total_depth = float(order_book.get("total_depth", 0.0))  # Live total depth
            liquidity_score = float(order_book.get("liquidity_score", 0.0))  # Live liquidity score

            if total_depth > 0.0:
                impact_ratio = float(order_size) / total_depth  # Calculate from live data
                impact_score = min(1.0, impact_ratio * IMPACT_MULTIPLIER)  # Calculate from live data
            else:
                impact_ratio = 1.0  # Max impact when no live depth (error state, not fallback data)
                impact_score = 1.0  # Max impact when no live depth (error state, not fallback data)

            is_safe = impact_ratio < self.volume_impact_threshold and liquidity_score > MIN_LIQUIDITY_SCORE_THRESHOLD and total_depth > self.min_liquidity_threshold  # Evaluate from live data

            return {
                "symbol": symbol.upper(),  # Live symbol
                "order_size": float(order_size),  # Live order size
                "total_depth": float(total_depth),  # Live total depth
                "impact_ratio": float(impact_ratio),  # Live impact ratio
                "impact_score": float(impact_score),  # Live impact score
                "is_safe": bool(is_safe),  # Live safety assessment
                "liquidity_score": float(liquidity_score),  # Live liquidity score
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
                "source": "market_impact_analysis",  # Live source
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error analyzing live market impact for %s", symbol)
            return {
                "symbol": symbol.upper(),
                "order_size": float(order_size),
                "total_depth": 0.0,  # Error state (not fallback data)
                "impact_ratio": 1.0,  # Error state (not fallback data)
                "impact_score": 1.0,  # Error state (not fallback data)
                "is_safe": False,  # Error state (not fallback data)
                "liquidity_score": 0.0,  # Error state (not fallback data)
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
                "source": "market_impact_analysis",
                "error": "Error analyzing live market impact",
            }

    async def get_optimal_entry_point(self, symbol: str, signal_direction: str) -> dict[str, Any]:
        """
        Choose an entry side and assess if conditions are optimal from live order book (backend port 8000).

        Args:
            symbol: Live trading symbol
            signal_direction: Live signal direction ("BUY", "SELL", "HOLD")

        Returns:
            Dictionary with live optimal entry point analysis
        """
        try:
            order_book = await self.analyze_order_book_depth(symbol)  # Get live order book analysis
            bid_depth = float(order_book.get("bid_depth", 0.0))  # Live bid depth
            ask_depth = float(order_book.get("ask_depth", 0.0))  # Live ask depth
            spread = float(order_book.get("bid_ask_spread", DEFAULT_ERROR_SPREAD))  # Live spread
            liquidity_score = float(order_book.get("liquidity_score", 0.0))  # Live liquidity score

            direction = str(signal_direction).upper()  # Live direction
            if direction == "BUY":
                entry_side = "bid"  # Buy at bid from live order book
                entry_depth = bid_depth  # Live bid depth
                entry_advantage = "buying_at_bid_cheaper"
            elif direction == "SELL":
                entry_side = "ask"  # Sell at ask from live order book
                entry_depth = ask_depth  # Live ask depth
                entry_advantage = "selling_at_ask_higher"
            else:
                return {
                    "symbol": symbol.upper(),
                    "signal_direction": direction,  # Live direction
                    "entry_side": "none",
                    "entry_depth": 0.0,  # No entry (not fallback data)
                    "spread": spread,  # Live spread
                    "liquidity_score": liquidity_score,  # Live liquidity score
                    "is_optimal": False,  # No entry (not fallback data)
                    "reason": "HOLD signal - no entry point",
                    "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
                }

            is_optimal = liquidity_score > MIN_LIQUIDITY_SCORE_THRESHOLD and spread < self.max_spread_threshold and entry_depth > self.min_liquidity_threshold  # Evaluate from live data

            return {
                "symbol": symbol.upper(),  # Live symbol
                "signal_direction": direction,  # Live direction
                "entry_side": entry_side,  # Live entry side
                "entry_depth": float(entry_depth),  # Live entry depth
                "spread": float(spread),  # Live spread
                "liquidity_score": float(liquidity_score),  # Live liquidity score
                "is_optimal": bool(is_optimal),  # Live optimal assessment
                "entry_advantage": entry_advantage,
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error getting live optimal entry point for %s", symbol)
            return {
                "symbol": symbol.upper(),
                "signal_direction": str(signal_direction).upper(),
                "entry_side": "none",
                "entry_depth": 0.0,  # Error state (not fallback data)
                "spread": DEFAULT_ERROR_SPREAD,  # Error state (not fallback data)
                "liquidity_score": 0.0,  # Error state (not fallback data)
                "is_optimal": False,  # Error state (not fallback data)
                "reason": "Error analyzing live entry point",
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

    async def enhance_autobuy_signal(self, symbol: str, base_signal: dict[str, Any]) -> dict[str, Any]:
        """
        Augment an existing signal with live microstructure insights for execution (backend port 8000).

        Args:
            symbol: Live trading symbol
            base_signal: Live base signal dictionary

        Returns:
            Enhanced signal dictionary with live microstructure analysis
        """
        try:
            direction = str(base_signal.get("signal", "HOLD")).upper()  # Live direction
            entry_analysis = await self.get_optimal_entry_point(symbol, direction)  # Get live entry analysis

            order_size = float(base_signal.get("quantity", 100.0))  # Live order size (default if missing, not fallback)
            impact_analysis = await self.analyze_market_impact(symbol, order_size)  # Get live impact analysis

            enhanced = dict(base_signal)  # Start with live base signal
            enhanced["microstructure"] = {
                "entry_side": entry_analysis.get("entry_side"),  # Live entry side
                "entry_depth": entry_analysis.get("entry_depth"),  # Live entry depth
                "spread": entry_analysis.get("spread"),  # Live spread
                "liquidity_score": entry_analysis.get("liquidity_score"),  # Live liquidity score
                "is_optimal": entry_analysis.get("is_optimal"),  # Live optimal assessment
                "market_impact": impact_analysis.get("impact_score"),  # Live impact score
                "is_safe": impact_analysis.get("is_safe"),  # Live safety assessment
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

            raw_conf = float(enhanced.get("confidence", DEFAULT_ERROR_CONFIDENCE) or DEFAULT_ERROR_CONFIDENCE)
            try:
                from backend.services.confidence_normalizer import ConfidenceNormalizer

                base_conf = ConfidenceNormalizer.normalize(raw_conf)
            except Exception as ex:
                logger.debug("ConfidenceNormalizer unavailable: %s", ex)
                base_conf = raw_conf
            if entry_analysis.get("is_optimal") and impact_analysis.get("is_safe"):
                enhanced["confidence"] = min(1.0, base_conf * 1.1)  # Increase from live assessment
            elif not entry_analysis.get("is_optimal") or not impact_analysis.get("is_safe"):
                enhanced["confidence"] = max(0.1, base_conf * 0.8)  # Decrease from live assessment
            else:
                enhanced["confidence"] = base_conf  # Keep live confidence

            enhanced["microstructure_reasoning"] = self._get_microstructure_reasoning(entry_analysis, impact_analysis)  # Generate from live analysis
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error enhancing AutoBuy signal with live microstructure for %s", symbol)
            return base_signal  # Return original live signal on error

    def _get_microstructure_reasoning(self, entry_analysis: dict[str, Any], impact_analysis: dict[str, Any]) -> str:
        """
        Explain how live microstructure affected the signal (backend port 8000).

        Args:
            entry_analysis: Live entry analysis dictionary
            impact_analysis: Live impact analysis dictionary

        Returns:
            Reasoning string based on live analysis
        """
        if entry_analysis.get("is_optimal") and impact_analysis.get("is_safe"):
            return "Optimal market conditions from live data - good liquidity and low impact"
        if not entry_analysis.get("is_optimal"):
            return "Suboptimal entry conditions from live data - check liquidity and spread"
        if not impact_analysis.get("is_safe"):
            return "High market impact risk from live data - consider smaller order size"
        return "Mixed market conditions from live data - proceed with caution"


# Global live market microstructure analyzer instance
live_market_microstructure_analyzer = LiveMarketMicrostructureAnalyzer()  # Initialize singleton for live operations


def get_live_market_microstructure_analyzer() -> LiveMarketMicrostructureAnalyzer:
    """
    Get the global live market microstructure analyzer instance (backend port 8000).

    Returns:
        Global live market microstructure analyzer instance for live operations
    """
    return live_market_microstructure_analyzer
