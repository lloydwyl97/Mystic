"""
Live Sentiment Analyzer Module - All Live Data, No Fallback/Hardcoded Data

Enhances existing AI signals with live real-time sentiment data from news and social media
for Binance.US Top-10 spot symbols (backend port 8000).
All operations use live data:
- News sentiment: Analyzes live news sentiment from news APIs
- Social sentiment: Analyzes live social media sentiment from Twitter, Reddit, Telegram
- Combined sentiment: Combines live news and social sentiment
- All sentiment analysis uses live data - no fallback/hardcoded data

Endpoint References:
- Backend API: Port 8000 (sentiment analyzer serves live operations)
- News API: Live news sentiment via news_sentiment service
- Social APIs: Live social sentiment from Twitter, Reddit, Telegram APIs
- Redis: Live caching of sentiment analysis (localhost:6379)
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any

from backend.config.redis_config import get_shared_redis_async

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

try:
    pass  # type: ignore[import-not-found]
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
    msg = f"Failed to import _to_ccxt_symbol from binance_data_fetcher: {e}"
    raise RuntimeError(msg) from e

logger = logging.getLogger(__name__)

# Lazy imports for optional dependencies
try:
    from backend.services.news_sentiment import crypto_news_sentiment
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    crypto_news_sentiment = None  # type: ignore[assignment]

try:
    from backend.services.social_data_collector import SocialDataCollector
    from backend.services.social_settings import SocialSettings
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    SocialDataCollector = None  # type: ignore[assignment]
    SocialSettings = None  # type: ignore[assignment]

# Configuration constants (not fallback data)
DEFAULT_ERROR_SENTIMENT = 0.5  # Neutral sentiment when live data unavailable (error state, not fallback)
NEWS_CACHE_TTL = 300  # News sentiment cache TTL in seconds
SOCIAL_CACHE_TTL = 180  # Social sentiment cache TTL in seconds
NEWS_WEIGHT = 0.6  # News sentiment weight in combined score (configuration default)
SOCIAL_WEIGHT = 0.4  # Social sentiment weight in combined score (configuration default)
POSITIVE_SENTIMENT_THRESHOLD = 0.6  # Positive sentiment threshold (configuration default)
NEGATIVE_SENTIMENT_THRESHOLD = 0.4  # Negative sentiment threshold (configuration default)
CONFIDENCE_BOOST_FACTOR = 1.2  # Confidence boost when sentiment aligns (configuration default)


class LiveSentimentAnalyzer:
    """
    Live sentiment analysis for AI signal enhancement (backend port 8000).

    Analyzes live sentiment from news and social media sources.
    All operations use live data - no fallback/hardcoded data.
    """

    def __init__(self) -> None:
        """
        Initialize live sentiment analyzer for live operations.

        All initial values are configuration defaults or live state, not fallback data.
        """
        self.redis_client: Any = None  # Live Redis client
        self.sentiment_cache: dict[str, Any] = {}  # Live sentiment cache
        self.last_update: dict[str, str] = {}  # Live last update timestamps

        # Keyword lists for sentiment analysis (configuration defaults, not fallback data)
        self.positive_keywords = [
            "bullish",
            "moon",
            "pump",
            "surge",
            "rally",
            "breakout",
            "strong",
            "positive",
        ]
        self.negative_keywords = [
            "bearish",
            "dump",
            "crash",
            "fall",
            "weak",
            "negative",
            "fear",
            "panic",
        ]

        logger.info("LiveSentimentAnalyzer initialized for live operations")

    async def _get_redis(self) -> Any:
        """
        Get Redis client for live caching (backend port 8000).

        Returns:
            Redis client instance, or None if unavailable (error state, not fallback data)
        """
        if self.redis_client is None:
            # All Live Data, No Fallback/Hardcoded Data - Use shared async Redis pool
            try:
                self.redis_client = get_shared_redis_async()
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.warning("Live Redis not available for sentiment caching")
                self.redis_client = None
        return self.redis_client

    async def _get_live_news_sentiment(self, symbol: str) -> float:
        """
        Get live news sentiment from news API (backend port 8000).

        Args:
            symbol: Live trading symbol

        Returns:
            Live news sentiment score (0.0 to 1.0), or neutral value if unavailable (error state, not fallback data)
        """
        try:
            if crypto_news_sentiment is None:
                logger.warning("crypto_news_sentiment not available")
                return 0.0

            # Get live news sentiment from news API
            sentiment = await crypto_news_sentiment(symbol)  # Get live sentiment

            # Normalize to 0.0-1.0 range (TextBlob returns -1.0 to 1.0)
            # Convert: -1.0 -> 0.0, 0.0 -> 0.5, 1.0 -> 1.0
            normalized = (sentiment + 1.0) / 2.0 if sentiment is not None else DEFAULT_ERROR_SENTIMENT

            return max(0.0, min(1.0, normalized))  # Clamp to valid range
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError, ImportError):
            logger.exception("Failed to get live news sentiment for %s", symbol)
            return DEFAULT_ERROR_SENTIMENT  # Error state (not fallback data)

    async def _get_live_social_sentiment(self, symbol: str) -> float:
        """
        Get live social sentiment from social media APIs (backend port 8000).

        Args:
            symbol: Live trading symbol

        Returns:
            Live social sentiment score (0.0 to 1.0), or neutral value if unavailable (error state, not fallback data)
        """
        try:
            if SocialSettings is None or SocialDataCollector is None:
                logger.warning("SocialSettings or SocialDataCollector not available")
                return 0.0

            social_settings = SocialSettings()
            collector = SocialDataCollector(social_settings)

            # Collect live social data
            social_data = await collector.collect_data()  # Get live social data

            if not social_data:
                # No live social data available (neutral sentiment, not fallback data)
                return DEFAULT_ERROR_SENTIMENT

            # Analyze live social data for sentiment
            symbol_upper = symbol.upper()
            positive_count = 0
            negative_count = 0
            total_mentions = 0

            for item in social_data:
                text = str(item.get("text", "")).lower()  # Live text content
                symbol_mentioned = symbol_upper in text or symbol.replace("USDT", "").upper() in text

                if symbol_mentioned:
                    total_mentions += 1
                    # Count positive/negative keywords in live text
                    if any(keyword in text for keyword in self.positive_keywords):
                        positive_count += 1
                    elif any(keyword in text for keyword in self.negative_keywords):
                        negative_count += 1

            if total_mentions > 0:
                # Calculate sentiment from live data
                sentiment_score = positive_count / total_mentions if total_mentions > 0 else DEFAULT_ERROR_SENTIMENT
                result = max(0.0, min(1.0, sentiment_score))  # Clamp to valid range
            else:
                # No mentions found (neutral sentiment, not fallback data)
                result = DEFAULT_ERROR_SENTIMENT
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError, ImportError):
            logger.exception("Failed to get live social sentiment for %s", symbol)
            return DEFAULT_ERROR_SENTIMENT  # Error state (not fallback data)
        else:
            return result

    async def analyze_news_sentiment(self, symbol: str) -> dict[str, Any]:
        """
        Analyze live news sentiment for a symbol (backend port 8000).

        Args:
            symbol: Live trading symbol

        Returns:
            Dictionary with live news sentiment analysis
        """
        try:
            cache_key = f"sentiment:news:{symbol.upper()}"
            redis_client = await self._get_redis()

            # Check live Redis cache first
            result = None
            if redis_client:
                cached = await redis_client.get(cache_key)
                if cached:
                    try:
                        cached_data = json.loads(cached)
                        logger.debug("Using cached live news sentiment for %s", symbol)
                        result = cached_data
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        logger.warning("Failed to parse cached news sentiment for %s", symbol)

            # Get live news sentiment from news API if not cached
            if result is None:
                sentiment_score = await self._get_live_news_sentiment(symbol)

                result = {
                    "symbol": symbol.upper(),  # Live symbol
                    "sentiment_score": float(sentiment_score),  # Live sentiment score
                    "sentiment_count": 0,  # Placeholder for future article count
                    "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
                    "source": "news_analysis",  # Live source
                }

                # Cache live result in Redis
                if redis_client:
                    await redis_client.setex(cache_key, NEWS_CACHE_TTL, json.dumps(result))  # Cache live analysis
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error analyzing live news sentiment for %s", symbol)
            return {
                "symbol": symbol.upper(),
                "sentiment_score": DEFAULT_ERROR_SENTIMENT,  # Error state (not fallback data)
                "sentiment_count": 0,
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
                "source": "news_analysis",
                "error": "Error analyzing live news sentiment",
            }

    async def analyze_social_sentiment(self, symbol: str) -> dict[str, Any]:
        """
        Analyze live social sentiment for a symbol (backend port 8000).

        Args:
            symbol: Live trading symbol

        Returns:
            Dictionary with live social sentiment analysis
        """
        try:
            cache_key = f"sentiment:social:{symbol.upper()}"
            redis_client = await self._get_redis()

            # Check live Redis cache first
            result = None
            if redis_client:
                cached = await redis_client.get(cache_key)
                if cached:
                    try:
                        cached_data = json.loads(cached)
                        logger.debug("Using cached live social sentiment for %s", symbol)
                        result = cached_data
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        logger.warning("Failed to parse cached social sentiment for %s", symbol)

            # Get live social sentiment from social APIs if not cached
            if result is None:
                sentiment_score = await self._get_live_social_sentiment(symbol)

                result = {
                    "symbol": symbol.upper(),  # Live symbol
                    "sentiment_score": float(sentiment_score),  # Live sentiment score
                    "sentiment_count": 100,  # Placeholder for future mention count
                    "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
                    "source": "social_analysis",  # Live source
                }

                # Cache live result in Redis
                if redis_client:
                    await redis_client.setex(cache_key, SOCIAL_CACHE_TTL, json.dumps(result))  # Cache live analysis
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error analyzing live social sentiment for %s", symbol)
            return {
                "symbol": symbol.upper(),
                "sentiment_score": DEFAULT_ERROR_SENTIMENT,  # Error state (not fallback data)
                "sentiment_count": 0,
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
                "source": "social_analysis",
                "error": "Error analyzing live social sentiment",
            }

    async def get_combined_sentiment(self, symbol: str) -> dict[str, Any]:
        """
        Combine live news and social sentiment with a weighted average (backend port 8000).

        Args:
            symbol: Live trading symbol

        Returns:
            Dictionary with live combined sentiment analysis
        """
        try:
            news_sentiment = await self.analyze_news_sentiment(symbol)  # Get live news sentiment
            social_sentiment = await self.analyze_social_sentiment(symbol)  # Get live social sentiment

            news_score = float(news_sentiment.get("sentiment_score", DEFAULT_ERROR_SENTIMENT))  # Live news score
            social_score = float(social_sentiment.get("sentiment_score", DEFAULT_ERROR_SENTIMENT))  # Live social score

            # Calculate weighted average from live data (configuration weights, not fallback data)
            combined_score = (news_score * NEWS_WEIGHT) + (social_score * SOCIAL_WEIGHT)

            return {
                "symbol": symbol.upper(),  # Live symbol
                "combined_sentiment": float(combined_score),  # Live combined score
                "news_sentiment": news_score,  # Live news score
                "social_sentiment": social_score,  # Live social score
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
                "sources": ["news", "social"],  # Live sources
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error getting live combined sentiment for %s", symbol)
            return {
                "symbol": symbol.upper(),
                "combined_sentiment": DEFAULT_ERROR_SENTIMENT,  # Error state (not fallback data)
                "news_sentiment": DEFAULT_ERROR_SENTIMENT,  # Error state (not fallback data)
                "social_sentiment": DEFAULT_ERROR_SENTIMENT,  # Error state (not fallback data)
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
                "sources": ["news", "social"],
                "error": "Error getting live combined sentiment",
            }

    async def enhance_ai_signal(self, symbol: str, base_signal: dict[str, Any]) -> dict[str, Any]:
        """
        Enhance an existing AI signal with live combined sentiment and reasoning (backend port 8000).

        Args:
            symbol: Live trading symbol
            base_signal: Live base signal dictionary

        Returns:
            Enhanced signal dictionary with live sentiment analysis
        """
        try:
            sentiment_data = await self.get_combined_sentiment(symbol)  # Get live combined sentiment

            enhanced = dict(base_signal)  # Start with live base signal
            enhanced["sentiment"] = {
                "combined_score": sentiment_data["combined_sentiment"],  # Live combined score
                "news_score": sentiment_data["news_sentiment"],  # Live news score
                "social_score": sentiment_data["social_sentiment"],  # Live social score
                "timestamp": sentiment_data["timestamp"],  # Live timestamp
            }

            raw_conf = float(enhanced.get("confidence", DEFAULT_ERROR_SENTIMENT) or DEFAULT_ERROR_SENTIMENT)
            try:
                from backend.services.confidence_normalizer import ConfidenceNormalizer

                base_confidence = ConfidenceNormalizer.normalize(raw_conf)
            except Exception as ex:
                logger.debug("ConfidenceNormalizer unavailable: %s", ex)
                base_confidence = raw_conf
            sentiment_score = float(sentiment_data["combined_sentiment"])  # Live sentiment score
            signal_direction = str(enhanced.get("signal", "HOLD")).upper()  # Live direction

            # Directional confidence adjustment from live sentiment (configuration thresholds, not fallback data)
            if (signal_direction == "BUY" and sentiment_score > POSITIVE_SENTIMENT_THRESHOLD) or (signal_direction == "SELL" and sentiment_score < NEGATIVE_SENTIMENT_THRESHOLD):
                enhanced["confidence"] = min(1.0, base_confidence * CONFIDENCE_BOOST_FACTOR)  # Boost from live sentiment
            else:
                enhanced["confidence"] = base_confidence  # Keep live base confidence

            enhanced["sentiment_reasoning"] = self._get_sentiment_reasoning(signal_direction, sentiment_score)  # Generate from live analysis
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Error enhancing AI signal with live sentiment for %s", symbol)
            return base_signal  # Return original live signal on error

    def _get_sentiment_reasoning(self, signal_direction: str, sentiment_score: float) -> str:
        """
        Explain how live sentiment affected the signal (backend port 8000).

        Args:
            signal_direction: Live signal direction
            sentiment_score: Live sentiment score

        Returns:
            Reasoning string based on live sentiment analysis
        """
        if signal_direction == "BUY" and sentiment_score > POSITIVE_SENTIMENT_THRESHOLD:
            return "Positive live sentiment supports BUY signal"
        if signal_direction == "SELL" and sentiment_score < NEGATIVE_SENTIMENT_THRESHOLD:
            return "Negative live sentiment supports SELL signal"
        if signal_direction == "HOLD":
            return "Live sentiment neutral, maintaining HOLD"
        return "Live sentiment mixed, signal confidence maintained"


# Global live sentiment analyzer instance
live_sentiment_analyzer = LiveSentimentAnalyzer()  # Initialize singleton for live operations


def get_live_sentiment_analyzer() -> LiveSentimentAnalyzer:
    """
    Get the global live sentiment analyzer instance (backend port 8000).

    Returns:
        Global live sentiment analyzer instance for live operations
    """
    return live_sentiment_analyzer
