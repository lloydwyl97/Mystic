"""
Live Trading Service Module - All Live Data, No Fallback/Hardcoded Data

Production-safe wrapper around CCXT for Binance.US Top-10 spot trading (backend port 8000).
All operations use live data:
- Order management: Places and manages live orders on Binance.US
- Trade execution: Executes live trades on Binance.US
- Balance retrieval: Gets live account balances from Binance.US
- Ticker data: Gets live ticker data from Binance.US
- All trading operations use live data - no fallback/hardcoded data

Single-source-of-truth:
- EXCHANGE_ID = "binance_us" (from binance_data_fetcher)
- _to_ccxt_symbol() helper used for all CCXT symbol formatting (BASE/QUOTE only)

Top 10 Coins Universe (should import from trading_universe when available):
BTC, ETH, ADA, SOL, DOGE, XRP, BCH, LTC, AVAX, LINK (all quoted in USDT)

Endpoint References:
- Backend API: Port 8000 (live trading service serves live operations)
- Binance.US API: Live trading operations via CCXT
- Canonical Cache: Live trade logging
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import asyncio
import logging
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

try:
    # Import from single source of truth
    from backend.config.trading_universe import EXCHANGE_ID, TOP10_COINS
    from backend.modules.market.binance_data_fetcher import _to_ccxt_symbol  # type: ignore[import-not-found]
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe or _to_ccxt_symbol: {e}"
    raise RuntimeError(msg) from e


try:
    import ccxt  # synchronous CCXT
except (ImportError, ModuleNotFoundError, AttributeError):  # pragma: no cover
    ccxt = None  # type: ignore[assignment]

from backend.services.canonical_cache import canonical_cache
from backend.utils.binance_weight_limiter import BinanceWeightLimiter, CircuitOpenError, RateLimitedError

logger = logging.getLogger(__name__)

# --------- Data Models ---------


@dataclass
class OrderResult:
    """
    Order result from live trading operations (backend port 8000).

    All fields represent live order execution results - no fallback/hardcoded data.
    """

    success: bool  # Live order success status
    order: dict[str, Any] | None  # Live order data
    error: str | None = None  # Error message if failed (not fallback data)


@dataclass
class ServiceStatus:
    """
    Service status for live trading operations (backend port 8000).

    All fields represent live service status - no fallback/hardcoded data.
    """

    service: str  # Service name
    status: str  # Live service status
    exchange: str  # Live exchange ID
    ccxt_available: bool  # CCXT availability (live state)
    markets_loaded: bool  # Markets loaded status (live state)
    top_symbols: list[str]  # Top symbols list (configuration, not fallback data)


# --------- Live Trading Service ---------


class LiveTradingService:
    """
    Live trading service for EXCHANGE_ID = 'binance_us' (backend port 8000).

    All CCXT calls receive BASE/QUOTE symbols via _to_ccxt_symbol().
    All operations use live data from Binance.US API - no fallback/hardcoded data.
    """

    # Top 10 coins (BASE only); all quoted in USDT for CCXT calls
    # Use TOP10_COINS from trading_universe (live data)
    TOP_COINS: tuple[str, ...] = tuple(TOP10_COINS)

    def __init__(self) -> None:
        """
        Initialize live trading service for live operations.

        All initial values are configuration defaults or live state, not fallback data.
        """
        self.exchange_id = EXCHANGE_ID  # Live exchange ID (single source of truth)
        self.cache = canonical_cache  # Live cache for trade logging
        self._exchange = None  # Live CCXT exchange instance
        self._markets_loaded = False  # Live market load status
        self._limiter: BinanceWeightLimiter | None = None
        self._limiter_lock = asyncio.Lock()
        self._init_exchange()

    # ---------- Private Helpers ----------

    def _init_exchange(self) -> None:
        """
        Initialize CCXT exchange instance for binance_us with proper async pattern (backend port 8000).

        Initializes live exchange connection to Binance.US API.
        """
        if ccxt is None:
            logger.warning("CCXT not available. Install with: pip install ccxt")
            return

        # Map our EXCHANGE_ID to the CCXT class attribute
        # EXCHANGE_ID format: "binance_us" -> CCXT format: "binanceus" (remove underscore)
        ccxt_class_attr = EXCHANGE_ID.replace("_", "") if self.exchange_id == EXCHANGE_ID else None  # Configuration mapping
        if not ccxt_class_attr or not hasattr(ccxt, ccxt_class_attr):
            logger.error("Unsupported exchange_id for CCXT: %s", self.exchange_id)
            return

        # Get live API credentials from environment variables
        api_key = os.getenv("BINANCE_US_API_KEY", "")  # Live API key
        api_secret = os.getenv("BINANCE_US_SECRET", "")  # Live API secret

        try:
            exchange_class = getattr(ccxt, ccxt_class_attr)
            self._exchange = exchange_class(
                {
                    "apiKey": api_key,  # Live API key
                    "secret": api_secret,  # Live API secret
                    "enableRateLimit": True,  # Configuration default
                    "options": {
                        "defaultType": "spot",  # Configuration default
                        "adjustForTimeDifference": True,  # Configuration default
                    },
                },
            )
            # Load markets synchronously but log that async pattern is preferred
            logger.warning("Using synchronous CCXT initialization - consider migrating to async pattern")
            self._load_markets()  # Load live markets
            logger.info("LiveTradingService initialized for live operations on %s", self.exchange_id)
        except Exception:
            logger.exception("Failed to initialize CCXT exchange for live operations")
            self._exchange = None
            self._markets_loaded = False

    def _load_markets(self) -> None:
        """
        Load live markets from Binance.US API (backend port 8000).

        Loads live market data if exchange is available.
        """
        if not self._exchange:
            return
        try:
            self._exchange.load_markets()  # Load live markets
            self._markets_loaded = True
        except Exception:
            logger.exception("Failed to load live markets")
            self._markets_loaded = False

    async def _get_limiter(self) -> BinanceWeightLimiter:
        """Return shared Binance weight limiter for live trading operations."""
        if self._limiter is not None:
            return self._limiter

        async with self._limiter_lock:
            if self._limiter is None:
                self._limiter = await BinanceWeightLimiter.create()
        return self._limiter

    def _require_exchange(self) -> None:
        """
        Ensure exchange is initialized and markets are loaded (backend port 8000).

        Raises:
            RuntimeError: If exchange or markets are not available
        """
        if self._exchange is None:
            msg = "Live exchange not initialized"
            raise RuntimeError(msg)
        if not self._markets_loaded:
            self._load_markets()  # Try to load live markets
            if not self._markets_loaded:
                msg = "Live markets not loaded"
                raise RuntimeError(msg)

    def _normalize_order(self, raw: dict[str, Any]) -> dict[str, Any]:
        """
        Normalize live order data from CCXT (backend port 8000).

        Args:
            raw: Raw order data from live CCXT response

        Returns:
            Normalized order dictionary from live data
        """
        return {
            "id": raw.get("id"),  # Live order ID
            "symbol": raw.get("symbol"),  # Live symbol
            "type": raw.get("type"),  # Live order type
            "side": raw.get("side"),  # Live order side
            "price": raw.get("price"),  # Live order price
            "amount": raw.get("amount"),  # Live order amount
            "filled": raw.get("filled"),  # Live filled amount
            "remaining": raw.get("remaining"),  # Live remaining amount
            "status": raw.get("status"),  # Live order status
            "timestamp": raw.get("timestamp"),  # Live timestamp
            "datetime": raw.get("datetime"),  # Live datetime
            "fee": raw.get("fee"),  # Live fee
            "info": raw.get("info"),  # Live info
        }

    def _normalize_trade(self, raw: dict[str, Any]) -> dict[str, Any]:
        """
        Normalize live trade data from CCXT (backend port 8000).

        Args:
            raw: Raw trade data from live CCXT response

        Returns:
            Normalized trade dictionary from live data
        """
        return {
            "id": raw.get("id"),  # Live trade ID
            "order": raw.get("order"),  # Live order ID
            "symbol": raw.get("symbol"),  # Live symbol
            "side": raw.get("side"),  # Live trade side
            "price": raw.get("price"),  # Live trade price
            "amount": raw.get("amount"),  # Live trade amount
            "cost": raw.get("cost"),  # Live trade cost
            "fee": raw.get("fee"),  # Live trade fee
            "timestamp": raw.get("timestamp"),  # Live timestamp
            "datetime": raw.get("datetime"),  # Live datetime
            "info": raw.get("info"),  # Live info
        }

    def _log_trade_to_cache(
        self,
        trade_id: str,
        base: str,
        quote: str,
        side: str,
        quantity: float,
        price: float,
        status: str = "completed",
    ) -> None:
        """
        Log live trade to canonical cache (backend port 8000).

        Args:
            trade_id: Live trade ID
            base: Live base asset
            quote: Live quote asset
            side: Live trade side
            quantity: Live trade quantity
            price: Live trade price
            status: Live trade status (configuration default, not fallback data)
        """
        try:
            symbol_key = f"{base.upper()}{quote.upper()}"  # Live symbol key
            self.cache.log_trade(
                trade_id=trade_id,  # Live trade ID
                symbol=symbol_key,  # Live symbol
                side=side.upper(),  # Live side
                quantity=float(quantity),  # Live quantity
                price=float(price),  # Live price
                exchange=self.exchange_id,  # Live exchange ID
                status=status,  # Live status
            )
        except Exception:
            logger.exception("Failed to log live trade to cache")

    # ---------- Public API ----------

    async def get_open_orders(self, base: str | None = None, quote: str = "USDT", limit: int = 100) -> dict[str, Any]:
        """
        Return live open orders (backend port 8000).

        If base is None, returns for TOP_COINS universe (USDT quote).

        Args:
            base: Optional base asset (if None, gets for all TOP_COINS)
            quote: Quote asset (configuration default "USDT", not fallback data)
            limit: Maximum orders to retrieve (configuration default 100, not fallback data)

        Returns:
            Dictionary with live open orders from Binance.US API
        """
        try:
            self._require_exchange()
            limiter = await self._get_limiter()
            orders_by_symbol: dict[str, list[dict[str, Any]]] = {}

            bases = (base.upper(),) if base else self.TOP_COINS  # Live base assets
            for b in bases:
                ccxt_symbol = _to_ccxt_symbol(b, quote)  # Normalize live symbol
                try:
                    await limiter.consume("/api/v3/openOrders", weight=5, wait=True, timeout=5.0)
                    raw_orders = self._exchange.fetch_open_orders(ccxt_symbol, limit=limit)  # Get live orders  # type: ignore[attr-defined]
                    orders_by_symbol[f"{b}{quote.upper()}"] = [self._normalize_order(o) for o in raw_orders]  # Normalize live orders
                except (RateLimitedError, CircuitOpenError) as e:
                    logger.warning("Rate limited fetching open orders for %s: %s", ccxt_symbol, e)
                    orders_by_symbol[f"{b}{quote.upper()}"] = []
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception("fetch_open_orders failed for live symbol %s", ccxt_symbol)
                    orders_by_symbol[f"{b}{quote.upper()}"] = []  # Empty list on error (not fallback data)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("get_open_orders error on live exchange")
            return {
                "status": "error",
                "message": "Error getting live open orders",
                "exchange": self.exchange_id,
                "orders": {},  # Empty dict on error (not fallback data)
            }

    async def get_trade_history(self, base: str | None = None, quote: str = "USDT", limit: int = 100) -> dict[str, Any]:
        """
        Return recent live trades (backend port 8000).

        If base is None, returns for TOP_COINS universe (USDT quote).

        Args:
            base: Optional base asset (if None, gets for all TOP_COINS)
            quote: Quote asset (configuration default "USDT", not fallback data)
            limit: Maximum trades to retrieve (configuration default 100, not fallback data)

        Returns:
            Dictionary with live trade history from Binance.US API
        """
        try:
            self._require_exchange()
            trades_by_symbol: dict[str, list[dict[str, Any]]] = {}

            bases = (base.upper(),) if base else self.TOP_COINS  # Live base assets
            for b in bases:
                ccxt_symbol = _to_ccxt_symbol(b, quote)  # Normalize live symbol
                try:
                    raw_trades = self._exchange.fetch_my_trades(ccxt_symbol, limit=limit)  # Get live trades  # type: ignore[attr-defined]
                    trades_by_symbol[f"{b}{quote.upper()}"] = [self._normalize_trade(t) for t in raw_trades]  # Normalize live trades
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.exception("fetch_my_trades failed for live symbol %s", ccxt_symbol)
                    trades_by_symbol[f"{b}{quote.upper()}"] = []  # Empty list on error (not fallback data)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("get_trade_history error on live exchange")
            return {
                "status": "error",
                "message": "Error getting live trade history",
                "exchange": self.exchange_id,
                "trades": {},  # Empty dict on error (not fallback data)
            }

    async def place_market_order(self, base: str, quote: str, side: str, amount: float) -> OrderResult:
        """
        Place a live market order (backend port 8000).

        Places order on Binance.US using live API.

        Args:
            base: Live base asset
            quote: Live quote asset
            side: Live order side ("buy" or "sell")
            amount: Live BASE quantity

        Returns:
            OrderResult with live order execution result
        """
        try:
            self._require_exchange()
            side_l = side.lower()
            if side_l not in {"buy", "sell"}:
                return OrderResult(False, None, "Invalid side")  # Invalid input (not fallback data)

            symbol = _to_ccxt_symbol(base, quote)  # Normalize live symbol
            raw_order = self._exchange.create_order(symbol, "market", side_l, amount)  # Place live order  # type: ignore[attr-defined]
            order = self._normalize_order(raw_order)  # Normalize live order

            # Best-effort fill price logging from live data
            price = float(order.get("price") or 0.0)  # Get from live order
            if price <= 0:
                # Try live ticker last price if order has no price
                try:
                    ticker = self._exchange.fetch_ticker(symbol)  # Get live ticker  # type: ignore[attr-defined]
                    price = float(ticker.get("last") or 0.0)  # Get live last price
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    logger.warning("Failed to get live price for trade logging")
                    price = 0.0  # Error state (not fallback data)

            self._log_trade_to_cache(
                trade_id=str(order.get("id") or f"mkt_{datetime.now(timezone.utc).timestamp()}"),  # Live trade ID
                base=base,  # Live base
                quote=quote,  # Live quote
                side=side_l,  # Live side
                quantity=float(order.get("amount") or amount),  # Live quantity
                price=price,  # Live price
                status=str(order.get("status") or "completed"),  # Live status
            )
            return OrderResult(True, order, None)  # Success with live order
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("place_market_order error on live exchange")
            return OrderResult(False, None, "Error placing live market order")

    async def cancel_order(self, order_id: str, base: str, quote: str) -> dict[str, Any]:
        """
        Cancel a specific live order (backend port 8000).

        Args:
            order_id: Live order ID
            base: Live base asset
            quote: Live quote asset

        Returns:
            Dictionary with cancellation result
        """
        try:
            self._require_exchange()
            symbol = _to_ccxt_symbol(base, quote)  # Normalize live symbol
            self._exchange.cancel_order(order_id, symbol)  # Cancel live order  # type: ignore[attr-defined]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("cancel_order error on live exchange")
            return {"status": "error", "message": "Error canceling live order", "exchange": self.exchange_id}

    async def get_balance(self) -> dict[str, Any]:
        """
        Return live account balances (backend port 8000).

        Returns:
            Dictionary with live account balances from Binance.US API
        """
        try:
            self._require_exchange()
            self._exchange.fetch_balance()  # Get live balance  # type: ignore[attr-defined]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("get_balance error on live exchange")
            return {
                "status": "error",
                "message": "Error getting live balance",
                "exchange": self.exchange_id,
                "balance": {},  # Empty dict on error (not fallback data)
            }

    async def get_ticker(self, base: str, quote: str = "USDT") -> dict[str, Any]:
        """
        Return latest live ticker for BASE/QUOTE (backend port 8000).

        Args:
            base: Live base asset
            quote: Quote asset (configuration default "USDT", not fallback data)

        Returns:
            Dictionary with live ticker data from Binance.US API
        """
        try:
            self._require_exchange()
            symbol = _to_ccxt_symbol(base, quote)  # Normalize live symbol
            t = self._exchange.fetch_ticker(symbol)  # Get live ticker  # type: ignore[attr-defined]
            return {
                "status": "success",
                "exchange": self.exchange_id,  # Live exchange ID
                "symbol": f"{base.upper()}{quote.upper()}",  # Live symbol
                "last": t.get("last"),  # Live last price
                "bid": t.get("bid"),  # Live bid price
                "ask": t.get("ask"),  # Live ask price
                "info": t.get("info"),  # Live ticker info
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("get_ticker error on live exchange")
            return {"status": "error", "message": "Error getting live ticker", "exchange": self.exchange_id}

    async def status(self) -> ServiceStatus:
        """
        Get live service status (backend port 8000).

        Returns:
            ServiceStatus with live service state
        """
        return ServiceStatus(
            service="LiveTradingService",
            status="active" if self._exchange else "disabled",  # Live status
            exchange=self.exchange_id,  # Live exchange ID
            ccxt_available=bool(ccxt is not None),  # CCXT availability
            markets_loaded=self._markets_loaded,  # Live market load status
            top_symbols=[f"{b}/USDT" for b in self.TOP_COINS],  # Configuration symbols
        )


# --------- Global Instance & Getter ---------

_live_trading_service = LiveTradingService()  # Initialize singleton for live operations


def get_live_trading_service() -> LiveTradingService:
    """
    Get the global live trading service instance (backend port 8000).

    Returns:
        Global live trading service instance for live operations
    """
    return _live_trading_service


__all__ = [
    "EXCHANGE_ID",
    "LiveTradingService",
    "OrderResult",
    "ServiceStatus",
    "_to_ccxt_symbol",
    "get_live_trading_service",
]
