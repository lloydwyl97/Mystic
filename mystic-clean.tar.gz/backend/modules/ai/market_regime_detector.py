"""
Market Regime Detection Module - All Live Data, No Fallback/Hardcoded Data

Detects live volatility regimes, trend strength, market cycles, and seasonality
for Binance.US Top-10 spot symbols (backend port 8000).
All operations use live data:
- Volatility regime: Detects from live OHLCV data
- Trend strength: Calculates from live price movements
- Market cycle: Identifies from live price and volume patterns
- Seasonality: Uses configuration-based patterns (not fallback data)
- All analysis uses live data - no fallback/hardcoded data

Endpoint References:
- Backend API: Port 8000 (market regime detector serves live operations)
- All calculations use live OHLCV data - no mock/test data
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Any

import pandas as pd

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

try:
    from backend.modules.market.binance_data_fetcher import _to_ccxt_symbol
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
    msg = f"Failed to import _to_ccxt_symbol from binance_data_fetcher: {e}"
    raise RuntimeError(msg) from e


logger = logging.getLogger(__name__)

# Configuration constants (not fallback data)
DEFAULT_ERROR_SCORE = 0.5  # Neutral score when live data unavailable (error state, not fallback)
DEFAULT_ERROR_SEASONALITY = 1.0  # Neutral seasonality when unavailable (error state, not fallback)
VOLATILITY_LOW_THRESHOLD = 0.02  # Low volatility threshold (configuration default)
VOLATILITY_NORMAL_THRESHOLD = 0.05  # Normal volatility threshold (configuration default)
VOLATILITY_HIGH_THRESHOLD = 0.10  # High volatility threshold (configuration default)
VOLATILITY_EXTREME_THRESHOLD = 0.20  # Extreme volatility threshold (configuration default)
TREND_STRONG_THRESHOLD = 0.7  # Strong trend threshold (configuration default)
TREND_WEAK_THRESHOLD = 0.3  # Weak trend threshold (configuration default)
VOLATILITY_LOOKBACK = 20  # Volatility lookback period (configuration default)
TREND_LOOKBACK = 50  # Trend lookback period (configuration default)
CYCLE_LOOKBACK = 100  # Cycle lookback period (configuration default)
TREND_CHANGE_THRESHOLD = 0.05  # Trend change threshold (configuration default)
VOLATILITY_QUANTILE = 0.7  # Volatility quantile for cycle detection (configuration default)
SEASONALITY_HOURLY_WEIGHT = 0.3  # Hourly seasonality weight (configuration default)
SEASONALITY_DAILY_WEIGHT = 0.3  # Daily seasonality weight (configuration default)
SEASONALITY_WEEKLY_WEIGHT = 0.2  # Weekly seasonality weight (configuration default)
SEASONALITY_MONTHLY_WEIGHT = 0.2  # Monthly seasonality weight (configuration default)
FAVORABLE_SEASONALITY_THRESHOLD = 1.1  # Favorable seasonality threshold (configuration default)
UNFAVORABLE_SEASONALITY_THRESHOLD = 0.9  # Unfavorable seasonality threshold (configuration default)
POSITION_BOOST_FACTOR = 1.2  # Position size boost for low volatility (configuration default)
POSITION_REDUCE_FACTOR = 0.7  # Position size reduction for high volatility (configuration default)
POSITION_MIN_FACTOR = 0.3  # Minimum position size for extreme volatility (configuration default)
SEASONALITY_BOOST_FACTOR = 1.1  # Seasonality boost factor (configuration default)
SEASONALITY_REDUCE_FACTOR = 0.9  # Seasonality reduction factor (configuration default)
LOW_CONFIDENCE_THRESHOLD = 0.4  # Low regime confidence threshold (configuration default)
HIGH_CONFIDENCE_THRESHOLD = 0.8  # High regime confidence threshold (configuration default)


class VolatilityRegime(Enum):
    """Volatility regime classification from live market data (backend port 8000)."""

    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    EXTREME = "extreme"


class TrendStrength(Enum):
    """Trend strength classification from live market data (backend port 8000)."""

    STRONG_BULL = "strong_bull"
    WEAK_BULL = "weak_bull"
    SIDEWAYS = "sideways"
    WEAK_BEAR = "weak_bear"
    STRONG_BEAR = "strong_bear"


class MarketCycle(Enum):
    """Market cycle classification from live market data (backend port 8000)."""

    ACCUMULATION = "accumulation"
    MARKUP = "markup"
    DISTRIBUTION = "distribution"
    MARKDOWN = "markdown"


@dataclass
class RegimeAnalysis:
    """
    Market regime analysis result from live data (backend port 8000).

    All fields represent live market regime analysis - no fallback/hardcoded data.
    """

    symbol: str  # Live trading symbol
    volatility_regime: VolatilityRegime  # Live volatility regime
    trend_strength: TrendStrength  # Live trend strength
    market_cycle: MarketCycle  # Live market cycle
    volatility_score: float  # Live volatility score
    trend_score: float  # Live trend score
    cycle_score: float  # Live cycle score
    seasonality_score: float  # Seasonality score (configuration-based, not fallback data)
    regime_confidence: float  # Live regime confidence
    timestamp: datetime  # Live timestamp


class MarketRegimeDetector:
    """
    Market regime detector for live market analysis (backend port 8000).

    Detects volatility regimes, trend strength, market cycles, and seasonality from live OHLCV data.
    All operations use live data - no fallback/hardcoded data.
    """

    def __init__(self) -> None:
        """
        Initialize market regime detector for live operations.

        All initial values are configuration defaults or live state, not fallback data.
        """
        # Volatility thresholds (configuration defaults, not fallback data)
        self.volatility_thresholds: dict[str, float] = {
            "low": VOLATILITY_LOW_THRESHOLD,
            "normal": VOLATILITY_NORMAL_THRESHOLD,
            "high": VOLATILITY_HIGH_THRESHOLD,
            "extreme": VOLATILITY_EXTREME_THRESHOLD,
        }

        # Trend thresholds (configuration defaults, not fallback data)
        self.trend_thresholds: dict[str, float] = {
            "strong": TREND_STRONG_THRESHOLD,
            "weak": TREND_WEAK_THRESHOLD,
        }

        # Lookback periods (configuration defaults, not fallback data)
        self.volatility_lookback: int = VOLATILITY_LOOKBACK
        self.trend_lookback: int = TREND_LOOKBACK
        self.cycle_lookback: int = CYCLE_LOOKBACK

        # Seasonality patterns (configuration defaults based on historical patterns, not fallback data)
        self.seasonality_patterns: dict[str, dict[int, float]] = {
            "hourly": self._get_hourly_pattern(),
            "daily": self._get_daily_pattern(),
            "weekly": self._get_weekly_pattern(),
            "monthly": self._get_monthly_pattern(),
        }

        logger.info("MarketRegimeDetector initialized for live operations")

    def _get_hourly_pattern(self) -> dict[int, float]:
        """
        Get hourly seasonality pattern (backend port 8000).

        Returns:
            Dictionary with hourly patterns (configuration defaults based on historical patterns, not fallback data)
        """
        pattern: dict[int, float] = {}
        for hour in range(24):
            if 0 <= hour < 6:
                pattern[hour] = 0.8  # Configuration default (early morning)
            elif 6 <= hour < 12:
                pattern[hour] = 1.0  # Configuration default (morning)
            elif 12 <= hour < 18:
                pattern[hour] = 1.2  # Configuration default (afternoon)
            else:
                pattern[hour] = 0.9  # Configuration default (evening)
        return pattern

    def _get_daily_pattern(self) -> dict[int, float]:
        """
        Get daily seasonality pattern (backend port 8000).

        Returns:
            Dictionary with daily patterns (configuration defaults based on historical patterns, not fallback data)
        """
        return {
            0: 0.8,  # Monday (configuration default)
            1: 1.1,  # Tuesday (configuration default)
            2: 1.2,  # Wednesday (configuration default)
            3: 1.1,  # Thursday (configuration default)
            4: 0.9,  # Friday (configuration default)
            5: 0.7,  # Saturday (configuration default)
            6: 0.7,  # Sunday (configuration default)
        }

    def _get_weekly_pattern(self) -> dict[int, float]:
        """
        Get weekly seasonality pattern (backend port 8000).

        Returns:
            Dictionary with weekly patterns (configuration defaults based on historical patterns, not fallback data)
        """
        return {
            1: 1.1,  # Week 1 (configuration default)
            2: 0.9,  # Week 2 (configuration default)
            3: 1.1,  # Week 3 (configuration default)
            4: 0.9,  # Week 4 (configuration default)
        }

    def _get_monthly_pattern(self) -> dict[int, float]:
        """
        Get monthly seasonality pattern (backend port 8000).

        Returns:
            Dictionary with monthly patterns (configuration defaults based on historical patterns, not fallback data)
        """
        pattern: dict[int, float] = {}
        for month in range(1, 13):
            if month in (1, 2, 3):
                pattern[month] = 1.1  # Configuration default (Q1)
            elif month in (4, 5, 6):
                pattern[month] = 1.0  # Configuration default (Q2)
            elif month in (7, 8, 9):
                pattern[month] = 0.9  # Configuration default (Q3)
            else:
                pattern[month] = 1.1  # Configuration default (Q4)
        return pattern

    async def detect_volatility_regime(self, symbol: str, ohlcv_data: list[list[float]]) -> tuple[VolatilityRegime, float]:
        """
        Detect live volatility regime from OHLCV data (backend port 8000).

        Args:
            symbol: Live trading symbol
            ohlcv_data: Live OHLCV data list

        Returns:
            Tuple of (volatility regime, volatility score) from live data
        """
        try:
            if not ohlcv_data or len(ohlcv_data) < self.volatility_lookback:
                # Insufficient live data (neutral regime, not fallback data)
                return VolatilityRegime.NORMAL, DEFAULT_ERROR_SCORE

            df = pd.DataFrame(
                ohlcv_data,  # Live OHLCV data
                columns=["timestamp", "open", "high", "low", "close", "volume"],
            )
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")  # Convert live timestamps
            df = df.set_index("timestamp")

            df["returns"] = df["close"].pct_change()  # Calculate from live prices
            df["volatility"] = df["returns"].rolling(self.volatility_lookback).std()  # Calculate from live returns
            current_volatility = float(df["volatility"].iloc[-1])  # Latest live volatility

            if pd.isna(current_volatility):
                return VolatilityRegime.NORMAL, DEFAULT_ERROR_SCORE  # Error state (not fallback data)

            # Classify from live volatility
            if current_volatility <= self.volatility_thresholds["low"]:
                result = (VolatilityRegime.LOW, 0.2)  # Low volatility from live data
            elif current_volatility <= self.volatility_thresholds["normal"]:
                result = (VolatilityRegime.NORMAL, DEFAULT_ERROR_SCORE)  # Normal volatility from live data
            elif current_volatility <= self.volatility_thresholds["high"]:
                result = (VolatilityRegime.HIGH, 0.8)  # High volatility from live data
            else:
                result = (VolatilityRegime.EXTREME, 1.0)  # Extreme volatility from live data
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Volatility regime detection failed for live symbol %s", symbol)
            return VolatilityRegime.NORMAL, DEFAULT_ERROR_SCORE  # Error state (not fallback data)
        else:
            return result

    async def detect_trend_strength(self, symbol: str, ohlcv_data: list[list[float]]) -> tuple[TrendStrength, float]:
        """
        Detect live trend strength from OHLCV data (backend port 8000).

        Args:
            symbol: Live trading symbol
            ohlcv_data: Live OHLCV data list

        Returns:
            Tuple of (trend strength, trend score) from live data
        """
        try:
            if not ohlcv_data or len(ohlcv_data) < self.trend_lookback:
                # Insufficient live data (neutral trend, not fallback data)
                return TrendStrength.SIDEWAYS, DEFAULT_ERROR_SCORE

            df = pd.DataFrame(
                ohlcv_data,  # Live OHLCV data
                columns=["timestamp", "open", "high", "low", "close", "volume"],
            )
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")  # Convert live timestamps
            df = df.set_index("timestamp")

            # Calculate moving averages from live prices
            df["sma_20"] = df["close"].rolling(20).mean()  # From live prices
            df["sma_50"] = df["close"].rolling(50).mean()  # From live prices
            df["ema_12"] = df["close"].ewm(span=12).mean()  # From live prices
            df["ema_26"] = df["close"].ewm(span=26).mean()  # From live prices

            current_price = float(df["close"].iloc[-1])  # Latest live price
            sma_20 = float(df["sma_20"].iloc[-1])  # Latest live SMA20
            sma_50 = float(df["sma_50"].iloc[-1])  # Latest live SMA50
            ema_12 = float(df["ema_12"].iloc[-1])  # Latest live EMA12
            ema_26 = float(df["ema_26"].iloc[-1])  # Latest live EMA26

            # Calculate trend indicators from live data
            price_vs_sma20 = (current_price - sma_20) / sma_20 if sma_20 else 0.0  # From live data
            price_vs_sma50 = (current_price - sma_50) / sma_50 if sma_50 else 0.0  # From live data
            sma20_vs_sma50 = (sma_20 - sma_50) / sma_50 if sma_50 else 0.0  # From live data
            ema12_vs_ema26 = (ema_12 - ema_26) / ema_26 if ema_26 else 0.0  # From live data

            trend_score = float((price_vs_sma20 + price_vs_sma50 + sma20_vs_sma50 + ema12_vs_ema26) / 4)  # Calculate from live data

            # Classify from live trend score
            if abs(trend_score) > self.trend_thresholds["strong"]:
                ((TrendStrength.STRONG_BULL if trend_score > 0 else TrendStrength.STRONG_BEAR), abs(trend_score))  # Strong trend from live data
            elif abs(trend_score) > self.trend_thresholds["weak"]:
                ((TrendStrength.WEAK_BULL if trend_score > 0 else TrendStrength.WEAK_BEAR), abs(trend_score))  # Weak trend from live data
            else:
                pass  # Sideways from live data
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Trend strength detection failed for live symbol %s", symbol)
            return TrendStrength.SIDEWAYS, DEFAULT_ERROR_SCORE  # Error state (not fallback data)

    async def detect_market_cycle(self, symbol: str, ohlcv_data: list[list[float]]) -> tuple[MarketCycle, float]:
        """
        Detect live market cycle from OHLCV data (backend port 8000).

        Args:
            symbol: Live trading symbol
            ohlcv_data: Live OHLCV data list

        Returns:
            Tuple of (market cycle, cycle score) from live data
        """
        try:
            if not ohlcv_data or len(ohlcv_data) < self.cycle_lookback:
                # Insufficient live data (neutral cycle, not fallback data)
                return MarketCycle.ACCUMULATION, DEFAULT_ERROR_SCORE

            df = pd.DataFrame(
                ohlcv_data,  # Live OHLCV data
                columns=["timestamp", "open", "high", "low", "close", "volume"],
            )
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")  # Convert live timestamps
            df = df.set_index("timestamp")

            # Calculate indicators from live prices and volume
            df["sma_20"] = df["close"].rolling(20).mean()  # From live prices
            df["sma_50"] = df["close"].rolling(50).mean()  # From live prices
            df["volume_sma"] = df["volume"].rolling(20).mean()  # From live volume
            df["price_change"] = df["close"].pct_change()  # From live prices
            df["volatility"] = df["price_change"].rolling(20).std()  # From live price changes

            recent = df.tail(20)  # Recent live data
            price_trend = (float(recent["close"].iloc[-1]) - float(recent["close"].iloc[0])) / float(recent["close"].iloc[0])  # Calculate from live prices
            volume_trend = (float(recent["volume"].iloc[-1]) - float(recent["volume"].iloc[0])) / max(float(recent["volume"].iloc[0]), 1.0)  # Calculate from live volume
            volatility_level = float(recent["volatility"].mean())  # From live volatility

            sma20 = float(recent["sma_20"].iloc[-1])  # Latest live SMA20
            sma50 = float(recent["sma_50"].iloc[-1])  # Latest live SMA50
            last_close = float(recent["close"].iloc[-1])  # Latest live close
            price_vs_sma20 = (last_close - sma20) / sma20 if sma20 else 0.0  # From live data
            price_vs_sma50 = (last_close - sma50) / sma50 if sma50 else 0.0  # From live data

            # Classify cycle from live data (configuration thresholds, not fallback data)
            if price_trend > TREND_CHANGE_THRESHOLD and volume_trend > 0 and price_vs_sma20 > 0 and price_vs_sma50 > 0:
                (MarketCycle.MARKUP, min(1.0, (price_trend + max(volume_trend, 0)) / 2))  # Markup from live data
            elif price_trend < -TREND_CHANGE_THRESHOLD and volume_trend > 0 and price_vs_sma20 < 0 and price_vs_sma50 < 0:
                (MarketCycle.MARKDOWN, min(1.0, (abs(price_trend) + max(volume_trend, 0)) / 2))  # Markdown from live data
            elif volatility_level > float(recent["volatility"].quantile(VOLATILITY_QUANTILE)) and abs(price_trend) < 0.02:
                (MarketCycle.DISTRIBUTION, min(1.0, volatility_level * 2))  # Distribution from live data
            else:
                pass  # Accumulation from live data
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Market cycle detection failed for live symbol %s", symbol)
            return MarketCycle.ACCUMULATION, DEFAULT_ERROR_SCORE  # Error state (not fallback data)

    async def calculate_seasonality_score(self, symbol: str, timestamp: datetime | None = None) -> float:
        """
        Calculate seasonality score from configuration patterns (backend port 8000).

        Args:
            symbol: Live trading symbol
            timestamp: Optional timestamp (uses current time if None)

        Returns:
            Seasonality score from configuration patterns (not fallback data)
        """
        try:
            ts = timestamp or datetime.now(timezone.utc)  # Use live timestamp

            hourly = self.seasonality_patterns["hourly"]  # Configuration patterns
            daily = self.seasonality_patterns["daily"]  # Configuration patterns
            weekly = self.seasonality_patterns["weekly"]  # Configuration patterns
            monthly = self.seasonality_patterns["monthly"]  # Configuration patterns

            hour_score = float(hourly.get(ts.hour, DEFAULT_ERROR_SEASONALITY))  # From live time
            day_score = float(daily.get(ts.weekday(), DEFAULT_ERROR_SEASONALITY))  # From live time
            week_index = (ts.day - 1) // 7 + 1
            week_score = float(weekly.get(week_index, DEFAULT_ERROR_SEASONALITY))  # From live time
            month_score = float(monthly.get(ts.month, DEFAULT_ERROR_SEASONALITY))  # From live time

            # Calculate weighted average (configuration weights, not fallback data)
            return hour_score * SEASONALITY_HOURLY_WEIGHT + day_score * SEASONALITY_DAILY_WEIGHT + week_score * SEASONALITY_WEEKLY_WEIGHT + month_score * SEASONALITY_MONTHLY_WEIGHT
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Seasonality calculation failed for live symbol %s", symbol)
            return DEFAULT_ERROR_SEASONALITY  # Error state (not fallback data)

    async def analyze_market_regime(self, symbol: str, ohlcv_data: list[list[float]]) -> RegimeAnalysis:
        """
        Analyze complete market regime from live OHLCV data (backend port 8000).

        Args:
            symbol: Live trading symbol
            ohlcv_data: Live OHLCV data list

        Returns:
            RegimeAnalysis with all regime metrics from live data
        """
        try:
            vol_task = self.detect_volatility_regime(symbol, ohlcv_data)  # Detect from live data
            trend_task = self.detect_trend_strength(symbol, ohlcv_data)  # Detect from live data
            cycle_task = self.detect_market_cycle(symbol, ohlcv_data)  # Detect from live data
            seasonality_task = self.calculate_seasonality_score(symbol)  # Calculate from config patterns

            volatility_regime, volatility_score = await vol_task  # From live data
            trend_strength, trend_score = await trend_task  # From live data
            market_cycle, cycle_score = await cycle_task  # From live data
            seasonality_score = await seasonality_task  # From config patterns

            from backend.services.confidence_normalizer import ConfidenceNormalizer

            regime_confidence = ConfidenceNormalizer.normalize(float((volatility_score + trend_score + cycle_score + seasonality_score) / 4))  # Calculate from live data

            return RegimeAnalysis(
                symbol=symbol,  # Live symbol
                volatility_regime=volatility_regime,  # From live data
                trend_strength=trend_strength,  # From live data
                market_cycle=market_cycle,  # From live data
                volatility_score=volatility_score,  # From live data
                trend_score=trend_score,  # From live data
                cycle_score=cycle_score,  # From live data
                seasonality_score=seasonality_score,  # From config patterns
                regime_confidence=regime_confidence,  # From live data
                timestamp=datetime.now(timezone.utc),  # Live timestamp
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Market regime analysis failed for live symbol %s", symbol)
            # Error state return (not fallback data)
            return RegimeAnalysis(
                symbol=symbol,
                volatility_regime=VolatilityRegime.NORMAL,  # Error state (not fallback data)
                trend_strength=TrendStrength.SIDEWAYS,  # Error state (not fallback data)
                market_cycle=MarketCycle.ACCUMULATION,  # Error state (not fallback data)
                volatility_score=DEFAULT_ERROR_SCORE,  # Error state (not fallback data)
                trend_score=DEFAULT_ERROR_SCORE,  # Error state (not fallback data)
                cycle_score=DEFAULT_ERROR_SCORE,  # Error state (not fallback data)
                seasonality_score=DEFAULT_ERROR_SEASONALITY,  # Error state (not fallback data)
                regime_confidence=DEFAULT_ERROR_SCORE,  # Error state (not fallback data)
                timestamp=datetime.now(timezone.utc),  # Live timestamp
            )

    async def get_regime_recommendation(self, regime: RegimeAnalysis) -> dict[str, Any]:
        """
        Get trading recommendation from live regime analysis (backend port 8000).

        Args:
            regime: Live regime analysis result

        Returns:
            Dictionary with trading recommendation based on live regime
        """
        try:
            rec: dict[str, Any] = {
                "symbol": regime.symbol,  # Live symbol
                "exchange": EXCHANGE_ID,  # Live exchange ID
                "regime_summary": f"{regime.volatility_regime.value}_{regime.trend_strength.value}_{regime.market_cycle.value}",  # From live data
                "trading_recommendation": "HOLD",  # Default recommendation
                "position_size_multiplier": 1.0,  # Default multiplier
                "risk_level": "medium",  # Default risk level
                "reasoning": [],  # Live reasoning
                "timestamp": regime.timestamp.isoformat(),  # Live timestamp
            }

            # Adjust position size from live volatility regime (configuration factors, not fallback data)
            if regime.volatility_regime == VolatilityRegime.LOW:
                rec["position_size_multiplier"] = POSITION_BOOST_FACTOR  # Boost from live data
                rec["reasoning"].append("Low volatility from live data - can increase position size")
            elif regime.volatility_regime == VolatilityRegime.HIGH:
                rec["position_size_multiplier"] = POSITION_REDUCE_FACTOR  # Reduce from live data
                rec["reasoning"].append("High volatility from live data - reduce position size")
            elif regime.volatility_regime == VolatilityRegime.EXTREME:
                rec["position_size_multiplier"] = POSITION_MIN_FACTOR  # Minimum from live data
                rec["reasoning"].append("Extreme volatility from live data - minimal position size")
                rec["risk_level"] = "high"  # High risk from live data

            # Trading recommendation from live trend strength
            if regime.trend_strength in (
                TrendStrength.STRONG_BULL,
                TrendStrength.WEAK_BULL,
            ):
                rec["trading_recommendation"] = "BUY"  # From live trend
                rec["reasoning"].append(f"Bullish trend detected from live data: {regime.trend_strength.value}")
            elif regime.trend_strength in (
                TrendStrength.STRONG_BEAR,
                TrendStrength.WEAK_BEAR,
            ):
                rec["trading_recommendation"] = "SELL"  # From live trend
                rec["reasoning"].append(f"Bearish trend detected from live data: {regime.trend_strength.value}")
            else:
                rec["trading_recommendation"] = "HOLD"  # From live trend
                rec["reasoning"].append("Sideways market from live data - wait for clear direction")

            # Market cycle insights from live data
            if regime.market_cycle == MarketCycle.MARKUP:
                rec["reasoning"].append("Markup phase from live data - trend continuation likely")
            elif regime.market_cycle == MarketCycle.MARKDOWN:
                rec["reasoning"].append("Markdown phase from live data - trend continuation likely")
            elif regime.market_cycle == MarketCycle.ACCUMULATION:
                rec["reasoning"].append("Accumulation phase from live data - prepare for breakout")
            elif regime.market_cycle == MarketCycle.DISTRIBUTION:
                rec["reasoning"].append("Distribution phase from live data - prepare for breakdown")

            # Seasonality adjustments (configuration thresholds, not fallback data)
            if regime.seasonality_score > FAVORABLE_SEASONALITY_THRESHOLD:
                rec["reasoning"].append("Favorable seasonality - increased activity expected")
                rec["position_size_multiplier"] *= SEASONALITY_BOOST_FACTOR  # Boost from config patterns
            elif regime.seasonality_score < UNFAVORABLE_SEASONALITY_THRESHOLD:
                rec["reasoning"].append("Unfavorable seasonality - reduced activity expected")
                rec["position_size_multiplier"] *= SEASONALITY_REDUCE_FACTOR  # Reduce from config patterns

            # Risk level from live regime confidence (configuration thresholds, not fallback data)
            if regime.regime_confidence < LOW_CONFIDENCE_THRESHOLD:
                rec["risk_level"] = "high"  # High risk from live data
                rec["reasoning"].append("Low regime confidence from live data - high uncertainty")
            elif regime.regime_confidence > HIGH_CONFIDENCE_THRESHOLD:
                rec["risk_level"] = "low"  # Low risk from live data
                rec["reasoning"].append("High regime confidence from live data - clear market state")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Regime recommendation failed for live symbol %s", regime.symbol)
            return {
                "symbol": regime.symbol,
                "exchange": EXCHANGE_ID,
                "regime_summary": "unknown",
                "trading_recommendation": "HOLD",  # Error state (not fallback data)
                "position_size_multiplier": 1.0,  # Error state (not fallback data)
                "risk_level": "high",  # Error state (not fallback data)
                "reasoning": ["Error in live regime analysis"],
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }


__all__ = [
    "EXCHANGE_ID",
    "MarketCycle",
    "MarketRegimeDetector",
    "RegimeAnalysis",
    "TrendStrength",
    "VolatilityRegime",
    "_to_ccxt_symbol",
]
