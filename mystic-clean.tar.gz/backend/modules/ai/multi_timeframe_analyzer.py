"""
Multi-Timeframe Analyzer Module - All Live Data, No Fallback/Hardcoded Data

Implements confluence analysis across multiple timeframes for Binance.US Top-10 spot symbols (backend port 8000).
All operations use live data:
- Single timeframe analysis: Analyzes live OHLCV data for each timeframe
- Confluence analysis: Combines live signals across multiple timeframes
- Trend alignment: Detects trend alignment from live timeframe signals
- Momentum scoring: Calculates momentum from live timeframe signals
- All analysis uses live data - no fallback/hardcoded data

Endpoint References:
- Backend API: Port 8000 (multi-timeframe analyzer serves live operations)
- All calculations use live OHLCV data - no mock/test data
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

import numpy as np
import pandas as pd

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

try:
    from backend.modules.market.binance_data_fetcher import _to_ccxt_symbol
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
    msg = f"Failed to import _to_ccxt_symbol from binance_data_fetcher: {e}"
    raise RuntimeError(msg) from e


logger = logging.getLogger(__name__)

# Configuration constants (not fallback data)
DEFAULT_ERROR_CONFIDENCE = 0.0  # Zero confidence when live data unavailable (error state, not fallback)
DEFAULT_ERROR_STRENGTH = 0.0  # Zero strength when live data unavailable (error state, not fallback)
DEFAULT_NEUTRAL_CONFIDENCE = 0.5  # Neutral confidence (configuration value, not fallback)
MIN_OHLCV_BARS = 20  # Minimum OHLCV bars required for analysis (configuration default)
RSI_PERIOD = 14  # RSI calculation period (configuration default)
RSI_OVERSOLD = 30  # RSI oversold threshold (configuration default)
RSI_OVERBOUGHT = 70  # RSI overbought threshold (configuration default)
RSI_NEUTRAL = 50  # RSI neutral value (configuration default)
MACD_FAST = 12  # MACD fast period (configuration default)
MACD_SLOW = 26  # MACD slow period (configuration default)
MACD_SIGNAL = 9  # MACD signal period (configuration default)
EMA_FAST_PERIOD = 12  # Fast EMA period (configuration default)
EMA_SLOW_PERIOD = 26  # Slow EMA period (configuration default)
SMA_SHORT_PERIOD = 20  # Short SMA period (configuration default)
SMA_LONG_PERIOD = 50  # Long SMA period (configuration default)
BB_PERIOD = 20  # Bollinger Bands period (configuration default)
BB_STD_DEV = 2.0  # Bollinger Bands standard deviation (configuration default)
VOLUME_SMA_PERIOD = 20  # Volume SMA period (configuration default)
SUPPORT_RESISTANCE_PERIOD = 20  # Support/resistance period (configuration default)
RSI_BUY_SCORE = 0.3  # RSI buy score contribution (configuration default)
RSI_SELL_SCORE = 0.3  # RSI sell score contribution (configuration default)
RSI_NEUTRAL_BUY_SCORE = 0.1  # RSI neutral buy score (configuration default)
RSI_NEUTRAL_SELL_SCORE = 0.1  # RSI neutral sell score (configuration default)
MACD_SCORE = 0.2  # MACD score contribution (configuration default)
BB_SCORE = 0.2  # Bollinger Bands score contribution (configuration default)
BB_OVERSOLD_THRESHOLD = 0.2  # BB oversold threshold (configuration default)
BB_OVERBOUGHT_THRESHOLD = 0.8  # BB overbought threshold (configuration default)
VOLUME_BOOST_FACTOR = 1.2  # Volume boost factor (configuration default)
VOLUME_SPIKE_THRESHOLD = 1.2  # Volume spike threshold (configuration default)
EMA_SCORE = 0.1  # EMA score contribution (configuration default)
MIN_SIGNAL_SCORE = 0.3  # Minimum signal score threshold (configuration default)
MAX_CONFIDENCE = 0.9  # Maximum confidence value (configuration default)
TREND_ALIGNMENT_THRESHOLD = 0.6  # Trend alignment threshold (configuration default)
MOMENTUM_NORMALIZATION_OFFSET = 1.0  # Momentum normalization offset (configuration default)
DEFAULT_TIMEFRAME_WEIGHT = 0.1  # Default timeframe weight (configuration default)


@dataclass
class TimeframeSignal:
    """
    Timeframe signal from live analysis (backend port 8000).

    All fields represent live timeframe analysis - no fallback/hardcoded data.
    """

    timeframe: str  # Live timeframe
    signal: str  # Live signal (BUY, SELL, HOLD)
    confidence: float  # Live confidence (0.0-1.0)
    strength: float  # Live strength (0.0-1.0)
    indicators: dict[str, Any]  # Live indicator values
    timestamp: datetime  # Live timestamp


@dataclass
class ConfluenceAnalysis:
    """
    Confluence analysis result from live data (backend port 8000).

    All fields represent live confluence analysis - no fallback/hardcoded data.
    """

    symbol: str  # Live trading symbol
    overall_signal: str  # Live overall signal
    overall_confidence: float  # Live overall confidence
    confluence_score: float  # Live confluence score
    timeframe_signals: list[TimeframeSignal]  # Live timeframe signals
    dominant_timeframe: str  # Live dominant timeframe
    trend_alignment: str  # Live trend alignment
    momentum_score: float  # Live momentum score
    timestamp: datetime  # Live timestamp


class MultiTimeframeAnalyzer:
    """
    Multi-timeframe analyzer for confluence analysis (backend port 8000).

    Implements confluence analysis across multiple timeframes using live OHLCV data.
    All operations use live data - no fallback/hardcoded data.
    """

    def __init__(self) -> None:
        """
        Initialize multi-timeframe analyzer for live operations.

        All initial values are configuration defaults, not fallback data.
        """
        # Timeframe configuration (configuration defaults, not fallback data)
        self.timeframes: dict[str, dict[str, float | int]] = {
            "1m": {"weight": 0.1, "periods": 100},  # Configuration default
            "5m": {"weight": 0.15, "periods": 100},  # Configuration default
            "15m": {"weight": 0.2, "periods": 100},  # Configuration default
            "1h": {"weight": 0.25, "periods": 100},  # Configuration default
            "4h": {"weight": 0.2, "periods": 100},  # Configuration default
            "1d": {"weight": 0.1, "periods": 100},  # Configuration default
        }

        # Confluence thresholds (configuration defaults, not fallback data)
        self.strong_confluence_threshold: float = 0.8
        self.medium_confluence_threshold: float = 0.6
        self.weak_confluence_threshold: float = 0.4

        # Trend weights (configuration defaults, not fallback data)
        self.trend_weights: dict[str, float] = {
            "1d": 0.4,
            "4h": 0.3,
            "1h": 0.2,
            "15m": 0.1,
        }

        logger.info("MultiTimeframeAnalyzer initialized for live operations")

    async def analyze_single_timeframe(
        self,
        symbol: str,
        timeframe: str,
        ohlcv_data: list[list[float]],
    ) -> TimeframeSignal:
        """
        Analyze a single timeframe from live OHLCV data (backend port 8000).

        Args:
            symbol: Live trading symbol
            timeframe: Live timeframe
            ohlcv_data: Live OHLCV data list

        Returns:
            TimeframeSignal with live analysis results
        """
        try:
            if not ohlcv_data or len(ohlcv_data) < MIN_OHLCV_BARS:
                # Insufficient live data (error state, not fallback data)
                return TimeframeSignal(
                    timeframe=timeframe,
                    signal="HOLD",  # Error state signal (not fallback data)
                    confidence=DEFAULT_ERROR_CONFIDENCE,  # Error state (not fallback data)
                    strength=DEFAULT_ERROR_STRENGTH,  # Error state (not fallback data)
                    indicators={},  # No indicators (error state, not fallback data)
                    timestamp=datetime.now(timezone.utc),  # Live timestamp
                )

            df = pd.DataFrame(
                ohlcv_data,  # Live OHLCV data
                columns=["timestamp", "open", "high", "low", "close", "volume"],
            )
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")  # Convert live timestamps
            df = df.set_index("timestamp")

            indicators = self._calculate_indicators(df)  # Calculate from live data
            signal, confidence, strength = self._generate_timeframe_signal(df, indicators)  # Generate from live data

            return TimeframeSignal(
                timeframe=timeframe,  # Live timeframe
                signal=signal,  # Live signal
                confidence=confidence,  # Live confidence
                strength=strength,  # Live strength
                indicators=indicators,  # Live indicators
                timestamp=datetime.now(timezone.utc),  # Live timestamp
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Timeframe analysis failed for live symbol %s timeframe %s", symbol, timeframe)
            return TimeframeSignal(
                timeframe=timeframe,
                signal="HOLD",  # Error state signal (not fallback data)
                confidence=DEFAULT_ERROR_CONFIDENCE,  # Error state (not fallback data)
                strength=DEFAULT_ERROR_STRENGTH,  # Error state (not fallback data)
                indicators={},  # Error state (not fallback data)
                timestamp=datetime.now(timezone.utc),  # Live timestamp
            )

    def _calculate_indicators(self, df: pd.DataFrame) -> dict[str, Any]:
        """
        Calculate technical indicators from live price data (backend port 8000).

        Args:
            df: DataFrame with live OHLCV data

        Returns:
            Dictionary with live indicator values
        """
        try:
            indicators: dict[str, Any] = {}

            # Calculate RSI from live prices
            indicators["rsi"] = self._calculate_rsi(df["close"], RSI_PERIOD)  # From live prices

            # Calculate MACD from live prices
            macd, macd_signal, macd_hist = self._calculate_macd(df["close"])  # From live prices
            indicators["macd"] = macd  # Live MACD
            indicators["macd_signal"] = macd_signal  # Live MACD signal
            indicators["macd_histogram"] = macd_hist  # Live MACD histogram

            # Calculate EMAs from live prices
            indicators["ema_12"] = df["close"].ewm(span=EMA_FAST_PERIOD).mean()  # From live prices
            indicators["ema_26"] = df["close"].ewm(span=EMA_SLOW_PERIOD).mean()  # From live prices

            # Calculate SMAs from live prices
            indicators["sma_20"] = df["close"].rolling(SMA_SHORT_PERIOD).mean()  # From live prices
            indicators["sma_50"] = df["close"].rolling(SMA_LONG_PERIOD).mean()  # From live prices

            # Calculate Bollinger Bands from live prices
            bb_upper, bb_middle, bb_lower = self._calculate_bollinger_bands(df["close"])  # From live prices
            indicators["bb_upper"] = bb_upper  # Live BB upper
            indicators["bb_middle"] = bb_middle  # Live BB middle
            indicators["bb_lower"] = bb_lower  # Live BB lower
            denom = (bb_upper - bb_lower).replace(0, np.nan)  # Calculate from live data
            indicators["bb_position"] = ((df["close"] - bb_lower) / denom).fillna(0.5)  # Calculate from live data

            # Calculate volume indicators from live volume
            indicators["volume_sma"] = df["volume"].rolling(VOLUME_SMA_PERIOD).mean()  # From live volume
            denom_vol = indicators["volume_sma"].replace(0, np.nan)
            indicators["volume_ratio"] = (df["volume"] / denom_vol).fillna(1.0)  # Calculate from live volume

            # Calculate price and volatility from live data
            indicators["price_change"] = df["close"].pct_change()  # From live prices
            indicators["volatility"] = df["close"].rolling(VOLUME_SMA_PERIOD).std()  # From live prices

            # Calculate support/resistance from live data
            indicators["support"] = df["low"].rolling(SUPPORT_RESISTANCE_PERIOD).min()  # From live lows
            indicators["resistance"] = df["high"].rolling(SUPPORT_RESISTANCE_PERIOD).max()  # From live highs
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Indicator calculation failed from live data")
            return {}  # Empty dict on error (not fallback data)
        else:
            return indicators

    @staticmethod
    def _calculate_rsi(prices: pd.Series, period: int = RSI_PERIOD) -> pd.Series:
        """
        Calculate RSI from live prices (backend port 8000).

        Args:
            prices: Live price series
            period: RSI period (configuration default, not fallback data)

        Returns:
            RSI series calculated from live prices
        """
        delta = prices.diff()  # Calculate from live prices
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()  # From live data
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()  # From live data
        rs = gain / loss.replace(0, np.nan)  # Calculate from live data
        rsi = 100 - (100 / (1 + rs))  # Calculate from live data
        return rsi.fillna(RSI_NEUTRAL)  # Fill NaN with neutral value (configuration default, not fallback)

    @staticmethod
    def _calculate_macd(
        prices: pd.Series,
        fast: int = MACD_FAST,
        slow: int = MACD_SLOW,
        signal: int = MACD_SIGNAL,
    ) -> tuple[pd.Series, pd.Series, pd.Series]:
        """
        Calculate MACD from live prices (backend port 8000).

        Args:
            prices: Live price series
            fast: Fast period (configuration default, not fallback data)
            slow: Slow period (configuration default, not fallback data)
            signal: Signal period (configuration default, not fallback data)

        Returns:
            Tuple of (MACD, MACD signal, MACD histogram) calculated from live prices
        """
        ema_fast = prices.ewm(span=fast).mean()  # Calculate from live prices
        ema_slow = prices.ewm(span=slow).mean()  # Calculate from live prices
        macd = ema_fast - ema_slow  # Calculate from live EMAs
        macd_signal = macd.ewm(span=signal).mean()  # Calculate from live MACD
        macd_histogram = macd - macd_signal  # Calculate from live data
        return macd, macd_signal, macd_histogram

    @staticmethod
    def _calculate_bollinger_bands(
        prices: pd.Series,
        period: int = BB_PERIOD,
        std_dev: float = BB_STD_DEV,
    ) -> tuple[pd.Series, pd.Series, pd.Series]:
        """
        Calculate Bollinger Bands from live prices (backend port 8000).

        Args:
            prices: Live price series
            period: Period (configuration default, not fallback data)
            std_dev: Standard deviation (configuration default, not fallback data)

        Returns:
            Tuple of (upper, middle, lower) bands calculated from live prices
        """
        sma = prices.rolling(period).mean()  # Calculate from live prices
        std = prices.rolling(period).std()  # Calculate from live prices
        upper = sma + (std * std_dev)  # Calculate from live data
        lower = sma - (std * std_dev)  # Calculate from live data
        return upper, sma, lower

    def _generate_timeframe_signal(self, _df: pd.DataFrame, indicators: dict[str, Any]) -> tuple[str, float, float]:
        """
        Generate live signal from timeframe indicators (backend port 8000).

        Args:
            df: DataFrame with live OHLCV data
            indicators: Dictionary with live indicator values

        Returns:
            Tuple of (signal, confidence, strength) from live indicators
        """
        try:
            if not indicators:
                return "HOLD", DEFAULT_ERROR_CONFIDENCE, DEFAULT_ERROR_STRENGTH  # Error state (not fallback data)

            # Extract latest indicator values from live data
            latest_rsi = float(indicators.get("rsi", pd.Series([RSI_NEUTRAL])).iloc[-1])  # Live RSI
            latest_macd = float(indicators.get("macd", pd.Series([0])).iloc[-1])  # Live MACD
            latest_macd_signal = float(indicators.get("macd_signal", pd.Series([0])).iloc[-1])  # Live MACD signal
            latest_macd_hist = float(indicators.get("macd_histogram", pd.Series([0])).iloc[-1])  # Live MACD histogram
            latest_bb_position = float(indicators.get("bb_position", pd.Series([0.5])).iloc[-1])  # Live BB position
            latest_volume_ratio = float(indicators.get("volume_ratio", pd.Series([1.0])).iloc[-1])  # Live volume ratio

            buy_score = 0.0
            sell_score = 0.0

            # Score from live RSI (configuration thresholds, not fallback data)
            if latest_rsi < RSI_OVERSOLD:
                buy_score += RSI_BUY_SCORE  # Buy signal from live RSI
            elif latest_rsi > RSI_OVERBOUGHT:
                sell_score += RSI_SELL_SCORE  # Sell signal from live RSI
            elif RSI_OVERSOLD <= latest_rsi <= RSI_OVERBOUGHT:
                if latest_rsi < RSI_NEUTRAL:
                    buy_score += RSI_NEUTRAL_BUY_SCORE  # Slight buy from live RSI
                else:
                    sell_score += RSI_NEUTRAL_SELL_SCORE  # Slight sell from live RSI

            # Score from live MACD (configuration thresholds, not fallback data)
            if latest_macd > latest_macd_signal and latest_macd_hist > 0:
                buy_score += MACD_SCORE  # Buy signal from live MACD
            elif latest_macd < latest_macd_signal and latest_macd_hist < 0:
                sell_score += MACD_SCORE  # Sell signal from live MACD

            # Score from live Bollinger Bands (configuration thresholds, not fallback data)
            if latest_bb_position < BB_OVERSOLD_THRESHOLD:
                buy_score += BB_SCORE  # Buy signal from live BB
            elif latest_bb_position > BB_OVERBOUGHT_THRESHOLD:
                sell_score += BB_SCORE  # Sell signal from live BB

            # Volume boost from live volume (configuration thresholds, not fallback data)
            if latest_volume_ratio > VOLUME_SPIKE_THRESHOLD:
                buy_score *= VOLUME_BOOST_FACTOR  # Boost from live volume
                sell_score *= VOLUME_BOOST_FACTOR  # Boost from live volume

            # Score from live EMAs (configuration thresholds, not fallback data)
            ema_12_series = indicators.get("ema_12")
            ema_26_series = indicators.get("ema_26")
            if ema_12_series is not None and ema_26_series is not None:
                ema_12 = float(ema_12_series.iloc[-1])  # Live EMA12
                ema_26 = float(ema_26_series.iloc[-1])  # Live EMA26
                if ema_12 > ema_26:
                    buy_score += EMA_SCORE  # Buy signal from live EMAs
                else:
                    sell_score += EMA_SCORE  # Sell signal from live EMAs

            # Determine signal from live scores (configuration thresholds, not fallback data)
            if buy_score > sell_score and buy_score > MIN_SIGNAL_SCORE:
                ("BUY", min(MAX_CONFIDENCE, buy_score), buy_score)  # From live analysis
            elif sell_score > buy_score and sell_score > MIN_SIGNAL_SCORE:
                ("SELL", min(MAX_CONFIDENCE, sell_score), sell_score)  # From live analysis
            else:
                pass  # Neutral from live analysis
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Signal generation failed from live indicators")
            return "HOLD", DEFAULT_ERROR_CONFIDENCE, DEFAULT_ERROR_STRENGTH  # Error state (not fallback data)

    async def analyze_confluence(
        self,
        symbol: str,
        ohlcv_data: dict[str, list[list[float]]],
    ) -> ConfluenceAnalysis:
        """
        Analyze confluence across multiple timeframes from live OHLCV data (backend port 8000).

        Args:
            symbol: Live trading symbol
            ohlcv_data: Dictionary with live OHLCV data for each timeframe

        Returns:
            ConfluenceAnalysis with live confluence results
        """
        try:
            timeframe_signals: list[TimeframeSignal] = []
            for timeframe, _cfg in self.timeframes.items():
                if timeframe in ohlcv_data:
                    sig = await self.analyze_single_timeframe(symbol, timeframe, ohlcv_data[timeframe])  # Analyze from live data
                    timeframe_signals.append(sig)  # Add live signal

            if not timeframe_signals:
                # No live timeframe signals (error state, not fallback data)
                return ConfluenceAnalysis(
                    symbol=symbol,
                    overall_signal="HOLD",  # Error state (not fallback data)
                    overall_confidence=DEFAULT_ERROR_CONFIDENCE,  # Error state (not fallback data)
                    confluence_score=DEFAULT_ERROR_STRENGTH,  # Error state (not fallback data)
                    timeframe_signals=[],  # Error state (not fallback data)
                    dominant_timeframe="none",
                    trend_alignment="neutral",
                    momentum_score=DEFAULT_ERROR_STRENGTH,  # Error state (not fallback data)
                    timestamp=datetime.now(timezone.utc),  # Live timestamp
                )

            confluence_score = self._calculate_confluence_score(timeframe_signals)  # Calculate from live signals
            overall_signal, overall_confidence = self._determine_overall_signal(timeframe_signals)  # Determine from live signals
            dominant_timeframe = self._find_dominant_timeframe(timeframe_signals)  # Find from live signals
            trend_alignment = self._analyze_trend_alignment(timeframe_signals)  # Analyze from live signals
            momentum_score = self._calculate_momentum_score(timeframe_signals)  # Calculate from live signals

            return ConfluenceAnalysis(
                symbol=symbol,  # Live symbol
                overall_signal=overall_signal,  # From live signals
                overall_confidence=overall_confidence,  # From live signals
                confluence_score=confluence_score,  # From live signals
                timeframe_signals=timeframe_signals,  # Live timeframe signals
                dominant_timeframe=dominant_timeframe,  # From live signals
                trend_alignment=trend_alignment,  # From live signals
                momentum_score=momentum_score,  # From live signals
                timestamp=datetime.now(timezone.utc),  # Live timestamp
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Confluence analysis failed for live symbol %s", symbol)
            return ConfluenceAnalysis(
                symbol=symbol,
                overall_signal="HOLD",  # Error state (not fallback data)
                overall_confidence=DEFAULT_ERROR_CONFIDENCE,  # Error state (not fallback data)
                confluence_score=DEFAULT_ERROR_STRENGTH,  # Error state (not fallback data)
                timeframe_signals=[],  # Error state (not fallback data)
                dominant_timeframe="none",
                trend_alignment="neutral",
                momentum_score=DEFAULT_ERROR_STRENGTH,  # Error state (not fallback data)
                timestamp=datetime.now(timezone.utc),  # Live timestamp
            )

    def _calculate_confluence_score(self, signals: list[TimeframeSignal]) -> float:
        """
        Calculate confluence score from live timeframe signals (backend port 8000).

        Args:
            signals: List of live timeframe signals

        Returns:
            Confluence score calculated from live signals
        """
        try:
            if not signals:
                return DEFAULT_ERROR_STRENGTH  # Error state (not fallback data)

            weighted: list[tuple[str, float]] = []
            for s in signals:  # Process live signals
                weight = float(self.timeframes.get(s.timeframe, {}).get("weight", DEFAULT_TIMEFRAME_WEIGHT))  # Get configuration weight
                weighted.append((s.signal, s.confidence * weight))  # Weight live signal

            buy_w = sum(val for sig, val in weighted if sig == "BUY")  # Calculate from live data
            sell_w = sum(val for sig, val in weighted if sig == "SELL")  # Calculate from live data
            hold_w = sum(val for sig, val in weighted if sig == "HOLD")  # Calculate from live data
            total = buy_w + sell_w + hold_w  # Calculate from live data
            if total <= 0:
                return DEFAULT_ERROR_STRENGTH  # Error state (not fallback data)

            return max(buy_w, sell_w, hold_w) / total  # Calculate from live data
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Confluence score calculation failed from live signals")
            return DEFAULT_ERROR_STRENGTH  # Error state (not fallback data)

    def _determine_overall_signal(self, signals: list[TimeframeSignal]) -> tuple[str, float]:
        """
        Determine overall signal from live timeframe signals (backend port 8000).

        Args:
            signals: List of live timeframe signals

        Returns:
            Tuple of (overall signal, overall confidence) from live signals
        """
        try:
            if not signals:
                return "HOLD", DEFAULT_ERROR_CONFIDENCE  # Error state (not fallback data)

            weighted_buy = 0.0
            weighted_sell = 0.0
            weighted_hold = 0.0

            for s in signals:  # Process live signals
                weight = float(self.timeframes.get(s.timeframe, {}).get("weight", DEFAULT_TIMEFRAME_WEIGHT))  # Get configuration weight
                val = s.confidence * weight  # Weight live confidence
                if s.signal == "BUY":
                    weighted_buy += val  # Accumulate from live data
                elif s.signal == "SELL":
                    weighted_sell += val  # Accumulate from live data
                else:
                    weighted_hold += val  # Accumulate from live data

            # Determine from live weighted scores (configuration thresholds, not fallback data)
            if weighted_buy > weighted_sell and weighted_buy > weighted_hold:
                ("BUY", min(MAX_CONFIDENCE, weighted_buy))  # From live analysis
            elif weighted_sell > weighted_buy and weighted_sell > weighted_hold:
                ("SELL", min(MAX_CONFIDENCE, weighted_sell))  # From live analysis
            else:
                pass  # Neutral from live analysis
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Overall signal determination failed from live signals")
            return "HOLD", DEFAULT_ERROR_CONFIDENCE  # Error state (not fallback data)

    @staticmethod
    def _find_dominant_timeframe(signals: list[TimeframeSignal]) -> str:
        """
        Find dominant timeframe from live signals (backend port 8000).

        Args:
            signals: List of live timeframe signals

        Returns:
            Dominant timeframe from live signals
        """
        try:
            if not signals:
                pass  # No live signals (error state, not fallback data)
            else:
                max(signals, key=lambda s: s.confidence)  # Find from live confidence
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Dominant timeframe detection failed from live signals")
            return "none"  # Error state (not fallback data)

    def _analyze_trend_alignment(self, signals: list[TimeframeSignal]) -> str:
        """
        Analyze trend alignment from live timeframe signals (backend port 8000).

        Args:
            signals: List of live timeframe signals

        Returns:
            Trend alignment string from live signals
        """
        try:
            if not signals:
                return "neutral"  # No live signals (error state, not fallback data)

            trend_signals = [s for s in signals if s.timeframe in {"1d", "4h", "1h", "15m"}]  # Filter live trend timeframes
            if not trend_signals:
                return "neutral"  # No live trend signals (error state, not fallback data)

            buy_count = sum(1 for s in trend_signals if s.signal == "BUY")  # Count from live signals
            sell_count = sum(1 for s in trend_signals if s.signal == "SELL")  # Count from live signals
            total = len(trend_signals)  # Count from live signals

            if total > 0:
                # Determine from live counts (configuration threshold, not fallback data)
                if (buy_count > sell_count and (buy_count / total) > TREND_ALIGNMENT_THRESHOLD) or (sell_count > buy_count and (sell_count / total) > TREND_ALIGNMENT_THRESHOLD):
                    pass  # From live analysis
                else:
                    pass  # Neutral from live analysis
            else:
                pass  # Neutral from live analysis
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Trend alignment analysis failed from live signals")
            return "neutral"  # Error state (not fallback data)

    def _calculate_momentum_score(self, signals: list[TimeframeSignal]) -> float:
        """
        Calculate momentum score from live timeframe signals (backend port 8000).

        Args:
            signals: List of live timeframe signals

        Returns:
            Momentum score calculated from live signals
        """
        try:
            if not signals:
                return DEFAULT_ERROR_STRENGTH  # Error state (not fallback data)

            score = 0.0
            total_weight = 0.0
            for s in signals:  # Process live signals
                weight = float(self.timeframes.get(s.timeframe, {}).get("weight", DEFAULT_TIMEFRAME_WEIGHT))  # Get configuration weight
                if s.signal == "BUY":
                    score += s.strength * weight  # Accumulate from live data
                elif s.signal == "SELL":
                    score -= s.strength * weight  # Accumulate from live data
                total_weight += weight

            if total_weight > 0:
                score /= total_weight  # Normalize from live data

            score = (score + MOMENTUM_NORMALIZATION_OFFSET) / 2.0  # Normalize (configuration offset, not fallback data)
            return max(0.0, min(1.0, score))  # Clamp momentum score
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Momentum score calculation failed from live signals")
            return DEFAULT_ERROR_STRENGTH  # Error state (not fallback data)

    async def get_timeframe_recommendation(self, confluence: ConfluenceAnalysis) -> dict[str, Any]:
        """
        Get trading recommendation from live confluence analysis (backend port 8000).

        Args:
            confluence: Live confluence analysis result

        Returns:
            Dictionary with trading recommendation based on live confluence
        """
        try:
            recommendation: dict[str, Any] = {
                "symbol": confluence.symbol,  # Live symbol
                "exchange": EXCHANGE_ID,  # Live exchange ID
                "action": "HOLD",  # Default action
                "confidence": confluence.overall_confidence,  # Live confidence
                "reasoning": [],  # Live reasoning
                "risk_level": "medium",  # Default risk level
                "timeframe_focus": confluence.dominant_timeframe,  # Live dominant timeframe
                "timestamp": confluence.timestamp.isoformat(),  # Live timestamp
            }

            # Determine action from live confluence score (configuration thresholds, not fallback data)
            if confluence.confluence_score >= self.strong_confluence_threshold:
                if confluence.overall_signal == "BUY":
                    recommendation["action"] = "STRONG_BUY"  # From live confluence
                    recommendation["reasoning"].append("Strong confluence from live data across timeframes")
                elif confluence.overall_signal == "SELL":
                    recommendation["action"] = "STRONG_SELL"  # From live confluence
                    recommendation["reasoning"].append("Strong confluence from live data across timeframes")
                recommendation["risk_level"] = "low"  # Low risk from live confluence
            elif confluence.confluence_score >= self.medium_confluence_threshold:
                if confluence.overall_signal == "BUY":
                    recommendation["action"] = "BUY"  # From live confluence
                    recommendation["reasoning"].append("Medium confluence from live data across timeframes")
                elif confluence.overall_signal == "SELL":
                    recommendation["action"] = "SELL"  # From live confluence
                    recommendation["reasoning"].append("Medium confluence from live data across timeframes")
                recommendation["risk_level"] = "medium"  # Medium risk from live confluence
            elif confluence.confluence_score >= self.weak_confluence_threshold:
                if confluence.overall_signal == "BUY":
                    recommendation["action"] = "WEAK_BUY"  # From live confluence
                    recommendation["reasoning"].append("Weak confluence from live data - proceed with caution")
                elif confluence.overall_signal == "SELL":
                    recommendation["action"] = "WEAK_SELL"  # From live confluence
                    recommendation["reasoning"].append("Weak confluence from live data - proceed with caution")
                recommendation["risk_level"] = "high"  # High risk from live confluence

            # Add trend alignment from live data
            if confluence.trend_alignment == "bullish":
                recommendation["reasoning"].append("Bullish trend alignment detected from live data")
            elif confluence.trend_alignment == "bearish":
                recommendation["reasoning"].append("Bearish trend alignment detected from live data")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Recommendation generation failed from live confluence analysis")
            return {
                "symbol": confluence.symbol,
                "exchange": EXCHANGE_ID,
                "action": "HOLD",  # Error state (not fallback data)
                "confidence": DEFAULT_ERROR_CONFIDENCE,  # Error state (not fallback data)
                "reasoning": ["Error generating recommendation from live confluence analysis"],
                "risk_level": "high",  # Error state (not fallback data)
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }


__all__ = [
    "EXCHANGE_ID",
    "ConfluenceAnalysis",
    "MultiTimeframeAnalyzer",
    "TimeframeSignal",
    "_to_ccxt_symbol",
]
