"""
Multiversal Liquidity Engine Module - All Live Data, No Fallback/Hardcoded Data

Analyzes live liquidity on Binance.US and surfaces best execution paths
for Binance.US Top-10 spot symbols (backend port 8000).
All operations use live data:
- Order book analysis: Analyzes live order books from Binance.US
- Liquidity capacity: Calculates capacity from live order book depth
- Arbitrage opportunities: Detects best execution opportunities from live spreads
- All calculations use live data - no fallback/hardcoded data

Rules enforced in this module:
- Single-source-of-truth constants: EXCHANGE_ID = "binance_us"
- One _to_ccxt_symbol() helper imported and used to format ccxt symbols (BASE/QUOTE only)
- No ad-hoc exchange strings or leaks of "binance"/"binanceus" — only EXCHANGE_ID
- ccxt calls receive symbols strictly as "BASE/QUOTE"
- Logging has no special characters
- Top 10 coins are the only monitored assets (should import from trading_universe when available)

Endpoint References:
- Backend API: Port 8000 (liquidity engine serves live operations)
- Binance.US API: Live order book data via CCXT
- Canonical Cache: Live signal storage
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime, timezone
from typing import Any

# Single source of truth for exchange id + symbol helper
# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID, TOP10_COINS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

try:
    from backend.modules.market.binance_data_fetcher import _to_ccxt_symbol
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import _to_ccxt_symbol from binance_data_fetcher: {e}"
    raise RuntimeError(msg) from e


from backend.services.canonical_cache import canonical_cache

logger = logging.getLogger(__name__)

# Optional ccxt import (we will handle absence gracefully)
try:
    import ccxt  # type: ignore[import-not-found]

    CCXT_AVAILABLE = True
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError, ImportError):
    CCXT_AVAILABLE = False
    logger.warning("ccxt not available. Install with: pip install ccxt")

# Signals / strategy constants (configuration defaults, not fallback data)
SIGNAL_TYPE_ARBITRAGE = "ARBITRAGE_OPPORTUNITY"
STRATEGY_ID = "multiversal_liquidity"

# Top 10 coins (BASE symbols only) - from trading_universe (live data)
TOP10_BASES: list[str] = list(TOP10_COINS)

# Configuration constants (not fallback data)
ORDER_BOOK_FETCH_DELAY = 0.05  # Delay between order book fetches (configuration default)
DEFAULT_ERROR_CAPACITY = 0.0  # Zero capacity when unavailable (error state, not fallback)
DEFAULT_ERROR_PRICE = 0.0  # Zero price when unavailable (error state, not fallback)
BEST_EXECUTION_SCORE_CAPACITY_NORMALIZATION = 1.0  # Capacity normalization factor (configuration default)


class MultiversalLiquidityEngine:
    """
    Multiversal liquidity engine for live liquidity analysis (backend port 8000).

    Analyzes live liquidity on Binance.US and surfaces best execution paths.
    All operations use live data - no fallback/hardcoded data.
    """

    def __init__(self) -> None:
        """
        Initialize liquidity engine using a single supported venue for live operations.

        All initial values are configuration defaults or live state, not fallback data.
        """
        self.cache = canonical_cache  # Live cache for signals

        # Venue configuration (single venue aligned to EXCHANGE_ID)
        self.venue_key = EXCHANGE_ID  # Live canonical id
        self.venue_name = EXCHANGE_ID  # Live canonical id in outputs

        # Get live API credentials from environment variables
        self.api_key = os.getenv("BINANCE_API_KEY", "")  # Live API key (empty if not set)
        self.api_secret = os.getenv("BINANCE_SECRET", "")  # Live API secret (empty if not set)

        # Trading parameters (configuration defaults, not fallback data)
        self.min_arbitrage_spread: float = 0.003  # 0.3% minimum spread
        self.max_slippage: float = 0.001  # 0.1% maximum slippage
        self.min_volume_usd: float = 100.0  # Minimum volume in USD
        self.max_volume_usd: float = 10000.0  # Maximum volume in USD

        # Symbols monitored (constructed strictly as BASE/QUOTE from live configuration)
        self.quote_asset = "USDT"  # Configuration default quote asset
        self.top_symbols: list[str] = [_to_ccxt_symbol(base, self.quote_asset) for base in TOP10_BASES]  # Live symbols

        # ccxt exchange instance (single venue)
        self._exchange = None  # Live exchange instance
        self._init_exchange()

        logger.info("MultiversalLiquidityEngine initialized for live operations")

    def _init_exchange(self) -> None:
        """
        Initialize exchange instance for the single supported venue with proper async pattern (backend port 8000).

        Initializes live exchange connection to Binance.US API.
        """
        try:
            if not CCXT_AVAILABLE:
                logger.warning("ccxt is not available - engine will operate in degraded mode")
                return

            # Derive ccxt class name from EXCHANGE_ID without leaking "binanceus" literals
            # Example: "binance_us" -> "binanceus"
            ccxt_class_name = EXCHANGE_ID.replace("_", "")  # Configuration mapping
            if not hasattr(ccxt, ccxt_class_name):
                logger.error("ccxt does not have exchange class for: %s", EXCHANGE_ID)
                return

            exchange_class = getattr(ccxt, ccxt_class_name)
            self._exchange = exchange_class(
                {
                    "apiKey": self.api_key,  # Live API key
                    "secret": self.api_secret,  # Live API secret
                    "enableRateLimit": True,  # Configuration default
                    "options": {
                        "defaultType": "spot",  # Configuration default
                        "adjustForTimeDifference": True,  # Configuration default
                    },
                },
            )
            # Log that async pattern is preferred for production
            logger.warning("Using synchronous CCXT initialization - consider migrating to async pattern")
            logger.info("Live exchange initialized: %s", self.venue_name)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to initialize live exchange")
            self._exchange = None

    async def _fetch_orderbook(self, symbol: str) -> dict[str, Any] | None:
        """
        Fetch live order book for a symbol (BASE/QUOTE) (backend port 8000).

        Args:
            symbol: Live trading symbol

        Returns:
            Live order book dictionary, or None if unavailable
        """
        try:
            if not CCXT_AVAILABLE or self._exchange is None:
                return None

            # ccxt calls are synchronous by default; run them without blocking
            orderbook = await asyncio.to_thread(self._exchange.fetch_order_book, symbol)  # Get live order book
            result = None if not orderbook or "bids" not in orderbook or "asks" not in orderbook else orderbook  # No live data (None, not fallback data) or Return live order book
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to fetch live order book for %s", symbol)
            return None  # Error state (None, not fallback data)
        else:
            return result

    @staticmethod
    def _best_prices(orderbook: dict[str, Any]) -> tuple[float, float]:
        """
        Return (best_bid, best_ask) from live CCXT-style orderbook (backend port 8000).

        Args:
            orderbook: Live order book dictionary

        Returns:
            Tuple of (best_bid, best_ask) from live order book
        """
        try:
            bids = orderbook.get("bids") or []  # Live bids
            asks = orderbook.get("asks") or []  # Live asks
            float(bids[0][0]) if bids else DEFAULT_ERROR_PRICE  # Live best bid
            float(asks[0][0]) if asks else DEFAULT_ERROR_PRICE  # Live best ask
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to compute best prices from live order book")
            return DEFAULT_ERROR_PRICE, DEFAULT_ERROR_PRICE  # Error state (not fallback data)

    @staticmethod
    def _volume_capacity(orderbook: dict[str, Any], target_volume_usd: float) -> dict[str, float]:
        """
        Compute the capacity (USD) and effective prices from live order book (backend port 8000).

        Args:
            orderbook: Live order book dictionary
            target_volume_usd: Target volume in USD

        Returns:
            Dictionary with capacity and effective prices from live order book
        """
        try:
            bids = orderbook.get("bids") or []  # Live bids
            asks = orderbook.get("asks") or []  # Live asks

            if not bids or not asks:
                return {
                    "capacity": DEFAULT_ERROR_CAPACITY,  # Error state (not fallback data)
                    "bid_price": DEFAULT_ERROR_PRICE,  # Error state (not fallback data)
                    "ask_price": DEFAULT_ERROR_PRICE,  # Error state (not fallback data)
                }

            # Aggregate bids (sell into bids) from live order book
            sell_usd = 0.0
            sell_value = 0.0
            for price, amount in bids:  # Process live bids
                p = float(price)  # Live price
                a = float(amount)  # Live amount
                v = p * a  # USD value from live data
                remain = max(0.0, target_volume_usd - sell_usd)
                take = min(v, remain)
                if take <= 0:
                    break
                # portion of amount at this level needed to reach 'take' USD
                amt_used = take / p  # Calculate from live data
                sell_usd += take
                sell_value += p * amt_used
                sell_value / sell_usd if sell_usd > 0 else p  # Calculate from live data

            # Aggregate asks (buy from asks) from live order book
            buy_usd = 0.0
            buy_value = 0.0
            for price, amount in asks:  # Process live asks
                p = float(price)  # Live price
                a = float(amount)  # Live amount
                v = p * float(a)  # USD value from live data
                remain = max(0.0, target_volume_usd - buy_usd)
                take = min(v, remain)
                if take <= 0:
                    break
                amt_used = take / p  # Calculate from live data
                buy_usd += take
                buy_value += p * amt_used
                buy_value / buy_usd if buy_usd > 0 else p  # Calculate from live data

            min(sell_usd, buy_usd)  # Calculate from live data
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to compute volume capacity from live order book")
            return {
                "capacity": DEFAULT_ERROR_CAPACITY,  # Error state (not fallback data)
                "bid_price": DEFAULT_ERROR_PRICE,  # Error state (not fallback data)
                "ask_price": DEFAULT_ERROR_PRICE,  # Error state (not fallback data)
            }

    async def _fetch_all_orderbooks(self) -> dict[str, dict[str, Any]]:
        """
        Fetch live order books for all monitored symbols from the single venue (backend port 8000).

        Returns:
            Dictionary with live order books for all symbols
        """
        try:
            results: dict[str, dict[str, Any]] = {}
            venue_books: dict[str, Any] = {}

            for symbol in self.top_symbols:  # Process all live symbols
                ob = await self._fetch_orderbook(symbol)  # Get live order book
                if ob:
                    venue_books[symbol] = ob  # Store live order book
                await asyncio.sleep(ORDER_BOOK_FETCH_DELAY)  # Rate limiting (configuration delay)

            if venue_books:
                results[self.venue_key] = venue_books  # Store live results
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed fetching all live order books")
            return {}  # Empty dict on error (not fallback data)

    def _detect_opportunities_single_venue(self, orderbooks: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
        """
        Detect best execution opportunities from live order books (backend port 8000).

        With a single venue, true cross-venue arbitrage does not exist.
        We instead surface "best execution" opportunities per symbol: tight spreads + sufficient capacity.

        Args:
            orderbooks: Dictionary with live order books

        Returns:
            List of live best execution opportunities
        """
        try:
            opportunities: list[dict[str, Any]] = []
            venue_books = orderbooks.get(self.venue_key) or {}  # Get live order books
            for symbol, ob in venue_books.items():  # Process live order books
                best_bid, best_ask = self._best_prices(ob)  # Get from live data
                if best_bid <= 0.0 or best_ask <= 0.0:
                    continue  # Skip invalid live data

                spread = (best_ask - best_bid) / best_ask if best_ask > 0 else 0.0  # Calculate from live data
                capacity_info = self._volume_capacity(ob, self.max_volume_usd)  # Calculate from live data

                # Heuristic: we want spreads tighter than threshold and capacity above minimum (from live data)
                if spread <= self.min_arbitrage_spread and capacity_info["capacity"] >= self.min_volume_usd:
                    opportunities.append(
                        {
                            "symbol": symbol,  # Live symbol
                            "venue": self.venue_name,  # Live venue
                            "best_bid": best_bid,  # Live best bid
                            "best_ask": best_ask,  # Live best ask
                            "spread_pct": spread * 100.0,  # Live spread percentage
                            "max_volume_usd": capacity_info["capacity"],  # Live capacity
                            "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
                        },
                    )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed detecting opportunities from live order books")
            return []  # Empty list on error (not fallback data)

    async def find_arbitrage_opportunities(self) -> list[dict[str, Any]]:
        """
        Find live best execution opportunities (backend port 8000).

        With a single venue constraint, this returns "best execution" candidates.
        Each result is still stored as a signal for downstream consumers, using consistent constants.

        Returns:
            List of live best execution opportunities
        """
        try:
            orderbooks = await self._fetch_all_orderbooks()  # Get live order books
            if not orderbooks:
                logger.warning("No live order books available")
                return []  # No live data (empty list, not fallback data)

            opportunities = self._detect_opportunities_single_venue(orderbooks)  # Detect from live data

            # Store as signals for visibility/consumption
            for opp in opportunities:  # Process live opportunities
                signal_id = f"opportunity_{opp['symbol'].replace('/', '')}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
                confidence = 1.0 if opp["spread_pct"] <= (self.min_arbitrage_spread * 100.0) else 0.5  # Calculate from live data
                self.cache.store_signal(
                    signal_id=signal_id,
                    symbol=opp["symbol"],  # Live symbol
                    signal_type=SIGNAL_TYPE_ARBITRAGE,
                    confidence=confidence,  # Live confidence
                    strategy=STRATEGY_ID,
                    metadata={**opp, "exchange": EXCHANGE_ID},  # Live metadata
                )

            logger.info("Live opportunities evaluated: %d", len(opportunities))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to evaluate live opportunities")
            return []  # Empty list on error (not fallback data)
        else:
            return opportunities

    def best_liquidity_path(self, symbol: str) -> dict[str, Any]:
        """
        Return the most recent best-execution snapshot for a symbol from live data (backend port 8000).

        Args:
            symbol: Live trading symbol

        Returns:
            Dictionary with best liquidity path from live signals
        """
        try:
            signals = self.cache.get_signals_by_type(SIGNAL_TYPE_ARBITRAGE, limit=50)  # Get live signals
            symbol_signals = [s for s in signals if s.get("metadata", {}).get("symbol") == symbol]  # Filter by live symbol
            if not symbol_signals:
                return {
                    "symbol": symbol,
                    "success": False,
                    "reason": "No recent live data available",
                }  # No live data (not fallback data)

            # Best is defined as minimal spread with sufficient capacity from live data
            def _score(sig: dict[str, Any]) -> float:
                md = sig.get("metadata", {})
                spread = float(md.get("spread_pct", 100.0))  # Live spread
                capacity = float(md.get("max_volume_usd", 0.0))  # Live capacity
                return -spread + min(capacity / self.max_volume_usd, BEST_EXECUTION_SCORE_CAPACITY_NORMALIZATION)  # Calculate from live data

            best = max(symbol_signals, key=_score)  # Get best from live signals
            md = best.get("metadata", {})
            return {
                "symbol": symbol,  # Live symbol
                "success": True,
                "venue": md.get("venue", self.venue_name),  # Live venue
                "best_bid": md.get("best_bid"),  # Live best bid
                "best_ask": md.get("best_ask"),  # Live best ask
                "spread_pct": md.get("spread_pct"),  # Live spread percentage
                "max_volume_usd": md.get("max_volume_usd"),  # Live capacity
                "timestamp": md.get("timestamp"),  # Live timestamp
                "confidence": best.get("confidence", 0.0),  # Live confidence
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to compute best liquidity path from live data for %s", symbol)
            return {"symbol": symbol, "success": False, "error": "Error getting live liquidity path"}

    def get_routing_map(self) -> dict[str, Any]:
        """
        Return a simple routing map from live data (backend port 8000).

        Returns:
            Dictionary with per-symbol best spread and capacity from live data
        """
        try:
            recent = self.cache.get_signals_by_type(SIGNAL_TYPE_ARBITRAGE, limit=100)  # Get live signals
            symbols_info: dict[str, Any] = {}

            for base in TOP10_BASES:  # Process all live symbols
                sym = _to_ccxt_symbol(base, self.quote_asset)  # Normalize live symbol
                entries = [s for s in recent if s.get("metadata", {}).get("symbol") == sym]  # Filter by live symbol
                if not entries:
                    continue  # Skip if no live data
                # Take the most recent from live signals
                latest = max(entries, key=lambda s: s.get("timestamp", ""))  # Latest live signal
                md = latest.get("metadata", {})
                symbols_info[sym] = {
                    "venue": md.get("venue", self.venue_name),  # Live venue
                    "spread_pct": md.get("spread_pct", 0.0),  # Live spread
                    "max_volume_usd": md.get("max_volume_usd", 0.0),  # Live capacity
                    "last_updated": md.get("timestamp", ""),  # Live timestamp
                }

            venue_summary = {
                self.venue_key: {
                    "name": self.venue_name,  # Live venue name
                    "connected": bool(self._exchange),  # Live connection status
                    "monitored_symbols": self.top_symbols,  # Live monitored symbols
                },
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to build routing map from live data")
            return {"exchanges": {}, "symbols": {}}  # Empty dicts on error (not fallback data)
        else:
            return {"exchanges": venue_summary, "symbols": symbols_info}  # Return live routing map

    def get_liquidity_status(self) -> dict[str, Any]:
        """
        Return live engine status and monitoring configuration (backend port 8000).

        Returns:
            Dictionary with live engine status and configuration
        """
        try:
            return {
                "service": "MultiversalLiquidityEngine",
                "status": "active",  # Live status
                "exchange": EXCHANGE_ID,  # Live exchange ID
                "exchanges_connected": 1 if self._exchange else 0,  # Live connection count
                "ccxt_available": CCXT_AVAILABLE,  # CCXT availability
                "monitored_symbols": self.top_symbols,  # Live monitored symbols
                "parameters": {
                    "min_arbitrage_spread": self.min_arbitrage_spread,  # Configuration
                    "max_slippage": self.max_slippage,  # Configuration
                    "min_volume_usd": self.min_volume_usd,  # Configuration
                    "max_volume_usd": self.max_volume_usd,  # Configuration
                },
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live liquidity status")
            return {"success": False, "error": "Error getting live liquidity status"}


def get_multiversal_liquidity_engine() -> MultiversalLiquidityEngine:
    """
    Accessor for global engine instance (backend port 8000).
    Uses lazy initialization to avoid blocking during import.

    Returns:
        Global multiversal liquidity engine instance for live operations
    """
    if not hasattr(get_multiversal_liquidity_engine, "_instance"):
        get_multiversal_liquidity_engine._instance = MultiversalLiquidityEngine()
    return get_multiversal_liquidity_engine._instance


# For backward compatibility - lazy wrapper
class _LazyMultiversalLiquidityEngine:
    def __getattr__(self, name):
        return getattr(get_multiversal_liquidity_engine(), name)

    def __bool__(self):
        return True


multiversal_liquidity_engine = _LazyMultiversalLiquidityEngine()


__all__ = [
    "EXCHANGE_ID",
    "SIGNAL_TYPE_ARBITRAGE",
    "STRATEGY_ID",
    "TOP10_BASES",
    "MultiversalLiquidityEngine",
    "_to_ccxt_symbol",
    "get_multiversal_liquidity_engine",
    "multiversal_liquidity_engine",
]
