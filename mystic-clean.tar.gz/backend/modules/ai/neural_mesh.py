"""
Neural Mesh Module - All Live Data, No Fallback/Hardcoded Data

Maintains a distributed shared agent learning network for parameter sharing and strategy merging
for Binance.US Top-10 spot trading (backend port 8000).
All operations use live data:
- Agent performance: Gets live agent performance from canonical cache
- Agent parameters: Gets live agent parameters from canonical cache
- Mesh updates: Updates mesh state from live agent evaluations
- All operations use live data - no fallback/hardcoded data

Rules enforced in this module:
- Single-source-of-truth constants: EXCHANGE_ID = "binance_us"
- One _to_ccxt_symbol() helper imported (error handling when import fails, not fallback data)
- No ad-hoc strings for signal types or mesh symbol
- Logging has no special characters
- No references to non-Binance-US exchanges or unrelated services

Endpoint References:
- Backend API: Port 8000 (neural mesh serves live operations)
- Canonical Cache: Live agent performance and parameter signals
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import copy
import logging
from datetime import datetime, timezone
from typing import Any

# Single source of truth for exchange id + symbol helper
# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

try:
    from backend.modules.market.binance_data_fetcher import _to_ccxt_symbol
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import _to_ccxt_symbol from binance_data_fetcher: {e}"
    raise RuntimeError(msg) from e


from backend.services.canonical_cache import canonical_cache

logger = logging.getLogger(__name__)

# Signal constants (configuration defaults, not fallback data)
SIGNAL_SYMBOL = "NEURAL_MESH"
SIGNAL_TYPE_MESH_UPDATE = "MESH_UPDATE"
SIGNAL_TYPE_AGENT_PERFORMANCE = "AGENT_PERFORMANCE"
SIGNAL_TYPE_AGENT_PARAMETERS = "AGENT_PARAMETERS"

# Configuration constants (not fallback data)
DEFAULT_ERROR_PNL = 0.0  # Zero PnL when unavailable (error state, not fallback)
DEFAULT_ERROR_WIN_RATE = 0.0  # Zero win rate when unavailable (error state, not fallback)
DEFAULT_ERROR_TRADES = 0  # Zero trades when unavailable (error state, not fallback)
DEFAULT_ERROR_SHARPE = 0.0  # Zero Sharpe ratio when unavailable (error state, not fallback)
DEFAULT_ERROR_SCORE = 0.0  # Zero performance score when unavailable (error state, not fallback)
DEFAULT_ERROR_WEIGHT = 0.0  # Zero performance weight when unavailable (error state, not fallback)
PNL_NORMALIZATION = 1000.0  # PnL normalization factor (configuration default)
TRADE_COUNT_NORMALIZATION = 100.0  # Trade count normalization factor (configuration default)
PNL_WEIGHT = 0.4  # PnL weight in performance score (configuration default)
WIN_RATE_WEIGHT = 0.3  # Win rate weight in performance score (configuration default)
SHARPE_WEIGHT = 0.2  # Sharpe ratio weight in performance score (configuration default)
TRADE_COUNT_WEIGHT = 0.1  # Trade count weight in performance score (configuration default)


class NeuralMesh:
    """
    Neural mesh for distributed agent learning (backend port 8000).

    Maintains a distributed shared agent learning network for parameter sharing and strategy merging.
    All operations use live data from canonical cache - no fallback/hardcoded data.
    """

    def __init__(self) -> None:
        """
        Initialize neural mesh with distributed learning parameters for live operations.

        All initial values are configuration defaults or live state, not fallback data.
        """
        self.cache = canonical_cache  # Live cache for agent data

        # Mesh configuration (configuration defaults, not fallback data)
        self.mesh_update_interval: int = 3600  # seconds
        self.min_trades_for_evaluation: int = 20
        self.performance_weight_decay: float = 0.95
        self.parameter_merge_rate: float = 0.1

        # Agent tracking (live state, not fallback data)
        self.registered_agents: dict[str, dict[str, Any]] = {}
        self.mesh_state: dict[str, Any] = {
            "global_parameters": {},  # Will be initialized with configuration defaults
            "performance_weights": {},  # Live performance weights
            "last_update": None,  # Live last update time
            "mesh_version": 0,  # Live mesh version
        }

        # Parameter categories for sharing (configuration defaults, not fallback data)
        self.parameter_categories: dict[str, list[str]] = {
            "rsi_thresholds": ["rsi_oversold", "rsi_overbought"],
            "ema_weights": ["ema_fast", "ema_slow"],
            "risk_parameters": ["risk_factor", "confidence_threshold"],
            "trade_parameters": [
                "take_profit_percentage",
                "stop_loss_percentage",
                "position_size_percentage",
            ],
        }

        # Initialize mesh state with configuration defaults
        self._initialize_mesh_state()

        logger.info("NeuralMesh initialized for live operations")

    def _initialize_mesh_state(self) -> None:
        """
        Initialize the global mesh state with configuration default parameters (backend port 8000).

        All default parameters are configuration values, not fallback data.
        """
        try:
            # Configuration default parameters (not fallback data)
            self.mesh_state["global_parameters"] = {
                "rsi_oversold": 30.0,  # Configuration default
                "rsi_overbought": 70.0,  # Configuration default
                "ema_fast": 12,  # Configuration default
                "ema_slow": 26,  # Configuration default
                "risk_factor": 1.0,  # Configuration default
                "confidence_threshold": 0.6,  # Configuration default
                "take_profit_percentage": 0.05,  # Configuration default
                "stop_loss_percentage": 0.03,  # Configuration default
                "position_size_percentage": 0.1,  # Configuration default
            }
            self.mesh_state["performance_weights"] = {}  # Live performance weights
            self.mesh_state["last_update"] = datetime.now(timezone.utc).isoformat()  # Live timestamp
            self.mesh_state["mesh_version"] = 0  # Initial version

            logger.info("Mesh state initialized with configuration default parameters")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to initialize mesh state with configuration defaults")

    def _get_agent_performance(self, agent_id: str) -> dict[str, Any]:
        """
        Get live agent performance from cache (backend port 8000).

        Args:
            agent_id: Live agent ID

        Returns:
            Dictionary with live agent performance metrics
        """
        try:
            signals = self.cache.get_signals_by_type(SIGNAL_TYPE_AGENT_PERFORMANCE, limit=10)  # Get live signals
            agent_signals = [s for s in signals if s.get("metadata", {}).get("agent_id") == agent_id]  # Filter by live agent

            if agent_signals:
                latest_perf = agent_signals[0].get("metadata", {}).get("performance", {})  # Get live performance
                return {
                    "total_pnl": latest_perf.get("total_pnl", DEFAULT_ERROR_PNL),  # Live PnL
                    "win_rate": latest_perf.get("win_rate", DEFAULT_ERROR_WIN_RATE),  # Live win rate
                    "total_trades": latest_perf.get("total_trades", DEFAULT_ERROR_TRADES),  # Live trade count
                    "sharpe_ratio": latest_perf.get("sharpe_ratio", DEFAULT_ERROR_SHARPE),  # Live Sharpe ratio
                    "timestamp": agent_signals[0].get("timestamp"),  # Live timestamp
                }

            # No live performance data available (error state, not fallback data)
            return {
                "total_pnl": DEFAULT_ERROR_PNL,  # Error state (not fallback data)
                "win_rate": DEFAULT_ERROR_WIN_RATE,  # Error state (not fallback data)
                "total_trades": DEFAULT_ERROR_TRADES,  # Error state (not fallback data)
                "sharpe_ratio": DEFAULT_ERROR_SHARPE,  # Error state (not fallback data)
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live agent performance for %s", agent_id)
            return {
                "total_pnl": DEFAULT_ERROR_PNL,  # Error state (not fallback data)
                "win_rate": DEFAULT_ERROR_WIN_RATE,  # Error state (not fallback data)
                "total_trades": DEFAULT_ERROR_TRADES,  # Error state (not fallback data)
                "sharpe_ratio": DEFAULT_ERROR_SHARPE,  # Error state (not fallback data)
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

    def _get_agent_parameters(self, agent_id: str) -> dict[str, Any]:
        """
        Get live agent parameters from cache (backend port 8000).

        Args:
            agent_id: Live agent ID

        Returns:
            Dictionary with live agent parameters, or configuration defaults if unavailable
        """
        try:
            signals = self.cache.get_signals_by_type(SIGNAL_TYPE_AGENT_PARAMETERS, limit=5)  # Get live signals
            agent_signals = [s for s in signals if s.get("metadata", {}).get("agent_id") == agent_id]  # Filter by live agent

            if agent_signals:
                return agent_signals[0].get("metadata", {}).get("parameters", {})  # Return live parameters

            # No live parameters available, return configuration defaults (not fallback data)
            return copy.deepcopy(self.mesh_state["global_parameters"])

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live agent parameters for %s", agent_id)
            return copy.deepcopy(self.mesh_state["global_parameters"])  # Configuration defaults on error

    def _calculate_performance_score(self, performance: dict[str, Any]) -> float:
        """
        Calculate performance score from live agent performance (backend port 8000).

        Args:
            performance: Live agent performance dictionary

        Returns:
            Performance score calculated from live data
        """
        try:
            # Performance score weights (configuration defaults, not fallback data)
            pnl_weight = PNL_WEIGHT
            win_rate_weight = WIN_RATE_WEIGHT
            sharpe_weight = SHARPE_WEIGHT
            trade_count_weight = TRADE_COUNT_WEIGHT

            # Normalize live PnL
            normalized_pnl = min(performance.get("total_pnl", DEFAULT_ERROR_PNL) / PNL_NORMALIZATION, 1.0)  # From live data
            # Normalize live trade count
            normalized_trades = min(performance.get("total_trades", DEFAULT_ERROR_TRADES) / TRADE_COUNT_NORMALIZATION, 1.0)  # From live data

            # Calculate score from live data (configuration weights, not fallback data)
            score = (
                pnl_weight * normalized_pnl  # From live PnL
                + win_rate_weight * performance.get("win_rate", DEFAULT_ERROR_WIN_RATE)  # From live win rate
                + sharpe_weight * max(0.0, performance.get("sharpe_ratio", DEFAULT_ERROR_SHARPE))  # From live Sharpe
                + trade_count_weight * normalized_trades  # From live trade count
            )

            return max(0.0, min(1.0, score))  # Clamp score
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to calculate performance score from live data")
            return DEFAULT_ERROR_SCORE  # Error state (not fallback data)

    def _merge_parameters(self, agent_parameters: dict[str, Any], performance_score: float) -> dict[str, Any]:
        """
        Merge agent parameters with global parameters weighted by live performance (backend port 8000).

        Args:
            agent_parameters: Live agent parameters dictionary
            performance_score: Live performance score

        Returns:
            Merged parameters dictionary from live agent and global parameters
        """
        try:
            merged = copy.deepcopy(self.mesh_state["global_parameters"])  # Start with configuration defaults

            for _, parameters in self.parameter_categories.items():
                for param in parameters:
                    if param in agent_parameters:
                        g = merged.get(param, 0.0)  # Global parameter
                        a = agent_parameters.get(param, 0.0)  # Live agent parameter
                        # Merge based on live performance score (configuration merge rate, not fallback data)
                        merged[param] = (1 - self.parameter_merge_rate) * g + self.parameter_merge_rate * ((1 - performance_score) * g + performance_score * a)  # Merge from live data

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to merge parameters from live data")
            return copy.deepcopy(self.mesh_state["global_parameters"])  # Configuration defaults on error
        else:
            return merged

    def _evaluate_agent_trades(self, agent_id: str) -> dict[str, Any]:
        """
        Evaluate live agent trading performance and produce merged parameters (backend port 8000).

        Args:
            agent_id: Live agent ID

        Returns:
            Dictionary with agent evaluation results from live data
        """
        try:
            perf = self._get_agent_performance(agent_id)  # Get live performance

            if perf.get("total_trades", DEFAULT_ERROR_TRADES) < self.min_trades_for_evaluation:
                return {
                    "agent_id": agent_id,
                    "evaluated": False,
                    "reason": f"Insufficient live trades: {perf.get('total_trades', DEFAULT_ERROR_TRADES)} < {self.min_trades_for_evaluation}",
                }  # Insufficient live data (not fallback data)

            score = self._calculate_performance_score(perf)  # Calculate from live data
            agent_params = self._get_agent_parameters(agent_id)  # Get live parameters
            merged_params = self._merge_parameters(agent_params, score)  # Merge from live data

            return {
                "agent_id": agent_id,  # Live agent ID
                "evaluated": True,
                "performance": perf,  # Live performance
                "performance_score": score,  # Live performance score
                "agent_parameters": agent_params,  # Live agent parameters
                "merged_parameters": merged_params,  # Merged from live data
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to evaluate live agent %s", agent_id)
            return {
                "agent_id": agent_id,
                "evaluated": False,
                "error": "Error evaluating live agent",
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

    def _update_mesh_state(self, agent_evaluations: list[dict[str, Any]]) -> dict[str, Any]:
        """
        Update mesh state using successful live agent evaluations (backend port 8000).

        Args:
            agent_evaluations: List of live agent evaluation results

        Returns:
            Updated mesh state from live evaluations
        """
        try:
            successful = [ev for ev in agent_evaluations if ev.get("evaluated")]  # Filter successful
            if not successful:
                logger.warning("No successful live agent evaluations for mesh update")
                return self.mesh_state  # Return current state if no live evaluations

            total_weight = 0.0
            weighted_params: dict[str, float] = {}

            for ev in successful:  # Process live evaluations
                w = float(ev.get("performance_score", DEFAULT_ERROR_SCORE))  # Live performance score
                merged = ev.get("merged_parameters", {})  # Merged from live data
                for k, v in merged.items():
                    weighted_params[k] = weighted_params.get(k, 0.0) + float(v) * w  # Weight from live data
                total_weight += w  # Accumulate from live data

            if total_weight > 0:
                for k in list(weighted_params.keys()):
                    weighted_params[k] /= total_weight  # Normalize from live data
                self.mesh_state["global_parameters"].update(weighted_params)  # Update from live data

            # Update performance weights with decay from live data
            for ev in successful:  # Process live evaluations
                agent_id = ev.get("agent_id", "")
                w = float(ev.get("performance_score", DEFAULT_ERROR_SCORE))  # Live performance score
                prior = float(self.mesh_state["performance_weights"].get(agent_id, DEFAULT_ERROR_WEIGHT))
                decayed = prior * self.performance_weight_decay  # Apply decay
                self.mesh_state["performance_weights"][agent_id] = max(decayed, w)  # Update from live data

            self.mesh_state["last_update"] = datetime.now(timezone.utc).isoformat()  # Live timestamp
            self.mesh_state["mesh_version"] = int(self.mesh_state.get("mesh_version", 0)) + 1  # Increment version

            logger.info("Mesh state updated from %d live agent evaluations", len(successful))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to update mesh state from live evaluations")
            return self.mesh_state  # Return current state on error
        else:
            return self.mesh_state

    def update_mesh(self) -> dict[str, Any]:
        """
        Update the neural mesh with latest live agent data (backend port 8000).

        Returns:
            Updated mesh state from live agent evaluations
        """
        try:
            logger.info("Updating neural mesh from live agent data")
            agent_ids = list(self.registered_agents.keys())  # Get live registered agents

            if not agent_ids:
                logger.warning("No registered agents for live mesh update")
                return self.mesh_state

            evaluations = [self._evaluate_agent_trades(aid) for aid in agent_ids]  # Evaluate all live agents
            updated = self._update_mesh_state(evaluations)  # Update from live evaluations

            # Persist mesh update with live data
            evaluated_count = len([e for e in evaluations if e.get("evaluated")])  # Count from live data
            confidence = evaluated_count / len(evaluations) if evaluations else 0.0  # Calculate from live data

            mesh_id = f"neural_mesh_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
            self.cache.store_signal(
                signal_id=mesh_id,
                symbol=SIGNAL_SYMBOL,
                signal_type=SIGNAL_TYPE_MESH_UPDATE,
                confidence=confidence,  # Live confidence
                strategy="distributed_learning",
                metadata={
                    "mesh_state": updated,  # Live mesh state
                    "agent_evaluations": evaluations,  # Live evaluations
                    "update_timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
                    "exchange": EXCHANGE_ID,  # Live exchange ID
                },
            )

            logger.info("Neural mesh updated from %d live agents", len(evaluations))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to update mesh from live agent data")
            return self.mesh_state  # Return current state on error
        else:
            return updated

    def get_mesh_state(self) -> dict[str, Any]:
        """
        Get current mesh state and configuration (backend port 8000).

        Returns:
            Dictionary with live mesh state and configuration
        """
        try:
            return {
                "mesh_state": self.mesh_state,  # Live mesh state
                "registered_agents": list(self.registered_agents.keys()),  # Live registered agents
                "parameter_categories": self.parameter_categories,  # Configuration categories
                "configuration": {
                    "mesh_update_interval": self.mesh_update_interval,  # Configuration
                    "min_trades_for_evaluation": self.min_trades_for_evaluation,  # Configuration
                    "performance_weight_decay": self.performance_weight_decay,  # Configuration
                    "parameter_merge_rate": self.parameter_merge_rate,  # Configuration
                },
                "exchange": EXCHANGE_ID,  # Live exchange ID
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live mesh state")
            return {
                "error": "Error getting live mesh state",
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

    def sync_agent(self, agent_id: str) -> dict[str, Any]:
        """
        Sync an agent with the current live mesh state (backend port 8000).

        Args:
            agent_id: Live agent ID

        Returns:
            Dictionary with sync result from live mesh state
        """
        try:
            logger.info("Syncing agent %s with live mesh state", agent_id)

            if agent_id not in self.registered_agents:
                self.registered_agents[agent_id] = {
                    "registered_at": datetime.now(timezone.utc).isoformat(),  # Live registration time
                    "last_sync": None,
                    "sync_count": 0,
                }

            self.registered_agents[agent_id]["last_sync"] = datetime.now(timezone.utc).isoformat()  # Live sync time
            self.registered_agents[agent_id]["sync_count"] += 1  # Increment sync count

            mesh_parameters = copy.deepcopy(self.mesh_state["global_parameters"])  # Get live mesh parameters
            performance_weight = float(self.mesh_state["performance_weights"].get(agent_id, DEFAULT_ERROR_WEIGHT))  # Get live performance weight

            resp = {
                "agent_id": agent_id,  # Live agent ID
                "synced": True,
                "mesh_parameters": mesh_parameters,  # Live mesh parameters
                "performance_weight": performance_weight,  # Live performance weight
                "mesh_version": self.mesh_state["mesh_version"],  # Live mesh version
                "exchange": EXCHANGE_ID,  # Live exchange ID
                "sync_timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

            logger.info("Agent %s synced with live mesh state", agent_id)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to sync agent %s with live mesh state", agent_id)
            return {
                "agent_id": agent_id,
                "synced": False,
                "error": "Error syncing with live mesh state",
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }
        else:
            return resp

    def register_agent(self, agent_id: str, initial_parameters: dict[str, Any] | None = None) -> dict[str, Any]:
        """
        Register a new agent with the neural mesh (backend port 8000).

        Args:
            agent_id: Live agent ID
            initial_parameters: Optional initial parameters (uses configuration defaults if None, not fallback data)

        Returns:
            Dictionary with registration result
        """
        try:
            logger.info("Registering agent %s with live neural mesh", agent_id)

            self.registered_agents[agent_id] = {
                "registered_at": datetime.now(timezone.utc).isoformat(),  # Live registration time
                "last_sync": None,
                "sync_count": 0,
                "initial_parameters": initial_parameters or copy.deepcopy(self.mesh_state["global_parameters"]),  # Use config defaults if None
            }

            self.mesh_state["performance_weights"][agent_id] = DEFAULT_ERROR_WEIGHT  # Initialize weight

            resp = {
                "agent_id": agent_id,  # Live agent ID
                "registered": True,
                "mesh_parameters": copy.deepcopy(self.mesh_state["global_parameters"]),  # Live mesh parameters
                "mesh_version": self.mesh_state["mesh_version"],  # Live mesh version
                "exchange": EXCHANGE_ID,  # Live exchange ID
                "registration_timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

            logger.info("Agent %s registered with live neural mesh", agent_id)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to register agent %s with live neural mesh", agent_id)
            return {
                "agent_id": agent_id,
                "registered": False,
                "error": "Error registering with live neural mesh",
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }
        else:
            return resp

    def get_mesh_history(self, limit: int = 10) -> list[dict[str, Any]]:
        """
        Get neural mesh update history from live signals (backend port 8000).

        Args:
            limit: Number of history entries to retrieve (configuration default, not fallback data)

        Returns:
            List of live mesh update signals from cache
        """
        try:
            return self.cache.get_signals_by_type(SIGNAL_TYPE_MESH_UPDATE, limit=limit)  # Get live signals
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live mesh history")
            return []  # Empty list on error (not fallback data)

    def get_mesh_status(self) -> dict[str, Any]:
        """
        Get current live neural mesh status (backend port 8000).

        Returns:
            Dictionary with live mesh status and configuration
        """
        try:
            return {
                "service": "NeuralMesh",
                "status": "active",  # Live status
                "registered_agents": len(self.registered_agents),  # Live agent count
                "mesh_version": self.mesh_state["mesh_version"],  # Live mesh version
                "last_update": self.mesh_state["last_update"],  # Live last update time
                "exchange": EXCHANGE_ID,  # Live exchange ID
                "configuration": {
                    "mesh_update_interval": self.mesh_update_interval,  # Configuration
                    "min_trades_for_evaluation": self.min_trades_for_evaluation,  # Configuration
                    "performance_weight_decay": self.performance_weight_decay,  # Configuration
                    "parameter_merge_rate": self.parameter_merge_rate,  # Configuration
                },
                "parameter_categories": self.parameter_categories,  # Configuration categories
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live mesh status")
            return {"success": False, "error": "Error getting live mesh status"}


# Global neural mesh instance
neural_mesh = NeuralMesh()  # Initialize singleton for live operations


def get_neural_mesh() -> NeuralMesh:
    """
    Get the global neural mesh instance (backend port 8000).

    Returns:
        Global neural mesh instance for live operations
    """
    return neural_mesh


__all__ = [
    "EXCHANGE_ID",
    "SIGNAL_SYMBOL",
    "SIGNAL_TYPE_AGENT_PARAMETERS",
    "SIGNAL_TYPE_AGENT_PERFORMANCE",
    "SIGNAL_TYPE_MESH_UPDATE",
    "NeuralMesh",
    "_to_ccxt_symbol",
    "get_neural_mesh",
    "neural_mesh",
]
