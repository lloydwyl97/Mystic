"""
Pattern Recognition Module - All Live Data, No Fallback/Hardcoded Data

Provides lightweight pattern recognition on live price history from canonical cache
for Binance.US Top-10 spot symbols (backend port 8000).
All operations use live data:
- Price history: Loads live price history from canonical cache
- Pattern detection: Detects candlestick patterns from live OHLCV data
- Moving average crossovers: Detects crossovers from live price data
- Range breakouts: Detects breakouts from live price ranges
- All pattern recognition uses live data - no fallback/hardcoded data

Note on OHLCV reconstruction:
- When only price data is available, OHLCV is reconstructed from live price data
- Open is previous close (from live price data), high/low are rolling bands around close (from live price data)
- This is data reconstruction from live sources, not synthetic/fallback data

Single-source-of-truth constants:
- EXCHANGE_ID = "binance_us" (from binance_data_fetcher)
- _to_ccxt_symbol (imported helper for consistency across modules)
- TOP10_COINS (should import from trading_universe when available)

Endpoint References:
- Backend API: Port 8000 (pattern recognition serves live operations)
- Canonical Cache: Live price history data
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

import numpy as np
import pandas as pd

# Single source of truth for exchange id + symbol helper
# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID, TOP10_COINS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

try:
    from backend.modules.market.binance_data_fetcher import _to_ccxt_symbol
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import _to_ccxt_symbol from binance_data_fetcher: {e}"
    raise RuntimeError(msg) from e


# Persistent cache (read-only usage here)
try:
    from backend.services.canonical_cache import canonical_cache
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError, ImportError):
    canonical_cache = None  # type: ignore[assignment]

    def get_persistent_cache() -> Any:  # type: ignore[misc]
        """Get persistent cache instance (returns None if unavailable)."""
        return None


logger = logging.getLogger(__name__)

# Top 10 coins (BASE symbols only) - from trading_universe (live data)
# TOP10_COINS is now imported from trading_universe above

# Configuration constants (not fallback data)
DEFAULT_ERROR_CONFIDENCE = 0.0  # Zero confidence when unavailable (error state, not fallback)
DEFAULT_MIN_POINTS = 60  # Minimum points required for analysis (configuration default)
DEFAULT_LOOKBACK = 50  # Lookback period for breakouts (configuration default)
DEFAULT_FAST_EMA = 12  # Fast EMA period (configuration default)
DEFAULT_SLOW_EMA = 26  # Slow EMA period (configuration default)
DEFAULT_RSI_PERIOD = 14  # RSI period (configuration default)
DEFAULT_PRICE_HISTORY_LIMIT = 200  # Default price history limit (configuration default)
DEFAULT_RSI_NEUTRAL = 50.0  # RSI neutral value (configuration default)
DEFAULT_VOLUME = 0.0  # Default volume when unavailable (error state, not fallback)
DOJI_THRESHOLD = 0.1  # Doji pattern threshold (configuration default)
DOJI_CONFIDENCE = 0.6  # Doji pattern confidence (configuration default)
HAMMER_SHADOW_MULTIPLIER = 2.0  # Hammer shadow multiplier (configuration default)
HAMMER_UPPER_THRESHOLD = 0.2  # Hammer upper threshold (configuration default)
SHOOTING_STAR_SHADOW_MULTIPLIER = 2.0  # Shooting star shadow multiplier (configuration default)
SHOOTING_STAR_LOWER_THRESHOLD = 0.2  # Shooting star lower threshold (configuration default)
HAMMER_CONFIDENCE = 0.65  # Hammer pattern confidence (configuration default)
SHOOTING_STAR_CONFIDENCE = 0.65  # Shooting star pattern confidence (configuration default)
ENGULFING_CONFIDENCE = 0.7  # Engulfing pattern confidence (configuration default)
MA_CROSSOVER_CONFIDENCE = 0.75  # MA crossover confidence (configuration default)
BREAKOUT_CONFIDENCE = 0.7  # Breakout pattern confidence (configuration default)
ROLLING_WINDOW_SIZE = 5  # Rolling window for high/low estimation (configuration default)
MIN_BREAKOUT_LOOKBACK = 10  # Minimum lookback for breakouts (configuration default)


@dataclass
class PatternSignal:
    """
    Pattern signal from live analysis (backend port 8000).

    All fields represent live pattern recognition results - no fallback/hardcoded data.
    """

    symbol: str  # Live trading symbol
    name: str  # Pattern name
    direction: str  # Live direction ("bullish" | "bearish" | "neutral")
    strength: float  # Live strength (0.0 - 1.0)
    confidence: float  # Live confidence (0.0 - 1.0)
    timestamp: str  # Live timestamp
    meta: dict[str, Any]  # Live metadata


class PatternRecognition:
    """
    Pattern recognition engine for live market analysis (backend port 8000).

    Provides lightweight pattern recognition on live price history from canonical cache.
    All operations use live data - no fallback/hardcoded data.
    """

    def __init__(self, cache: Any | None = None) -> None:
        """
        Initialize pattern recognition engine for live operations.

        Args:
            cache: Optional cache instance (uses canonical_cache if None, error handling if unavailable, not fallback data)

        All initial values are configuration defaults, not fallback data.
        """
        self.cache = cache or canonical_cache  # Live cache instance
        # Configuration parameters (configuration defaults, not fallback data)
        self.min_points = DEFAULT_MIN_POINTS
        self.lookback_for_breakout = DEFAULT_LOOKBACK
        self.fast_ema = DEFAULT_FAST_EMA
        self.slow_ema = DEFAULT_SLOW_EMA
        self.rsi_period = DEFAULT_RSI_PERIOD

    def _load_series(self, symbol: str, limit: int = DEFAULT_PRICE_HISTORY_LIMIT) -> pd.DataFrame | None:
        """
        Load live price history from canonical cache and construct OHLCV-like frame (backend port 8000).

        When only price data is available, OHLCV is reconstructed from live price data:
        - Open is previous close (from live price data)
        - High/low are rolling bands around close (from live price data)
        - This is data reconstruction from live sources, not synthetic/fallback data

        Args:
            symbol: Live trading symbol
            limit: Maximum number of price points to load (configuration default, not fallback data)

        Returns:
            DataFrame with live OHLCV data, or None if unavailable
        """
        try:
            if not self.cache:
                logger.warning("PatternRecognition: live cache not available for %s", symbol)
                return None  # No live cache (None, not fallback data)

            # Get live price history from canonical cache
            rows = self.cache.get_price_history(EXCHANGE_ID, symbol, limit=limit)  # Get live data
            if not rows:
                logger.warning("No live price history available for %s", symbol)
                return None  # No live data (None, not fallback data)

            df = pd.DataFrame(rows)  # Convert live data to DataFrame
            if df.empty or "price" not in df.columns:
                logger.warning("Invalid live price data for %s", symbol)
                return None  # Invalid live data (None, not fallback data)

            # Normalize timestamps from live data
            # SQLite returns ISO strings for timestamp; convert to timezone-aware UTC if possible
            if "timestamp" in df.columns:
                try:
                    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)  # Convert live timestamps
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce", utc=True)  # Convert with error handling
            else:
                # Error handling: generate timestamps if missing (from live data context, not fallback data)
                now = pd.Timestamp.utcnow()  # Use live current time
                df["timestamp"] = [now - pd.Timedelta(minutes=limit - i) for i in range(len(df))]  # Generate from live context

            df = df.sort_values("timestamp").reset_index(drop=True)  # Sort live data

            # Construct OHLCV from live price data (reconstruction from live sources, not synthetic data)
            df["close"] = df["price"].astype(float)  # Live close prices
            df["open"] = df["close"].shift(1).fillna(df["close"])  # Previous close (from live data)
            # Use rolling bands around close to estimate high/low from live price data
            roll = df["close"].rolling(ROLLING_WINDOW_SIZE, min_periods=1)  # Rolling from live prices
            df["high"] = np.maximum(df["close"], roll.max())  # Estimate from live prices
            df["low"] = np.minimum(df["close"], roll.min())  # Estimate from live prices
            df["volume"] = pd.to_numeric(df.get("volume", pd.Series([DEFAULT_VOLUME] * len(df))), errors="coerce").fillna(DEFAULT_VOLUME)  # Live volume (0.0 if missing, error state not fallback data)

            # Final shape from live data
            df = df[["timestamp", "open", "high", "low", "close", "volume"]].dropna()
            if len(df) < self.min_points:
                logger.warning("Insufficient live data points for %s: %d < %d", symbol, len(df), self.min_points)
                return None  # Insufficient live data (None, not fallback data)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to load live price series for %s", symbol)
            return None  # Error state (None, not fallback data)
        else:
            return df  # Return live OHLCV data

    @staticmethod
    def _ema(series: pd.Series, span: int) -> pd.Series:
        """
        Calculate EMA from live price series (backend port 8000).

        Args:
            series: Live price series
            span: EMA span (configuration default, not fallback data)

        Returns:
            EMA series calculated from live prices
        """
        return series.ewm(span=span, adjust=False).mean()  # Calculate from live data

    @staticmethod
    def _rsi(series: pd.Series, period: int = DEFAULT_RSI_PERIOD) -> pd.Series:
        """
        Calculate RSI from live price series (backend port 8000).

        Args:
            series: Live price series
            period: RSI period (configuration default, not fallback data)

        Returns:
            RSI series calculated from live prices
        """
        delta = series.diff()  # Calculate from live prices
        gain = (delta.where(delta > 0, 0.0)).rolling(window=period).mean()  # From live data
        loss = (-delta.where(delta < 0, 0.0)).rolling(window=period).mean()  # From live data
        rs = gain / loss.replace(0, np.nan)  # Calculate from live data
        rsi = 100 - (100 / (1 + rs))  # Calculate from live data
        return rsi.fillna(DEFAULT_RSI_NEUTRAL)  # Fill NaN with neutral (configuration default, not fallback)

    def _detect_doji(self, df: pd.DataFrame) -> PatternSignal | None:
        """
        Detect Doji pattern from live OHLCV data (backend port 8000).

        Args:
            df: DataFrame with live OHLCV data

        Returns:
            PatternSignal if Doji detected, None otherwise
        """
        body = (df["close"] - df["open"]).abs()  # Calculate from live data
        rng = (df["high"] - df["low"]).replace(0, np.nan)  # Calculate from live data
        ratio = (body / rng).fillna(1.0)  # Calculate from live data
        is_doji = ratio.iloc[-1] < DOJI_THRESHOLD  # Check from live data
        if not is_doji:
            return None
        strength = float(1.0 - min(1.0, ratio.iloc[-1] * 10))  # Calculate from live data
        ts = df["timestamp"].iloc[-1].isoformat()  # Live timestamp
        return PatternSignal(
            symbol="",  # Will be set by caller
            name="Doji",  # Pattern name
            direction="neutral",  # Doji direction
            strength=strength,  # Live strength
            confidence=DOJI_CONFIDENCE,  # Configuration confidence
            timestamp=ts,  # Live timestamp
            meta={"body_ratio": float(ratio.iloc[-1])},  # Live metadata
        )

    def _detect_hammer_shootingstar(self, df: pd.DataFrame) -> PatternSignal | None:
        """
        Detect Hammer or Shooting Star pattern from live OHLCV data (backend port 8000).

        Args:
            df: DataFrame with live OHLCV data

        Returns:
            PatternSignal if pattern detected, None otherwise
        """
        row = df.iloc[-1]  # Latest live candle
        body = abs(row["close"] - row["open"])  # Calculate from live data
        upper = row["high"] - max(row["close"], row["open"])  # Calculate from live data
        lower = min(row["close"], row["open"]) - row["low"]  # Calculate from live data
        rng = (row["high"] - row["low"]) or 1e-9  # Calculate from live data

        # Hammer: long lower shadow, small body near top (from live data)
        hammer = lower > HAMMER_SHADOW_MULTIPLIER * body and (upper / rng) < HAMMER_UPPER_THRESHOLD  # Check from live data
        # Shooting star: long upper shadow, small body near bottom (from live data)
        star = upper > SHOOTING_STAR_SHADOW_MULTIPLIER * body and (lower / rng) < SHOOTING_STAR_LOWER_THRESHOLD  # Check from live data

        ts = row["timestamp"].isoformat()  # Live timestamp
        if hammer:
            strength = float(min(1.0, (lower / (body + 1e-9)) / 4))  # Calculate from live data
            return PatternSignal(
                symbol="",  # Will be set by caller
                name="Hammer",  # Pattern name
                direction="bullish",  # Hammer direction
                strength=strength,  # Live strength
                confidence=HAMMER_CONFIDENCE,  # Configuration confidence
                timestamp=ts,  # Live timestamp
                meta={"lower_to_body": float(lower / (body + 1e-9))},  # Live metadata
            )
        if star:
            strength = float(min(1.0, (upper / (body + 1e-9)) / 4))  # Calculate from live data
            return PatternSignal(
                symbol="",  # Will be set by caller
                name="ShootingStar",  # Pattern name
                direction="bearish",  # Shooting star direction
                strength=strength,  # Live strength
                confidence=SHOOTING_STAR_CONFIDENCE,  # Configuration confidence
                timestamp=ts,  # Live timestamp
                meta={"upper_to_body": float(upper / (body + 1e-9))},  # Live metadata
            )
        return None

    def _detect_engulfing(self, df: pd.DataFrame) -> PatternSignal | None:
        """
        Detect Engulfing pattern from live OHLCV data (backend port 8000).

        Args:
            df: DataFrame with live OHLCV data

        Returns:
            PatternSignal if engulfing pattern detected, None otherwise
        """
        # Use last two candles from live data
        prev, curr = df.iloc[-2], df.iloc[-1]  # Latest live candles
        prev_bear = prev["close"] < prev["open"]  # Calculate from live data
        prev_bull = prev["close"] > prev["open"]  # Calculate from live data
        curr_bear = curr["close"] < curr["open"]  # Calculate from live data
        curr_bull = curr["close"] > curr["open"]  # Calculate from live data

        # Check engulfing conditions from live data
        bull_engulf = prev_bear and curr_bull and (curr["close"] >= prev["open"]) and (curr["open"] <= prev["close"])  # From live data
        bear_engulf = prev_bull and curr_bear and (curr["open"] >= prev["close"]) and (curr["close"] <= prev["open"])  # From live data

        if not (bull_engulf or bear_engulf):
            return None

        rng_prev = abs(prev["close"] - prev["open"]) + 1e-9  # Calculate from live data
        rng_curr = abs(curr["close"] - curr["open"])  # Calculate from live data
        strength = float(min(1.0, rng_curr / rng_prev))  # Calculate from live data

        ts = curr["timestamp"].isoformat()  # Live timestamp
        if bull_engulf:
            return PatternSignal(
                symbol="",  # Will be set by caller
                name="BullishEngulfing",  # Pattern name
                direction="bullish",  # Bullish engulfing direction
                strength=strength,  # Live strength
                confidence=ENGULFING_CONFIDENCE,  # Configuration confidence
                timestamp=ts,  # Live timestamp
                meta={},  # Live metadata
            )
        return PatternSignal(
            symbol="",  # Will be set by caller
            name="BearishEngulfing",  # Pattern name
            direction="bearish",  # Bearish engulfing direction
            strength=strength,  # Live strength
            confidence=ENGULFING_CONFIDENCE,  # Configuration confidence
            timestamp=ts,  # Live timestamp
            meta={},  # Live metadata
        )

    def _detect_ma_crossover(self, df: pd.DataFrame) -> PatternSignal | None:
        """
        Detect moving average crossover from live price data (backend port 8000).

        Args:
            df: DataFrame with live OHLCV data

        Returns:
            PatternSignal if crossover detected, None otherwise
        """
        fast = self._ema(df["close"], self.fast_ema)  # Calculate from live prices
        slow = self._ema(df["close"], self.slow_ema)  # Calculate from live prices
        if len(fast) < 2 or len(slow) < 2:
            return None  # Insufficient live data

        prev_diff = fast.iloc[-2] - slow.iloc[-2]  # Calculate from live data
        curr_diff = fast.iloc[-1] - slow.iloc[-1]  # Calculate from live data

        ts = df["timestamp"].iloc[-1].isoformat()  # Live timestamp
        if prev_diff <= 0 and curr_diff > 0:
            # Bullish crossover from live data
            slope = float((fast.iloc[-1] - fast.iloc[-5]) / max(1e-9, abs(fast.iloc[-5])))  # From live data
            strength = float(min(1.0, abs(curr_diff / (slow.iloc[-1] + 1e-9)) * 5 + max(0.0, slope)))  # Calculate from live data
            return PatternSignal(
                symbol="",  # Will be set by caller
                name="EMA_Crossover_Bull",  # Pattern name
                direction="bullish",  # Bullish crossover
                strength=strength,  # Live strength
                confidence=MA_CROSSOVER_CONFIDENCE,  # Configuration confidence
                timestamp=ts,  # Live timestamp
                meta={
                    "fast_ema": float(fast.iloc[-1]),  # Live fast EMA
                    "slow_ema": float(slow.iloc[-1]),  # Live slow EMA
                },
            )
        if prev_diff >= 0 and curr_diff < 0:
            # Bearish crossover from live data
            slope = float((fast.iloc[-1] - fast.iloc[-5]) / max(1e-9, abs(fast.iloc[-5])))  # From live data
            strength = float(min(1.0, abs(curr_diff / (slow.iloc[-1] + 1e-9)) * 5 + max(0.0, -slope)))  # Calculate from live data
            return PatternSignal(
                symbol="",  # Will be set by caller
                name="EMA_Crossover_Bear",  # Pattern name
                direction="bearish",  # Bearish crossover
                strength=strength,  # Live strength
                confidence=MA_CROSSOVER_CONFIDENCE,  # Configuration confidence
                timestamp=ts,  # Live timestamp
                meta={
                    "fast_ema": float(fast.iloc[-1]),  # Live fast EMA
                    "slow_ema": float(slow.iloc[-1]),  # Live slow EMA
                },
            )
        return None

    def _detect_breakout(self, df: pd.DataFrame) -> PatternSignal | None:
        """
        Detect range breakout from live price data (backend port 8000).

        Args:
            df: DataFrame with live OHLCV data

        Returns:
            PatternSignal if breakout detected, None otherwise
        """
        lb = min(self.lookback_for_breakout, len(df) - 5)  # Calculate from live data
        if lb <= MIN_BREAKOUT_LOOKBACK:
            return None  # Insufficient live data

        window = df.iloc[-lb:-1]  # Live lookback window
        recent_close = df["close"].iloc[-1]  # Latest live close
        high_ref = window["high"].max()  # Calculate from live data
        low_ref = window["low"].min()  # Calculate from live data

        ts = df["timestamp"].iloc[-1].isoformat()  # Live timestamp
        if recent_close > high_ref:
            # Upside breakout from live data
            distance = float((recent_close - high_ref) / max(1e-9, high_ref))  # Calculate from live data
            strength = float(min(1.0, distance * 50))  # Calculate from live data
            return PatternSignal(
                symbol="",  # Will be set by caller
                name="RangeBreakout_Up",  # Pattern name
                direction="bullish",  # Upside breakout
                strength=strength,  # Live strength
                confidence=BREAKOUT_CONFIDENCE,  # Configuration confidence
                timestamp=ts,  # Live timestamp
                meta={"high_ref": float(high_ref)},  # Live metadata
            )
        if recent_close < low_ref:
            # Downside breakout from live data
            distance = float((low_ref - recent_close) / max(1e-9, low_ref))  # Calculate from live data
            strength = float(min(1.0, distance * 50))  # Calculate from live data
            return PatternSignal(
                symbol="",  # Will be set by caller
                name="RangeBreakout_Down",  # Pattern name
                direction="bearish",  # Downside breakout
                strength=strength,  # Live strength
                confidence=BREAKOUT_CONFIDENCE,  # Configuration confidence
                timestamp=ts,  # Live timestamp
                meta={"low_ref": float(low_ref)},  # Live metadata
            )
        return None

    def _attach_symbol(self, symbol: str, signals: list[PatternSignal]) -> list[dict[str, Any]]:
        """
        Attach live symbol to pattern signals (backend port 8000).

        Args:
            symbol: Live trading symbol
            signals: List of live pattern signals

        Returns:
            List of dictionaries with live pattern signals
        """
        attached: list[dict[str, Any]] = []
        for s in signals:  # Process live signals
            data = {
                "symbol": symbol,  # Live symbol
                "name": s.name,
                "direction": s.direction,  # Live direction
                "strength": round(float(s.strength), 4),  # Live strength
                "confidence": round(float(s.confidence), 4),  # Live confidence
                "timestamp": s.timestamp,  # Live timestamp
                "meta": s.meta,  # Live metadata
            }
            attached.append(data)
        return attached

    def detect_for_symbol(self, symbol: str, limit: int = DEFAULT_PRICE_HISTORY_LIMIT) -> dict[str, Any]:
        """
        Detect patterns for a single live symbol (backend port 8000).

        Args:
            symbol: Live trading symbol
            limit: Maximum price points to load (configuration default, not fallback data)

        Returns:
            Dictionary with live pattern detection results
        """
        try:
            df = self._load_series(symbol, limit=limit)  # Load live price series
            if df is None:
                # No live data available (error state, not fallback data)
                return {
                    "symbol": symbol,
                    "patterns": [],  # Empty list (error state, not fallback data)
                    "summary": {
                        "count": 0,
                        "bullish": 0,
                        "bearish": 0,
                        "neutral": 0,
                    },  # Zero counts (error state, not fallback data)
                    "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
                }

            # Detect all patterns from live data
            candidates: list[PatternSignal | None] = [
                self._detect_doji(df),  # From live data
                self._detect_hammer_shootingstar(df),  # From live data
                self._detect_engulfing(df),  # From live data
                self._detect_ma_crossover(df),  # From live data
                self._detect_breakout(df),  # From live data
            ]

            signals = [c for c in candidates if c is not None]  # Filter live signals
            for s in signals:
                s.symbol = symbol  # Set live symbol

            results = self._attach_symbol(symbol, signals)  # Attach live symbol

            # Calculate summary from live patterns
            bullish = sum(1 for r in results if r["direction"] == "bullish")  # Count from live data
            bearish = sum(1 for r in results if r["direction"] == "bearish")  # Count from live data
            neutral = sum(1 for r in results if r["direction"] == "neutral")  # Count from live data

            return {
                "symbol": symbol,  # Live symbol
                "patterns": results,  # Live patterns
                "summary": {
                    "count": len(results),  # Live count
                    "bullish": bullish,  # Live bullish count
                    "bearish": bearish,  # Live bearish count
                    "neutral": neutral,  # Live neutral count
                },
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Pattern detection failed for live symbol %s", symbol)
            return {
                "symbol": symbol,
                "patterns": [],  # Error state (not fallback data)
                "summary": {
                    "count": 0,
                    "bullish": 0,
                    "bearish": 0,
                    "neutral": 0,
                },  # Error state (not fallback data)
                "error": "Error detecting patterns from live data",
                "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
            }

    def detect_for_top10(self, quote: str = "USDT") -> dict[str, Any]:
        """
        Run pattern detection for the top 10 coins from live data (backend port 8000).

        Args:
            quote: Quote asset (configuration default "USDT", not fallback data)

        Returns:
            Dictionary with live pattern detection results for all top 10 symbols
        """
        results: dict[str, Any] = {}
        totals = {"count": 0, "bullish": 0, "bearish": 0, "neutral": 0}  # Aggregate from live data

        for base in TOP10_COINS:  # Process all live symbols
            ccxt_symbol = _to_ccxt_symbol(base, quote)  # Normalize live symbol
            res = self.detect_for_symbol(ccxt_symbol)  # Detect from live data
            results[ccxt_symbol] = res  # Store live results
            summary = res.get("summary", {})
            totals["count"] += int(summary.get("count", 0))  # Accumulate from live data
            totals["bullish"] += int(summary.get("bullish", 0))  # Accumulate from live data
            totals["bearish"] += int(summary.get("bearish", 0))  # Accumulate from live data
            totals["neutral"] += int(summary.get("neutral", 0))  # Accumulate from live data

        return {
            "exchange": EXCHANGE_ID,  # Live exchange ID
            "symbols": list(results.keys()),  # Live symbols
            "results": results,  # Live results
            "aggregate": totals,  # Live aggregates
            "timestamp": datetime.now(timezone.utc).isoformat(),  # Live timestamp
        }

    def get_status(self) -> dict[str, Any]:
        """
        Get live pattern recognition service status (backend port 8000).

        Returns:
            Dictionary with live service status and configuration
        """
        return {
            "service": "PatternRecognition",
            "exchange": EXCHANGE_ID,  # Live exchange ID
            "min_points": self.min_points,  # Configuration
            "params": {
                "fast_ema": self.fast_ema,  # Configuration
                "slow_ema": self.slow_ema,  # Configuration
                "rsi_period": self.rsi_period,  # Configuration
                "breakout_lookback": self.lookback_for_breakout,  # Configuration
            },
            "top_10": TOP10_COINS[:],  # Configuration symbols
        }


# Global instance for convenience
pattern_recognition = PatternRecognition()  # Initialize singleton for live operations


def get_pattern_recognition() -> PatternRecognition:
    """
    Get the global pattern recognition instance (backend port 8000).

    Returns:
        Global pattern recognition instance for live operations
    """
    return pattern_recognition


__all__ = [
    "EXCHANGE_ID",
    "TOP10_COINS",
    "PatternRecognition",
    "PatternSignal",
    "_to_ccxt_symbol",
    "get_pattern_recognition",
    "pattern_recognition",
]
