"""
Persistent Cache Module - All Live Data, No Fallback/Hardcoded Data

SQLite-backed persistent caching for live market data, trades, and AI signals
for Binance.US Top-10 spot trading (backend port 8000).
All operations use live data:
- Market data storage: Stores live market data from Binance.US API
- Trade logging: Logs live trades executed on Binance.US
- Signal storage: Stores live AI signals from trading operations
- All data operations use live data - no fallback/hardcoded data

Single-source-of-truth:
- EXCHANGE_ID = "binance_us" (from binance_data_fetcher)
- No ad-hoc exchange strings
- Windows-friendly, Python 3.12

Endpoint References:
- Backend API: Port 8000 (persistent cache serves live operations)
- SQLite Database: Live persistent storage (cache.db)
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import contextlib
import json
import logging
import os
import signal
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Single source of truth (prefer import; error handling if unavailable)
# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

try:
    from backend.modules.market.binance_data_fetcher import _to_ccxt_symbol
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
    msg = f"Failed to import _to_ccxt_symbol from binance_data_fetcher: {e}"
    raise RuntimeError(msg) from e


# Configuration constants (not fallback data)
DEFAULT_DB_PATH = os.getenv("CACHE_DB_PATH", "cache.db")  # Default database path (configuration default)
DEFAULT_ERROR_AGE = 1e9  # Large number for error state (error state, not fallback data)
DEFAULT_QUERY_TIMEOUT = 5  # Query timeout in seconds (configuration default)
DEFAULT_CLEAR_DAYS = 30  # Default days for clearing old data (configuration default)
DEFAULT_ERROR_PRICE = 0.0  # Zero price when unavailable (error state, not fallback data)
DEFAULT_ERROR_CHANGE = 0.0  # Zero change when unavailable (error state, not fallback data)
DEFAULT_ERROR_VOLUME = 100000.0  # Default volume placeholder (removed - should use live data only)


class PersistentCache:
    """
    SQLite-backed persistent cache for live market data, trades, and AI signals (backend port 8000).

    Provides persistent storage for live trading operations.
    All operations use live data - no fallback/hardcoded data.
    """

    def __init__(self, db_path: str = DEFAULT_DB_PATH) -> None:
        """
        Initialize persistent cache for live operations.

        Args:
            db_path: Database file path (configuration default, not fallback data)

        All initial values are configuration defaults or live state, not fallback data.
        """
        self.db_path = db_path  # Live database path
        self.connection: sqlite3.Connection | None = None  # Live database connection
        self._init_database()

    def _init_database(self) -> None:
        """
        Initialize live SQLite database connection (backend port 8000).

        Creates database connection and tables for live data storage.
        """
        conn = None
        try:
            conn = sqlite3.connect(self.db_path, check_same_thread=False)  # Connect to live database
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA foreign_keys = ON;")  # Enable foreign keys
            conn.execute("PRAGMA journal_mode = WAL;")  # Use WAL mode
            self.connection = conn
            self._create_tables()  # Create tables for live data
            logger.info("Persistent cache initialized for live operations with database: %s", self.db_path)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to initialize live persistent cache")
            if conn is not None:
                try:
                    conn.close()
                except Exception as ex:
                    logger.debug("conn.close fallback: %s", ex)
            self.connection = None
            raise

    def _create_tables(self) -> None:
        """
        Create database tables for live data storage (backend port 8000).

        Creates tables for market data, ticker data, trades, and signals.
        """
        cursor = self.connection.cursor()

        # Create market_data table for live price data
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS market_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                exchange TEXT NOT NULL,
                symbol TEXT NOT NULL,
                price REAL NOT NULL,
                volume REAL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
            """,
        )

        # Create market_ticker_24h table for live 24h ticker data
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS market_ticker_24h (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                exchange TEXT NOT NULL,
                symbol TEXT NOT NULL,
                last_price REAL,
                volume_24h REAL,
                change_24h REAL,
                high_24h REAL,
                low_24h REAL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
            """,
        )

        # Create trade_journal table for live trade data
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS trade_journal (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                trade_id TEXT UNIQUE NOT NULL,
                symbol TEXT NOT NULL,
                side TEXT NOT NULL,
                quantity REAL NOT NULL,
                price REAL NOT NULL,
                total_value REAL NOT NULL,
                exchange TEXT NOT NULL,
                status TEXT DEFAULT 'pending',
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
            """,
        )

        # Create ai_signals table for live AI signal data
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS ai_signals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                signal_id TEXT UNIQUE NOT NULL,
                symbol TEXT NOT NULL,
                signal_type TEXT NOT NULL,
                confidence REAL NOT NULL,
                price_target REAL,
                stop_loss REAL,
                take_profit REAL,
                strategy TEXT,
                metadata TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
            """,
        )

        # Create indexes for live data queries
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_market_data_sym_ts ON market_data(symbol, timestamp)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_market_data_ex_sym ON market_data(exchange, symbol)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_ticker24h_ex_sym_ts ON market_ticker_24h(exchange, symbol, timestamp)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_trade_journal_sym_ts ON trade_journal(symbol, timestamp)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_ai_signals_sym_ts ON ai_signals(symbol, timestamp)")

        self.connection.commit()

    def set_price(
        self,
        exchange: str,
        symbol: str,
        price: float,
        timestamp: float | None = None,
        volume: float | None = None,
    ) -> bool:
        """
        Store live price data (backend port 8000).

        Args:
            exchange: Live exchange ID
            symbol: Live trading symbol
            price: Live price
            timestamp: Optional timestamp (uses current time if None)
            volume: Optional live volume

        Returns:
            True if stored successfully, False otherwise
        """
        try:
            cursor = self.connection.cursor()
            if timestamp is not None:
                cursor.execute(
                    """
                    INSERT INTO market_data (exchange, symbol, price, volume, timestamp)
                    VALUES (?, ?, ?, ?, datetime(?, 'unixepoch'))
                    """,
                    (exchange, symbol, price, volume, timestamp),  # Store live data
                )
            else:
                cursor.execute(
                    """
                    INSERT INTO market_data (exchange, symbol, price, volume)
                    VALUES (?, ?, ?, ?)
                    """,
                    (exchange, symbol, price, volume),  # Store live data with auto timestamp
                )
            self.connection.commit()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to store live price for %s on %s", symbol, exchange)
            return False
        else:
            return True

    def set_ticker_24h(
        self,
        exchange: str,
        symbol: str,
        last_price: float | None = None,
        volume_24h: float | None = None,
        change_24h: float | None = None,
        high_24h: float | None = None,
        low_24h: float | None = None,
        timestamp: float | None = None,
    ) -> bool:
        """
        Store live 24h ticker data (backend port 8000).

        Args:
            exchange: Live exchange ID
            symbol: Live trading symbol
            last_price: Live last price
            volume_24h: Live 24h volume
            change_24h: Live 24h change
            high_24h: Live 24h high
            low_24h: Live 24h low
            timestamp: Optional timestamp (uses current time if None)

        Returns:
            True if stored successfully, False otherwise
        """
        try:
            cursor = self.connection.cursor()
            if timestamp is not None:
                cursor.execute(
                    """
                    INSERT INTO market_ticker_24h (exchange, symbol, last_price, volume_24h, change_24h, high_24h, low_24h, timestamp)
                    VALUES (?, ?, ?, ?, ?, ?, ?, datetime(?, 'unixepoch'))
                    """,
                    (
                        exchange,
                        symbol,
                        last_price,  # Live last price
                        volume_24h,  # Live 24h volume
                        change_24h,  # Live 24h change
                        high_24h,  # Live 24h high
                        low_24h,  # Live 24h low
                        timestamp,
                    ),
                )
            else:
                cursor.execute(
                    """
                    INSERT INTO market_ticker_24h (exchange, symbol, last_price, volume_24h, change_24h, high_24h, low_24h)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        exchange,
                        symbol,
                        last_price,  # Live last price
                        volume_24h,  # Live 24h volume
                        change_24h,  # Live 24h change
                        high_24h,  # Live 24h high
                        low_24h,  # Live 24h low
                    ),
                )
            self.connection.commit()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to store live 24h ticker for %s on %s", symbol, exchange)
            return False
        else:
            return True

    def get_latest_ticker_24h(self, exchange: str, symbol: str) -> dict[str, Any] | None:
        """
        Get latest live 24h ticker data (backend port 8000).

        Args:
            exchange: Live exchange ID
            symbol: Live trading symbol

        Returns:
            Dictionary with live 24h ticker data, or None if unavailable
        """
        try:
            cursor = self.connection.cursor()
            cursor.execute(
                """
                SELECT last_price, volume_24h, change_24h, high_24h, low_24h, timestamp
                FROM market_ticker_24h
                WHERE exchange = ? AND symbol = ?
                ORDER BY timestamp DESC
                LIMIT 1
                """,
                (exchange, symbol),
            )
            row = cursor.fetchone()
            if not row:
                return None  # No live data (None, not fallback data)
            return {
                "last_price": row["last_price"],  # Live last price
                "volume_24h": row["volume_24h"],  # Live 24h volume
                "change_24h": row["change_24h"],  # Live 24h change
                "high_24h": row["high_24h"],  # Live 24h high
                "low_24h": row["low_24h"],  # Live 24h low
                "timestamp": row["timestamp"],  # Live timestamp
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live 24h ticker for %s on %s", symbol, exchange)
            return None  # Error state (None, not fallback data)

    def get_ticker_24h(self, exchange: str, symbol: str) -> dict[str, Any] | None:
        """
        Alias for get_latest_ticker_24h for compatibility (backend port 8000).

        Args:
            exchange: Live exchange ID
            symbol: Live trading symbol

        Returns:
            Dictionary with live 24h ticker data, or None if unavailable
        """
        return self.get_latest_ticker_24h(exchange, symbol)

    def get_latest_price(self, exchange: str, symbol: str) -> float | None:
        """
        Get latest live price (backend port 8000).

        Args:
            exchange: Live exchange ID
            symbol: Live trading symbol

        Returns:
            Latest live price, or None if unavailable
        """
        try:
            cursor = self.connection.cursor()
            cursor.execute(
                """
                SELECT price
                FROM market_data
                WHERE exchange = ? AND symbol = ?
                ORDER BY timestamp DESC
                LIMIT 1
                """,
                (exchange, symbol),
            )
            row = cursor.fetchone()
            return float(row["price"]) if row else None  # Return live price or None (not fallback data)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get latest live price for %s on %s", symbol, exchange)
            return None  # Error state (None, not fallback data)

    def get_price_history(self, exchange: str, symbol: str, limit: int = 100) -> list[dict[str, Any]]:
        """
        Get live price history (backend port 8000).

        Args:
            exchange: Live exchange ID
            symbol: Live trading symbol
            limit: Maximum number of records (configuration default, not fallback data)

        Returns:
            List of live price history records
        """
        try:
            cursor = self.connection.cursor()
            cursor.execute(
                """
                SELECT price, volume, timestamp
                FROM market_data
                WHERE exchange = ? AND symbol = ?
                ORDER BY timestamp DESC
                LIMIT ?
                """,
                (exchange, symbol, limit),
            )
            return [dict(row) for row in cursor.fetchall()]  # Return live price history
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live price history for %s on %s", symbol, exchange)
            return []  # Empty list on error (not fallback data)

    def get_latest_prices(self) -> dict[str, float]:
        """
        Return latest live prices keyed by symbol (backend port 8000).

        Returns:
            Dictionary with latest live prices for all symbols
        """
        try:
            # Add timeout to database operations
            def timeout_handler(_signum, _frame):
                msg = "Database query timeout"
                raise TimeoutError(msg)

            cursor = self.connection.cursor()

            # Set a query timeout for the query (configuration timeout, not fallback data)
            if hasattr(signal, "SIGALRM"):  # Unix systems
                signal.signal(signal.SIGALRM, timeout_handler)
                signal.alarm(DEFAULT_QUERY_TIMEOUT)

            try:
                cursor.execute(
                    """
                    SELECT md.symbol, md.price
                    FROM market_data md
                    JOIN (
                        SELECT symbol, MAX(timestamp) AS max_ts
                        FROM market_data
                        GROUP BY symbol
                    ) t ON t.symbol = md.symbol AND t.max_ts = md.timestamp
                    """,
                )
                result = {row["symbol"]: float(row["price"]) for row in cursor.fetchall()}  # Get live prices

                if hasattr(signal, "SIGALRM"):
                    signal.alarm(0)  # Cancel the alarm
            except TimeoutError:
                logger.warning("Database query timeout in get_latest_prices")
                return {}  # Empty dict on timeout (error state, not fallback data)
            else:
                return result
            finally:
                if hasattr(signal, "SIGALRM"):
                    signal.alarm(0)  # Ensure alarm is cancelled

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Database error in get_latest_prices")
            return {}  # Empty dict on error (not fallback data)

    def log_trade(
        self,
        trade_id: str,
        symbol: str,
        side: str,
        quantity: float,
        price: float,
        exchange: str,
        status: str = "pending",
    ) -> bool:
        """
        Log live trade to journal (backend port 8000).

        Args:
            trade_id: Live trade ID
            symbol: Live trading symbol
            side: Live trade side
            quantity: Live trade quantity
            price: Live trade price
            exchange: Live exchange ID
            status: Live trade status (configuration default "pending", not fallback data)

        Returns:
            True if logged successfully, False otherwise
        """
        try:
            total_value = quantity * price  # Calculate from live data
            cursor = self.connection.cursor()
            cursor.execute(
                """
                INSERT INTO trade_journal (trade_id, symbol, side, quantity, price, total_value, exchange, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    trade_id,  # Live trade ID
                    symbol,  # Live symbol
                    side,  # Live side
                    quantity,  # Live quantity
                    price,  # Live price
                    total_value,  # Calculated from live data
                    exchange,  # Live exchange ID
                    status,  # Live status
                ),
            )
            self.connection.commit()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to log live trade %s", trade_id)
            return False
        else:
            return True

    def get_trades(self, symbol: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        """
        Get live trades from journal (backend port 8000).

        Args:
            symbol: Optional live trading symbol (gets all if None)
            limit: Maximum number of records (configuration default, not fallback data)

        Returns:
            List of live trade records
        """
        try:
            cursor = self.connection.cursor()
            if symbol:
                cursor.execute(
                    """
                    SELECT * FROM trade_journal
                    WHERE symbol = ?
                    ORDER BY timestamp DESC
                    LIMIT ?
                    """,
                    (symbol, limit),
                )
            else:
                cursor.execute(
                    """
                    SELECT * FROM trade_journal
                    ORDER BY timestamp DESC
                    LIMIT ?
                    """,
                    (limit,),
                )
            return [dict(row) for row in cursor.fetchall()]  # Return live trades
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live trades")
            return []  # Empty list on error (not fallback data)

    def store_signal(
        self,
        signal_id: str,
        symbol: str,
        signal_type: str,
        confidence: float,
        price_target: float | None = None,
        stop_loss: float | None = None,
        take_profit: float | None = None,
        strategy: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        """
        Store live AI signal (backend port 8000).

        Args:
            signal_id: Live signal ID
            symbol: Live trading symbol
            signal_type: Live signal type
            confidence: Live signal confidence
            price_target: Optional live price target
            stop_loss: Optional live stop loss
            take_profit: Optional live take profit
            strategy: Optional strategy name
            metadata: Optional live metadata dictionary

        Returns:
            True if stored successfully, False otherwise
        """
        try:
            metadata_json = json.dumps(metadata) if metadata else None  # Serialize live metadata
            cursor = self.connection.cursor()
            cursor.execute(
                """
                INSERT INTO ai_signals (signal_id, symbol, signal_type, confidence, price_target,
                                        stop_loss, take_profit, strategy, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    signal_id,  # Live signal ID
                    symbol,  # Live symbol
                    signal_type,  # Live signal type
                    confidence,  # Live confidence
                    price_target,  # Live price target
                    stop_loss,  # Live stop loss
                    take_profit,  # Live take profit
                    strategy,  # Strategy name
                    metadata_json,  # Live metadata
                ),
            )
            self.connection.commit()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to store live signal %s", signal_id)
            return False
        else:
            return True

    def get_signals(
        self,
        symbol: str | None = None,
        signal_type: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """
        Get live AI signals (backend port 8000).

        Args:
            symbol: Optional live trading symbol (gets all if None)
            signal_type: Optional live signal type (gets all if None)
            limit: Maximum number of records (configuration default, not fallback data)

        Returns:
            List of live signal records
        """
        try:
            cursor = self.connection.cursor()
            if symbol and signal_type:
                cursor.execute(
                    """
                    SELECT * FROM ai_signals
                    WHERE symbol = ? AND signal_type = ?
                    ORDER BY timestamp DESC
                    LIMIT ?
                    """,
                    (symbol, signal_type, limit),
                )
            elif symbol:
                cursor.execute(
                    """
                    SELECT * FROM ai_signals
                    WHERE symbol = ?
                    ORDER BY timestamp DESC
                    LIMIT ?
                    """,
                    (symbol, limit),
                )
            elif signal_type:
                cursor.execute(
                    """
                    SELECT * FROM ai_signals
                    WHERE signal_type = ?
                    ORDER BY timestamp DESC
                    LIMIT ?
                    """,
                    (signal_type, limit),
                )
            else:
                cursor.execute(
                    """
                    SELECT * FROM ai_signals
                    ORDER BY timestamp DESC
                    LIMIT ?
                    """,
                    (limit,),
                )

            results: list[dict[str, Any]] = []
            for row in cursor.fetchall():
                result = dict(row)
                if result.get("metadata"):
                    with contextlib.suppress(json.JSONDecodeError, TypeError):
                        result["metadata"] = json.loads(result["metadata"])  # Parse live metadata
                results.append(result)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live signals")
            return []  # Empty list on error (not fallback data)
        else:
            return results  # Return live signals

    def get_signals_by_type(self, signal_type: str, limit: int = 100) -> list[dict[str, Any]]:
        """
        Get live AI signals by type (backend port 8000).

        Args:
            signal_type: Live signal type
            limit: Maximum number of records (configuration default, not fallback data)

        Returns:
            List of live signal records
        """
        return self.get_signals(signal_type=signal_type, limit=limit)

    def get_historical_prices(self, symbol: str, hours: int = 24, exchange: str = EXCHANGE_ID) -> list[float]:
        """
        Get live historical prices (backend port 8000).

        Args:
            symbol: Live trading symbol
            hours: Number of hours of history (configuration default, not fallback data)
            exchange: Live exchange ID (configuration default, not fallback data)

        Returns:
            List of live historical prices
        """
        try:
            history = self.get_price_history(exchange, symbol, limit=hours)  # Get live price history
            return [float(h.get("price", DEFAULT_ERROR_PRICE)) for h in history if h.get("price") is not None]  # Extract live prices
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live historical prices for %s", symbol)
            return []  # Empty list on error (not fallback data)

    def get_live_ticker(self, symbol: str, exchange: str = EXCHANGE_ID) -> dict[str, Any]:
        """
        Get live ticker data (backend port 8000).

        Args:
            symbol: Live trading symbol
            exchange: Live exchange ID (configuration default, not fallback data)

        Returns:
            Dictionary with live ticker data
        """
        try:
            price = self.get_latest_price(exchange, symbol)  # Get live price
            if price is not None:
                # Get live 24h ticker for change_24h
                ticker_24h = self.get_latest_ticker_24h(exchange, symbol)
                change_24h = ticker_24h.get("change_24h") if ticker_24h else DEFAULT_ERROR_CHANGE  # Live change or error state
                return {"price": price, "change_24h": change_24h}  # Return live data
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live ticker for %s", symbol)
            return {}  # Empty dict on error (not fallback data)
        else:
            return {}  # No live data (empty dict, not fallback data)

    def get_last_update_age(self) -> float:
        """
        Get seconds since latest live market_data row (backend port 8000).

        Returns:
            Seconds since last update, or large number if no data (error state, not fallback data)
        """
        try:
            cursor = self.connection.cursor()
            cursor.execute("SELECT strftime('%s', MAX(timestamp)) AS ts FROM market_data")
            row = cursor.fetchone()
            if not row or row["ts"] is None:
                return DEFAULT_ERROR_AGE  # No live data (error state, not fallback data)
            last_ts = float(row["ts"])  # Get from live data
            now = datetime.now(timezone.utc).timestamp()  # Live current time
            return max(0.0, now - last_ts)  # Calculate from live data
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get last update age from live data")
            return DEFAULT_ERROR_AGE  # Error state (not fallback data)

    def get_last_update_age_v2(self) -> float:
        """
        Get seconds since latest live market_data row - v2 (backend port 8000).

        Returns:
            Seconds since last update, or large number if no data (error state, not fallback data)
        """
        try:
            cursor = self.connection.cursor()
            cursor.execute("SELECT strftime('%s', MAX(timestamp)) AS ts FROM market_data")
            row = cursor.fetchone()
            if not row or row["ts"] is None:
                return DEFAULT_ERROR_AGE  # No live data (error state, not fallback data)
            last_ts = float(row["ts"])  # Get from live data
            now = datetime.now(timezone.utc).timestamp()  # Live current time
            return max(0.0, now - last_ts)  # Calculate from live data
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get last update age v2 from live data")
            return DEFAULT_ERROR_AGE  # Error state (not fallback data)

    def get_binance(self) -> dict[str, Any]:
        """
        Return latest live prices in a simple mapping compatible with dashboard expectations (backend port 8000).

        Returns:
            Dictionary with latest live prices (all from live data, no hardcoded values)
        """
        try:
            prices = self.get_latest_prices()  # Get live prices
            result: dict[str, Any] = {}
            for symbol, price in prices.items():  # Process live prices
                if symbol and price and ("USDT" in symbol or "-USD" in symbol):
                    # Get live 24h ticker data for change_24h and volume_24h
                    ticker_24h = self.get_latest_ticker_24h(EXCHANGE_ID, symbol)
                    change_24h = ticker_24h.get("change_24h") if ticker_24h else DEFAULT_ERROR_CHANGE  # Live change or error state
                    volume_24h = ticker_24h.get("volume_24h") if ticker_24h else DEFAULT_ERROR_PRICE  # Live volume or error state
                    result[symbol] = {
                        "price": float(price),  # Live price
                        "price_change_24h": change_24h,  # Live change or error state
                        "volume_24h": volume_24h,  # Live volume or error state
                    }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live Binance data")
            return {}  # Empty dict on error (not fallback data)
        else:
            return result  # Return all live data

    def get_last_update(self) -> str:
        """
        Get last update timestamp from live cache (backend port 8000).

        Returns:
            Last update timestamp string from live cache
        """
        try:
            stats = self.get_cache_stats()  # Get live cache stats
            return stats.get("latest_market_update", "") or ""  # Get from live stats
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get last update from live cache")
            return ""  # Empty string on error (not fallback data)

    def get_cache_stats(self) -> dict[str, Any]:
        """
        Get live cache statistics (backend port 8000).

        Returns:
            Dictionary with live cache statistics
        """
        try:
            cursor = self.connection.cursor()

            cursor.execute("SELECT COUNT(*) AS c FROM market_data")
            market_data_count = int(cursor.fetchone()["c"])  # Count from live data

            cursor.execute("SELECT COUNT(*) AS c FROM trade_journal")
            trade_count = int(cursor.fetchone()["c"])  # Count from live data

            cursor.execute("SELECT COUNT(*) AS c FROM ai_signals")
            signal_count = int(cursor.fetchone()["c"])  # Count from live data

            cursor.execute("SELECT MAX(timestamp) AS latest FROM market_data")
            latest_market = cursor.fetchone()["latest"]  # Get from live data

            cursor.execute("SELECT MAX(timestamp) AS latest FROM trade_journal")
            latest_trade = cursor.fetchone()["latest"]  # Get from live data

            cursor.execute("SELECT MAX(timestamp) AS latest FROM ai_signals")
            latest_signal = cursor.fetchone()["latest"]  # Get from live data

            return {
                "market_data_count": market_data_count,  # Live count
                "trade_count": trade_count,  # Live count
                "signal_count": signal_count,  # Live count
                "latest_market_update": latest_market,  # Live timestamp
                "latest_trade": latest_trade,  # Live timestamp
                "latest_signal": latest_signal,  # Live timestamp
                "database_size": (Path(self.db_path).stat().st_size if Path(self.db_path).exists() else 0),  # Live database size
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get live cache stats")
            return {}  # Empty dict on error (not fallback data)

    def clear_old_data(self, days: int = DEFAULT_CLEAR_DAYS) -> bool:
        """
        Delete rows older than N days based on timestamp (backend port 8000).

        Args:
            days: Number of days to retain (configuration default, not fallback data)

        Returns:
            True if cleared successfully, False otherwise
        """
        try:
            cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")  # Calculate from live current time
            cursor = self.connection.cursor()

            cursor.execute("DELETE FROM market_data WHERE timestamp < ?", (cutoff,))
            market_deleted = cursor.rowcount  # Count deleted live rows

            cursor.execute(
                "DELETE FROM trade_journal WHERE timestamp < ? AND status != 'completed'",
                (cutoff,),
            )
            trade_deleted = cursor.rowcount  # Count deleted live rows

            cursor.execute("DELETE FROM ai_signals WHERE timestamp < ?", (cutoff,))
            signal_deleted = cursor.rowcount  # Count deleted live rows

            self.connection.commit()
            logger.info(
                "Cleared old live data: %d market rows, %d trade rows, %d signal rows",
                market_deleted,
                trade_deleted,
                signal_deleted,
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to clear old live data")
            return False
        else:
            return True

    def close(self) -> None:
        """
        Close live database connection (backend port 8000).
        """
        if self.connection:
            with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                self.connection.close()  # Close live connection

    def __del__(self) -> None:
        """Cleanup on deletion."""
        try:
            self.close()
        except (AttributeError, TypeError, ValueError, RuntimeError):
            # contextlib or other modules may be None during interpreter shutdown
            pass


# Global cache instance - lazy initialized to avoid startup conflicts
persistent_cache = None  # Will be initialized on first use


def _get_or_init_persistent_cache() -> PersistentCache:
    """Initialize cache on first use (lazy loading)."""
    global persistent_cache
    if persistent_cache is None:
        persistent_cache = PersistentCache()
    return persistent_cache


def get_persistent_cache() -> PersistentCache:
    """
    Get the global persistent cache instance (backend port 8000).

    Returns:
        Global persistent cache instance for live operations
    """
    return _get_or_init_persistent_cache()


__all__ = [
    "EXCHANGE_ID",
    "PersistentCache",
    "_to_ccxt_symbol",
    "get_persistent_cache",
    "persistent_cache",
]
