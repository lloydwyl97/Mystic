"""
Poller Module - All Live Data, No Fallback/Hardcoded Data

Poller utilities for Mystic Trading Platform for Binance.US Top-10 spot trading (backend port 8000).
All operations use live data:
- Cache access: Gets live persistent cache for live market data storage
- Single source of truth constants: Uses EXCHANGE_ID and Top-10 coins from trading_universe
- Symbol tracking: Tracks all 10 coins and their symbols for AI identification
- No ad-hoc exchange strings
- All operations use live data - no fallback/hardcoded data

Endpoint References:
- Backend API: Port 8000 (poller serves live operations)
- Binance.US API: Live market data via persistent cache
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

# Import persistent cache at module level (required for get_cache)
try:
    from backend.modules.ai.persistent_cache import get_persistent_cache
except (ImportError, ModuleNotFoundError):
    get_persistent_cache = None  # type: ignore[assignment]

# Single source of truth - Trading Universe (ALL 10 COINS - HARDCODED AS REQUIRED)
try:
    from backend.config.trading_universe import (
        EXCHANGE_ID,
        TOP10_COINS,
        TRADING_SYMBOLS,
        get_base_symbols,
        get_trading_symbols,
    )
    from backend.modules.market.binance_data_fetcher import _to_ccxt_symbol
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, KeyError, IndexError, RuntimeError) as e:
    msg = "Trading universe configuration is required for live operations"
    logger.exception("Failed to import trading universe")
    raise RuntimeError(msg) from e

# Symbol tracking for AI - maps base symbols to trading symbols and CCXT symbols
# AI needs to know what coins are what, so we track all symbol formats
_SYMBOL_MAP: dict[str, dict[str, str]] = {}
_CCXT_SYMBOLS: list[str] = []


def _initialize_symbol_tracking() -> None:
    """
    Initialize symbol tracking for AI identification (backend port 8000).

    Tracks all 10 coins in multiple formats so AI knows what coins are what:
    - Base symbols (BTC, ETH, etc.)
    - Trading symbols (BTCUSDT, ETHUSDT, etc.)
    - CCXT symbols (BTC/USDT, ETH/USDT, etc.)
    """
    global _SYMBOL_MAP, _CCXT_SYMBOLS
    _SYMBOL_MAP = {}
    _CCXT_SYMBOLS = []

    # Track all 10 coins for AI
    for base_symbol in TOP10_COINS:
        trading_symbol = f"{base_symbol}USDT"
        ccxt_symbol = _to_ccxt_symbol(base_symbol, "USDT")

        _SYMBOL_MAP[base_symbol] = {
            "base": base_symbol,
            "trading": trading_symbol,
            "ccxt": ccxt_symbol,
        }
        _CCXT_SYMBOLS.append(ccxt_symbol)

    logger.info("Initialized symbol tracking for AI: %d coins tracked", len(_SYMBOL_MAP))


# Initialize symbol tracking on module import
_initialize_symbol_tracking()


def get_symbol_map() -> dict[str, dict[str, str]]:
    """
    Get symbol mapping for AI identification (backend port 8000).

    Returns mapping of all 10 coins in multiple formats so AI knows what coins are what.
    Format: {base_symbol: {"base": str, "trading": str, "ccxt": str}}

    Returns:
        Dictionary mapping base symbols to their various formats
    """
    return _SYMBOL_MAP.copy()


def get_ccxt_symbols() -> list[str]:
    """
    Get all CCXT format symbols for the 10 coins (backend port 8000).

    Returns list of all 10 coins in CCXT format (BASE/QUOTE).

    Returns:
        List of CCXT format symbols (e.g., ["BTC/USDT", "ETH/USDT", ...])
    """
    return _CCXT_SYMBOLS.copy()


def get_cache() -> Any:
    """
    Get cache instance for live operations (backend port 8000).

    Gets live persistent cache for live market data storage.
    Fails if persistent cache is unavailable (no fallback data).

    Returns:
        Live cache instance (PersistentCache)

    Raises:
        RuntimeError: If persistent cache is unavailable
    """
    if get_persistent_cache is None:
        msg = "Persistent cache is required for live operations"
        logger.error("Persistent cache unavailable")
        raise RuntimeError(msg)

    try:
        # Get live persistent cache (required for live operations)
        return get_persistent_cache()  # Return live persistent cache
    except (AttributeError, ValueError, TypeError, KeyError, IndexError, RuntimeError) as e:
        msg = "Persistent cache is required for live operations"
        logger.exception("Persistent cache unavailable")
        raise RuntimeError(msg) from e


__all__ = [
    "EXCHANGE_ID",
    "TOP10_COINS",
    "TRADING_SYMBOLS",
    "_to_ccxt_symbol",
    "get_base_symbols",
    "get_cache",
    "get_ccxt_symbols",
    "get_symbol_map",
    "get_trading_symbols",
]
