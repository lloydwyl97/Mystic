"""
Predictive Analytics for AI Trading - All Live Data, No Fallback/Hardcoded Data

Implements price prediction, volatility forecasting, and market microstructure analysis
for Binance.US Top-10 spot trading (backend port 8000).
All operations use live data:
- Price predictions: Generated from live OHLCV market data
- Volatility forecasts: Calculated from live price movements
- Market microstructure: Analyzed from live trading data
- All operations use live data - no fallback/hardcoded data

Endpoint References:
- Backend API: Port 8000 (predictive analytics serves live operations)
- Binance.US API: Live market data for predictions
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import logging
import warnings
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats

from backend.config.redis_config import get_shared_redis_async
from backend.services.confidence_normalizer import ConfidenceNormalizer

# Single source of truth - Trading Universe (ALL 10 COINS - HARDCODED AS REQUIRED)
try:
    from backend.config.trading_universe import EXCHANGE_ID, TOP10_COINS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, KeyError, IndexError, RuntimeError) as e:
    msg = "Trading universe configuration is required for live operations"
    logging.getLogger(__name__).exception("Failed to import trading universe")
    raise RuntimeError(msg) from e

# Single source of truth - Symbol normalization (same as persistent_cache uses)
try:
    from backend.modules.market.binance_data_fetcher import _to_ccxt_symbol
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, KeyError, IndexError, RuntimeError) as e:
    msg = "Symbol normalizer is required for live operations"
    logging.getLogger(__name__).exception("Failed to import symbol normalizer")
    raise RuntimeError(msg) from e

# Import Fibonacci patterns (required - no fallback)
try:
    from backend.indicators.advanced_indicators import FibonacciPatterns
except (ImportError, ModuleNotFoundError) as e:
    msg = "FibonacciPatterns is required for live operations"
    logging.getLogger(__name__).exception("Failed to import FibonacciPatterns")
    raise RuntimeError(msg) from e

warnings.filterwarnings("ignore")

logger = logging.getLogger(__name__)

# ---------- Data Models ----------


@dataclass
class PricePrediction:
    symbol: str
    current_price: float
    predicted_price_1h: float
    predicted_price_4h: float
    predicted_price_24h: float
    confidence_1h: float
    confidence_4h: float
    confidence_24h: float
    price_targets: dict[str, float]
    support_levels: list[float]
    resistance_levels: list[float]
    breakout_probability: float
    reversal_probability: float
    timestamp: datetime


@dataclass
class VolatilityForecast:
    symbol: str
    current_volatility: float
    predicted_volatility_1h: float
    predicted_volatility_4h: float
    predicted_volatility_24h: float
    volatility_regime: str
    volatility_trend: str
    confidence: float
    timestamp: datetime


@dataclass
class MarketMicrostructureAnalysis:
    symbol: str
    bid_ask_spread: float
    order_book_imbalance: float
    market_depth: float
    price_impact: float
    liquidity_score: float
    market_maker_activity: float
    institutional_flow: float
    retail_sentiment: float
    timestamp: datetime


# ---------- Core Service ----------


class PredictiveAnalytics:
    def __init__(self) -> None:
        self.redis_client: Any = None
        self.prediction_horizons = [1, 4, 24]
        self.lookback_periods = [24, 168, 720]
        self.fibonacci = FibonacciPatterns()
        self.confidence_threshold = 0.6
        self.volatility_windows = [24, 168, 720]
        self.volatility_regimes = {
            "low": 0.02,
            "normal": 0.05,
            "high": 0.10,
            "extreme": 0.20,
        }
        logger.info("PredictiveAnalytics initialized")

    async def _get_redis(self) -> Any:
        """
        Get Redis client for live operations (backend port 8000).

        Uses REDIS_URL environment variable or constructs from REDIS_HOST/REDIS_PORT/REDIS_DB.
        Returns None if Redis is unavailable (optional dependency).

        Returns:
            Redis client instance or None if unavailable
        """
        if self.redis_client is None:
            try:
                self.redis_client = get_shared_redis_async()
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.warning("Redis not available (optional): %s", e)
                self.redis_client = None
        return self.redis_client

    def _calculate_technical_indicators(self, df: pd.DataFrame) -> dict[str, Any]:
        try:
            indicators: dict[str, Any] = {}
            close = df["close"]

            indicators["sma_20"] = close.rolling(20).mean()
            indicators["sma_50"] = close.rolling(50).mean()
            indicators["ema_12"] = close.ewm(span=12, adjust=False).mean()
            indicators["ema_26"] = close.ewm(span=26, adjust=False).mean()

            delta = close.diff()
            gain = delta.clip(lower=0).rolling(14).mean()
            loss = (-delta.clip(upper=0)).rolling(14).mean()
            rs = gain / loss.replace(0, np.nan)
            indicators["rsi"] = 100 - (100 / (1 + rs))

            indicators["macd"] = indicators["ema_12"] - indicators["ema_26"]
            indicators["macd_signal"] = indicators["macd"].ewm(span=9, adjust=False).mean()
            indicators["macd_histogram"] = indicators["macd"] - indicators["macd_signal"]

            sma_20 = indicators["sma_20"]
            std_20 = close.rolling(20).std()
            bb_upper = sma_20 + (std_20 * 2)
            bb_lower = sma_20 - (std_20 * 2)
            indicators["bb_upper"] = bb_upper
            indicators["bb_lower"] = bb_lower
            width = (bb_upper - bb_lower).replace(0, np.nan)
            indicators["bb_position"] = (close - bb_lower) / width

            vol_sma = df["volume"].rolling(20).mean().replace(0, np.nan)
            indicators["volume_sma"] = vol_sma
            indicators["volume_ratio"] = df["volume"] / vol_sma

            indicators["price_change"] = close.pct_change()
            indicators["volatility"] = indicators["price_change"].rolling(20).std()

            # Fibonacci Pattern Analysis
            if len(df) >= 20:  # Minimum length for Fibonacci analysis
                try:
                    fib_features = self.fibonacci.get_features(df)
                    indicators.update({f"fib_{key}": value for key, value in fib_features.items()})
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.warning("Error calculating Fibonacci features: %s", e)
                    # Skip Fibonacci features if calculation fails (no fallback data)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Technical indicators calculation failed")
            return {}
        else:
            return indicators

    def _calculate_support_resistance(self, df: pd.DataFrame) -> tuple[list[float], list[float]]:
        try:
            recent = df.tail(100)
            highs = recent["high"].rolling(10, center=True).max()
            lows = recent["low"].rolling(10, center=True).min()
            peaks = recent.loc[recent["high"] == highs, "high"].dropna()
            troughs = recent.loc[recent["low"] == lows, "low"].dropna()
            resistance = peaks.nlargest(3).tolist()
            support = troughs.nsmallest(3).tolist()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Support/resistance calculation failed")
            return [], []
        else:
            return support, resistance

    def _predict_price_arima(self, prices: pd.Series, _horizon: int) -> tuple[float, float]:
        try:
            if len(prices) < 30:
                return float(prices.iloc[-1]), 0.5
            X = prices.shift(1).dropna()
            y = prices.loc[X.index]
            slope, intercept, r_value, _p, _se = stats.linregress(X, y)
            current = float(prices.iloc[-1])
            predicted = float(intercept + slope * current)
            confidence = ConfidenceNormalizer.normalize(float(min(0.9, max(0.1, r_value**2))))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("ARIMA-like prediction failed: %s", e)
            return (float(prices.iloc[-1]) if len(prices) else 0.0), 0.5
        else:
            return predicted, confidence

    def _predict_price_trend(self, df: pd.DataFrame, horizon: int) -> tuple[float, float]:
        try:
            if len(df) < 20:
                return float(df["close"].iloc[-1]), 0.5
            sma_20 = df["close"].rolling(20).mean()
            current = float(df["close"].iloc[-1])
            if len(sma_20.dropna()) < 10:
                return current, 0.5
            slope = float((sma_20.iloc[-1] - sma_20.iloc[-10]) / 10)
            predicted = current + (slope * horizon)
            strength = abs(slope) / max(current, 1e-9)
            confidence = ConfidenceNormalizer.normalize(float(min(0.9, max(0.1, strength * 100))))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Trend prediction failed: %s", e)
            return (float(df["close"].iloc[-1]) if len(df) else 0.0), 0.5
        else:
            return predicted, confidence

    def _predict_price_volatility(self, df: pd.DataFrame, horizon: int) -> tuple[float, float]:
        try:
            if len(df) < 20:
                return float(df["close"].iloc[-1]), 0.5
            returns = df["close"].pct_change().dropna()
            vol = float(returns.rolling(20).std().dropna().iloc[-1]) if len(returns) >= 20 else float(returns.std())
            current = float(df["close"].iloc[-1])
            rng = np.random.default_rng()
            expected_change = float(rng.normal(0.0, vol * np.sqrt(horizon)))
            predicted = current * (1.0 + expected_change)
            confidence = ConfidenceNormalizer.normalize(float(min(0.9, max(0.1, 1.0 - vol * 10))))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Volatility-based prediction failed: %s", e)
            return (float(df["close"].iloc[-1]) if len(df) else 0.0), 0.5
        else:
            return predicted, confidence

    async def predict_price(self, symbol: str, ohlcv_data: list[list[float]]) -> PricePrediction:
        """
        Predict price for symbol using live OHLCV data (backend port 8000).

        Args:
            symbol: Trading symbol (must be in Top-10)
            ohlcv_data: Live OHLCV data (at least 30 data points required)

        Returns:
            PricePrediction with live predictions

        Raises:
            ValueError: If insufficient data or symbol not in Top-10
        """
        # Validate data before try block to avoid TRY301
        if not ohlcv_data or len(ohlcv_data) < 30:
            msg = f"Insufficient OHLCV data for {symbol}: need at least 30 data points, got {len(ohlcv_data) if ohlcv_data else 0}"
            logger.error(msg)
            raise ValueError(msg)

        try:
            df = pd.DataFrame(
                ohlcv_data,
                columns=["timestamp", "open", "high", "low", "close", "volume"],
            )
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
            df = df.set_index("timestamp")
            df = df.sort_index()

            current_price = float(df["close"].iloc[-1])
            indicators = self._calculate_technical_indicators(df)

            predictions: dict[str, float] = {}
            confidences: dict[str, float] = {}

            for horizon in self.prediction_horizons:
                if horizon <= 1:
                    pred, conf = self._predict_price_arima(df["close"], horizon)
                elif horizon <= 4:
                    pred, conf = self._predict_price_trend(df, horizon)
                else:
                    pred, conf = self._predict_price_volatility(df, horizon)
                predictions[f"{horizon}h"] = float(pred)
                confidences[f"{horizon}h"] = float(conf)

            support_levels, resistance_levels = self._calculate_support_resistance(df)
            breakout_prob = self._calculate_breakout_probability(df, indicators)
            reversal_prob = self._calculate_reversal_probability(df, indicators)

            price_targets = {
                "conservative": current_price * 1.02,
                "moderate": current_price * 1.05,
                "aggressive": current_price * 1.10,
                "support": (support_levels[0] if support_levels else current_price * 0.98),
                "resistance": (resistance_levels[0] if resistance_levels else current_price * 1.02),
            }

            return PricePrediction(
                symbol=symbol,
                current_price=current_price,
                predicted_price_1h=predictions.get("1h", current_price),
                predicted_price_4h=predictions.get("4h", current_price),
                predicted_price_24h=predictions.get("24h", current_price),
                confidence_1h=confidences.get("1h", 0.5),
                confidence_4h=confidences.get("4h", 0.5),
                confidence_24h=confidences.get("24h", 0.5),
                price_targets=price_targets,
                support_levels=support_levels,
                resistance_levels=resistance_levels,
                breakout_probability=breakout_prob,
                reversal_probability=reversal_prob,
                timestamp=datetime.now(timezone.utc),
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Price prediction failed for %s", symbol)
            msg = f"Price prediction failed for {symbol}: {e!s}"
            raise RuntimeError(msg) from e

    def _calculate_breakout_probability(self, df: pd.DataFrame, indicators: dict[str, Any]) -> float:
        try:
            if not indicators or len(df) < 20:
                return 0.5

            factors: list[float] = []

            vr = indicators.get("volume_ratio")
            if vr is not None and not np.isnan(vr.iloc[-1]):
                vr_val = float(vr.iloc[-1])
                if vr_val > 1.5:
                    factors.append(0.8)
                elif vr_val > 1.2:
                    factors.append(0.6)
                else:
                    factors.append(0.4)

            vol = indicators.get("volatility")
            if vol is not None and not np.isnan(vol.iloc[-1]):
                vol_val = float(vol.iloc[-1])
                factors.append(0.7 if vol_val > 0.02 else 0.5)

            rsi = indicators.get("rsi")
            if rsi is not None and not np.isnan(rsi.iloc[-1]):
                rsi_val = float(rsi.iloc[-1])
                factors.append(0.6 if 30 < rsi_val < 70 else 0.4)

            macd = indicators.get("macd")
            macd_signal = indicators.get("macd_signal")
            if macd is not None and macd_signal is not None:
                m = float(macd.iloc[-1])
                s = float(macd_signal.iloc[-1])
                factors.append(0.7 if m > s else 0.3)

            return float(np.mean(factors)) if factors else 0.5
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Breakout probability calculation failed: %s", e)
            return 0.5

    def _calculate_reversal_probability(self, df: pd.DataFrame, indicators: dict[str, Any]) -> float:
        try:
            if not indicators or len(df) < 20:
                return 0.5

            factors: list[float] = []

            rsi = indicators.get("rsi")
            if rsi is not None and not np.isnan(rsi.iloc[-1]):
                r = float(rsi.iloc[-1])
                if r > 80 or r < 20:
                    factors.append(0.8)
                elif r > 70 or r < 30:
                    factors.append(0.6)
                else:
                    factors.append(0.3)

            bb_pos = indicators.get("bb_position")
            if bb_pos is not None and not np.isnan(bb_pos.iloc[-1]):
                bp = float(bb_pos.iloc[-1])
                factors.append(0.7 if bp > 0.9 or bp < 0.1 else 0.4)

            macd = indicators.get("macd")
            macd_signal = indicators.get("macd_signal")
            if macd is not None and macd_signal is not None:
                m = float(macd.iloc[-1])
                s = float(macd_signal.iloc[-1])
                diverging = (m > 0 and s < 0) or (m < 0 and s > 0)
                factors.append(0.6 if diverging else 0.4)

            return float(np.mean(factors)) if factors else 0.5
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Reversal probability calculation failed: %s", e)
            return 0.5

    async def forecast_volatility(self, symbol: str, ohlcv_data: list[list[float]]) -> VolatilityForecast:
        """
        Forecast volatility for symbol using live OHLCV data (backend port 8000).

        Args:
            symbol: Trading symbol (must be in Top-10)
            ohlcv_data: Live OHLCV data (at least 30 data points required)

        Returns:
            VolatilityForecast with live volatility predictions

        Raises:
            ValueError: If insufficient data or symbol not in Top-10
        """
        # Validate data before try block to avoid TRY301
        if not ohlcv_data or len(ohlcv_data) < 30:
            msg = f"Insufficient OHLCV data for {symbol}: need at least 30 data points, got {len(ohlcv_data) if ohlcv_data else 0}"
            logger.error(msg)
            raise ValueError(msg)

        try:
            df = pd.DataFrame(
                ohlcv_data,
                columns=["timestamp", "open", "high", "low", "close", "volume"],
            )
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
            df = df.set_index("timestamp").sort_index()

            returns = df["close"].pct_change()
            rolling_std = returns.rolling(20).std()
            valid_std = rolling_std.dropna()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error processing volatility data for {symbol}: {e}")
            raise

        # Validate standard deviation data outside try to avoid TRY301
        if len(valid_std) == 0:
            msg = f"Cannot calculate volatility for {symbol}: no valid standard deviation data"
            logger.error(msg)
            raise ValueError(msg)

        try:
            current_vol = float(valid_std.iloc[-1])
            vol_tail = rolling_std.tail(10).dropna()
            recent_vol = float(vol_tail.mean()) if len(vol_tail) else current_vol
            vol_trend_series = rolling_std.tail(10).pct_change().dropna()
            vol_trend = float(vol_trend_series.mean()) if len(vol_trend_series) else 0.0

            preds: dict[str, float] = {}
            for horizon in self.prediction_horizons:
                preds[f"{horizon}h"] = float(max(0.0, recent_vol * (1.0 + vol_trend * horizon)))

            if current_vol < self.volatility_regimes["low"]:
                regime = "low"
            elif current_vol < self.volatility_regimes["normal"]:
                regime = "normal"
            elif current_vol < self.volatility_regimes["high"]:
                regime = "high"
            else:
                regime = "extreme"

            trend = "stable"
            if vol_trend > 0.01:
                trend = "increasing"
            elif vol_trend < -0.01:
                trend = "decreasing"

            confidence = ConfidenceNormalizer.normalize(float(min(0.9, max(0.1, 1.0 - abs(vol_trend) * 10))))

            return VolatilityForecast(
                symbol=symbol,
                current_volatility=current_vol,
                predicted_volatility_1h=preds.get("1h", current_vol),
                predicted_volatility_4h=preds.get("4h", current_vol),
                predicted_volatility_24h=preds.get("24h", current_vol),
                volatility_regime=regime,
                volatility_trend=trend,
                confidence=confidence,
                timestamp=datetime.now(timezone.utc),
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Volatility forecasting failed for %s", symbol)
            msg = f"Volatility forecasting failed for {symbol}: {e!s}"
            raise RuntimeError(msg) from e

    async def analyze_market_microstructure(self, symbol: str, ohlcv_data: list[list[float]]) -> MarketMicrostructureAnalysis:
        """
        Analyze market microstructure for symbol using live OHLCV data (backend port 8000).

        Args:
            symbol: Trading symbol (must be in Top-10)
            ohlcv_data: Live OHLCV data (at least 20 data points required)

        Returns:
            MarketMicrostructureAnalysis with live microstructure data

        Raises:
            ValueError: If insufficient data or symbol not in Top-10
        """
        # Validate data before try block to avoid TRY301
        if not ohlcv_data or len(ohlcv_data) < 20:
            msg = f"Insufficient OHLCV data for {symbol}: need at least 20 data points, got {len(ohlcv_data) if ohlcv_data else 0}"
            logger.error(msg)
            raise ValueError(msg)

        try:
            df = pd.DataFrame(
                ohlcv_data,
                columns=["timestamp", "open", "high", "low", "close", "volume"],
            )
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
            df = df.set_index("timestamp").sort_index()

            current_price = float(df["close"].iloc[-1])
            bid_ask_spread = current_price * 0.001

            vol_tail = df["volume"].tail(10)
            recent_volume = float(vol_tail.mean())
            vol_trend_series = vol_tail.pct_change().dropna()
            volume_trend = float(vol_trend_series.mean()) if len(vol_trend_series) else 0.0
            order_book_imbalance = float(min(1.0, max(-1.0, volume_trend * 10)))

            market_depth = recent_volume * 0.1
            price_impact = float(abs(df["close"].pct_change().tail(10).mean()) * 100)

            liquidity_score = float(min(1.0, market_depth / max(current_price * 1000, 1e-9)))

            price_stability = float(1.0 - df["close"].pct_change().abs().tail(10).mean())
            market_maker_activity = float(max(0.0, min(1.0, price_stability)))

            threshold = float(df["volume"].quantile(0.8))
            large_ratio = float((df["volume"] > threshold).sum() / max(len(df), 1))
            institutional_flow = float(min(1.0, large_ratio * 2.0))

            price_momentum = float(df["close"].pct_change().tail(5).mean())
            retail_sentiment = float((price_momentum + 1.0) / 2.0)

            return MarketMicrostructureAnalysis(
                symbol=symbol,
                bid_ask_spread=bid_ask_spread,
                order_book_imbalance=order_book_imbalance,
                market_depth=market_depth,
                price_impact=price_impact,
                liquidity_score=liquidity_score,
                market_maker_activity=market_maker_activity,
                institutional_flow=institutional_flow,
                retail_sentiment=retail_sentiment,
                timestamp=datetime.now(timezone.utc),
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Market microstructure analysis failed for %s", symbol)
            msg = f"Market microstructure analysis failed for {symbol}: {e!s}"
            raise RuntimeError(msg) from e

    async def get_trading_recommendation(
        self,
        price_pred: PricePrediction,
        vol_forecast: VolatilityForecast,
        microstructure: MarketMicrostructureAnalysis,
    ) -> dict[str, Any]:
        try:
            rec: dict[str, Any] = {
                "symbol": price_pred.symbol,
                "action": "HOLD",
                "confidence": 0.5,
                "reasoning": [],
                "price_targets": price_pred.price_targets,
                "risk_assessment": "medium",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            cp = max(price_pred.current_price, 1e-9)
            chg_1h = (price_pred.predicted_price_1h - cp) / cp
            chg_24h = (price_pred.predicted_price_24h - cp) / cp

            if chg_1h > 0.02 and price_pred.confidence_1h > 0.6:
                rec["action"] = "BUY"
                rec["confidence"] = ConfidenceNormalizer.normalize(float(price_pred.confidence_1h))
                rec["reasoning"].append(f"Strong 1h signal: +{chg_1h:.2%}")
            elif chg_1h < -0.02 and price_pred.confidence_1h > 0.6:
                rec["action"] = "SELL"
                rec["confidence"] = ConfidenceNormalizer.normalize(float(price_pred.confidence_1h))
                rec["reasoning"].append(f"Strong 1h signal: {chg_1h:.2%}")
            elif chg_24h > 0.05 and price_pred.confidence_24h > 0.6:
                rec["action"] = "BUY"
                rec["confidence"] = ConfidenceNormalizer.normalize(float(price_pred.confidence_24h))
                rec["reasoning"].append(f"Strong 24h signal: +{chg_24h:.2%}")
            elif chg_24h < -0.05 and price_pred.confidence_24h > 0.6:
                rec["action"] = "SELL"
                rec["confidence"] = ConfidenceNormalizer.normalize(float(price_pred.confidence_24h))
                rec["reasoning"].append(f"Strong 24h signal: {chg_24h:.2%}")

            if vol_forecast.volatility_regime == "extreme":
                rec["risk_assessment"] = "high"
                rec["reasoning"].append("Extreme volatility regime")
            elif vol_forecast.volatility_regime == "low":
                rec["risk_assessment"] = "low"
                rec["reasoning"].append("Low volatility regime")

            if microstructure.liquidity_score < 0.3:
                rec["risk_assessment"] = "high"
                rec["reasoning"].append("Low liquidity (slippage risk)")
            elif microstructure.liquidity_score > 0.7:
                rec["reasoning"].append("High liquidity (good execution)")

            if price_pred.breakout_probability > 0.7:
                rec["reasoning"].append(f"High breakout probability: {price_pred.breakout_probability:.2%}")
            elif price_pred.reversal_probability > 0.7:
                rec["reasoning"].append(f"High reversal probability: {price_pred.reversal_probability:.2%}")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Trading recommendation failed: %s", e)
            return {
                "symbol": price_pred.symbol,
                "action": "HOLD",
                "confidence": 0.0,
                "reasoning": ["Error in analysis"],
                "price_targets": {},
                "risk_assessment": "high",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        else:
            return rec


__all__ = [
    "EXCHANGE_ID",
    "TOP10_COINS",
    "MarketMicrostructureAnalysis",
    "PredictiveAnalytics",
    "PricePrediction",
    "VolatilityForecast",
    "_to_ccxt_symbol",
]
