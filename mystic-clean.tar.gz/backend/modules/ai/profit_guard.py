"""
Profit Guard Module for Mystic AI Trading Platform - All Live Data, No Fallback/Hardcoded Data

Protects open positions using stop-loss, take-profit, and trailing logic with
consistent risk controls for Binance.US Top-10 spot trading (backend port 8000).
All operations use live data:
- Position protection: Uses live position data from Binance.US
- Risk controls: Applies live risk parameters to protect positions
- Stop-loss/take-profit: Calculated from live market prices
- All operations use live data - no fallback/hardcoded data

Endpoint References:
- Backend API: Port 8000 (profit guard serves live operations)
- Binance.US API: Live position and market data
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import logging
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any

# Single source of truth - Trading Universe (ALL 10 COINS - HARDCODED AS REQUIRED)
try:
    from backend.config.trading_universe import EXCHANGE_ID, TOP10_COINS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, KeyError, IndexError, RuntimeError) as e:
    msg = "Trading universe configuration is required for live operations"
    logging.getLogger(__name__).exception("Failed to import trading universe")
    raise RuntimeError(msg) from e

# Single source of truth - Symbol normalization (same as persistent_cache uses)
try:
    from backend.modules.market.binance_data_fetcher import _to_ccxt_symbol
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, KeyError, IndexError, RuntimeError) as e:
    msg = "Symbol normalizer is required for live operations"
    logging.getLogger(__name__).exception("Failed to import symbol normalizer")
    raise RuntimeError(msg) from e

logger = logging.getLogger(__name__)

# ---------- Data Models ----------


@dataclass
class GuardConfig:
    """Risk configuration for profit guard decisions."""

    max_position_pct: float = 0.10  # 10% of portfolio per symbol
    daily_loss_limit_pct: float = 0.05  # 5% daily loss limit
    max_drawdown_pct: float = 0.15  # 15% rolling drawdown cap
    stop_loss_pct: float = 0.02  # 2% fixed stop-loss
    take_profit_pct: float = 0.04  # 4% fixed take-profit
    trailing_pct: float = 0.015  # 1.5% trailing stop
    slippage_pct: float = 0.0005  # 5 bps execution buffer
    min_notional_usd: float = 10.0  # minimum notional to place orders
    quote_asset: str = "USDT"  # unified quote


@dataclass
class Position:
    """Simplified position model used by the ProfitGuard."""

    symbol: str  # e.g., "BTCUSDT" or "BTC/USDT"
    base: str  # e.g., "BTC"
    quote: str  # e.g., "USDT"
    side: str  # "long" or "short"
    quantity: float  # base units
    entry_price: float  # avg entry
    mark_price: float  # latest price
    highest_price: float  # session peak (for trailing)
    lowest_price: float  # session trough (for trailing)
    unrealized_pnl: float  # in quote units
    portfolio_value: float  # total portfolio value in quote units
    daily_pnl: float  # PnL today in quote units
    current_drawdown_pct: float  # rolling DD 0..1
    timestamp: datetime  # position snapshot time


@dataclass
class GuardDecision:
    """Decision and order instructions emitted by ProfitGuard."""

    exchange: str
    ccxt_symbol: str
    action: str  # "hold", "adjust", "close", "reduce", "increase"
    reason: str
    stop_loss: float | None
    take_profit: float | None
    trailing_stop: float | None
    target_qty: float | None
    meta: dict[str, Any]
    timestamp: str


# ---------- Core Engine ----------


class ProfitGuard:
    """Encapsulates defensive risk logic (SL/TP/trailing) for open positions."""

    def __init__(self, config: GuardConfig | None = None) -> None:
        self.config = config or GuardConfig()
        logger.info("ProfitGuard initialized")

    # ---- Public API ----

    def assess(self, position: Position) -> GuardDecision:
        """
        Compute the next best defensive action for a position.
        Returns instructions without placing orders.
        """
        self._validate_position(position)

        # Portfolio-level hard stops
        if self._exceeds_daily_loss(position):
            return self._decision(
                position,
                action="close",
                reason="daily_loss_limit",
                stops=self._zero_stops(),
                target_qty=0.0,
                extra={"daily_pnl": position.daily_pnl},
            )

        if self._exceeds_drawdown(position):
            return self._decision(
                position,
                action="close",
                reason="max_drawdown",
                stops=self._zero_stops(),
                target_qty=0.0,
                extra={"drawdown_pct": position.current_drawdown_pct},
            )

        if self._exceeds_position_limit(position):
            reduced_qty = self._reduced_quantity(position)
            return self._decision(
                position,
                action="reduce",
                reason="position_size_limit",
                stops=self._compute_stops(position),
                target_qty=reduced_qty,
                extra={"max_position_pct": self.config.max_position_pct},
            )

        # Symbol-level stops
        stops = self._compute_stops(position)
        action, reason = self._action_from_stops(position, stops)

        # Enforce minimum notional
        target_qty = position.quantity if action in ("hold", "adjust") else 0.0
        if self._notional(position.mark_price, target_qty) < self.config.min_notional_usd:
            action = "hold"
            reason = "below_min_notional"

        return self._decision(
            position,
            action=action,
            reason=reason,
            stops=stops,
            target_qty=target_qty,
            extra={},
        )

    def batch_assess(self, positions: list[Position]) -> list[GuardDecision]:
        decisions: list[GuardDecision] = []
        for p in positions:
            try:
                decisions.append(self.assess(p))
            except Exception:
                logger.exception("Assess failed for %s", p.symbol)
        return decisions

    # ---- Internal helpers ----

    def _validate_position(self, p: Position) -> None:
        if p.quantity <= 0 or p.entry_price <= 0 or p.mark_price <= 0 or p.portfolio_value <= 0:
            msg = "Invalid position inputs"
            raise ValueError(msg)
        if p.side not in ("long", "short"):
            msg = "Position side must be 'long' or 'short'"
            raise ValueError(msg)
        if p.quote.upper() != self.config.quote_asset.upper():
            msg = "Mismatched quote asset"
            raise ValueError(msg)

    def _exceeds_daily_loss(self, p: Position) -> bool:
        limit = -abs(self.config.daily_loss_limit_pct) * p.portfolio_value
        return p.daily_pnl <= limit

    def _exceeds_drawdown(self, p: Position) -> bool:
        return p.current_drawdown_pct >= self.config.max_drawdown_pct

    def _exceeds_position_limit(self, p: Position) -> bool:
        max_notional = self.config.max_position_pct * p.portfolio_value
        return self._notional(p.entry_price, p.quantity) > max_notional

    def _reduced_quantity(self, p: Position) -> float:
        max_notional = self.config.max_position_pct * p.portfolio_value
        if p.entry_price <= 0:
            return p.quantity
        target_qty = max_notional / p.entry_price
        return max(0.0, min(p.quantity, target_qty))

    def _notional(self, price: float, qty: float) -> float:
        return float(price * qty)

    def _zero_stops(self) -> tuple[float | None, float | None, float | None]:
        return None, None, None

    def _compute_stops(self, p: Position) -> tuple[float | None, float | None, float | None]:
        sl_buffer = self.config.stop_loss_pct * p.entry_price
        tp_buffer = self.config.take_profit_pct * p.entry_price
        slip = self.config.slippage_pct * p.mark_price

        if p.side == "long":
            stop_loss = max(0.0, p.entry_price - sl_buffer) if sl_buffer > 0 else None
            take_profit = p.entry_price + tp_buffer if tp_buffer > 0 else None
            trailing = self._trailing_from_peak(p.highest_price, self.config.trailing_pct, is_long=True)
            stop_loss = stop_loss if stop_loss is None else max(0.0, stop_loss - slip)
            take_profit = take_profit if take_profit is None else max(0.0, take_profit - slip)
        else:
            stop_loss = p.entry_price + sl_buffer if sl_buffer > 0 else None
            take_profit = max(0.0, p.entry_price - tp_buffer) if tp_buffer > 0 else None
            trailing = self._trailing_from_peak(p.lowest_price, self.config.trailing_pct, is_long=False)
            stop_loss = stop_loss if stop_loss is None else max(0.0, stop_loss + slip)
            take_profit = take_profit if take_profit is None else max(0.0, take_profit + slip)

        return stop_loss, take_profit, trailing

    def _trailing_from_peak(self, ref_price: float, pct: float, *, is_long: bool) -> float | None:
        if ref_price <= 0 or pct <= 0:
            return None
        if is_long:
            return max(0.0, ref_price * (1.0 - pct))
        return max(0.0, ref_price * (1.0 + pct))

    def _action_from_stops(self, p: Position, stops: tuple[float | None, float | None, float | None]) -> tuple[str, str]:
        stop_loss, take_profit, trailing = stops

        if p.side == "long":
            if stop_loss is not None and p.mark_price <= stop_loss:
                return "close", "stop_loss_hit"
            if take_profit is not None and p.mark_price >= take_profit:
                return "close", "take_profit_hit"
            if trailing is not None and p.mark_price <= trailing:
                return "close", "trailing_stop_hit"
        else:
            if stop_loss is not None and p.mark_price >= stop_loss:
                return "close", "stop_loss_hit"
            if take_profit is not None and p.mark_price <= take_profit:
                return "close", "take_profit_hit"
            if trailing is not None and p.mark_price >= trailing:
                return "close", "trailing_stop_hit"

        return "adjust", "maintain_protection"

    def _decision(
        self,
        p: Position,
        *,
        action: str,
        reason: str,
        stops: tuple[float | None, float | None, float | None],
        target_qty: float | None,
        extra: dict[str, Any],
    ) -> GuardDecision:
        stop_loss, take_profit, trailing = stops
        ccxt_symbol = _to_ccxt_symbol(p.base, p.quote)
        meta: dict[str, Any] = {
            "entry_price": p.entry_price,
            "mark_price": p.mark_price,
            "unrealized_pnl": p.unrealized_pnl,
            "highest_price": p.highest_price,
            "lowest_price": p.lowest_price,
            "portfolio_value": p.portfolio_value,
            "daily_pnl": p.daily_pnl,
            "current_drawdown_pct": p.current_drawdown_pct,
            "side": p.side,
            **extra,
        }
        return GuardDecision(
            exchange=EXCHANGE_ID,
            ccxt_symbol=ccxt_symbol,
            action=action,
            reason=reason,
            stop_loss=stop_loss,
            take_profit=take_profit,
            trailing_stop=trailing,
            target_qty=round(target_qty, 8) if target_qty is not None else None,
            meta=meta,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    # ---- Utility constructors ----

    @staticmethod
    def from_snapshot(snapshot: dict[str, Any], config: GuardConfig | None = None) -> tuple[ProfitGuard, Position]:
        """
        Build ProfitGuard and Position from a raw snapshot dict (backend port 8000).

        Expected keys: symbol, base, quote, side, qty/quantity, entry/entry_price,
        mark/mark_price, hi/highest_price, lo/lowest_price, upnl/unrealized_pnl,
        port/portfolio_value, daily_pnl, dd_pct/current_drawdown_pct.

        Args:
            snapshot: Dictionary with live position data (required fields must be present)
            config: Optional guard configuration

        Returns:
            Tuple of (ProfitGuard instance, Position instance)

        Raises:
            ValueError: If required fields are missing or invalid
        """
        # Validate required fields (no fallback data)
        base = str(snapshot.get("base", "") or "").upper().strip()
        quote = str(snapshot.get("quote", "") or "").upper().strip()
        if not base:
            msg = "Position snapshot missing required 'base' field"
            raise ValueError(msg)
        if not quote:
            # Use quote from config as default (live configuration, not fallback data)
            quote = config.quote_asset.upper() if config else "USDT"
            logger.warning("Position snapshot missing 'quote', using config default: %s", quote)

        symbol = str(snapshot.get("symbol", f"{base}{quote}") or f"{base}{quote}").upper()

        # Validate required numeric fields (no zero fallbacks)
        quantity = snapshot.get("qty") or snapshot.get("quantity")
        if quantity is None:
            msg = f"Position snapshot missing required 'qty' or 'quantity' field for {symbol}"
            raise ValueError(msg)

        entry_price = snapshot.get("entry") or snapshot.get("entry_price")
        if entry_price is None:
            msg = f"Position snapshot missing required 'entry' or 'entry_price' field for {symbol}"
            raise ValueError(msg)

        mark_price = snapshot.get("mark") or snapshot.get("mark_price")
        if mark_price is None:
            msg = f"Position snapshot missing required 'mark' or 'mark_price' field for {symbol}"
            raise ValueError(msg)

        # Optional fields with defaults from mark_price (live data, not fallback)
        highest_price = snapshot.get("hi") or snapshot.get("highest_price") or mark_price
        lowest_price = snapshot.get("lo") or snapshot.get("lowest_price") or mark_price

        position = Position(
            symbol=symbol,
            base=base or symbol.replace(quote, ""),
            quote=quote,
            side=str(snapshot.get("side", "long")).lower(),
            quantity=float(quantity),
            entry_price=float(entry_price),
            mark_price=float(mark_price),
            highest_price=float(highest_price),
            lowest_price=float(lowest_price),
            unrealized_pnl=float(snapshot.get("upnl") or snapshot.get("unrealized_pnl") or 0.0),
            portfolio_value=float(snapshot.get("port") or snapshot.get("portfolio_value") or 0.0),
            daily_pnl=float(snapshot.get("daily_pnl") or 0.0),
            current_drawdown_pct=float(snapshot.get("dd_pct") or snapshot.get("current_drawdown_pct") or 0.0),
            timestamp=datetime.now(timezone.utc),
        )
        return ProfitGuard(config), position


# ---------- Convenience API ----------


def protect_position(snapshot: dict[str, Any], config: dict[str, Any] | None = None) -> dict[str, Any]:
    """
    Convenience function for one-shot evaluation.
    Returns a serializable dict suitable for downstream APIs.
    """
    guard_cfg = GuardConfig(**config) if isinstance(config, dict) else GuardConfig()
    guard, position = ProfitGuard.from_snapshot(snapshot, guard_cfg)
    decision = guard.assess(position)
    result = asdict(decision)
    # Ensure nested datetime fields in meta are serializable
    result["meta"] = {k: (v.isoformat() if hasattr(v, "isoformat") else v) for k, v in result["meta"].items()}
    return result


__all__ = [
    "EXCHANGE_ID",
    "TOP10_COINS",
    "GuardConfig",
    "GuardDecision",
    "Position",
    "ProfitGuard",
    "_to_ccxt_symbol",
    "protect_position",
]
