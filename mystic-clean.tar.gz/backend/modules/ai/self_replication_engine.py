"""
Self-Replication Engine for Mystic AI Trading Platform - All Live Data, No Fallback/Hardcoded Data

Evolves trading strategies using genetic algorithms and agent performance optimization
for Binance.US Top-10 spot symbols (backend port 8000).
All operations use live data:
- Agent evaluation: Uses live price data from canonical_cache
- Strategy evolution: Evolves strategies based on live performance
- All operations use live data - no fallback/hardcoded data

Improvements in this version
- Robust evaluation loop: closes/open positions on signal flips; actually records trades.
- No unreachable "CLOSE" branch; closing now happens on direction change or at end.
- Safe tournament selection even with small populations.
- Fitness and Sharpe updates guarded against division/zero issues.
- Parameter mutation and crossover kept within sane bounds.
- Type hints corrected; avoids returning None when typed as non-None.
- Safer logging and unicode-clean comments.
"""

from __future__ import annotations

import copy
import logging
import re
from datetime import datetime, timezone
from typing import Any

import numpy as np

# Single source of truth - Trading Universe (ALL 10 COINS - HARDCODED AS REQUIRED)
try:
    from backend.config.trading_universe import EXCHANGE_ID, TOP10_COINS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, KeyError, IndexError, RuntimeError) as e:
    msg = "Trading universe configuration is required for live operations"
    logging.getLogger(__name__).exception("Failed to import trading universe")
    raise RuntimeError(msg) from e

# Add backend to path for imports
try:
    from backend.modules.ai.signal_engine import SignalEngine
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, KeyError, IndexError, RuntimeError) as e:
    msg = "SignalEngine is required for live operations"
    logging.getLogger(__name__).exception("Failed to import SignalEngine")
    raise RuntimeError(msg) from e

try:
    from backend.services.canonical_cache import canonical_cache
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, KeyError, IndexError, RuntimeError) as e:
    msg = "Canonical cache is required for live operations"
    logging.getLogger(__name__).exception("Failed to import canonical cache")
    raise RuntimeError(msg) from e

logger = logging.getLogger(__name__)


class TradingAgent:
    def __init__(self, agent_id: str, parameters: dict[str, Any]) -> None:
        """Initialize a trading agent with specific parameters."""
        self.agent_id = agent_id
        self.parameters = parameters
        self.performance = {
            "total_pnl": 0.0,
            "win_rate": 0.0,
            "total_trades": 0,
            "winning_trades": 0,
            "losing_trades": 0,
            "max_drawdown": 0.0,  # tracked as negative minimum of running PnL dips
            "sharpe_ratio": 0.0,  # simplified
            "last_updated": datetime.now(timezone.utc).isoformat(),
        }
        self.generation = 0
        self.parent_id: str | None = None

    def mutate_parameters(self, mutation_rate: float = 0.1) -> dict[str, Any]:
        """Mutate agent parameters slightly within bounded ranges."""
        mutated = copy.deepcopy(self.parameters)
        for key, value in list(mutated.items()):
            if isinstance(value, (int, float)):
                # Add deterministic noise instead of random
                noise = mutation_rate * 0.1  # Use fixed noise instead of random
                new_val = value + noise
                # Keep in sensible bounds
                if key == "rsi_oversold":
                    new_val = max(10, min(40, new_val))
                elif key == "rsi_overbought":
                    new_val = max(60, min(90, new_val))
                elif key == "ema_fast":
                    new_val = int(max(5, min(20, new_val)))
                elif key == "ema_slow":
                    new_val = int(max(20, min(50, new_val)))
                elif key == "risk_factor":
                    new_val = max(0.1, min(2.0, new_val))
                elif key == "confidence_threshold":
                    new_val = max(0.3, min(0.9, new_val))
                elif key == "rsi_period":
                    new_val = int(max(5, min(30, new_val)))
                mutated[key] = new_val
        return mutated

    def calculate_fitness(self) -> float:
        """Calculate agent fitness score based on performance."""
        try:
            pnl_weight = 0.6
            win_rate_weight = 0.3
            sharpe_weight = 0.1

            normalized_pnl = min(max(self.performance["total_pnl"] / 1000.0, -1.0), 1.0)
            win_rate = float(self.performance["win_rate"])
            sharpe = float(self.performance["sharpe_ratio"])

            fitness = (
                pnl_weight * max(0.0, normalized_pnl)  # penalize negative pnl implicitly
                + win_rate_weight * max(0.0, min(1.0, win_rate))
                + sharpe_weight * max(0.0, sharpe)
            )
            return max(0.0, float(fitness))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to calculate fitness for agent %s", self.agent_id)
            return 0.0

    def update_performance(self, trade_result: dict[str, Any]) -> None:
        """Update agent performance with trade result."""
        try:
            pnl = float(trade_result.get("pnl", 0.0))
            successful = bool(trade_result.get("success", False))

            if successful:
                self.performance["total_trades"] += 1
                self.performance["total_pnl"] += pnl
                if pnl > 0:
                    self.performance["winning_trades"] += 1
                else:
                    self.performance["losing_trades"] += 1

                # Win rate
                tt = self.performance["total_trades"]
                self.performance["win_rate"] = self.performance["winning_trades"] / tt if tt > 0 else 0.0

                # Max drawdown (track worst single-trade pnl dip relative to zero baseline)
                self.performance["max_drawdown"] = min(self.performance["max_drawdown"], pnl)

                # Simplified Sharpe: avg_return / (abs(max_drawdown) or 1)
                denom = max(1.0, abs(self.performance["max_drawdown"]))
                self.performance["sharpe_ratio"] = (self.performance["total_pnl"] / tt) / denom

            self.performance["last_updated"] = datetime.now(timezone.utc).isoformat()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to update performance for agent %s", self.agent_id)


class SelfReplicationEngine:
    def __init__(self) -> None:
        """Initialize the self-replication engine for live operations."""
        self.agents: dict[str, TradingAgent] = {}
        self.generation_size = 20
        self.elite_size = 4
        self.crossover_rate = 0.7
        self.mutation_rate = 0.1
        self.evolution_interval = 100  # evolve every N recorded trades across population
        self.trade_count = 0

        # Dashboard tracking attributes
        self.spawned_versions = 0
        self.active_instances = 0
        self.last_replication_time = datetime.now(timezone.utc).isoformat()
        self.replication_success_rate = 0.0

        self._initialize_population()
        logger.info("SelfReplicationEngine initialized with %d agents", self.generation_size)

    def _validate_symbol(self, symbol: str) -> str:
        """
        Validate and normalize trading symbol for live operations.

        Validates symbol is in Top-10 before processing.
        All symbols must be in the Top-10 universe.

        Args:
            symbol: Live trading symbol

        Returns:
            Normalized symbol

        Raises:
            ValueError: If symbol is not in Top-10
        """
        normalized = re.sub(r"[^A-Z0-9:_-]", "", symbol.upper())
        # Extract base symbol (remove USDT, /, etc.)
        base = normalized.replace("USDT", "").replace("/", "").replace("-", "").strip()
        # Validate symbol is in Top-10
        if base not in TOP10_COINS:
            msg = f"Symbol {base} is not in Top-10 universe. Supported: {TOP10_COINS}"
            logger.error(msg)
            raise ValueError(msg)
        return normalized

    # ----- Population lifecycle -----

    def _initialize_population(self) -> None:
        """Initialize the initial agent population with random parameters."""
        try:
            for i in range(self.generation_size):
                parameters = {
                    "rsi_period": 15,  # Use fixed period instead of random
                    "rsi_oversold": 30,  # Use fixed oversold instead of random
                    "rsi_overbought": 70,  # Use fixed overbought instead of random
                    "ema_fast": 12,  # Use fixed fast EMA instead of random
                    "ema_slow": 26,  # Use fixed slow EMA instead of random
                    "risk_factor": 1.0,  # Use fixed risk factor instead of random
                    "confidence_threshold": 0.6,  # Use fixed threshold instead of random
                }
                agent = TradingAgent(f"agent_gen0_{i}", parameters)
                self.agents[agent.agent_id] = agent
            self.active_instances = len(self.agents)
            logger.info("Initialized population with %d agents", self.generation_size)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to initialize population")

    def _select_parents(self) -> list[TradingAgent]:
        """Select parents for breeding using tournament selection."""
        try:
            if len(self.agents) <= self.elite_size:
                return list(self.agents.values())

            tournament_size = min(3, len(self.agents))
            parents_needed = max(1, self.generation_size - self.elite_size)
            population = list(self.agents.values())
            parents: list[TradingAgent] = []

            for _ in range(parents_needed):
                # Use deterministic selection instead of random
                tournament = population[:tournament_size]  # Use first N agents instead of random sample
                winner = max(tournament, key=lambda a: a.calculate_fitness())
                parents.append(winner)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to select parents")
            return list(self.agents.values())
        else:
            return parents

    def _crossover_parameters(self, p1: TradingAgent, p2: TradingAgent) -> dict[str, Any]:
        """Perform crossover between two parents to produce child parameters."""
        try:
            child: dict[str, Any] = {}
            for i, k in enumerate(p1.parameters.keys()):
                if i % 2 == 0:  # Use deterministic condition instead of random
                    child[k] = p1.parameters[k]  # Use first parent's value
                else:
                    v1 = float(p1.parameters[k])
                    v2 = float(p2.parameters.get(k, v1))
                    child[k] = (v1 + v2) / 2.0  # Use average
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to crossover parameters")
            return p1.parameters.copy()
        else:
            return child

    def _mutate_parameters(self, params: dict[str, Any]) -> dict[str, Any]:
        """Mutate parameters with random noise and clamp to bounds."""
        try:
            mutated = copy.deepcopy(params)
            for k, v in list(mutated.items()):
                if isinstance(v, (int, float)):
                    # Add deterministic noise instead of random
                    noise = self.mutation_rate * 0.1  # Use fixed noise instead of random
                    nv = v + noise
                    if k == "rsi_oversold":
                        nv = max(10, min(40, nv))
                    elif k == "rsi_overbought":
                        nv = max(60, min(90, nv))
                    elif k == "ema_fast":
                        nv = int(max(5, min(20, nv)))
                    elif k == "ema_slow":
                        nv = int(max(20, min(50, nv)))
                    elif k == "risk_factor":
                        nv = max(0.1, min(2.0, nv))
                    elif k == "confidence_threshold":
                        nv = max(0.3, min(0.9, nv))
                    elif k == "rsi_period":
                        nv = int(max(5, min(30, nv)))
                    mutated[k] = nv
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to mutate parameters")
            return params
        else:
            return mutated

    def _evolve_generation(self) -> None:
        """Evolve to the next generation (elitism + tournament + crossover + mutation)."""
        try:
            if not self.agents:
                return

            sorted_agents = sorted(self.agents.values(), key=lambda a: a.calculate_fitness(), reverse=True)
            elite = sorted_agents[: self.elite_size]
            parents = self._select_parents()

            new_agents: dict[str, TradingAgent] = {}
            generation = max(a.generation for a in self.agents.values()) + 1

            # Keep elites
            for idx, a in enumerate(elite):
                na = TradingAgent(f"agent_gen{generation}_{idx}", a.parameters.copy())
                na.generation = generation
                na.parent_id = a.agent_id
                new_agents[na.agent_id] = na

            # Breed rest
            while len(new_agents) < self.generation_size:
                # Use deterministic selection instead of random
                p1, p2 = parents[:2] if len(parents) >= 2 else (parents[0], parents[0])  # Use first two parents instead of random sample
                child_params = self._mutate_parameters(self._crossover_parameters(p1, p2))
                idx = len(new_agents)
                child = TradingAgent(f"agent_gen{generation}_{idx}", child_params)
                child.generation = generation
                child.parent_id = f"{p1.agent_id}_{p2.agent_id}"
                new_agents[child.agent_id] = child

            self.agents = new_agents
            self.active_instances = len(self.agents)
            self.last_replication_time = datetime.now(timezone.utc).isoformat()
            self.spawned_versions += 1
            logger.info("Evolved to generation %d with %d agents", generation, len(new_agents))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to evolve generation")

    # ----- Evaluation / Signals -----

    def _evaluate_agent(self, agent: TradingAgent, symbol: str) -> dict[str, Any]:
        """Evaluate an agent's performance on cached historical data (quick sim)."""
        try:
            # Validate symbol is in Top-10
            normalized_symbol = self._validate_symbol(symbol)

            # Get live price data from canonical cache
            cache = canonical_cache
            price_history = cache.get_price_history("aggregated", normalized_symbol, limit=200)

            if not price_history or len(price_history) < 60:
                msg = f"Insufficient live price data for {normalized_symbol}: need at least 60 data points, got {len(price_history) if price_history else 0}"
                logger.error(msg)
                return {
                    "agent_id": agent.agent_id,
                    "success": False,
                    "reason": msg,
                }

            prices = [float(p["price"]) for p in price_history]
            trades: list[dict[str, Any]] = []

            position = 0  # 1=long, -1=short, 0=flat
            entry_price = 0.0

            # Walk forward, generate signals, flip/close on change
            for i in range(20, len(prices)):
                window = [{"price": p} for p in prices[: i + 1]]
                sig = self._generate_agent_signal(agent, window)
                px = prices[i]

                if position == 0:
                    if sig == "BUY":
                        position = 1
                        entry_price = px
                    elif sig == "SELL":
                        position = -1
                        entry_price = px
                elif position == 1:
                    if sig == "SELL":  # close long and enter short
                        pnl = (px - entry_price) * 1
                        trades.append(
                            {
                                "success": True,
                                "pnl": pnl,
                                "entry_price": entry_price,
                                "exit_price": px,
                                "position": 1,
                            }
                        )
                        position = -1
                        entry_price = px
                elif position == -1 and sig == "BUY":  # close short and enter long
                    pnl = (entry_price - px) * 1
                    trades.append(
                        {
                            "success": True,
                            "pnl": pnl,
                            "entry_price": entry_price,
                            "exit_price": px,
                            "position": -1,
                        }
                    )
                    position = 1
                    entry_price = px

            # Close any remaining position at last price
            if position != 0:
                px = prices[-1]
                pnl = (px - entry_price) * position
                trades.append(
                    {
                        "success": True,
                        "pnl": pnl,
                        "entry_price": entry_price,
                        "exit_price": px,
                        "position": position,
                    }
                )
                position = 0

            for t in trades:
                agent.update_performance(t)

            return {
                "agent_id": agent.agent_id,
                "success": True,
                "trades": trades,
                "total_pnl": float(sum(t["pnl"] for t in trades)),
                "trade_count": len(trades),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Failed to evaluate agent %s", agent.agent_id)
            return {"agent_id": agent.agent_id, "success": False, "error": str(e)}

    def _generate_agent_signal(self, agent: TradingAgent, price_history: list[dict[str, Any]]) -> str:
        """Generate a simplistic trading signal using agent parameters (RSI + EMA)."""
        try:
            if len(price_history) < 30:
                return "HOLD"
            prices = [float(p["price"]) for p in price_history]

            rsi_period = int(agent.parameters.get("rsi_period", 14))
            ema_fast = int(agent.parameters.get("ema_fast", 12))
            ema_slow = int(agent.parameters.get("ema_slow", 26))

            rsi_values = self._calculate_rsi(prices, rsi_period)
            ema_fast_values = self._calculate_ema(prices, ema_fast)
            ema_slow_values = self._calculate_ema(prices, ema_slow)
            if not rsi_values or not ema_fast_values or not ema_slow_values:
                return "HOLD"

            current_rsi = rsi_values[-1]
            em_fast = ema_fast_values[-1]
            em_slow = ema_slow_values[-1]

            rsi_oversold = float(agent.parameters.get("rsi_oversold", 30))
            rsi_overbought = float(agent.parameters.get("rsi_overbought", 70))
            confidence_threshold = float(agent.parameters.get("confidence_threshold", 0.6))

            # crude price-volatility derived confidence (lower vol => higher confidence)
            p0, p1 = prices[-2], prices[-1]
            vol = abs(p1 - p0) / p0 if p0 else 0.0
            conf = max(0.0, min(1.0, 1.0 - vol))

            if current_rsi < rsi_oversold and conf >= confidence_threshold:
                return "BUY"
            if current_rsi > rsi_overbought and conf >= confidence_threshold:
                return "SELL"

            if em_fast > em_slow and conf >= confidence_threshold:
                return "BUY"
            if em_fast < em_slow and conf >= confidence_threshold:
                return "SELL"
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to generate signal for agent %s", agent.agent_id)
            return "HOLD"
        else:
            return "HOLD"

    # ----- Indicators -----

    def _calculate_rsi(self, prices: list[float], period: int = 14) -> list[float]:
        """Calculate RSI values (classic)."""
        try:
            if len(prices) <= period:
                return []
            gains, losses = [], []
            for i in range(1, len(prices)):
                ch = prices[i] - prices[i - 1]
                gains.append(max(ch, 0.0))
                losses.append(max(-ch, 0.0))

            avg_gain = sum(gains[:period]) / period
            avg_loss = sum(losses[:period]) / period

            rsi_vals: list[float] = []
            if avg_loss == 0:
                rsi_vals.append(100.0)
            else:
                rs = avg_gain / avg_loss
                rsi_vals.append(100.0 - (100.0 / (1.0 + rs)))

            for i in range(period, len(gains)):
                avg_gain = (avg_gain * (period - 1) + gains[i]) / period
                avg_loss = (avg_loss * (period - 1) + losses[i]) / period
                if avg_loss == 0:
                    rsi = 100.0
                else:
                    rs = avg_gain / avg_loss
                    rsi = 100.0 - (100.0 / (1.0 + rs))
                rsi_vals.append(rsi)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to calculate RSI")
            return []
        else:
            return rsi_vals

    def _calculate_ema(self, prices: list[float], period: int) -> list[float]:
        """Calculate EMA values."""
        try:
            if len(prices) < period:
                return []
            ema_values: list[float] = []
            k = 2.0 / (period + 1.0)
            sma = sum(prices[:period]) / period
            ema_values.append(sma)
            for i in range(period, len(prices)):
                ema_values.append(prices[i] * k + ema_values[-1] * (1.0 - k))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to calculate EMA")
            return []
        else:
            return ema_values

    # ----- Public API -----

    def train_agents(self, exchange: str, symbol: str) -> dict[str, Any]:
        """
        Train agents on historical data for a symbol.

        Args:
            exchange: Live exchange ID (must match EXCHANGE_ID from trading_universe)
            symbol: Live trading symbol (must be in Top-10)

        Returns:
            Training results with best agent information

        Raises:
            ValueError: If exchange doesn't match or symbol is not in Top-10
            RuntimeError: If training fails
        """
        # Validate exchange before try block to avoid TRY301
        if exchange != EXCHANGE_ID:
            msg = f"Exchange {exchange} does not match configured EXCHANGE_ID {EXCHANGE_ID}"
            logger.error(msg)
            raise ValueError(msg)

        try:
            # Validate symbol is in Top-10
            normalized_symbol = self._validate_symbol(symbol)

            evals: list[dict[str, Any]] = []
            for agent in self.agents.values():
                res = self._evaluate_agent(agent, normalized_symbol)
                evals.append(res)

            # Update trade count from successful evaluations
            self.trade_count += sum(ev.get("trade_count", 0) for ev in evals if ev.get("success"))

            # Evolve if enough trades accumulated
            if self.trade_count >= self.evolution_interval:
                self._evolve_generation()
                self.trade_count = 0

            best = self.get_best_agent()

            return {
                "success": True,
                "symbol": normalized_symbol,
                "exchange": exchange,
                "agents_evaluated": len(evals),
                "best_agent": best,
                "generation": max(a.generation for a in self.agents.values()) if self.agents else 0,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Failed to train agents")
            msg = f"Training agents failed for {symbol}: {e!s}"
            raise RuntimeError(msg) from e

    def get_best_agent(self) -> dict[str, Any] | None:
        """Get the current best performing agent snapshot."""
        try:
            if not self.agents:
                return None
            best = max(self.agents.values(), key=lambda a: a.calculate_fitness())
            return {
                "agent_id": best.agent_id,
                "parameters": best.parameters,
                "performance": best.performance,
                "fitness": best.calculate_fitness(),
                "generation": best.generation,
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get best agent")
            return None

    def get_agent_population(self) -> dict[str, Any]:
        """Get current population stats and per-agent summaries."""
        try:
            if not self.agents:
                return {"success": False, "reason": "No agents available"}

            fitness = [a.calculate_fitness() for a in self.agents.values()]
            perfs = [a.performance for a in self.agents.values()]

            def avg(arr):
                return float(np.mean(arr)) if arr else 0.0

            return {
                "success": True,
                "population_size": len(self.agents),
                "generation": max(a.generation for a in self.agents.values()),
                "average_fitness": avg(fitness),
                "max_fitness": max(fitness),
                "min_fitness": min(fitness),
                "average_pnl": avg([p["total_pnl"] for p in perfs]),
                "average_win_rate": avg([p["win_rate"] for p in perfs]),
                "agents": [
                    {
                        "agent_id": a.agent_id,
                        "fitness": a.calculate_fitness(),
                        "performance": a.performance,
                        "generation": a.generation,
                    }
                    for a in self.agents.values()
                ],
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Failed to get agent population")
            msg = f"Failed to get agent population: {e!s}"
            raise RuntimeError(msg) from e

    def update_replication_stats(self, success: bool = True) -> None:
        """Update replication statistics for dashboard."""
        try:
            self.spawned_versions += 1
            self.active_instances = len(self.agents)
            self.last_replication_time = datetime.now(timezone.utc).isoformat()
            self.replication_success_rate = max(
                0.0,
                min(1.0, self.replication_success_rate + (0.1 if success else -0.05)),
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to update replication stats")

    def get_replication_stats(self) -> dict[str, Any]:
        """Get replication statistics snapshot for dashboards."""
        try:
            return {
                "spawned_versions": self.spawned_versions,
                "active_instances": self.active_instances,
                "last_replication_time": self.last_replication_time,
                "replication_success_rate": self.replication_success_rate,
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Failed to get replication stats")
            msg = f"Failed to get replication stats: {e!s}"
            raise RuntimeError(msg) from e

    def get_signal_engine_reference(self) -> SignalEngine | None:
        """Get a fresh SignalEngine instance for integration (optional)."""
        try:
            return SignalEngine()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get SignalEngine reference")
            return None


# Global instance + accessor
self_replication_engine = SelfReplicationEngine()


def get_self_replication_engine() -> SelfReplicationEngine:
    """Get the global self-replication engine instance."""
    return self_replication_engine


if __name__ == "__main__":
    eng = SelfReplicationEngine()
    logger.info("SelfReplicationEngine initialized: %s", eng)

    # Use live exchange ID and first Top-10 coin for testing
    test_symbol = f"{TOP10_COINS[0]}USDT" if TOP10_COINS else "BTCUSDT"
    res = eng.train_agents(EXCHANGE_ID, test_symbol)
    logger.info("Training result: %s", res)

    best = eng.get_best_agent()
    logger.info("Best agent: %s", best)

    pop = eng.get_agent_population()
    logger.info("Population stats: %s", pop)
