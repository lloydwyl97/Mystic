"""
Signal Engine for Mystic AI Trading Platform - All Live Data, No Fallback/Hardcoded Data

Generates trading signals using technical indicators and (optional) machine learning + live sentiment
for Binance.US Top-10 spot symbols (backend port 8000).
All operations use live data:
- OHLCV data: Fetches live price data from canonical_cache
- Technical indicators: Calculates RSI, EMA from live data
- ML predictions: Uses live data for training and prediction
- All operations use live data - no fallback/hardcoded data

Key guarantees
- Safe to import: handles missing deps (sklearn, sentiment analyzer) gracefully.
- No side effects on import.
- Defensive around async sentiment calls (works whether an event loop exists or not).
- Avoids using an unfitted scaler/model (returns HOLD instead of throwing).
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import logging
import re
from datetime import datetime, timezone
from typing import Any

import numpy as np
import pandas as pd

# Single source of truth - Trading Universe (ALL 10 COINS - HARDCODED AS REQUIRED)
try:
    from backend.config.trading_universe import EXCHANGE_ID, TOP10_COINS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, KeyError, IndexError, RuntimeError) as e:
    msg = "Trading universe configuration is required for live operations"
    logging.getLogger(__name__).exception("Failed to import trading universe")
    raise RuntimeError(msg) from e

# Import from proper package structure
try:
    from backend.services.canonical_cache import canonical_cache
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, KeyError, IndexError, RuntimeError) as e:
    msg = "Canonical cache is required for live operations"
    logging.getLogger(__name__).exception("Failed to import canonical cache")
    raise RuntimeError(msg) from e

logger = logging.getLogger(__name__)

# --- Optional deps (sklearn) ---
try:
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler

    SKLEARN_AVAILABLE = True
except (ImportError, ModuleNotFoundError) as e:  # pragma: no cover
    SKLEARN_AVAILABLE = False
    logger.warning(f"Scikit-learn not available: {e}. Install with: pip install scikit-learn")

# --- Optional live sentiment analyzer ---
try:
    from backend.modules.ai.live_sentiment_analyzer import LiveSentimentAnalyzer
except (ImportError, ModuleNotFoundError, AttributeError) as e:  # pragma: no cover
    LiveSentimentAnalyzer = None  # type: ignore[assignment]
    logger.info(f"LiveSentimentAnalyzer not available: {e}; proceeding without sentiment enhancements.")


class SignalEngine:
    def __init__(self) -> None:
        """Initialize signal engine with cache and optional ML/sentiment components for live operations."""
        self.cache = canonical_cache

        # ML parts (optional)
        self.scaler = StandardScaler() if SKLEARN_AVAILABLE else None
        self.ml_model = LogisticRegression(random_state=42) if SKLEARN_AVAILABLE else None
        self._ml_trained = False  # guard against using unfitted scaler/model

        # Live sentiment analyzer (optional)
        self.sentiment_analyzer = LiveSentimentAnalyzer() if LiveSentimentAnalyzer else None

        # Technical indicator parameters
        self.rsi_period = 14
        self.ema_fast = 12
        self.ema_slow = 26
        self.ml_lookback = 100

        # Signal thresholds
        self.rsi_oversold = 30
        self.rsi_overbought = 70
        self.min_confidence = 0.6

        logger.info(
            "SignalEngine initialized%s",
            " with live sentiment" if self.sentiment_analyzer else "",
        )

    def _validate_symbol(self, symbol: str) -> str:
        """
        Validate and normalize trading symbol for live operations.

        Validates symbol is in Top-10 before processing.
        All symbols must be in the Top-10 universe.

        Args:
            symbol: Live trading symbol

        Returns:
            Normalized symbol

        Raises:
            ValueError: If symbol is not in Top-10
        """
        normalized = re.sub(r"[^A-Z0-9:_-]", "", symbol.upper())
        # Extract base symbol (remove USDT, /, etc.)
        base = normalized.replace("USDT", "").replace("/", "").replace("-", "").strip()
        # Validate symbol is in Top-10
        if base not in TOP10_COINS:
            msg = f"Symbol {base} is not in Top-10 universe. Supported: {TOP10_COINS}"
            logger.error(msg)
            raise ValueError(msg)
        return normalized

    # ---------------------------
    # Data prep
    # ---------------------------

    def _get_ohlcv_data(self, symbol: str, limit: int = 200) -> pd.DataFrame | None:
        """Get OHLCV-ish data from cache and convert to DataFrame."""
        try:
            # Validate symbol is in Top-10
            normalized_symbol = self._validate_symbol(symbol)
            price_history = self.cache.get_price_history("aggregated", normalized_symbol, limit=limit)
            if not price_history or len(price_history) < 50:
                logger.warning(
                    "Insufficient price data for %s: %d records",
                    symbol,
                    len(price_history) if price_history else 0,
                )
                return None

            df = pd.DataFrame(price_history)
            if "timestamp" not in df.columns or "price" not in df.columns:
                logger.error("Price history missing required fields for %s", symbol)
                return None

            df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
            df = df.dropna(subset=["timestamp"]).sort_values("timestamp")

            # Build OHLCV proxy (close=price; open = previous close)
            df["close"] = pd.to_numeric(df["price"], errors="coerce")
            df["open"] = df["close"].shift(1).fillna(df["close"])
            df["high"] = df["close"]
            df["low"] = df["close"]

            if "volume" in df.columns:
                df["volume"] = pd.to_numeric(df["volume"], errors="coerce").fillna(0.0)
            else:
                df["volume"] = 0.0

            out = df[["timestamp", "open", "high", "low", "close", "volume"]].dropna()
            return out if len(out) else None
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get OHLCV data for %s", symbol)
            return None

    # ---------------------------
    # Indicators
    # ---------------------------

    def calculate_rsi(self, prices: pd.Series, period: int = 14) -> pd.Series:
        """Calculate RSI (Relative Strength Index)."""
        try:
            delta = prices.diff()
            gains = delta.where(delta > 0, 0.0)
            losses = -delta.where(delta < 0, 0.0)

            avg_gains = gains.rolling(window=period, min_periods=period).mean()
            avg_losses = losses.rolling(window=period, min_periods=period).mean()

            rs = avg_gains / avg_losses.replace(0, np.nan)
            rsi = 100 - (100 / (1 + rs))
            return rsi.bfill().fillna(50.0)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to calculate RSI")
            return pd.Series([np.nan] * len(prices), index=prices.index)

    def calculate_ema(self, prices: pd.Series, period: int) -> pd.Series:
        """Calculate EMA (Exponential Moving Average)."""
        try:
            return prices.ewm(span=period, adjust=False).mean()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to calculate EMA")
            return pd.Series([np.nan] * len(prices), index=prices.index)

    def detect_ema_crossover(self, fast_ema: pd.Series, slow_ema: pd.Series) -> tuple[str, float]:
        """Detect EMA crossover signals -> ('BUY'|'SELL'|'HOLD', confidence)."""
        try:
            if len(fast_ema) < 2 or len(slow_ema) < 2:
                return "HOLD", 0.0

            fast_curr, fast_prev = fast_ema.iloc[-1], fast_ema.iloc[-2]
            slow_curr, slow_prev = slow_ema.iloc[-1], slow_ema.iloc[-2]

            if pd.isna(fast_curr) or pd.isna(fast_prev) or pd.isna(slow_curr) or pd.isna(slow_prev):
                return "HOLD", 0.0

            if fast_curr > slow_curr and fast_prev <= slow_prev:
                return "BUY", 0.8
            if fast_curr < slow_curr and fast_prev >= slow_prev:
                return "SELL", 0.8
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to detect EMA crossover")
            return "HOLD", 0.0
        else:
            return "HOLD", 0.0

    # ---------------------------
    # ML pipeline (optional)
    # ---------------------------

    def prepare_ml_features(self, df: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        """Prepare features/labels for ML model (binary next-step up/down)."""
        try:
            if len(df) < self.ml_lookback + 2:
                return np.array([]), np.array([])

            df = df.copy()
            df["rsi"] = self.calculate_rsi(df["close"], self.rsi_period)
            df["ema_fast"] = self.calculate_ema(df["close"], self.ema_fast)
            df["ema_slow"] = self.calculate_ema(df["close"], self.ema_slow)

            features: list[list[float]] = []
            labels: list[int] = []

            for i in range(self.ml_lookback, len(df) - 1):
                c = df["close"].iloc[i]
                c1 = df["close"].iloc[i - 1]
                c5 = df["close"].iloc[i - 5] if i >= 5 else c1
                c10 = df["close"].iloc[i - 10] if i >= 10 else c5

                price_change = (c - c1) / c1 if c1 else 0.0
                price_change_5 = (c - c5) / c5 if c5 else 0.0
                price_change_10 = (c - c10) / c10 if c10 else 0.0

                rsi = float(df["rsi"].iloc[i]) if not pd.isna(df["rsi"].iloc[i]) else 50.0
                ema_f = df["ema_fast"].iloc[i]
                ema_s = df["ema_slow"].iloc[i]
                ema_ratio = float(ema_f / ema_s) if not pd.isna(ema_f) and not pd.isna(ema_s) and ema_s else 1.0

                v1 = df["volume"].iloc[i - 1] if i > 0 else 0.0
                v_change = float((df["volume"].iloc[i] - v1) / v1) if v1 else 0.0

                features.append(
                    [
                        price_change,
                        price_change_5,
                        price_change_10,
                        rsi,
                        ema_ratio,
                        v_change,
                    ]
                )
                labels.append(1 if df["close"].iloc[i + 1] > c else 0)

            return np.asarray(features, dtype=float), np.asarray(labels, dtype=int)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to prepare ML features")
            return np.array([]), np.array([])

    def train_ml_model(self, symbol: str) -> bool:
        """Train ML model for a symbol; returns True if trained."""
        try:
            if not SKLEARN_AVAILABLE or self.ml_model is None or self.scaler is None:
                logger.info("ML not available; skipping training.")
                return False

            df = self._get_ohlcv_data(symbol, limit=500)
            if df is None or len(df) < 200:
                logger.warning("Insufficient data for ML training: %s", symbol)
                self._ml_trained = False
                return False

            X, y = self.prepare_ml_features(df)
            if X.size == 0:
                logger.warning("No features prepared for ML training: %s", symbol)
                self._ml_trained = False
                return False

            Xs = self.scaler.fit_transform(X)
            self.ml_model.fit(Xs, y)
            self._ml_trained = True
            logger.info("ML model trained for %s", symbol)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to train ML model for %s", symbol)
            self._ml_trained = False
            return False
        else:
            return True

    def predict_trend(self, symbol: str) -> tuple[str, float]:
        """Predict trend using ML model; returns ('BUY'|'SELL'|'HOLD', confidence)."""
        try:
            if not (SKLEARN_AVAILABLE and self.ml_model and self.scaler and self._ml_trained):
                return "HOLD", 0.0

            df = self._get_ohlcv_data(symbol, limit=50)
            if df is None or len(df) < max(20, self.ml_lookback + 2):
                return "HOLD", 0.0

            X, _ = self.prepare_ml_features(df)
            if X.size == 0:
                return "HOLD", 0.0

            latest = X[-1].reshape(1, -1)
            latest_scaled = self.scaler.transform(latest)

            pred = int(self.ml_model.predict(latest_scaled)[0])
            proba = float(np.max(self.ml_model.predict_proba(latest_scaled)[0]))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to predict trend for %s", symbol)
            return "HOLD", 0.0
        else:
            return ("BUY" if pred == 1 else "SELL"), proba

    # ---------------------------
    # Signals
    # ---------------------------

    def generate_signal(self, symbol: str) -> dict[str, Any]:
        """Generate a trading signal for a symbol (RSI + EMA cross + optional ML + optional sentiment)."""
        try:
            # Validate symbol is in Top-10
            normalized_symbol = self._validate_symbol(symbol)
            df = self._get_ohlcv_data(normalized_symbol)
            if df is None or len(df) < 50:
                msg = f"Insufficient live price data for {normalized_symbol}: need at least 50 data points"
                logger.error(msg)
                return {
                    "symbol": normalized_symbol,
                    "signal": "HOLD",
                    "confidence": 0.0,
                    "error": msg,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

            # Indicators
            rsi = self.calculate_rsi(df["close"], self.rsi_period)
            ema_fast = self.calculate_ema(df["close"], self.ema_fast)
            ema_slow = self.calculate_ema(df["close"], self.ema_slow)
            current_rsi = float(rsi.iloc[-1]) if not pd.isna(rsi.iloc[-1]) else 50.0

            signals: list[str] = []
            confidences: list[float] = []

            # RSI
            if current_rsi < self.rsi_oversold:
                signals.append("BUY")
                confidences.append(0.7)
            elif current_rsi > self.rsi_overbought:
                signals.append("SELL")
                confidences.append(0.7)

            # EMA cross
            ema_sig, ema_conf = self.detect_ema_crossover(ema_fast, ema_slow)
            if ema_sig != "HOLD":
                signals.append(ema_sig)
                confidences.append(ema_conf)

            # ML
            ml_sig, ml_conf = self.predict_trend(symbol)
            if ml_sig != "HOLD" and ml_conf >= self.min_confidence:
                signals.append(ml_sig)
                confidences.append(ml_conf)

            # Final decision
            if not signals:
                final_signal = "HOLD"
                final_conf = 0.0
            else:
                buy_count = signals.count("BUY")
                sell_count = signals.count("SELL")
                final_signal = "BUY" if buy_count > sell_count else "SELL" if sell_count > buy_count else "HOLD"
                final_conf = float(sum(confidences) / len(confidences)) if confidences else 0.0

            base_signal = {
                "symbol": normalized_symbol,
                "signal": final_signal,
                "confidence": round(final_conf, 3),
                "indicators": {
                    "rsi": round(current_rsi, 2),
                    "ema_fast": round(float(ema_fast.iloc[-1]), 6) if not pd.isna(ema_fast.iloc[-1]) else None,
                    "ema_slow": round(float(ema_slow.iloc[-1]), 6) if not pd.isna(ema_slow.iloc[-1]) else None,
                },
                "signals_used": signals,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

            # Optional: enhance with live sentiment (robust to existing event loops)
            if self.sentiment_analyzer and hasattr(self.sentiment_analyzer, "enhance_ai_signal"):
                try:
                    coro = self.sentiment_analyzer.enhance_ai_signal(normalized_symbol, base_signal)  # type: ignore[attr-defined]
                    try:
                        # loop = asyncio.get_running_loop()  # Unused
                        # Run in a worker to avoid interfering with existing loop
                        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as ex:
                            fut = ex.submit(asyncio.run, coro)
                            return fut.result(timeout=5)  # short, defensive timeout
                    except RuntimeError:
                        # No running loop, safe to asyncio.run
                        return asyncio.run(coro)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.warning("Sentiment enhancement failed for %s: %s", normalized_symbol, e)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to generate signal for %s", symbol)
            return base_signal
        else:
            return base_signal

    def get_signal(self, exchange: str, symbol: str) -> dict[str, Any]:
        """
        Compatibility wrapper for generating signals.

        Args:
            exchange: Live exchange ID (must match EXCHANGE_ID from trading_universe)
            symbol: Live trading symbol (must be in Top-10)

        Returns:
            Trading signal dictionary

        Raises:
            ValueError: If exchange doesn't match or symbol is not in Top-10
            RuntimeError: If signal generation fails
        """
        # Validate exchange matches EXCHANGE_ID
        if exchange != EXCHANGE_ID:
            msg = f"Exchange {exchange} does not match configured EXCHANGE_ID {EXCHANGE_ID}"
            logger.error(msg)
            raise ValueError(msg)
        return self.generate_signal(symbol)

    def get_all_signals(self) -> dict[str, Any]:
        """Get signals for all Top-10 symbols."""
        try:
            # Use Top-10 coins from trading_universe (all 10 coins - hardcoded as required)
            symbols = [f"{coin}USDT" for coin in TOP10_COINS]
            signals: dict[str, Any] = {}
            non_hold = 0
            for s in symbols:
                try:
                    sig = self.generate_signal(s)
                    signals[s] = sig
                    if sig.get("signal") != "HOLD":
                        non_hold += 1
                except (ValueError, RuntimeError) as e:
                    logger.warning("Failed to generate signal for %s: %s", s, e)
                    signals[s] = {
                        "symbol": s,
                        "signal": "HOLD",
                        "confidence": 0.0,
                        "error": str(e),
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    }
            return {
                "success": True,
                "total_symbols": len(symbols),
                "successful_signals": non_hold,
                "signals": signals,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Failed to get all signals")
            msg = f"Failed to get all signals: {e!s}"
            raise RuntimeError(msg) from e

    def get_active_signals_count(self) -> int:
        """Count recent non-HOLD trading signals from cache."""
        try:
            recent = self.cache.get_signals_by_type("TRADING_SIGNAL", limit=100)
            return sum(1 for s in recent if s.get("metadata", {}).get("signal") != "HOLD")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get active signals count")
            return 0

    def get_service_status(self) -> dict[str, Any]:
        """Return service + configuration status snapshot."""
        try:
            return {
                "service": "SignalEngine",
                "status": "active",
                "sklearn_available": SKLEARN_AVAILABLE,
                "ml_model_trained": bool(self._ml_trained),
                "sentiment_enabled": bool(self.sentiment_analyzer is not None),
                "configuration": {
                    "rsi_period": self.rsi_period,
                    "ema_fast": self.ema_fast,
                    "ema_slow": self.ema_slow,
                    "ml_lookback": self.ml_lookback,
                    "rsi_oversold": self.rsi_oversold,
                    "rsi_overbought": self.rsi_overbought,
                    "min_confidence": self.min_confidence,
                },
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Failed to get service status")
            msg = f"Failed to get service status: {e!s}"
            raise RuntimeError(msg) from e


# Global instance + accessor
signal_engine = SignalEngine()


def get_signal_engine() -> SignalEngine:
    return signal_engine


if __name__ == "__main__":  # manual smoke test
    engine = SignalEngine()
    logger.info("SignalEngine initialized (sentiment=%s / sklearn=%s)", bool(engine.sentiment_analyzer), SKLEARN_AVAILABLE)

    # Use live exchange ID and first Top-10 coin for testing
    test_symbol = f"{TOP10_COINS[0]}USDT" if TOP10_COINS else "BTCUSDT"
    # Try training ML quickly (may return False if not enough data)
    trained = engine.train_ml_model(test_symbol)
    logger.info("ML trained: %s", trained)

    sig = engine.get_signal(EXCHANGE_ID, test_symbol)
    logger.info("Signal result: %s", sig)

    status = engine.get_service_status()
    logger.info("Service status: %s", status)
