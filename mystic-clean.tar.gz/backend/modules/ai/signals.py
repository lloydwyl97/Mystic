"""
Signals Module - All Live Data, No Fallback/Hardcoded Data

Centralized signal generation and management for Binance.US Top-10 spot trading (backend port 8000).
All operations use live data:
- Signal generation: Generates signals from live price/volume series from Binance.US API
- Indicator calculations: RSI, MACD, volume spikes calculated from live market data
- Signal storage: In-memory signal storage for live trading operations
- All signals use live data - no fallback/hardcoded data

Design goals
- Safe to import (no side effects)
- Pure in-memory by default (no external I/O)
- Predictable, explicit API for emitting/querying signals
- Lightweight deduplication, cooldowns, and rate limiting
- Simple indicator helpers (RSI/MACD) using live price series from Binance.US API

Compatibility helpers
- `to_cache_record()` matches common fields used by PersistentCache.store_signal(...)

Endpoint References:
- Backend API: Port 8000 (signals manager serves live operations)
- Binance.US API: Live price/volume data for indicator calculations
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import builtins
import hashlib
import logging
import re
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any

import numpy as np

# Single source of truth - Trading Universe (ALL 10 COINS - HARDCODED AS REQUIRED)
try:
    from backend.config.trading_universe import EXCHANGE_ID, TOP10_COINS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, KeyError, IndexError, RuntimeError) as e:
    msg = "Trading universe configuration is required for live operations"
    logging.getLogger(__name__).exception("Failed to import trading universe")
    raise RuntimeError(msg) from e

logger = logging.getLogger(__name__)

# ---------------------------
# Enums / Datamodel
# ---------------------------


class SignalType(Enum):
    ENTRY = "ENTRY"
    EXIT = "EXIT"
    RISK = "RISK"
    INFO = "INFO"
    TIME_OPTIMIZATION = "TIME_OPTIMIZATION"
    MOMENTUM = "MOMENTUM"
    MEAN_REVERSION = "MEAN_REVERSION"
    BREAKOUT = "BREAKOUT"


class SignalAction(Enum):
    BUY = "BUY"
    SELL = "SELL"
    CLOSE = "CLOSE"
    HOLD = "HOLD"
    ALERT = "ALERT"
    NONE = "NONE"


class SignalSource(Enum):
    AI = "AI"
    STRATEGY = "STRATEGY"
    RISK = "RISK"
    SYSTEM = "SYSTEM"
    ANALYZER = "ANALYZER"


@dataclass
class Signal:
    """
    Represents a live trading signal generated from live market data (backend port 8000).

    All fields are from live data sources - no hardcoded/fallback data.
    """

    id: str  # Live signal ID
    symbol: str  # Live trading symbol
    signal_type: SignalType  # Live signal type
    action: SignalAction  # Live signal action
    confidence: float  # Live confidence (0..1) calculated from live data
    price: float | None = None  # Live price from Binance.US API
    strength: float | None = None  # Optional normalized 0..1 from live analysis
    source: SignalSource = SignalSource.AI  # Live signal source
    strategy: str | None = None  # Strategy name
    metadata: dict[str, Any] = field(default_factory=dict)  # Live metadata from analysis
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())  # Live timestamp
    expires_at: str | None = None  # Optional expiration timestamp
    acknowledged: bool = False  # Acknowledgment status
    group_key: str | None = None  # Useful for batch ops (e.g., strategy session)
    _dedupe_hash: str = field(default="", repr=False)  # Deduplication hash

    def is_expired(self) -> bool:
        if not self.expires_at:
            return False
        try:
            return datetime.now(timezone.utc) >= datetime.fromisoformat(self.expires_at)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            # If unparsable, treat as non-expired to be safe
            return False

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["signal_type"] = self.signal_type.value
        d["action"] = self.action.value
        d["source"] = self.source.value
        d.pop("_dedupe_hash", None)
        return d

    # Compatibility layer for PersistentCache.store_signal(...)
    def to_cache_record(self) -> dict[str, Any]:
        try:
            from backend.services.confidence_normalizer import ConfidenceNormalizer

            conf = ConfidenceNormalizer.normalize(float(self.confidence))
        except Exception:
            conf = float(self.confidence)
        return {
            "signal_id": self.id,
            "symbol": self.symbol,
            "signal_type": self.signal_type.value,
            "confidence": conf,
            "strategy": self.strategy or "",
            "metadata": self.metadata,
            "timestamp": self.created_at,
        }


# ---------------------------
# Utility Functions
# ---------------------------


def _mk_id(prefix: str = "sig") -> str:
    ts_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
    return f"{prefix}_{ts_ms}"


def _mk_hash(
    symbol: str,
    stype: SignalType,
    action: SignalAction,
    price: float | None,
    payload: dict[str, Any],
) -> str:
    # Stable content hash to dedupe near-identical signals
    h = hashlib.sha256()
    h.update(symbol.encode("utf-8"))
    h.update(stype.value.encode("utf-8"))
    h.update(action.value.encode("utf-8"))
    if price is not None:
        h.update(f"{price:.8f}".encode())
    # Include a minimal subset of metadata that typically defines uniqueness
    keys = sorted(k for k in payload if k not in {"created_at", "expires_at"})
    for k in keys:
        v = payload[k]
        h.update(str(k).encode("utf-8"))
        h.update(str(v).encode("utf-8"))
    return h.hexdigest()


# ---------------------------
# Manager
# ---------------------------


class SignalsManager:
    """
    In-memory signal store for live trading signals (backend port 8000).

    Manages live signal generation, deduplication, cooldowns, and rate limiting.
    All signals are generated from live market data - no fallback/hardcoded data.
    """

    def __init__(self) -> None:
        """
        Initialize signals manager for live operations.

        All initial values are configuration defaults or live state, not fallback data.
        """
        self._signals: dict[str, Signal] = {}  # Live signal storage
        self._by_symbol: dict[str, list[str]] = {}  # Live symbol index
        self._history: list[dict[str, Any]] = []  # Append-only history, capped
        self._cooldowns: dict[tuple[str, SignalType], float] = {}  # Epoch seconds when next allowed
        self._last_min_bucket: int = 0  # Rate limit bucket
        self._per_min_counter: int = 0  # Rate limit counter

        # Configuration tunables (not fallback data)
        self.cooldown_seconds: float = 30.0  # Cooldown per (symbol, type) in seconds (configuration default)
        self.rate_limit_per_min: int = 240  # Global rate limit per minute (configuration default)
        self.history_limit: int = 10000  # Maximum history records (increased for deeper learning)
        self.max_live: int = 2000  # Maximum live signals (configuration default)

        # Advanced signal processing features
        self.multi_timeframe_enabled: bool = True  # Enable multi-timeframe analysis
        self.risk_adjusted_signals: bool = True  # Enable risk-adjusted signal generation
        self.timeframe_weights: dict[str, float] = {  # Timeframe importance weights
            "1m": 0.3,
            "5m": 0.4,
            "15m": 0.2,
            "1h": 0.1,
        }
        self.market_regime_signals: dict[str, str] = {}  # Current market regime per symbol
        self.correlation_signals: dict[str, dict[str, float]] = {}  # Cross-symbol correlations
        self.volatility_adjusted_confidence: dict[str, float] = {}  # Volatility-adjusted confidence

        logger.info("SignalsManager initialized for live operations")

    def _validate_symbol(self, symbol: str) -> str:
        """
        Validate and normalize trading symbol for live operations.

        Validates symbol is in Top-10 before normalizing.
        All symbols must be in the Top-10 universe.

        Args:
            symbol: Live trading symbol

        Returns:
            Normalized symbol

        Raises:
            ValueError: If symbol is not in Top-10
        """
        normalized = re.sub(r"[^A-Z0-9:_-]", "", symbol.upper())
        # Extract base symbol (remove USDT, /, etc.)
        base = normalized.replace("USDT", "").replace("/", "").replace("-", "").strip()
        # Validate symbol is in Top-10
        if base not in TOP10_COINS:
            msg = f"Symbol {base} is not in Top-10 universe. Supported: {TOP10_COINS}"
            logger.error(msg)
            raise ValueError(msg)
        return normalized

    # -----------------------
    # Emit / Create
    # -----------------------

    def emit(
        self,
        *,
        symbol: str,
        signal_type: SignalType,
        action: SignalAction,
        confidence: float,
        price: float | None = None,
        strength: float | None = None,
        source: SignalSource = SignalSource.AI,
        strategy: str | None = None,
        ttl_seconds: int | None = None,
        metadata: dict[str, Any] | None = None,
        group_key: str | None = None,
        dedupe_epsilon: float = 0.001,  # ~0.1% price diff allowed for dedupe (configuration default)
    ) -> dict[str, Any]:
        """
        Emit a new live signal with deduplication, cooldown, and rate limiting (backend port 8000).

        All signal data must be from live sources - no fallback/hardcoded data.

        Args:
            symbol: Live trading symbol
            signal_type: Live signal type
            action: Live signal action
            confidence: Live confidence score (0..1) from live analysis
            price: Optional live price from Binance.US API
            strength: Optional strength score (0..1) from live analysis
            source: Live signal source
            strategy: Optional strategy name
            ttl_seconds: Optional TTL in seconds (configuration default, not fallback data)
            metadata: Optional live metadata from analysis
            group_key: Optional group key for batch operations
            dedupe_epsilon: Price difference threshold for deduplication (configuration default)

        Returns:
            {"success": bool, "signal": dict} on success
            {"success": False, "error": str} on failure or deduped/cooldown
        """
        # Validate confidence
        try:
            c = float(confidence)
            if c < 0 or c > 1:
                return {"success": False, "error": "confidence must be between 0 and 1"}
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            return {"success": False, "error": "confidence must be numeric"}

        # Validate symbol is in Top-10
        try:
            normalized_symbol = self._validate_symbol(symbol)
        except ValueError as e:
            return {"success": False, "error": str(e)}

        meta = dict(metadata or {})
        # Rate limit check
        if not self._check_rate_limit():
            return {"success": False, "error": "rate_limited"}

        # Cooldown check
        key = (symbol, signal_type)
        now = datetime.now(timezone.utc)
        now_epoch = now.timestamp()
        next_ok = self._cooldowns.get(key, 0.0)
        if now_epoch < next_ok:
            return {"success": False, "error": "cooldown"}

        # Dedupe check (against the most recent signals for the symbol)
        dedupe_payload = {
            "action": action.value,
            "strength": strength if strength is not None else "",
            "source": source.value,
            "strategy": strategy or "",
            **meta,
        }
        content_hash = _mk_hash(symbol, signal_type, action, price, dedupe_payload)

        if self._is_duplicate(symbol, signal_type, action, price, content_hash, epsilon=dedupe_epsilon):
            return {"success": False, "error": "duplicate"}

        # Build Signal
        sig_id = _mk_id()
        expires_at = (now + timedelta(seconds=int(ttl_seconds))) if ttl_seconds else None
        s = Signal(
            id=sig_id,
            symbol=normalized_symbol,
            signal_type=signal_type,
            action=action,
            confidence=c,
            price=float(price) if price is not None else None,
            strength=float(strength) if strength is not None else None,
            source=source,
            strategy=strategy,
            metadata=meta,
            expires_at=expires_at.isoformat() if expires_at else None,
            group_key=group_key,
            _dedupe_hash=content_hash,
        )

        # Store
        self._signals[sig_id] = s
        arr = self._by_symbol.setdefault(normalized_symbol, [])
        arr.append(sig_id)
        # Cap live map size lightly
        if len(self._signals) > self.max_live:
            self._evict_oldest()

        # Update cooldown
        self._cooldowns[key] = now_epoch + self.cooldown_seconds

        # Append compact history
        self._append_history({"event": "emit", "signal_id": sig_id, "symbol": normalized_symbol, "ts": s.created_at})

        logger.debug(
            "Signal emitted: %s %s %s conf=%.3f",
            normalized_symbol,
            signal_type.value,
            action.value,
            c,
        )
        return {"success": True, "signal": s.to_dict()}

    def _is_duplicate(
        self,
        symbol: str,
        signal_type: SignalType,
        action: SignalAction,
        price: float | None,
        content_hash: str,
        *,
        epsilon: float,
    ) -> bool:
        # Check last few signals for the symbol for hash/price similarity
        ids = self._by_symbol.get(symbol, [])
        for sig_id in reversed(ids[-10:]):  # check only last 10 for speed
            s = self._signals.get(sig_id)
            if not s:
                continue
            if s.signal_type is signal_type and s.action is action:
                # hash match => duplicate
                if s._dedupe_hash == content_hash:
                    return True
                # near price match => likely duplicate
                if price is not None and s.price is not None and s.price > 0:
                    delta = abs(price - s.price) / max(1e-9, s.price)
                    if delta <= epsilon:
                        return True
        return False

    def _check_rate_limit(self) -> bool:
        bucket = int(datetime.now(timezone.utc).timestamp() // 60)
        if bucket != self._last_min_bucket:
            self._last_min_bucket = bucket
            self._per_min_counter = 0
        self._per_min_counter += 1
        return self._per_min_counter <= self.rate_limit_per_min

    def _append_history(self, rec: dict[str, Any]) -> None:
        self._history.append(rec)
        if len(self._history) > self.history_limit:
            self._history = self._history[-(self.history_limit // 2) :]

    def _evict_oldest(self) -> None:
        # Simple eviction: drop oldest 5%
        if not self._signals:
            return
        drop = max(1, int(len(self._signals) * 0.05))
        # Build list of (id, created_at)
        items: list[tuple[str, float]] = []
        for sid, s in self._signals.items():
            try:
                ts = datetime.fromisoformat(s.created_at).timestamp()
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                ts = 0.0
            items.append((sid, ts))
        items.sort(key=lambda x: x[1])
        for sid, _ in items[:drop]:
            self._remove_signal_id(sid)

    def _remove_signal_id(self, sid: str) -> None:
        s = self._signals.pop(sid, None)
        if not s:
            return
        arr = self._by_symbol.get(s.symbol, [])
        if sid in arr:
            arr.remove(sid)
        self._append_history(
            {
                "event": "evict",
                "signal_id": sid,
                "symbol": s.symbol,
                "ts": datetime.now(timezone.utc).isoformat(),
            }
        )

    # -----------------------
    # Query / Manage
    # -----------------------

    def get(self, signal_id: str) -> dict[str, Any] | None:
        s = self._signals.get(signal_id)
        return s.to_dict() if s else None

    def list(
        self,
        *,
        symbol: str | None = None,
        signal_type: SignalType | None = None,
        action: SignalAction | None = None,
        active_only: bool = True,
        limit: int = 100,
    ) -> builtins.list[dict[str, Any]]:
        ids = []
        if symbol:
            # Validate symbol is in Top-10
            try:
                normalized_symbol = self._validate_symbol(symbol)
                ids = list(self._by_symbol.get(normalized_symbol, []))
            except ValueError:
                # Invalid symbol - return empty list
                return []
        else:
            ids = list(self._signals.keys())

        out: list[dict[str, Any]] = []
        for sid in reversed(ids):
            s = self._signals.get(sid)
            if not s:
                continue
            if signal_type and s.signal_type is not signal_type:
                continue
            if action and s.action is not action:
                continue
            if active_only and s.is_expired():
                continue
            out.append(s.to_dict())
            if len(out) >= max(1, limit):
                break
        return out

    def ack(self, signal_id: str) -> dict[str, Any]:
        s = self._signals.get(signal_id)
        if not s:
            return {"success": False, "error": "not_found"}
        s.acknowledged = True
        self._append_history(
            {
                "event": "ack",
                "signal_id": signal_id,
                "ts": datetime.now(timezone.utc).isoformat(),
            }
        )
        return {"success": True, "signal": s.to_dict()}

    def dismiss(self, signal_id: str) -> dict[str, Any]:
        s = self._signals.get(signal_id)
        if not s:
            return {"success": False, "error": "not_found"}
        self._remove_signal_id(signal_id)
        self._append_history(
            {
                "event": "dismiss",
                "signal_id": signal_id,
                "ts": datetime.now(timezone.utc).isoformat(),
            }
        )
        return {"success": True}

    def clear_expired(self) -> int:
        to_delete = [sid for sid, s in self._signals.items() if s.is_expired()]
        for sid in to_delete:
            self._remove_signal_id(sid)
        if to_delete:
            logger.info("Cleared %d expired signals", len(to_delete))
        return len(to_delete)

    def clear_all(self) -> int:
        n = len(self._signals)
        self._signals.clear()
        self._by_symbol.clear()
        self._append_history(
            {
                "event": "clear_all",
                "count": n,
                "ts": datetime.now(timezone.utc).isoformat(),
            }
        )
        return n

    # -----------------------
    # Stats / Export
    # -----------------------

    def stats(self) -> dict[str, Any]:
        total = len(self._signals)
        expired = sum(1 for s in self._signals.values() if s.is_expired())
        acked = sum(1 for s in self._signals.values() if s.acknowledged)
        by_type: dict[str, int] = {}
        for s in self._signals.values():
            by_type[s.signal_type.value] = by_type.get(s.signal_type.value, 0) + 1
        return {
            "total": total,
            "expired": expired,
            "acknowledged": acked,
            "by_type": by_type,
            "symbols": len(self._by_symbol),
            "rate_limit_per_min": self.rate_limit_per_min,
            "cooldown_seconds": self.cooldown_seconds,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def export(self) -> dict[str, Any]:
        return {
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "signals": [s.to_dict() for s in self._signals.values()],
            "history_tail": self._history[-100:],
            "config": {
                "cooldown_seconds": self.cooldown_seconds,
                "rate_limit_per_min": self.rate_limit_per_min,
                "history_limit": self.history_limit,
                "max_live": self.max_live,
            },
        }

    def import_(self, payload: dict[str, Any]) -> dict[str, Any]:
        try:
            items = payload.get("signals", [])
            count = 0
            for raw in items:
                if not isinstance(raw, dict):
                    continue
                try:
                    s = self._from_dict(raw)
                    self._signals[s.id] = s
                    arr = self._by_symbol.setdefault(s.symbol, [])
                    if s.id not in arr:
                        arr.append(s.id)
                    count += 1
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    continue
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Import failed")
            return {"success": False, "imported": 0}
        else:
            return {"success": True, "imported": count}

    def _from_dict(self, d: dict[str, Any]) -> Signal:
        # Validate symbol is in Top-10 during import
        raw_symbol = str(d["symbol"]).upper().replace("-", "/")
        try:
            normalized_symbol = self._validate_symbol(raw_symbol)
        except ValueError as e:
            msg = f"Invalid symbol in import data: {e}"
            logger.exception("Invalid symbol in import data")
            raise ValueError(msg) from e

        raw_conf = float(d.get("confidence", 0.0) or 0.0)
        try:
            from backend.services.confidence_normalizer import ConfidenceNormalizer

            conf = ConfidenceNormalizer.normalize(raw_conf)
        except Exception:
            conf = raw_conf
        return Signal(
            id=str(d["id"]),
            symbol=normalized_symbol,
            signal_type=SignalType(str(d["signal_type"])),
            action=SignalAction(str(d["action"])),
            confidence=conf,
            price=float(d["price"]) if d.get("price") is not None else None,
            strength=float(d["strength"]) if d.get("strength") is not None else None,
            source=SignalSource(str(d.get("source", "AI"))),
            strategy=d.get("strategy"),
            metadata=dict(d.get("metadata", {})),
            created_at=str(d.get("created_at", datetime.now(timezone.utc).isoformat())),
            expires_at=d.get("expires_at"),
            acknowledged=bool(d.get("acknowledged", False)),
            group_key=d.get("group_key"),
            _dedupe_hash=_mk_hash(
                normalized_symbol,
                SignalType(str(d["signal_type"])),
                SignalAction(str(d["action"])),
                float(d["price"]) if d.get("price") is not None else None,
                {
                    **dict(d.get("metadata", {})),
                    "strategy": d.get("strategy", ""),
                    "source": str(d.get("source", "AI")),
                },
            ),
        )

    # -----------------------
    # Convenience generators
    # -----------------------

    def generate_from_indicators(
        self,
        *,
        symbol: str,
        price_series: builtins.list[float],
        volume_series: builtins.list[float] | None = None,
        rsi_period: int = 14,
        macd_fast: int = 12,
        macd_slow: int = 26,
        macd_signal: int = 9,
        strategy_name: str = "indicator_pack",
    ) -> builtins.list[dict[str, Any]]:
        """
        Generate basic live signals from live price/volume series (backend port 8000).

        Calculates RSI, MACD crossovers, and volume spikes from live Binance.US market data.
        All price and volume data must be live - no fallback/hardcoded data.

        Args:
            symbol: Live trading symbol (must be in Top-10)
            price_series: Live price series from Binance.US API (ordered oldest->newest)
            volume_series: Optional live volume series from Binance.US API
            rsi_period: RSI period (configuration default, not fallback data)
            macd_fast: MACD fast period (configuration default, not fallback data)
            macd_slow: MACD slow period (configuration default, not fallback data)
            macd_signal: MACD signal period (configuration default, not fallback data)
            strategy_name: Strategy name

        Returns:
            List of live signal dictionaries generated from live indicators

        Raises:
            ValueError: If symbol is not in Top-10 or insufficient data
        """
        # Validate symbol is in Top-10
        try:
            normalized_symbol = self._validate_symbol(symbol)
        except ValueError:
            logger.exception("Symbol validation failed")
            return []

        results: list[dict[str, Any]] = []
        if not price_series or len(price_series) < max(3, rsi_period + 1, macd_slow + macd_signal):
            msg = f"Insufficient live price data for {normalized_symbol}: need at least {max(3, rsi_period + 1, macd_slow + macd_signal)} data points, got {len(price_series) if price_series else 0}"
            logger.error(msg)
            return results

        last_price = float(price_series[-1])

        # RSI
        rsi_val = _rsi(price_series, rsi_period)
        if rsi_val is not None:
            if rsi_val < 30:
                results.append(
                    self.emit(
                        symbol=normalized_symbol,
                        signal_type=SignalType.MEAN_REVERSION,
                        action=SignalAction.BUY,
                        confidence=_scale_conf(30 - rsi_val, 0, 30),
                        price=last_price,
                        strategy=strategy_name,
                        source=SignalSource.AI,
                        metadata={"indicator": "RSI", "rsi": round(rsi_val, 2)},
                    ),
                )
            elif rsi_val > 70:
                results.append(
                    self.emit(
                        symbol=normalized_symbol,
                        signal_type=SignalType.MEAN_REVERSION,
                        action=SignalAction.SELL,
                        confidence=_scale_conf(rsi_val - 70, 0, 30),
                        price=last_price,
                        strategy=strategy_name,
                        source=SignalSource.AI,
                        metadata={"indicator": "RSI", "rsi": round(rsi_val, 2)},
                    ),
                )

        # MACD cross
        macd_line, signal_line = _macd(price_series, macd_fast, macd_slow, macd_signal)
        if macd_line is not None and signal_line is not None and len(macd_line) >= 2 and len(signal_line) >= 2:
            prev_diff = macd_line[-2] - signal_line[-2]
            curr_diff = macd_line[-1] - signal_line[-1]
            if prev_diff <= 0 and curr_diff > 0:
                results.append(
                    self.emit(
                        symbol=normalized_symbol,
                        signal_type=SignalType.MOMENTUM,
                        action=SignalAction.BUY,
                        confidence=_scale_conf(abs(curr_diff), 0, max(1e-6, abs(macd_line[-1]))),
                        price=last_price,
                        strategy=strategy_name,
                        source=SignalSource.AI,
                        metadata={"indicator": "MACD", "cross": "bullish"},
                    ),
                )
            elif prev_diff >= 0 and curr_diff < 0:
                results.append(
                    self.emit(
                        symbol=normalized_symbol,
                        signal_type=SignalType.MOMENTUM,
                        action=SignalAction.SELL,
                        confidence=_scale_conf(abs(curr_diff), 0, max(1e-6, abs(macd_line[-1]))),
                        price=last_price,
                        strategy=strategy_name,
                        source=SignalSource.AI,
                        metadata={"indicator": "MACD", "cross": "bearish"},
                    ),
                )

        # Volume spike (optional)
        if volume_series and len(volume_series) == len(price_series) and len(volume_series) >= 20:
            v_avg = sum(volume_series[-20:]) / 20.0
            v_last = float(volume_series[-1])
            if v_avg > 0 and v_last > 1.5 * v_avg:
                # Volume breakout -> momentum BUY by default
                results.append(
                    self.emit(
                        symbol=normalized_symbol,
                        signal_type=SignalType.BREAKOUT,
                        action=SignalAction.BUY,
                        confidence=_scale_conf((v_last / v_avg) - 1.0, 0, 2.0),
                        price=last_price,
                        strategy=strategy_name,
                        source=SignalSource.AI,
                        metadata={
                            "indicator": "VOLUME_SPIKE",
                            "ratio": round(v_last / v_avg, 2),
                        },
                    ),
                )

        # Filter out unsuccessful emits (rate-limited/duplicate)
        return [r for r in results if r.get("success")]

    # -----------------------
    # Back-compat summary helpers
    # -----------------------

    def get_trade_summary(self) -> dict[str, Any]:
        """
        Legacy-style quick summary for callers expecting ai_signals.get_trade_summary().
        """
        total = 0
        buys = 0
        sells = 0
        closes = 0
        for s in self._signals.values():
            total += 1
            if s.action is SignalAction.BUY:
                buys += 1
            elif s.action is SignalAction.SELL:
                sells += 1
            elif s.action is SignalAction.CLOSE:
                closes += 1
        win_rate = 0.0  # Not tracked here—use StrategyAnalyzer for real stats
        raw_avg = (sum(float(s.confidence) for s in self._signals.values()) / total) if total else 0.0
        try:
            from backend.services.confidence_normalizer import ConfidenceNormalizer

            avg_conf = ConfidenceNormalizer.normalize(raw_avg)
        except Exception:
            avg_conf = raw_avg
        return {
            "total_trades": total,
            "buy_signals": buys,
            "sell_signals": sells,
            "close_signals": closes,
            "win_rate": win_rate,
            "average_confidence": avg_conf,
        }

    # ===== ADVANCED SIGNAL PROCESSING =====
    # These methods were previously unreachable dead code inside _scale_conf (a module-level function).
    # They are now correctly added as SignalsManager class methods.

    def generate_multi_timeframe_signal(self, symbol: str, base_signal: dict[str, Any], timeframe_data: dict[str, dict[str, Any]]) -> dict[str, Any]:
        """Generate multi-timeframe enhanced signal using live data from multiple timeframes."""
        if not self.multi_timeframe_enabled:
            return base_signal
        try:
            timeframe_signals = []
            total_weight = 0
            for tf, weight in self.timeframe_weights.items():
                if tf in timeframe_data:
                    tf_signal = timeframe_data[tf]
                    tf_confidence = tf_signal.get("confidence", 0.5) * weight
                    timeframe_signals.append(tf_confidence)
                    total_weight += weight
            if timeframe_signals and total_weight > 0:
                consensus_confidence = sum(timeframe_signals) / total_weight
                enhanced_signal = base_signal.copy()
                enhanced_signal["confidence"] = min(1.0, enhanced_signal.get("confidence", 0.5) * 0.7 + consensus_confidence * 0.3)
                meta = enhanced_signal.setdefault("metadata", {})
                meta["multi_timeframe_consensus"] = consensus_confidence
                meta["timeframes_used"] = list(timeframe_data.keys())
                logger.info("Multi-timeframe signal for %s: consensus=%.3f", symbol, consensus_confidence)
                return enhanced_signal
        except Exception as e:
            logger.exception("Multi-timeframe signal generation failed for %s: %s", symbol, e)
        return base_signal

    def generate_risk_adjusted_signal(self, symbol: str, base_signal: dict[str, Any], risk_metrics: dict[str, Any]) -> dict[str, Any]:
        """Generate risk-adjusted signal based on current market volatility and position risk."""
        if not self.risk_adjusted_signals:
            return base_signal
        try:
            adjusted = base_signal.copy()
            volatility = float(risk_metrics.get("volatility", 0.5) or 0.5)
            drawdown = float(risk_metrics.get("drawdown", 0.0) or 0.0)
            if volatility > 0.7:
                adjusted["confidence"] = adjusted.get("confidence", 0.5) * 0.85
            if drawdown > 0.1:
                adjusted["confidence"] = adjusted.get("confidence", 0.5) * (1.0 - drawdown * 0.5)
            adjusted["confidence"] = max(0.0, min(1.0, adjusted.get("confidence", 0.5)))
            meta = adjusted.setdefault("metadata", {})
            meta["risk_adjusted"] = True
            meta["volatility"] = volatility
            meta["drawdown"] = drawdown
            return adjusted
        except Exception as e:
            logger.exception("Risk-adjusted signal generation failed for %s: %s", symbol, e)
        return base_signal

    def detect_market_regime(self, symbol: str, market_data: dict[str, Any]) -> str:
        """Detect market regime from live market data."""
        try:
            volatility = float(market_data.get("volatility", 0.5) or 0.5)
            momentum = float(market_data.get("momentum", 0.0) or 0.0)
            trend_strength = float(market_data.get("trend_strength", 0.0) or 0.0)
            if volatility > 0.7:
                return "high_volatility"
            if momentum > 0.3 and trend_strength > 0.5:
                return "bullish_trending"
            if momentum < -0.3 and trend_strength > 0.5:
                return "bearish"
            if trend_strength < 0.2:
                return "ranging"
            return "neutral"
        except Exception as e:
            logger.exception("Market regime detection failed for %s: %s", symbol, e)
            return "neutral"

    def calculate_cross_symbol_correlations(self, symbol: str, all_symbols_data: dict[str, dict[str, Any]]) -> dict[str, float]:
        """Calculate correlations with other symbols using live market data."""
        correlations: dict[str, float] = {}
        try:
            my_prices = all_symbols_data.get(symbol, {}).get("prices", [])
            if not my_prices:
                return correlations
            for other_sym, other_data in all_symbols_data.items():
                if other_sym == symbol:
                    continue
                other_prices = other_data.get("prices", [])
                if not other_prices:
                    continue
                corr = self._calculate_correlation(my_prices, other_prices)
                correlations[other_sym] = corr
        except Exception as e:
            logger.exception("Cross-symbol correlations failed for %s: %s", symbol, e)
        return correlations

    @staticmethod
    def _calculate_correlation(prices1: list[float], prices2: list[float]) -> float:
        """Calculate Pearson correlation between two price series."""
        try:
            n = min(len(prices1), len(prices2))
            if n < 2:
                return 0.0
            p1 = prices1[-n:]
            p2 = prices2[-n:]
            mean1 = sum(p1) / n
            mean2 = sum(p2) / n
            cov = sum((a - mean1) * (b - mean2) for a, b in zip(p1, p2, strict=False)) / n
            std1 = (sum((a - mean1) ** 2 for a in p1) / n) ** 0.5
            std2 = (sum((b - mean2) ** 2 for b in p2) / n) ** 0.5
            if std1 == 0 or std2 == 0:
                return 0.0
            return cov / (std1 * std2)
        except Exception:
            return 0.0

    def generate_advanced_signal(
        self, symbol: str, ai_prediction: dict[str, Any], market_data: dict[str, Any], risk_metrics: dict[str, Any], timeframe_data: dict[str, dict[str, Any]] | None = None
    ) -> dict[str, Any]:
        """Generate comprehensive advanced signal combining AI, market, risk, and multi-timeframe data."""
        try:
            raw_conf = float(ai_prediction.get("confidence", 0.5) or 0.5)
            try:
                from backend.services.confidence_normalizer import ConfidenceNormalizer

                base_conf = ConfidenceNormalizer.normalize(raw_conf)
            except Exception:
                base_conf = raw_conf
            base_signal: dict[str, Any] = {
                "symbol": symbol,
                "signal_type": SignalType.ENTRY,
                "action": SignalAction.BUY if ai_prediction.get("prediction", 0) == 1 else SignalAction.SELL,
                "confidence": base_conf,
                "price": market_data.get("current_price"),
                "source": SignalSource.AI,
                "metadata": {
                    "ai_model": ai_prediction.get("model_name", "unknown"),
                    "feature_count": ai_prediction.get("feature_count", 0),
                    "prediction_timestamp": ai_prediction.get("timestamp"),
                },
            }
            if timeframe_data:
                base_signal = self.generate_multi_timeframe_signal(symbol, base_signal, timeframe_data)
            base_signal = self.generate_risk_adjusted_signal(symbol, base_signal, risk_metrics)
            regime = self.detect_market_regime(symbol, market_data)
            base_signal["metadata"]["market_regime"] = regime
            base_signal["metadata"]["advanced_analytics"] = {
                "volatility_regime": "high" if risk_metrics.get("volatility", 0.5) > 0.7 else "normal",
                "momentum_strength": market_data.get("momentum", 0.0),
                "trend_strength": market_data.get("trend_strength", 0.0),
                "volume_profile": "high" if market_data.get("volume_ratio", 1.0) > 1.2 else "normal",
            }
            if regime in ["high_volatility", "bearish"]:
                base_signal["confidence"] = base_signal.get("confidence", 0.5) * 0.8
            logger.info("Advanced signal for %s: action=%s confidence=%.3f regime=%s", symbol, base_signal["action"].value, base_signal["confidence"], regime)
            return base_signal
        except Exception as e:
            logger.exception("Advanced signal generation failed for %s: %s", symbol, e)
            return {"symbol": symbol, "signal_type": SignalType.INFO, "action": SignalAction.HOLD, "confidence": 0.5, "metadata": {"error": str(e)}}


# ---------------------------
# Indicator helpers (very light)
# ---------------------------


def _ema(series: list[float], period: int) -> list[float]:
    """
    Calculate Exponential Moving Average from live price series (backend port 8000).

    Args:
        series: Live price series from Binance.US API
        period: EMA period (configuration default, not fallback data)

    Returns:
        List of EMA values calculated from live data
    """
    if period <= 1 or len(series) < period:
        return []  # Insufficient live data
    k = 2 / (period + 1)
    ema_vals: list[float] = []
    sma = sum(series[:period]) / period  # Initial SMA from live data
    ema_vals.append(sma)
    for price in series[period:]:  # Process live prices
        ema_vals.append((price - ema_vals[-1]) * k + ema_vals[-1])  # Calculate from live data
    return ema_vals


def _macd(series: list[float], fast: int, slow: int, signal: int) -> tuple[list[float] | None, list[float] | None]:
    """
    Calculate MACD (Moving Average Convergence Divergence) from live price series (backend port 8000).

    Args:
        series: Live price series from Binance.US API
        fast: Fast EMA period (configuration default, not fallback data)
        slow: Slow EMA period (configuration default, not fallback data)
        signal: Signal line period (configuration default, not fallback data)

    Returns:
        Tuple of (MACD line, signal line) calculated from live data, or (None, None) if insufficient data
    """
    if slow <= fast:
        slow = fast + 1
    if len(series) < slow + signal:
        return None, None  # Insufficient live data
    ema_fast = _ema(series, fast)  # Calculate from live data
    ema_slow = _ema(series, slow)  # Calculate from live data
    # Align lengths
    macd_line = []
    for i in range(len(ema_slow)):
        macd_line.append(ema_fast[i + (len(ema_fast) - len(ema_slow))] - ema_slow[i])  # Calculate from live EMAs
    signal_line = _ema(macd_line, signal)  # Calculate signal line from live MACD
    if not signal_line:
        return None, None  # Insufficient live data
    # Align lengths
    macd_line = macd_line[-len(signal_line) :]
    return macd_line, signal_line


def _rsi(series: list[float], period: int) -> float | None:
    """
    Calculate RSI (Relative Strength Index) from live price series (backend port 8000).

    Args:
        series: Live price series from Binance.US API
        period: RSI period (configuration default, not fallback data)

    Returns:
        RSI value calculated from live data, or None if insufficient data
    """
    if len(series) <= period:
        return None  # Insufficient live data
    gains = 0.0
    losses = 0.0
    for i in range(1, period + 1):
        diff = series[i] - series[i - 1]  # Calculate from live prices
        if diff >= 0:
            gains += diff
        else:
            losses -= diff
    avg_gain = gains / period  # Calculate from live data
    avg_loss = losses / period  # Calculate from live data
    if avg_loss == 0:
        return 100.0  # All gains, no losses from live data
    rs = avg_gain / avg_loss  # Calculate from live data
    rsi_vals = [100 - (100 / (1 + rs))]  # Initial RSI from live data
    # Wilder's smoothing
    for i in range(period + 1, len(series)):
        diff = series[i] - series[i - 1]  # Calculate from live prices
        gain = max(diff, 0.0)
        loss = max(-diff, 0.0)
        avg_gain = (avg_gain * (period - 1) + gain) / period  # Update from live data
        avg_loss = (avg_loss * (period - 1) + loss) / period  # Update from live data
        if avg_loss == 0:
            rsi_vals.append(100.0)  # All gains from live data
        else:
            rs = avg_gain / avg_loss  # Calculate from live data
            rsi_vals.append(100 - (100 / (1 + rs)))  # Calculate from live data
    return float(rsi_vals[-1]) if rsi_vals else None


def _scale_conf(x: float, lo: float, hi: float) -> float:
    """
    Scale confidence value to 0..1 range (backend port 8000).

    Args:
        x: Value to scale from live data
        lo: Lower bound (configuration default, not fallback data)
        hi: Upper bound (configuration default, not fallback data)

    Returns:
        Scaled confidence value (0..1)
    """
    if hi <= lo:
        return 0.5  # Default neutral confidence (error state, not fallback)
    v = (x - lo) / (hi - lo)  # Calculate from live data
    return float(max(0.0, min(1.0, v)))


# ---------------------------
# Global instance + accessor
# ---------------------------

signals_manager = SignalsManager()


def get_signals_manager() -> SignalsManager:
    """
    Get the global signals manager instance for live operations (backend port 8000).

    Returns:
        Global signals manager instance
    """
    return signals_manager


__all__ = [
    "EXCHANGE_ID",
    "TOP10_COINS",
    "Signal",
    "SignalAction",
    "SignalSource",
    "SignalType",
    "SignalsManager",
    "get_signals_manager",
    "signals_manager",
]
