"""
Strategy Manager for Mystic Trading Platform AI

Centralized registry and lifecycle management for trading strategies.
- Safe to import (no side effects)
- No external I/O
- Minimal, predictable API for adding/updating/removing strategies
"""

from __future__ import annotations

import builtins
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class StrategyState(Enum):
    ACTIVE = "active"
    PAUSED = "paused"
    DISABLED = "disabled"


@dataclass
class Strategy:
    """In-memory representation of a strategy."""

    id: str
    name: str
    config: dict[str, Any] = field(default_factory=dict)
    state: StrategyState = StrategyState.ACTIVE
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updated_at: str | None = None
    version: int = 1

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "config": self.config,
            "state": self.state.value,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "version": self.version,
        }


class StrategyManager:
    """
    Manages the lifecycle of strategies:
      - Register / Update / Remove
      - Activate / Pause / Disable
      - Quick validation and metadata
      - Lightweight performance accounting
    """

    def __init__(self) -> None:
        self._strategies: dict[str, Strategy] = {}
        # Lightweight counters; deeper analytics belong in StrategyAnalyzer
        self._stats: dict[str, dict[str, Any]] = {}
        logger.info("[OK] StrategyManager initialized")

    # -------------------------
    # CRUD
    # -------------------------

    def register(self, strategy_id: str, name: str, config: dict[str, Any]) -> dict[str, Any]:
        """Register a new strategy. Raises ValueError on invalid input."""
        self._validate_config_or_raise({"id": strategy_id, "name": name, **(config or {})}, strict=True)

        if strategy_id in self._strategies:
            msg = "Strategy with this ID already exists"
            raise ValueError(msg)

        strat = Strategy(id=strategy_id, name=name, config=config or {})
        self._strategies[strategy_id] = strat
        self._stats[strategy_id] = {"executions": 0, "wins": 0, "losses": 0, "pnl": 0.0}

        logger.info("Strategy registered: %s (%s)", strategy_id, name)
        return {"success": True, "strategy": strat.to_dict()}

    def update(self, strategy_id: str, updates: dict[str, Any]) -> dict[str, Any]:
        """Update strategy metadata/config."""
        strat = self._strategies.get(strategy_id)
        if not strat:
            return {"success": False, "error": "Strategy not found"}

        # Only config/name/state/version are updateable
        if "name" in updates and isinstance(updates["name"], str) and updates["name"].strip():
            strat.name = updates["name"].strip()

        if "config" in updates and isinstance(updates["config"], dict):
            # Shallow merge for safety/predictability
            new_cfg = dict(strat.config)
            new_cfg.update(updates["config"])
            # Validate the merged config with the required fields preserved
            self._validate_config_or_raise({"id": strat.id, "name": strat.name, **new_cfg}, strict=False)
            strat.config = new_cfg

        if "state" in updates:
            try:
                strat.state = StrategyState(str(updates["state"]))
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                return {"success": False, "error": "Invalid state"}

        strat.version += 1
        strat.updated_at = datetime.now(timezone.utc).isoformat()

        logger.info("Strategy updated: %s (v%s)", strategy_id, strat.version)
        return {"success": True, "strategy": strat.to_dict()}

    def remove(self, strategy_id: str) -> dict[str, Any]:
        """Remove a strategy."""
        if strategy_id not in self._strategies:
            return {"success": False, "error": "Strategy not found"}
        del self._strategies[strategy_id]
        self._stats.pop(strategy_id, None)
        logger.info("Strategy removed: %s", strategy_id)
        return {"success": True}

    # -------------------------
    # State controls
    # -------------------------

    def activate(self, strategy_id: str) -> dict[str, Any]:
        return self._set_state(strategy_id, StrategyState.ACTIVE)

    def pause(self, strategy_id: str) -> dict[str, Any]:
        return self._set_state(strategy_id, StrategyState.PAUSED)

    def disable(self, strategy_id: str) -> dict[str, Any]:
        return self._set_state(strategy_id, StrategyState.DISABLED)

    def _set_state(self, strategy_id: str, state: StrategyState) -> dict[str, Any]:
        strat = self._strategies.get(strategy_id)
        if not strat:
            return {"success": False, "error": "Strategy not found"}
        strat.state = state
        strat.updated_at = datetime.now(timezone.utc).isoformat()
        logger.info("Strategy %s set to %s", strategy_id, state.value)
        return {"success": True, "strategy": strat.to_dict()}

    # -------------------------
    # Retrieval
    # -------------------------

    def get(self, strategy_id: str) -> dict[str, Any] | None:
        strat = self._strategies.get(strategy_id)
        return strat.to_dict() if strat else None

    def list(self, state: str | None = None) -> builtins.list[dict[str, Any]]:
        items = list(self._strategies.values())
        if state:
            try:
                st = StrategyState(state)
                items = [s for s in items if s.state is st]
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                items = []
        return [s.to_dict() for s in items]

    # -------------------------
    # Validation
    # -------------------------

    def validate(self, config: dict[str, Any]) -> dict[str, Any]:
        """Public validation entrypoint."""
        ok, errors = self._validate_config(config)
        return {"valid": ok, "errors": errors}

    def _validate_config_or_raise(self, config: dict[str, Any], *, strict: bool) -> None:
        ok, errors = self._validate_config(config)
        if strict and not ok:
            msg = f"Invalid strategy config: {errors}"
            raise ValueError(msg)

    def _validate_config(self, config: dict[str, Any]) -> tuple[bool, builtins.list[str]]:
        errors: list[str] = []
        if not isinstance(config, dict):
            return False, ["Configuration must be a dictionary"]

        # Required fields
        for field_name in ("id", "name"):
            v = config.get(field_name)
            if v is None or (isinstance(v, str) and not v.strip()):
                errors.append(f"Missing or empty required field: {field_name}")

        # Optional sanity checks
        # Example: if "risk" present, ensure it's sane
        risk = config.get("risk")
        if risk is not None:
            try:
                r = float(risk)
                if r <= 0:
                    errors.append("risk must be positive")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                errors.append("risk must be numeric")

        return (len(errors) == 0), errors

    # -------------------------
    # Lightweight statistics (optional)
    # -------------------------

    def record_result(self, strategy_id: str, *, pnl: float, win: bool | None = None) -> dict[str, Any]:
        """Record one execution result for quick stats."""
        s = self._stats.get(strategy_id)
        if not s or strategy_id not in self._strategies:
            return {"success": False, "error": "Strategy not found"}

        s["executions"] = int(s.get("executions", 0)) + 1
        s["pnl"] = float(s.get("pnl", 0.0)) + float(pnl)
        if win is True:
            s["wins"] = int(s.get("wins", 0)) + 1
        elif win is False:
            s["losses"] = int(s.get("losses", 0)) + 1

        return {"success": True, "stats": self._stats[strategy_id].copy()}

    def get_stats(self, strategy_id: str | None = None) -> dict[str, Any]:
        """Get stats for one strategy or aggregate across all."""
        if strategy_id:
            st = self._stats.get(strategy_id, {})
            return {"strategy_id": strategy_id, "stats": st.copy()}
        # Aggregate view
        total_exec = sum(int(s.get("executions", 0)) for s in self._stats.values())
        total_pnl = sum(float(s.get("pnl", 0.0)) for s in self._stats.values())
        total_wins = sum(int(s.get("wins", 0)) for s in self._stats.values())
        total_losses = sum(int(s.get("losses", 0)) for s in self._stats.values())
        win_rate = (total_wins / (total_wins + total_losses)) if (total_wins + total_losses) > 0 else 0.0
        return {
            "aggregate": {
                "executions": total_exec,
                "pnl": total_pnl,
                "wins": total_wins,
                "losses": total_losses,
                "win_rate": win_rate,
                "strategies_tracked": len(self._stats),
            },
        }

    # -------------------------
    # Export / Import
    # -------------------------

    def export(self) -> dict[str, Any]:
        """Export all strategies (no I/O here; caller decides where to write)."""
        return {
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "count": len(self._strategies),
            "strategies": [s.to_dict() for s in self._strategies.values()],
        }

    def import_(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Import strategies from a plain dict structure."""
        try:
            items = payload.get("strategies", [])
            if not isinstance(items, list):
                return {"success": False, "error": "Invalid import format"}

            imported = 0
            for raw in items:
                if not isinstance(raw, dict):
                    continue
                sid = raw.get("id")
                name = raw.get("name")
                cfg = raw.get("config", {})
                if not sid or not name:
                    continue
                if sid in self._strategies:
                    # Merge update
                    self.update(sid, {"name": name, "config": cfg})
                else:
                    self.register(sid, name, cfg)
                imported += 1
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Import failed: %s", e)
            return {"success": False, "imported": 0}
        else:
            return {"success": True, "imported": imported}

    # -------------------------
    # Status
    # -------------------------

    def status(self) -> dict[str, Any]:
        active = sum(1 for s in self._strategies.values() if s.state is StrategyState.ACTIVE)
        paused = sum(1 for s in self._strategies.values() if s.state is StrategyState.PAUSED)
        disabled = sum(1 for s in self._strategies.values() if s.state is StrategyState.DISABLED)
        return {
            "service": "StrategyManager",
            "total": len(self._strategies),
            "active": active,
            "paused": paused,
            "disabled": disabled,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }


# Global instance + helper
strategy_manager = StrategyManager()


def get_strategy_manager() -> StrategyManager:
    return strategy_manager
