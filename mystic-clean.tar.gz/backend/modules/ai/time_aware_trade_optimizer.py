"""
Time-Aware Trade Optimizer for Mystic AI Trading Platform - All Live Data, No Fallback/Hardcoded Data

Analyzes historical price data to identify optimal trading windows and timing patterns
for Binance.US Top-10 spot symbols (backend port 8000).
All operations use live data:
- Historical data: Fetches live historical data from canonical_cache
- Time optimization: Analyzes live price/volume patterns for optimal entry/exit times
- All analysis uses live data - no fallback/hardcoded data

Design goals:
- Safe to import (no side effects)
- Relies on canonical_cache for historical data
- All timestamps treated as UTC
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timezone
from typing import Any

import numpy as np

# Single source of truth - Trading Universe (ALL 10 COINS - HARDCODED AS REQUIRED)
try:
    from backend.config.trading_universe import EXCHANGE_ID, TOP10_COINS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, KeyError, IndexError, RuntimeError) as e:
    msg = "Trading universe configuration is required for live operations"
    logging.getLogger(__name__).exception("Failed to import trading universe")
    raise RuntimeError(msg) from e

# Project import (expected to exist in repo)
try:
    from backend.services.canonical_cache import canonical_cache
    from backend.services.confidence_normalizer import ConfidenceNormalizer
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, KeyError, IndexError, RuntimeError) as e:
    msg = "Canonical cache is required for live operations"
    logging.getLogger(__name__).exception("Failed to import canonical cache")
    raise RuntimeError(msg) from e

logger = logging.getLogger(__name__)


class TimeAwareTradeOptimizer:
    """
    Identify statistically favorable hours (UTC) for entries and exits by combining:
      - Intraday volatility patterns
      - Hourly volume surges
      - Simple price-action-derived "trade" signals (proxy for historical trades)

    Notes:
      - Uses cached, already-aggregated historical data via canonical_cache.
      - All timestamps are treated as UTC.
    """

    def __init__(self) -> None:
        self.cache = canonical_cache

        # Time horizon (in hours) for analyses
        self.time_windows: dict[str, int] = {
            "intraday": 24,  # hours
            "weekly": 168,  # 7 days
            "monthly": 720,  # 30 days
        }

        # Analysis thresholds
        self.volatility_threshold: float = 0.02  # 2% avg. change between consecutive hourly prices
        self.volume_surge_threshold: float = 1.5  # 50% above overall hourly average
        self.min_data_points: int = 100

        # Pattern / scoring controls
        self.hour_granularity: int = 1
        self.confidence_threshold: float = 0.60
        self.min_trades_for_pattern: int = 5

        # Optional session buckets (not currently used in scoring, but exposed)
        self.trading_sessions: dict[str, tuple[int, int]] = {
            "asian": (0, 8),  # 00:00-08:00 UTC
            "london": (8, 16),  # 08:00-16:00 UTC
            "new_york": (13, 21),  # 13:00-21:00 UTC
        }

        logger.info("TimeAwareTradeOptimizer initialized for live operations")

    def _validate_symbol(self, symbol: str) -> str:
        """
        Validate and normalize trading symbol for live operations.

        Validates symbol is in Top-10 before processing.
        All symbols must be in the Top-10 universe.

        Args:
            symbol: Live trading symbol

        Returns:
            Normalized symbol

        Raises:
            ValueError: If symbol is not in Top-10
        """
        normalized = re.sub(r"[^A-Z0-9:_-]", "", symbol.upper())
        # Extract base symbol (remove USDT, /, etc.)
        base = normalized.replace("USDT", "").replace("/", "").replace("-", "").strip()
        # Validate symbol is in Top-10
        if base not in TOP10_COINS:
            msg = f"Symbol {base} is not in Top-10 universe. Supported: {TOP10_COINS}"
            logger.error(msg)
            raise ValueError(msg)
        return normalized

    # -----------------------------
    # Data access
    # -----------------------------

    def _get_historical_data(self, symbol: str, hours: int = 168) -> list[dict[str, Any]]:
        """
        Retrieve historical price/volume data from cache for `symbol`.

        Expected record format (per canonical_cache contract):
          {
            "timestamp": ISO8601 string (UTC),
            "price": float/string,
            "volume": float/string (optional)
          }

        Returns a list, sorted by timestamp ascending.
        """
        try:
            # Validate symbol is in Top-10
            normalized_symbol = self._validate_symbol(symbol)
            # Pull most-recent `hours` records from the 'aggregated' feed
            price_history = self.cache.get_price_history("aggregated", normalized_symbol, limit=hours)

            if not price_history or len(price_history) < self.min_data_points:
                msg = f"Insufficient live historical data for {normalized_symbol}: need at least {self.min_data_points} records, got {len(price_history) if price_history else 0}"
                logger.error(msg)
                return []

            hist: list[dict[str, Any]] = []
            for row in price_history:
                try:
                    ts_raw = str(row["timestamp"])
                    # Handle trailing Z (Zulu)
                    ts = datetime.fromisoformat(ts_raw.replace("Z", "+00:00")) if ts_raw.endswith("Z") else datetime.fromisoformat(ts_raw)
                    price = float(row["price"])
                    volume = float(row.get("volume", 0.0))
                    hist.append({"timestamp": ts, "price": price, "volume": volume})
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.debug("Skipping invalid point for %s: %s", symbol, e)

            hist.sort(key=lambda x: x["timestamp"])
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Failed to get historical data for %s", symbol)
            return []  # Empty list on error (not fallback data)
        else:
            return hist

    # -----------------------------
    # Analyses
    # -----------------------------

    def _calculate_intraday_volatility(self, data: list[dict[str, Any]]) -> dict[str, Any]:
        """
        Compute mean absolute % change per UTC hour bucket.
        Returns:
          {
            "hourly_volatility": {hour: float, ...},
            "peak_hours": [hour, ...]
          }
        """
        try:
            if len(data) < 24:
                return {"hourly_volatility": {}, "peak_hours": []}

            by_hour: dict[int, list[float]] = {}
            for row in data:
                h = row["timestamp"].hour
                by_hour.setdefault(h, []).append(row["price"])

            hourly_vol: dict[int, float] = {}
            peak_hours: list[int] = []

            for hour, prices in by_hour.items():
                if len(prices) < 2:
                    continue
                # % changes between consecutive values
                changes = [abs(prices[i] - prices[i - 1]) / prices[i - 1] for i in range(1, len(prices)) if prices[i - 1] != 0]
                if not changes:
                    continue
                avg = float(np.mean(changes))
                hourly_vol[hour] = avg
                if avg > self.volatility_threshold:
                    peak_hours.append(hour)

            return {
                "hourly_volatility": hourly_vol,
                "peak_hours": sorted(set(peak_hours)),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Intraday volatility calc failed")
            return {"hourly_volatility": {}, "peak_hours": []}

    def _identify_volume_surges(self, data: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """
        Identify UTC hours where average volume > (overall_avg * volume_surge_threshold).
        Returns a list sorted by surge_factor desc:
          [{ "hour": int, "avg_volume": float, "surge_factor": float }, ...]
        """
        try:
            if len(data) < 24:
                return []

            by_hour: dict[int, list[float]] = {}
            for row in data:
                h = row["timestamp"].hour
                by_hour.setdefault(h, []).append(float(row.get("volume", 0.0)))

            avg_by_hour: dict[int, float] = {h: float(np.mean(vs)) for h, vs in by_hour.items() if vs}
            all_vols = [v for vs in by_hour.values() for v in vs]
            overall = float(np.mean(all_vols)) if all_vols else 0.0
            if overall <= 0:
                return []

            surges: list[dict[str, Any]] = []
            for hour, avg_v in avg_by_hour.items():
                if avg_v > overall * self.volume_surge_threshold:
                    surges.append(
                        {
                            "hour": hour,
                            "avg_volume": avg_v,
                            "surge_factor": (avg_v / overall) if overall > 0 else 1.0,
                        },
                    )
            return sorted(surges, key=lambda x: x["surge_factor"], reverse=True)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Volume surge detection failed")
            return []

    def _analyze_historical_trades(self, data: list[dict[str, Any]]) -> dict[str, Any]:
        """
        Proxy "trade" analysis from price changes:
          - Entry signal when price jumps > +1% over previous hour
          - Exit  signal when price drops < -1% over previous hour
        Returns:
          { "entry_times": [hour...], "exit_times": [hour...], "successful_hours": [hour...] }
        """
        try:
            if len(data) < self.min_trades_for_pattern:
                return {"entry_times": [], "exit_times": [], "successful_hours": []}

            entry_hours: list[int] = []
            exit_hours: list[int] = []
            success_hours: list[int] = []

            for i in range(1, len(data)):
                p0 = data[i - 1]["price"]
                p1 = data[i]["price"]
                if p0 == 0:
                    continue
                change = (p1 - p0) / p0
                h = data[i]["timestamp"].hour

                if change > 0.01:
                    entry_hours.append(h)
                    success_hours.append(h)
                elif change < -0.01:
                    exit_hours.append(h)
                    success_hours.append(h)

            def _top_hours(hours: list[int], top_n: int) -> list[int]:
                counts: dict[int, int] = {}
                for h in hours:
                    counts[h] = counts.get(h, 0) + 1
                return [h for h, _c in sorted(counts.items(), key=lambda t: t[1], reverse=True)[:top_n]]

            return {
                "entry_times": _top_hours(entry_hours, 3),
                "exit_times": _top_hours(exit_hours, 3),
                "successful_hours": _top_hours(success_hours, 5),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Historical trade analysis failed")
            return {"entry_times": [], "exit_times": [], "successful_hours": []}

    # -----------------------------
    # Synthesis / decisions
    # -----------------------------

    def _calculate_optimal_windows(
        self,
        volatility: dict[str, Any],
        volume_surges: list[dict[str, Any]],
        trade_sig: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Combine signals to derive optimal entry/exit windows and hours to avoid.
        """
        try:
            entry_score: dict[int, float] = {}
            exit_score: dict[int, float] = {}

            # Volatility contributes to both entry and exit scoring (moderate weight)
            for h in set(volatility.get("peak_hours", [])):
                entry_score[h] = entry_score.get(h, 0.0) + 1.0
                exit_score[h] = exit_score.get(h, 0.0) + 1.0

            # Volume surges (higher weight to entries)
            for surge in volume_surges:
                h = int(surge["hour"])
                entry_score[h] = entry_score.get(h, 0.0) + 2.0

            # Historical signals (moderate weight)
            for h in set(trade_sig.get("successful_hours", [])):
                entry_score[h] = entry_score.get(h, 0.0) + 1.0
                exit_score[h] = exit_score.get(h, 0.0) + 1.0

            best_entry_hours = [h for h, _ in sorted(entry_score.items(), key=lambda t: t[1], reverse=True)[:3]]
            best_exit_hours = [h for h, _ in sorted(exit_score.items(), key=lambda t: t[1], reverse=True)[:3]]

            active_hours = set(entry_score) | set(exit_score)
            avoid_hours = sorted(set(range(24)) - active_hours)

            # Confidence: normalize by number of signal-bearing hours (simple heuristic)
            total_signal_hours = len(active_hours)
            # cap denominator to avoid tiny fractions when signals are abundant
            confidence = min(1.0, (total_signal_hours / 20.0)) if total_signal_hours > 0 else 0.0
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Optimal window calculation failed")
            return {
                "best_entry_hours": [],
                "best_exit_hours": [],
                "avoid_hours": [],
                "confidence": 0.0,
            }
        else:
            return {
                "best_entry_hours": best_entry_hours,
                "best_exit_hours": best_exit_hours,
                "avoid_hours": avoid_hours,
                "confidence": confidence,
            }

    def _format_time_decision(self, symbol: str, windows: dict[str, Any]) -> dict[str, Any]:
        """
        Produce human-friendly times (UTC) and include alternatives.

        All times are calculated from live data - no hardcoded fallback times.
        """
        try:

            def to_time(h):
                return f"{int(h):02d}:00 UTC"

            entry_list = [to_time(h) for h in windows.get("best_entry_hours", [])]
            exit_list = [to_time(h) for h in windows.get("best_exit_hours", [])]

            entry_list_result = entry_list
            exit_list_result = exit_list
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error calculating optimal times for {symbol}: {e}")
            raise

        # Validate entry/exit lists outside try to avoid TRY301
        if not entry_list_result:
            msg = f"No optimal entry hours calculated from live data for {symbol}"
            logger.error(msg)
            raise ValueError(msg)

        if not exit_list_result:
            msg = f"No optimal exit hours calculated from live data for {symbol}"
            logger.error(msg)
            raise ValueError(msg)

        try:
            primary_entry = entry_list_result[0]
            primary_exit = exit_list_result[0]

            return {
                "symbol": symbol,
                "best_entry": primary_entry,
                "best_exit": primary_exit,
                "confidence": ConfidenceNormalizer.normalize(float(windows.get("confidence", 0.0) or 0.0)),
                "alternative_entries": entry_list[1:] if len(entry_list) > 1 else [],
                "alternative_exits": exit_list[1:] if len(exit_list) > 1 else [],
                "avoid_hours": sorted(windows.get("avoid_hours", [])),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Decision formatting failed")
            msg = f"Failed to format time decision for {symbol}: {e!s}"
            raise RuntimeError(msg) from e

    # -----------------------------
    # Public API
    # -----------------------------

    def get_optimal_trade_times(self, exchange: str, symbol: str) -> dict[str, Any]:
        """
        Compute optimal entry/exit hours for a symbol using ~1-week historical data.

        Args:
            exchange: Live exchange ID (must match EXCHANGE_ID from trading_universe)
            symbol: Live trading symbol (must be in Top-10)

        Returns:
            Dictionary with optimal trade times calculated from live data

        Raises:
            ValueError: If exchange doesn't match or symbol is not in Top-10
            RuntimeError: If optimization fails
        """
        # Validate exchange before try block to avoid TRY301
        if exchange != EXCHANGE_ID:
            msg = f"Exchange {exchange} does not match configured EXCHANGE_ID {EXCHANGE_ID}"
            logger.error(msg)
            raise ValueError(msg)

        try:
            # Validate symbol is in Top-10
            normalized_symbol = self._validate_symbol(symbol)

            logger.info("Analyzing optimal trade times for %s", normalized_symbol)

            data = self._get_historical_data(normalized_symbol, hours=self.time_windows["weekly"])
            vol = self._calculate_intraday_volatility(data)
            surges = self._identify_volume_surges(data)
            trades = self._analyze_historical_trades(data)

            windows = self._calculate_optimal_windows(vol, surges, trades)
            decision = self._format_time_decision(normalized_symbol, windows)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error analyzing optimal trade times: {e}")
            raise

        # Validate data outside try to avoid TRY301
        if not data:
            msg = f"Insufficient live historical data for {normalized_symbol}"
            logger.error(msg)
            raise ValueError(msg)

        try:
            # Persist a summary signal for downstream consumers
            try:
                opt_id = f"time_opt_{normalized_symbol}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
                self.cache.store_signal(
                    signal_id=opt_id,
                    symbol=normalized_symbol,
                    signal_type="TIME_OPTIMIZATION",
                    confidence=ConfidenceNormalizer.normalize(float(windows.get("confidence", 0.0))),
                    strategy="time_aware_optimization",
                    metadata=decision,
                )
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                logger.debug("Failed to store optimization signal for %s", normalized_symbol)

            logger.info(
                "Time optimization complete for %s: %s -> %s",
                normalized_symbol,
                decision["best_entry"],
                decision["best_exit"],
            )

            return {
                "symbol": normalized_symbol,
                "success": True,
                "time_decision": decision,
                "analysis_summary": {
                    "volatility_peaks": len(vol.get("peak_hours", [])),
                    "volume_surges": len(surges),
                    "historical_patterns": len(trades.get("successful_hours", [])),
                },
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Optimal trade time computation failed for %s", symbol)
            msg = f"Optimal trade time computation failed for {symbol}: {e!s}"
            raise RuntimeError(msg) from e

    def optimize_all_symbols(self) -> dict[str, Any]:
        """
        Batch optimization over all Top-10 symbols.

        Uses Top-10 coins from trading_universe (all 10 coins - hardcoded as required).
        """
        try:
            logger.info("Starting batch time optimization for Top-10 symbols")

            # Use Top-10 coins from trading_universe (all 10 coins - hardcoded as required)
            symbols = [f"{coin}USDT" for coin in TOP10_COINS]

            results: dict[str, Any] = {}
            ok = 0

            for sym in symbols:
                try:
                    res = self.get_optimal_trade_times(EXCHANGE_ID, sym)
                    results[sym] = res
                    if res.get("success"):
                        ok += 1
                except (ValueError, RuntimeError) as e:
                    logger.warning("Failed to optimize %s: %s", sym, e)
                    results[sym] = {
                        "symbol": sym,
                        "success": False,
                        "error": str(e),
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    }

            return {
                "success": True,
                "total_symbols": len(symbols),
                "successful_optimizations": ok,
                "results": results,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Batch optimization failed")
            msg = f"Batch optimization failed: {e!s}"
            raise RuntimeError(msg) from e

    def get_optimization_history(self, symbol: str, limit: int = 10) -> list[dict[str, Any]]:
        """
        Retrieve recent TIME_OPTIMIZATION signals for `symbol` from cache.
        """
        try:
            sigs = self.cache.get_signals_by_type("TIME_OPTIMIZATION", limit=limit) or []
            return [s for s in sigs if s.get("symbol") == symbol]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            logger.exception("Optimization history retrieval failed for %s", symbol)
            return []

    def get_optimizer_status(self) -> dict[str, Any]:
        """
        Basic status/introspection.
        """
        try:
            return {
                "service": "TimeAwareTradeOptimizer",
                "status": "active",
                "time_windows": dict(self.time_windows),
                "parameters": {
                    "volatility_threshold": self.volatility_threshold,
                    "volume_surge_threshold": self.volume_surge_threshold,
                    "min_data_points": self.min_data_points,
                    "confidence_threshold": self.confidence_threshold,
                },
                "trading_sessions": dict(self.trading_sessions),
                "capabilities": {
                    "intraday_volatility_analysis": True,
                    "volume_surge_detection": True,
                    "historical_trade_analysis": True,
                    "optimal_window_calculation": True,
                },
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Status retrieval failed")
            msg = f"Status retrieval failed: {e!s}"
            raise RuntimeError(msg) from e


# Singleton
time_aware_trade_optimizer = TimeAwareTradeOptimizer()


def get_time_aware_trade_optimizer() -> TimeAwareTradeOptimizer:
    return time_aware_trade_optimizer


if __name__ == "__main__":
    opt = TimeAwareTradeOptimizer()
    logger.info("TimeAwareTradeOptimizer initialized.")
    # Use live exchange ID and first Top-10 coin for testing
    test_symbol = f"{TOP10_COINS[0]}USDT" if TOP10_COINS else "BTCUSDT"
    logger.info(opt.get_optimal_trade_times(EXCHANGE_ID, test_symbol))
    logger.info(opt.get_optimizer_status())
