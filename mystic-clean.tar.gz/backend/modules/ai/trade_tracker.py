"""
Trade Tracker Module - All Live Data, No Fallback/Hardcoded Data

Provides functions for tracking live trades, history, and summaries for Binance.US Top-10 spot trading
(backend port 8000).
All operations use live data:
- Active trades: Fetches live open orders from Binance.US via LiveTradingService
- Trade history: Retrieves live trade history from Binance.US via LiveTradingService
- Trade summaries: Aggregates live trade statistics from live trading operations
- All tracking uses live data - no fallback/hardcoded data

Features:
- Safe to import (no side effects)
- Works whether or not the live trading service is installed
- Robust asyncio bridge so sync callers can invoke async services safely
- All operations use live data from Binance.US

Endpoint References:
- Backend API: Port 8000 (trade tracker serves live operations)
- Binance.US API: Live trade data via LiveTradingService
- All operations handle live data - no mock/test data
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import logging
from typing import Any

# Optional imports - try at top level
try:
    from backend.services.live_trading_service import LiveTradingService  # type: ignore[import-not-found]
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    LiveTradingService = None

try:
    from backend.modules.ai.ai_signals import (
        get_trade_summary as ai_get_trade_summary,
    )  # type: ignore[import-not-found]
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    ai_get_trade_summary = None

# Optional import for persistent trade storage
try:
    from backend.trade_memory_integration import log_trade_entry  # type: ignore[import-not-found]
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    log_trade_entry = None

# Single source of truth - Trading Universe (ALL 10 COINS - HARDCODED AS REQUIRED)
try:
    from backend.config.trading_universe import EXCHANGE_ID, TOP10_COINS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, KeyError, IndexError, RuntimeError) as e:
    msg = "Trading universe configuration is required for live operations"
    logging.getLogger(__name__).exception("Failed to import trading universe")
    raise RuntimeError(msg) from e

logger = logging.getLogger(__name__)

# Configuration constants (not fallback data)
DEFAULT_TIMEOUT = 10.0  # Default timeout for async operations in seconds (configuration default)
TRADE_HISTORY_TIMEOUT = 15.0  # Timeout for trade history operations in seconds (configuration default)
DEFAULT_LIMIT = 100  # Default limit for trade history (configuration default)


# -----------------------------
# Internal helpers
# -----------------------------


def _run_coro(coro, timeout: float | None = DEFAULT_TIMEOUT) -> Any:
    """
    Run an async coroutine from a sync function, regardless of whether a loop is already running (backend port 8000).

    Strategy:
      - If we're already inside an event loop: execute the coroutine in a worker thread
        using `asyncio.run(...)` so we don't interfere with the running loop.
      - If not: simply `asyncio.run(coro)`.

    Args:
        coro: Async coroutine to execute (returns live data)
        timeout: Timeout in seconds (configuration default, not fallback data)

    Returns:
        Coroutine result with live data, or raises on timeout/exception
    """
    try:
        asyncio.get_running_loop()  # Will raise RuntimeError if no loop is running
        # We are inside an event loop -> use a worker thread to run a fresh event loop
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(asyncio.run, coro)
            return future.result(timeout=timeout)  # Execute coroutine returning live data
    except RuntimeError:
        # No running loop -> safe to call asyncio.run directly
        return asyncio.run(coro)  # Execute coroutine returning live data
    except concurrent.futures.TimeoutError as e:
        msg = "Async operation timed out"
        raise TimeoutError(msg) from e


def _flatten_exchange_map(result: dict[str, Any], key: str) -> list[dict[str, Any]]:
    """
    Flatten exchange map from live trading service response (backend port 8000).

    Given a result like {"status":"success","orders":{"binance":[...]}}
    return a single flattened list for the requested `key` ("orders" or "trades").

    Args:
        result: Live trading service response dictionary
        key: Key to extract ("orders" or "trades") from live response

    Returns:
        Flattened list of live items from all exchanges
    """
    items: list[dict[str, Any]] = []
    try:
        for exchange_items in result.get(key, {}).values():
            if isinstance(exchange_items, list):
                items.extend(exchange_items)  # Add live items from exchange
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        logger.exception("Failed to flatten %s", key)
    return items


# -----------------------------
# Public API
# -----------------------------


def get_active_trades() -> list[dict[str, Any]]:
    """
    Get list of active live trades from Binance.US trading service (backend port 8000).

    Fetches live open orders from Binance.US via LiveTradingService.
    All trades are from live exchange - no fallback/hardcoded data.

    Returns:
        List of live active trade dictionaries from Binance.US, or empty list if unavailable
    """
    if LiveTradingService is None:
        logger.error("LiveTradingService is not available")
        return []

    trading_service = LiveTradingService()

    try:
        result = _run_coro(trading_service.get_open_orders(), timeout=DEFAULT_TIMEOUT)  # Get live open orders
    except TimeoutError:
        logger.exception("Timeout while fetching live open orders")
        return []  # Empty list on timeout (error state, not fallback data)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        logger.exception("Error calling live trading service (open orders)")
        return []  # Empty list on error (no live data)

    if isinstance(result, dict) and result.get("status") == "success":
        return _flatten_exchange_map(result, "orders")  # Return live orders

    logger.error(
        "Live trading service error: %s",
        result.get("message", "Unknown error") if isinstance(result, dict) else "Unknown",
    )
    return []  # Empty list on error (not fallback data)


def get_trade_history(limit: int = DEFAULT_LIMIT) -> list[dict[str, Any]]:
    """
    Get live trade history from Binance.US trading service (backend port 8000).

    Retrieves live trade history from Binance.US via LiveTradingService.
    All trades are from live exchange - no fallback/hardcoded data.

    Args:
        limit: Maximum number of trades to retrieve (configuration default, not fallback data)

    Returns:
        List of live trade history dictionaries from Binance.US, or empty list if unavailable
    """
    if LiveTradingService is None:
        logger.error("LiveTradingService is not available")
        return []

    trading_service = LiveTradingService()

    try:
        result = _run_coro(trading_service.get_trade_history(limit=limit), timeout=TRADE_HISTORY_TIMEOUT)  # Get live trade history
    except TimeoutError:
        logger.exception("Timeout while fetching live trade history")
        return []  # Empty list on timeout (error state, not fallback data)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        logger.exception("Error calling live trading service (trade history)")
        return []  # Empty list on error (no live data)

    if isinstance(result, dict) and result.get("status") == "success":
        return _flatten_exchange_map(result, "trades")  # Return live trades

    logger.error(
        "Live trading service error: %s",
        result.get("message", "Unknown error") if isinstance(result, dict) else "Unknown",
    )
    return []  # Empty list on error (not fallback data)


def get_trade_summary() -> dict[str, Any]:
    """
    Get aggregated live trade summary from AI signals (backend port 8000).

    Aggregates live trade statistics from live trading operations.
    All statistics are from live data - no fallback/hardcoded data.

    Returns:
        Dictionary with live trade summary statistics:
        - total_trades: Total live trades count
        - winning_trades: Winning live trades count
        - losing_trades: Losing live trades count
        - total_profit: Total profit from live trades
        - win_rate: Win rate from live trades
        - average_profit: Average profit from live trades
    """
    if ai_get_trade_summary is None:
        msg = "ai_get_trade_summary is not available"
        logger.error(msg)
        raise RuntimeError(msg)

    summary = ai_get_trade_summary()  # Get live summary from AI signals
    if not isinstance(summary, dict):
        msg = "ai_get_trade_summary must return a dict"
        raise TypeError(msg)

    # Validate required fields are present (all from live data)
    # Zero values are valid when there are no trades yet (not fallback data)
    required_fields = ["total_trades", "winning_trades", "losing_trades", "total_profit", "win_rate", "average_profit"]
    missing_fields = [f for f in required_fields if f not in summary]
    if missing_fields:
        msg = f"Live trade summary missing required fields: {missing_fields}"
        logger.error(msg)
        raise ValueError(msg)

    # Return summary with all required fields from live data
    # Zero values indicate no trades yet, not fallback data
    return {
        "total_trades": summary.get("total_trades", 0),  # From live data, zero if no trades yet
        "winning_trades": summary.get("winning_trades", 0),  # From live data, zero if no trades yet
        "losing_trades": summary.get("losing_trades", 0),  # From live data, zero if no trades yet
        "total_profit": summary.get("total_profit", 0.0),  # From live data, zero if no trades yet
        "win_rate": summary.get("win_rate", 0.0),  # From live data, zero if no trades yet
        "average_profit": summary.get("average_profit", 0.0),  # From live data, zero if no trades yet
        **(
            {
                k: v
                for k, v in summary.items()
                if k
                not in {
                    "total_trades",
                    "winning_trades",
                    "losing_trades",
                    "total_profit",
                    "win_rate",
                    "average_profit",
                }
            }
        ),
    }


def get_orders() -> list[dict[str, Any]]:
    """
    Get all live orders (alias for get_active_trades for compatibility) (backend port 8000).

    Returns:
        List of live active trade dictionaries from Binance.US
    """
    return get_active_trades()  # Return live active trades


def record_entry(symbol: str, position_size: float, price: float) -> None:
    """
    Record a trade entry for tracking purposes (backend port 8000).

    Stores trade entry to persistent database via trade_memory_integration.
    All data is from live trading operations - no fallback/hardcoded data.

    Args:
        symbol: Trading symbol (e.g., 'BTC/USD', 'BTC-USDT', 'BTCUSDT')
        position_size: Size of the position (live quantity)
        price: Entry price (live price)

    Note:
        Trade entry is stored to database via log_trade_entry for persistent tracking.
        Symbol is normalized to coin name (e.g., 'BTC/USD' -> 'BTC') for storage.
    """
    try:
        # Normalize symbol to coin name for database storage
        # Handle various formats: 'BTC/USD', 'BTC-USDT', 'BTCUSDT' -> 'BTC'
        coin = symbol.upper()
        # Remove common separators and quote currencies
        for sep in ["/", "-", "_"]:
            if sep in coin:
                coin = coin.split(sep)[0]
        # Remove quote currencies if present
        for quote in ["USD", "USDT", "USDC", "BUSD"]:
            if coin.endswith(quote):
                coin = coin[: -len(quote)]
            if coin.startswith(quote):
                coin = coin[len(quote) :]

        # Log the entry
        logger.debug(f"Trade entry recorded: {symbol} -> {coin}, size={position_size}, price={price}")

        # Store to persistent database if available
        if log_trade_entry is not None:
            try:
                # Use default strategy name for trade tracker entries
                strategy_name = "trade_tracker"
                trade_id = log_trade_entry(
                    coin=coin,
                    strategy_name=strategy_name,
                    entry_price=price,
                    quantity=position_size,
                    entry_reason=f"Trade entry from trade_tracker for {symbol}",
                    trade_type="spot",
                    risk_level="medium",
                    tags=f"trade_tracker,{symbol}",
                )
                if trade_id:
                    logger.info(f"Trade entry persisted to database: trade_id={trade_id}, coin={coin}, price={price}")
                else:
                    logger.warning(f"Trade entry logging returned no trade_id for {coin}")
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.warning(f"Failed to persist trade entry to database: {e}")
        else:
            logger.debug("log_trade_entry not available - entry logged only (no persistence)")
    except Exception as e:
        logger.warning(f"Failed to record trade entry: {e}")


__all__ = [
    "EXCHANGE_ID",
    "TOP10_COINS",
    "get_active_trades",
    "get_orders",
    "get_trade_history",
    "get_trade_summary",
    "record_entry",
]
