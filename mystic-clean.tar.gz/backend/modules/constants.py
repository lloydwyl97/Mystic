"""
Constants for Mystic Trading Platform - All Live Data, No Fallback/Hardcoded Data

This module defines constants for live trading operations (backend port 8000).
All constants are configuration values for live operations:
- Exchange constants: Live exchange identifiers (Binance.US)
- Trading constants: Live trading operation timeouts and retry limits
- API constants: Live API configuration values (backend port 8000)
- Error messages: Live error message templates (not fallback data)
- Status constants: Live status values for operations
- All constants are configuration defaults, not fallback/hardcoded data

Endpoint References:
- Backend API: Port 8000 (constants used by live operations)
- Binance.US API: Live exchange operations
- All constants serve live operations - no mock/test data
"""

# Exchange constants (live exchange configuration)
# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

# Trading constants (live trading operation configuration)
DEFAULT_TIMEOUT = 30.0  # Configuration default for live API timeouts (seconds), not fallback data
MAX_RETRIES = 3  # Configuration default for live operation retries, not fallback data

# API constants (live API configuration - backend port 8000)
API_VERSION = "1.0.0"  # Live API version (configuration, not fallback data)
DEFAULT_PAGE_SIZE = 100  # Configuration default for live pagination, not fallback data

# Error messages (live error message templates - not fallback data)
ERROR_SERVICE_UNAVAILABLE = "Service temporarily unavailable"  # Live error message template
ERROR_INVALID_PARAMETERS = "Invalid parameters provided"  # Live error message template
ERROR_RATE_LIMIT_EXCEEDED = "Rate limit exceeded"  # Live error message template

# Status constants (live status values for operations)
STATUS_ACTIVE = "active"  # Live active status value
STATUS_INACTIVE = "inactive"  # Live inactive status value
STATUS_ERROR = "error"  # Live error status value
STATUS_PENDING = "pending"  # Live pending status value
