"""
Data Module for Mystic Trading Platform

Contains all data-related functionality including market data,
price fetching, and data processing.
"""

from .binance_data import BinanceDataFetcher, BinanceMarketData

# Legacy alias - create alias for BinanceDataFetcher
from .market_data import MarketData, MarketDataManager, market_data_manager

BinanceData = BinanceDataFetcher

__all__ = [
    "BinanceData",
    "BinanceDataFetcher",
    "BinanceMarketData",
    "MarketData",
    "MarketDataManager",
    "market_data_manager",
]
