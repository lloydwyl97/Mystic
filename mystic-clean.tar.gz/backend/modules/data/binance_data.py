"""
Binance Data Fetcher Module for Mystic Trading Platform

Handles all Binance US API interactions with centralized coin management.

Rules enforced:
- Uses Binance US (ccxt.binanceus) only
- Ten coins, centrally managed:
    BTC, ETH, ADA, SOL, DOGE, XRP, BCH, LTC, AVAX, LINK  (all against USDT)
- Async-friendly API with thread offloading for ccxt's sync methods
- Deterministic, UTC ISO8601 timestamps when exposed in dicts
- No hidden background loops; caller drives when to fetch
- Robust error handling and clear, ASCII-safe logging
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

# Direct imports for production
import ccxt

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import EXCHANGE_ID from trading_universe: {e}"
    raise RuntimeError(msg) from e

CCXT_AVAILABLE = True


def _get_exchange_id() -> str:
    """Get EXCHANGE_ID from trading_universe (live data)"""
    return EXCHANGE_ID


# Force IPv4 only for all connections (Binance US requirement)
try:
    import socket as _socket

    _orig_getaddrinfo = getattr(_socket, "getaddrinfo", None)

    def _ipv4_getaddrinfo(host, port, family=0, sock_type=0, proto=0, flags=0):
        try:
            return _orig_getaddrinfo(host, port, _socket.AF_INET, sock_type, proto, flags)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            return _orig_getaddrinfo(host, port, family, sock_type, proto, flags)

    if callable(_orig_getaddrinfo):
        _socket.getaddrinfo = _ipv4_getaddrinfo
except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
    pass

logger = logging.getLogger(__name__)

# =========================
# Data structure
# =========================


@dataclass
class BinanceMarketData:
    """Lightweight market snapshot."""

    symbol: str  # e.g., "BTC"
    price: float
    volume: float  # quote volume preferred if available
    change_24h: float  # percent, e.g., -1.23 for -1.23%
    high_24h: float
    low_24h: float
    timestamp: float  # epoch seconds
    exchange: str = field(default_factory=lambda: _get_exchange_id())

    def to_dict(self) -> dict[str, Any]:
        # Provide an ISO timestamp field as well (UTC, explicit)
        return {
            "symbol": self.symbol,
            "price": float(self.price),
            "volume": float(self.volume),
            "change_24h": float(self.change_24h),
            "high_24h": float(self.high_24h),
            "low_24h": float(self.low_24h),
            "timestamp": float(self.timestamp),
            "timestamp_iso": _iso_utc(self.timestamp),
            "exchange": self.exchange,
        }


# =========================
# Custom exceptions
# =========================


class BinanceClientError(Exception):
    """Raised when the Binance US client cannot be created or used."""


class BinanceDataError(Exception):
    """Raised for data fetch/transform errors."""


# =========================
# Utils
# =========================


def _iso_utc(epoch_seconds: float) -> str:
    return datetime.fromtimestamp(float(epoch_seconds), tz=timezone.utc).isoformat()


def _ensure_ccxt() -> None:
    if not CCXT_AVAILABLE:
        msg = "ccxt is not available. Please install 'ccxt' to use BinanceDataFetcher."
        raise BinanceClientError(msg)


def _pair_for(coin: str) -> str:
    # Binance US standard pair format
    return f"{coin.upper()}/USDT"


# =========================
# Main fetcher
# =========================


class BinanceDataFetcher:
    """
    Binance US API data fetcher with centralized coin management.

    Notes:
    - ccxt.binanceus is synchronous; we offload calls to a thread via asyncio.to_thread.
    - Public endpoints do not require API keys. If provided, they will be set.
    - All methods are async and safe to call concurrently.
    """

    def __init__(self) -> None:
        _ensure_ccxt()

        # Canonical, fixed list of supported coins (requested top 10)
        self._supported_coins: list[str] = [
            "BTC",
            "ETH",
            "ADA",
            "SOL",
            "DOGE",
            "XRP",
            "BCH",
            "LTC",
            "AVAX",
            "LINK",
        ]
        # Map coin -> trading pair
        self._pairs: dict[str, str] = {c: _pair_for(c) for c in self._supported_coins}

        # Create ccxt client (public only by default)
        api_key = os.getenv("BINANCEUS_API_KEY", "") or "public"
        secret = os.getenv("BINANCEUS_API_SECRET", "") or "public"
        # enableRateLimit keeps internal pacing conservative
        self._client = ccxt.binanceus(
            {
                "apiKey": api_key if api_key != "public" else "",
                "secret": secret if secret != "public" else "",
                "enableRateLimit": True,
                # Optional: safer defaults
                "options": {
                    "defaultType": "spot",
                },
            },
        )

        # Preload markets once on demand (lazy)
        self._markets_loaded: bool = False

        logger.info("BinanceDataFetcher initialized with %d coins", len(self._supported_coins))

    # --------- coin management ---------

    def get_supported_coins(self) -> list[str]:
        return list(self._supported_coins)

    def add_coin(self, coin: str) -> bool:
        """Add a coin (uppercased) and map it to COIN/USDT. No-op if exists."""
        try:
            c = coin.upper()
            if c not in self._supported_coins:
                self._supported_coins.append(c)
                self._pairs[c] = _pair_for(c)
                logger.info("Added coin: %s", c)
                return True
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error adding coin %s: %s", coin, str(e))
            return False
        else:
            return False

    def remove_coin(self, coin: str) -> bool:
        """Remove a coin; also removes its pair mapping."""
        try:
            c = coin.upper()
            if c in self._supported_coins:
                self._supported_coins.remove(c)
                self._pairs.pop(c, None)
                logger.info("Removed coin: %s", c)
                return True
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error removing coin %s: %s", coin, str(e))
            return False
        else:
            return False

    # --------- public data fetch ---------

    async def get_market_data(self, coin: str) -> BinanceMarketData | None:
        """
        Fetch a single coin's market snapshot via public ticker.
        Returns None if coin/pair unsupported or fetch fails.
        """
        try:
            await self._ensure_markets()
            c = coin.upper()
            pair = self._pairs.get(c)
            if not pair:
                logger.warning("Symbol %s not supported", c)
                return None

            # ccxt's fetch_ticker is sync; offload to a thread
            ticker = await asyncio.to_thread(self._client.fetch_ticker, pair)

            # Normalize fields w/ fallbacks
            last = float(ticker.get("last") or ticker.get("close") or 0.0)
            # Prefer quoteVolume if available; else use baseVolume as a fallback
            volume = float(ticker.get("quoteVolume") or ticker.get("baseVolume") or 0.0)
            pct = float(ticker.get("percentage") or 0.0)
            high = float(ticker.get("high") or 0.0)
            low = float(ticker.get("low") or 0.0)
            ts = float(ticker.get("timestamp") / 1000.0) if ticker.get("timestamp") else time.time()

            return BinanceMarketData(
                symbol=c,
                price=last,
                volume=volume,
                change_24h=pct,
                high_24h=high,
                low_24h=low,
                timestamp=ts,
                exchange=EXCHANGE_ID,
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error getting Binance US data for %s: %s", coin, str(e))
            return None

    async def get_all_market_data(self) -> dict[str, BinanceMarketData]:
        """Fetch market snapshots for all supported coins (best-effort)."""
        await self._ensure_markets()
        tasks = [self.get_market_data(c) for c in self._supported_coins]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        out: dict[str, BinanceMarketData] = {}
        for coin, result in zip(self._supported_coins, results, strict=False):
            if isinstance(result, BinanceMarketData):
                out[coin] = result
            else:
                logger.warning("Failed to get data for %s: %s", coin, result)
        return out

    async def get_order_book(self, coin: str, limit: int = 10) -> dict[str, Any] | None:
        """Fetch top-of-book depth (bids/asks)."""
        try:
            await self._ensure_markets()
            c = coin.upper()
            pair = self._pairs.get(c)
            if not pair:
                return None

            book = await asyncio.to_thread(self._client.fetch_order_book, pair, limit)
            ts = float(book.get("timestamp") / 1000.0) if book.get("timestamp") else time.time()
            return {
                "symbol": c,
                "bids": (book.get("bids") or [])[:limit],
                "asks": (book.get("asks") or [])[:limit],
                "timestamp": ts,
                "timestamp_iso": _iso_utc(ts),
                "exchange": EXCHANGE_ID,
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error getting order book for %s: %s", coin, str(e))
            return None

    async def get_recent_trades(self, coin: str, limit: int = 50) -> list[dict[str, Any]] | None:
        """Fetch recent public trades for a coin/pair."""
        try:
            await self._ensure_markets()
            c = coin.upper()
            pair = self._pairs.get(c)
            if not pair:
                return None

            trades = await asyncio.to_thread(self._client.fetch_trades, pair, None, limit)

            out: list[dict[str, Any]] = []
            for t in trades or []:
                ts = float(t.get("timestamp") / 1000.0) if t.get("timestamp") else time.time()
                out.append(
                    {
                        "symbol": c,
                        "price": float(t.get("price") or 0.0),
                        "quantity": float(t.get("amount") or 0.0),
                        "side": str(t.get("side") or ""),
                        "timestamp": ts,
                        "timestamp_iso": _iso_utc(ts),
                        "exchange": EXCHANGE_ID,
                    },
                )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error getting recent trades for %s: %s", coin, str(e))
            return None
        else:
            return out

    # --------- diagnostics ---------

    def get_statistics(self) -> dict[str, Any]:
        """Return basic diagnostics; purely synchronous introspection."""
        try:
            return {
                "supported_coins": len(self._supported_coins),
                "pairs": len(self._pairs),
                "markets_loaded": bool(self._markets_loaded),
                "client_available": self._client is not None,
                "exchange": EXCHANGE_ID,
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error building statistics: %s", str(e))
            return {
                "supported_coins": 0,
                "pairs": 0,
                "markets_loaded": False,
                "client_available": False,
                "exchange": EXCHANGE_ID,
                "error": str(e),
            }

    # --------- internals ---------

    async def _ensure_markets(self) -> None:
        """Load markets once (thread offloaded)."""
        if self._markets_loaded:
            return
        try:
            # Skip load_markets for Binance.US as it doesn't support margin endpoints
            # and causes 404 errors on /sapi/v1/margin/allAssets
            logger.debug("Skipping load_markets for Binance.US (margin endpoints not supported)")
            self._markets_loaded = True
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            # Not critical for public ticker endpoints, but helps symbol validation
            logger.debug("load_markets failed (continuing): %s", str(e))
            self._markets_loaded = False


# =========
# Singleton
# =========

# =========
# Singleton - only create if ccxt is available
# =========

if CCXT_AVAILABLE:
    binance_fetcher = BinanceDataFetcher()
else:
    binance_fetcher = None
    logger.warning("WARNING: BinanceDataFetcher not available - ccxt dependency missing")

# Legacy alias (if older code expects a class name)
BinanceData = BinanceDataFetcher

__all__ = [
    "BinanceClientError",
    "BinanceData",
    "BinanceDataError",
    "BinanceDataFetcher",
    "BinanceMarketData",
    "binance_fetcher",
]
