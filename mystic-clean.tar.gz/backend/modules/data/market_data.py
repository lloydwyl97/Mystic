"""
Market Data Manager Module for Mystic Trading Platform

Extracted from data_fetchers.py and cosmic_fetcher.py to improve modularity.
Handles live market data fetching, processing, and caching with standardized error handling.

Rules enforced:
- UTC ISO8601 timestamps (timezone-aware) everywhere
- Deterministic behavior (no randomness)
- Robust error handling with ASCII-safe logging
- No background tasks/threads; explicit async calls only
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import httpx

from backend.utils.exceptions import MarketDataException, handle_async_exception

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID, TOP10_COINS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import EXCHANGE_ID from trading_universe: {e}"
    raise RuntimeError(msg) from e

logger = logging.getLogger(__name__)


def _get_exchange_id() -> str:
    """Get EXCHANGE_ID from trading_universe (live data)"""
    return EXCHANGE_ID


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class MarketData:
    """Market data structure"""

    symbol: str  # canonical base symbol, e.g. "BTC"
    price: float  # last price (USD)
    volume: float  # 24h quote volume (USD when possible)
    change_24h: float  # 24h % change (e.g., -2.34 for -2.34%)
    high_24h: float
    low_24h: float
    timestamp: str  # UTC ISO8601 (timezone-aware)
    exchange: str = field(default_factory=lambda: _get_exchange_id())

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary"""
        return {
            "symbol": self.symbol,
            "price": self.price,
            "volume": self.volume,
            "change_24h": self.change_24h,
            "high_24h": self.high_24h,
            "low_24h": self.low_24h,
            "timestamp": self.timestamp,
            "exchange": self.exchange,
        }


class MarketDataManager:
    """Manages live market data fetching and processing"""

    def __init__(self) -> None:
        self.market_data: dict[str, MarketData] = {}
        self.last_update_epoch: dict[str, float] = {}
        self.update_interval = 30  # seconds (freshness TTL)
        # Use official Top-10 from single source of truth
        self.supported_symbols = TOP10_COINS.copy()
        logger.info("MarketDataManager initialized with official Top-10: %s", self.supported_symbols)

    # ---------------------------
    # Public API
    # ---------------------------

    @handle_async_exception("Failed to get market data for symbol", MarketDataException)
    async def get_market_data(self, symbol: str) -> MarketData | None:
        """Get live market data for a symbol (cached within update_interval)."""
        base = symbol.upper()
        try:
            if self._is_data_fresh(base):
                return self.market_data.get(base)

            data = await self._fetch_live_market_data(base)
            if data:
                self.market_data[base] = data
                self.last_update_epoch[base] = time.time()
                return data
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error getting live market data for %s: %s", base, str(e))
            raise MarketDataException(
                message=f"Failed to get market data for {base}",
                details={"symbol": base, "error": str(e)},
            ) from e
        else:
            return None

    @handle_async_exception("Failed to get all market data", MarketDataException)
    async def get_all_market_data(self) -> dict[str, MarketData]:
        """Get live market data for all supported symbols."""
        tasks = [self.get_market_data(sym) for sym in self.supported_symbols]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        out: dict[str, MarketData] = {}
        for i, res in enumerate(results):
            sym = self.supported_symbols[i]
            if isinstance(res, MarketData):
                out[sym] = res
            elif isinstance(res, Exception):
                logger.warning("Failed to get live data for %s: %s", sym, str(res))
        return out

    @handle_async_exception("Failed to get market summary", MarketDataException)
    async def get_market_summary(self) -> dict[str, Any]:
        """Get live market summary for all symbols."""
        try:
            data = await self.get_all_market_data()
            total_volume = sum(md.volume for md in data.values())
            avg_change = (sum(md.change_24h for md in data.values()) / len(data)) if data else 0.0
            return {
                "symbols": [md.to_dict() for md in data.values()],
                "total_symbols": len(data),
                "total_volume": total_volume,
                "average_change_24h": avg_change,
                "timestamp": _now_iso(),
                "live_data": True,
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error getting live market summary: %s", str(e))
            return {
                "symbols": [],
                "total_symbols": 0,
                "total_volume": 0.0,
                "average_change_24h": 0.0,
                "timestamp": _now_iso(),
                "live_data": False,
                "error": str(e),
            }

    # ---------------------------
    # Internals
    # ---------------------------

    def _is_data_fresh(self, symbol: str) -> bool:
        """Check if market data is fresh for symbol."""
        last = self.last_update_epoch.get(symbol)
        return bool(last and (time.time() - last) < self.update_interval)

    @handle_async_exception("Failed to fetch live market data", MarketDataException)
    async def _fetch_live_market_data(self, symbol: str) -> MarketData | None:
        """Fetch live market data from multiple sources with graceful fallback."""
        sources = (self._fetch_binance_us_24hr,)
        for src in sources:
            try:
                md = await src(symbol)
                if md:
                    logger.debug("Fetched live market data for %s from %s", symbol, src.__name__)
                    return md
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.debug("Source %s failed for %s: %s", src.__name__, symbol, str(e))
                continue
        logger.warning("No live data sources available for %s", symbol)
        return None

    # ---------------------------
    # Source: Binance US (24hr ticker)
    # ---------------------------

    @handle_async_exception("Failed to fetch Binance US live data", MarketDataException)
    async def _fetch_binance_us_24hr(self, symbol: str) -> MarketData | None:
        """
        Fetch from Binance US public REST:
        GET https://api.binance.us/api/v3/ticker/24hr?symbol={BASE}USDT
        """
        pair = f"{symbol}USDT"
        url = f"https://api.binance.us/api/v3/ticker/24hr?symbol={pair}"

        async with httpx.AsyncClient(timeout=httpx.Timeout(6, read=6)) as client:
            r = await client.get(url)
            if r.status_code != 200:
                return None
            t = r.json()

        # Prefer quote volume when present (should be 'quoteVolume' in USDT)
        price = float(t.get("lastPrice", 0.0))
        vol_quote = float(t.get("quoteVolume", 0.0) or 0.0)
        vol_base = float(t.get("volume", 0.0) or 0.0)
        change_pct = float(t.get("priceChangePercent", 0.0) or 0.0)
        high = float(t.get("highPrice", 0.0) or 0.0)
        low = float(t.get("lowPrice", 0.0) or 0.0)

        # If quote volume missing, approximate with base * price
        volume_usd = vol_quote if vol_quote > 0 else vol_base * price

        return MarketData(
            symbol=symbol,
            price=price,
            volume=volume_usd,
            change_24h=change_pct,
            high_24h=high,
            low_24h=low,
            timestamp=_now_iso(),
            exchange=EXCHANGE_ID,
        )

    # ---------------------------
    # Admin / Utilities
    # ---------------------------

    def get_supported_symbols(self) -> list[str]:
        """Get list of supported symbols (copy)."""
        return list(self.supported_symbols)

    def add_symbol(self, symbol: str) -> bool:
        """Add a new symbol to supported list."""
        base = symbol.upper()
        try:
            if base not in self.supported_symbols:
                self.supported_symbols.append(base)
                logger.info("Added symbol: %s", base)
                return True
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error adding symbol %s: %s", base, str(e))
            return False
        else:
            return False

    def remove_symbol(self, symbol: str) -> bool:
        """Remove a symbol from supported list and cache."""
        base = symbol.upper()
        try:
            changed = False
            if base in self.supported_symbols:
                self.supported_symbols.remove(base)
                changed = True
            if base in self.market_data:
                self.market_data.pop(base, None)
                changed = True
            if base in self.last_update_epoch:
                self.last_update_epoch.pop(base, None)
                changed = True
            if changed:
                logger.info("Removed symbol: %s", base)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error removing symbol %s: %s", base, str(e))
            return False
        else:
            return changed

    def get_statistics(self) -> dict[str, Any]:
        """Get market data manager statistics."""
        try:
            return {
                "supported_symbols": len(self.supported_symbols),
                "cached_symbols": len(self.market_data),
                "last_update_epoch": dict(self.last_update_epoch),
                "update_interval_seconds": self.update_interval,
                "live_data": True,
                "timestamp": _now_iso(),
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error getting market data statistics: %s", str(e))
            return {"live_data": False, "error": str(e), "timestamp": _now_iso()}


# Global market data manager instance
market_data_manager = MarketDataManager()
