"""
Binance Data Fetcher - Constants and Utilities
Single source of truth for Binance US exchange configuration
"""

# Import from single source of truth (trading_universe)
try:
    from backend.config.trading_universe import (
        EXCHANGE_ID,
        TOP10_COINS,
    )
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e


def _to_ccxt_symbol(base: str, quote: str = "USDT") -> str:
    """
    Convert base/quote to CCXT format (BASE/QUOTE)

    Args:
        base: Base currency (e.g., "BTC", "ETH")
        quote: Quote currency (default: "USDT")

    Returns:
        CCXT format symbol (e.g., "BTC/USDT")
    """
    if not base:
        return ""

    base_clean = str(base).strip().upper()
    quote_clean = str(quote).strip().upper()

    # If already in CCXT format, return as-is
    if "/" in base_clean:
        return base_clean

    return f"{base_clean}/{quote_clean}"


def _to_binance_symbol(ccxt_symbol: str) -> str:
    """
    Convert CCXT format to Binance format (remove slash)

    Args:
        ccxt_symbol: CCXT format (e.g., "BTC/USDT")

    Returns:
        Binance format (e.g., "BTCUSDT")
    """
    if not ccxt_symbol:
        return ""

    return str(ccxt_symbol).replace("/", "")


# Top 10 trading symbols (BASE only) - Use TOP10_COINS from trading_universe (live data)
TOP10_BASES = list(TOP10_COINS)

# Top 10 in CCXT format (BASE/QUOTE)
TOP10_SYMBOLS_CCXT = [f"{base}/USDT" for base in TOP10_BASES]

# Top 10 in Binance format (BASEQUOTE)
TOP10_SYMBOLS_BINANCE = [f"{base}USDT" for base in TOP10_BASES]
