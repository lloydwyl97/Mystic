"""
Analytics Engine Module - All Live Data, No Fallback/Hardcoded Data

Provides analytics and metrics tracking functionality for live AI operations (backend port 8000).
All operations use live data:
- Event tracking: Tracks live events from AI operations
- Metrics tracking: Stores live metrics from trading operations
- All timestamps use live UTC time
- All data is from live operations - no fallback/hardcoded data

This module re-exports AnalyticsEngine from backend.modules.ai.analytics_engine
to maintain backward compatibility with imports expecting it in the metrics module.
"""

from __future__ import annotations

# Import from the actual location in AI module
from backend.modules.ai.analytics_engine import AnalyticsEngine, AnalyticsEvent

# Re-export for backward compatibility
__all__ = ["AnalyticsEngine", "AnalyticsEvent"]
