"""
Metrics Collector for Mystic Trading Platform

Contains metrics collection logic, extracted from metrics_collector.py.
Handles real-time metrics collection and monitoring.

Rules enforced:
- UTC ISO8601 timestamps (timezone-aware) everywhere
- Deterministic behavior (no randomness)
- Robust error handling with ASCII-safe logging
- No background threads; pure call-and-return API
"""

from __future__ import annotations

import json
import logging
import time
from datetime import datetime, timedelta, timezone
from typing import Any

import psutil

from backend.utils.exceptions import MetricsException

logger = logging.getLogger(__name__)

# Simple usage of imports to avoid unused import errors
_ = json.dumps({"status": "loaded"})


def _now_iso() -> str:
    """UTC ISO8601 string (timezone-aware)."""
    return datetime.now(timezone.utc).isoformat()


def _parse_iso(ts: str) -> datetime:
    """Parse ISO string to aware UTC datetime (best-effort)."""
    try:
        d = datetime.fromisoformat(ts)
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        return datetime.now(timezone.utc)


def _safe_ratio(num: float, den: float) -> float:
    return float(num) / float(den) if den not in (0, 0.0) else 0.0


class MetricsCollector:
    """Metrics collector for system and trading performance monitoring."""

    def __init__(self) -> None:
        self.metrics: dict[str, Any] = {}
        self.metrics_data: dict[str, Any] = {}  # public store for test-compatibility
        self.collection_interval: int = 60  # seconds
        self.last_collection: datetime | None = None
        self.is_active: bool = True
        self.metrics_history: list[dict[str, Any]] = []
        logger.info("MetricsCollector initialized")

    # ---------------------------
    # System / Trading / API
    # ---------------------------

    def collect_system_metrics(self) -> dict[str, Any]:
        """Collect system performance metrics."""
        try:
            # CPU
            cpu_percent = float(psutil.cpu_percent(interval=1))  # blocking 1s sample for stability

            # Memory
            mem = psutil.virtual_memory()
            mem_percent = float(mem.percent)

            # Disk (root mount)
            disk = psutil.disk_usage("/")
            disk_percent = float(disk.percent)

            # Uptime (seconds since boot)
            uptime_seconds = max(0.0, float(time.time() - psutil.boot_time()))

            metrics = {
                "cpu_usage": cpu_percent,  # %
                "memory_usage": mem_percent,  # %
                "disk_usage": disk_percent,  # %
                "uptime": uptime_seconds,  # seconds
                "timestamp": _now_iso(),
            }
            self.metrics["system"] = metrics
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            msg = f"System metrics collection failed: {e}"
            logger.exception(msg)
            return {"error": str(e), "timestamp": _now_iso()}
        else:
            return metrics

    def collect_trading_metrics(self, trading_data: dict[str, Any]) -> dict[str, Any]:
        """Collect trading performance metrics (inputs validated & normalized)."""
        try:
            td = trading_data or {}
            total_trades = int(td.get("total_trades", 0) or 0)
            active_positions = int(td.get("active_positions", 0) or 0)
            total_pnl = float(td.get("total_pnl", 0.0) or 0.0)
            daily_trades = int(td.get("daily_trades", 0) or 0)
            portfolio_value = float(td.get("portfolio_value", 0.0) or 0.0)
            win_rate = float(td.get("win_rate", 0.0) or 0.0)

            risk = td.get("risk_metrics", {}) or {}
            max_drawdown = float(risk.get("max_drawdown", td.get("max_drawdown", 0.0) or 0.0))
            sharpe_ratio = float(risk.get("sharpe_ratio", td.get("sharpe_ratio", 0.0) or 0.0))
            volatility = float(risk.get("volatility", td.get("volatility", 0.0) or 0.0))

            # Clamp common percentage-like values to sane ranges
            if 0.0 <= win_rate <= 1.0:
                pass
            elif 0.0 <= win_rate <= 100.0:
                win_rate = win_rate / 100.0  # accept % as 0-100 and convert to 0-1
            else:
                win_rate = 0.0

            metrics = {
                "timestamp": _now_iso(),
                "total_trades": total_trades,
                "active_positions": active_positions,
                "total_pnl": total_pnl,
                "win_rate": win_rate,  # 0.0 - 1.0
                "daily_trades": daily_trades,
                "portfolio_value": portfolio_value,
                "risk_metrics": {
                    "max_drawdown": max_drawdown,  # 0-1 preferred
                    "sharpe_ratio": sharpe_ratio,
                    "volatility": volatility,
                },
            }
            self.metrics["trading"] = metrics
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            msg = f"Trading metrics collection failed: {e}"
            logger.exception(msg)
            return {"error": str(e), "timestamp": _now_iso()}
        else:
            return metrics

    def collect_api_metrics(self, api_data: dict[str, Any]) -> dict[str, Any]:
        """Collect API performance metrics."""
        try:
            ad = api_data or {}
            total_requests = int(ad.get("total_requests", 0) or 0)
            successful_requests = int(ad.get("successful_requests", 0) or 0)
            failed_requests = int(ad.get("failed_requests", 0) or 0)
            avg_resp = float(ad.get("average_response_time", 0.0) or 0.0)
            rpm = int(ad.get("requests_per_minute", 0) or 0)
            error_rate = ad.get("error_rate", None)

            # Derive error_rate if not present
            if error_rate is None:
                denom = successful_requests + failed_requests
                error_rate = _safe_ratio(failed_requests, denom)

            endpoints = ad.get("endpoints", {}) or {}

            metrics = {
                "timestamp": _now_iso(),
                "total_requests": total_requests,
                "successful_requests": successful_requests,
                "failed_requests": failed_requests,
                "average_response_time": avg_resp,
                "requests_per_minute": rpm,
                "error_rate": float(error_rate),
                "endpoints": endpoints,
            }
            self.metrics["api"] = metrics
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            msg = f"API metrics collection failed: {e}"
            logger.exception(msg)
            return {"error": str(e), "timestamp": _now_iso()}
        else:
            return metrics

    # ---------------------------
    # Trade / Performance / Market / AI
    # ---------------------------

    def collect_trade_metrics(self, trade_data: dict[str, Any]) -> dict[str, Any]:
        """Collect trade-specific metrics (validates required fields)."""
        # Validate required fields before try block to avoid TRY301
        required = ["id", "symbol", "profit"]
        for field in required:
            if field not in trade_data:
                msg = f"Missing required field: {field}"
                raise MetricsException(msg)

        try:
            metrics = {
                "trade_id": str(trade_data["id"]),
                "symbol": str(trade_data["symbol"]),
                "profit": float(trade_data["profit"]),
                "timestamp": _now_iso(),
            }
            # optional fields
            if "action" in trade_data:
                metrics["action"] = str(trade_data["action"])
            if "quantity" in trade_data:
                metrics["quantity"] = float(trade_data["quantity"])
            if "price" in trade_data:
                metrics["price"] = float(trade_data["price"])

            self.metrics["trade"] = metrics
        except MetricsException:
            raise
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            msg = f"Trade metrics collection failed: {e}"
            logger.exception(msg)
            raise MetricsException(msg) from e
        else:
            return metrics

    def collect_performance_metrics(self, trades: list[dict[str, Any]]) -> dict[str, Any]:
        """Collect aggregate performance metrics from trades list."""
        try:
            if not trades:
                out = {
                    "total_trades": 0,
                    "total_profit": 0.0,
                    "win_rate": 0.0,
                    "average_profit": 0.0,
                    "timestamp": _now_iso(),
                }
                self.metrics["performance"] = out
                return out

            total_trades = len(trades)
            profits = [float(t.get("profit", 0.0) or 0.0) for t in trades]
            total_profit = float(sum(profits))
            wins = sum(1 for p in profits if p > 0.0)
            win_rate = _safe_ratio(wins, total_trades)
            average_profit = _safe_ratio(total_profit, total_trades)

            out = {
                "total_trades": total_trades,
                "total_profit": total_profit,
                "win_rate": win_rate,
                "average_profit": average_profit,
                "timestamp": _now_iso(),
            }
            self.metrics["performance"] = out
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            msg = f"Performance metrics collection failed: {e}"
            logger.exception(msg)
            return {"error": str(e), "timestamp": _now_iso()}
        else:
            return out

    def collect_market_metrics(self, market_data: dict[str, Any]) -> dict[str, Any]:
        """Collect market-related metrics from a symbol->data map."""
        try:
            total_symbols = len(market_data or {})
            if total_symbols == 0:
                out = {
                    "total_symbols": 0,
                    "average_price": 0.0,
                    "total_volume": 0.0,
                    "average_change": 0.0,
                    "timestamp": _now_iso(),
                }
                self.metrics["market"] = out
                return out

            vals = (market_data or {}).values()
            total_volume = float(sum(float(v.get("volume", 0.0) or 0.0) for v in vals))
            total_price = float(sum(float(v.get("price", 0.0) or 0.0) for v in vals))
            average_price = _safe_ratio(total_price, total_symbols)

            changes = [float(v.get("change_24h", 0.0) or 0.0) for v in (market_data or {}).values()]
            average_change = _safe_ratio(sum(changes), len(changes)) if changes else 0.0

            out = {
                "total_symbols": total_symbols,
                "average_price": average_price,
                "total_volume": total_volume,
                "average_change": average_change,
                "timestamp": _now_iso(),
            }
            self.metrics["market"] = out
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            msg = f"Market metrics collection failed: {e}"
            logger.exception(msg)
            return {"error": str(e), "timestamp": _now_iso()}
        else:
            return out

    def collect_ai_metrics(self, ai_data: dict[str, Any]) -> dict[str, Any]:
        """Collect AI-related metrics."""
        try:
            ad = ai_data or {}
            out = {
                "timestamp": _now_iso(),
                "predictions_made": int(ad.get("predictions_made", 0) or 0),
                "accuracy": float(ad.get("accuracy", 0.0) or 0.0),
                "model_version": str(ad.get("model_version", "unknown")),
                "training_time": float(ad.get("training_time", 0.0) or 0.0),
                "inference_time": float(ad.get("inference_time", 0.0) or 0.0),
                "confidence_score": float(ad.get("confidence_score", 0.0) or 0.0),
            }
            self.metrics["ai"] = out
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            msg = f"AI metrics collection failed: {e}"
            logger.exception(msg)
            return {"error": str(e), "timestamp": _now_iso()}
        else:
            return out

    # ---------------------------
    # Storage API
    # ---------------------------

    def store_metrics(self, category: str, metrics: dict[str, Any]) -> bool:
        """Store metrics in a specific category."""
        try:
            self.metrics_data[str(category)] = dict(metrics)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Failed to store metrics: %s", e)
            return False
        else:
            return True

    def get_metrics(self, category: str) -> dict[str, Any]:
        """Get metrics for a specific category."""
        return dict(self.metrics_data.get(str(category), {}))

    def get_all_metrics(self) -> dict[str, Any]:
        """Get all stored metrics."""
        return dict(self.metrics_data)

    def clear_metrics(self, category: str) -> None:
        """Clear metrics for a specific category."""
        self.metrics_data.pop(str(category), None)

    def clear_all_metrics(self) -> None:
        """Clear all stored metrics."""
        self.metrics_data.clear()

    def import_metrics(self, import_data: dict[str, Any]) -> bool:
        """Import metrics from external data."""
        try:
            if "metrics_data" not in import_data:
                msg = "Invalid import format: missing metrics_data"
                raise MetricsException(msg)
            md = import_data["metrics_data"]
            if not isinstance(md, dict):
                msg = "Invalid import format: metrics_data must be a dict"
                raise MetricsException(msg)
            self.metrics_data.update(md)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Failed to import metrics: %s", e)
            msg = f"Import failed: {e}"
            raise MetricsException(msg) from e
        else:
            return True

    def validate_metrics(self, metrics: Any) -> bool:
        """Validate metrics data shape."""
        return isinstance(metrics, dict)

    # ---------------------------
    # Bulk collection / summaries
    # ---------------------------

    def collect_all_metrics(
        self,
        trading_data: dict[str, Any] | None = None,
        api_data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Collect a snapshot of system, trading, and api metrics."""
        snapshot = {
            "timestamp": _now_iso(),
            "system": self.collect_system_metrics(),
            "trading": self.collect_trading_metrics(trading_data or {}),
            "api": self.collect_api_metrics(api_data or {}),
        }
        self.metrics_history.append(snapshot)
        if len(self.metrics_history) > 1000:
            self.metrics_history = self.metrics_history[-500:]
        self.last_collection = datetime.now(timezone.utc)
        return snapshot

    def get_metrics_summary(self) -> dict[str, Any]:
        """Get a summary of collected metrics (from store)."""
        if not self.metrics_data:
            return {"error": "No metrics collected yet", "timestamp": _now_iso()}

        summary: dict[str, Any] = {
            "total_categories": len(self.metrics_data),
            "last_updated": _now_iso(),
            "key_metrics": {},
            "categories": list(self.metrics_data.keys()),
        }
        for category, data in self.metrics_data.items():
            if isinstance(data, dict):
                summary["key_metrics"][category] = {
                    "count": len(data),
                    "has_numeric": any(isinstance(v, (int, float)) for v in data.values()),
                }
        return summary

    def get_metrics_history(self, hours: int = 24) -> list[dict[str, Any]]:
        """Get metrics history within the last N hours."""
        if not self.metrics_history:
            return []
        cutoff = datetime.now(timezone.utc) - timedelta(hours=max(0, int(hours)))
        out: list[dict[str, Any]] = []
        for m in self.metrics_history:
            ts = _parse_iso(m.get("timestamp", _now_iso()))
            if ts > cutoff:
                out.append(m)
        return out

    def get_metrics_trends(self, metric_type: str, metric_name: str, hours: int = 24) -> dict[str, Any]:
        """Get trends for a specific metric across history."""
        history = self.get_metrics_history(hours)
        if not history:
            return {"error": "No metrics history available", "timestamp": _now_iso()}

        values: list[float] = []
        timestamps: list[str] = []

        for snap in history:
            mt = snap.get(metric_type)
            if isinstance(mt, dict) and metric_name in mt:
                try:
                    values.append(float(mt[metric_name]))
                    timestamps.append(snap.get("timestamp", _now_iso()))
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    continue

        if not values:
            return {
                "error": f"Metric {metric_name} not found in {metric_type}",
                "timestamp": _now_iso(),
            }

        if len(values) > 1:
            trend = "increasing" if values[-1] > values[0] else "decreasing" if values[-1] < values[0] else "stable"
            change_percent = _safe_ratio(values[-1] - values[0], values[0]) * 100.0 if values[0] != 0 else 0.0
        else:
            trend = "stable"
            change_percent = 0.0

        return {
            "metric_type": metric_type,
            "metric_name": metric_name,
            "current_value": values[-1],
            "average_value": sum(values) / len(values),
            "min_value": min(values),
            "max_value": max(values),
            "trend": trend,
            "change_percent": round(change_percent, 2),
            "data_points": len(values),
            "timestamps": timestamps,
            "values": values,
            "timestamp": _now_iso(),
        }

    # ---------------------------
    # Control & Housekeeping
    # ---------------------------

    def set_collection_interval(self, interval_seconds: int) -> dict[str, Any]:
        """Set the metrics collection interval."""
        if interval_seconds < 10:
            return {"error": "Collection interval must be at least 10 seconds"}
        self.collection_interval = int(interval_seconds)
        logger.info("Metrics collection interval set to %s seconds", interval_seconds)
        return {"success": True, "interval": self.collection_interval}

    def start_collection(self) -> dict[str, Any]:
        """Start metrics collection (flag only)."""
        self.is_active = True
        logger.info("Metrics collection started")
        return {"success": True, "status": "started", "timestamp": _now_iso()}

    def stop_collection(self) -> dict[str, Any]:
        """Stop metrics collection (flag only)."""
        self.is_active = False
        logger.info("Metrics collection stopped")
        return {"success": True, "status": "stopped", "timestamp": _now_iso()}

    def clear_metrics_history(self) -> dict[str, Any]:
        """Clear metrics history."""
        n = len(self.metrics_history)
        self.metrics_history.clear()
        logger.info("Cleared %s metrics history entries", n)
        return {"success": True, "cleared_count": n, "timestamp": _now_iso()}

    def export_metrics(self, format_type: str = "json") -> dict[str, Any]:
        """Export metrics in specified format (JSON only for now)."""
        try:
            return {
                "metrics_data": self.metrics_data,
                "export_timestamp": _now_iso(),
                "version": "1.0",
                "format": format_type,
                "success": True,
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Failed to export metrics: %s", e)
            return {"error": str(e), "success": False, "timestamp": _now_iso()}

    def get_health_status(self) -> dict[str, Any]:
        """Get health status of metrics collection."""
        if not self.last_collection:
            return {
                "status": "not_started",
                "message": "No metrics collected yet",
                "is_active": self.is_active,
            }

        delta = datetime.now(timezone.utc) - self.last_collection
        if delta > timedelta(minutes=5):
            status = "stale"
            message = f"Last collection was {delta.total_seconds():.0f} seconds ago"
        elif delta > timedelta(minutes=1):
            status = "warning"
            message = f"Last collection was {delta.total_seconds():.0f} seconds ago"
        else:
            status = "healthy"
            message = "Metrics collection is working normally"

        return {
            "status": status,
            "message": message,
            "is_active": self.is_active,
            "last_collection": self.last_collection.isoformat(),
            "collection_interval": self.collection_interval,
            "timestamp": _now_iso(),
        }
