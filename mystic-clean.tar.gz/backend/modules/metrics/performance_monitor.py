"""
Performance Monitor for Mystic Trading Platform

Contains performance monitoring logic for real-time system monitoring.
Handles performance metrics, alerts, and optimization.

Rules enforced:
- UTC ISO8601 timestamps (timezone-aware)
- Deterministic behavior (no randomness)
- No background threads or hidden loops; caller drives collection explicitly
- Robust, ASCII-safe logging; graceful fallbacks when optional deps missing
"""

from __future__ import annotations

import contextlib
import logging
import time
from collections import defaultdict, deque
from collections.abc import Callable
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _pct(sorted_vals: list[float], q: float) -> float:
    """Compute quantile q in [0,1] from a sorted list. Returns 0.0 for empty."""
    if not sorted_vals:
        return 0.0
    if q <= 0:
        return sorted_vals[0]
    if q >= 1:
        return sorted_vals[-1]
    pos = q * (len(sorted_vals) - 1)
    lo = int(pos)
    hi = min(lo + 1, len(sorted_vals) - 1)
    frac = pos - lo
    return sorted_vals[lo] * (1.0 - frac) + sorted_vals[hi] * frac


@dataclass
class Gauge:
    value: float = 0.0
    updated_at: str = field(default_factory=_now_iso)


@dataclass
class Counter:
    count: int = 0
    updated_at: str = field(default_factory=_now_iso)


@dataclass
class TimerSeries:
    """Holds recent timings and can summarize percentiles quickly."""

    window: int = 2000
    values: deque[float] = field(default_factory=deque)  # seconds
    last_updated: str = field(default_factory=_now_iso)

    def add(self, seconds: float) -> None:
        if self.window <= 0:
            return
        self.values.append(seconds)
        while len(self.values) > self.window:
            self.values.popleft()
        self.last_updated = _now_iso()

    def summary(self) -> dict[str, float]:
        arr = list(self.values)
        arr.sort()
        total = sum(arr) if arr else 0.0
        avg = (total / len(arr)) if arr else 0.0
        return {
            "count": float(len(arr)),
            "avg": avg,
            "p50": _pct(arr, 0.50),
            "p90": _pct(arr, 0.90),
            "p95": _pct(arr, 0.95),
            "p99": _pct(arr, 0.99),
            "min": arr[0] if arr else 0.0,
            "max": arr[-1] if arr else 0.0,
            "sum": total,
        }


@dataclass
class MovingAverage:
    """Simple EMA for lightweight smooth metrics."""

    alpha: float = 0.2
    value: float | None = None
    updated_at: str = field(default_factory=_now_iso)

    def push(self, x: float) -> float:
        if self.value is None:
            self.value = x
        else:
            self.value = self.alpha * x + (1.0 - self.alpha) * self.value
        self.updated_at = _now_iso()
        return self.value


@dataclass
class Threshold:
    """Threshold definition for alerting."""

    metric: str  # e.g., "api:/orders POST.latency_ms.p95"
    operator: str  # ">", ">=", "<", "<=", "==", "!="
    value: float  # threshold to compare against
    severity: str = "warning"  # "info" | "warning" | "error" | "critical"
    window: int = 60  # observation hint in seconds (informational)
    enabled: bool = True
    created_at: str = field(default_factory=_now_iso)

    def check(self, current: float) -> bool:
        ops = {
            ">": lambda a, b: a > b,
            ">=": lambda a, b: a >= b,
            "<": lambda a, b: a < b,
            "<=": lambda a, b: a <= b,
            "==": lambda a, b: a == b,
            "!=": lambda a, b: a != b,
        }
        fn = ops.get(self.operator)
        if fn is None:
            return False
        return fn(current, self.value)


@dataclass
class AlertEvent:
    metric: str
    observed: float
    threshold: Threshold
    timestamp: str = field(default_factory=_now_iso)
    message: str = ""


class PerformanceMonitor:
    """
    Centralized, pull-driven performance monitor.

    - Gauges (set/get)
    - Counters (increment)
    - Timers (record durations, summarize percentiles)
    - EMA metrics (push values to smooth)
    - Threshold-based alerts via optional callback (no background threads)
    """

    def __init__(
        self,
        timer_window: int = 2000,
        alert_callback: Callable[[AlertEvent], None] | None = None,
    ) -> None:
        self._gauges: dict[str, Gauge] = {}
        self._counters: dict[str, Counter] = {}
        self._timers: dict[str, TimerSeries] = defaultdict(lambda: TimerSeries(window=timer_window))
        self._emas: dict[str, MovingAverage] = {}
        self._thresholds: dict[str, Threshold] = {}
        self._alerts: list[AlertEvent] = []
        self._alert_callback = alert_callback

        self._started_at: str | None = None
        self._stopped_at: str | None = None
        self._last_tick: str | None = None

        logger.info("PerformanceMonitor initialized")

    # --------------------------
    # Lifecycle
    # --------------------------

    def start(self) -> dict[str, Any]:
        self._started_at = _now_iso()
        self._stopped_at = None
        logger.info("Performance monitoring started")
        return {"success": True, "started_at": self._started_at}

    def stop(self) -> dict[str, Any]:
        self._stopped_at = _now_iso()
        logger.info("Performance monitoring stopped")
        return {"success": True, "stopped_at": self._stopped_at}

    def tick(self) -> None:
        """A lightweight heartbeat the host can call to mark progress."""
        self._last_tick = _now_iso()

    # --------------------------
    # Gauges / Counters / EMA
    # --------------------------

    def set_gauge(self, name: str, value: float) -> None:
        self._gauges[name] = Gauge(value=float(value))
        logger.debug("Gauge set: %s=%.6f", name, float(value))

    def get_gauge(self, name: str) -> float:
        g = self._gauges.get(name)
        return g.value if g else 0.0

    def inc(self, name: str, by: int = 1) -> int:
        ref = self._counters.get(name)
        if ref is None:
            ref = Counter()
            self._counters[name] = ref
        ref.count += int(by)
        ref.updated_at = _now_iso()
        logger.debug("Counter inc: %s by %d -> %d", name, by, ref.count)
        return ref.count

    def get_count(self, name: str) -> int:
        c = self._counters.get(name)
        return c.count if c else 0

    def push_ema(self, name: str, x: float, alpha: float = 0.2) -> float:
        ref = self._emas.get(name)
        if ref is None or abs(ref.alpha - alpha) > 1e-9:
            ref = MovingAverage(alpha=alpha)
            self._emas[name] = ref
        val = ref.push(float(x))
        logger.debug(
            "EMA push: %s x=%.6f -> %.6f",
            name,
            float(x),
            val if val is not None else 0.0,
        )
        return float(val if val is not None else 0.0)

    def get_ema(self, name: str) -> float:
        ref = self._emas.get(name)
        return float(ref.value) if ref and ref.value is not None else 0.0

    # --------------------------
    # Timers
    # --------------------------

    @contextlib.contextmanager
    def time_block(self, timer_name: str):
        """Context manager to time synchronous blocks."""
        t0 = time.perf_counter()
        try:
            yield
        finally:
            dt = time.perf_counter() - t0
            self.observe_seconds(timer_name, dt)

    async def time_async(self, timer_name: str, coro):
        """Await and time an async coroutine, returning its result."""
        t0 = time.perf_counter()
        try:
            return await coro
        finally:
            dt = time.perf_counter() - t0
            self.observe_seconds(timer_name, dt)

    def observe_ms(self, timer_name: str, milliseconds: float) -> None:
        self.observe_seconds(timer_name, milliseconds / 1000.0)

    def observe_seconds(self, timer_name: str, seconds: float) -> None:
        self._timers[timer_name].add(float(seconds))
        logger.debug("Timer observe: %s=%.6fs", timer_name, float(seconds))

    def timer_summary(self, timer_name: str) -> dict[str, float]:
        return self._timers[timer_name].summary()

    # --------------------------
    # Thresholds / Alerts
    # --------------------------

    def set_threshold(
        self,
        key: str,
        metric: str,
        operator: str,
        value: float,
        severity: str = "warning",
        window: int = 60,
        enabled: bool = True,
    ) -> Threshold:
        th = Threshold(
            metric=metric,
            operator=operator,
            value=float(value),
            severity=severity,
            window=window,
            enabled=enabled,
        )
        self._thresholds[key] = th
        logger.info("Threshold set: %s -> %s %s %.6f", key, metric, operator, float(value))
        return th

    def remove_threshold(self, key: str) -> bool:
        return self._thresholds.pop(key, None) is not None

    def list_thresholds(self) -> dict[str, dict[str, Any]]:
        return {k: asdict(v) for k, v in self._thresholds.items()}

    def evaluate_thresholds(self) -> list[AlertEvent]:
        """
        Evaluate all thresholds against current metrics.

        Metric lookup supports:
          - gauge:<name>
          - counter:<name>
          - timer:<name>.<field> where field in {avg,p50,p90,p95,p99,min,max,sum,count}
          - ema:<name>
        """
        alerts: list[AlertEvent] = []
        for key, th in self._thresholds.items():
            if not th.enabled:
                continue
            current = self._resolve_metric_value(th.metric)
            if current is None:
                continue
            if th.check(current):
                evt = AlertEvent(
                    metric=th.metric,
                    observed=current,
                    threshold=th,
                    message=f"Threshold '{key}' violated: {th.metric} {th.operator} {th.value} (observed {current})",
                )
                self._alerts.append(evt)
                alerts.append(evt)
                logger.warning(evt.message)
                if self._alert_callback:
                    with contextlib.suppress(Exception):
                        self._alert_callback(evt)
        return alerts

    def _resolve_metric_value(self, metric: str) -> float | None:
        try:
            if metric.startswith("gauge:"):
                name = metric.split(":", 1)[1]
                return self.get_gauge(name)
            if metric.startswith("counter:"):
                name = metric.split(":", 1)[1]
                return float(self.get_count(name))
            if metric.startswith("ema:"):
                name = metric.split(":", 1)[1]
                return self.get_ema(name)
            if metric.startswith("timer:"):
                spec = metric.split(":", 1)[1]
                timer, _, field = spec.partition(".")
                summ = self.timer_summary(timer)
                return float(summ.get(field, 0.0))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.debug("Metric resolve failed for %s: %s", metric, str(e))
        return None

    def get_alerts(self, limit: int = 100) -> list[dict[str, Any]]:
        return [asdict(a) for a in self._alerts[-limit:]]

    def clear_alerts(self) -> int:
        n = len(self._alerts)
        self._alerts.clear()
        return n

    # --------------------------
    # Summaries / Export
    # --------------------------

    def get_summary(self) -> dict[str, Any]:
        timers = {name: ts.summary() for name, ts in self._timers.items()}
        return {
            "timestamp": _now_iso(),
            "started_at": self._started_at,
            "stopped_at": self._stopped_at,
            "last_tick": self._last_tick,
            "gauges": {k: asdict(v) for k, v in self._gauges.items()},
            "counters": {k: asdict(v) for k, v in self._counters.items()},
            "timers": timers,
            "emas": {
                k: {
                    "value": (v.value if v.value is not None else 0.0),
                    "alpha": v.alpha,
                    "updated_at": v.updated_at,
                }
                for k, v in self._emas.items()
            },
            "thresholds": self.list_thresholds(),
            "alerts_count": len(self._alerts),
        }

    def export_state(self) -> dict[str, Any]:
        """Export current state for persistence/testing."""
        return {
            "timestamp": _now_iso(),
            "gauges": {k: asdict(v) for k, v in self._gauges.items()},
            "counters": {k: asdict(v) for k, v in self._counters.items()},
            "timers": {k: list(v.values) for k, v in self._timers.items()},
            "emas": {k: {"value": v.value, "alpha": v.alpha, "updated_at": v.updated_at} for k, v in self._emas.items()},
            "thresholds": self.list_thresholds(),
            "alerts": [asdict(a) for a in self._alerts],
            "started_at": self._started_at,
            "stopped_at": self._stopped_at,
            "last_tick": self._last_tick,
        }

    def import_state(self, data: dict[str, Any]) -> bool:
        """Import a previously exported state (best-effort)."""
        try:
            self._gauges = {k: Gauge(**v) for k, v in (data.get("gauges") or {}).items()}
            self._counters = {k: Counter(**v) for k, v in (data.get("counters") or {}).items()}

            self._timers.clear()
            for name, vals in (data.get("timers") or {}).items():
                series = TimerSeries()
                for sec in vals or []:
                    series.add(float(sec))
                self._timers[name] = series

            self._emas = {}
            for k, v in (data.get("emas") or {}).items():
                ma = MovingAverage(alpha=float(v.get("alpha", 0.2)))
                val = v.get("value", None)
                if val is not None:
                    ma.value = float(val)
                ma.updated_at = v.get("updated_at", _now_iso())
                self._emas[k] = ma

            self._thresholds = {k: Threshold(**t) for k, t in (data.get("thresholds") or {}).items()}
            self._alerts = [AlertEvent(**a) for a in (data.get("alerts") or [])]

            self._started_at = data.get("started_at")
            self._stopped_at = data.get("stopped_at")
            self._last_tick = data.get("last_tick")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Failed to import performance state: %s", str(e))
            return False
        else:
            return True

    # --------------------------
    # Convenience helpers
    # --------------------------

    def observe_http(
        self,
        method: str,
        path: str,
        latency_seconds: float,
        status_code: int,
        weight_cost: int = 1,
    ) -> None:
        """Record a lightweight set of HTTP metrics."""
        m = method.upper()
        key_base = f"http:{m}:{path}"
        self.observe_seconds(f"{key_base}.latency", latency_seconds)
        self.inc(f"{key_base}.count", 1)
        self.inc("http:requests_total", 1)
        self.inc(f"http:status:{status_code}", 1)
        self.inc("http:weight_cost", int(weight_cost))

    def apdex(self, timer_name: str, t_seconds: float) -> float:
        """
        Compute a simple Apdex score for a timer using last window:
        satisfied: dt <= T, tolerating: T < dt <= 4T, frustrated: dt > 4T
        """
        vals = list(self._timers[timer_name].values)
        if not vals or t_seconds <= 0:
            return 0.0
        sat = tol = fru = 0
        T = t_seconds
        for dt in vals:
            if dt <= T:
                sat += 1
            elif dt <= 4 * T:
                tol += 1
            else:
                fru += 1
        total = len(vals)
        return ((sat + 0.5 * tol) / total) if total else 0.0


# Global instance (optional)
performance_monitor = PerformanceMonitor()
