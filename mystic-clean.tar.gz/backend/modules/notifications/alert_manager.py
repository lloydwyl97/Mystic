"""
Alert Manager for Mystic Trading Platform

Contains alert management logic for real-time trading alerts.
Handles alert generation, delivery, and management.

Rules enforced:
- Single exchange ID constant: EXCHANGE_ID = "binance_us"
- One symbol-normalization helper: _to_ccxt_symbol()
- All symbols normalized to CCXT BASE/QUOTE form (e.g., "ETH/USDT")
- ASCII-only logging (Windows-safe)
- Deterministic behavior (no randomness)

This manager does not send alerts itself; it tracks, validates, triggers,
and provides summaries for upstream notification senders.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from typing import Any

from backend.utils.exceptions import NotificationException

logger = logging.getLogger(__name__)

# Prevent unused-import lint issues
_ = json.dumps({"status": "loaded"})

# =========================
# Exchange constant & symbol helper
# =========================

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e


def _to_ccxt_symbol(s: str) -> str:
    """
    Normalize to CCXT BASE/QUOTE with '/' delimiter, uppercase.
    Examples:
      "eth-usdt" -> "ETH/USDT"
      "eth_usdt" -> "ETH/USDT"
      "ETHUSDT"  -> "ETH/USDT" (best-effort for common quotes)
      "xrp/usdt" -> "XRP/USDT"
    """
    u = (s or "").strip().upper()
    if not u:
        return u

    # Already has slash: normalize both sides
    if "/" in u:
        base, _, quote = u.partition("/")
        base = base.replace("-", "").replace("_", "")
        quote = quote.replace("-", "").replace("_", "")
        return f"{base}/{quote}"

    # Replace common separators to slash
    candidate = u.replace("-", "/").replace("_", "/")
    if "/" in candidate:
        base, _, quote = candidate.partition("/")
        return f"{base}/{quote}"

    # Compact form best-effort split by known quotes
    KNOWN_QUOTES = ("USDT", "USD", "USDC", "BUSD", "BTC", "ETH")
    for q in KNOWN_QUOTES:
        if candidate.endswith(q) and len(candidate) > len(q):
            base = candidate[: -len(q)]
            return f"{base}/{q}"

    return candidate


class AlertManager:
    """Alert manager for trading notifications and alerts."""

    def __init__(self) -> None:
        self.alerts: dict[str, dict[str, Any]] = {}
        self.alert_history: list[dict[str, Any]] = []
        self.alert_types: dict[str, dict[str, Any]] = {
            "price_alert": {
                "description": "Price-based alerts",
                "fields": ["symbol", "condition", "threshold"],
            },
            "volume_alert": {
                "description": "Volume-based alerts",
                "fields": ["symbol", "condition", "threshold"],
            },
            "system_alert": {
                "description": "System alerts",
                "fields": ["message"],
            },
            "trade_alert": {
                "description": "Trade alerts",
                "fields": ["symbol", "action", "quantity"],
            },
        }
        self.is_active: bool = True
        self.notification_channels: list[str] = ["email", "webhook", "database"]
        self.exchange: str = EXCHANGE_ID
        logger.info("AlertManager initialized (exchange=%s)", EXCHANGE_ID)

    # -----------------------
    # Create / Read / Update / Delete
    # -----------------------

    def create_alert(
        self,
        alert_type: str,
        symbol: str | None = None,
        condition: str | None = None,
        threshold: float | None = None,
        message: str | None = None,
        expires_at: Any = None,  # ISO string or datetime or None
        action: str | None = None,  # for trade_alert
        quantity: float | None = None,  # for trade_alert
    ) -> dict[str, Any]:
        """Create a new alert with field validation and normalized symbol."""
        if alert_type not in self.alert_types:
            msg = f"Invalid alert type: {alert_type}"
            raise NotificationException(msg)

        # Validate required fields for the alert type
        required = self.alert_types[alert_type]["fields"]
        for field in required:
            if field == "symbol":
                if not symbol:
                    msg = "Missing required parameter: symbol"
                    raise NotificationException(msg)
            elif field == "condition":
                if not condition:
                    msg = "Missing required parameter: condition"
                    raise NotificationException(msg)
                if condition not in (">", "<", ">=", "<="):
                    msg = "Invalid condition; use one of: '>', '<', '>=', '<='"
                    raise NotificationException(msg)
            elif field == "threshold":
                if threshold is None:
                    msg = "Missing required parameter: threshold"
                    raise NotificationException(msg)
            elif field == "message":
                if not message:
                    msg = "Missing required parameter: message"
                    raise NotificationException(msg)
            elif field == "action":
                if not action:
                    msg = "Missing required parameter: action"
                    raise NotificationException(msg)
            elif field == "quantity" and quantity is None:
                msg = "Missing required parameter: quantity"
                raise NotificationException(msg)

        # Normalize input for known fields
        norm_symbol = _to_ccxt_symbol(symbol) if symbol else None

        # Parse expires_at to aware datetime if provided
        exp_dt: datetime | None = None
        if isinstance(expires_at, datetime):
            exp_dt = expires_at if expires_at.tzinfo else expires_at.replace(tzinfo=timezone.utc)
        elif isinstance(expires_at, str):
            try:
                parsed = datetime.fromisoformat(expires_at)
                exp_dt = parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                exp_dt = None

        alert_id = f"alert_{len(self.alerts) + 1}_{int(datetime.now(timezone.utc).timestamp() * 1000):013d}"
        now_iso = datetime.now(timezone.utc).isoformat()

        alert: dict[str, Any] = {
            "id": alert_id,
            "type": alert_type,
            "symbol": norm_symbol,
            "condition": condition,
            "threshold": float(threshold) if threshold is not None else None,
            "message": message,
            "action": action,
            "quantity": float(quantity) if quantity is not None else None,
            "active": True,
            "created_at": now_iso,
            "triggered": False,
            "triggered_at": None,
            "exchange": EXCHANGE_ID,
        }
        if exp_dt is not None:
            alert["expires_at"] = exp_dt.isoformat()

        self.alerts[alert_id] = alert
        logger.info(
            "Alert created: id=%s type=%s symbol=%s",
            alert_id,
            alert_type,
            norm_symbol or "-",
        )
        return alert

    def get_alert(self, alert_id: str) -> dict[str, Any] | None:
        """Get alert by ID."""
        return self.alerts.get(alert_id)

    def update_alert(self, alert_id: str, updates: dict[str, Any]) -> bool:
        """Update an alert with field allow-list and normalization."""
        if alert_id not in self.alerts:
            return False

        alert = self.alerts[alert_id]
        valid_fields = {
            "threshold",
            "message",
            "condition",
            "active",
            "symbol",
            "expires_at",
            "action",
            "quantity",
        }

        for field, value in updates.items():
            if field not in valid_fields:
                msg = f"Invalid field: {field}"
                raise NotificationException(msg)
            if field == "symbol" and isinstance(value, str):
                alert["symbol"] = _to_ccxt_symbol(value)
            elif field == "expires_at":
                if isinstance(value, datetime):
                    dt = value if value.tzinfo else value.replace(tzinfo=timezone.utc)
                    alert["expires_at"] = dt.isoformat()
                elif isinstance(value, str):
                    try:
                        parsed = datetime.fromisoformat(value)
                        dt = parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)
                        alert["expires_at"] = dt.isoformat()
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        # ignore invalid date strings
                        continue
                else:
                    continue
            elif field == "condition":
                if value not in (">", "<", ">=", "<="):
                    msg = "Invalid condition; use one of: '>', '<', '>=', '<='"
                    raise NotificationException(msg)
                alert["condition"] = value
            elif field == "threshold" and value is not None:
                alert["threshold"] = float(value)
            elif field == "quantity" and value is not None:
                alert["quantity"] = float(value)
            else:
                alert[field] = value

        logger.info("Alert updated: id=%s", alert_id)
        return True

    def delete_alert(self, alert_id: str) -> bool:
        """Delete an alert."""
        if alert_id in self.alerts:
            self.alert_history.append(self.alerts[alert_id])
            del self.alerts[alert_id]
            logger.info("Alert deleted: id=%s", alert_id)
            return True
        return False

    def list_alerts(self, alert_type: str | None = None, symbol: str | None = None) -> list[str]:
        """List alert IDs with optional filtering."""
        alert_ids = list(self.alerts.keys())
        if alert_type:
            alert_ids = [aid for aid in alert_ids if self.alerts[aid]["type"] == alert_type]
        if symbol:
            sym = _to_ccxt_symbol(symbol)
            alert_ids = [aid for aid in alert_ids if self.alerts[aid]["symbol"] == sym]
        return alert_ids

    def activate_alert(self, alert_id: str) -> bool:
        """Activate an alert."""
        if alert_id in self.alerts:
            self.alerts[alert_id]["active"] = True
            logger.info("Alert activated: id=%s", alert_id)
            return True
        return False

    def deactivate_alert(self, alert_id: str) -> bool:
        """Deactivate an alert."""
        if alert_id in self.alerts:
            self.alerts[alert_id]["active"] = False
            logger.info("Alert deactivated: id=%s", alert_id)
            return True
        return False

    # -----------------------
    # Trigger checks
    # -----------------------

    def check_price_alerts(self, market_data: dict[str, Any]) -> list[dict[str, Any]]:
        """Check price-based alerts against normalized market_data."""
        # Normalize market_data keys to CCXT symbols
        norm_md: dict[str, dict[str, Any]] = {}
        for k, v in (market_data or {}).items():
            norm_md[_to_ccxt_symbol(k)] = v

        triggered_alerts: list[dict[str, Any]] = []
        now_iso = datetime.now(timezone.utc).isoformat()

        for alert_id, alert in self.alerts.items():
            if not alert["active"] or alert["type"] != "price_alert":
                continue

            sym = alert.get("symbol")
            if not sym or sym not in norm_md:
                continue

            # Skip expired
            if self._is_expired(alert):
                continue

            try:
                price = float(norm_md[sym].get("price", 0.0))
                threshold = float(alert["threshold"])
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                continue

            cond = alert.get("condition")
            should_trigger = bool((cond == ">" and price > threshold) or (cond == "<" and price < threshold) or (cond == ">=" and price >= threshold) or (cond == "<=" and price <= threshold))

            if should_trigger and not alert.get("triggered", False):
                alert["triggered"] = True
                alert["triggered_at"] = now_iso
                out = dict(alert)
                out["alert_id"] = alert_id
                triggered_alerts.append(out)

        return triggered_alerts

    def check_volume_alerts(self, market_data: dict[str, Any]) -> list[dict[str, Any]]:
        """Check volume-based alerts against normalized market_data."""
        norm_md: dict[str, dict[str, Any]] = {}
        for k, v in (market_data or {}).items():
            norm_md[_to_ccxt_symbol(k)] = v

        triggered_alerts: list[dict[str, Any]] = []
        now_iso = datetime.now(timezone.utc).isoformat()

        for alert_id, alert in self.alerts.items():
            if not alert["active"] or alert["type"] != "volume_alert":
                continue

            sym = alert.get("symbol")
            if not sym or sym not in norm_md:
                continue

            # Skip expired
            if self._is_expired(alert):
                continue

            try:
                volume = float(norm_md[sym].get("volume", 0.0))
                threshold = float(alert["threshold"])
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                continue

            cond = alert.get("condition")
            should_trigger = bool((cond == ">" and volume > threshold) or (cond == "<" and volume < threshold) or (cond == ">=" and volume >= threshold) or (cond == "<=" and volume <= threshold))

            if should_trigger and not alert.get("triggered", False):
                alert["triggered"] = True
                alert["triggered_at"] = now_iso
                out = dict(alert)
                out["alert_id"] = alert_id
                triggered_alerts.append(out)

        return triggered_alerts

    def check_all_alerts(self, market_data: dict[str, Any]) -> list[dict[str, Any]]:
        """Check all alert types in one pass."""
        triggered_alerts: list[dict[str, Any]] = []
        triggered_alerts.extend(self.check_price_alerts(market_data))
        triggered_alerts.extend(self.check_volume_alerts(market_data))
        return triggered_alerts

    # -----------------------
    # Stats / Maintenance
    # -----------------------

    def get_alert_statistics(self) -> dict[str, Any]:
        """Get summary statistics for alerts."""
        total_alerts = len(self.alerts)
        active_alerts = sum(1 for a in self.alerts.values() if a.get("active"))
        inactive_alerts = total_alerts - active_alerts
        triggered_alerts = sum(1 for a in self.alerts.values() if a.get("triggered"))

        type_counts: dict[str, int] = {}
        for a in self.alerts.values():
            t = a.get("type", "unknown")
            type_counts[t] = type_counts.get(t, 0) + 1

        return {
            "total_alerts": total_alerts,
            "active_alerts": active_alerts,
            "inactive_alerts": inactive_alerts,
            "triggered_alerts": triggered_alerts,
            "alerts_by_type": type_counts,
            "exchange": EXCHANGE_ID,
        }

    def cleanup_expired_alerts(self, days: int = 30) -> int:
        """Remove alerts older than 'days' if no explicit expires_at, or past explicit expiry."""
        now = datetime.now(timezone.utc)
        cutoff_date = now - timedelta(days=days)
        expired: list[str] = []

        for alert_id, alert in list(self.alerts.items()):
            exp_s = alert.get("expires_at")
            if exp_s:
                try:
                    dt = datetime.fromisoformat(exp_s)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    dt = None
                if dt and dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                if dt and dt < now:
                    expired.append(alert_id)
                    continue

            # If no explicit expiry, fall back to created_at cutoff
            try:
                created = datetime.fromisoformat(str(alert.get("created_at")))
                if created.tzinfo is None:
                    created = created.replace(tzinfo=timezone.utc)
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                created = now

            if created < cutoff_date:
                expired.append(alert_id)

        for aid in expired:
            self.alert_history.append(self.alerts[aid])
            del self.alerts[aid]

        logger.info("Expired alerts cleaned: count=%d", len(expired))
        return len(expired)

    # -----------------------
    # Legacy / Convenience
    # -----------------------

    def get_alerts(self, status: str | None = None, alert_type: str | None = None) -> list[dict[str, Any]]:
        """Get alerts with optional filtering (legacy)."""
        filtered = list(self.alerts.values())

        if status == "active":
            filtered = [a for a in filtered if a.get("active")]
        elif status == "triggered":
            filtered = [a for a in filtered if a.get("triggered")]

        if alert_type:
            filtered = [a for a in filtered if a.get("type") == alert_type]

        return filtered

    def acknowledge_alert(self, alert_id: str) -> dict[str, Any]:
        """Acknowledge an alert (legacy)."""
        if alert_id in self.alerts:
            self.alerts[alert_id]["acknowledged"] = True
            self.alerts[alert_id]["acknowledged_at"] = datetime.now(timezone.utc).isoformat()
            logger.info("Alert acknowledged: id=%s", alert_id)
            return {"success": True, "alert": self.alerts[alert_id]}
        return {"success": False, "error": "Alert not found"}

    def resolve_alert(self, alert_id: str, resolution_notes: str = "") -> dict[str, Any]:
        """Resolve an alert (legacy)."""
        if alert_id in self.alerts:
            a = self.alerts[alert_id]
            a["status"] = "resolved"
            a["resolved_at"] = datetime.now(timezone.utc).isoformat()
            a["resolution_notes"] = resolution_notes
            logger.info("Alert resolved: id=%s", alert_id)
            return {"success": True, "alert": a}
        return {"success": False, "error": "Alert not found"}

    def add_alert_rule(self, rule_name: str, rule_config: dict[str, Any]) -> dict[str, Any]:
        """Add a new alert rule (legacy)."""
        rule = {
            "name": rule_name,
            "config": rule_config,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "is_active": True,
        }
        self.alert_rules = getattr(self, "alert_rules", {})
        self.alert_rules[rule_name] = rule
        logger.info("Alert rule added: name=%s", rule_name)
        return {"success": True, "rule": rule}

    def remove_alert_rule(self, rule_name: str) -> dict[str, Any]:
        """Remove an alert rule (legacy)."""
        self.alert_rules = getattr(self, "alert_rules", {})
        if rule_name in self.alert_rules:
            del self.alert_rules[rule_name]
            logger.info("Alert rule removed: name=%s", rule_name)
            return {"success": True}
        return {"success": False, "error": "Rule not found"}

    def check_alert_conditions(self, market_data: dict[str, Any]) -> list[dict[str, Any]]:
        """Legacy aggregation wrapper -> delegates to check_all_alerts."""
        return self.check_all_alerts(market_data)

    def clear_old_alerts(self, days: int = 30) -> dict[str, Any]:
        """Clear alerts older than specified days (legacy)."""
        cleared = self.cleanup_expired_alerts(days)
        return {
            "success": True,
            "cleared_count": cleared,
            "remaining_count": len(self.alerts),
        }

    def export_alerts(self, format_type: str = "json") -> dict[str, Any]:
        """Export alerts (legacy)."""
        if format_type == "json":
            return {
                "success": True,
                "data": list(self.alerts.values()),
                "export_timestamp": datetime.now(timezone.utc).isoformat(),
            }
        return {"success": False, "error": "Unsupported format"}

    def import_alerts(self, alerts_data: list[dict[str, Any]]) -> dict[str, Any]:
        """Import alerts (legacy)."""
        imported = 0
        for a in alerts_data or []:
            try:
                aid = a.get("id") or f"imported_{imported}_{int(datetime.now(timezone.utc).timestamp() * 1000):013d}"
                # Normalize symbol if present
                if isinstance(a.get("symbol"), str):
                    a["symbol"] = _to_ccxt_symbol(a["symbol"])
                self.alerts[aid] = a
                imported += 1
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception("Failed to import alert: %s", e)
        return {
            "success": True,
            "imported_count": imported,
            "total_alerts": len(self.alerts),
        }

    def get_alert_by_id(self, alert_id: str) -> dict[str, Any] | None:
        """Get alert by ID (legacy alias)."""
        return self.get_alert(alert_id)

    # -----------------------
    # Internal helpers
    # -----------------------

    def _is_expired(self, alert: dict[str, Any]) -> bool:
        """Return True if alert has an expires_at in the past."""
        exp_s = alert.get("expires_at")
        if not exp_s:
            return False
        try:
            dt = datetime.fromisoformat(exp_s)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt < datetime.now(timezone.utc)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            return False
