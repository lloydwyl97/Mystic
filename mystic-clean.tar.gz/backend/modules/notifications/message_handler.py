"""
Message Handler for Mystic Trading Platform

Contains message handling logic for notifications and alerts.
Handles message formatting, routing, and delivery.

Rules enforced:
- UTC ISO timestamps everywhere (string form)
- ASCII-safe logging
- Deterministic behavior (no randomness)
- Safe channel dispatch (timeouts, simple validation)
- Single ID format for messages & deliveries
"""

from __future__ import annotations

import json
import logging
import smtplib
from datetime import datetime, timedelta, timezone
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Any

import httpx

from backend.utils.exceptions import NotificationException

logger = logging.getLogger(__name__)

# Prevent unused-import lint issues
_ = json.dumps({"status": "loaded"})


def _now_iso() -> str:
    """UTC ISO8601 timestamp (always timezone-aware) with Z suffix."""
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _parse_iso(dt: str) -> datetime:
    """Parse an ISO timestamp to aware UTC datetime (best-effort)."""
    try:
        d = datetime.fromisoformat(dt)
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        return datetime.now(timezone.utc)


class MessageHandler:
    """Message handler for notifications and alerts delivery."""

    def __init__(self) -> None:
        self.channels: dict[str, dict[str, Any]] = {}
        self.message_templates: dict[str, str] = {}
        self.delivery_history: list[dict[str, Any]] = []
        self.messages: dict[str, dict[str, Any]] = {}
        self.message_queue: list[str] = []
        self.message_types: dict[str, dict[str, Any]] = {
            "notification": {"fields": ["title", "content", "recipient"]},
            "alert": {"fields": ["title", "content", "recipient"]},
            "trade": {"fields": ["title", "content", "recipient"]},
            "system": {"fields": ["title", "content", "recipient"]},
            "trade_notification": {"fields": ["title", "content", "recipient"]},
            "system_notification": {"fields": ["title", "content", "recipient"]},
        }
        self.is_active: bool = True
        logger.info("MessageHandler initialized")

    # -----------------------
    # Channels & Templates
    # -----------------------

    def add_channel(self, channel_name: str, config: dict[str, Any]) -> dict[str, Any]:
        """Add a new message delivery channel."""
        channel = {
            "name": channel_name,
            "config": config or {},
            "is_active": True,
            "created_at": _now_iso(),
        }
        self.channels[channel_name] = channel
        logger.info("Channel added: %s", channel_name)
        return {"success": True, "channel": channel}

    def remove_channel(self, channel_name: str) -> dict[str, Any]:
        """Remove a message delivery channel."""
        if channel_name in self.channels:
            del self.channels[channel_name]
            logger.info("Channel removed: %s", channel_name)
            return {"success": True}
        return {"success": False, "error": "Channel not found"}

    def add_template(self, template_name: str, template_content: str) -> dict[str, Any]:
        """Add a message template."""
        self.message_templates[template_name] = template_content
        logger.info("Template added: %s", template_name)
        return {"success": True, "template": template_name}

    def remove_template(self, template_name: str) -> dict[str, Any]:
        """Remove a message template."""
        if template_name in self.message_templates:
            del self.message_templates[template_name]
            logger.info("Template removed: %s", template_name)
            return {"success": True}
        return {"success": False, "error": "Template not found"}

    # -----------------------
    # High-level send APIs
    # -----------------------

    def send_message(
        self,
        message_type: str,
        content: dict[str, Any],
        channels: list[str] | None = None,
    ) -> dict[str, Any]:
        """Send a message through specified channels."""
        if not self.is_active:
            return {"error": "Message handler is not active"}

        if not channels:
            channels = list(self.channels.keys())

        results: dict[str, Any] = {}
        successful_deliveries = 0

        for channel_name in channels:
            if channel_name not in self.channels:
                results[channel_name] = {"error": "Channel not found"}
                continue

            channel = self.channels[channel_name]
            if not channel.get("is_active", True):
                results[channel_name] = {"error": "Channel is not active"}
                continue

            try:
                result = self._send_to_channel(channel_name, message_type, content)
                results[channel_name] = result
                if result.get("success"):
                    successful_deliveries += 1
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception("Send to channel failed (%s): %s", channel_name, e)
                results[channel_name] = {"error": str(e)}

        delivery_id = f"delivery_{int(datetime.now(timezone.utc).timestamp() * 1000):013d}"
        delivery_record = {
            "delivery_id": delivery_id,
            "timestamp": _now_iso(),
            "message_type": message_type,
            "content": content,
            "channels": channels,
            "results": results,
            "successful_deliveries": successful_deliveries,
            "total_channels": len(channels),
        }
        self.delivery_history.append(delivery_record)
        if len(self.delivery_history) > 1000:
            self.delivery_history = self.delivery_history[-500:]

        return {
            "success": successful_deliveries > 0,
            "successful_deliveries": successful_deliveries,
            "total_channels": len(channels),
            "delivery_id": delivery_id,
            "results": results,
        }

    def send_notification(
        self,
        title: str,
        content: str,
        recipient: str,
        priority: str | None = None,
    ) -> dict[str, Any]:
        return self.create_message(
            message_type="notification",
            title=title,
            content=content,
            recipient=recipient,
            priority=priority,
        )

    def send_alert(
        self,
        title: str,
        content: str,
        recipient: str,
        priority: str | None = None,
    ) -> dict[str, Any]:
        return self.create_message(
            message_type="alert",
            title=title,
            content=content,
            recipient=recipient,
            priority=priority,
        )

    def send_trade_notification(self, recipient: str, trade_data: dict[str, Any] | None = None) -> dict[str, Any]:
        title = ""
        body = ""
        if trade_data:
            title = trade_data.get("title") or (f"Trade Alert: {trade_data['symbol']}" if "symbol" in trade_data else "")
            body = trade_data.get("content") or (f"Trade action: {trade_data['side']}" if "side" in trade_data else trade_data.get("action", ""))

        msg = self.create_message(
            message_type="trade_notification",
            title=title,
            content=body,
            recipient=recipient,
        )
        msg["type"] = "trade_notification"
        if trade_data:
            msg["trade_data"] = trade_data
        return msg

    def send_system_notification(
        self,
        title: str,
        content: str,
        recipient: str,
        priority: str | None = None,
    ) -> dict[str, Any]:
        msg = self.create_message(
            message_type="system_notification",
            title=title,
            content=content,
            recipient=recipient,
            priority=priority,
        )
        msg["type"] = "system_notification"
        return msg

    # -----------------------
    # Status & Diagnostics
    # -----------------------

    def get_delivery_status(self, message_id: str | None = None) -> dict[str, Any]:
        """Get delivery status for messages."""
        if message_id:
            for record in self.delivery_history:
                if record.get("delivery_id") == message_id or record.get("message_id") == message_id:
                    return record
            return {"error": "Message not found"}

        recent = self.delivery_history[-10:] if self.delivery_history else []
        total = len(self.delivery_history)
        successful = sum(1 for r in self.delivery_history if r.get("successful_deliveries", 0) > 0)

        return {
            "total_messages": total,
            "successful_messages": successful,
            "success_rate": (successful / total * 100) if total > 0 else 0.0,
            "recent_deliveries": recent,
        }

    def get_channel_status(self) -> dict[str, Any]:
        """Get status of all channels."""
        status: dict[str, Any] = {}
        for name, ch in self.channels.items():
            status[name] = {
                "is_active": ch.get("is_active", True),
                "created_at": ch.get("created_at"),
                "config": ch.get("config", {}),
            }
        return status

    def test_channel(self, channel_name: str) -> dict[str, Any]:
        """Test a specific channel."""
        if channel_name not in self.channels:
            return {"error": "Channel not found"}

        try:
            test_content = {
                "subject": "Test Message",
                "body": "This is a test message from Mystic Trading Platform",
                "timestamp": _now_iso(),
                "type": "test",
            }
            result = self._send_to_channel(channel_name, "test", test_content)
            return {
                "success": result.get("success", False),
                "message": "Channel test completed",
                "result": result,
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Channel test failed (%s): %s", channel_name, e)
            return {"error": str(e)}

    # -----------------------
    # Channel Dispatch
    # -----------------------

    def _send_to_channel(self, channel_name: str, _message_type: str, content: dict[str, Any]) -> dict[str, Any]:
        """Send message to a specific channel."""
        channel = self.channels[channel_name]
        config = channel.get("config", {})

        if channel_name == "email":
            return self._send_email(config, content)
        if channel_name == "webhook":
            return self._send_webhook(config, content)
        if channel_name == "slack":
            return self._send_slack(config, content)
        if channel_name == "telegram":
            return self._send_telegram(config, content)
        return {"error": f"Unsupported channel: {channel_name}"}

    def _send_email(self, config: dict[str, Any], content: dict[str, Any]) -> dict[str, Any]:
        """Send email message."""
        try:
            smtp_server = config.get("smtp_server", "localhost")
            smtp_port = int(config.get("smtp_port", 587))
            username = config.get("username", "")
            password = config.get("password", "")
            from_email = config.get("from_email", "noreply@mystic-trading.com")
            use_ssl = bool(config.get("use_ssl", False))
            use_starttls = bool(config.get("use_starttls", True))
            timeout = int(config.get("timeout", 15))

            recipients = content.get("recipients") or [config.get("default_to", "")]
            recipients = [r for r in recipients if r]  # drop empties
            if not recipients:
                return {"error": "No email recipient provided"}

            subject = content.get("subject") or "Mystic Trading Notification"
            body = content.get("body") or ""

            msg = MIMEMultipart()
            msg["From"] = from_email
            msg["To"] = ", ".join(recipients)
            msg["Subject"] = subject
            msg.attach(MIMEText(body, "plain"))

            if use_ssl:
                with smtplib.SMTP_SSL(smtp_server, smtp_port, timeout=timeout) as server:
                    if username and password:
                        server.login(username, password)
                    server.send_message(msg)
            else:
                with smtplib.SMTP(smtp_server, smtp_port, timeout=timeout) as server:
                    if use_starttls:
                        server.starttls()
                    if username and password:
                        server.login(username, password)
                    server.send_message(msg)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Email sending failed: %s", e)
            return {"error": str(e)}
        else:
            return {"success": True, "message": "Email sent"}

    async def _send_webhook(self, config: dict[str, Any], content: dict[str, Any]) -> dict[str, Any]:
        """Send webhook message."""
        try:
            webhook_url = config.get("url", "")
            if not webhook_url:
                return {"error": "Webhook URL not configured"}

            payload = {
                "timestamp": _now_iso(),
                "content": content,
                "source": "mystic_trading_platform",
            }

            async with httpx.AsyncClient() as client:
                r = await client.post(webhook_url, json=payload, timeout=int(config.get("timeout", 10)))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Webhook sending failed: %s", e)
            return {"error": str(e)}
        else:
            if r.status_code == 200:
                return {"success": True, "message": "Webhook sent"}
            return {"error": f"Webhook failed with status {r.status_code}"}

    async def _send_slack(self, config: dict[str, Any], content: dict[str, Any]) -> dict[str, Any]:
        """Send Slack message via incoming webhook."""
        try:
            webhook_url = config.get("webhook_url", "")
            if not webhook_url:
                return {"error": "Slack webhook URL not configured"}

            slack_message = {
                "text": content.get("body", ""),
                "attachments": [
                    {
                        "title": content.get("subject", "Mystic Trading Alert"),
                        "color": self._get_severity_color(content.get("severity", "info")),
                        "fields": [
                            {
                                "title": "Type",
                                "value": content.get("type", "notification"),
                                "short": True,
                            },
                            {
                                "title": "Timestamp",
                                "value": content.get("timestamp", _now_iso()),
                                "short": True,
                            },
                        ],
                    },
                ],
            }

            async with httpx.AsyncClient() as client:
                r = await client.post(
                    webhook_url,
                    json=slack_message,
                    timeout=int(config.get("timeout", 10)),
                )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Slack sending failed: %s", e)
            return {"error": str(e)}
        else:
            if r.status_code == 200:
                return {"success": True, "message": "Slack message sent"}
            return {"error": f"Slack failed with status {r.status_code}"}

    async def _send_telegram(self, config: dict[str, Any], content: dict[str, Any]) -> dict[str, Any]:
        """Send Telegram message via Bot API."""
        try:
            bot_token = config.get("bot_token", "")
            chat_id = config.get("chat_id", "")
            if not bot_token or not chat_id:
                return {"error": "Telegram bot token or chat ID not configured"}

            message = f"*{content.get('subject', 'Mystic Trading Alert')}*\n\n"
            message += content.get("body", "")
            message += f"\n\n_Time: {content.get('timestamp', _now_iso())}_"

            url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
            payload = {"chat_id": chat_id, "text": message, "parse_mode": "Markdown"}
            async with httpx.AsyncClient() as client:
                r = await client.post(url, json=payload, timeout=int(config.get("timeout", 10)))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Telegram sending failed: %s", e)
            return {"error": str(e)}
        else:
            if r.status_code == 200:
                return {"success": True, "message": "Telegram message sent"}
            return {"error": f"Telegram failed with status {r.status_code}"}

    # -----------------------
    # Formatting helpers
    # -----------------------

    def _format_notification(self, notification_type: str, data: dict[str, Any]) -> dict[str, Any]:
        """Format notification content."""
        template = self.message_templates.get(notification_type, "")
        body = template.format(**data) if template else f"Notification: {notification_type}\nData: {json.dumps(data, indent=2)}"
        return {
            "subject": f"Mystic Trading - {notification_type.title()}",
            "body": body,
            "type": "notification",
            "timestamp": _now_iso(),
        }

    def _format_alert(self, alert_type: str, alert_data: dict[str, Any], severity: str) -> dict[str, Any]:
        """Format alert content."""
        template = self.message_templates.get(f"alert_{alert_type}", "")
        body = template.format(**alert_data) if template else f"Alert: {alert_type}\nSeverity: {severity}\nData: {json.dumps(alert_data, indent=2)}"
        return {
            "subject": f"Mystic Trading Alert - {alert_type.title()}",
            "body": body,
            "type": "alert",
            "severity": severity,
            "timestamp": _now_iso(),
        }

    def _get_severity_color(self, severity: str) -> str:
        """Get color for severity level."""
        colors = {
            "info": "#36a64f",
            "warning": "#ffa500",
            "error": "#ff0000",
            "critical": "#8b0000",
        }
        return colors.get(severity, "#36a64f")

    # -----------------------
    # Message CRUD & Queries
    # -----------------------

    def create_message(
        self,
        message_type: str,
        title: str | None = None,
        content: str | None = None,
        recipient: str | None = None,
        priority: str | None = None,
    ) -> dict[str, Any]:
        if message_type not in self.message_types:
            msg = f"Invalid message type: {message_type}"
            raise NotificationException(msg)

        required = self.message_types[message_type]["fields"]
        for field in required:
            if field == "title" and not title:
                msg = "Missing required parameters"
                raise NotificationException(msg)
            if field == "content" and not content:
                msg = "Missing required parameters"
                raise NotificationException(msg)
            if field == "recipient" and not recipient:
                msg = "Missing required parameters"
                raise NotificationException(msg)

        msg_id = f"msg_{int(datetime.now(timezone.utc).timestamp() * 1000):013d}"
        msg = {
            "id": msg_id,
            "type": message_type,
            "title": title,
            "content": content,
            "recipient": recipient,
            "priority": (priority or "medium"),
            "created_at": _now_iso(),
            "read": False,
        }
        self.messages[msg_id] = msg
        self.message_queue.append(msg_id)
        logger.info("Message created: type=%s id=%s", message_type, msg_id)
        return msg

    def get_message(self, message_id: str) -> dict[str, Any] | None:
        return self.messages.get(message_id)

    def mark_as_read(self, message_id: str) -> bool:
        if message_id in self.messages:
            self.messages[message_id]["read"] = True
            self.messages[message_id]["read_at"] = _now_iso()
            return True
        return False

    def delete_message(self, message_id: str) -> bool:
        if message_id in self.messages:
            del self.messages[message_id]
            if message_id in self.message_queue:
                self.message_queue.remove(message_id)
            return True
        return False

    def list_messages(
        self,
        message_type: str | None = None,
        recipient: str | None = None,
        unread_only: bool = False,
    ) -> list[dict[str, Any]]:
        ids = list(self.messages.keys())
        if message_type:
            ids = [mid for mid in ids if self.messages[mid]["type"] == message_type]
        if recipient:
            ids = [mid for mid in ids if self.messages[mid]["recipient"] == recipient]
        if unread_only:
            ids = [mid for mid in ids if not self.messages[mid]["read"]]
        return [self.messages[mid] for mid in ids]

    def list_unread_messages(self, recipient: str) -> list[dict[str, Any]]:
        return [m for m in self.messages.values() if m.get("recipient") == recipient and not m.get("read")]

    def get_message_statistics(self, recipient: str | None = None) -> dict[str, Any]:
        filtered = [m for m in self.messages.values() if m.get("recipient") == recipient] if recipient else list(self.messages.values())
        total = len(filtered)
        unread = len([m for m in filtered if not m.get("read")])
        read = total - unread
        by_type: dict[str, int] = {}
        for m in filtered:
            t = m.get("type", "unknown")
            by_type[t] = by_type.get(t, 0) + 1
        return {
            "total_messages": total,
            "unread_messages": unread,
            "read_messages": read,
            "messages_by_type": by_type,
        }

    def cleanup_old_messages(self, days: int = 30) -> int:
        now = datetime.now(timezone.utc)
        cutoff = now - timedelta(days=days)
        to_delete: list[str] = []
        for mid, m in self.messages.items():
            created = _parse_iso(str(m.get("created_at", _now_iso())))
            if created < cutoff:
                to_delete.append(mid)
        for mid in to_delete:
            self.delete_message(mid)
        return len(to_delete)

    def bulk_mark_as_read(self, message_ids: list[str]) -> int:
        count = 0
        for mid in message_ids:
            if self.mark_as_read(mid):
                count += 1
        return count

    def bulk_delete_messages(self, message_ids: list[str]) -> int:
        count = 0
        for mid in message_ids:
            if self.delete_message(mid):
                count += 1
        return count

    def search_messages(self, query: str, recipient: str | None = None) -> list[dict[str, Any]]:
        q = (query or "").lower()
        out: list[dict[str, Any]] = []
        for m in self.messages.values():
            if recipient and m.get("recipient") != recipient:
                continue
            hay = f"{m.get('title', '')!s} {m.get('content', '')!s}".lower()
            if q in hay:
                out.append(m)
        return out
