"""
Strategy Executor for Mystic Trading Platform

Contains strategy execution logic for live trading.
Handles real-time strategy implementation and order execution.

Rules enforced:
- Single source of truth for exchange id: EXCHANGE_ID = "binance_us"
- One symbol-normalization helper: _to_ccxt_symbol()
- All symbols normalized to CCXT BASE/QUOTE form (e.g., "ETH/USDT")
- No "binance" or "binanceus" leaks - only "binance_us"
- ASCII-only logging (Windows PowerShell safe)
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any

from backend.utils.exceptions import StrategyException

logger = logging.getLogger(__name__)

# Prevent unused-import lint issues
_ = json.dumps({"status": "loaded"})

# =========================
# Exchange constant & symbol helper
# =========================

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e


def _to_ccxt_symbol(s: str) -> str:
    """
    Normalize to CCXT BASE/QUOTE with '/' delimiter, uppercase.
    Examples:
      "eth-usdt" -> "ETH/USDT"
      "eth_usdt" -> "ETH/USDT"
      "ETHUSDT"  -> "ETH/USDT" (best-effort for common quotes)
      "xrp/usdt" -> "XRP/USDT"
    """
    u = (s or "").strip().upper()
    if not u:
        return u

    if "/" in u:
        base, _, quote = u.partition("/")
        base = base.replace("-", "").replace("_", "")
        quote = quote.replace("-", "").replace("_", "")
        return f"{base}/{quote}"

    candidate = u.replace("-", "/").replace("_", "/")
    if "/" in candidate:
        base, _, quote = candidate.partition("/")
        return f"{base}/{quote}"

    KNOWN_QUOTES = ("USDT", "USD", "USDC", "BUSD", "BTC", "ETH")
    for q in KNOWN_QUOTES:
        if candidate.endswith(q) and len(candidate) > len(q):
            base = candidate[: -len(q)]
            return f"{base}/{q}"

    return candidate


class StrategyExecutor:
    """Strategy executor for live trading implementation"""

    def __init__(self) -> None:
        self.active_strategies: dict[str, dict[str, Any]] = {}
        self.strategy_history: list[dict[str, Any]] = []
        self.execution_stats: dict[str, dict[str, Any]] = {}
        self.is_active: bool = True
        self.risk_limits: dict[str, float] = {
            "max_position_size": 0.1,  # 10% of portfolio
            "max_daily_loss": 0.05,  # 5% daily loss limit
            "max_drawdown": 0.15,  # 15% max drawdown
        }

    def add_strategy(self, strategy_id: str, strategy_config: dict[str, Any]) -> dict[str, Any]:
        """Add a new strategy for execution"""
        strategy = {
            "id": strategy_id,
            "config": strategy_config,
            "status": "active",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "execution_count": 0,
            "total_pnl": 0.0,
            "last_execution": None,
            "exchange": EXCHANGE_ID,
        }
        self.active_strategies[strategy_id] = strategy
        logger.info("Strategy added: id=%s exchange=%s", strategy_id, EXCHANGE_ID)
        return {"success": True, "strategy": strategy}

    def remove_strategy(self, strategy_id: str) -> dict[str, Any]:
        """Remove a strategy from execution"""
        if strategy_id in self.active_strategies:
            del self.active_strategies[strategy_id]
            logger.info("Strategy removed: id=%s", strategy_id)
            return {"success": True}
        return {"success": False, "error": "Strategy not found"}

    def execute_strategy(
        self,
        strategy_id: str,
        market_data: dict[str, Any] | None = None,
        portfolio_data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Execute a loaded strategy with given market and portfolio data.

        ccxt calls only receive BASE/QUOTE: all symbols are normalized via _to_ccxt_symbol().
        """
        if strategy_id not in self.active_strategies:
            msg = "Strategy not found"
            raise StrategyException(msg)
        if market_data is None or portfolio_data is None:
            msg = "Market data and portfolio data are required"
            raise StrategyException(msg)

        # Normalize symbol keys in market_data
        normalized_market = self._normalize_market_data(market_data)

        strategy = self.active_strategies[strategy_id]
        conditions = strategy.get("conditions")
        if not isinstance(conditions, list):
            msg = "Invalid strategy configuration"
            raise StrategyException(msg)

        actions = self._evaluate_conditions(conditions, normalized_market)

        # Execute actions
        executed_actions: list[dict[str, Any]] = []
        for action in actions:
            # Normalize symbol in action (defensive)
            if "symbol" in action:
                action["symbol"] = _to_ccxt_symbol(action["symbol"])
            result = self._execute_action(action)
            executed_actions.append(result)

        # Stats
        stats = self.execution_stats.setdefault(strategy_id, {"executions": 0, "successful_actions": 0})
        stats["executions"] += 1
        stats["successful_actions"] += len([a for a in executed_actions if a.get("status") == "success"])

        # History entry
        self.strategy_history.append(
            {
                "strategy_id": strategy_id,
                "executed_at": datetime.now(timezone.utc).isoformat(),
                "execution_results": executed_actions,
            },
        )

        return {"status": "success", "actions": executed_actions}

    def get_strategy_status(self, strategy_id: str) -> dict[str, Any]:
        """Get status of a specific strategy"""
        if strategy_id not in self.active_strategies:
            return {"error": "Strategy not found"}

        strategy = self.active_strategies[strategy_id]
        performance = self._calculate_strategy_performance(strategy_id)

        return {
            "strategy": strategy,
            "performance": performance,
            "is_active": self.is_active,
        }

    def get_all_strategies_status(self) -> dict[str, Any]:
        """Get status of all active strategies"""
        strategies_status: dict[str, Any] = {}
        for strategy_id in self.active_strategies:
            strategies_status[strategy_id] = self.get_strategy_status(strategy_id)
        return {
            "total_strategies": len(self.active_strategies),
            "active_strategies": len([s for s in self.active_strategies.values() if s["status"] == "active"]),
            "strategies": strategies_status,
            "executor_active": self.is_active,
        }

    def pause_strategy(self, strategy_id: str) -> dict[str, Any]:
        """Pause a strategy execution"""
        if strategy_id not in self.active_strategies:
            return {"error": "Strategy not found"}
        self.active_strategies[strategy_id]["status"] = "paused"
        logger.info("Strategy paused: id=%s", strategy_id)
        return {"success": True, "status": "paused"}

    def resume_strategy(self, strategy_id: str) -> dict[str, Any]:
        """Resume a strategy execution"""
        if strategy_id not in self.active_strategies:
            return {"error": "Strategy not found"}
        self.active_strategies[strategy_id]["status"] = "active"
        logger.info("Strategy resumed: id=%s", strategy_id)
        return {"success": True, "status": "active"}

    def update_risk_limits(self, new_limits: dict[str, float]) -> dict[str, Any]:
        """Update risk limits"""
        for key, value in new_limits.items():
            if key in self.risk_limits:
                self.risk_limits[key] = float(value)
        logger.info("Risk limits updated")
        return {"success": True, "risk_limits": self.risk_limits}

    def get_execution_history(self, strategy_id: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        """Get execution history"""
        history = self.strategy_history
        if strategy_id:
            history = [record for record in history if record.get("strategy_id") == strategy_id]
        return history[-limit:] if history else []

    def get_performance_summary(self) -> dict[str, Any]:
        """Get overall performance summary"""
        total_executions = sum(s.get("execution_count", 0) for s in self.active_strategies.values())
        total_pnl = sum(s.get("total_pnl", 0.0) for s in self.active_strategies.values())

        successful_executions = 0
        for record in self.strategy_history:
            results = record.get("execution_results", [])
            if any(res.get("success") for res in results):
                successful_executions += 1

        success_rate = (successful_executions / len(self.strategy_history) * 100.0) if self.strategy_history else 0.0

        return {
            "total_strategies": len(self.active_strategies),
            "total_executions": total_executions,
            "total_pnl": total_pnl,
            "success_rate": round(success_rate, 2),
            "execution_history_count": len(self.strategy_history),
            "risk_limits": self.risk_limits,
            "exchange": EXCHANGE_ID,
        }

    # =========================
    # Internal helpers
    # =========================

    def _normalize_market_data(self, market_data: dict[str, Any]) -> dict[str, Any]:
        """
        Return a new dict with normalized CCXT symbols as keys.
        Ensures downstream uses BASE/QUOTE only.
        """
        out: dict[str, Any] = {}
        for sym, data in market_data.items():
            out[_to_ccxt_symbol(sym)] = data
        return out

    def _check_risk_limits(self, portfolio_data: dict[str, Any]) -> dict[str, Any]:
        """Check if current portfolio violates risk limits"""
        try:
            daily_pnl = float(portfolio_data.get("daily_pnl", 0.0))
            portfolio_value = float(portfolio_data.get("total_value", 1.0))
            if portfolio_value <= 0:
                return {"passed": False, "reason": "Invalid portfolio value"}

            if abs(daily_pnl) / portfolio_value > self.risk_limits["max_daily_loss"]:
                return {"passed": False, "reason": "Daily loss limit exceeded"}

            current_drawdown = float(portfolio_data.get("current_drawdown", 0.0))
            if current_drawdown > self.risk_limits["max_drawdown"]:
                return {"passed": False, "reason": "Max drawdown exceeded"}
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Risk limit check failed: %s", e)
            return {"passed": False, "reason": f"Risk check error: {e}"}
        else:
            return {"passed": True}

    def _generate_signals(self, strategy: dict[str, Any], market_data: dict[str, Any]) -> list[dict[str, Any]]:
        """Generate trading signals based on strategy and market data"""
        try:
            config = strategy.get("config", {})
            strategy_type = config.get("type", "basic")
            if strategy_type == "momentum":
                return self._generate_momentum_signals(market_data, config)
            if strategy_type == "mean_reversion":
                return self._generate_mean_reversion_signals(market_data, config)
            if strategy_type == "breakout":
                return self._generate_breakout_signals(market_data, config)
            return self._generate_basic_signals(market_data, config)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Signal generation failed: %s", e)
            return []

    def _execute_trade(self, signal: dict[str, Any], portfolio_data: dict[str, Any]) -> dict[str, Any]:
        """Execute a single trade based on signal (simulation stub)"""
        try:
            symbol = _to_ccxt_symbol(signal.get("symbol", ""))
            action = signal.get("action", "")
            quantity = float(signal.get("quantity", 0.0))
            price = float(signal.get("price", 0.0))

            trade_result = {
                "symbol": symbol,
                "action": action,
                "quantity": quantity,
                "price": price,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "success": True,
                "order_id": f"order_{datetime.now(timezone.utc).timestamp()}",
                "commission": quantity * price * 0.001,  # 0.1% commission
                "status": "filled",
                "exchange": EXCHANGE_ID,
            }

            if action == "buy":
                trade_result["pnl"] = 0.0
            elif action == "sell":
                # Use normalized symbol for portfolio lookup
                pos = portfolio_data.get("positions", {}).get(symbol, {})
                entry_price = float(pos.get("entry_price", price))
                trade_result["pnl"] = (price - entry_price) * quantity
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Trade execution failed: %s", e)
            return {
                "success": False,
                "error": str(e),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        else:
            return trade_result

    def _calculate_strategy_performance(self, strategy_id: str) -> dict[str, Any]:
        """Calculate performance metrics for a strategy"""
        strategy_history = self.get_execution_history(strategy_id)
        if not strategy_history:
            return {"error": "No execution history available"}

        total_trades = 0
        successful_trades = 0
        total_pnl = 0.0

        for record in strategy_history:
            for result in record.get("execution_results", []):
                total_trades += 1
                if result.get("success"):
                    successful_trades += 1
                    total_pnl += float(result.get("pnl", 0.0))

        win_rate = (successful_trades / total_trades * 100.0) if total_trades > 0 else 0.0
        avg_pnl = (total_pnl / total_trades) if total_trades > 0 else 0.0

        return {
            "total_trades": total_trades,
            "successful_trades": successful_trades,
            "win_rate": round(win_rate, 2),
            "total_pnl": round(total_pnl, 2),
            "avg_pnl_per_trade": round(avg_pnl, 2),
        }

    def _generate_momentum_signals(self, market_data: dict[str, Any], _config: dict[str, Any]) -> list[dict[str, Any]]:
        """Generate momentum-based trading signals"""
        signals: list[dict[str, Any]] = []
        for symbol, data in market_data.items():
            rsi = data.get("rsi", 50)
            price = data.get("price", 0.0)
            if rsi < 30:
                signals.append(
                    {
                        "symbol": symbol,
                        "action": "buy",
                        "quantity": 1.0,
                        "price": price,
                        "confidence": 0.8,
                        "reason": "RSI oversold",
                    }
                )
            elif rsi > 70:
                signals.append(
                    {
                        "symbol": symbol,
                        "action": "sell",
                        "quantity": 1.0,
                        "price": price,
                        "confidence": 0.8,
                        "reason": "RSI overbought",
                    }
                )
        return signals

    def _generate_mean_reversion_signals(self, market_data: dict[str, Any], _config: dict[str, Any]) -> list[dict[str, Any]]:
        """Generate mean reversion trading signals"""
        signals: list[dict[str, Any]] = []
        for symbol, data in market_data.items():
            price = data.get("price", 0.0)
            bb_upper = data.get("bollinger_upper", price * 1.02)
            bb_lower = data.get("bollinger_lower", price * 0.98)
            if price > bb_upper:
                signals.append(
                    {
                        "symbol": symbol,
                        "action": "sell",
                        "quantity": 1.0,
                        "price": price,
                        "confidence": 0.7,
                        "reason": "Above upper band",
                    }
                )
            elif price < bb_lower:
                signals.append(
                    {
                        "symbol": symbol,
                        "action": "buy",
                        "quantity": 1.0,
                        "price": price,
                        "confidence": 0.7,
                        "reason": "Below lower band",
                    }
                )
        return signals

    def _generate_breakout_signals(self, market_data: dict[str, Any], _config: dict[str, Any]) -> list[dict[str, Any]]:
        """Generate breakout trading signals"""
        signals: list[dict[str, Any]] = []
        for symbol, data in market_data.items():
            price = data.get("price", 0.0)
            volume = data.get("volume", 0.0)
            avg_volume = data.get("avg_volume", volume)
            if avg_volume > 0 and volume > avg_volume * 1.5:
                signals.append(
                    {
                        "symbol": symbol,
                        "action": "buy",
                        "quantity": 1.0,
                        "price": price,
                        "confidence": 0.6,
                        "reason": "Volume breakout",
                    }
                )
        return signals

    def _generate_basic_signals(self, market_data: dict[str, Any], _config: dict[str, Any]) -> list[dict[str, Any]]:
        """Generate basic trading signals"""
        signals: list[dict[str, Any]] = []
        for symbol, data in market_data.items():
            price = data.get("price", 0.0)
            macd = data.get("macd", 0.0)
            if macd > 0:
                signals.append(
                    {
                        "symbol": symbol,
                        "action": "buy",
                        "quantity": 1.0,
                        "price": price,
                        "confidence": 0.5,
                        "reason": "Positive MACD",
                    }
                )
            elif macd < 0:
                signals.append(
                    {
                        "symbol": symbol,
                        "action": "sell",
                        "quantity": 1.0,
                        "price": price,
                        "confidence": 0.5,
                        "reason": "Negative MACD",
                    }
                )
        return signals

    def load_strategy(self, strategy_config: dict[str, Any]) -> bool:
        """Load a new strategy configuration"""
        if not isinstance(strategy_config, dict) or "id" not in strategy_config or "name" not in strategy_config or "conditions" not in strategy_config:
            msg = "Invalid strategy configuration"
            raise StrategyException(msg)

        strategy_id = strategy_config["id"]
        if strategy_id in self.active_strategies:
            msg = "Strategy with this ID already loaded"
            raise StrategyException(msg)

        self.active_strategies[strategy_id] = strategy_config
        self.strategy_history.append(
            {
                "action": "load",
                "strategy_id": strategy_id,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        )
        return True

    def unload_strategy(self, strategy_id: str) -> bool:
        """Unload a strategy by ID"""
        if strategy_id not in self.active_strategies:
            return False
        del self.active_strategies[strategy_id]
        self.strategy_history.append(
            {
                "action": "unload",
                "strategy_id": strategy_id,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        )
        if strategy_id in self.execution_stats:
            del self.execution_stats[strategy_id]
        return True

    def get_strategy(self, strategy_id: str) -> dict[str, Any] | None:
        """Get strategy configuration by ID"""
        return self.active_strategies.get(strategy_id)

    def update_strategy(self, strategy_id: str, updated_config: dict[str, Any]) -> dict[str, Any]:
        """Update an existing strategy configuration"""
        if strategy_id not in self.active_strategies:
            msg = "Strategy not found"
            raise StrategyException(msg)
        if not isinstance(updated_config, dict):
            msg = "Invalid strategy configuration"
            raise StrategyException(msg)

        # Support both add_strategy (wrapped config) and load_strategy (raw config) styles
        if "config" in self.active_strategies[strategy_id]:
            self.active_strategies[strategy_id]["config"] = updated_config
        else:
            self.active_strategies[strategy_id].update(updated_config)

        self.active_strategies[strategy_id]["updated_at"] = datetime.now(timezone.utc).isoformat()
        logger.info("Strategy updated: id=%s", strategy_id)
        return {"success": True, "strategy": self.active_strategies[strategy_id]}

    def list_strategies(self) -> list[str]:
        """List all loaded strategy IDs"""
        return list(self.active_strategies.keys())

    def get_execution_stats(self, strategy_id: str) -> dict[str, Any]:
        """Get execution stats for a strategy"""
        return self.execution_stats.get(strategy_id, {})

    def get_all_execution_stats(self) -> dict[str, dict[str, Any]]:
        """Get execution stats for all strategies"""
        return self.execution_stats

    def _evaluate_conditions(self, conditions: list[dict[str, Any]], market_data: dict[str, Any]) -> list[dict[str, Any]]:
        """
        Evaluate trading conditions and return all matches for all symbols.
        Ensures returned actions contain normalized CCXT symbols.
        """
        actions: list[dict[str, Any]] = []
        for symbol, data in market_data.items():
            rsi = data.get("rsi")
            for cond in conditions:
                c = cond.get("condition")
                if (c == "rsi < 30" and rsi is not None and rsi < 30) or (c == "rsi > 70" and rsi is not None and rsi > 70):
                    action = {**cond, "symbol": symbol}
                    actions.append(action)
                elif c not in ["rsi < 30", "rsi > 70"]:
                    msg = "Invalid condition"
                    raise StrategyException(msg)
        return actions

    def _execute_action(self, action: dict[str, Any]) -> dict[str, Any]:
        """Execute a trading action and return result with action key included."""
        if not isinstance(action, dict) or "action" not in action or "symbol" not in action or "quantity" not in action:
            msg = "Invalid action or missing parameters"
            raise StrategyException(msg)
        if action["action"] not in ["buy", "sell"]:
            msg = "Invalid action or missing parameters"
            raise StrategyException(msg)

        # Normalize symbol on output to keep BASE/QUOTE invariant
        norm_symbol = _to_ccxt_symbol(action["symbol"])
        return {
            "status": "success",
            "order_id": "12345",
            "action": action["action"],
            "symbol": norm_symbol,
            "exchange": EXCHANGE_ID,
        }
