"""
Order Manager Module for Mystic Trading Platform

Extracted from trade_engine.py and auto_trading_manager.py to improve modularity.
Handles order creation, management, and execution.

Rules enforced:
- Single source of truth: EXCHANGE_ID = "binance_us"
- One _to_ccxt_symbol() helper for symbol normalization; no ad-hoc string munging
- Symbols stored and compared in CCXT BASE/QUOTE form (e.g., "ETH/USDT")
- No "binance" or "binanceus" string leaks — only "binance_us"
- ASCII-only logging (safe for Windows PowerShell)
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)

# =========================
# Exchange constants & symbol helper
# =========================

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e


def _to_ccxt_symbol(s: str) -> str:
    """
    Normalize to CCXT BASE/QUOTE form with '/' delimiter, uppercase.
    Examples:
      "eth-usdt" -> "ETH/USDT"
      "eth_usdt" -> "ETH/USDT"
      "ETHUSDT"  -> "ETH/USDT" (best effort for common USDT forms)
      "xrp/usdt" -> "XRP/USDT"
    """
    u = (s or "").strip().upper()
    if not u:
        return u

    # Already contains '/', just clean separators
    if "/" in u:
        base, _, quote = u.partition("/")
        base = base.replace("-", "").replace("_", "")
        quote = quote.replace("-", "").replace("_", "")
        return f"{base}/{quote}"

    # Replace common separators, then split if possible
    candidate = u.replace("-", "/").replace("_", "/")
    if "/" in candidate:
        base, _, quote = candidate.partition("/")
        return f"{base}/{quote}"

    # Fallback for concatenated pairs with common quotes
    KNOWN_QUOTES = ("USDT", "USD", "USDC", "BUSD", "BTC", "ETH")
    for q in KNOWN_QUOTES:
        if candidate.endswith(q) and len(candidate) > len(q):
            base = candidate[: -len(q)]
            return f"{base}/{q}"

    # Last resort: return uppercase candidate unchanged
    return candidate


# =========================
# Order model & enums
# =========================


class OrderType(Enum):
    """Order types"""

    MARKET = "market"
    LIMIT = "limit"
    STOP = "stop"
    STOP_LIMIT = "stop_limit"


class OrderSide(Enum):
    """Order sides"""

    BUY = "buy"
    SELL = "sell"


class OrderStatus(Enum):
    """Order statuses"""

    PENDING = "pending"
    FILLED = "filled"
    CANCELLED = "cancelled"
    REJECTED = "rejected"
    PARTIALLY_FILLED = "partially_filled"


@dataclass
class Order:
    """Order data structure"""

    id: str
    symbol: str  # Stored as CCXT "BASE/QUOTE"
    side: OrderSide
    order_type: OrderType
    quantity: float
    price: float | None = None
    status: OrderStatus = OrderStatus.PENDING
    timestamp: float | None = None
    exchange: str = EXCHANGE_ID  # single source of truth

    def __post_init__(self) -> None:
        if self.timestamp is None:
            self.timestamp = time.time()


# =========================
# Manager
# =========================


class OrderManager:
    """Manages order creation, execution, and tracking"""

    def __init__(self) -> None:
        self.orders: dict[str, Order] = {}
        self.order_counter = 0
        logger.info("OrderManager initialized")

    def _next_order_id(self) -> str:
        self.order_counter += 1
        return f"order_{self.order_counter}_{int(time.time())}"

    def create_order(
        self,
        symbol: str,
        side: OrderSide,
        order_type: OrderType,
        quantity: float,
        price: float | None = None,
        _exchange: str = EXCHANGE_ID,
    ) -> Order:
        """Create a new order"""
        try:
            order_id = self._next_order_id()
            norm_symbol = _to_ccxt_symbol(symbol)

            order = Order(
                id=order_id,
                symbol=norm_symbol,
                side=side,
                order_type=order_type,
                quantity=float(quantity),
                price=float(price) if price is not None else None,
                exchange=EXCHANGE_ID,  # force single-source exchange id
            )

            self.orders[order_id] = order
            logger.info(
                "Order created: id=%s symbol=%s side=%s type=%s qty=%s price=%s exchange=%s",
                order_id,
                order.symbol,
                order.side.value,
                order.order_type.value,
                order.quantity,
                f"{order.price:.8f}" if order.price is not None else "None",
                order.exchange,
            )
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error creating order: %s", e)
            raise
        else:
            return order

    def get_order(self, order_id: str) -> Order | None:
        """Get order by ID"""
        return self.orders.get(order_id)

    def get_orders(
        self,
        symbol: str | None = None,
        status: OrderStatus | None = None,
        limit: int = 100,
    ) -> list[Order]:
        """Get orders with optional filtering"""
        try:
            orders = list(self.orders.values())

            if symbol:
                norm = _to_ccxt_symbol(symbol)
                orders = [o for o in orders if o.symbol == norm]

            if status:
                orders = [o for o in orders if o.status == status]

            if limit <= 0:
                return []
            return orders[:limit]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error getting orders: %s", e)
            return []

    def update_order_status(self, order_id: str, status: OrderStatus) -> bool:
        """Update order status"""
        try:
            o = self.orders.get(order_id)
            if not o:
                return False
            o.status = status
            logger.info("Order %s status updated to %s", order_id, status.value)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error updating order status: %s", e)
            return False
        else:
            return True

    def cancel_order(self, order_id: str) -> bool:
        """Cancel an order"""
        try:
            o = self.orders.get(order_id)
            if not o:
                return False
            o.status = OrderStatus.CANCELLED
            logger.info("Order %s cancelled", order_id)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error cancelling order: %s", e)
            return False
        else:
            return True

    def get_order_history(
        self,
        symbol: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> dict[str, Any]:
        """Get order history with pagination"""
        try:
            # Reuse filtering; ensure stable ordering by timestamp desc
            orders = self.get_orders(symbol=symbol, limit=10_000)
            orders.sort(key=lambda o: o.timestamp or 0.0, reverse=True)

            offset = max(offset, 0)
            if limit <= 0:
                sliced: list[Order] = []
            else:
                start = offset
                end = offset + limit
                sliced = orders[start:end]

            return {
                "orders": [self._order_to_dict(order) for order in sliced],
                "total": len(orders),
                "limit": limit,
                "offset": offset,
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error getting order history: %s", e)
            return {"orders": [], "total": 0, "limit": limit, "offset": offset}

    def _order_to_dict(self, order: Order) -> dict[str, Any]:
        """Convert order to dictionary"""
        return {
            "id": order.id,
            "symbol": order.symbol,
            "side": order.side.value,
            "order_type": order.order_type.value,
            "quantity": order.quantity,
            "price": order.price,
            "status": order.status.value,
            "timestamp": order.timestamp,
            "exchange": order.exchange,
        }

    def get_statistics(self) -> dict[str, Any]:
        """Get order statistics"""
        try:
            total_orders = len(self.orders)
            pending_orders = sum(1 for o in self.orders.values() if o.status == OrderStatus.PENDING)
            filled_orders = sum(1 for o in self.orders.values() if o.status == OrderStatus.FILLED)
            cancelled_orders = sum(1 for o in self.orders.values() if o.status == OrderStatus.CANCELLED)
            fill_rate = (filled_orders / total_orders) if total_orders > 0 else 0.0
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception("Error getting order statistics: %s", e)
            return {}
        else:
            return {
                "total_orders": total_orders,
                "pending_orders": pending_orders,
                "filled_orders": filled_orders,
                "cancelled_orders": cancelled_orders,
                "fill_rate": fill_rate,
                "exchange": EXCHANGE_ID,
            }


# Global order manager instance
order_manager = OrderManager()
