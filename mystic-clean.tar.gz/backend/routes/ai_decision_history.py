"""
AI Decision History Endpoints

AI decision history and shadow trading comparison.
- Live data only (no fabricated fallbacks)
"""

from __future__ import annotations

import contextlib
import json
import logging
import os
from typing import Any

from fastapi import APIRouter, HTTPException

from backend.config.redis_config import get_redis_client
from backend.metrics import shadow_match_ratio

logger = logging.getLogger(__name__)
router = APIRouter(tags=["ai_decisions"])

ALLOWED_SYMBOLS = {
    "BTCUSDT",
    "ETHUSDT",
    "ADAUSDT",
    "SOLUSDT",
    "DOGEUSDT",
    "XRPUSDT",
    "BCHUSDT",
    "LTCUSDT",
    "AVAXUSDT",
    "LINKUSDT",
}

_MAX_LIMIT = 1000

_redis_client: Any = None


def _redis_url() -> str:
    """Get Redis URL from environment."""
    env_url = os.getenv("REDIS_URL")
    if env_url:
        return env_url
    host = os.getenv("REDIS_HOST")
    port = os.getenv("REDIS_PORT")
    db = os.getenv("REDIS_DB")
    if not host:
        host = "localhost"
    if not port:
        port = "6379"
    if not db:
        db = "0"
    try:
        port_int = int(port)
    except (ValueError, TypeError):
        port_int = 6379
    try:
        db_int = int(db)
    except (ValueError, TypeError):
        db_int = 0
    return f"redis://{host}:{port_int}/{db_int}"


# Redis client state - using dict to avoid global keyword
_redis_client_state: dict[str, Any] = {"instance": None}


def _get_redis() -> Any:
    """Get Redis client instance from shared pool."""
    if _redis_client_state["instance"] is None:
        _redis_client_state["instance"] = get_redis_client()
    return _redis_client_state["instance"]


def _clamp_limit(limit: int) -> int:
    """Clamp limit to valid range."""
    try:
        v = int(limit)
    except (ValueError, TypeError):
        v = 100
    v = max(v, 1)
    return min(v, _MAX_LIMIT)


def _validate_symbol(symbol: str) -> str:
    """Validate and normalize symbol."""
    s = symbol.upper()
    if s not in ALLOWED_SYMBOLS:
        symbols_list = sorted(ALLOWED_SYMBOLS)
        raise HTTPException(
            status_code=400,
            detail=f"symbol must be one of {symbols_list}",
        )
    return s


def _parse_json_list(
    raw: list[str] | None,
) -> list[dict[str, Any]]:
    """Parse JSON list from Redis."""
    out: list[dict[str, Any]] = []
    if not isinstance(raw, list):
        return out
    for s in raw:
        try:
            parsed = json.loads(s)
            if isinstance(parsed, dict):
                out.append(parsed)
        except (ValueError, TypeError, json.JSONDecodeError):
            continue
    return out


def _norm_action(d: dict[str, Any]) -> str:
    """Normalize action/decision from dict."""
    action = d.get("action")
    if not action:
        action = d.get("decision")
    if not action:
        return ""
    a = str(action).strip().lower()
    return a.removeprefix("shadow_")


@router.get("/ai/decisions/{symbol}/history")
async def get_decision_history(symbol: str, limit: int = 100) -> dict[str, Any]:
    """Get decision history for symbol."""
    try:
        sym = _validate_symbol(symbol)
        r = _get_redis()
        lim = _clamp_limit(limit)
        start = -lim
        key = f"ai_decision_hist:{sym}"
        raw = await r.lrange(key, start, -1)
        items = _parse_json_list(raw)

        response: dict[str, Any] = {
            "symbol": sym,
            "count": len(items),
        }

        if items:
            response["items"] = items
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error getting decision history: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get decision history: {e}") from e
    else:
        return response


@router.get("/ai/decisions/{symbol}/shadow_history")
async def get_shadow_decision_history(symbol: str, limit: int = 100) -> dict[str, Any]:
    """Get shadow decision history for symbol."""
    try:
        sym = _validate_symbol(symbol)
        r = _get_redis()
        lim = _clamp_limit(limit)
        start = -lim
        key = f"ai_decision_shadow_hist:{sym}"
        raw = await r.lrange(key, start, -1)
        items = _parse_json_list(raw)

        response: dict[str, Any] = {
            "symbol": sym,
            "count": len(items),
        }

        if items:
            response["items"] = items
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error getting shadow history: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to get shadow history: {e}",
        ) from e
    else:
        return response


@router.get("/ai/decisions/{symbol}/diff")
async def get_decision_diff(symbol: str, limit: int = 100) -> dict[str, Any]:
    """Get difference between live and shadow decisions."""
    try:
        sym = _validate_symbol(symbol)
        r = _get_redis()
        lim = _clamp_limit(limit)
        start = -lim
        live_key = f"ai_decision_hist:{sym}"
        shadow_key = f"ai_decision_shadow_hist:{sym}"
        async with r.pipeline(transaction=False) as pipe:
            pipe.lrange(live_key, start, -1)
            pipe.lrange(shadow_key, start, -1)
            results = await pipe.execute()

        if not isinstance(results, list) or len(results) < 2:
            return {
                "symbol": sym,
                "compared": 0,
                "matches": 0,
                "mismatches": 0,
                "items": [],
            }

        live_raw = results[0]
        sh_raw = results[1]

        if not isinstance(live_raw, list):
            live_raw = []
        if not isinstance(sh_raw, list):
            sh_raw = []

        n = min(len(live_raw), len(sh_raw))
        matches = 0
        mismatches = 0
        rows: list[dict[str, Any]] = []

        for i in range(-n, 0):
            try:
                lv_str = live_raw[i]
                sv_str = sh_raw[i]
                lv = json.loads(lv_str)
                sv = json.loads(sv_str)
            except (ValueError, TypeError, json.JSONDecodeError):
                continue

            if not isinstance(lv, dict) or not isinstance(sv, dict):
                continue

            l_reason_val = lv.get("reason")
            s_reason_val = sv.get("reason")

            l_reason = str(l_reason_val).strip().lower() if l_reason_val else ""

            s_reason = str(s_reason_val).strip().lower() if s_reason_val else ""

            live_exec = l_reason.startswith("executed")
            shadow_exec = s_reason.startswith("shadow_executed")

            l_action = _norm_action(lv)
            s_action = _norm_action(sv)
            same_action = l_action == s_action and l_action != ""

            same = (live_exec and shadow_exec) or (not live_exec and not shadow_exec and same_action)

            if same:
                matches += 1
            else:
                mismatches += 1

            rows.append({"live": lv, "shadow": sv, "match": bool(same)})

        response: dict[str, Any] = {
            "symbol": sym,
            "compared": n,
            "matches": matches,
            "mismatches": mismatches,
            "items": rows,
        }

        if n > 0:
            ratio = float(matches) / float(n)
            response["match_ratio"] = ratio
            with contextlib.suppress(Exception):
                shadow_match_ratio.labels(symbol=sym).set(ratio)
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error getting decision diff: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get decision diff: {e}") from e
    else:
        return response
