"""
AI Evaluation Endpoints

DR (Data/Decision Risk) evaluation endpoints.
- Live data only (no fabricated fallbacks)
"""

from __future__ import annotations

import logging
import os
import time
from typing import Any

from fastapi import APIRouter, HTTPException, Query

from backend.config.redis_config import get_redis_client
from backend.services.dr_evaluator import dr_evaluator

logger = logging.getLogger(__name__)
router = APIRouter(tags=["ai_eval"])

# Import from single source of truth
try:
    from backend.config.trading_universe import TRADING_SYMBOLS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

# Use TRADING_SYMBOLS from trading_universe (live data)
ALLOWED_SYMBOLS = set(TRADING_SYMBOLS)

_redis_client: Any = None


def _redis_url() -> str:
    """Get Redis URL from environment (no fallback)."""
    # All Live Data, No Fallback/Hardcoded Data
    redis_url = os.getenv("REDIS_URL")
    if not redis_url:
        redis_host = os.getenv("REDIS_HOST")
        if not redis_host:
            msg = "REDIS_URL or REDIS_HOST environment variable is required - no fallback/hardcoded Redis URL"
            raise RuntimeError(msg)
        redis_port = os.getenv("REDIS_PORT", "6379")
        redis_db = os.getenv("REDIS_DB", "0")
        redis_url = f"redis://{redis_host}:{redis_port}/{redis_db}"
    return redis_url


# Redis client state - using dict to avoid global keyword
_redis_client_state: dict[str, Any] = {"instance": None}


def _get_redis() -> Any:
    """Get Redis client instance from shared pool."""
    if _redis_client_state["instance"] is None:
        _redis_client_state["instance"] = get_redis_client()
    return _redis_client_state["instance"]


def _clamp_limit(limit: int) -> int:
    """Clamp limit to valid range."""
    try:
        v = int(limit)
    except (ValueError, TypeError):
        v = 200
    v = max(v, 10)
    return min(v, 2000)


def _get_symbols() -> list[str]:
    """Get symbols from environment or return empty list."""
    raw = os.getenv("TOP_SYMBOLS", "")
    if not raw.strip():
        return []
    parts = [p.strip().upper() for p in raw.split(",")]
    dedup = []
    seen = set()
    for p in parts:
        if p in ALLOWED_SYMBOLS and p not in seen:
            seen.add(p)
            dedup.append(p)
    return dedup


def _ccxt_pair(symbol: str) -> str:
    """Convert symbol to CCXT pair format."""
    return symbol.replace("USDT", "/USDT")


def _avg_str_list(arr: list[str]) -> float | None:
    """Calculate average of string list - returns None if unavailable."""
    if not arr:
        return None
    try:
        vals = [float(x) for x in arr]
        if vals:
            return sum(vals) / len(vals)
    except (ValueError, TypeError):
        return None
    else:
        return None


@router.get("/ai/dr/summary")
async def get_dr_summary(
    limit: int = Query(200, ge=10, le=2000),
) -> dict[str, Any]:
    """Get DR summary from Redis."""
    try:
        r = _get_redis()
        symbols = _get_symbols()
        if not symbols:
            return {"items": [], "ts": int(time.time())}

        lim = _clamp_limit(limit)
        end_idx = min(999, max(0, lim - 1))

        async with r.pipeline(transaction=False) as pipe:
            for s in symbols:
                ccxt = _ccxt_pair(s)
                pipe.get(f"risk:pnl:symbol:{ccxt}")
                pipe.lrange(f"paper:slippage:{ccxt}", 0, end_idx)
                pipe.lrange(f"paper:fillratio:{ccxt}", 0, end_idx)
            results = await pipe.execute()

        items_map: dict[str, dict[str, Any]] = {}
        for s in symbols:
            items_map[s] = {"symbol": s}

        it = iter(results)
        for s in symbols:
            try:
                pnl_raw = next(it)
                slip_raw = next(it)
                fill_raw = next(it)
            except StopIteration:
                pnl_raw, slip_raw, fill_raw = None, [], []

            slip_raw = slip_raw if isinstance(slip_raw, list) else []

            fill_raw = fill_raw if isinstance(fill_raw, list) else []

            if pnl_raw is not None:
                try:
                    pnl_val = float(pnl_raw)
                    items_map[s]["live_pnl"] = round(pnl_val, 2)
                except (ValueError, TypeError):
                    pass

            slip_avg = _avg_str_list(slip_raw)
            if slip_avg is not None:
                items_map[s]["paper_slippage_bp_avg"] = round(slip_avg, 3)

            fill_avg = _avg_str_list(fill_raw)
            if fill_avg is not None:
                items_map[s]["paper_fill_ratio_avg"] = round(fill_avg, 3)

        items = [items_map[s] for s in symbols]
        return {"items": items, "ts": int(time.time())}
    except Exception as e:
        logger.exception(f"Error getting DR summary: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get DR summary: {e}") from e


@router.get("/ai/dr/evaluate")
async def run_dr_evaluate(
    limit: int = Query(200, ge=10, le=2000),
    t_high_delta: float = Query(0.02, ge=-0.3, le=0.3),
) -> dict[str, Any]:
    """Run DR evaluation."""
    try:
        return await dr_evaluator.evaluate_all(limit=limit, t_high_delta=t_high_delta)
    except Exception as e:
        logger.exception(f"Error running DR evaluate: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to run DR evaluate: {e}") from e
