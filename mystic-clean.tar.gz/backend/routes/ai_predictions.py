"""
AI Predictions Endpoints

AI price prediction functionality.
- Live data only (no fabricated fallbacks)
"""

import asyncio
import logging
import os
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException

from backend.database_schema import DATABASE_PATH
from backend.modules.ai.ai_signals import (
    market_strength_signals,
    mystic_oracle,
    risk_adjusted_signals,
    signal_scorer,
    technical_signals,
    trend_analysis,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/ai", tags=["ai-predictions"])

ALLOWED_SYMBOLS = {
    "BTCUSDT",
    "ETHUSDT",
    "ADAUSDT",
    "SOLUSDT",
    "DOGEUSDT",
    "XRPUSDT",
    "BCHUSDT",
    "LTCUSDT",
    "AVAXUSDT",
    "LINKUSDT",
}
ALLOWED_BASES = {s[:-4] for s in ALLOWED_SYMBOLS}


def _utc_iso() -> str:
    """Get current timestamp in ISO format."""
    return datetime.now(timezone.utc).isoformat()


def _safe_int(x: Any) -> int | None:
    """Convert to int - returns None if unavailable."""
    try:
        return int(x)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError):
        return None


def _safe_float(x: Any) -> float | None:
    """Convert to float - returns None if unavailable."""
    try:
        return float(x)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError):
        return None


def _norm_symbol(sym: str) -> str | None:
    """Normalize symbol to USDT format."""
    if not sym:
        return None
    s = sym.upper().replace("-", "").replace("/", "").replace(" ", "")
    if s.endswith("USD") and not s.endswith("USDT"):
        s = s[:-3] + "USDT"
    if s in ALLOWED_SYMBOLS:
        return s
    if s in ALLOWED_BASES:
        s2 = s + "USDT"
        return s2 if s2 in ALLOWED_SYMBOLS else None
    return None


def _extract_scorer(
    signal_text: str,
) -> tuple[str | None, int | None]:
    """Extract symbol and score from signal text."""
    if not signal_text:
        return None, None
    parts = signal_text.strip().split()
    if not parts:
        return None, None
    sym = _norm_symbol(parts[0])
    score = None
    for p in parts[1:]:
        v = _safe_int(p)
        if v is not None and 0 <= v <= 100:
            score = v
            break
    return sym, score


@router.get("/prediction-list")
async def get_ai_predictions() -> list[dict[str, Any]]:
    """Get AI price predictions."""
    try:
        predictions: list[dict[str, Any]] = []

        scored_signals_list = signal_scorer()
        if not isinstance(scored_signals_list, list):
            scored_signals_list = []

        risk_signals_list = risk_adjusted_signals()
        if not isinstance(risk_signals_list, list):
            risk_signals_list = []

        tech_signals_list = technical_signals()
        if not isinstance(tech_signals_list, list):
            tech_signals_list = []

        price_index: dict[str, float] = {}
        for s in risk_signals_list:
            if not isinstance(s, dict):
                continue
            sym = _norm_symbol(s.get("symbol"))
            if sym:
                price_val = s.get("price")
                price = _safe_float(price_val)
                if price is not None:
                    price_index[sym] = price

        for s in tech_signals_list:
            if not isinstance(s, dict):
                continue
            sym = _norm_symbol(s.get("symbol"))
            if sym and sym not in price_index:
                price_val = s.get("price")
                price = _safe_float(price_val)
                if price is not None:
                    price_index[sym] = price

        for signal in scored_signals_list[:10]:
            try:
                sym, score = _extract_scorer(signal)
                if not sym or score is None:
                    continue

                cur = price_index.get(sym)
                if cur is None or cur <= 0:
                    continue

                pred = cur * (1 + (score - 50) / 100)

                entry: dict[str, Any] = {
                    "id": (f"pred_{sym}_{int(datetime.now(timezone.utc).timestamp())}"),
                    "symbol": sym,
                    "predictedPrice": round(pred, 6),
                    "currentPrice": round(cur, 6),
                    "confidence": min(max(score, 0), 95),
                    "timeframe": "24H",
                    "timestamp": _utc_iso(),
                    "source": "AI Signal Scorer",
                    "reasoning": f"Signal score: {score} - {signal}",
                }

                if score > 60:
                    entry["direction"] = "UP"
                else:
                    entry["direction"] = "DOWN"

                predictions.append(entry)
            except Exception as e:
                logger.exception(f"prediction-format scorer error: {e}")
                continue

        for s in risk_signals_list[:5]:
            try:
                if not isinstance(s, dict):
                    continue

                sym = _norm_symbol(s.get("symbol"))
                if not sym:
                    continue

                price_val = s.get("price")
                cur = _safe_float(price_val)
                if cur is None:
                    cur = price_index.get(sym)

                if cur is None or cur <= 0:
                    continue

                score_val = s.get("score")
                score = _safe_int(score_val)
                if score is None:
                    continue

                pred = cur * (1 + (score - 50) / 100)

                entry: dict[str, Any] = {
                    "id": (f"risk_pred_{sym}_{int(datetime.now(timezone.utc).timestamp())}"),
                    "symbol": sym,
                    "predictedPrice": round(pred, 6),
                    "currentPrice": round(cur, 6),
                    "confidence": min(max(score, 0), 95),
                    "timeframe": "24H",
                    "timestamp": _utc_iso(),
                    "source": "AI Risk Analysis",
                }

                if score > 60:
                    entry["direction"] = "UP"
                else:
                    entry["direction"] = "DOWN"

                risk_score = s.get("risk_score")
                reasoning_parts = [f"Risk-adjusted score: {score}"]
                if risk_score is not None:
                    reasoning_parts.append(f"Risk: {risk_score}")
                entry["reasoning"] = ", ".join(reasoning_parts)

                predictions.append(entry)
            except Exception as e:
                logger.exception(f"prediction-format risk error: {e}")
                continue

        for s in tech_signals_list[:5]:
            try:
                if not isinstance(s, dict):
                    continue

                sym = _norm_symbol(s.get("symbol"))
                if not sym:
                    continue

                price_val = s.get("price")
                cur = _safe_float(price_val)
                if cur is None:
                    cur = price_index.get(sym)

                if cur is None or cur <= 0:
                    continue

                strength_val = s.get("strength")
                strength = _safe_int(strength_val)
                if strength is None:
                    continue

                pred = cur * (1 + (strength - 50) / 100)

                entry: dict[str, Any] = {
                    "id": (f"tech_pred_{sym}_{int(datetime.now(timezone.utc).timestamp())}"),
                    "symbol": sym,
                    "predictedPrice": round(pred, 6),
                    "currentPrice": round(cur, 6),
                    "confidence": min(max(strength, 0), 95),
                    "timeframe": "24H",
                    "timestamp": _utc_iso(),
                    "source": "Technical Analysis",
                }

                if strength > 50:
                    entry["direction"] = "UP"
                else:
                    entry["direction"] = "DOWN"

                signal_type = s.get("signal_type")
                reasoning_parts = [f"Technical strength: {strength}"]
                if signal_type:
                    reasoning_parts.append(f"Signal type: {signal_type}")
                entry["reasoning"] = ", ".join(reasoning_parts)

                predictions.append(entry)
            except Exception as e:
                logger.exception(f"prediction-format technical error: {e}")
                continue
    except Exception as e:
        logger.exception(f"Error getting AI predictions: {e}")
        raise HTTPException(status_code=500, detail="Failed to get AI predictions") from e
    else:
        return predictions


@router.post("/train")
async def train_ai_model(data: dict[str, Any]) -> dict[str, Any]:
    """Train AI model for predictions."""
    # Validate symbol before try block to avoid TRY301
    req_symbol = data.get("symbol")
    symbol = _norm_symbol(req_symbol) if req_symbol else None
    if not symbol:
        raise HTTPException(status_code=400, detail="Invalid or missing symbol")

    try:
        timeframe_val = data.get("timeframe")
        timeframe = str(timeframe_val).upper() if timeframe_val else None

        scored_signals_list = signal_scorer()
        if not isinstance(scored_signals_list, list):
            scored_signals_list = []

        risk_signals_list = risk_adjusted_signals()
        if not isinstance(risk_signals_list, list):
            risk_signals_list = []

        tech_signals_list = technical_signals()
        if not isinstance(tech_signals_list, list):
            tech_signals_list = []

        total = len(scored_signals_list) + len(risk_signals_list) + len(tech_signals_list)

        hi = 0
        for s in scored_signals_list:
            _, score = _extract_scorer(s)
            if score is not None and score > 80:
                hi += 1

        for s in risk_signals_list:
            if not isinstance(s, dict):
                continue
            score_val = s.get("score")
            score = _safe_int(score_val)
            if score is not None and score > 80:
                hi += 1

        for s in tech_signals_list:
            if not isinstance(s, dict):
                continue
            strength_val = s.get("strength")
            strength = _safe_int(strength_val)
            if strength is not None and strength > 80:
                hi += 1

        response: dict[str, Any] = {
            "success": True,
            "symbol": symbol,
            "total_signals": total,
            "high_confidence_signals": hi,
        }

        if timeframe:
            response["timeframe"] = timeframe

        if total > 0:
            accuracy = round((hi / total * 100.0), 1)
            response["accuracy"] = accuracy

        message_parts = [f"AI model analysis completed for {symbol}"]
        if timeframe:
            message_parts.append(f"on {timeframe} timeframe")
        response["message"] = " ".join(message_parts)
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error training AI model: {e}")
        raise HTTPException(status_code=500, detail="Failed to train AI model") from e
    else:
        return response


@router.get("/signals/history")
async def get_signal_history(hours: int = 12) -> dict[str, Any]:
    """Get historical AI signals for comparison - LIVE PRODUCTION"""
    try:
        import sqlite3
        from datetime import datetime, timedelta

        # Calculate time range
        since_time = datetime.now(timezone.utc) - timedelta(hours=hours)

        conn = sqlite3.connect(DATABASE_PATH)
        try:
            cursor = conn.cursor()

            # Get signals from the last N hours
            cursor.execute(
                """
                SELECT symbol, side, reason, price, created_at
                FROM ai_live_signals
                WHERE created_at > ?
                ORDER BY created_at DESC
            """,
                (since_time.isoformat(),),
            )

            signals = cursor.fetchall()
        finally:
            conn.close()

        # Format signals for response
        formatted_signals = []
        for signal in signals:
            symbol, side, reason, price, created_at = signal
            formatted_signals.append({"symbol": symbol, "action": side.upper(), "reason": reason, "price": price, "timestamp": created_at, "source": "historical_ai_signal"})

        # Group by symbol for comparison
        symbol_summary = {}
        for signal in formatted_signals:
            symbol = signal["symbol"]
            if symbol not in symbol_summary:
                symbol_summary[symbol] = {"total_signals": 0, "buy_signals": 0, "sell_signals": 0, "hold_signals": 0, "last_signal": None, "first_signal": None}

            symbol_summary[symbol]["total_signals"] += 1
            action = signal["action"]
            if action == "BUY":
                symbol_summary[symbol]["buy_signals"] += 1
            elif action == "SELL":
                symbol_summary[symbol]["sell_signals"] += 1
            elif action == "HOLD":
                symbol_summary[symbol]["hold_signals"] += 1

            # Track first and last signals
            if symbol_summary[symbol]["first_signal"] is None:
                symbol_summary[symbol]["first_signal"] = signal
            symbol_summary[symbol]["last_signal"] = signal

        return {
            "timestamp": _utc_iso(),
            "hours_analyzed": hours,
            "total_signals": len(formatted_signals),
            "signals": formatted_signals,
            "symbol_summary": symbol_summary,
            "source": "live_production_database",
        }

    except Exception as e:
        logger.exception(f"Error getting signal history: {e}")
        raise HTTPException(status_code=500, detail="Failed to get signal history") from e


@router.post("/signals/generate-test")
async def generate_test_signals() -> dict[str, Any]:
    """Generate and save test AI signals to verify database persistence - LIVE PRODUCTION"""
    try:
        import redis
        from backend.services.ai_signal_generator import get_signal_generator

        # Get signal generator
        gen = get_signal_generator()

        # Generate test signals for a few symbols
        test_symbols = ["BTCUSDT", "ETHUSDT", "ADAUSDT"]
        results = []

        for symbol in test_symbols:
            try:
                # Trigger signal generation (this should save to both Redis and DB)
                await gen._generate_signal_for_symbol(symbol)
                results.append(f"Generated signal for {symbol}")
            except Exception as e:
                results.append(f"Failed to generate signal for {symbol}: {e}")

        # Check what was saved (sync Redis in thread)
        def _count_redis_signals():
            redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
            r = redis.from_url(redis_url, decode_responses=True)
            try:
                return len(list(r.scan_iter(match="ai_signal:*", count=100)))
            finally:
                r.close()

        redis_signals = await asyncio.to_thread(_count_redis_signals)

        import sqlite3

        conn = sqlite3.connect(DATABASE_PATH)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM ai_live_signals WHERE symbol IN ('BTCUSDT', 'ETHUSDT', 'ADAUSDT')")
            db_count = cursor.fetchone()[0]
        finally:
            conn.close()

        return {
            "timestamp": _utc_iso(),
            "message": "Test signal generation completed",
            "results": results,
            "redis_signals": redis_signals,
            "database_signals": db_count,
            "source": "live_production_test",
        }

    except Exception as e:
        logger.exception(f"Error in test signal generation: {e}")
        raise HTTPException(status_code=500, detail="Failed to generate test signals") from e


@router.get("/signals/compare")
async def compare_signals(hours_ago: int = 12) -> dict[str, Any]:
    """Compare current signals with historical signals from N hours ago - LIVE PRODUCTION"""
    try:
        import sqlite3
        from datetime import datetime, timedelta

        # Get historical signals
        historical_since = datetime.now(timezone.utc) - timedelta(hours=hours_ago)
        historical_until = datetime.now(timezone.utc) - timedelta(hours=hours_ago - 1)  # 1-hour window

        conn = sqlite3.connect(DATABASE_PATH)
        try:
            cursor = conn.cursor()

            # Get signals from the specific hour window
            cursor.execute(
                """
                SELECT symbol, side, reason, price, created_at
                FROM ai_live_signals
                WHERE created_at BETWEEN ? AND ?
                ORDER BY created_at DESC
            """,
                (historical_since.isoformat(), historical_until.isoformat()),
            )

            historical_signals = cursor.fetchall()
        finally:
            conn.close()

        # Get current signals from Redis (sync in thread)
        def _fetch_current_signals_sync():
            import redis
            from backend.services.confidence_normalizer import ConfidenceNormalizer

            out = {}
            redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
            r = redis.from_url(redis_url, decode_responses=True)
            try:
                ai_keys = list(r.scan_iter(match="ai_signal:*", count=100))
                for key in ai_keys:
                    data = r.hgetall(key)
                    symbol = key.replace("ai_signal:", "")
                    raw_c = float(data.get("confidence", 0) or 0)
                    try:
                        conf = ConfidenceNormalizer.normalize(raw_c)
                    except Exception as ex:
                        logger.debug("ConfidenceNormalizer unavailable: %s", ex)
                        conf = raw_c
                    out[symbol] = {
                        "action": data.get("prediction", "UNKNOWN"),
                        "confidence": conf,
                        "timestamp": data.get("timestamp", "unknown"),
                        "source": "current_redis",
                    }
                return out
            finally:
                r.close()

        try:
            current_signals = await asyncio.to_thread(_fetch_current_signals_sync)
        except Exception as e:
            logger.warning("Could not fetch current signals from Redis: %s", e)
            current_signals = {}

        # Format historical signals
        formatted_historical = []
        for signal in historical_signals:
            symbol, side, reason, price, created_at = signal
            formatted_historical.append({"symbol": symbol, "action": side.upper(), "reason": reason, "price": price, "timestamp": created_at, "source": "historical_database"})

        # Create comparison
        comparison = {}
        all_symbols = set([s["symbol"] for s in formatted_historical] + list(current_signals.keys()))

        for symbol in all_symbols:
            historical_for_symbol = [s for s in formatted_historical if s["symbol"] == symbol]
            current_for_symbol = current_signals.get(symbol)

            comparison[symbol] = {
                "historical_signals": len(historical_for_symbol),
                "historical_actions": [s["action"] for s in historical_for_symbol],
                "current_signal": current_for_symbol["action"] if current_for_symbol else None,
                "current_confidence": current_for_symbol["confidence"] if current_for_symbol else None,
                "signal_changed": False,
            }

            # Check if signal changed
            if historical_for_symbol and current_for_symbol:
                last_historical = historical_for_symbol[0]["action"]  # Most recent historical
                current = current_for_symbol["action"]
                comparison[symbol]["signal_changed"] = last_historical != current

        return {
            "timestamp": _utc_iso(),
            "comparison_period": f"{hours_ago} hours ago (1-hour window)",
            "current_signals": current_signals,
            "historical_signals": formatted_historical,
            "comparison": comparison,
            "summary": {
                "total_historical_signals": len(formatted_historical),
                "total_current_signals": len(current_signals),
                "symbols_with_changes": sum(1 for c in comparison.values() if c["signal_changed"]),
            },
            "source": "live_production_comparison",
        }

    except Exception as e:
        logger.exception(f"Error comparing signals: {e}")
        raise HTTPException(status_code=500, detail="Failed to compare signals") from e


@router.get("/trends")
async def get_market_trends() -> dict[str, Any]:
    """Get market trends and analysis."""
    try:
        response: dict[str, Any] = {
            "timestamp": _utc_iso(),
        }

        trend_data: dict[str, Any] = {}
        try:
            trend_result = trend_analysis()
            if isinstance(trend_result, dict):
                trend_data = trend_result
        except Exception as e:
            logger.warning(f"Trend analysis not available: {e}")

        if trend_data:
            response["trend_analysis"] = trend_data

        oracle_data: dict[str, Any] = {}
        try:
            oracle_result = mystic_oracle()
            if isinstance(oracle_result, dict):
                oracle_data = oracle_result
        except Exception as e:
            logger.warning(f"Mystic oracle not available: {e}")

        if oracle_data:
            response["oracle_insights"] = oracle_data

        market_strength_dict = market_strength_signals()
        if isinstance(market_strength_dict, dict) and market_strength_dict:
            response["market_strength"] = market_strength_dict
    except Exception as e:
        logger.exception(f"Error getting market trends: {e}")
        raise HTTPException(status_code=500, detail="Failed to get market trends") from e
    else:
        return response


@router.get("/signals/analysis")
async def get_ai_signals_analysis() -> dict[str, Any]:
    """Get AI signal analysis (risk_adjusted + technical). Use /api/ai/signals for dashboard signals feed."""
    try:
        response: dict[str, Any] = {
            "timestamp": _utc_iso(),
        }

        # Get risk-adjusted signals
        risk_signals_list = risk_adjusted_signals()
        if isinstance(risk_signals_list, list):
            risk_adjusted_formatted = []
            for s in risk_signals_list[:20]:  # Limit to 20 signals
                if not isinstance(s, dict):
                    continue

                signal_entry: dict[str, Any] = {
                    "action": s.get("signal", s.get("action", "HOLD")),
                    "confidence": int(s.get("confidence", s.get("score", 50))),
                    "strength": "STRONG" if s.get("confidence", s.get("score", 50)) > 80 else "WEAK",
                    "symbol": s.get("symbol", ""),
                    "timestamp": _utc_iso(),
                }
                risk_adjusted_formatted.append(signal_entry)

            response["risk_adjusted"] = risk_adjusted_formatted

        # Get technical signals as additional data
        tech_signals_list = technical_signals()
        if isinstance(tech_signals_list, list):
            technical_formatted = []
            for s in tech_signals_list[:10]:  # Limit to 10 signals
                if not isinstance(s, dict):
                    continue

                signal_entry: dict[str, Any] = {
                    "action": s.get("signal", "HOLD"),
                    "confidence": int(s.get("strength", s.get("confidence", 50))),
                    "strength": "STRONG" if s.get("strength", s.get("confidence", 50)) > 75 else "WEAK",
                    "symbol": s.get("symbol", ""),
                    "timestamp": _utc_iso(),
                }
                technical_formatted.append(signal_entry)

            response["technical"] = technical_formatted

        # Get basic signal counts
        scored_signals_list = signal_scorer()
        if isinstance(scored_signals_list, list):
            response["total_signals"] = len(scored_signals_list)
            response["active_signals"] = len([s for s in scored_signals_list if _extract_scorer(s)[1] and _extract_scorer(s)[1] > 60])

    except Exception as e:
        logger.exception(f"Error getting AI signals: {e}")
        raise HTTPException(status_code=500, detail="Failed to get AI signals") from e
    else:
        return response
