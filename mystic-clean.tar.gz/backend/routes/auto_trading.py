"""
Auto Trading Endpoints

Auto trading control and management with advanced signal filtering.
- Live data only (no fabricated fallbacks)
- Binance US only
"""

from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException

from backend.ai.auto_trade import (
    BinanceUSAPI,
    disable_trading,
    enable_trading,
    get_account_balance,
    get_market_data,
    get_trading_status,
)
from backend.config.trading_universe import EXCHANGE_ID, TRADING_SYMBOLS
from backend.services.canonical_signal_snapshot import build_canonical_signal_rows

# Try to import AUTO_BUY_CONFIG for configuration endpoint
try:
    from backend.config import AUTO_BUY_CONFIG
except (ImportError, ModuleNotFoundError):
    AUTO_BUY_CONFIG = None
from backend.modules.ai.ai_signals import (
    market_strength_signals,
    mystic_oracle,
    risk_adjusted_signals,
    signal_scorer,
    technical_signals,
    trend_analysis,
)
from backend.modules.ai.trade_tracker import (
    get_active_trades,
    get_trade_history,
    get_trade_summary,
    record_entry,
)
from backend.services.canonical_cache import canonical_cache as cache
from backend.services.canonical_cache import (
    canonical_cache as get_shared_cache,
)
from backend.services.confidence_normalizer import ConfidenceNormalizer

# Lazy imports for optional AI services (may not be available in all deployments)
try:
    from backend.modules.ai.ai_model_versioning import get_ai_model_versioning
except ImportError:
    get_ai_model_versioning = None  # type: ignore[assignment, misc]

try:
    from backend.ai_training_pipeline import get_ai_training_pipeline
except ImportError:
    get_ai_training_pipeline = None  # type: ignore[assignment, misc]

try:
    from backend.experimental_integration import get_experimental_integration
except ImportError:
    get_experimental_integration = None  # type: ignore[assignment, misc]

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/autobuy", tags=["auto-trading"])

# SINGLE SOURCE OF TRUTH - Binance US only
ALLOWED_SYMBOLS = list(TRADING_SYMBOLS)  # Use TRADING_SYMBOLS from trading_universe (live data)
ALLOWED_BASES = {s[:-4] for s in ALLOWED_SYMBOLS}


def _utc_iso() -> str:
    """Get current timestamp in ISO format."""
    return datetime.now(timezone.utc).isoformat()


def _norm_symbol(sym: str | None) -> str | None:
    """Normalize symbol to Binance USDT format."""
    if not sym:
        return None
    s = sym.upper().replace("-", "").replace("/", "").replace(" ", "")
    if s.endswith("USD") and not s.endswith("USDT"):
        s = s[:-3] + "USDT"
    if s in ALLOWED_SYMBOLS:
        return s
    if s in ALLOWED_BASES:
        s2 = s + "USDT"
        return s2 if s2 in ALLOWED_SYMBOLS else None
    return None


def _safe_int(x: Any) -> int | None:
    """Convert to int - returns None if unavailable."""
    try:
        return int(x)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError):
        return None


def _safe_float(x: Any) -> float | None:
    """Convert to float - returns None if unavailable."""
    try:
        return float(x)
    except (ValueError, TypeError, AttributeError, KeyError, IndexError):
        return None


def _extract_scorer(signal_text: str) -> tuple[str | None, int | None]:
    """Extract symbol and score from signal text."""
    if not signal_text:
        return None, None
    parts = signal_text.strip().split()
    if not parts:
        return None, None
    sym = _norm_symbol(parts[0])
    score = None
    for p in parts[1:]:
        v = _safe_int(p)
        if v is not None and 0 <= v <= 100:
            score = v
            break
    return sym, score


class AdvancedSignalFilter:
    """Advanced signal filtering for higher win percentage."""

    def __init__(self) -> None:
        self.signal_history: dict[str, list[dict[str, Any]]] = {}
        self.confirmation_threshold = 3
        self.min_confidence = 75
        self.volume_threshold = 1.5
        self.volatility_threshold = 0.02
        self.trend_confirmation = True
        self.whale_activity_check = True

    def validate_signal(self, signal: dict[str, Any]) -> dict[str, Any]:
        """Validate signal and calculate score."""
        score = 0
        reasons: list[str] = []

        raw_conf = signal.get("confidence")
        try:
            conf = ConfidenceNormalizer.normalize(float(raw_conf)) if raw_conf is not None else None
        except (TypeError, ValueError):
            conf = None
        min_norm = self.min_confidence / 100.0 if self.min_confidence > 1 else self.min_confidence
        if conf is not None and conf >= min_norm:
            score += 25
            reasons.append("High confidence")
        else:
            reasons.append("Low confidence")

        vol_ratio = _safe_float(signal.get("volume_ratio"))
        if vol_ratio is not None and vol_ratio >= self.volume_threshold:
            score += 20
            reasons.append("High volume")
        else:
            reasons.append("Low volume")

        volty = _safe_float(signal.get("volatility"))
        if volty is not None and volty >= self.volatility_threshold:
            score += 15
            reasons.append("Good volatility")
        else:
            reasons.append("Low volatility")

        if bool(signal.get("trend_aligned", False)):
            score += 20
            reasons.append("Trend aligned")
        else:
            reasons.append("Trend misaligned")

        tech_score = self._check_technical_indicators(signal)
        score += tech_score
        reasons.append(f"Technical score: {tech_score}")

        sentiment_score = self._check_market_sentiment(signal)
        score += sentiment_score
        reasons.append(f"Sentiment score: {sentiment_score}")

        if bool(signal.get("whale_activity", False)):
            score += 10
            reasons.append("Whale activity detected")

        return {
            "original_signal": signal,
            "score": score,
            "approved": score >= 70,
            "reasons": reasons,
            "timestamp": _utc_iso(),
        }

    def _check_technical_indicators(self, signal: dict[str, Any]) -> int:
        """Check technical indicators."""
        score = 0
        rsi = _safe_int(signal.get("rsi"))
        if rsi is not None and 30 <= rsi <= 70:
            score += 5
        if bool(signal.get("macd_bullish", False)):
            score += 5
        bb_pos = _safe_float(signal.get("bb_position"))
        if bb_pos is not None and bb_pos > 0.3:
            score += 5
        if bool(signal.get("ma_aligned", False)):
            score += 5
        return score

    def _check_market_sentiment(self, signal: dict[str, Any]) -> int:
        """Check market sentiment."""
        score = 0
        fear_greed = _safe_int(signal.get("fear_greed_index"))
        if fear_greed is not None and 20 <= fear_greed <= 80:
            score += 5
        social_sent = _safe_float(signal.get("social_sentiment"))
        if social_sent is not None and social_sent > 0.6:
            score += 5
        news_sent = _safe_float(signal.get("news_sentiment"))
        if news_sent is not None and news_sent > 0.5:
            score += 5
        return score

    async def get_signal_history(self, symbol: str) -> list[dict[str, Any]]:
        """Get signal history for symbol."""
        await asyncio.sleep(0.05)
        return self.signal_history.get(symbol, [])


signal_filter = AdvancedSignalFilter()


@router.get("/ai-status")
async def get_autobuy_ai_status() -> dict[str, Any]:
    """Get AutoBuy AI status."""
    try:
        trading_status = get_trading_status()

        if not isinstance(trading_status, dict):
            return {
                "status": "error",
                "error": "Invalid trading status format",
                "timestamp": _utc_iso(),
            }

        ai_status: dict[str, Any] = {
            "timestamp": _utc_iso(),
        }

        enabled = trading_status.get("enabled")
        if enabled is not None:
            ai_status["enabled"] = enabled
            ai_status["active_strategies"] = 1 if enabled else 0

        last_signal = trading_status.get("last_signal")
        if last_signal is not None:
            ai_status["last_signal"] = last_signal

        # Try to get AI performance from cache (get_shared_cache is the cache object, not a function)
        if get_shared_cache:
            try:
                ai_data = await get_shared_cache.get("ai_performance")
                if isinstance(ai_data, dict):
                    accuracy = ai_data.get("accuracy")
                    if accuracy is not None:
                        ai_status["performance"] = float(accuracy)
            except Exception:
                pass

        return {"ai_status": ai_status, "timestamp": _utc_iso()}
    except Exception as e:
        logger.exception(f"Error getting AutoBuy AI status: {e}")
        return {
            "status": "error",
            "error": str(e),
            "timestamp": _utc_iso(),
        }


@router.post("/start")
async def start_auto_buy(data: dict[str, Any]) -> dict[str, Any]:
    """Start auto trading."""
    try:
        enable_trading()

        enhanced_config: dict[str, Any] = {
            **data,
            "signal_filtering": True,
            "multi_confirmation": True,
            "risk_management": True,
            "position_sizing": True,
            "stop_loss_dynamic": True,
            "take_profit_dynamic": True,
        }

        max_daily_loss = _safe_float(data.get("max_daily_loss"))
        if max_daily_loss is not None:
            enhanced_config["max_daily_loss"] = max_daily_loss

        max_concurrent = _safe_int(data.get("max_concurrent_positions"))
        if max_concurrent is not None:
            enhanced_config["max_concurrent_positions"] = max_concurrent

        min_score = _safe_int(data.get("min_signal_score"))
        if min_score is not None:
            enhanced_config["min_signal_score"] = min_score

        conf_threshold = _safe_int(data.get("confirmation_threshold"))
        if conf_threshold is not None:
            enhanced_config["confirmation_threshold"] = conf_threshold

        return {
            "success": True,
            "message": "Advanced auto trading started successfully",
            "config": enhanced_config,
            "trading_enabled": True,
            "timestamp": _utc_iso(),
        }
    except Exception as e:
        logger.exception(f"Error starting auto buy: {e}")
        raise HTTPException(status_code=500, detail="Failed to start auto buy") from e


@router.post("/validate-signal")
async def validate_signal(
    signal: dict[str, Any],
) -> dict[str, Any]:
    """Validate a trading signal."""
    # Validate symbol before try block to avoid TRY301
    sym = _norm_symbol(signal.get("symbol"))
    if not sym:
        raise HTTPException(status_code=400, detail="Invalid or unsupported symbol")

    try:
        signal = {**signal, "symbol": sym}
        return signal_filter.validate_signal(signal)
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error validating signal: {e}")
        raise HTTPException(status_code=500, detail="Failed to validate signal") from e


@router.post("/execute")
async def execute_trade(signal: dict[str, Any]) -> dict[str, Any]:
    """Execute a trade."""
    try:
        sym = _norm_symbol(signal.get("symbol"))
        if not sym:
            return {
                "success": False,
                "message": ("Signal rejected - invalid/unsupported symbol"),
                "reasons": ["Unsupported symbol"],
            }

        signal_data: dict[str, Any] = {
            **signal,
            "symbol": sym,
        }

        price_val = signal.get("price")
        if price_val is not None:
            price = _safe_float(price_val)
            if price is not None:
                signal_data["price"] = price

        amount_val = signal.get("amount")
        if amount_val is not None:
            amount = _safe_float(amount_val)
            if amount is not None:
                signal_data["amount"] = amount

        validated = signal_filter.validate_signal(signal_data)
        if not validated.get("approved"):
            return {
                "success": False,
                "message": "Signal rejected - insufficient score",
                "score": validated.get("score"),
                "reasons": validated.get("reasons"),
            }

        scored_signals_list = signal_scorer()
        if not isinstance(scored_signals_list, list):
            scored_signals_list = []

        risk_signals_list = risk_adjusted_signals()
        if not isinstance(risk_signals_list, list):
            risk_signals_list = []

        technical_signals_list = technical_signals()
        if not isinstance(technical_signals_list, list):
            technical_signals_list = []

        confirmed = False

        for ss in scored_signals_list:
            s_sym, s_score = _extract_scorer(ss)
            if s_sym == sym and s_score is not None and s_score > 80:
                confirmed = True
                break

        if not confirmed:
            for rs in risk_signals_list:
                if not isinstance(rs, dict):
                    continue
                rs_sym = _norm_symbol(rs.get("symbol"))
                if rs_sym == sym:
                    rs_score = _safe_int(rs.get("score"))
                    if rs_score is not None and rs_score > 80:
                        confirmed = True
                        break

        if not confirmed:
            for ts in technical_signals_list:
                if not isinstance(ts, dict):
                    continue
                ts_sym = _norm_symbol(ts.get("symbol"))
                if ts_sym == sym:
                    ts_strength = _safe_int(ts.get("strength"))
                    if ts_strength is not None and ts_strength > 80:
                        confirmed = True
                        break

        if not confirmed:
            reasons = validated.get("reasons", [])
            reasons.append("Not confirmed by AI")
            return {
                "success": False,
                "message": "Signal not confirmed by AI systems",
                "score": validated.get("score"),
                "reasons": reasons,
            }

        market_strength_dict = market_strength_signals()
        if not isinstance(market_strength_dict, dict):
            market_strength_dict = {}

        t_data: dict[str, Any] = {}
        try:
            trend_result = trend_analysis()
            if isinstance(trend_result, dict):
                t_data = trend_result
        except Exception as e:
            logger.warning(f"Trend analysis not available: {e}")

        o_data: dict[str, Any] = {}
        try:
            oracle_result = mystic_oracle()
            if isinstance(oracle_result, dict):
                o_data = oracle_result
        except Exception as e:
            logger.warning(f"Mystic oracle not available: {e}")

        return await _execute_trade_with_comprehensive_risk_management(signal_data, validated, market_strength_dict, t_data, o_data)
    except Exception as e:
        logger.exception(f"Error executing trade: {e}")
        raise HTTPException(status_code=500, detail="Failed to execute trade") from e


async def _check_multi_confirmation(symbol: str, _signal: dict[str, Any]) -> bool:
    """Check multi-source confirmation."""
    try:
        sym = _norm_symbol(symbol)
        if not sym:
            return False

        scored_signals_list = signal_scorer()
        if not isinstance(scored_signals_list, list):
            scored_signals_list = []

        risk_signals_list = risk_adjusted_signals()
        if not isinstance(risk_signals_list, list):
            risk_signals_list = []

        technical_signals_list = technical_signals()
        if not isinstance(technical_signals_list, list):
            technical_signals_list = []

        confirmations = 0

        for ss in scored_signals_list:
            s_sym, _ = _extract_scorer(ss)
            if s_sym == sym:
                confirmations += 1
                break

        for rs in risk_signals_list:
            if not isinstance(rs, dict):
                continue
            if _norm_symbol(rs.get("symbol")) == sym:
                confirmations += 1
                break

        for ts in technical_signals_list:
            if not isinstance(ts, dict):
                continue
            if _norm_symbol(ts.get("symbol")) == sym:
                confirmations += 1
                break
    except Exception as e:
        logger.exception(f"Error checking multi confirmation: {e}")
        return False
    else:
        return confirmations >= 2


async def _execute_trade_with_comprehensive_risk_management(
    signal: dict[str, Any],
    validated: dict[str, Any],
    market_strength: dict[str, Any],
    trend_data: dict[str, Any],
    oracle_data: dict[str, Any],
) -> dict[str, Any]:
    """Execute trade with comprehensive risk management."""
    try:
        symbol = signal.get("symbol", "")
        price_val = signal.get("price")
        amount_val = signal.get("amount")

        if price_val is None or amount_val is None:
            return {
                "success": False,
                "message": "Missing price or amount",
                "timestamp": _utc_iso(),
            }

        price = _safe_float(price_val)
        amount = _safe_float(amount_val)

        if price is None or amount is None or price <= 0:
            return {
                "success": False,
                "message": "Invalid price or amount",
                "timestamp": _utc_iso(),
            }

        risk_per_trade = 0.02
        position_size = amount * risk_per_trade

        stop_loss = price * 0.95
        take_profit = price * 1.10

        market_recommendation_val = market_strength.get("recommendation")
        if market_recommendation_val == "BULLISH":
            position_size *= 1.2
        elif market_recommendation_val == "BEARISH":
            position_size *= 0.8

        try:
            record_entry(symbol, position_size, price)
        except Exception as e:
            logger.exception(f"record_entry failed: {e}")

        trade_details: dict[str, Any] = {
            "symbol": symbol,
            "price": price,
            "amount": position_size,
            "stop_loss": stop_loss,
            "take_profit": take_profit,
            "ai_score": validated.get("score"),
        }

        if market_recommendation_val:
            trade_details["market_recommendation"] = market_recommendation_val

        trend_summary = trend_data.get("summary")
        if trend_summary is not None:
            trade_details["trend_analysis"] = trend_summary

        oracle_pred = oracle_data.get("prediction")
        if oracle_pred is not None:
            trade_details["oracle_insight"] = oracle_pred

        return {
            "success": True,
            "message": f"Trade executed successfully for {symbol}",
            "trade_details": trade_details,
            "timestamp": _utc_iso(),
        }
    except Exception as e:
        logger.exception(f"Error in comprehensive trade execution: {e}")
        return {
            "success": False,
            "message": f"Trade execution failed: {e}",
            "timestamp": _utc_iso(),
        }


@router.post("/stop")
async def stop_auto_buy() -> dict[str, Any]:
    """Stop auto trading."""
    try:
        disable_trading()
        return {
            "success": True,
            "message": "Auto trading stopped successfully",
            "trading_enabled": False,
            "timestamp": _utc_iso(),
        }
    except Exception as e:
        logger.exception(f"Error stopping auto buy: {e}")
        raise HTTPException(status_code=500, detail="Failed to stop auto buy") from e


@router.get("/auto-trading/status")
async def get_auto_buy_status() -> dict[str, Any]:
    """Get auto trading status."""
    try:
        trading_status = get_trading_status()
        trade_summary = get_trade_summary()

        active_trades_result = get_active_trades()
        if isinstance(active_trades_result, list):
            active_trades_dict = {t.get("symbol", f"trade_{i}"): t for i, t in enumerate(active_trades_result) if isinstance(t, dict)}
        elif isinstance(active_trades_result, dict):
            active_trades_dict = active_trades_result
        else:
            active_trades_dict = {}

        scored_signals_list = signal_scorer()
        if not isinstance(scored_signals_list, list):
            scored_signals_list = []

        risk_signals_list = risk_adjusted_signals()
        if not isinstance(risk_signals_list, list):
            risk_signals_list = []

        technical_signals_list = technical_signals()
        if not isinstance(technical_signals_list, list):
            technical_signals_list = []

        market_strength_dict = market_strength_signals()
        if not isinstance(market_strength_dict, dict):
            market_strength_dict = {}

        response: dict[str, Any] = {
            "active_trades": len(active_trades_dict),
            "timestamp": _utc_iso(),
        }

        if isinstance(trading_status, dict):
            trading_enabled = trading_status.get("trading_enabled")
            if trading_enabled is not None:
                response["trading_enabled"] = trading_enabled

            cache_status = trading_status.get("cache_status")
            if isinstance(cache_status, dict):
                response["cache_status"] = cache_status

            last_update = trading_status.get("last_update")
            if last_update is not None:
                response["last_update"] = last_update

        if isinstance(trade_summary, dict):
            total_trades = trade_summary.get("total_trades")
            if total_trades is not None:
                response["total_trades"] = total_trades

            total_pnl = trade_summary.get("total_pnl")
            if total_pnl is not None:
                response["total_profit"] = total_pnl

            win_rate = trade_summary.get("win_rate")
            if win_rate is not None:
                response["win_rate"] = win_rate

        ai_signals: dict[str, Any] = {
            "scored_signals": len(scored_signals_list),
            "risk_signals": len(risk_signals_list),
            "technical_signals": len(technical_signals_list),
        }

        market_strength_val = market_strength_dict.get("market_strength")
        if market_strength_val is not None:
            ai_signals["market_strength"] = market_strength_val

        market_rec = market_strength_dict.get("recommendation")
        if market_rec is not None:
            ai_signals["market_recommendation"] = market_rec

        response["ai_signals"] = ai_signals

    except Exception as e:
        logger.exception(f"Error getting auto buy status: {e}")
        raise HTTPException(status_code=500, detail="Failed to get auto buy status") from e
    else:
        return response


@router.get("/performance")
async def get_auto_buy_performance() -> dict[str, Any]:
    """Get auto trading performance."""
    try:
        trade_summary = get_trade_summary()
        active_trades_result = get_active_trades()
        if isinstance(active_trades_result, list):
            active_trades_dict = {t.get("symbol", f"trade_{i}"): t for i, t in enumerate(active_trades_result) if isinstance(t, dict)}
        elif isinstance(active_trades_result, dict):
            active_trades_dict = active_trades_result
        else:
            active_trades_dict = {}

        hist = get_trade_history(limit=50)
        if asyncio.iscoroutine(hist):
            trade_history_list = await hist
        else:
            trade_history_list = hist

        if not isinstance(trade_history_list, list):
            trade_history_list = []

        response: dict[str, Any] = {
            "active_trades": len(active_trades_dict),
            "timestamp": _utc_iso(),
        }

        if isinstance(trade_summary, dict):
            total_trades = trade_summary.get("total_trades")
            if total_trades is not None:
                response["total_trades"] = total_trades

            profitable_trades = trade_summary.get("profitable_trades")
            if profitable_trades is not None:
                response["profitable_trades"] = profitable_trades

            total_pnl = trade_summary.get("total_pnl")
            if total_pnl is not None:
                response["total_profit"] = round(float(total_pnl), 2)

            win_rate = trade_summary.get("win_rate")
            if win_rate is not None:
                response["win_rate"] = round(float(win_rate), 2)

            avg_pnl = trade_summary.get("avg_pnl")
            if avg_pnl is not None:
                response["average_profit"] = round(float(avg_pnl), 2)

        active_value_sum = 0.0
        try:
            for t in active_trades_dict.values():
                if not isinstance(t, dict):
                    continue
                amount_val = _safe_float(t.get("amount"))
                buy_price_val = _safe_float(t.get("buy_price"))
                if amount_val is not None and buy_price_val is not None:
                    active_value_sum += amount_val * buy_price_val
        except Exception:
            pass

        if active_value_sum > 0:
            response["active_value"] = round(active_value_sum, 2)

        recent_trades = trade_history_list[-10:] if trade_history_list else []

        if recent_trades:
            recent_perf: dict[str, Any] = {
                "recent_trades": len(recent_trades),
            }

            recent_pnl_sum = 0.0
            wins = 0
            for t in recent_trades:
                if not isinstance(t, dict):
                    continue
                profit_loss_val = _safe_float(t.get("profit_loss"))
                if profit_loss_val is not None:
                    recent_pnl_sum += profit_loss_val
                    if profit_loss_val > 0:
                        wins += 1

            if recent_pnl_sum != 0:
                recent_perf["recent_pnl"] = round(recent_pnl_sum, 2)

            if len(recent_trades) > 0:
                recent_win_rate = round(wins / len(recent_trades) * 100.0, 2)
                recent_perf["recent_win_rate"] = recent_win_rate

            response["recent_performance"] = recent_perf

    except Exception as e:
        logger.exception(f"Error getting auto buy performance: {e}")
        raise HTTPException(status_code=500, detail="Failed to get auto buy performance") from e
    else:
        return response


@router.get("/ml-status")
async def get_ml_status() -> dict[str, Any]:
    """Get ML model status."""
    try:
        scored_signals_list = signal_scorer()
        if not isinstance(scored_signals_list, list):
            scored_signals_list = []

        risk_signals_list = risk_adjusted_signals()
        if not isinstance(risk_signals_list, list):
            risk_signals_list = []

        technical_signals_list = technical_signals()
        if not isinstance(technical_signals_list, list):
            technical_signals_list = []

        market_strength_dict = market_strength_signals()
        if not isinstance(market_strength_dict, dict):
            market_strength_dict = {}

        total_signals = len(scored_signals_list) + len(risk_signals_list) + len(technical_signals_list)

        hi = 0
        for s in scored_signals_list:
            _, sc = _extract_scorer(s)
            if sc is not None and sc > 80:
                hi += 1

        for s in risk_signals_list:
            if not isinstance(s, dict):
                continue
            s_score = _safe_int(s.get("score"))
            if s_score is not None and s_score > 80:
                hi += 1

        for s in technical_signals_list:
            if not isinstance(s, dict):
                continue
            s_strength = _safe_int(s.get("strength"))
            if s_strength is not None and s_strength > 80:
                hi += 1

        response: dict[str, Any] = {
            "models": {},
            "overall_performance": {
                "total_signals": total_signals,
                "high_confidence_signals": hi,
            },
            "timestamp": _utc_iso(),
        }

        signal_scorer_model: dict[str, Any] = {
            "status": "ACTIVE",
            "signals": len(scored_signals_list),
        }
        response["models"]["signal_scorer"] = signal_scorer_model

        risk_assessor_model: dict[str, Any] = {
            "status": "ACTIVE",
            "signals": len(risk_signals_list),
        }
        response["models"]["risk_assessor"] = risk_assessor_model

        technical_analyzer_model: dict[str, Any] = {
            "status": "ACTIVE",
            "signals": len(technical_signals_list),
        }
        response["models"]["technical_analyzer"] = technical_analyzer_model

        market_strength_model: dict[str, Any] = {
            "status": "ACTIVE",
        }
        market_strength_val = market_strength_dict.get("market_strength")
        if market_strength_val is not None:
            market_strength_model["strength"] = market_strength_val
        response["models"]["market_strength"] = market_strength_model

        if total_signals > 0:
            accuracy = round((hi / total_signals * 100.0), 1)
            response["overall_performance"]["accuracy"] = accuracy

        market_rec = market_strength_dict.get("recommendation")
        if market_rec is not None:
            response["overall_performance"]["market_recommendation"] = market_rec

    except Exception as e:
        logger.exception(f"Error getting ML status: {e}")
        raise HTTPException(status_code=500, detail="Failed to get ML status") from e
    else:
        return response


@router.get("/sentiment-analysis/{symbol}")
async def get_sentiment_analysis(symbol: str) -> dict[str, Any]:
    """Get sentiment analysis for symbol."""
    # Validate symbol before try block to avoid TRY301
    sym = _norm_symbol(symbol)
    if not sym:
        raise HTTPException(status_code=400, detail="Invalid or unsupported symbol")

    market_strength_dict = market_strength_signals()
    if not isinstance(market_strength_dict, dict):
        market_strength_dict = {}

    t_data: dict[str, Any] = {}
    try:
        trend_result = trend_analysis()
        if isinstance(trend_result, dict):
            t_data = trend_result
    except Exception as e:
        logger.warning(f"Trend analysis not available: {e}")

    o_data: dict[str, Any] = {}
    try:
        oracle_result = mystic_oracle()
        if isinstance(oracle_result, dict):
            o_data = oracle_result
    except Exception as e:
        logger.warning(f"Mystic oracle not available: {e}")

    # Validate market data outside try to avoid TRY301
    binance_data = cache.get_binance()
    if not isinstance(binance_data, dict):
        raise HTTPException(status_code=503, detail="Market data unavailable")

    sym_cache = binance_data.get(sym)
    if not isinstance(sym_cache, dict):
        raise HTTPException(status_code=404, detail=f"No data for {sym}")

    price_change_val = sym_cache.get("price_change_24h")
    volume_val = sym_cache.get("volume_24h")

    price_change = _safe_float(price_change_val) if price_change_val else None
    volume = _safe_float(volume_val) if volume_val else None

    sentiment_score = 50
    if price_change is not None:
        if price_change > 10:
            sentiment_score += 20
        elif price_change > 5:
            sentiment_score += 10
        elif price_change < -10:
            sentiment_score -= 20
        elif price_change < -5:
            sentiment_score -= 10

    rec = market_strength_dict.get("recommendation")
    if rec == "BULLISH":
        sentiment_score += 15
    elif rec == "BEARISH":
        sentiment_score -= 15

    if volume is not None and volume > 10_000_000:
        sentiment_score += 5

    sentiment_score = max(0, min(100, sentiment_score))

    response: dict[str, Any] = {
        "symbol": sym,
        "sentiment_score": sentiment_score,
        "sentiment": _interpret_sentiment(sentiment_score),
        "recommendation": _get_sentiment_recommendation(
            {
                "score": sentiment_score,
                "price_change": price_change,
                "market_strength": rec,
                "trend_analysis": t_data.get("summary"),
                "oracle_insight": o_data.get("prediction"),
            }
        ),
        "factors": {
            "timestamp": _utc_iso(),
        },
        "timestamp": _utc_iso(),
    }

    if price_change is not None:
        response["factors"]["price_change_24h"] = price_change

        if volume is not None:
            response["factors"]["volume_24h"] = volume

        market_strength_val = market_strength_dict.get("market_strength")
        if market_strength_val is not None:
            response["factors"]["market_strength"] = market_strength_val

        trend_summary = t_data.get("summary")
        if trend_summary is not None:
            response["factors"]["trend_analysis"] = trend_summary

        oracle_pred = o_data.get("prediction")
        if oracle_pred is not None:
            response["factors"]["oracle_insight"] = oracle_pred

    return response


def _interpret_sentiment(score: float) -> str:
    """Interpret sentiment score."""
    if score >= 80:
        return "VERY_BULLISH"
    if score >= 60:
        return "BULLISH"
    if score >= 40:
        return "NEUTRAL"
    if score >= 20:
        return "BEARISH"
    return "VERY_BEARISH"


def _get_sentiment_recommendation(sentiment: dict[str, Any]) -> str:
    """Get sentiment recommendation."""
    score_val = sentiment.get("score")
    if score_val is None:
        return "HOLD"
    score = int(score_val)
    if score >= 80:
        return "STRONG_BUY"
    if score >= 60:
        return "BUY"
    if score >= 40:
        return "HOLD"
    if score >= 20:
        return "SELL"
    return "STRONG_SELL"


@router.get("/test-integrations")
async def test_integrations() -> dict[str, Any]:
    """Test integrations."""
    # Validate trading symbols outside try to avoid TRY301
    test_symbol = TRADING_SYMBOLS[0] if TRADING_SYMBOLS else None
    if not test_symbol:
        msg = "No trading symbols available - TRADING_SYMBOLS must be configured"
        raise RuntimeError(msg)

    try:
        results: dict[str, Any] = {
            "timestamp": _utc_iso(),
        }

        binance_us_data: dict[str, Any] = {}

        try:
            async with BinanceUSAPI() as binance:
                btc_ticker = await binance.get_ticker_price(test_symbol)
                if btc_ticker:
                    binance_us_data["btc_ticker"] = btc_ticker

                btc_24hr = await binance.get_24hr_ticker(test_symbol)
                if btc_24hr:
                    binance_us_data["btc_24hr"] = btc_24hr

                account_info = await binance.get_account_info()
                if account_info:
                    binance_us_data["account_info"] = account_info
        except Exception as e:
            binance_us_data["error"] = str(e)

        if binance_us_data:
            results[EXCHANGE_ID] = binance_us_data

        combined_data_obj: dict[str, Any] = {}
        try:
            combined_data = await get_market_data(test_symbol)
            if combined_data:
                combined_data_obj = combined_data
        except Exception as e:
            combined_data_obj["error"] = str(e)

        if combined_data_obj:
            results["combined_data"] = combined_data_obj

        account_balance_obj: dict[str, Any] = {}
        try:
            balance_data = await get_account_balance()
            if balance_data:
                account_balance_obj = balance_data
        except Exception as e:
            account_balance_obj["error"] = str(e)

        if account_balance_obj:
            results["account_balance"] = account_balance_obj

    except Exception as e:
        logger.exception(f"Error testing integrations: {e}")
        raise HTTPException(status_code=500, detail=f"Integration test failed: {e}") from e
    else:
        return {
            "success": True,
            "message": "Integration test completed",
            "results": results,
        }


@router.get("/market-data/{symbol}")
async def get_symbol_market_data(symbol: str) -> dict[str, Any]:
    """Get market data for symbol."""

    # Validate symbol outside try to avoid TRY301
    sym = _norm_symbol(symbol)
    if not sym:
        raise HTTPException(status_code=400, detail="Invalid or unsupported symbol")

    try:
        data = await get_market_data(sym)

        response: dict[str, Any] = {
            "success": True,
            "symbol": sym,
        }

        if data:
            response["data"] = data

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error getting market data for {symbol}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get market data: {e}") from e
    else:
        return response


@router.get("/account-status")
async def get_account_status() -> dict[str, Any]:
    """Get account status."""
    try:
        balance_data = await get_account_balance()
        trading_status = get_trading_status()

        response: dict[str, Any] = {"success": True}

        if balance_data:
            response["account"] = balance_data

        if trading_status:
            response["trading_status"] = trading_status

    except Exception as e:
        logger.exception(f"Error getting account status: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get account status: {e}") from e
    else:
        return response


@router.get("/system-status")
async def get_system_status() -> dict[str, Any]:
    """Get system status."""
    # Validate trading symbols outside try to avoid TRY301
    test_symbol = TRADING_SYMBOLS[0] if TRADING_SYMBOLS else None
    if not test_symbol:
        msg = "No trading symbols available - TRADING_SYMBOLS must be configured"
        raise RuntimeError(msg)

    # Validate trading symbols for pairs check outside try to avoid TRY301
    test_symbols = list(TRADING_SYMBOLS[:3]) if len(TRADING_SYMBOLS) >= 3 else list(TRADING_SYMBOLS)
    if not test_symbols:
        msg = "No trading symbols available - TRADING_SYMBOLS must be configured"
        raise RuntimeError(msg)

    try:
        trading_status = get_trading_status()
        account_balance = await get_account_balance()

        api_status: dict[str, Any] = {}

        binance_us_status: dict[str, Any] = {}

        try:
            async with BinanceUSAPI() as binance:
                btc_ticker = await binance.get_ticker_price(test_symbol)
                if btc_ticker:
                    binance_us_status["status"] = "connected"
                    binance_us_status["last_test"] = _utc_iso()
                    binance_us_status["sample_data"] = btc_ticker
                else:
                    binance_us_status["status"] = "error"
                    binance_us_status["last_test"] = _utc_iso()
        except Exception as e:
            binance_us_status["status"] = "error"
            binance_us_status["last_test"] = _utc_iso()
            binance_us_status["error"] = str(e)

        if binance_us_status:
            api_status[EXCHANGE_ID] = binance_us_status

        signal_filter_status: dict[str, Any] = {
            "min_confidence": signal_filter.min_confidence,
            "volume_threshold": signal_filter.volume_threshold,
            "volatility_threshold": signal_filter.volatility_threshold,
            "confirmation_threshold": signal_filter.confirmation_threshold,
        }

        history_count = sum(len(h) for h in signal_filter.signal_history.values())
        signal_filter_status["signal_history_count"] = history_count

        ai_signals_status: dict[str, Any] = {}
        try:
            scored_signals_list = signal_scorer()
            if not isinstance(scored_signals_list, list):
                scored_signals_list = []

            risk_signals_list = risk_adjusted_signals()
            if not isinstance(risk_signals_list, list):
                risk_signals_list = []

            technical_signals_list = technical_signals()
            if not isinstance(technical_signals_list, list):
                technical_signals_list = []

            market_strength_dict = market_strength_signals()
            if not isinstance(market_strength_dict, dict):
                market_strength_dict = {}

            signal_scorer_info: dict[str, Any] = {
                "count": len(scored_signals_list),
                "status": "active",
            }
            ai_signals_status["signal_scorer"] = signal_scorer_info

            risk_signals_info: dict[str, Any] = {
                "count": len(risk_signals_list),
                "status": "active",
            }
            ai_signals_status["risk_signals"] = risk_signals_info

            technical_signals_info: dict[str, Any] = {
                "count": len(technical_signals_list),
                "status": "active",
            }
            ai_signals_status["technical_signals"] = technical_signals_info

            market_strength_info: dict[str, Any] = {"status": "active"}
            market_strength_val = market_strength_dict.get("market_strength")
            if market_strength_val is not None:
                market_strength_info["strength"] = market_strength_val
            ai_signals_status["market_strength"] = market_strength_info
        except Exception as e:
            ai_signals_status["error"] = str(e)

        trading_pairs_status: dict[str, Any] = {}
        try:
            async with BinanceUSAPI() as binance:
                for sym in test_symbols:
                    try:
                        tkr = await binance.get_ticker_price(sym)
                        if tkr:
                            pair_status: dict[str, Any] = {
                                "status": "active",
                            }
                            price_val = tkr.get("price")
                            if price_val is not None:
                                pair_status["price"] = price_val

                            timestamp_val = tkr.get("timestamp")
                            if timestamp_val is not None:
                                pair_status["last_update"] = timestamp_val

                            trading_pairs_status[sym] = pair_status
                        else:
                            trading_pairs_status[sym] = {
                                "status": "error",
                                "error": "No data",
                            }
                    except Exception as e:
                        trading_pairs_status[sym] = {
                            "status": "error",
                            "error": str(e),
                        }
        except Exception as e:
            logger.exception(f"BinanceUSAPI session error: {e}")

        system_status: dict[str, Any] = {
            "timestamp": _utc_iso(),
        }

        if isinstance(trading_status, dict):
            trading_enabled = trading_status.get("trading_enabled")
            if trading_enabled is not None:
                system_status["trading_enabled"] = trading_enabled

            uptime_seconds = trading_status.get("uptime_seconds")
            if uptime_seconds is not None:
                system_status["uptime_seconds"] = uptime_seconds

            start_time = trading_status.get("start_time")
            if start_time is not None:
                system_status["start_time"] = start_time

            stats = trading_status.get("stats")
            if isinstance(stats, dict):
                system_status["trading_stats"] = stats

        if api_status:
            system_status["api_status"] = api_status

        system_status["signal_filter"] = signal_filter_status

        if ai_signals_status:
            system_status["ai_signals"] = ai_signals_status

        if trading_pairs_status:
            system_status["trading_pairs"] = trading_pairs_status

        if account_balance:
            system_status["account"] = account_balance

    except Exception as e:
        logger.exception(f"Error getting system status: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get system status: {e}") from e
    else:
        return {
            "success": True,
            "system_status": system_status,
            "timestamp": _utc_iso(),
        }


@router.get("/comprehensive-status")
async def get_comprehensive_status() -> dict[str, Any]:
    """Get comprehensive system status."""
    try:
        # Allow partial availability - not all services required
        if get_ai_model_versioning is None and get_ai_training_pipeline is None and get_experimental_integration is None:
            return {
                "status": "error",
                "error": "No AI services available",
                "timestamp": _utc_iso(),
            }

        trading_status = get_trading_status()
        account_balance = await get_account_balance()

        ai_training = get_ai_training_pipeline(get_shared_cache) if get_ai_training_pipeline else None
        ai_versioning = get_ai_model_versioning() if get_ai_model_versioning else None
        experimental = get_experimental_integration() if get_experimental_integration else None

        api_status: dict[str, Any] = {}

        binance_us_status: dict[str, Any] = {}
        try:
            async with BinanceUSAPI() as binance:
                account_info = await binance.get_account_info()
                if account_info:
                    binance_us_status["status"] = "online"
                    binance_us_status["last_test"] = _utc_iso()
                else:
                    binance_us_status["status"] = "error"
                    binance_us_status["last_test"] = _utc_iso()
        except Exception as e:
            binance_us_status["status"] = "offline"
            binance_us_status["error"] = str(e)
            binance_us_status["last_test"] = _utc_iso()

        if binance_us_status:
            api_status[EXCHANGE_ID] = binance_us_status

        experimental_status_obj: dict[str, Any] = {}
        if experimental:
            try:
                exp_status = experimental.get_service_status()
                if isinstance(exp_status, dict):
                    experimental_status_obj = exp_status
            except Exception:
                pass

        ai_systems_status: dict[str, Any] = {}

        if ai_training:
            try:
                training_status = ai_training.get_status()
                if isinstance(training_status, dict):
                    ai_systems_status["training_pipeline"] = training_status
            except Exception:
                pass

        if ai_versioning:
            try:
                versioning_status = ai_versioning.get_status()
                if isinstance(versioning_status, dict):
                    ai_systems_status["model_versioning"] = versioning_status

                active_model = getattr(ai_versioning, "active_model", None)
                if active_model is not None:
                    ai_systems_status["active_model"] = active_model
            except Exception:
                pass

        autobuy_status: dict[str, Any] = {}

        if isinstance(trading_status, dict):
            is_running = trading_status.get("is_running")
            if is_running is not None:
                autobuy_status["is_running"] = is_running

            total_trades = trading_status.get("total_trades")
            if total_trades is not None:
                autobuy_status["total_trades"] = total_trades

            successful_trades = trading_status.get("successful_trades")
            if successful_trades is not None:
                autobuy_status["successful_trades"] = successful_trades

            failed_trades = trading_status.get("failed_trades")
            if failed_trades is not None:
                autobuy_status["failed_trades"] = failed_trades

            total_profit = trading_status.get("total_profit")
            if total_profit is not None:
                autobuy_status["total_profit"] = total_profit

            win_rate = trading_status.get("win_rate")
            if win_rate is not None:
                autobuy_status["win_rate"] = win_rate

            uptime = trading_status.get("uptime")
            if uptime is not None:
                autobuy_status["uptime"] = uptime

            last_trade = trading_status.get("last_trade_time")
            if last_trade is not None:
                autobuy_status["last_trade"] = last_trade

        system_overview: dict[str, Any] = {
            "timestamp": _utc_iso(),
        }

        if isinstance(trading_status, dict):
            is_running = trading_status.get("is_running")
            if is_running is not None:
                system_overview["status"] = "operational" if is_running else "stopped"

        comprehensive_status: dict[str, Any] = {
            "system_overview": system_overview,
            "trading_system": {},
            "timestamp": _utc_iso(),
        }

        if autobuy_status:
            comprehensive_status["trading_system"]["autobuy_status"] = autobuy_status

        if account_balance:
            comprehensive_status["trading_system"]["account_balance"] = account_balance

        if api_status:
            comprehensive_status["trading_system"]["api_status"] = api_status

        if ai_systems_status:
            comprehensive_status["ai_systems"] = ai_systems_status

        if experimental_status_obj:
            comprehensive_status["experimental_services"] = experimental_status_obj

        performance_metrics: dict[str, Any] = {}

        if isinstance(trading_status, dict):
            total_trades = trading_status.get("total_trades")
            if total_trades is not None:
                performance_metrics["total_trades"] = total_trades

            win_rate = trading_status.get("win_rate")
            if win_rate is not None:
                performance_metrics["success_rate"] = win_rate

            total_profit = trading_status.get("total_profit")
            if total_profit is not None:
                performance_metrics["total_profit"] = total_profit

        if isinstance(experimental_status_obj, dict):
            active_services = experimental_status_obj.get("active_services")
            if active_services is not None:
                performance_metrics["active_services"] = active_services

        if ai_versioning:
            try:
                model_registry = getattr(ai_versioning, "model_registry", None)
                if model_registry:
                    performance_metrics["ai_models"] = len(model_registry)
            except Exception:
                pass

        if performance_metrics:
            comprehensive_status["performance_metrics"] = performance_metrics

        health_checks: dict[str, Any] = {}

        if isinstance(trading_status, dict):
            is_running = trading_status.get("is_running")
            if is_running is not None:
                health_checks["trading_system"] = "healthy" if is_running else "stopped"

        if ai_training:
            try:
                is_running = getattr(ai_training, "is_running", None)
                if is_running is not None:
                    health_checks["ai_training"] = "healthy" if is_running else "stopped"
            except Exception:
                pass

        if ai_versioning:
            health_checks["model_versioning"] = "healthy"
        else:
            health_checks["model_versioning"] = "stopped"

        if experimental:
            try:
                is_running = getattr(experimental, "is_running", None)
                if is_running is not None:
                    health_checks["experimental_integration"] = "healthy" if is_running else "stopped"
            except Exception:
                pass

        if api_status:
            all_online = all(api.get("status") == "online" for api in api_status.values() if isinstance(api, dict))
            health_checks["coin_apis"] = "healthy" if all_online else "degraded"

        if health_checks:
            comprehensive_status["health_checks"] = health_checks

    except Exception as e:
        logger.exception(f"Error getting comprehensive status: {e}")
        return {
            "error": str(e),
            "status": "error",
            "timestamp": _utc_iso(),
        }
    else:
        return comprehensive_status


@router.get("/status")
async def get_autobuy_status() -> dict[str, Any]:
    """Get autobuy system status."""
    try:
        trading_status = get_trading_status()

        # Now reading actual trading status from get_trading_status()

        return {
            "status": "success",
            "enabled": trading_status.get("trading_enabled", False),
            "mode": "live" if trading_status.get("trading_enabled", False) else "unknown",
            "timestamp": _utc_iso(),
            "data": trading_status,
        }
    except Exception as e:
        logger.exception(f"Error getting autobuy status: {e}")
        return {
            "status": "error",
            "error": str(e),
            "timestamp": _utc_iso(),
        }


@router.get("/stats")
async def get_autobuy_stats() -> dict[str, Any]:
    """Get autobuy performance statistics."""
    try:
        # get_trade_summary is a regular function, not async
        trade_summary_result = get_trade_summary()
        # If it returns a dict, use it; otherwise wrap it
        trade_summary = trade_summary_result if isinstance(trade_summary_result, dict) else {"raw_data": trade_summary_result}
        return {
            "status": "success",
            "timestamp": _utc_iso(),
            "summary": trade_summary,
        }
    except Exception as e:
        logger.exception(f"Error getting autobuy stats: {e}")
        return {
            "status": "error",
            "error": str(e),
            "timestamp": _utc_iso(),
        }


@router.get("/config")
async def get_autobuy_config() -> dict[str, Any]:
    """Get autobuy configuration."""
    try:
        config_data = AUTO_BUY_CONFIG if AUTO_BUY_CONFIG is not None else {}
        return {
            "status": "success",
            "timestamp": _utc_iso(),
            "config": config_data,
        }
    except Exception as e:
        logger.exception(f"Error getting autobuy config: {e}")
        return {
            "status": "error",
            "error": str(e),
            "timestamp": _utc_iso(),
        }


@router.get("/trades")
async def get_autobuy_trades() -> dict[str, Any]:
    """
    Get autobuy trade history.

    BINANCE WEIGHT PROTECTION:
    - 30-second Redis cache to prevent excessive Binance API calls
    - Reduces weight from 60 calls/min to 2 calls/min (97% reduction)
    - Cache key: autobuy:trades:cache:v1
    """
    try:
        # BINANCE WEIGHT PROTECTION: Check Redis cache first
        import json

        import redis

        cache_key = "autobuy:trades:cache:v1"
        cache_ttl = 30  # 30 seconds

        try:
            redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
            r = redis.from_url(redis_url, decode_responses=True)
            cached_data = r.get(cache_key)

            if cached_data:
                logger.debug("[CACHE HIT] Returning cached trades (avoiding Binance API)")
                r.close()
                return json.loads(cached_data)

            logger.info("[CACHE MISS] Fetching trades from Binance API")
        except Exception as cache_error:
            logger.warning(f"Redis cache unavailable: {cache_error}, proceeding without cache")
            r = None

        # Fetch trade history (may call Binance API - 10 weight)
        trade_history = get_trade_history()

        result = {
            "status": "success",
            "timestamp": _utc_iso(),
            "trades": trade_history,
            "cached": False,
        }

        # Store in cache for 30 seconds
        if r:
            try:
                r.setex(cache_key, cache_ttl, json.dumps(result))
                logger.debug(f"[CACHE STORED] Trades cached for {cache_ttl}s")
            except Exception as cache_error:
                logger.warning(f"Failed to cache trades: {cache_error}")
            finally:
                r.close()

        return result

    except Exception as e:
        logger.exception(f"Error getting autobuy trades: {e}")
        return {
            "status": "error",
            "error": str(e),
            "timestamp": _utc_iso(),
        }


@router.get("/orders")
async def get_autobuy_orders() -> dict[str, Any]:
    """Get autobuy orders (alias for trades endpoint)."""
    try:
        # Get active trades (orders)
        active_trades = get_active_trades()
        # Get trade history for completed orders
        trade_history = get_trade_history()

        # Combine into orders format
        orders = []

        # Add active orders
        if isinstance(active_trades, list):
            for trade in active_trades:
                orders.append(
                    {
                        "id": trade.get("id", "unknown"),
                        "symbol": trade.get("symbol", ""),
                        "side": trade.get("side", "BUY"),
                        "status": "active",
                        "price": trade.get("entry_price", 0),
                        "quantity": trade.get("quantity", 0),
                        "timestamp": trade.get("entry_time", _utc_iso()),
                    }
                )

        # Add completed orders
        if isinstance(trade_history, list):
            for trade in trade_history:
                orders.append(
                    {
                        "id": trade.get("id", "unknown"),
                        "symbol": trade.get("symbol", ""),
                        "side": trade.get("side", "BUY"),
                        "status": "completed",
                        "price": trade.get("exit_price", trade.get("entry_price", 0)),
                        "quantity": trade.get("quantity", 0),
                        "timestamp": trade.get("exit_time", trade.get("entry_time", _utc_iso())),
                        "pnl": trade.get("pnl", 0),
                    }
                )

        return {
            "status": "success",
            "timestamp": _utc_iso(),
            "orders": orders,
            "total": len(orders),
        }
    except Exception as e:
        logger.exception(f"Error getting autobuy orders: {e}")
        return {
            "status": "error",
            "error": str(e),
            "timestamp": _utc_iso(),
            "orders": [],
            "total": 0,
        }


@router.get("/signals")
async def get_autobuy_signals() -> dict[str, Any]:
    """
    Operator snapshot only: per-symbol rows from Redis HOT→ML→RULE (first present hash) or DB fallback.

    Not execution truth — no bar ranking, regime vetoes, governance, order submit/reject, or fills.
    See execution_disclaimer on the JSON response. Advisory hot-market feed is separate.
    """
    try:
        try:
            risk_adjusted = risk_adjusted_signals()
        except Exception as ra_err:
            logger.debug("risk_adjusted_signals failed: %s", ra_err, exc_info=True)
            risk_adjusted = []
        if not isinstance(risk_adjusted, list):
            risk_adjusted = []

        redis_client = None
        try:
            from backend.config.redis_config import get_shared_redis_async

            redis_client = get_shared_redis_async()
        except Exception as redis_err:
            logger.debug("autobuy/signals: no redis client: %s", redis_err, exc_info=True)

        signals_array = await build_canonical_signal_rows(
            list(TRADING_SYMBOLS),
            redis_client,
        )

        hot_market_bridge_feed: list[dict[str, Any]] = []
        if isinstance(risk_adjusted, list):
            for signal in risk_adjusted:
                if not isinstance(signal, dict):
                    continue
                hot_market_bridge_feed.append(
                    {
                        "symbol": signal.get("symbol", ""),
                        "recommendation": signal.get("recommendation", "HOLD"),
                        "score": int(signal.get("score", 0) or 0),
                        "change_24h": float(signal.get("change_24h", 0) or 0),
                        "price": signal.get("price", 0),
                        "layer": "advisory_hot_market_bridge",
                    }
                )

        return {
            "status": "success",
            "timestamp": _utc_iso(),
            "execution_disclaimer": (
                "Rows are a point-in-time snapshot of HOT→ML→RULE Redis layers or DB fallback. "
                "They are not execution truth and do not include bar ranking, regime vetoes, governance, "
                "order submission, rejects, or fills."
            ),
            "confidence_scale": (
                "winner_probability: signals[].winner_probability_0_1 / confidence_0_1 (argmax class, 0-1). "
                "BUY admission: buy_margin vs buy_margin_threshold (sleeve-aware). "
                "executor_buy_eligible only if model BUY admission passes AND executor_will_see "
                "(Redis HOT>ML>RULE hash OR pe_buy_candidate:* after enqueue, non-stale, price:{base}>0). "
                "Pure DB fallback with no Redis/pe_buy_candidate uses NOT_ON_EXECUTOR_BUS. "
                "See executor_visibility_blocker, executor_bus_route, model_buy_ready, "
                "candidate_creation_possible."
            ),
            "signals": signals_array,
            "hot_market_bridge_feed": hot_market_bridge_feed,
            "raw_signals": {
                "mystic_oracle": mystic_oracle(),
                "market_strength": market_strength_signals(),
                "risk_adjusted": risk_adjusted,
                "signal_scorer": signal_scorer(),
            },
        }
    except Exception as e:
        logger.exception(f"Error getting autobuy signals: {e}")
        return {
            "status": "error",
            "error": str(e),
            "timestamp": _utc_iso(),
        }
