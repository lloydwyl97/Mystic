"""
Bot Management Endpoints

Bot control and status management.
- Live data only (no fabricated fallbacks)
"""

from __future__ import annotations

import contextlib
import logging
from datetime import datetime, timezone
from typing import Any, Literal

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field, conint

# Lazy import for optional bot service (may not be available in all deployments)
try:
    from backend.services.bot_service import get_bot_service as _get_bot_service_impl
except ImportError:
    _get_bot_service_impl = None

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/bots", tags=["bot-management"])

# Allowed enums for better hygiene
BotType = Literal["MOMENTUM", "SCALPING", "ARBITRAGE", "MEAN_REVERSION"]
RiskLevel = Literal["LOW", "MEDIUM", "HIGH"]
BotStatus = Literal["ACTIVE", "PAUSED", "DISABLED"]


class ToggleRequest(BaseModel):
    """Toggle request model."""

    bot_id: conint(gt=0) = Field(alias="botId")


class ToggleResponse(BaseModel):
    """Toggle response model."""

    success: bool
    bot_id: int = Field(alias="botId")
    enabled: bool
    message: str


class ConfigUpdateRequest(BaseModel):
    """Config update request model."""

    bot_id: conint(gt=0) = Field(alias="botId")
    config: dict[str, Any] = Field(default_factory=dict)


def _utc_iso() -> str:
    """Get current timestamp in ISO format."""
    return datetime.now(timezone.utc).isoformat()


def _get_bot_service() -> Any:
    """Get bot service."""

    def _ensure_bot_service():
        if _get_bot_service_impl is None:
            raise ImportError("Bot service not available")
        return _get_bot_service_impl()

    try:
        return _ensure_bot_service()
    except Exception as e:
        logger.info(f"Bot service not available: {e}")
        return None


@router.get("/bot-management/status")
async def get_bot_status() -> list[dict[str, Any]]:
    """Get status of all trading bots."""
    try:
        svc = _get_bot_service()
        if not svc:
            return []

        try:
            bots = await svc.list_bots_status()
            if not isinstance(bots, list):
                return []

            norm: list[dict[str, Any]] = []
            for b in bots:
                if not isinstance(b, dict):
                    continue

                bot_id_val = b.get("id")
                if bot_id_val is None:
                    continue

                try:
                    bid = int(bot_id_val)
                except (ValueError, TypeError):
                    continue

                entry: dict[str, Any] = {
                    "id": bid,
                    "updatedAt": _utc_iso(),
                }

                name = b.get("name")
                if name is not None:
                    entry["name"] = str(name)

                bot_type = b.get("type")
                if bot_type is not None:
                    entry["type"] = str(bot_type).upper()

                status = b.get("status")
                if status is not None:
                    entry["status"] = str(status)

                profit = b.get("profit")
                if profit is not None:
                    with contextlib.suppress(ValueError, TypeError):
                        entry["profit"] = float(profit)

                trades = b.get("trades")
                if trades is not None:
                    with contextlib.suppress(ValueError, TypeError):
                        entry["trades"] = int(trades)

                success_rate = b.get("successRate")
                if success_rate is not None:
                    with contextlib.suppress(ValueError, TypeError):
                        entry["successRate"] = float(success_rate)

                risk_level = b.get("riskLevel")
                if risk_level is not None:
                    entry["riskLevel"] = str(risk_level).upper()

                features = b.get("features")
                if isinstance(features, list):
                    entry["features"] = features

                last_trade = b.get("lastTrade")
                if last_trade is not None:
                    entry["lastTrade"] = last_trade

                next_signal = b.get("nextSignal")
                if next_signal is not None:
                    entry["nextSignal"] = next_signal

                norm.append(entry)
        except Exception as e:
            logger.exception(f"bot_service.list_bots_status failed: {e}")
            return []
    except Exception as e:
        logger.exception(f"Error getting bot status: {e}")
        raise HTTPException(status_code=500, detail="Failed to get bot status") from e
    else:
        return norm


@router.post("/toggle", response_model=ToggleResponse)
async def toggle_bot(data: ToggleRequest) -> dict[str, Any]:
    """Toggle bot on/off."""
    try:
        bot_id = int(data.bot_id)
        svc = _get_bot_service()

        if not svc:
            return {
                "status": "error",
                "error": "Bot service not available",
                "timestamp": _utc_iso(),
            }

        try:
            enabled = await svc.toggle_bot(bot_id)
        except AttributeError:
            try:
                current = await svc.is_enabled(bot_id)
                enabled = await svc.set_enabled(bot_id, not bool(current))
            except Exception as e:
                logger.exception(f"bot_service toggle failed: {e}")
                raise HTTPException(
                    status_code=500,
                    detail=f"Failed to toggle bot: {e}",
                ) from e
        except Exception as e:
            logger.exception(f"bot_service.toggle failed: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to toggle bot: {e}") from e

        enabled_bool = bool(enabled)
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error toggling bot: {e}")
        raise HTTPException(status_code=500, detail="Failed to toggle bot") from e
    else:
        return {
            "success": True,
            "botId": bot_id,  # Keep botId for API compatibility
            "enabled": enabled_bool,
            "message": (f"Bot {bot_id} {'enabled' if enabled_bool else 'disabled'} successfully"),
        }


@router.put("/config")
async def update_bot_config(
    data: ConfigUpdateRequest,
) -> dict[str, Any]:
    """Update bot configuration."""
    try:
        bot_id = int(data.bot_id)
        cfg = data.config or {}

        svc = _get_bot_service()

        if not svc:
            return {
                "status": "error",
                "error": "Bot service not available",
                "timestamp": _utc_iso(),
            }

        try:
            await svc.update_config(bot_id, cfg)
        except Exception as e:
            logger.exception(f"bot_service.update_config failed: {e}")
            raise HTTPException(
                status_code=500,
                detail=f"Failed to update bot config: {e}",
            ) from e

        return {
            "success": True,
            "botId": bot_id,  # Keep botId for API compatibility
            "message": (f"Bot {bot_id} configuration updated successfully"),
            "updatedAt": _utc_iso(),
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error updating bot config: {e}")
        raise HTTPException(status_code=500, detail="Failed to update bot config") from e
