"""
Bot Routes

API endpoints for bot control and management.
- Live data only (no fabricated fallbacks)
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any, Literal

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field, validator

from backend.services.bot_manager import BotManager

logger = logging.getLogger(__name__)

router = APIRouter(tags=["bot-routes"])
bot_manager = BotManager()


def _utc_iso() -> str:
    """Get current timestamp in ISO format."""
    return datetime.now(timezone.utc).isoformat()


def _norm_symbol(sym: str) -> str:
    """Normalize symbol format."""
    return (sym or "").upper().replace(" ", "").replace("/", "").replace("-", "")


def _norm_action(action: str) -> str:
    """Normalize action to BUY or SELL."""
    a = (action or "").upper()
    if a not in {"BUY", "SELL"}:
        raise HTTPException(status_code=400, detail="action must be BUY or SELL")
    return a


async def _maybe_await(val: Any) -> Any:
    """Await if coroutine, otherwise return value."""
    if asyncio.iscoroutine(val):
        return await val
    return val


class AutoBuyConfig(BaseModel):
    """Auto-buy configuration model."""

    max_daily_loss: float | None = Field(default=None, ge=0, le=100)
    max_concurrent_positions: int | None = Field(default=None, ge=0, le=1000)
    min_signal_score: int | None = Field(default=None, ge=0, le=100)

    class Config:
        extra = "allow"  # accept additional keys transparently


class TradeRequest(BaseModel):
    """Trade request model."""

    symbol: str = Field(..., min_length=1)
    action: Literal["BUY", "SELL", "buy", "sell"]
    amount: float = Field(1000.0, gt=0)
    strategy: str = Field("default", min_length=1)

    @validator("symbol")
    @classmethod
    def _v_symbol(cls, v: str) -> str:
        s = _norm_symbol(v)
        if not s:
            msg = "symbol is required"
            raise ValueError(msg)
        return s

    @validator("action")
    @classmethod
    def _v_action(cls, v: str) -> str:
        return _norm_action(v)


@router.get("/bot/status")
async def get_bot_status() -> dict[str, Any]:
    """Get current bot status."""
    try:
        res = bot_manager.get_bot_status()
        res = await _maybe_await(res)

        if not isinstance(res, dict):
            return {
                "status": "error",
                "error": "Invalid bot status format",
                "timestamp": _utc_iso(),
            }

        if "timestamp" not in res:
            res["timestamp"] = _utc_iso()
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error getting bot status: {e}")
        raise HTTPException(status_code=500, detail="Failed to get bot status") from e
    else:
        return res


@router.post("/bot/start")
async def start_bot() -> dict[str, Any]:
    """Start the trading bot."""
    try:
        res = bot_manager.start_bot()
        res = await _maybe_await(res)

        if not isinstance(res, dict):
            return {
                "status": "error",
                "error": "Invalid start response format",
                "timestamp": _utc_iso(),
            }

        if "timestamp" not in res:
            res["timestamp"] = _utc_iso()
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error starting bot: {e}")
        raise HTTPException(status_code=500, detail="Failed to start bot") from e


@router.post("/bot/stop")
async def stop_bot() -> dict[str, Any]:
    """Stop the trading bot."""
    try:
        res = bot_manager.stop_bot()
        res = await _maybe_await(res)

        if not isinstance(res, dict):
            return {
                "status": "error",
                "error": "Invalid stop response format",
                "timestamp": _utc_iso(),
            }

        if "timestamp" not in res:
            res["timestamp"] = _utc_iso()
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error stopping bot: {e}")
        raise HTTPException(status_code=500, detail="Failed to stop bot") from e
    else:
        return res


@router.post("/auto-buy/configure")
async def configure_auto_buy(
    config: AutoBuyConfig,
) -> dict[str, Any]:
    """Configure auto-buy settings."""
    try:
        payload: dict[str, Any] = config.dict()
        res = bot_manager.configure_auto_buy(payload)
        res = await _maybe_await(res)

        if not isinstance(res, dict):
            return {
                "status": "error",
                "error": "Invalid configure response format",
                "timestamp": _utc_iso(),
            }

        if "timestamp" not in res:
            res["timestamp"] = _utc_iso()
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    except Exception as e:
        logger.exception(f"Error configuring auto-buy: {e}")
        raise HTTPException(status_code=500, detail="Failed to configure auto-buy") from e
    else:
        return res


@router.get("/auto-buy/config")
async def get_auto_buy_config() -> dict[str, Any]:
    """Get current auto-buy configuration."""
    try:
        res = bot_manager.get_auto_buy_config()
        res = await _maybe_await(res)

        if not isinstance(res, dict):
            return {
                "status": "error",
                "error": "Invalid config response format",
                "timestamp": _utc_iso(),
            }

        if "timestamp" not in res:
            res["timestamp"] = _utc_iso()
    except Exception as e:
        logger.exception(f"Error getting auto-buy config: {e}")
        raise HTTPException(status_code=500, detail="Failed to get auto-buy config") from e
    else:
        return res


@router.get("/bot/logs")
async def get_bot_logs(
    limit: int = Query(100, ge=1, le=10_000),
) -> dict[str, Any]:
    """Get bot logs."""
    try:
        res = bot_manager.get_bot_logs(limit)
        res = await _maybe_await(res)

        if not isinstance(res, dict):
            return {
                "status": "error",
                "error": "Invalid logs response format",
                "timestamp": _utc_iso(),
            }

        if "limit" not in res:
            res["limit"] = limit

        if "timestamp" not in res:
            res["timestamp"] = _utc_iso()
    except Exception as e:
        logger.exception(f"Error getting bot logs: {e}")
        raise HTTPException(status_code=500, detail="Failed to get bot logs") from e
    else:
        return res


@router.post("/trade/execute")
async def execute_trade(req: TradeRequest) -> dict[str, Any]:
    """Execute a trade."""
    try:
        res = bot_manager.execute_trade(req.symbol, req.action, req.amount, req.strategy)
        res = await _maybe_await(res)

        if not isinstance(res, dict):
            return {
                "status": "error",
                "error": "Invalid trade response format",
                "timestamp": _utc_iso(),
            }

        if "timestamp" not in res:
            res["timestamp"] = _utc_iso()
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error executing trade: {e}")
        raise HTTPException(status_code=500, detail="Failed to execute trade") from e
    else:
        return res
