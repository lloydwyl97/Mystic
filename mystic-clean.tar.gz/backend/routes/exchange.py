"""
Exchange Router - Exchange Integration

Exchange integration endpoints for Binance US only.
- Live data only (no fabricated fallbacks)
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException, Path, Query

from backend.config.settings import settings
from backend.services.binance_rest_client import BinanceREST
from backend.services.live_market_data import live_market_data_service
from backend.services.live_trading_service import trading_service
from backend.services.market_data import MarketDataService
from backend.services.redis_service import get_redis_service
from backend.utils.binance_weight_limiter import BinanceWeightLimiter

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

router = APIRouter(tags=["exchange"])
logger = logging.getLogger(__name__)


def _utc_iso() -> str:
    """Get current timestamp in ISO format."""
    return datetime.now(timezone.utc).isoformat()


def _norm_symbol(sym: str) -> str:
    """Normalize symbol to Binance USDT format (e.g., BTCUSDT)."""
    s = (sym or "").upper().strip().replace("/", "").replace(" ", "")
    if s.endswith("-USD"):
        s = s[:-4] + "USDT"
    if s.endswith("USD") and not s.endswith("USDT"):
        s = s[:-3] + "USDT"
    return s


def get_redis_client() -> Any:
    """Get Redis client."""
    try:
        return get_redis_service()
    except Exception as e:
        logger.exception(f"Error getting Redis client: {e}")
        raise HTTPException(status_code=500, detail="Redis service unavailable") from e


def _ensure_binance_us(exchange_id: str) -> None:
    """Ensure exchange is Binance US only."""
    if exchange_id.lower() != EXCHANGE_ID.lower():
        raise HTTPException(status_code=404, detail=f"Only '{EXCHANGE_ID}' is supported")


# ============================================================================
# EXCHANGE INTEGRATION ENDPOINTS
# ============================================================================


@router.get("/api/exchanges")
async def get_exchanges() -> dict[str, Any]:
    """Get list of supported exchanges with live status check."""
    try:
        api_key = getattr(settings, "binance_us_api_key", None)
        api_secret = getattr(settings, "binance_us_api_secret", None)
        api_keys_configured = bool(api_key and api_secret)

        status = None
        trading_enabled = None

        try:
            test_ticker = await live_market_data_service.get_ticker("BTC/USDT")
            status = "connected" if test_ticker else "degraded"
        except Exception:
            status = "disconnected"

        try:
            if api_keys_configured:
                account = await trading_service.get_account_balance()
                if isinstance(account, dict):
                    account_status = account.get("status")
                    trading_enabled = account_status != "error"
                else:
                    trading_enabled = bool(account)
        except Exception:
            trading_enabled = False

        exchange_entry: dict[str, Any] = {
            "id": EXCHANGE_ID,
            "name": "Binance US",
            "timestamp": _utc_iso(),
            "source": "live_api_check",
        }

        if status:
            exchange_entry["status"] = status

        exchange_entry["api_keys_configured"] = api_keys_configured

        if trading_enabled is not None:
            exchange_entry["trading_enabled"] = trading_enabled

        return {"exchanges": [exchange_entry], "timestamp": _utc_iso()}
    except Exception as e:
        logger.exception(f"Error getting exchanges: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting exchanges: {e}") from e


@router.get("/api/exchanges/{exchange_id}/status")
async def get_exchange_status(
    exchange_id: str = Path(..., description=f"Must be '{EXCHANGE_ID}'"),
) -> dict[str, Any]:
    """Get live status of Binance.US exchange."""
    try:
        _ensure_binance_us(exchange_id)

        market_status = None
        try:
            test_ticker = await live_market_data_service.get_ticker("BTC/USDT")
            market_status = "healthy" if test_ticker else "degraded"
        except Exception:
            market_status = "unhealthy"

        trading_status = None
        try:
            account = await trading_service.get_account_balance()
            if isinstance(account, dict):
                account_status = account.get("status")
                trading_status = "enabled" if account_status != "error" else "disabled"
            else:
                trading_status = "enabled" if account else "disabled"
        except Exception:
            trading_status = "unavailable"

        response: dict[str, Any] = {
            "exchange_id": EXCHANGE_ID,
            "last_heartbeat": _utc_iso(),
            "timestamp": _utc_iso(),
            "source": "live_api_check",
        }

        if market_status:
            response["api_status"] = market_status
            response["status"] = "connected" if market_status == "healthy" else "degraded"

        if trading_status:
            response["trading_status"] = trading_status
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error getting exchange status: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting exchange status: {e}") from e
    else:
        return response


@router.get("/api/exchanges/{exchange_id}/balance")
async def get_exchange_balance(
    exchange_id: str = Path(..., description=f"Must be '{EXCHANGE_ID}'"),
) -> dict[str, Any]:
    """Get balance for Binance US from live trading service."""
    try:
        _ensure_binance_us(exchange_id)

        # Use LiveTradingService for balance operations
        balance_data = await trading_service.get_account_balance()

        response: dict[str, Any] = {
            "exchange_id": EXCHANGE_ID,
            "timestamp": _utc_iso(),
            "balances": balance_data.get("balances", []),
            "total_usd": balance_data.get("total_usd", 0),
            "free_usd": balance_data.get("free_usd", 0),
            "locked_usd": balance_data.get("locked_usd", 0),
            "status": "success",
            "source": "live_trading_service",
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error getting exchange balance: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting exchange balance: {e}") from e
    else:
        return response


@router.get("/api/exchanges/{exchange_id}/orders")
async def get_exchange_orders(
    exchange_id: str = Path(..., description=f"Must be '{EXCHANGE_ID}'"),
) -> dict[str, Any]:
    """Get live orders from Binance.US."""
    # Validate exchange and orders outside try to avoid TRY301
    _ensure_binance_us(exchange_id)

    try:
        orders_response = await trading_service.get_open_orders()
    except Exception as e:
        logger.exception(f"Error fetching orders: {e}")
        raise HTTPException(status_code=500, detail=f"Error fetching orders: {e}") from e

    if not isinstance(orders_response, dict):
        raise HTTPException(
            status_code=503,
            detail="Failed to fetch live orders from Binance.US",
        )

    response_status = orders_response.get("status")
    if response_status == "error":
        raise HTTPException(
            status_code=503,
            detail="Failed to fetch live orders from Binance.US",
        )

    try:
        orders = orders_response.get("orders")

        response: dict[str, Any] = {
            "exchange_id": EXCHANGE_ID,
            "timestamp": _utc_iso(),
            "source": f"live_{EXCHANGE_ID}",
        }

        if orders:
            response["orders"] = orders
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error getting exchange orders: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Error getting live exchange orders: {e}",
        ) from e
    else:
        return response


# ============================================================================
# BINANCE-SPECIFIC ENDPOINTS (US)
# ============================================================================


@router.get("/api/binance_us/status")
async def get_binance_status() -> dict[str, Any]:
    """Get Binance US exchange status from live service."""
    try:
        limiter = await BinanceWeightLimiter.create()
        client = BinanceREST(limiter)
        server_time = await client.get_server_time()

        response: dict[str, Any] = {
            "exchange": EXCHANGE_ID,
            "server_time": _utc_iso(),
            "timestamp": _utc_iso(),
        }

        if server_time:
            if isinstance(server_time, dict):
                server_ts = server_time.get("serverTime")
                if server_ts:
                    response["server_time"] = server_ts
            else:
                response["server_time"] = server_time

        status_info = await client.get_exchange_info()
        if isinstance(status_info, dict):
            status_val = status_info.get("status")
            if status_val:
                response["status"] = status_val

            api_version = status_info.get("api_version")
            if api_version:
                response["api_version"] = api_version

            rate_limits_data = status_info.get("rateLimits")
            if rate_limits_data:
                response["rate_limits"] = rate_limits_data
    except ImportError:
        return {
            "status": "error",
            "error": "Binance REST client not available",
            "timestamp": _utc_iso(),
        }
    except Exception as e:
        logger.exception(f"Error getting Binance status: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting Binance status: {e}") from e
    else:
        return response


@router.get("/api/binance_us/market-data")
async def get_binance_market_data(
    symbol: str = Query(default="", description="Binance symbol (from Top-10, required)"),
) -> dict[str, Any]:
    """Get live Binance market data - no static data."""
    # Validate symbol outside try to avoid TRY301
    norm = _norm_symbol(symbol)

    try:
        mds = MarketDataService.shared()
        live_data = await mds.get_live_data()
    except Exception as e:
        logger.exception(f"Error getting live data: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting live data: {e}") from e

    if not isinstance(live_data, dict):
        raise HTTPException(
            status_code=503,
            detail="Live market data service unavailable",
        )

    candidates = {
        norm,
        symbol.upper(),
        symbol.upper().replace("/", ""),
    }

    for key in candidates:
        if key in live_data:
            data = live_data[key]
            return {
                "symbol": key,
                "data": data,
                "timestamp": _utc_iso(),
            }

    raise HTTPException(
        status_code=404,
        detail=f"Live data not available for symbol: {symbol}",
    )
