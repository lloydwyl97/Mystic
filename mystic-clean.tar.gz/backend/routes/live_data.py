"""
Live Data Router

API endpoints for live market data.
- Live data only (no fabricated fallbacks)
"""

from __future__ import annotations

import inspect
import logging
from typing import Any

from fastapi import APIRouter, HTTPException

from backend.routes.live_data_manager import get_live_data_manager
from backend.services.market_data import MarketDataService
from backend.services.notification import get_notification_service
from backend.services.service_manager import service_manager

logger = logging.getLogger(__name__)
router = APIRouter()

# ============================================================================
# Service wiring
# ============================================================================

try:
    market_data_service = MarketDataService.shared()
except Exception:
    market_data_service = MarketDataService()

live_data_manager = get_live_data_manager(market_data_service)


class _NoopNotifier:
    """No-op notifier when service unavailable."""

    async def send_notification(self, *_args: Any, **_kwargs: Any) -> bool:
        return False


# Notification service state - using dict to avoid global keyword
_notification_service_state: dict[str, Any] = {"instance": None}

try:
    _notif = get_notification_service(None)
except Exception:
    _notif = None

# Initialize notification service state
_notification_service_state["instance"] = _notif or _NoopNotifier()


async def _safe_notify(title: str, message: str, level: str = "error") -> None:
    """
    Call notification_service.send_notification safely.
    Never let failures bubble up to the request.
    """
    try:
        send = getattr(_notification_service_state["instance"], "send_notification", None)
        if not callable(send):
            return
        if inspect.iscoroutinefunction(send):
            await send(title, message, level)
        else:
            send(title, message, level)  # type: ignore[misc]
    except Exception as e:
        logger.exception(f"Failed to send notification: {e}")


def rewire_notification_service(redis_client: Any) -> None:
    """Hot-plug a real notification service once Redis is available."""
    try:
        svc = get_notification_service(redis_client)
        _notification_service_state["instance"] = svc or _NoopNotifier()
    except Exception as e:
        logger.exception(f"Rewire notification service failed: {e}")
        _notification_service_state["instance"] = _NoopNotifier()


# ============================================================================
# Routes
# ============================================================================


@router.get("/live/supported")
async def get_supported_symbols() -> dict[str, Any]:
    """Get list of supported symbols for live data."""
    try:
        service_health = service_manager.get_health_status()
        result = live_data_manager.get_supported_symbols_data()

        if not isinstance(result, dict):
            return {
                "status": "error",
                "error": "Invalid supported symbols format",
            }

        result["service_health"] = service_health
    except Exception as e:
        logger.exception(f"Error getting supported symbols: {e}")
        await _safe_notify(
            "Live Data Error",
            f"Failed to get supported symbols: {e}",
            "error",
        )
        raise HTTPException(
            status_code=500,
            detail=f"Failed to get supported symbols: {e}",
        ) from e
    else:
        return result


@router.get("/live/enhanced")
async def get_enhanced_live_data() -> dict[str, Any]:
    """Get enhanced live data for all supported coins."""
    try:
        return live_data_manager.get_enhanced_live_data()
    except Exception as e:
        logger.exception(f"Error getting enhanced live data: {e}")
        await _safe_notify(
            "Live Data Error",
            f"Failed to get enhanced live data: {e}",
            "error",
        )
        raise HTTPException(
            status_code=500,
            detail=f"Failed to get enhanced live data: {e}",
        ) from e


@router.get("/live/all")
async def get_all_live_data() -> dict[str, Any]:
    """Get all live data for supported coins."""
    try:
        return live_data_manager.get_all_live_data()
    except Exception as e:
        logger.exception(f"Error getting all live data: {e}")
        await _safe_notify(
            "Live Data Error",
            f"Failed to get all live data: {e}",
            "error",
        )
        raise HTTPException(status_code=500, detail=f"Failed to get all live data: {e}") from e


@router.get("/live/{symbol}")
async def get_live_data(symbol: str) -> dict[str, Any]:
    """Get live data for a specific symbol."""
    try:
        return live_data_manager.get_live_data_for_symbol(symbol)
    except ValueError as e:
        # Symbol not supported — 404 is appropriate
        logger.exception(f"Symbol not supported: {symbol}: {e}")
        raise HTTPException(status_code=404, detail=str(e)) from e
    except Exception as e:
        logger.exception(f"Error getting live data for {symbol}: {e}")
        await _safe_notify(
            "Live Data Error",
            f"Failed to get live data for {symbol}: {e}",
            "error",
        )
        raise HTTPException(
            status_code=500,
            detail=f"Failed to get live data for {symbol}: {e}",
        ) from e


@router.get("/supported")
async def get_supported_coins() -> dict[str, Any]:
    """Get list of supported coins."""
    try:
        return live_data_manager.get_supported_coins_data()
    except Exception as e:
        logger.exception(f"Error getting supported coins: {e}")
        await _safe_notify(
            "Live Data Error",
            f"Failed to get supported coins: {e}",
            "error",
        )
        raise HTTPException(status_code=500, detail=f"Failed to get supported coins: {e}") from e


@router.get("/coin-support")
async def get_coin_support_info() -> dict[str, Any]:
    """Get detailed coin support information."""
    try:
        return live_data_manager.get_coin_support_info()
    except Exception as e:
        logger.exception(f"Error getting coin support info: {e}")
        await _safe_notify(
            "Live Data Error",
            f"Failed to get coin support info: {e}",
            "error",
        )
        raise HTTPException(
            status_code=500,
            detail=f"Failed to get coin support info: {e}",
        ) from e


@router.get("/summary")
async def get_coin_summary() -> dict[str, Any]:
    """Get summary of coin data."""
    try:
        return live_data_manager.get_coin_summary()
    except Exception as e:
        logger.exception(f"Error getting coin summary: {e}")
        await _safe_notify(
            "Live Data Error",
            f"Failed to get coin summary: {e}",
            "error",
        )
        raise HTTPException(status_code=500, detail=f"Failed to get coin summary: {e}") from e
