"""
Live Data Manager

Business logic for live data operations including data processing,
validation, and response formatting.
- Live data only (no fabricated fallbacks)
"""

from __future__ import annotations

import logging
import time
from typing import Any

from backend.services.market_data_sources import (
    SUPPORTED_COINS,
    get_coin_support_summary,
)

logger = logging.getLogger(__name__)


def _now() -> int:
    """Get current timestamp."""
    return int(time.time())


def _norm_symbol(sym: str) -> str:
    """
    Normalize symbols to canonical form expected by internal caches.
    - Accepts: BTCUSDT, BTC-USD, BTC/USDT, btcusdt
    - Returns: BTCUSDT
    """
    s = (sym or "").upper().strip().replace(" ", "")
    s = s.replace("/", "")
    if s.endswith("-USD"):
        s = s[:-4] + "USDT"
    if s.endswith("USD") and not s.endswith("USDT"):
        s = s[:-3] + "USDT"
    return s


def _to_dash_usd(sym_usdt: str) -> str:
    """BTCUSDT -> BTC-USD (for services expecting dash format)."""
    s = (sym_usdt or "").upper()
    return s.replace("USDT", "-USD") if s.endswith("USDT") else s


class LiveDataManager:
    """Manages live data business logic and operations."""

    def __init__(self, market_data_service: Any) -> None:
        self.market_data_service = market_data_service
        enhanced_cache = getattr(self.market_data_service, "enhanced_cache", None)
        if isinstance(enhanced_cache, dict):
            self._enhanced_cache = enhanced_cache
        else:
            self._enhanced_cache = {"data": {}}

        if "cache_hits" not in self._enhanced_cache:
            self._enhanced_cache["cache_hits"] = {}
        if "cache_misses" not in self._enhanced_cache:
            self._enhanced_cache["cache_misses"] = {}

        coin_config = getattr(self.market_data_service, "coin_config", None)
        if isinstance(coin_config, dict):
            self._coin_config = coin_config
        else:
            self._coin_config = {}

    # ----------------------------
    # Supported assets / capability
    # ----------------------------

    def get_supported_symbols_data(self) -> dict[str, Any]:
        """Get formatted data for supported symbols."""
        try:
            symbols = SUPPORTED_COINS
            return {
                "symbols": symbols,
                "count": len(symbols),
                "timestamp": _now(),
            }
        except Exception as e:
            logger.exception(f"Error getting supported symbols: {e}")
            raise

    def get_supported_coins_data(self) -> dict[str, Any]:
        """Get formatted data for supported coins."""
        try:
            coins = SUPPORTED_COINS
            return {
                "coins": coins,
                "count": len(coins),
                "timestamp": _now(),
            }
        except Exception as e:
            logger.exception(f"Error getting supported coins: {e}")
            raise

    def get_coin_support_info(self) -> dict[str, Any]:
        """Get detailed coin support information."""
        try:
            support_info = get_coin_support_summary()
            return {
                "support_info": support_info,
                "timestamp": _now(),
            }
        except Exception as e:
            logger.exception(f"Error getting coin support info: {e}")
            raise

    # ----------------------------
    # Live data
    # ----------------------------

    def get_enhanced_live_data(self) -> dict[str, Any]:
        """Get enhanced live data for all supported coins."""
        try:
            if hasattr(self.market_data_service, "get_all_latest_enhanced"):
                data = self.market_data_service.get_all_latest_enhanced()
            else:
                cache_data = self._enhanced_cache.get("data")
                data = cache_data if isinstance(cache_data, dict) else None

            result: dict[str, Any] = {"timestamp": _now()}

            if isinstance(data, (dict, list)):
                result["data"] = data
                result["count"] = len(data)
        except Exception as e:
            logger.exception(f"Error getting enhanced live data: {e}")
            raise
        else:
            return result

    def _all_supported_symbols(self) -> list[str]:
        """Union of all symbols from service config."""
        try:
            if isinstance(self._coin_config, dict) and self._coin_config:
                all_coins: list[str] = []
                for coins in self._coin_config.values():
                    if isinstance(coins, list):
                        all_coins.extend(coins)
                if all_coins:
                    return sorted({_norm_symbol(c) for c in all_coins})
            return sorted({_norm_symbol(c) for c in SUPPORTED_COINS})
        except Exception:
            return sorted({_norm_symbol(c) for c in SUPPORTED_COINS})

    def get_all_live_data(self) -> dict[str, Any]:
        """Get all live data for supported coins."""
        try:
            supported_symbols = self._all_supported_symbols()

            results: dict[str, Any] = {
                "symbols": {},
                "total_symbols": len(supported_symbols),
                "timestamp": _now(),
            }

            cache_data_obj = self._enhanced_cache.get("data")
            cache_data = cache_data_obj if isinstance(cache_data_obj, dict) else {}

            for sym in supported_symbols:
                try:
                    cached = cache_data.get(sym)
                    if isinstance(cached, dict):
                        entry: dict[str, Any] = {}

                        price = cached.get("price")
                        if price is not None:
                            entry["price"] = price

                        change = cached.get("change_24h")
                        if change is not None:
                            entry["change_24h"] = change

                        volume = cached.get("volume")
                        if volume is not None:
                            entry["volume"] = volume

                        api_source = cached.get("api_source")
                        if api_source is not None:
                            entry["api_source"] = api_source

                        timestamp = cached.get("timestamp")
                        if timestamp is not None:
                            entry["timestamp"] = timestamp

                        last_update = cached.get("last_update")
                        if last_update is not None:
                            entry["last_update"] = last_update

                        if entry:
                            results["symbols"][sym] = entry
                    else:
                        # No data available - don't add hardcoded error
                        pass
                except Exception as e:
                    logger.exception(f"Error processing symbol {sym}: {e}")
                    # Don't add hardcoded error entry
        except Exception as e:
            logger.exception(f"Error getting all live data: {e}")
            raise
        else:
            return results

    def get_live_data_for_symbol(self, symbol: str) -> dict[str, Any]:
        """Get live data for a specific symbol."""
        # Validate symbol outside try to avoid TRY301
        sym = _norm_symbol(symbol)
        if not self.validate_symbol(sym):
            msg = f"Symbol {symbol} not supported"
            raise ValueError(msg)

        cache_data_obj = self._enhanced_cache.get("data")
        cache_data = cache_data_obj if isinstance(cache_data_obj, dict) else {}
        cached_data = cache_data.get(sym)

        if not isinstance(cached_data, dict):
            try:
                dash = _to_dash_usd(sym)
                live_data = None

                if hasattr(self.market_data_service, "fetch_market_price"):
                    live_data = self.market_data_service.fetch_market_price(dash)

                if live_data:
                    entry: dict[str, Any] = {}

                    price = getattr(live_data, "price", None)
                    if price is not None:
                        entry["price"] = price

                    change = getattr(live_data, "change_24h", None)
                    if change is not None:
                        entry["change_24h"] = change

                    volume = getattr(live_data, "volume", None)
                    if volume is not None:
                        entry["volume"] = volume

                    api_source = getattr(self.market_data_service, "current_api", None)
                    if api_source is not None:
                        entry["api_source"] = api_source

                    timestamp = getattr(live_data, "timestamp", None)
                    if timestamp is not None:
                        entry["timestamp"] = timestamp
                    else:
                        entry["timestamp"] = _now()

                    entry["last_update"] = _now()

                    cached_data = entry
            except Exception as fetch_error:
                logger.exception(f"Error fetching data for {sym}: {fetch_error}")
                msg = f"Failed to fetch data for {sym}"
                raise ValueError(msg) from fetch_error

        # Validate data availability outside try to avoid TRY301
        if not isinstance(cached_data, dict):
            msg = f"No data available for {sym}"
            raise TypeError(msg)

        try:
            result: dict[str, Any] = {"symbol": sym}

            if isinstance(cached_data, dict):
                price = cached_data.get("price")
                if price is not None:
                    result["price"] = price

                change = cached_data.get("change_24h")
                if change is not None:
                    result["change_24h"] = change

                volume = cached_data.get("volume")
                if volume is not None:
                    result["volume"] = volume

                api_source = cached_data.get("api_source")
                if api_source is not None:
                    result["api_source"] = api_source

                timestamp = cached_data.get("timestamp")
                if timestamp is not None:
                    result["timestamp"] = timestamp

                last_update = cached_data.get("last_update")
                if last_update is not None:
                    result["last_update"] = last_update
        except Exception as e:
            logger.exception(f"Error getting live data for {symbol}: {e}")
            raise
        else:
            return result

    # ----------------------------
    # Summary / validation
    # ----------------------------

    def get_coin_summary(self) -> dict[str, Any]:
        """Get summary of coin data."""
        try:
            supported_symbols = self._all_supported_symbols()
            cache = self._enhanced_cache

            summary: dict[str, Any] = {
                "total_coins": len(supported_symbols),
                "timestamp": _now(),
            }

            if isinstance(self._coin_config, dict):
                apis = list(self._coin_config.keys())
                if apis:
                    summary["apis"] = apis

            cache_data = cache.get("data")
            if isinstance(cache_data, dict):
                summary["cache_stats"] = {
                    "cached_symbols": len(cache_data),
                }

                cache_hits = cache.get("cache_hits")
                if isinstance(cache_hits, dict):
                    summary["cache_stats"]["cache_hits"] = dict(cache_hits)

                cache_misses = cache.get("cache_misses")
                if isinstance(cache_misses, dict):
                    summary["cache_stats"]["cache_misses"] = dict(cache_misses)
        except Exception as e:
            logger.exception(f"Error getting coin summary: {e}")
            raise
        else:
            return summary

    def validate_symbol(self, symbol: str) -> bool:
        """Validate if a symbol is supported (various formats)."""
        sym = _norm_symbol(symbol)
        if isinstance(self._coin_config, dict):
            in_config = any(sym in {_norm_symbol(c) for c in coins or []} for coins in self._coin_config.values() if isinstance(coins, list))
            if in_config:
                return True
        in_default = sym in {_norm_symbol(c) for c in SUPPORTED_COINS}
        return bool(in_default)

    def format_error_response(self, error: str, symbol: str | None = None) -> dict[str, Any]:
        """Format error response for API endpoints."""
        response: dict[str, Any] = {
            "error": error,
            "timestamp": _now(),
        }
        if symbol:
            response["symbol"] = _norm_symbol(symbol)
        return response


# Global instance (initialized with market_data_service)
live_data_manager: LiveDataManager | None = None


# Live data manager state - using dict to avoid global keyword
_live_data_manager_state: dict[str, LiveDataManager | None] = {"instance": None}


def get_live_data_manager(market_data_service: Any) -> LiveDataManager:
    """Get or create live data manager instance."""
    if _live_data_manager_state["instance"] is None:
        _live_data_manager_state["instance"] = LiveDataManager(market_data_service)
    return _live_data_manager_state["instance"]
