"""
Market Routes

API endpoints for market data and signals.
- Live data only (no fabricated fallbacks)
"""

from __future__ import annotations

import inspect
import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException, Query

from backend.services.market_data import MarketDataService
from backend.services.notification import get_notification_service
from backend.services.service_manager import service_manager

# Import from single source of truth
try:
    from backend.config.trading_universe import EXCHANGE_ID
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

logger = logging.getLogger(__name__)
router = APIRouter(tags=["market"])

# ============================================================================
# Service wiring
# ============================================================================

try:
    market_data_service = MarketDataService.shared()
except Exception:
    market_data_service = MarketDataService()

try:
    from backend.services.live_market_data import (
        live_market_data_service,
    )
except Exception:
    live_market_data_service = None  # type: ignore[assignment]

# Optional imports - try at top level
try:
    from backend.modules.ai.persistent_cache import get_persistent_cache
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    get_persistent_cache = None


class _NoopNotifier:
    """No-op notifier when service unavailable."""

    async def send_notification(self, *_args: Any, **_kwargs: Any) -> bool:
        return False


# Notification service state - using dict to avoid global keyword
_notification_service_state: dict[str, Any] = {"instance": None}

try:
    _notif = get_notification_service(None)
except Exception:
    _notif = None

# Initialize notification service state
_notification_service_state["instance"] = _notif or _NoopNotifier()


async def _safe_notify(title: str, message: str, level: str = "error") -> None:
    """Send notification if service available."""
    try:
        send = getattr(_notification_service_state["instance"], "send_notification", None)
        if not callable(send):
            return
        if inspect.iscoroutinefunction(send):
            await send(title, message, level)
        else:
            send(title, message, level)  # type: ignore[misc]
    except Exception as e:
        logger.warning(f"Notification failed: {e}")


def rewire_notification_service(redis_client: Any) -> None:
    """Hot-plug a real notification service once Redis is available."""
    try:
        svc = get_notification_service(redis_client)
        _notification_service_state["instance"] = svc or _NoopNotifier()
    except Exception as e:
        logger.exception(f"Rewire notification service failed: {e}")
        _notification_service_state["instance"] = _NoopNotifier()


def _now_iso() -> str:
    """Get current timestamp in ISO format."""
    return datetime.now(timezone.utc).isoformat()


# ============================================================================
# Routes
# ============================================================================


@router.get("/coins/all")
async def get_all_coins() -> dict[str, Any]:
    """Get all available coins from market data service."""
    # Validate service availability outside try to avoid TRY301
    if not service_manager.market_data_service:
        raise HTTPException(
            status_code=503,
            detail="Market data service not available",
        )

    try:
        try:
            cached_data = await service_manager.market_data_service.get_all_cached_data()
            if not isinstance(cached_data, dict):
                cached_data = {}
        except Exception as e:
            logger.warning(f"Failed to get cached data: {e}")
            cached_data = {}

        try:
            coin_config = getattr(service_manager.market_data_service, "coin_config", None)
            if not isinstance(coin_config, dict):
                coin_config = {}
        except Exception as e:
            logger.warning(f"Failed to get coin config: {e}")
            coin_config = {}

        service_health = hasattr(service_manager.market_data_service, "get_all_cached_data")

        response: dict[str, Any] = {
            "total_coins": len(cached_data),
            "service_health": bool(service_health),
            "timestamp": _now_iso(),
        }

        if cached_data:
            response["coins"] = cached_data

        if coin_config:
            response["coin_config"] = coin_config
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error getting all coins: {e}")
        await _safe_notify("Market Data Error", f"Failed to get all coins: {e}", "error")
        raise HTTPException(status_code=500, detail=str(e)) from e
    else:
        return response


@router.get("/markets")
async def get_markets() -> dict[str, Any]:
    """Get market overview from live service."""
    # Validate service availability outside try to avoid TRY301
    if not live_market_data_service:
        raise HTTPException(
            status_code=503,
            detail="Live market data service not available",
        )

    try:
        raw = await live_market_data_service.get_market_data("usd", 50)

        if isinstance(raw, dict):
            coins = raw.get("coins")
            if not isinstance(coins, list):
                coins = []
        elif isinstance(raw, list):
            coins = raw
        else:
            coins = []

        markets: dict[str, dict[str, Any]] = {}
        for coin in coins:
            if not isinstance(coin, dict):
                continue

            symbol_val = coin.get("symbol")
            if not symbol_val:
                continue

            try:
                symbol = str(symbol_val).upper()
                market_entry: dict[str, Any] = {"symbol": symbol}

                name = coin.get("name")
                if name:
                    market_entry["name"] = name

                price = coin.get("current_price")
                if price is not None:
                    market_entry["price"] = price

                change = coin.get("price_change_percentage_24h")
                if change is not None:
                    market_entry["change_24h"] = change

                volume = coin.get("total_volume")
                if volume is not None:
                    market_entry["volume"] = volume

                mcap = coin.get("market_cap")
                if mcap is not None:
                    market_entry["market_cap"] = mcap

                rank = coin.get("market_cap_rank")
                if rank is not None:
                    market_entry["rank"] = rank

                markets[symbol] = market_entry
            except Exception as e:
                logger.debug(f"Skipping malformed coin entry: {e}")

        response: dict[str, Any] = {
            "markets": markets,
            "count": len(markets),
            "service_health": True,
            "timestamp": _now_iso(),
            "source": "live_market_data_service",
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error getting markets: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting markets: {e}") from e
    else:
        return response


@router.get("/markets/test")
async def test_markets() -> dict[str, Any]:
    """Smoke check for markets route."""
    return {
        "message": "Markets test endpoint working",
        "timestamp": _now_iso(),
        "status": "success",
    }


@router.get("/market/{symbol}")
async def get_market(symbol: str) -> dict[str, Any]:
    """Get specific market data from MarketDataService."""
    # Validate service availability outside try to avoid TRY301
    if not service_manager.market_data_service:
        raise HTTPException(
            status_code=503,
            detail="Market data service not available",
        )

    try:
        market_data = await service_manager.market_data_service.get_market_data(symbol)
        service_health = hasattr(service_manager.market_data_service, "get_market_data")
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error getting market data for {symbol}: {e}")
        await _safe_notify(
            "Market Data Error",
            f"Failed to get market data for {symbol}: {e}",
            "error",
        )
        raise HTTPException(status_code=500, detail=str(e)) from e
    else:
        return {
            "symbol": symbol.upper(),
            "data": market_data,
            "service_health": bool(service_health),
            "timestamp": _now_iso(),
        }


@router.get("/signals/live")
async def get_live_signals(
    symbol: str = Query("all", description="Asset symbol to analyze"),
) -> dict[str, Any]:
    """Get live trading signals from market_data_service."""
    # Validate service availability outside try to avoid TRY301
    if not service_manager.market_data_service:
        raise HTTPException(
            status_code=503,
            detail="Market data service not available",
        )

    try:
        signals = await service_manager.market_data_service.get_live_signals(symbol)
        service_health = hasattr(service_manager.market_data_service, "get_live_signals")
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error getting live signals: {e}")
        await _safe_notify("Market Data Error", f"Failed to get live signals: {e}", "error")
        raise HTTPException(status_code=500, detail=str(e)) from e
    else:
        return {
            "signals": signals,
            "symbol": symbol,
            "service_health": bool(service_health),
            "timestamp": _now_iso(),
        }


@router.get("/signals/unified")
async def get_unified_signals(
    symbol: str | None = None,
) -> dict[str, Any]:
    """Get unified signals from unified_signal_manager."""
    # Validate service availability outside try to avoid TRY301
    if not service_manager.unified_signal_manager:
        raise HTTPException(status_code=503, detail="Signal system not available")

    try:
        signals = await service_manager.unified_signal_manager.get_unified_signals(symbol)
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error getting unified signals: {e}")
        await _safe_notify(
            "Market Data Error",
            f"Failed to get unified signals: {e}",
            "error",
        )
        raise HTTPException(status_code=500, detail=str(e)) from e
    else:
        return {
            "unified_signals": signals,
            "timestamp": _now_iso(),
        }


@router.get("/signals/summary")
async def get_signal_summary() -> dict[str, Any]:
    """Get signal summary from unified_signal_manager."""
    # Validate service availability outside try to avoid TRY301
    if not service_manager.unified_signal_manager:
        raise HTTPException(status_code=503, detail="Signal system not available")

    try:
        summary = await service_manager.unified_signal_manager.get_signal_summary()
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error getting signal summary: {e}")
        await _safe_notify(
            "Market Data Error",
            f"Failed to get signal summary: {e}",
            "error",
        )
        raise HTTPException(status_code=500, detail=str(e)) from e
    else:
        return summary


@router.get("/market-data")
async def get_market_data() -> dict[str, Any]:
    """
    Get market data from persistent cache (Binance US prices).
    Returns dict keyed by base symbol with price + timestamps.
    """
    # Validate cache service outside try to avoid TRY301
    if get_persistent_cache is None:
        logger.warning("get_persistent_cache not available")
        return {"error": "Cache service not available"}

    try:
        cache = get_persistent_cache()
        latest_prices = cache.get_latest_prices()
    except Exception as e:
        logger.exception(f"Error getting cache: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting cache: {e}") from e

    # Validate market data outside try to avoid TRY301
    if not isinstance(latest_prices, dict):
        raise HTTPException(status_code=503, detail="Market data not available")

    market_data: dict[str, dict[str, Any]] = {}
    ts = datetime.now(timezone.utc).timestamp()

    for symbol, price in latest_prices.items():
        base = symbol.replace("USDT", "").replace("-USD", "")
        entry: dict[str, Any] = {
            "symbol": base,
            "timestamp": ts,
            "exchange": EXCHANGE_ID,
        }

        try:
            entry["price"] = float(price)
        except (ValueError, TypeError):
            continue

        market_data[base] = entry

    # Validate market data availability outside try to avoid TRY301
    if not market_data:
        logger.warning("No data in persistent cache")
        raise HTTPException(status_code=503, detail="Market data not available")

    return market_data


@router.get("/market-updates")
async def get_market_updates() -> dict[str, Any]:
    """Return compact update list from live market data service."""
    # Validate service availability outside try to avoid TRY301
    if not live_market_data_service:
        raise HTTPException(
            status_code=503,
            detail="Live market data service not available",
        )

    try:
        raw = await live_market_data_service.get_market_data("usd", 25)

        if isinstance(raw, dict):
            coins = raw.get("coins")
            if not isinstance(coins, list):
                coins = []
        elif isinstance(raw, list):
            coins = raw
        else:
            coins = []

        updates: list[dict[str, Any]] = []
        for coin in coins:
            if not isinstance(coin, dict):
                continue

            try:
                symbol_val = coin.get("symbol")
                if not symbol_val:
                    continue

                update_entry: dict[str, Any] = {
                    "symbol": str(symbol_val).upper(),
                    "timestamp": _now_iso(),
                }

                price = coin.get("current_price")
                if price is not None:
                    update_entry["price"] = price

                change = coin.get("price_change_percentage_24h")
                if change is not None:
                    update_entry["change_24h"] = change

                volume = coin.get("total_volume")
                if volume is not None:
                    update_entry["volume_24h"] = volume

                updates.append(update_entry)
            except Exception:
                continue

        response: dict[str, Any] = {
            "status": "success",
            "data": updates,
            "timestamp": _now_iso(),
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error getting market updates: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e
    else:
        return response


@router.get("/portfolio")
async def get_portfolio() -> dict[str, Any]:
    """Removed mock endpoint. Use real portfolio service."""
    raise HTTPException(
        status_code=501,
        detail=("Portfolio endpoint removed (no mock). Back with a real service."),
    )


@router.get("/live/portfolio")
async def get_live_portfolio() -> dict[str, Any]:
    """Removed mock endpoint."""
    raise HTTPException(
        status_code=501,
        detail="Live portfolio endpoint removed (no mock).",
    )


@router.get("/live/trades")
async def get_live_trades() -> dict[str, Any]:
    """Removed mock endpoint."""
    raise HTTPException(status_code=501, detail="Live trades endpoint removed (no mock).")


@router.get("/live/system-status")
async def get_system_status() -> dict[str, Any]:
    """Lightweight health snapshot from service_manager."""
    try:
        health = service_manager.get_health_status()
        response: dict[str, Any] = {
            "status": "success",
            "data": {"services": health, "last_update": _now_iso()},
            "timestamp": _now_iso(),
        }

        system_status = None
        if isinstance(health, dict):
            system_status = health.get("system")
        if system_status:
            response["data"]["system"] = system_status
    except Exception as e:
        logger.exception(f"Error building system status: {e}")
        raise HTTPException(status_code=500, detail="Failed to get system status") from e
    else:
        return response


@router.get("/auto-trades")
async def get_auto_trades() -> dict[str, Any]:
    """Removed mock endpoint."""
    raise HTTPException(status_code=501, detail="Auto-trades endpoint removed (no mock).")


@router.post("/auto-trade/{action}")
async def trigger_auto_trade(_action: str, _data: dict[str, Any]) -> dict[str, Any]:
    """Removed mock endpoint."""
    raise HTTPException(
        status_code=501,
        detail="Trigger auto-trade endpoint removed (no mock).",
    )
