"""
Notifications Router - Notification Management

Notification endpoints for managing user notifications.
- Live data only (no fabricated fallbacks)
"""

import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException

from backend.services.notification import get_notification_service
from backend.services.redis_service import get_redis_service

router = APIRouter()
logger = logging.getLogger(__name__)


def get_redis_client() -> Any:
    """Get Redis client."""
    try:
        return get_redis_service()
    except Exception as e:
        logger.exception(f"Error getting Redis client: {e}")
        raise HTTPException(status_code=500, detail="Redis service unavailable") from e


# Module-level dependency to avoid function call in default argument
_get_redis_client_dep = Depends(get_redis_client)


# ============================================================================
# NOTIFICATION ENDPOINTS
# ============================================================================


@router.get("/api/notifications")
async def get_notifications(
    _redis_client: Any = _get_redis_client_dep,
) -> dict[str, Any]:
    """Get user notifications from live service."""
    try:
        notification_service = get_notification_service()
        notifications = await notification_service.get_notifications()

        if not isinstance(notifications, list):
            return {
                "status": "error",
                "error": "Invalid notifications format",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        response: dict[str, Any] = {
            "notifications": notifications,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        unread_count = sum(1 for n in notifications if isinstance(n, dict) and n.get("read") is False)
        if unread_count > 0:
            response["unread_count"] = unread_count
    except ImportError:
        return {
            "status": "error",
            "error": "Notification service not available",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:
        logger.exception(f"Error getting notifications: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting notifications: {e}") from e
    else:
        return response


@router.post("/api/notifications/mark-read")
async def mark_notification_read(
    notification_id: str,
) -> dict[str, Any]:
    """Mark a notification as read."""
    try:
        notification_service = get_notification_service()
        result = await notification_service.mark_read(notification_id)

        return {
            "status": "success",
            "message": (f"Notification {notification_id} marked as read"),
            "result": result,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except ImportError:
        return {
            "status": "error",
            "error": "Notification service not available",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:
        logger.exception(f"Error marking notification as read: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Error marking notification as read: {e}",
        ) from e


@router.delete("/api/notifications/{notification_id}")
async def delete_notification(
    notification_id: str,
) -> dict[str, Any]:
    """Delete a notification."""
    try:
        notification_service = get_notification_service()
        result = await notification_service.delete_notification(notification_id)

        return {
            "status": "success",
            "message": f"Notification {notification_id} deleted",
            "result": result,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except ImportError:
        return {
            "status": "error",
            "error": "Notification service not available",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:
        logger.exception(f"Error deleting notification: {e}")
        raise HTTPException(status_code=500, detail=f"Error deleting notification: {e}") from e


@router.get("/api/notifications/settings")
async def get_notification_settings() -> dict[str, Any]:
    """Get notification settings from service."""
    try:
        notification_service = get_notification_service()
        settings = await notification_service.get_settings()

        if not isinstance(settings, dict):
            return {
                "status": "error",
                "error": "Invalid settings format",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        response: dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        # Only include keys that exist in live data
        email_notif = settings.get("email_notifications")
        if email_notif is not None:
            response["email_notifications"] = email_notif

        push_notif = settings.get("push_notifications")
        if push_notif is not None:
            response["push_notifications"] = push_notif

        trade_notif = settings.get("trade_notifications")
        if trade_notif is not None:
            response["trade_notifications"] = trade_notif

        price_alerts = settings.get("price_alerts")
        if price_alerts is not None:
            response["price_alerts"] = price_alerts

        news_notif = settings.get("news_notifications")
        if news_notif is not None:
            response["news_notifications"] = news_notif
    except ImportError:
        return {
            "status": "error",
            "error": "Notification service not available",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:
        logger.exception(f"Error getting notification settings: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Error getting notification settings: {e}",
        ) from e
    else:
        return response


@router.post("/api/notifications/settings")
async def update_notification_settings(
    settings: dict[str, Any],
) -> dict[str, Any]:
    """Update notification settings."""
    try:
        notification_service = get_notification_service()
        result = await notification_service.update_settings(settings)

        return {
            "status": "success",
            "message": "Notification settings updated",
            "settings": result,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except ImportError:
        return {
            "status": "error",
            "error": "Notification service not available",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:
        logger.exception(f"Error updating notification settings: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Error updating notification settings: {e}",
        ) from e


@router.get("/api/notifications/recent")
async def get_recent_notifications(
    _redis_client: Any = _get_redis_client_dep,
) -> dict[str, Any]:
    """Get the most recent notifications (for dashboard polling)."""
    try:
        notification_service = get_notification_service()
        notifications = await notification_service.get_recent_notifications()

        if not isinstance(notifications, list):
            return {
                "status": "error",
                "error": "Invalid notifications format",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        response: dict[str, Any] = {
            "notifications": notifications,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        unread_count = sum(1 for n in notifications if isinstance(n, dict) and n.get("read") is False)
        if unread_count > 0:
            response["unread_count"] = unread_count
    except ImportError:
        return {
            "status": "error",
            "error": "Notification service not available",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:
        logger.exception(f"Error getting recent notifications: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Error getting recent notifications: {e}",
        ) from e
    else:
        return response
