"""
Signals Router - Signal Management

Signal generation, health monitoring, and metrics endpoints.
- Live data only (no fabricated fallbacks)
"""

import contextlib
import logging
import time
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException

# Optional imports - may fail if Redis not configured
try:
    from backend.services.ai_signal_service import ai_signal_service
except (ImportError, ModuleNotFoundError, RuntimeError):
    ai_signal_service = None  # type: ignore[assignment, misc]

try:
    from backend.services.live_market_data import live_market_data_service
except (ImportError, ModuleNotFoundError, RuntimeError):
    live_market_data_service = None  # type: ignore[assignment, misc]

try:
    from backend.services.confidence_normalizer import ConfidenceNormalizer
except (ImportError, ModuleNotFoundError, RuntimeError):
    ConfidenceNormalizer = None  # type: ignore[assignment, misc]

try:
    from backend.services.signal_service import signal_service
except (ImportError, ModuleNotFoundError, RuntimeError):
    signal_service = None  # type: ignore[assignment, misc]

router = APIRouter()
logger = logging.getLogger(__name__)

# ============================================================================
# Internal helpers
# ============================================================================


def _norm_orig_conf(s: dict[str, Any]) -> Any:
    """Normalize original_confidence for validation response."""
    conf = s.get("confidence")
    if conf is None:
        return None
    if not ConfidenceNormalizer:
        return conf
    try:
        return ConfidenceNormalizer.normalize(float(conf))
    except (TypeError, ValueError):
        return conf


async def _fetch_market_coins(_currency: str = "usd", per_page: int = 50) -> list[dict[str, Any]]:
    """
    Get coin list from live market data service.
    Returns empty list if unavailable.
    Note: currency parameter reserved for future filtering.
    """
    # Check if service is available
    if live_market_data_service is None:
        logger.debug("Live market data service not available")
        return []

    try:
        # get_live_data() takes no parameters (only self)
        data = await live_market_data_service.get_live_data()
        if isinstance(data, dict):
            coins = data.get("coins")
            if isinstance(coins, list):
                # Apply currency and per_page filtering if needed
                filtered = coins[:per_page] if per_page else coins
                return filtered
        elif isinstance(data, list):
            # Apply per_page limit
            return data[:per_page] if per_page else data
    except Exception as e:
        logger.exception(f"Error fetching market coins: {e}")
        return []
    else:
        return []


def _now_iso() -> str:
    """Get current timestamp in ISO format."""
    return datetime.now(timezone.utc).isoformat()


def _classify_signal(
    change_24h: float | None,
    volume_24h: float | None,
    market_cap: float | None,
) -> tuple[str, int, str] | None:
    """
    Classify signal based on market data.
    Returns (signal, confidence, reason) or None if insufficient data.
    """
    if change_24h is None or volume_24h is None or market_cap is None:
        return None

    # High volume + strong momentum
    if volume_24h > 1_000_000_000:
        if change_24h > 8:
            return (
                "STRONG_BUY",
                85,
                "High volume + strong upward momentum",
            )
        if change_24h < -8:
            return (
                "STRONG_SELL",
                85,
                "High volume + strong downward momentum",
            )

    # Momentum
    if change_24h > 15:
        return "STRONG_BUY", 80, "Extreme upward momentum"
    if change_24h < -15:
        return "STRONG_SELL", 80, "Extreme downward momentum"

    # Large cap bias
    if market_cap > 10_000_000_000:
        if change_24h > 5:
            return "BUY", 75, "Large cap showing strength"
        if change_24h < -5:
            return "SELL", 75, "Large cap showing weakness"

    # General thresholds
    if change_24h > 10:
        return "STRONG_BUY", 85, "Strong upward momentum"
    if change_24h > 5:
        return "BUY", 70, "Upward momentum"
    if change_24h < -10:
        return "STRONG_SELL", 85, "Strong downward momentum"
    if change_24h < -5:
        return "SELL", 70, "Downward momentum"

    return "HOLD", 50, "Neutral conditions"


async def _build_basic_signals(
    per_page: int = 20,
) -> list[dict[str, Any]]:
    """Build basic signals from live market data."""
    coins = await _fetch_market_coins("usd", per_page)
    out: list[dict[str, Any]] = []
    now = time.time()

    for c in coins:
        if not isinstance(c, dict):
            continue

        change_val = c.get("price_change_percentage_24h")
        vol_val = c.get("total_volume")
        mcap_val = c.get("market_cap")

        if change_val is None or vol_val is None or mcap_val is None:
            continue

        try:
            change = float(change_val)
            vol = float(vol_val)
            mcap = float(mcap_val)
        except (ValueError, TypeError):
            continue

        sig_result = _classify_signal(change, vol, mcap)
        if not sig_result:
            continue

        sig, conf, reason = sig_result

        signal_entry: dict[str, Any] = {
            "symbol": (c.get("symbol") or "").upper(),
            "signal": sig,
            "confidence": conf,
            "reason": reason,
            "timestamp": now,
        }

        name = c.get("name")
        if name:
            signal_entry["name"] = name

        price_val = c.get("current_price")
        if price_val is not None:
            with contextlib.suppress(ValueError, TypeError):
                signal_entry["current_price"] = float(price_val)

        signal_entry["price_change_24h"] = change
        signal_entry["volume_24h"] = vol
        signal_entry["market_cap"] = mcap

        out.append(signal_entry)

    return out


async def _build_active_signals(
    per_page: int = 30,
) -> list[dict[str, Any]]:
    """Get active signals (non-HOLD) from live market data."""
    candidates = await _build_basic_signals(per_page)
    return [s for s in candidates if s.get("signal") in {"BUY", "SELL", "STRONG_BUY", "STRONG_SELL"}]


# ============================================================================
# SIGNAL MANAGEMENT ENDPOINTS
# ============================================================================


@router.get("/signals")
async def get_signals() -> dict[str, Any]:
    """Get trading signals from unified signal service."""
    try:
        result = await ai_signal_service.get_signals()
        if not isinstance(result, dict):
            return {
                "status": "error",
                "error": "Invalid signal service response",
                "timestamp": time.time(),
            }

        response: dict[str, Any] = {
            "timestamp": time.time(),
            "source": "unified_signal_service",
        }

        signals = result.get("signals")
        if signals:
            response["signals"] = signals

        total = result.get("total_signals")
        if total is not None:
            response["total_signals"] = total

        counts = result.get("counts_by_source")
        if counts:
            response["counts_by_source"] = counts

        watchlist = result.get("watchlist")
        if watchlist:
            response["watchlist"] = watchlist
    except Exception as e:
        logger.exception(f"Error getting signals: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting signals: {e}") from e
    else:
        return response


@router.get("/signals/{signal_id}")
async def get_signal(signal_id: str) -> dict[str, Any]:
    """Get a specific signal by ID (uses signal_service - legacy)."""
    if signal_service is None:
        raise HTTPException(status_code=503, detail="Signal service unavailable")
    try:
        sig = await signal_service.get_signal(signal_id)
    except Exception as e:
        logger.exception(f"Error getting signal: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting signal: {e}") from e

    if not sig:
        raise HTTPException(status_code=404, detail="Signal not found")

    return sig


@router.post("/signals")
async def create_signal(signal_data: dict[str, Any]) -> dict[str, Any]:
    """Create a new trading signal (uses signal_service - legacy)."""
    if signal_service is None:
        raise HTTPException(status_code=503, detail="Signal service unavailable")
    try:
        sig = await signal_service.create_signal(signal_data)
        return {
            "status": "success",
            "signal": sig,
            "message": "Signal created successfully",
            "timestamp": _now_iso(),
        }
    except Exception as e:
        logger.exception(f"Error creating signal: {e}")
        raise HTTPException(status_code=500, detail=f"Error creating signal: {e}") from e


@router.get("/signals/metrics")
async def get_signal_metrics() -> dict[str, Any]:
    """Get signal performance metrics - prefer ai_signal_service, fallback signal_service."""
    try:
        metrics: dict[str, Any] | None = None
        if ai_signal_service:
            data = await ai_signal_service.get_signals()
            sigs = data.get("signals") or []
            total = len(sigs)
            buy_count = sum(1 for s in sigs if str(s.get("side", s.get("type", ""))).upper() in ("BUY", "STRONG_BUY"))
            metrics = {
                "total_signals": total,
                "successful_signals": buy_count,
                "success_rate": buy_count / total if total else 0.0,
                "timestamp": _now_iso(),
            }
        if metrics is None and signal_service:
            metrics = await signal_service.get_metrics()
        if not isinstance(metrics, dict):
            metrics = {}

        response: dict[str, Any] = {
            "timestamp": _now_iso(),
            "source": "ai_signal_service" if ai_signal_service else "signal_service",
        }

        total = metrics.get("total_signals")
        if total is not None:
            response["total_signals"] = total

        successful = metrics.get("successful_signals")
        if successful is not None:
            response["successful_signals"] = successful

        failed = metrics.get("failed_signals")
        if failed is not None:
            response["failed_signals"] = failed

        success_rate = metrics.get("success_rate")
        if success_rate is not None:
            response["success_rate"] = success_rate

        avg_return = metrics.get("average_return")
        if avg_return is not None:
            response["average_return"] = avg_return

        best_signal = metrics.get("best_signal")
        if best_signal:
            response["best_signal"] = best_signal
    except Exception as e:
        logger.exception(f"Error getting signal metrics: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting signal metrics: {e}") from e
    else:
        return response


@router.get("/signals/overview")
async def get_signals_overview() -> dict[str, Any]:
    """Get signals overview with live data."""
    try:
        signals = await _build_basic_signals(per_page=20)
        response: dict[str, Any] = {
            "timestamp": time.time(),
            "source": "live_market_analysis",
        }

        if signals:
            response["signals"] = signals
            response["total_signals"] = len(signals)

            counts: dict[str, int] = {}
            for s in signals:
                sig_type = s.get("signal")
                if sig_type:
                    counts[sig_type] = counts.get(sig_type, 0) + 1

            if counts:
                response["signal_counts"] = counts
        else:
            response["signals"] = []
            response["total_signals"] = 0
    except Exception as e:
        logger.exception(f"Error getting signals overview: {e}")
        raise HTTPException(status_code=500, detail=f"Error: {e}") from e
    else:
        return response


@router.get("/signals/live")
async def get_live_signals() -> dict[str, Any]:
    """Get live trading signals - prefer ai_signal_service, fallback signal_service."""
    try:
        signals: list[dict[str, Any]] | None = None
        if ai_signal_service:
            data = await ai_signal_service.get_signals()
            signals = data.get("signals") or []
        if signals is None and signal_service:
            signals = await signal_service.get_live_signals()
        response: dict[str, Any] = {
            "timestamp": time.time(),
            "source": "live_signal_service",
        }

        if isinstance(signals, list):
            response["signals"] = signals
            if signals:
                response["total_signals"] = len(signals)
        else:
            response["signals"] = signals if signals else None
    except Exception as e:
        logger.exception(f"Error getting live signals: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting live signals: {e}") from e
    else:
        return response


@router.get("/api/signals/active")
async def get_api_active_signals() -> dict[str, Any]:
    """API endpoint for active signals."""
    if signal_service is None or ai_signal_service is None:
        return {"signals": [], "count": 0, "timestamp": time.time(), "source": "live_market_analysis"}
    return await get_active_signals()


@router.get("/api/signals/recent")
async def get_api_signals_recent(
    limit: int = 50,
) -> dict[str, Any]:
    """
    API endpoint for recent signals.
    Live-only: Uses signal service or live market data.
    """
    try:
        items: list[dict[str, Any]] = []
        if ai_signal_service:
            data = await ai_signal_service.get_signals()
            items = (data.get("signals") or [])[:limit]
        if not items and signal_service:
            latest = await signal_service.get_latest_signals()
            if isinstance(latest, list):
                items = latest
            elif latest:
                items = [latest] if isinstance(latest, dict) else []

        if not items:
            # Build from live market data if service has nothing
            basic = await _build_basic_signals(per_page=max(10, min(50, limit)))
            now_ts = time.time()

            for idx, row in enumerate(basic[:limit]):
                item: dict[str, Any] = {
                    "id": f"recent_{row.get('symbol', '')}_{idx}",
                    "timestamp": now_ts,
                    "source": "live_market_analysis",
                }

                symbol = row.get("symbol")
                if symbol:
                    item["symbol"] = symbol
                    item["symbol_display"] = symbol

                sig = row.get("signal")
                if sig:
                    item["type"] = str(sig).upper()

                conf = row.get("confidence")
                if conf is not None:
                    raw = float(conf)
                    item["confidence"] = ConfidenceNormalizer.normalize(raw) if ConfidenceNormalizer else raw

                price = row.get("current_price")
                if price is not None:
                    item["price"] = float(price)

                items.append(item)

        out = items[:limit]
        response: dict[str, Any] = {
            "signals": out,
            "timestamp": time.time(),
        }

        if out:
            response["count"] = len(out)
    except Exception as e:
        logger.exception(f"Error getting recent signals: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e
    else:
        return response


@router.get("/api/signals/alerts")
async def get_api_signal_alerts() -> dict[str, Any]:
    """API endpoint for signal alerts."""
    if signal_service is None or ai_signal_service is None:
        return {"alerts": [], "count": 0, "timestamp": time.time()}
    return await get_signal_alerts()


@router.get("/signals/active")
async def get_active_signals() -> dict[str, Any]:
    """Get currently active (non-HOLD) trading signals."""
    try:
        active = await _build_active_signals(per_page=30)
        response: dict[str, Any] = {
            "timestamp": time.time(),
            "source": "live_market_analysis",
        }

        if active:
            response["signals"] = active
            response["count"] = len(active)
        else:
            response["signals"] = []
            response["count"] = 0
    except Exception as e:
        logger.exception(f"Error getting active signals: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e
    else:
        return response


@router.get("/signals/history")
async def get_signals_history() -> dict[str, Any]:
    """Get historical signals (uses signal_service - legacy)."""
    if signal_service is None:
        return {"timestamp": time.time(), "source": "signal_service", "history": [], "performance": {}}
    try:
        history = await signal_service.get_signals_history()
        response: dict[str, Any] = {
            "timestamp": time.time(),
            "source": "signal_service",
        }

        if isinstance(history, dict):
            hist_data = history.get("history")
            if hist_data:
                response["history"] = hist_data

            perf = history.get("performance")
            if perf:
                response["performance"] = perf
        elif isinstance(history, list):
            response["history"] = history
    except Exception as e:
        logger.exception(f"Error getting signals history: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e
    else:
        return response


@router.get("/signals/performance")
async def get_signals_performance() -> dict[str, Any]:
    """Get signals performance metrics (uses signal_service - legacy)."""
    if signal_service is None:
        return {"performance": {}, "timestamp": time.time(), "source": "signal_service"}
    try:
        perf_data = await signal_service.get_performance()
        if not isinstance(perf_data, dict):
            return {
                "status": "error",
                "error": "Invalid performance data format",
                "timestamp": time.time(),
            }

        response: dict[str, Any] = {
            "performance": perf_data,
            "timestamp": time.time(),
            "source": "signal_service",
        }
    except Exception as e:
        logger.exception(f"Error getting signals performance: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e
    else:
        return response


@router.post("/signals/generate")
async def generate_signals() -> dict[str, Any]:
    """Generate new trading signals from live market conditions."""
    try:
        coins = await _fetch_market_coins("usd", 50)
        generated: list[dict[str, Any]] = []
        now = time.time()

        for c in coins:
            if not isinstance(c, dict):
                continue

            change_val = c.get("price_change_percentage_24h")
            vol_val = c.get("total_volume")
            mcap_val = c.get("market_cap")
            price_val = c.get("current_price")

            if change_val is None or vol_val is None:
                continue

            try:
                change = float(change_val)
                vol = float(vol_val)
                mcap = float(mcap_val) if mcap_val else None
                price = float(price_val) if price_val else None
            except (ValueError, TypeError):
                continue

            signals: list[dict[str, Any]] = []

            # Volume breakout signal
            if vol > 500_000_000 and abs(change) > 5:
                direction = "BUY" if change > 0 else "SELL"
                signals.append(
                    {
                        "type": "VOLUME_BREAKOUT",
                        "direction": direction,
                        "confidence": 75,
                        "reason": (f"High volume breakout with {'upward' if change > 0 else 'downward'} momentum"),
                    }
                )

            # Momentum signal
            if abs(change) > 10:
                direction = "BUY" if change > 0 else "SELL"
                signals.append(
                    {
                        "type": "MOMENTUM",
                        "direction": direction,
                        "confidence": 80,
                        "reason": (f"Strong {'upward' if change > 0 else 'downward'} momentum"),
                    }
                )

            # Market cap tilt
            if mcap is not None and mcap > 10_000_000_000:
                if change > 3:
                    signals.append(
                        {
                            "type": "LARGE_CAP_STRENGTH",
                            "direction": "BUY",
                            "confidence": 70,
                            "reason": "Large cap showing strength",
                        }
                    )
                elif change < -3:
                    signals.append(
                        {
                            "type": "LARGE_CAP_WEAKNESS",
                            "direction": "SELL",
                            "confidence": 70,
                            "reason": "Large cap showing weakness",
                        }
                    )

            if signals:
                entry: dict[str, Any] = {
                    "symbol": (c.get("symbol") or "").upper(),
                    "signals": signals,
                    "price_change_24h": change,
                    "volume_24h": vol,
                    "timestamp": now,
                }

                name = c.get("name")
                if name:
                    entry["name"] = name

                if price is not None:
                    entry["current_price"] = price

                if mcap is not None:
                    entry["market_cap"] = mcap

                generated.append(entry)

        response: dict[str, Any] = {
            "generated_signals": generated,
            "timestamp": now,
            "source": "live_signal_generation",
        }

        if generated:
            response["count"] = len(generated)
    except Exception as e:
        logger.exception(f"Error generating signals: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e
    else:
        return response


@router.post("/signals/validate")
async def validate_signals() -> dict[str, Any]:
    """Validate active signals against latest market conditions."""
    try:
        coins = await _fetch_market_coins("usd", 30)
        by_symbol: dict[str, dict[str, Any]] = {}
        for c in coins:
            if isinstance(c, dict):
                sym = (c.get("symbol") or "").upper()
                if sym:
                    by_symbol[sym] = c

        active = await _build_active_signals(per_page=30)
        validated: list[dict[str, Any]] = []
        now = time.time()

        for s in active:
            sym = s.get("symbol", "").upper()
            current = by_symbol.get(sym)
            if not current:
                continue

            change_val = current.get("price_change_percentage_24h")
            orig_change_val = s.get("price_change_24h")

            if change_val is None or orig_change_val is None:
                continue

            try:
                current_change = float(change_val)
                original_change = float(orig_change_val)
            except (ValueError, TypeError):
                continue

            signal_type = s.get("signal")
            still_valid = False
            reason = ""

            if signal_type in {"STRONG_BUY", "BUY"}:
                still_valid = current_change > original_change * 0.5
                reason = "Signal still valid - maintaining strength" if still_valid else "Signal weakened - reduced momentum"
            elif signal_type in {"STRONG_SELL", "SELL"}:
                target = original_change * 0.5
                still_valid = current_change < target
                reason = "Signal still valid - maintaining weakness" if still_valid else "Signal weakened - reduced downward pressure"

            validated.append(
                {
                    "symbol": sym,
                    "original_signal": signal_type,
                    "original_confidence": _norm_orig_conf(s),
                    "current_price_change": current_change,
                    "original_price_change": original_change,
                    "still_valid": still_valid,
                    "validation_reason": reason,
                    "timestamp": now,
                }
            )

        valid = [v for v in validated if v.get("still_valid")]
        stats: dict[str, Any] = {
            "total_signals": len(validated),
            "still_valid": len(valid),
            "invalidated": len(validated) - len(valid),
        }

        if validated:
            rate = len(valid) / len(validated) * 100
            stats["validation_rate"] = rate
    except Exception as e:
        logger.exception(f"Error validating signals: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e
    else:
        return {
            "validated_signals": validated,
            "validation_stats": stats,
            "timestamp": now,
            "source": "signal_validation",
        }


@router.get("/signals/alerts")
async def get_signal_alerts() -> dict[str, Any]:
    """Generate alerts for high-confidence active signals."""
    try:
        active = await _build_active_signals(per_page=30)
        alerts: list[dict[str, Any]] = []
        now = time.time()

        for s in active:
            conf = s.get("confidence")
            if conf is not None:
                raw = float(conf) if conf is not None else 0.0
                norm_conf = ConfidenceNormalizer.normalize(raw) if ConfidenceNormalizer else (raw / 100.0 if raw > 1 else raw)
                if norm_conf >= 0.8:
                    alert: dict[str, Any] = {
                        "type": "HIGH_CONFIDENCE_SIGNAL",
                        "signal": s.get("signal"),
                        "confidence": norm_conf,
                        "priority": "high",
                        "timestamp": now,
                    }
                    symbol = s.get("symbol")
                    if symbol:
                        alert["symbol"] = symbol
                    reason = s.get("reason")
                    if reason:
                        alert["reason"] = reason
                    alerts.append(alert)

        if len(active) > 20:
            alerts.append(
                {
                    "type": "MARKET_VOLATILITY",
                    "message": "High market volatility detected",
                    "priority": "medium",
                    "timestamp": now,
                }
            )

        response: dict[str, Any] = {
            "alerts": alerts,
            "timestamp": now,
            "source": "signal_alerts",
        }

        if alerts:
            response["count"] = len(alerts)
    except Exception as e:
        logger.exception(f"Error getting signal alerts: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e
    else:
        return response
