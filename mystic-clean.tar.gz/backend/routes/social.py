"""
Social Router - Social Trading

Endpoints for leaderboards, copy trading, and trader management.
- Live data only (no fabricated fallbacks)
"""

import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException

from backend.services.social_trading_service import get_social_trading_service

router = APIRouter()
logger = logging.getLogger(__name__)

# ============================================================================
# Helpers
# ============================================================================


def _now_iso() -> str:
    """Get current timestamp in ISO format."""
    return datetime.now(timezone.utc).isoformat()


# ============================================================================
# SOCIAL TRADING ENDPOINTS
# ============================================================================


@router.get("/api/social/leaderboard")
async def get_social_leaderboard(timeframe: str = "30d") -> dict[str, Any]:
    """Get social trading leaderboard (live data only)."""
    try:
        # Get database-backed service
        service = get_social_trading_service()
        if not service:
            raise HTTPException(status_code=503, detail="Social trading service not available")

        # Fetch leaderboard data from service
        leaderboard_data = await service.get_leaderboard(_period="monthly", category="pnl", limit=100)

        return {
            "timeframe": timeframe,
            "exchange_id": "binance_us",
            "leaderboard": leaderboard_data,
            "traders": leaderboard_data,  # Backward compatibility
            "count": len(leaderboard_data),
            "timestamp": _now_iso(),
            "source": "social_trading_service",
        }
    except Exception as e:
        logger.exception(f"Error getting social leaderboard: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting social leaderboard: {e}") from e


@router.get("/api/social/traders")
async def get_social_traders() -> dict[str, Any]:
    """Get list of social traders (live data only)."""
    try:

        def _get_service():
            service = get_social_trading_service()
            if not service:
                raise HTTPException(status_code=503, detail="Social trading service not available")
            return service

        service = _get_service()
        traders = await service.get_traders()
        result: dict[str, Any] = {
            "timestamp": _now_iso(),
            "source": "social_trading_service",
        }

        if isinstance(traders, list):
            result["traders"] = traders
            if traders:
                result["count"] = len(traders)
        else:
            result["traders"] = traders if traders else None
    except Exception as e:
        logger.exception(f"Error getting social traders: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting social traders: {e}") from e
    else:
        return result


@router.get("/api/social/traders/{trader_id}")
async def get_social_trader(trader_id: str) -> dict[str, Any]:
    """Get a specific social trader by ID (live data only)."""

    async def _get_trader():
        service = get_social_trading_service()
        if not service:
            raise HTTPException(status_code=503, detail="Social trading service not available")
        trader = await service.get_trader(trader_id)
        if not trader:
            raise HTTPException(status_code=404, detail="Trader not found")
        return trader

    try:
        trader = await _get_trader()
    except Exception as e:
        logger.exception(f"Error getting trader: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting trader: {e}") from e

    return {
        "trader": trader,
        "timestamp": _now_iso(),
        "source": "social_trading_service",
    }


@router.post("/api/social/copy-trade")
async def start_copy_trading(copy_data: dict[str, Any]) -> dict[str, Any]:
    """Start copying a trader's trades (live data only)."""
    try:

        def _get_service():
            service = get_social_trading_service()
            if not service:
                raise HTTPException(status_code=503, detail="Social trading service not available")
            return service

        service = _get_service()
        result = await service.start_copy_trading(copy_data)
        return {
            "status": "success",
            "message": "Copy trading started successfully",
            "result": result,
            "timestamp": _now_iso(),
            "source": "social_trading_service",
        }
    except Exception as e:
        logger.exception(f"Error starting copy trading: {e}")
        raise HTTPException(status_code=500, detail=f"Error starting copy trading: {e}") from e


@router.post("/api/social/stop-copy-trade")
async def stop_copy_trading(copy_data: dict[str, Any]) -> dict[str, Any]:
    """Stop copying a trader's trades (live data only)."""
    try:

        def _get_service():
            service = get_social_trading_service()
            if not service:
                raise HTTPException(status_code=503, detail="Social trading service not available")
            return service

        service = _get_service()
        result = await service.stop_copy_trading(copy_data)
        return {
            "status": "success",
            "message": "Copy trading stopped successfully",
            "result": result,
            "timestamp": _now_iso(),
            "source": "social_trading_service",
        }
    except Exception as e:
        logger.exception(f"Error stopping copy trading: {e}")
        raise HTTPException(status_code=500, detail=f"Error stopping copy trading: {e}") from e


@router.get("/api/social/copy-trades")
async def get_copy_trades() -> dict[str, Any]:
    """Get active copy trades from service (live data only)."""
    try:

        def _get_service():
            service = get_social_trading_service()
            if not service:
                raise HTTPException(status_code=503, detail="Social trading service not available")
            return service

        service = _get_service()
        copy_trades = await service.get_copy_trades()
        result: dict[str, Any] = {
            "timestamp": _now_iso(),
            "source": "social_trading_service",
        }

        if isinstance(copy_trades, list):
            result["copy_trades"] = copy_trades
            if copy_trades:
                result["count"] = len(copy_trades)
        else:
            result["copy_trades"] = copy_trades if copy_trades else None
    except Exception as e:
        logger.exception(f"Error getting copy trades: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting copy trades: {e}") from e
    else:
        return result


@router.get("/api/social/performance")
async def get_social_performance() -> dict[str, Any]:
    """Get social trading performance metrics (live data only)."""
    try:

        def _get_service():
            service = get_social_trading_service()
            if not service:
                raise HTTPException(status_code=503, detail="Social trading service not available")
            return service

        service = _get_service()
        performance = await service.get_performance()
        if not isinstance(performance, dict):
            return {
                "status": "error",
                "error": "Invalid performance data format",
                "timestamp": _now_iso(),
            }

        result: dict[str, Any] = {
            "timestamp": _now_iso(),
            "source": "social_trading_service",
        }

        total_traders = performance.get("total_traders")
        if total_traders is not None:
            result["total_traders"] = total_traders

        active_traders = performance.get("active_traders")
        if active_traders is not None:
            result["active_traders"] = active_traders

        total_copiers = performance.get("total_copiers")
        if total_copiers is not None:
            result["total_copiers"] = total_copiers

        total_copied_trades = performance.get("total_copied_trades")
        if total_copied_trades is not None:
            result["total_copied_trades"] = total_copied_trades

        avg_perf = performance.get("average_performance")
        if avg_perf is not None:
            result["average_performance"] = avg_perf

        top_trader = performance.get("top_trader")
        if top_trader is not None:
            result["top_trader"] = top_trader
    except Exception as e:
        logger.exception(f"Error getting social performance: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting social performance: {e}") from e
    else:
        return result
