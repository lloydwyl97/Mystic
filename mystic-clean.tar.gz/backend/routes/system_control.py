"""
System Control API - Restart/Start/Stop services from web interface
"""

import asyncio
import logging
import os
import subprocess
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException

from backend.config.redis_config import get_shared_redis_sync

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/control", tags=["control"])


def _default_mystic_dir() -> str:
    return str(Path(__file__).resolve().parent.parent.parent)


MYSTIC_DIR = Path(os.getenv("MYSTIC_DIR", _default_mystic_dir()))
PYTHON_PATH = MYSTIC_DIR / "venv" / "bin" / "python"


def _check_process_running(pattern: str) -> bool:
    """Check if a process matching pattern is running."""
    try:
        result = subprocess.run(
            ["pgrep", "-f", pattern],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except Exception as e:
        logger.warning("Process check failed (pgrep): %s", e)
        return False
    else:
        return result.returncode == 0


def _check_redis_sync() -> bool:
    """Check if Redis is connected (sync)."""
    try:
        client = get_shared_redis_sync()
        if client:
            client.ping()
            return True
    except Exception as ex:
        logger.warning("Redis check failed: %s", ex)
    return False


# Production scripts (matches start_mystic.sh)
_SCRIPTS = [
    ("live_data_collector.py", "collector"),
    ("start_ai_ml_trading.py", "ai"),
    ("start_agent_orchestrator.py", "agents"),
    ("start_portfolio_engine_integration.py", "portfolio"),
    ("start_ai_learning.py", "learning"),
]


@router.get("/status")
async def get_system_status() -> dict[str, Any]:
    """Get status of all Mystic services."""
    redis_ok = await asyncio.to_thread(_check_redis_sync)
    status: dict[str, Any] = {
        "backend_running": True,
        "redis_connected": redis_ok,
        "status": "ok",
    }
    for script, key in _SCRIPTS:
        status[f"{key}_running"] = _check_process_running(script)
    return status


@router.post("/restart")
async def restart_services() -> dict[str, Any]:
    """Restart all Mystic services (except backend which handles this request)."""
    logger.warning("System restart requested via API")

    try:
        for script, _ in _SCRIPTS:
            subprocess.run(["pkill", "-f", script], timeout=5, check=False)
        await asyncio.sleep(2)

        for script, _ in _SCRIPTS:
            subprocess.Popen(
                [str(PYTHON_PATH), script],
                cwd=str(MYSTIC_DIR),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
            await asyncio.sleep(1)

        logger.info("Services restarted successfully")
    except Exception as e:
        logger.exception(f"Failed to restart services: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e
    else:
        return {"status": "ok", "message": "Services restarted"}


@router.post("/start")
async def start_services() -> dict[str, Any]:
    """Start Mystic services."""
    logger.info("Service start requested via API")

    try:
        started = []
        for script, key in _SCRIPTS:
            if not _check_process_running(script):
                subprocess.Popen(
                    [str(PYTHON_PATH), script],
                    cwd=str(MYSTIC_DIR),
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True,
                )
                started.append(key)
                await asyncio.sleep(1)

        if started:
            return {"status": "ok", "message": f"Started: {', '.join(started)}"}
    except Exception as e:
        logger.exception(f"Failed to start services: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e
    else:
        return {"status": "ok", "message": "All services already running"}


@router.post("/stop")
async def stop_services() -> dict[str, Any]:
    """Stop Mystic services (except backend)."""
    logger.warning("Service stop requested via API")

    try:
        for script, _ in _SCRIPTS:
            subprocess.run(["pkill", "-f", script], timeout=5, check=False)
    except Exception as e:
        logger.exception(f"Failed to stop services: {e}")
        raise HTTPException(status_code=500, detail=str(e)) from e
    else:
        return {"status": "ok", "message": "Services stopped"}
