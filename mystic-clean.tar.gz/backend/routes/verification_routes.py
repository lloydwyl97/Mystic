"""
Trading Logic Verification Endpoints
"""

from fastapi import APIRouter

from backend.scripts.pipeline_verification_report import generate_pipeline_report

router = APIRouter(prefix="/verification", tags=["verification"])


@router.get("/pipeline-report")
async def get_pipeline_report(hours_back: int = 24) -> dict:
    """
    Get trading logic verification report

    Returns MODEL -> GATES -> EXECUTION analysis
    """
    return generate_pipeline_report(hours_back)


@router.get("/pipeline-report/sell-focus")
async def get_sell_focused_report(hours_back: int = 24) -> dict:
    """
    Get SELL-focused pipeline analysis
    """
    full_report = generate_pipeline_report(hours_back)

    return {
        "sell_path_analysis": full_report.get("sell_path_analysis", {}),
        "model_sell_percentage": full_report.get("model_distribution", {}).get("SELL_pct", 0),
        "top_sell_rejections": [r for r in full_report.get("top_rejection_reasons", []) if "SELL" in r[0]],
    }
