"""
WebSocket Router - Real-time Data (Single File)

- No fabricated data: use live services only
- Shared reader/sender loop with per-connection message rate limiting
- Light connection rate limiting (per-IP)
- Supports 'ping' -> {"type":"pong"}
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
from collections.abc import Awaitable, Callable
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect

# Lazy imports to avoid import-time failures
# from backend.endpoints.market.market_data_endpoints import get_market_live  # Moved to function
from backend.modules.ai.ai_signals import (
    get_live_signals_for_dashboard as get_signals,
)
from backend.services.market_data import MarketDataService
from backend.services.task_manager import task_manager

# Lazy imports to avoid import-time failures
# from backend.services.notification import get_notification_sink  # Moved to function
# from backend.unified_data_service import get_unified_stats, get_unified_trades  # Moved to function

# Optional: live Redis-backed connection stats (best-effort)
try:
    from backend.services.websocket_manager import get_connection_stats
except (ImportError, AttributeError):
    get_connection_stats = None  # type: ignore[assignment]

router = APIRouter()
logger = logging.getLogger(__name__)

# ============================================================================
# Utilities
# ============================================================================


def _now_iso() -> str:
    """Get current timestamp in ISO format."""
    return datetime.now(timezone.utc).isoformat()


# ============================================================================
# Lightweight connection + message rate limiting
# ============================================================================

# Max 20 new connections/min per IP
_WS_CONN_TRACKER: dict[str, list[float]] = {}
_WS_CONN_WINDOW = 60.0
_WS_CONN_MAX = 20
# WebSocket cleanup state - using dict to avoid global keyword
_ws_conn_cleanup_state: dict[str, float] = {"last_cleanup": 0.0}

# Max 60 messages/min per connection
_MSGS_PER_MIN_LIMIT = 60


# WebSocket cleanup state - using dict to avoid global keyword
_ws_conn_cleanup_state: dict[str, float] = {"last_cleanup": 0.0}


def _cleanup_conn_tracker(now: float) -> None:
    """Clean up old connection tracking data every 60 seconds with size limit."""
    if now - _ws_conn_cleanup_state["last_cleanup"] < 60.0:
        return

    # Remove old entries (older than 1 hour)
    for ip in list(_WS_CONN_TRACKER.keys()):
        _WS_CONN_TRACKER[ip] = [t for t in _WS_CONN_TRACKER[ip] if now - t < 3600.0]
        if not _WS_CONN_TRACKER[ip]:
            del _WS_CONN_TRACKER[ip]

    # Enforce hard limit on total tracker size (prevent unbounded growth)
    max_tracker_size = 500  # Hard limit to prevent memory issues
    if len(_WS_CONN_TRACKER) > max_tracker_size:
        # Remove oldest entries (by IP) to stay under limit
        sorted_ips = sorted(_WS_CONN_TRACKER.keys(), key=lambda ip: max(_WS_CONN_TRACKER[ip]) if _WS_CONN_TRACKER[ip] else 0)
        ips_to_remove = sorted_ips[: len(_WS_CONN_TRACKER) - max_tracker_size]
        for ip in ips_to_remove:
            del _WS_CONN_TRACKER[ip]
        logger.warning(f"WS tracker size exceeded {max_tracker_size}, removed {len(ips_to_remove)} old entries")

    _ws_conn_cleanup_state["last_cleanup"] = now


def _track_connection(ip: str, now: float) -> bool:
    """Track connection attempt and return True if allowed."""
    bucket = [t for t in _WS_CONN_TRACKER.get(ip, []) if now - t < _WS_CONN_WINDOW]
    if len(bucket) >= _WS_CONN_MAX:
        return False
    bucket.append(now)
    _WS_CONN_TRACKER[ip] = bucket
    return True


# ============================================================================
# Shared WS loop helpers
# ============================================================================


async def _reader_loop(
    websocket: WebSocket,
    client_ip: str,
    msg_rate_limit: int = _MSGS_PER_MIN_LIMIT,
    on_message: Callable[[str], Awaitable[None]] | None = None,
) -> None:
    """Read incoming frames, rate-limit, supports 'ping'."""
    try:
        msg_times: list[float] = []
        while True:
            data = await websocket.receive_text()
            now = asyncio.get_running_loop().time()
            msg_times = [t for t in msg_times if now - t < 60.0]
            msg_times.append(now)
            if len(msg_times) > msg_rate_limit:
                logger.warning(f"WS message rate limit exceeded for IP: {client_ip}")
                await websocket.send_text(
                    json.dumps(
                        {
                            "type": "error",
                            "error": "rate_limit",
                            "detail": "Too many messages. Please slow down.",
                            "ts": _now_iso(),
                        }
                    )
                )
                continue

            # Support both plain string "ping" and JSON {"type":"ping"} formats
            is_ping = False
            if data == "ping":
                is_ping = True
            else:
                try:
                    parsed = json.loads(data)
                    if isinstance(parsed, dict) and parsed.get("type") == "ping":
                        is_ping = True
                except (json.JSONDecodeError, AttributeError, TypeError):
                    pass  # Not JSON, not a ping

            if is_ping:
                await websocket.send_text(json.dumps({"type": "pong", "ts": _now_iso()}))
            elif on_message is not None:
                await on_message(data)
    except WebSocketDisconnect:
        pass  # graceful disconnect
    except Exception as e:
        logger.debug(f"Reader loop ended: {e}")


async def _serve_ws(
    websocket: WebSocket,
    build_payload: (Callable[[], Awaitable[dict[str, Any]]] | Callable[[], dict[str, Any]]),
    interval_sec: float,
    client_ip: str,
    msg_rate_limit: int = _MSGS_PER_MIN_LIMIT,
    on_message: Callable[[str], Awaitable[None]] | None = None,
) -> None:
    """Two-task loop: reader + periodic sender. Cancels when either ends."""
    await websocket.accept()
    try:
        reader_task = await task_manager.create_task(_reader_loop(websocket, client_ip, msg_rate_limit, on_message), name="websocket:reader_loop")

        async def _sender():
            while True:
                try:
                    if asyncio.iscoroutinefunction(build_payload):
                        payload = await build_payload()
                    else:
                        payload = build_payload()
                    await websocket.send_text(json.dumps(payload, default=str))
                except Exception as se:
                    logger.debug(f"WS sender frame warn: {se}")
                    try:
                        err_msg = {
                            "type": "error",
                            "detail": str(se),
                            "ts": _now_iso(),
                        }
                        await websocket.send_text(json.dumps(err_msg))
                    except Exception:
                        pass
                await asyncio.sleep(interval_sec)

        sender_task = await task_manager.create_task(_sender(), name="websocket:sender")
        _done, pending = await asyncio.wait({reader_task, sender_task}, return_when=asyncio.FIRST_COMPLETED)
        for t in pending:
            t.cancel()
    except WebSocketDisconnect:
        pass
    finally:
        with contextlib.suppress(Exception):
            await websocket.close()


# ============================================================================
# Payload builders (live data only, no fallbacks)
# ============================================================================


async def _payload_market_data() -> dict[str, Any]:
    """Build market data payload from live service."""
    try:
        market_service = MarketDataService.shared()
        live_data = await market_service.get_live_data()
        return {
            "type": "market_data",
            "data": live_data,
            "timestamp": _now_iso(),
        }
    except Exception as e:
        return {
            "type": "market_data_error",
            "error": f"Live data service failed: {e}",
            "timestamp": _now_iso(),
        }


async def _payload_ai_signals() -> dict[str, Any]:
    """Build AI signals payload from live service."""
    try:
        live_signals = await get_signals()
        return {
            "type": "signal",
            "data": {"signals": live_signals},
            "timestamp": _now_iso(),
        }
    except Exception as e:
        return {
            "type": "ai_signal_error",
            "error": f"Live AI signals failed: {e}",
            "timestamp": _now_iso(),
        }


async def _payload_trading_update() -> dict[str, Any]:
    """Build trading update payload from live service."""
    try:
        # Lazy import to avoid import-time failures
        try:
            from backend.unified_data_service import get_unified_stats, get_unified_trades
        except (ImportError, ModuleNotFoundError) as e:
            logger.debug(f"Unified data service not available: {e}")
            return {
                "type": "trading_update_error",
                "error": "Unified data service not available",
                "timestamp": _now_iso(),
            }

        trades = get_unified_trades(limit=5)
        recent_trades: list[dict[str, Any]] = []
        for t in trades or []:
            trade_data: dict[str, Any] = {}
            if t.get("id") is not None:
                trade_data["id"] = t.get("id")
            if t.get("symbol") is not None:
                trade_data["symbol"] = t.get("symbol")
            if t.get("side") is not None:
                trade_data["side"] = t.get("side")
            if t.get("quantity") is not None:
                trade_data["quantity"] = t.get("quantity")
            if t.get("price") is not None:
                trade_data["price"] = t.get("price")
            if t.get("timestamp") is not None:
                ts = t.get("timestamp")
                if hasattr(ts, "isoformat"):
                    trade_data["timestamp"] = ts.isoformat()
                else:
                    trade_data["timestamp"] = str(ts)
            if t.get("exit_price") is not None:
                trade_data["status"] = "filled"
                trade_data["exit_price"] = t.get("exit_price")
            else:
                trade_data["status"] = "open"
            if t.get("source") is not None:
                trade_data["source"] = t.get("source")
            if t.get("profit") is not None:
                trade_data["profit"] = t.get("profit")
            if trade_data:
                recent_trades.append(trade_data)

        stats = get_unified_stats() or {}
        account_balance: dict[str, Any] = {}
        if stats.get("total_usd") is not None:
            account_balance["total_usd"] = stats.get("total_usd")
        if stats.get("available_usd") is not None:
            account_balance["available_usd"] = stats.get("available_usd")
        if stats.get("paper_trades") is not None:
            account_balance["paper_trades"] = stats.get("paper_trades")
        if stats.get("real_trades") is not None:
            account_balance["real_trades"] = stats.get("real_trades")

        data: dict[str, Any] = {}
        if recent_trades:
            data["recent_trades"] = recent_trades
        if account_balance:
            data["account_balance"] = account_balance

        return {
            "type": "trading_update",
            "data": data,
            "timestamp": _now_iso(),
        }
    except Exception as e:
        logger.debug(f"Unified trading data unavailable: {e}")
        return {
            "type": "trading_update_error",
            "error": f"Live trading data failed: {e}",
            "timestamp": _now_iso(),
        }


async def _payload_notification() -> dict[str, Any]:
    """Build notification payload from live service."""
    try:
        # Lazy import to avoid import-time failures
        try:
            from backend.services.notification import get_notification_sink
        except (ImportError, AttributeError):
            return {
                "type": "notification_error",
                "error": "Notification service not available",
                "timestamp": _now_iso(),
            }

        sink = get_notification_sink()
        if sink and hasattr(sink, "next"):
            note = await sink.next()
            return {
                "type": "notification",
                "data": note,
                "timestamp": _now_iso(),
            }
        return {
            "type": "notification_error",
            "error": "Notification sink not available",
            "timestamp": _now_iso(),
        }
    except Exception as e:
        return {
            "type": "notification_error",
            "error": f"Notification service failed: {e}",
            "timestamp": _now_iso(),
        }


async def _payload_market_data_live() -> dict[str, Any]:
    """Build market data payload using get_market_live endpoint."""
    try:
        # Lazy import to avoid import-time failures
        from backend.endpoints.market.market_data_endpoints import get_market_live

        market_data = await get_market_live()
        return {
            "type": "market-data",
            "data": market_data,
            "timestamp": _now_iso(),
            "source": "live",
        }
    except Exception as e:
        return {
            "type": "market_data_error",
            "error": f"Live market endpoint failed: {e}",
            "timestamp": _now_iso(),
        }


# ============================================================================
# WebSocket Endpoints
# ============================================================================


@router.websocket("/ws/market-data")
async def websocket_market_data(websocket: WebSocket):
    """Real-time market data (live only)."""
    logger.info(f"WebSocket market-data connection from origin: {websocket.headers.get('Origin')}")

    now = asyncio.get_running_loop().time()
    _cleanup_conn_tracker(now)
    client_ip = websocket.client.host if websocket.client else "unknown"
    if not _track_connection(client_ip, now):
        await websocket.close(code=1008)  # Policy Violation / rate-limited
        return

    await _serve_ws(
        websocket,
        _payload_market_data_live,
        interval_sec=5.0,
        client_ip=client_ip,
    )


@router.websocket("/ws/ai-signals")
async def websocket_ai_signals(websocket: WebSocket):
    """Real-time AI signals list for dashboard."""
    logger.info(f"WebSocket ai-signals connection from origin: {websocket.headers.get('Origin')}")

    now = asyncio.get_running_loop().time()
    _cleanup_conn_tracker(now)
    client_ip = websocket.client.host if websocket.client else "unknown"
    if not _track_connection(client_ip, now):
        await websocket.close(code=1008)
        return

    await _serve_ws(websocket, _payload_ai_signals, interval_sec=5.0, client_ip=client_ip)


@router.websocket("/ws/notifications")
async def websocket_notifications(websocket: WebSocket):
    """Real-time notifications (live only)."""
    now = asyncio.get_running_loop().time()
    _cleanup_conn_tracker(now)
    client_ip = websocket.client.host if websocket.client else "unknown"
    if not _track_connection(client_ip, now):
        await websocket.close(code=1008)
        return

    await _serve_ws(
        websocket,
        _payload_notification,
        interval_sec=10.0,
        client_ip=client_ip,
    )


@router.websocket("/ws/trading-updates")
async def websocket_trading_updates(websocket: WebSocket):
    """Real-time trading updates (live only)."""
    logger.info(f"WS trading-updates connection from: {websocket.headers.get('Origin')}")

    now = asyncio.get_running_loop().time()
    _cleanup_conn_tracker(now)
    client_ip = websocket.client.host if websocket.client else "unknown"
    if not _track_connection(client_ip, now):
        await websocket.close(code=1008)
        return

    await _serve_ws(
        websocket,
        _payload_trading_update,
        interval_sec=2.0,
        client_ip=client_ip,
    )


# ============================================================================
# WebSocket management (HTTP)
# ============================================================================


@router.get("/api/websocket/status")
async def http_get_websocket_status():
    """Return WebSocket connection status if available."""
    # Validate callable outside try to avoid TRY301
    if not callable(get_connection_stats):
        msg = "WebSocket manager not available"
        raise TypeError(msg)

    try:
        return await get_connection_stats()  # type: ignore[misc]
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Live WebSocket stats unavailable: {e}") from e
