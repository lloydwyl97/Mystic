#!/usr/bin/env python3
"""
Backfill portfolio_engine_audit from paper_trades so G4 (audit integrity) can pass.

Inserts one audit row per paper_trades row (status in executed/dust_writeoff)
whose trade_id is not already present in portfolio_engine_audit.
Uses placeholder ledger JSON for historical rows (count reconciliation only).

Usage:
  python -m backend.scripts.backfill_portfolio_engine_audit [--db PATH] [--dry-run]
"""

from __future__ import annotations

import argparse
import os
import sqlite3
import sys
from pathlib import Path

if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))


def _db_path(env_path: str | None) -> str:
    return env_path or os.getenv("DB_PATH", "mystic_trading.db")


def main() -> int:
    parser = argparse.ArgumentParser(description="Backfill portfolio_engine_audit from paper_trades")
    parser.add_argument("--db", default=None, help="SQLite DB path (default: DB_PATH env or mystic_trading.db)")
    parser.add_argument("--dry-run", action="store_true", help="Only report counts and skip inserts")
    args = parser.parse_args()
    db_path = _db_path(args.db)

    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    # Ensure audit table exists
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='portfolio_engine_audit'")
    if not cur.fetchone():
        print(f"ERROR: table portfolio_engine_audit not found in {db_path}")
        conn.close()
        return 1

    # Count paper_trades (executed/dust_writeoff) and existing audit by trade_id
    cur.execute("SELECT COUNT(*) FROM paper_trades WHERE status IN ('executed','dust_writeoff')")
    pt_count = cur.fetchone()[0]
    cur.execute("SELECT trade_id FROM portfolio_engine_audit WHERE trade_id IS NOT NULL")
    audit_trade_ids = {row[0] for row in cur.fetchall()}
    audit_count = len(audit_trade_ids)

    # Rows to backfill: paper_trades with status executed/dust_writeoff and trade_id not in audit
    cur.execute(
        """
        SELECT trade_id, timestamp, side, symbol, quantity, price,
               COALESCE(fees_paid, 0), COALESCE(slippage_cost, 0), exit_type
        FROM paper_trades
        WHERE status IN ('executed','dust_writeoff')
        ORDER BY id ASC
        """
    )
    rows = cur.fetchall()

    to_insert = [r for r in rows if r[0] and r[0] not in audit_trade_ids]
    placeholder_ledger = "{}"

    print(f"paper_trades (executed/dust_writeoff): {pt_count}")
    print(f"portfolio_engine_audit (distinct trade_id): {audit_count}")
    print(f"To backfill: {len(to_insert)} rows")

    if args.dry_run:
        conn.close()
        return 0

    if not to_insert:
        print("Nothing to backfill.")
        conn.close()
        return 0

    # Insert one audit row per missing paper_trades row
    for r in rows:
        trade_id, ts, side, symbol, qty, price, fees, slippage, exit_type = r
        if not trade_id or trade_id in audit_trade_ids:
            continue
        action = (side or "BUY").upper() if isinstance(side, str) else "BUY"
        if action not in ("BUY", "SELL"):
            action = "BUY"
        cur.execute(
            """
            INSERT INTO portfolio_engine_audit (
                ts, action, symbol, qty, price, fees, slippage,
                decision_id, trade_id, ranked_candidates_json,
                pre_ledger_json, post_ledger_json,
                pre_positions_digest, post_positions_digest,
                invariant_ok, invariant_diff, entry_reason, exit_reason
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                ts or "",
                action,
                symbol or "",
                float(qty or 0),
                float(price or 0),
                float(fees or 0),
                float(slippage or 0),
                None,
                trade_id,
                "[]",
                placeholder_ledger,
                placeholder_ledger,
                None,
                None,
                1,
                0.0,
                None,
                exit_type,
            ),
        )
        audit_trade_ids.add(trade_id)

    conn.commit()
    cur.execute("SELECT COUNT(*) FROM portfolio_engine_audit")
    new_audit_count = cur.fetchone()[0]
    conn.close()
    print(f"Backfill done. portfolio_engine_audit count: {new_audit_count}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
