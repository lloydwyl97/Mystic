# PowerShell script to check PLC0415 with ruff using correct syntax
# Correct syntax: ruff check --output-format=json --select PLC0415

$ErrorActionPreference = 'Stop'

Write-Host "Running ruff check for PLC0415..." -ForegroundColor Green

# Use correct --output-format flag (not --format)
$command = "ruff check --output-format=json --select PLC0415 . > ruff_errors.json 2>&1"

Write-Host "Command: $command" -ForegroundColor Cyan

try {
    Invoke-Expression $command
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ Ruff check completed successfully" -ForegroundColor Green
    } else {
        Write-Host "⚠ Ruff found issues (exit code: $LASTEXITCODE)" -ForegroundColor Yellow
        Write-Host "Check ruff_errors.json for details" -ForegroundColor Cyan
    }
} catch {
    Write-Host "✗ Error running ruff: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host "Results saved to ruff_errors.json" -ForegroundColor Cyan

