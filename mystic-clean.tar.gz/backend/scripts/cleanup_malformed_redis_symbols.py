#!/usr/bin/env python3
"""
Redis Symbol Cleanup Script
============================

This script cleans up malformed symbol keys in Redis that may be causing
trading execution failures.

What it does:
1. Scans all ai_decision:* keys
2. Validates symbol format
3. Removes malformed keys
4. Reports on cleaned keys

SAFETY: This script only removes ai_decision:* keys, not market data or prices.
AI decisions are regenerated automatically by the AI Live Engine.

Usage:
    python -m backend.scripts.cleanup_malformed_redis_symbols [--dry-run]
"""

import argparse
import asyncio
import os
import sys
from datetime import datetime, timezone

import redis.asyncio as redis

# Add backend to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from backend.utils.canonical_symbol_formatter import CanonicalSymbolFormatter, SymbolFormatError


async def scan_and_cleanup_redis(dry_run: bool = True) -> dict:
    """
    Scan Redis for malformed ai_decision keys and clean them up.

    Args:
        dry_run: If True, only report issues without deleting

    Returns:
        Dictionary with cleanup statistics
    """
    redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")

    try:
        redis_client = redis.from_url(redis_url, decode_responses=True)
        await redis_client.ping()
        print(f"✓ Connected to Redis: {redis_url}")
    except Exception as e:
        print(f"✗ Failed to connect to Redis: {e}")
        return {"error": str(e)}

    stats = {
        "scanned": 0,
        "valid": 0,
        "malformed": 0,
        "deleted": 0,
        "errors": 0,
        "malformed_keys": [],
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

    try:
        # Scan for all ai_decision keys
        print("\nScanning ai_decision:* keys...")
        ai_keys = []
        async for k in redis_client.scan_iter(match="ai_decision:*", count=100):
            ai_keys.append(k)
        print(f"Found {len(ai_keys)} ai_decision keys")

        for key in ai_keys:
            stats["scanned"] += 1

            try:
                # Extract symbol from key (e.g., "ai_decision:BTCUSDT" -> "BTCUSDT")
                symbol = key.replace("ai_decision:", "")

                # Validate symbol format
                is_valid = CanonicalSymbolFormatter.validate(symbol)

                if is_valid:
                    stats["valid"] += 1
                    # Try to parse to catch edge cases
                    try:
                        base, quote = CanonicalSymbolFormatter.parse_symbol(symbol)
                        # Additional validation: check for double USDT
                        if "USDTUSDT" in symbol or symbol.count("USDT") > 1:
                            raise SymbolFormatError("Double USDT detected")
                        if "USDUSD" in symbol:
                            raise SymbolFormatError("Double USD detected")
                        print(f"  ✓ {key}: {symbol} -> {base}/{quote}")
                    except SymbolFormatError as e:
                        # Parsed but has issues
                        is_valid = False
                        stats["valid"] -= 1
                        stats["malformed"] += 1
                        stats["malformed_keys"].append(
                            {
                                "key": key,
                                "symbol": symbol,
                                "error": str(e),
                            }
                        )
                        print(f"  ✗ {key}: {symbol} - {e}")
                        if not dry_run:
                            await redis_client.delete(key)
                            stats["deleted"] += 1
                            print("    → DELETED")
                else:
                    stats["malformed"] += 1
                    stats["malformed_keys"].append(
                        {
                            "key": key,
                            "symbol": symbol,
                            "error": "Failed validation",
                        }
                    )
                    print(f"  ✗ {key}: {symbol} - INVALID FORMAT")
                    if not dry_run:
                        await redis_client.delete(key)
                        stats["deleted"] += 1
                        print("    → DELETED")
            except Exception as e:
                stats["errors"] += 1
                print(f"  ! Error processing {key}: {e}")

        # Also scan for ai_signal keys (similar issues)
        print("\nScanning ai_signal:* keys...")
        signal_keys = []
        async for k in redis_client.scan_iter(match="ai_signal:*", count=100):
            signal_keys.append(k)
        print(f"Found {len(signal_keys)} ai_signal keys")

        for key in signal_keys:
            stats["scanned"] += 1

            try:
                symbol = key.replace("ai_signal:", "")
                is_valid = CanonicalSymbolFormatter.validate(symbol)

                if is_valid:
                    stats["valid"] += 1
                    base, quote = CanonicalSymbolFormatter.parse_symbol(symbol)
                    # Check for double USDT
                    if "USDTUSDT" in symbol or symbol.count("USDT") > 1:
                        is_valid = False
                        stats["valid"] -= 1
                        stats["malformed"] += 1
                        stats["malformed_keys"].append(
                            {
                                "key": key,
                                "symbol": symbol,
                                "error": "Double USDT detected",
                            }
                        )
                        print(f"  ✗ {key}: {symbol} - Double USDT")
                        if not dry_run:
                            await redis_client.delete(key)
                            stats["deleted"] += 1
                            print("    → DELETED")
                    else:
                        print(f"  ✓ {key}: {symbol} -> {base}/{quote}")
                else:
                    stats["malformed"] += 1
                    stats["malformed_keys"].append(
                        {
                            "key": key,
                            "symbol": symbol,
                            "error": "Failed validation",
                        }
                    )
                    print(f"  ✗ {key}: {symbol} - INVALID FORMAT")
                    if not dry_run:
                        await redis_client.delete(key)
                        stats["deleted"] += 1
                        print("    → DELETED")
            except Exception as e:
                stats["errors"] += 1
                print(f"  ! Error processing {key}: {e}")

        await redis_client.aclose()

    except Exception as e:
        stats["errors"] += 1
        print(f"\n✗ Error during cleanup: {e}")
        stats["error"] = str(e)

    return stats


def print_summary(stats: dict, dry_run: bool):
    """Print cleanup summary"""
    print("\n" + "=" * 60)
    print("CLEANUP SUMMARY")
    print("=" * 60)
    print(f"Mode: {'DRY RUN (no changes made)' if dry_run else 'LIVE (keys deleted)'}")
    print(f"Timestamp: {stats.get('timestamp', 'N/A')}")
    print(f"\nKeys scanned: {stats['scanned']}")
    print(f"Valid keys: {stats['valid']}")
    print(f"Malformed keys: {stats['malformed']}")

    if not dry_run:
        print(f"Keys deleted: {stats['deleted']}")

    if stats["errors"] > 0:
        print(f"\n⚠ Errors encountered: {stats['errors']}")

    if stats["malformed"] > 0:
        print("\n⚠ MALFORMED KEYS FOUND:")
        for item in stats["malformed_keys"]:
            print(f"  - {item['key']}: {item['symbol']}")
            print(f"    Error: {item['error']}")

    if dry_run and stats["malformed"] > 0:
        print(f"\nRun without --dry-run to delete {stats['malformed']} malformed keys")
    elif not dry_run and stats["deleted"] > 0:
        print(f"\n✓ Successfully deleted {stats['deleted']} malformed keys")
        print("  AI decisions will be regenerated automatically by AI Live Engine")
    elif stats["malformed"] == 0:
        print("\n✓ All keys are properly formatted!")

    print("=" * 60)


async def main():
    parser = argparse.ArgumentParser(description="Clean up malformed symbol keys in Redis")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Scan and report without deleting keys (default: True)",
    )
    parser.add_argument(
        "--live",
        action="store_true",
        help="Actually delete malformed keys (use with caution)",
    )

    args = parser.parse_args()

    # Default to dry run unless --live is specified
    dry_run = not args.live

    print("=" * 60)
    print("REDIS SYMBOL CLEANUP SCRIPT")
    print("=" * 60)

    if dry_run:
        print("\n⚠ DRY RUN MODE - No changes will be made")
        print("  Use --live to actually delete malformed keys\n")
    else:
        print("\n⚠ LIVE MODE - Malformed keys will be DELETED")
        print("  Press Ctrl+C within 5 seconds to cancel...\n")
        try:
            await asyncio.sleep(5)
        except KeyboardInterrupt:
            print("\n✗ Cancelled by user")
            return

    stats = await scan_and_cleanup_redis(dry_run=dry_run)
    print_summary(stats, dry_run)


if __name__ == "__main__":
    asyncio.run(main())
