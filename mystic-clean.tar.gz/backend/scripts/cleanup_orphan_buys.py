#!/usr/bin/env python3
"""
Cleanup orphan BUYs: add dust_writeoff SELL rows for BUYs that have no matching SELL
and are not open positions. Restores BUY/SELL count consistency.

Usage:
  python -m backend.scripts.cleanup_orphan_buys [--db PATH] [--dry-run] [--backfill-audit]
"""

from __future__ import annotations

import argparse
import os
import sqlite3
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))


def _db_path(env_path: str | None) -> str:
    return env_path or os.getenv("DB_PATH", "mystic_trading.db")


def main() -> int:
    parser = argparse.ArgumentParser(description="Cleanup orphan BUYs with dust_writeoff SELLs")
    parser.add_argument("--db", default=None, help="SQLite DB path")
    parser.add_argument("--dry-run", action="store_true", help="Only report, no inserts")
    parser.add_argument("--backfill-audit", action="store_true", help="Run backfill_portfolio_engine_audit after cleanup")
    args = parser.parse_args()
    db_path = _db_path(args.db)

    if not os.path.isabs(db_path):
        db_path = os.path.abspath(db_path)
    if not Path(db_path).is_file():
        print(f"ERROR: DB not found: {db_path}")
        return 1

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='portfolio_engine_positions'")
    has_positions = cur.fetchone() is not None
    open_symbols = set()
    if has_positions:
        for row in cur.execute("SELECT symbol FROM portfolio_engine_positions WHERE quantity > 0"):
            open_symbols.add(row[0])

    cur.execute("PRAGMA table_info(paper_trades)")
    cols = {row[1] for row in cur.fetchall()}
    has_exit_type = "exit_type" in cols
    has_fees_paid = "fees_paid" in cols

    orphans: list[dict] = []
    for row in cur.execute(
        """
        SELECT symbol, COUNT(*) AS buys FROM paper_trades WHERE UPPER(side)='BUY' GROUP BY symbol
        """
    ):
        symbol = row[0]
        buy_count = row[1]
        sell_count_row = cur.execute(
            "SELECT COUNT(*) FROM paper_trades WHERE UPPER(side)='SELL' AND symbol=?",
            (symbol,),
        ).fetchone()
        sell_count = sell_count_row[0] if sell_count_row else 0
        open_adj = 1 if symbol in open_symbols else 0
        orphan_count = buy_count - sell_count - open_adj
        if orphan_count <= 0:
            continue

        buy_rows = list(
            cur.execute(
                """
                SELECT id, trade_id, paper_run_id, mode, quantity, price, timestamp
                FROM paper_trades WHERE UPPER(side)='BUY' AND symbol=?
                ORDER BY id ASC
                """,
                (symbol,),
            )
        )
        sell_rows = list(
            cur.execute(
                "SELECT id FROM paper_trades WHERE UPPER(side)='SELL' AND symbol=? ORDER BY id ASC",
                (symbol,),
            )
        )
        matched = len(sell_rows)
        unmatched_buys = buy_rows[matched:]
        if open_adj:
            unmatched_buys = unmatched_buys[:-1]
        for b in unmatched_buys:
            orphans.append(
                {
                    "id": b[0],
                    "trade_id": b[1],
                    "paper_run_id": b[2],
                    "mode": b[3],
                    "symbol": symbol,
                    "quantity": float(b[4]),
                    "price": float(b[5]),
                    "timestamp": b[6],
                }
            )

    print(f"Orphan BUYs to close: {len(orphans)}")
    if not orphans:
        conn.close()
        return 0

    if args.dry_run:
        for o in orphans[:10]:
            print(f"  Would add SELL: {o['symbol']} qty={o['quantity']} buy_trade_id={o['trade_id']}")
        if len(orphans) > 10:
            print(f"  ... and {len(orphans) - 10} more")
        conn.close()
        return 0

    ts = datetime.now(timezone.utc).isoformat(timespec="seconds")
    inserted = 0
    for o in orphans:
        sell_trade_id = f"orphan_cleanup_{o['trade_id']}_{int(time.time() * 1000)}_{inserted}"
        if has_exit_type and has_fees_paid:
            cur.execute(
                """
                INSERT INTO paper_trades (
                    trade_id, paper_run_id, mode, symbol, side, quantity, price,
                    entry_price, pnl, pnl_pct, remaining_position, hold_time_seconds,
                    fees_paid, slippage_cost, exit_type, timestamp, status
                ) VALUES (?, ?, ?, ?, 'SELL', ?, ?, ?, 0, 0, 0, NULL, 0, 0, 'ORPHAN_CLEANUP', ?, 'dust_writeoff')
                """,
                (
                    sell_trade_id,
                    o["paper_run_id"] or "default",
                    o["mode"] or "paper",
                    o["symbol"],
                    o["quantity"],
                    o["price"],
                    o["price"],
                    ts,
                ),
            )
        else:
            cur.execute(
                """
                INSERT INTO paper_trades (
                    trade_id, paper_run_id, mode, symbol, side, quantity, price,
                    entry_price, pnl, pnl_pct, remaining_position, hold_time_seconds,
                    commission, timestamp, status, exit_reason
                ) VALUES (?, ?, ?, ?, 'SELL', ?, ?, ?, 0, 0, 0, NULL, 0, ?, 'dust_writeoff', 'ORPHAN_CLEANUP')
                """,
                (
                    sell_trade_id,
                    o["paper_run_id"] or "default",
                    o["mode"] or "paper",
                    o["symbol"],
                    o["quantity"],
                    o["price"],
                    o["price"],
                    ts,
                ),
            )
        inserted += 1

    conn.commit()
    print(f"Inserted {inserted} dust_writeoff SELL rows")

    if args.backfill_audit:
        conn.close()
        import subprocess

        proj_root = Path(db_path).resolve().parent
        r = subprocess.run(
            [sys.executable, "-m", "backend.scripts.backfill_portfolio_engine_audit", "--db", db_path],
            cwd=str(proj_root),
        )
        return r.returncode

    conn.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
