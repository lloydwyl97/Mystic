#!/usr/bin/env python3
"""
COMPLETE SYSTEM CLEANUP - Fix Malformed Symbols Everywhere
===========================================================

This script cleans up ALL malformed symbol data from:
1. Redis (ai_decision, ai_signal keys)
2. SQLite (portfolio_engine_positions table)

Run this AFTER stopping all services, BEFORE restarting them.

Usage:
    python -m backend.scripts.complete_system_cleanup --live
"""

import argparse
import asyncio
import os
import sqlite3
import sys
from datetime import datetime, timezone

import redis.asyncio as redis

# Add backend to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from backend.database_schema import DATABASE_PATH
from backend.utils.canonical_symbol_formatter import CanonicalSymbolFormatter, SymbolFormatError


async def cleanup_redis(dry_run: bool = True) -> dict:
    """Clean up Redis malformed keys"""
    print("\n" + "=" * 60)
    print("REDIS CLEANUP")
    print("=" * 60)

    redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")

    try:
        redis_client = redis.from_url(redis_url, decode_responses=True)
        await redis_client.ping()
        print(f"✓ Connected to Redis: {redis_url}")
    except Exception as e:
        print(f"✗ Failed to connect to Redis: {e}")
        return {"error": str(e)}

    stats = {
        "scanned": 0,
        "valid": 0,
        "malformed": 0,
        "deleted": 0,
    }

    # Scan ai_decision keys
    print("\nScanning ai_decision:* keys...")
    ai_keys = []
    async for k in redis_client.scan_iter(match="ai_decision:*", count=100):
        ai_keys.append(k)

    for key in ai_keys:
        stats["scanned"] += 1
        symbol = key.replace("ai_decision:", "")

        try:
            # Validate
            CanonicalSymbolFormatter.parse_symbol(symbol)

            # Check for double USDT
            if "USDTUSDT" in symbol or symbol.count("USDT") > 1:
                raise SymbolFormatError("Double USDT")

            stats["valid"] += 1
            print(f"  ✓ {key}")
        except Exception as e:
            stats["malformed"] += 1
            print(f"  ✗ {key} - {e}")
            if not dry_run:
                await redis_client.delete(key)
                stats["deleted"] += 1
                print("    → DELETED")

    # Scan ai_signal keys
    print("\nScanning ai_signal:* keys...")
    signal_keys = []
    async for k in redis_client.scan_iter(match="ai_signal:*", count=100):
        signal_keys.append(k)

    for key in signal_keys:
        stats["scanned"] += 1
        symbol = key.replace("ai_signal:", "")

        try:
            CanonicalSymbolFormatter.parse_symbol(symbol)
            if "USDTUSDT" in symbol or symbol.count("USDT") > 1:
                raise SymbolFormatError("Double USDT")
            stats["valid"] += 1
            print(f"  ✓ {key}")
        except Exception as e:
            stats["malformed"] += 1
            print(f"  ✗ {key} - {e}")
            if not dry_run:
                await redis_client.delete(key)
                stats["deleted"] += 1
                print("    → DELETED")

    await redis_client.aclose()

    print(f"\nRedis: Scanned={stats['scanned']}, Valid={stats['valid']}, Malformed={stats['malformed']}, Deleted={stats['deleted']}")
    return stats


def cleanup_sqlite(dry_run: bool = True) -> dict:
    """Clean up SQLite malformed positions"""
    print("\n" + "=" * 60)
    print("SQLITE CLEANUP")
    print("=" * 60)

    db_path = os.getenv("PORTFOLIO_ENGINE_DB", DATABASE_PATH)

    if not os.path.exists(db_path):
        print(f"✗ SQLite database not found: {db_path}")
        return {"error": "Database not found"}

    print(f"✓ Found database: {db_path}")

    stats = {
        "scanned": 0,
        "valid": 0,
        "malformed": 0,
        "deleted": 0,
    }

    conn = None
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Check if table exists
        cursor.execute("""
            SELECT name FROM sqlite_master
            WHERE type='table' AND name='portfolio_engine_positions'
        """)

        if not cursor.fetchone():
            print("✗ Table 'portfolio_engine_positions' not found")
            return {"error": "Table not found"}

        # Get all positions
        cursor.execute("SELECT symbol FROM portfolio_engine_positions")
        rows = cursor.fetchall()

        print(f"\nScanning {len(rows)} positions...")

        malformed_symbols = []

        for (symbol,) in rows:
            stats["scanned"] += 1

            try:
                # Validate symbol
                CanonicalSymbolFormatter.parse_symbol(symbol)

                # Check for common malformations
                if "USDTUSDT" in symbol or symbol.count("USDT") > 1:
                    raise SymbolFormatError("Double USDT")
                if "//" in symbol or symbol.count("/") > 1:
                    raise SymbolFormatError("Multiple slashes")

                # Check if needs normalization
                normalized = CanonicalSymbolFormatter.to_ccxt(symbol)
                if normalized != symbol:
                    print(f"  ⚠ {symbol} should be {normalized} (will be auto-normalized on load)")

                stats["valid"] += 1
                print(f"  ✓ {symbol}")

            except Exception as e:
                stats["malformed"] += 1
                malformed_symbols.append(symbol)
                print(f"  ✗ {symbol} - {e}")

        # Delete malformed positions
        if malformed_symbols and not dry_run:
            for symbol in malformed_symbols:
                cursor.execute("DELETE FROM portfolio_engine_positions WHERE symbol = ?", (symbol,))
                stats["deleted"] += 1
                print(f"    → DELETED {symbol}")

            conn.commit()

    except Exception as e:
        print(f"✗ SQLite error: {e}")
        return {"error": str(e)}
    finally:
        if conn:
            conn.close()

    print(f"\nSQLite: Scanned={stats['scanned']}, Valid={stats['valid']}, Malformed={stats['malformed']}, Deleted={stats['deleted']}")
    return stats


async def main():
    parser = argparse.ArgumentParser(description="Complete system cleanup - fix all malformed symbols")
    parser.add_argument("--dry-run", action="store_true", help="Scan and report without making changes")
    parser.add_argument("--live", action="store_true", help="Actually delete malformed data (REQUIRED for cleanup)")

    args = parser.parse_args()
    dry_run = not args.live

    print("=" * 60)
    print("COMPLETE SYSTEM CLEANUP")
    print("=" * 60)
    print(f"Timestamp: {datetime.now(timezone.utc).isoformat()}")

    if dry_run:
        print("\n⚠ DRY RUN MODE - No changes will be made")
        print("  Use --live to actually clean up malformed data\n")
    else:
        print("\n⚠ LIVE MODE - Malformed data will be DELETED")
        print("  Make sure all services are STOPPED before proceeding!")
        print("  Press Ctrl+C within 5 seconds to cancel...\n")
        try:
            await asyncio.sleep(5)
        except KeyboardInterrupt:
            print("\n✗ Cancelled by user")
            return

    # Clean Redis
    redis_stats = await cleanup_redis(dry_run=dry_run)

    # Clean SQLite
    sqlite_stats = cleanup_sqlite(dry_run=dry_run)

    # Summary
    print("\n" + "=" * 60)
    print("CLEANUP SUMMARY")
    print("=" * 60)
    print(f"Mode: {'DRY RUN' if dry_run else 'LIVE'}")

    if "error" not in redis_stats:
        print("\nRedis:")
        print(f"  Scanned: {redis_stats['scanned']}")
        print(f"  Valid: {redis_stats['valid']}")
        print(f"  Malformed: {redis_stats['malformed']}")
        if not dry_run:
            print(f"  Deleted: {redis_stats['deleted']}")

    if "error" not in sqlite_stats:
        print("\nSQLite:")
        print(f"  Scanned: {sqlite_stats['scanned']}")
        print(f"  Valid: {sqlite_stats['valid']}")
        print(f"  Malformed: {sqlite_stats['malformed']}")
        if not dry_run:
            print(f"  Deleted: {sqlite_stats['deleted']}")

    total_malformed = redis_stats.get("malformed", 0) + sqlite_stats.get("malformed", 0)

    if total_malformed > 0:
        if dry_run:
            print(f"\n⚠ Found {total_malformed} malformed entries")
            print("  Run with --live to clean them up")
        else:
            total_deleted = redis_stats.get("deleted", 0) + sqlite_stats.get("deleted", 0)
            print(f"\n✓ Cleaned up {total_deleted} malformed entries")
            print("\nNEXT STEPS:")
            print("1. Verify cleanup was successful")
            print("2. Restart all trading services")
            print("3. Monitor logs for errors")
            print("4. Trading should resume normally")
    else:
        print("\n✓ No malformed data found - system is clean!")

    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
