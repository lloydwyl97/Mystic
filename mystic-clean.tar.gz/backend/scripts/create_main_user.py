"""
Create Main User Account for Lloyd
Sets up the primary user account with auto-login capability
"""

import asyncio
import sys
import traceback
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from backend.services.social_trading_service import SocialTradingService


async def create_main_user():
    """Create main user account"""
    print("Creating Main User Account...")

    # Create and initialize service
    service = SocialTradingService(database_pool_service=None, cache_service=None)

    try:
        await service.initialize()
        print("  [OK] Service initialized")
    except Exception as e:
        print(f"[ERROR] Failed to initialize service: {e}")
        return False

    try:
        # Main user data
        username = "lloyd"
        email = "lloyd@mystic-trading.local"
        display_name = "Lloyd - Main Trader"
        bio = "Primary trading account - Copying top AI strategies"

        # Check if user already exists
        existing_user = await service.get_user_by_username(username)
        if existing_user:
            print(f"  [OK] User '{username}' already exists (ID: {existing_user['id']})")
            user_id = existing_user["id"]
        else:
            # Create user
            user = await service.create_user(
                username=username,
                email=email,
                display_name=display_name,
                bio=bio,
            )

            if not user:
                print(f"  [ERROR] Failed to create user '{username}'")
                return False

            user_id = user.get("id")
            print(f"  [OK] Created user: {display_name} (ID: {user_id})")

        # Set initial stats
        initial_stats = {
            "total_trades": 0,
            "win_rate": 0.0,
            "total_pnl": 0.0,
            "total_pnl_percentage": 0.0,
            "sharpe_ratio": 0.0,
            "max_drawdown": 0.0,
            "followers_count": 0,
            "following_count": 0,
            "strategies_count": 0,
            "reputation_score": 100.0,
        }

        success = await service.update_user_stats(user_id, initial_stats)
        if success:
            print(f"  [OK] Initialized stats for user '{username}'")
        else:
            print(f"  [WARN] Could not initialize stats for user '{username}'")

        print("\n[SUCCESS] Main user account ready!")
        print(f"  Username: {username}")
        print(f"  Email: {email}")
        print(f"  User ID: {user_id}")
        print(f"  Display Name: {display_name}")

    except Exception as e:
        print(f"\n[ERROR] Error creating main user: {e}")
        traceback.print_exc()
        return False
    else:
        return True


async def main():
    """Main entry point"""
    success = await create_main_user()
    return 0 if success else 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
