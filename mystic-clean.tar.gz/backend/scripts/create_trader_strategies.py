"""
Create Default Strategies for Top Traders
Creates "All Trades" strategy for each trader to enable copy trading
"""

import asyncio
import sys
import traceback
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from backend.services.social_trading_service import SocialTradingService


async def create_strategies():
    """Create default strategies for top traders"""
    print("Creating Trader Strategies...")

    # Create and initialize service
    service = SocialTradingService(database_pool_service=None, cache_service=None)

    try:
        await service.initialize()
        print("  [OK] Service initialized")
    except Exception as e:
        print(f"[ERROR] Failed to initialize service: {e}")
        return False

    try:
        # Traders to create strategies for
        traders = [
            "value_investor",
            "cryptomaster_pro",
            "ai_trade_bot",
            "trend_follower",
            "scalp_king",
            "breakout_hunter",
            "risk_manager_pro",
            "volatility_pro",
            "mean_reversion",
            "grid_master",
        ]

        created_count = 0
        for username in traders:
            # Get user
            user = await service.get_user_by_username(username)
            if not user:
                print(f"  [WARN] User {username} not found")
                continue

            user_id = user["id"]

            # Create "All Trades" strategy
            strategy = await service.create_strategy(
                author_id=user_id,
                name=f"{user['display_name']} - All Trades",
                description=f"Copy all trades from {user['display_name']}",
                strategy_type="manual",
                symbol="ALL",
                timeframe="live",
                config={},
                indicators=[],
                entry_conditions={},
                exit_conditions={},
                is_public=True,
            )

            if strategy:
                print(f"  [OK] Created strategy for {username} (Strategy ID: {strategy['id']})")
                created_count += 1
            else:
                print(f"  [WARN] Failed to create strategy for {username}")

        print(f"\n[SUCCESS] Created {created_count} strategies")

    except Exception as e:
        print(f"\n[ERROR] Error creating strategies: {e}")
        traceback.print_exc()
        return False
    else:
        return True


async def main():
    """Main entry point"""
    success = await create_strategies()
    return 0 if success else 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
