#!/usr/bin/env python3
"""
Debug script: report why a symbol (e.g. SOL) may be "on hold" — exit not executing.

Checks:
- Redis: alerts:exit_hard_paused:* (set when 4+ exit failures)
- DB: portfolio_engine_positions (open positions)
- DB: portfolio_engine_ledger (trading_paused, pause_reason)
- DB: coin_performance (per-coin pause_until for BUY, not exit)

Output: backend/docs/EXIT_HOLD_DEBUG_REPORT.md
"""

from __future__ import annotations

import asyncio
import os
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path
from time import time as _time

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

try:
    import redis.asyncio as redis
except ImportError:
    redis = None  # type: ignore[assignment]

REDIS_URL = os.getenv("REDIS_URL", "redis://127.0.0.1:6379/0")
DB_PATH = os.getenv("DB_PATH", "mystic_trading.db")
if not Path(DB_PATH).is_absolute():
    DB_PATH = str(Path(__file__).resolve().parent.parent.parent / DB_PATH)
REPORT_PATH = "backend/docs/EXIT_HOLD_DEBUG_REPORT.md"


def _query_db(sql: str, params: tuple = ()) -> list:
    conn = sqlite3.connect(DB_PATH)
    try:
        cur = conn.cursor()
        cur.execute(sql, params)
        return cur.fetchall()
    finally:
        conn.close()


def _get_positions() -> list[dict]:
    try:
        cur_check = _query_db("SELECT name FROM sqlite_master WHERE type='table' AND name='portfolio_engine_positions'")
        if not cur_check:
            return []
        rows = _query_db(
            """SELECT symbol, quantity, entry_price, entry_time, trade_id, stop_price,
                      take_profit_1_price, take_profit_2_price, trailing_stop_price,
                      tp1_hit, highest_price, atr_at_entry, last_updated
               FROM portfolio_engine_positions"""
        )
        cols = [
            "symbol",
            "quantity",
            "entry_price",
            "entry_time",
            "trade_id",
            "stop_price",
            "take_profit_1_price",
            "take_profit_2_price",
            "trailing_stop_price",
            "tp1_hit",
            "highest_price",
            "atr_at_entry",
            "last_updated",
        ]
        return [dict(zip(cols, r, strict=True)) for r in rows]
    except Exception as e:
        return [{"_error": str(e)}]


def _get_ledger() -> dict | None:
    try:
        cur_check = _query_db("SELECT name FROM sqlite_master WHERE type='table' AND name='portfolio_engine_ledger'")
        if not cur_check:
            return None
        rows = _query_db(
            """SELECT principal, cash_balance, positions_value, total_equity,
                      account_status, trading_paused, pause_reason, last_updated
               FROM portfolio_engine_ledger WHERE id = 1"""
        )
        if not rows:
            return None
        r = rows[0]
        return {
            "principal": r[0],
            "cash_balance": r[1],
            "positions_value": r[2],
            "total_equity": r[3],
            "account_status": r[4],
            "trading_paused": bool(r[5]),
            "pause_reason": r[6] or "",
            "last_updated": r[7],
        }
    except Exception as e:
        return {"_error": str(e)}


def _get_coin_performance(symbol: str | None = None) -> list[dict]:
    try:
        cur_check = _query_db("SELECT name FROM sqlite_master WHERE type='table' AND name='coin_performance'")
        if not cur_check:
            return []
        rows = _query_db("SELECT symbol, pause_until, sizing_multiplier, trades_24h, total_trades_20, last_updated FROM coin_performance")
        if symbol:
            sym_norm = symbol.replace("/", "") if "/" in symbol else symbol
            rows = [r for r in rows if r[0] and (symbol in (r[0],) or sym_norm in (r[0].replace("/", ""),))]
        cols = ["symbol", "pause_until", "sizing_multiplier", "trades_24h", "total_trades_20", "last_updated"]
        return [dict(zip(cols, r, strict=True)) for r in rows]
    except Exception as e:
        return [{"_error": str(e)}]


async def _get_redis_exit_alerts() -> list[tuple[str, str]]:
    out: list[tuple[str, str]] = []
    try:
        if redis is None:
            out.append(("_error", "redis package not installed"))
            return out
        r = redis.from_url(REDIS_URL, decode_responses=True)
        await r.ping()
        keys = []
        async for k in r.scan_iter("alerts:exit_hard_paused:*"):
            keys.append(k)
        for k in keys:
            val = await r.get(k)
            out.append((k, val or ""))
        await r.aclose()
    except Exception as e:
        out.append(("_error", str(e)))
    return out


def _build_report(redis_alerts: list[tuple[str, str]]) -> str:
    lines: list[str] = []
    lines.append("# EXIT HOLD DEBUG REPORT")
    lines.append("")
    lines.append(f"Generated: {datetime.now(timezone.utc).isoformat()}")
    lines.append(f"DB: {DB_PATH}")
    lines.append(f"Redis: {REDIS_URL}")
    lines.append("")

    # 1. Redis exit hard-paused alerts
    lines.append("## 1. Redis: exit hard-paused alerts")
    lines.append("")
    if any(a[0] == "_error" for a in redis_alerts):
        for k, v in redis_alerts:
            lines.append(f"- **{k}**: {v}")
    elif not redis_alerts:
        lines.append("No `alerts:exit_hard_paused:*` keys found. (No symbol is currently hard-paused in Redis.)")
    else:
        for k, v in redis_alerts:
            lines.append(f"- **{k}**: `{v}`")
            lines.append("  → This symbol is skipped by the position monitor until the alert expires (24h) or is removed.")
    lines.append("")

    # 2. Open positions
    positions = _get_positions()
    lines.append("## 2. Open positions (portfolio_engine_positions)")
    lines.append("")
    if positions and "_error" in positions[0]:
        lines.append(f"Error: {positions[0]['_error']}")
    elif not positions:
        lines.append("No open positions.")
    else:
        for p in positions:
            lines.append(f"- **{p.get('symbol')}**")
            lines.append(f"  - quantity: {p.get('quantity')} | entry_price: {p.get('entry_price')} | entry_time: {p.get('entry_time')}")
            lines.append(f"  - stop_price: {p.get('stop_price')} | take_profit_1: {p.get('take_profit_1_price')} | take_profit_2: {p.get('take_profit_2_price')}")
            lines.append(f"  - trailing_stop_price: {p.get('trailing_stop_price')} | tp1_hit: {p.get('tp1_hit')} | highest_price: {p.get('highest_price')}")
            lines.append(f"  - last_updated: {p.get('last_updated')}")
    lines.append("")

    # 3. Ledger (global pause)
    ledger = _get_ledger()
    lines.append("## 3. Ledger (global trading pause)")
    lines.append("")
    if ledger is None:
        lines.append("No ledger row found.")
    elif "_error" in ledger:
        lines.append(f"Error: {ledger['_error']}")
    else:
        lines.append(f"- trading_paused: **{ledger.get('trading_paused')}**")
        lines.append(f"- pause_reason: {ledger.get('pause_reason') or '(none)'}")
        lines.append(f"- account_status: {ledger.get('account_status')}")
        lines.append(f"- cash_balance: {ledger.get('cash_balance')} | total_equity: {ledger.get('total_equity')}")
    lines.append("")

    # 4. Coin performance (SOL and any with pause_until)
    perf = _get_coin_performance("SOL/USDT")
    if not perf:
        perf = _get_coin_performance()
    lines.append("## 4. Coin performance (pause_until = per-coin BUY pause)")
    lines.append("")
    lines.append("(Per-coin pause_until affects BUYs only, not exit/sell.)")
    lines.append("")
    if perf and "_error" in perf[0]:
        lines.append(f"Error: {perf[0]['_error']}")
    elif not perf:
        lines.append("No rows (or table missing).")
    else:
        for p in perf:
            pause_until = p.get("pause_until") or 0
            is_paused = bool(pause_until and _time() < pause_until)
            lines.append(f"- **{p.get('symbol')}** | pause_until: {pause_until} | is_paused (BUY): **{is_paused}** | trades_24h: {p.get('trades_24h')} | total_trades_20: {p.get('total_trades_20')}")
    lines.append("")

    # 5. Conclusion
    lines.append("## 5. Why a position might stay on hold")
    lines.append("")
    sol_alert = any("SOL" in k for k, _ in redis_alerts if k != "_error")
    if sol_alert:
        lines.append(
            "- **SOL is in Redis `alerts:exit_hard_paused`** → The integration **skips** SOL in the "
            "position monitor (exit path never runs). Clear the Redis key or restart the app to reset "
            "in-memory state and allow exits again (until the next 4 failures)."
        )
    else:
        lines.append("- No Redis exit hard-pause alert found for SOL. If the app was restarted, in-memory `exit_hard_paused` is cleared; Redis key may have expired (24h TTL).")
    if ledger and ledger.get("trading_paused"):
        lines.append("- **Global trading_paused is True** → All sells may be blocked (depending on kill switch).")
    lines.append("- If the symbol is monitored: exit only runs when stop, TP, trailing, or time-exit condition is met.")
    lines.append("")

    return "\n".join(lines)


async def main() -> int:
    redis_alerts = await _get_redis_exit_alerts()
    report = _build_report(redis_alerts)
    out_path = Path(__file__).resolve().parent.parent / "docs" / "EXIT_HOLD_DEBUG_REPORT.md"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(report, encoding="utf-8")
    print(report)
    print(f"\nReport written to: {out_path}")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
