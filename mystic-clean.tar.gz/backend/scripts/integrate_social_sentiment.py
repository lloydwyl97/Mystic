#!/usr/bin/env python3
"""
Social Sentiment Integration Script

Connects all social sentiment components and integrates with AI training
pipeline.
- Live data only (no fabricated fallbacks)
"""

import argparse
import asyncio
import contextlib
import json
import logging
import sys
from pathlib import Path
from typing import Any

from backend.ai_training_pipeline import ai_training_pipeline
from backend.modules.ai.trade_tracker import get_trade_history
from backend.services.ai_sentiment_integration import sentiment_integration
from backend.services.market_data import MarketDataService
from backend.services.social_api_client import social_api_client
from backend.services.social_data_collector import social_collector
from backend.services.social_sentiment_processor import sentiment_processor
from backend.services.task_manager import task_manager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("social_sentiment_integration.log"),
    ],
)
logger = logging.getLogger("social_sentiment")


class SocialSentimentIntegrator:
    """
    Integrates social sentiment components with AI training pipeline.

    Connects data collection, sentiment processing, and AI integration.
    """

    def __init__(self) -> None:
        self.running = False
        self.collection_interval = 300  # 5 minutes
        self.integration_interval = 60  # 1 minute

        self.symbols: list[str] = []

        # Tasks
        self.collection_task = None
        self.integration_task = None

        logger.info("Social sentiment integrator initialized")

    async def start(self):
        """Start the integration process."""
        if self.running:
            logger.warning("Social sentiment integrator already running")
            return

        self.running = True

        # Start social API client
        try:
            await social_api_client.start()
            logger.info("Social API client started")
        except Exception as e:
            logger.exception(f"Error starting social API client: {e}")

        # Start collection and integration tasks
        self.collection_task = await task_manager.create_task(self._collection_loop(), name="integrate_social_sentiment:collection_loop")
        self.integration_task = await task_manager.create_task(self._integration_loop(), name="integrate_social_sentiment:integration_loop")

        logger.info("Social sentiment integration started")

    async def stop(self):
        """Stop the integration process."""
        if not self.running:
            return

        self.running = False

        # Cancel tasks
        if self.collection_task:
            self.collection_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self.collection_task
            self.collection_task = None

        if self.integration_task:
            self.integration_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self.integration_task
            self.integration_task = None

        # Stop social API client
        try:
            await social_api_client.stop()
            logger.info("Social API client stopped")
        except Exception as e:
            logger.exception(f"Error stopping social API client: {e}")

        logger.info("Social sentiment integration stopped")

    async def _collection_loop(self):
        """Main collection loop."""
        while self.running:
            try:
                await self._collect_social_data()
                await asyncio.sleep(self.collection_interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception(f"Error in collection loop: {e}")
                await asyncio.sleep(60)  # Retry after 1 minute

    async def _integration_loop(self):
        """Main integration loop."""
        while self.running:
            try:
                await self._integrate_sentiment()
                await asyncio.sleep(self.integration_interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception(f"Error in integration loop: {e}")
                await asyncio.sleep(60)  # Retry after 1 minute

    async def _collect_social_data(self) -> dict[str, Any]:
        """Collect social data and process sentiment."""
        try:
            # Collect data
            logger.info("Collecting social data...")
            collected_data = await social_collector.collect_data()

            if not isinstance(collected_data, list):
                collected_data = []

            logger.info(f"Collected {len(collected_data)} social media posts")

            # Process sentiment
            logger.info("Processing sentiment...")
            sentiment_data = await sentiment_processor.process_social_data(collected_data)

            if not isinstance(sentiment_data, dict):
                sentiment_data = {}

            logger.info(f"Processed sentiment for {len(sentiment_data)} symbols")

            # Update symbols from sentiment data
            if sentiment_data:
                self.symbols = list(sentiment_data.keys())

            # Log sentiment scores for symbols
            for symbol in self.symbols:
                if symbol in sentiment_data:
                    symbol_data = sentiment_data[symbol]
                    if isinstance(symbol_data, dict):
                        score = symbol_data.get("score")
                        posts = symbol_data.get("posts_count")

                        score_str = f"{float(score):.2f}" if score is not None else "N/A"

                        posts_str = f"{int(posts)} posts" if posts is not None else "N/A posts"

                        logger.info(f"{symbol} sentiment: {score_str} ({posts_str})")
        except Exception as e:
            logger.exception(f"Error collecting social data: {e}")
            return {}
        else:
            return sentiment_data

    async def _integrate_sentiment(self):
        """Integrate sentiment with AI training pipeline."""
        try:
            # Try to import AI training pipeline
            try:
                has_pipeline = True
            except Exception:
                logger.warning("AI training pipeline not available, using standalone integration")
                has_pipeline = False

            # Integrate sentiment with AI training pipeline
            logger.info("Integrating sentiment with AI training pipeline...")

            # Get live feature vectors from market data service
            features = await self._get_live_features()
            if not features:
                logger.warning("No live features available")
                return

            # Enhance feature vector for each symbol
            for symbol in self.symbols:
                enhanced_features = await sentiment_integration.enhance_feature_vector(features, symbol)

                if not isinstance(enhanced_features, dict):
                    continue

                # Log sentiment features
                score = enhanced_features.get("sentiment_score")
                magnitude = enhanced_features.get("sentiment_magnitude")
                confidence = enhanced_features.get("sentiment_confidence")
                signal = enhanced_features.get("sentiment_signal")

                if score is not None and magnitude is not None:
                    score_str = f"{float(score):.2f}"
                    mag_str = f"{float(magnitude):.2f}"
                else:
                    score_str = "N/A"
                    mag_str = "N/A"

                conf_str = f"{float(confidence):.2f}" if confidence is not None else "N/A"

                sig_str = f"{float(signal):.2f}" if signal is not None else "N/A"

                logger.info(f"{symbol} sentiment features: score={score_str}, magnitude={mag_str}, confidence={conf_str}, signal={sig_str}")

                # If we have the AI training pipeline, integrate with it
                if has_pipeline:
                    # Get live training data
                    training_data = await self._get_live_training_data(symbol)
                    if not training_data:
                        continue

                    # Enhance training data with sentiment
                    enhanced_training_data = await sentiment_integration.enhance_training_data(training_data, symbol)

                    if not enhanced_training_data:
                        continue

                    # Add to AI training pipeline
                    try:
                        ai_training_pipeline.add_training_data(enhanced_training_data)
                        logger.info(f"Added sentiment-enhanced training data for {symbol} to AI training pipeline")
                    except Exception as e:
                        logger.exception(f"Error adding training data to AI pipeline: {e}")

            logger.info("Sentiment integration complete")

        except Exception as e:
            logger.exception(f"Error integrating sentiment: {e}")

    async def _get_live_features(self) -> dict[str, Any] | None:
        """Get live feature vector from market data service."""
        try:
            mds = MarketDataService.shared()
            if not mds:
                return None

            market_data = await mds.get_market_data()
            if not isinstance(market_data, dict):
                return None

            features: dict[str, Any] = {}

            price = market_data.get("price")
            if price is not None:
                features["price"] = float(price)

            volume = market_data.get("volume")
            if volume is not None:
                features["volume"] = float(volume)

            rsi = market_data.get("rsi")
            if rsi is not None:
                features["rsi"] = float(rsi)

            macd = market_data.get("macd")
            if macd is not None:
                features["macd"] = float(macd)
        except Exception as e:
            logger.exception(f"Error getting live features: {e}")
            return None
        else:
            return features if features else None

    async def _get_live_training_data(self, symbol: str) -> dict[str, Any] | None:
        """Get live training data for symbol."""
        try:
            mds = MarketDataService.shared()
            if not mds:
                return None

            symbol_data = await mds.get_symbol_data(symbol)
            if not isinstance(symbol_data, dict):
                return None

            features: dict[str, Any] = {}

            price = symbol_data.get("price")
            if price is not None:
                features["price"] = float(price)

            volume = symbol_data.get("volume")
            if volume is not None:
                features["volume"] = float(volume)

            rsi = symbol_data.get("rsi")
            if rsi is not None:
                features["rsi"] = float(rsi)

            macd = symbol_data.get("macd")
            if macd is not None:
                features["macd"] = float(macd)

            if not features:
                return None

            # Get live targets from historical performance
            targets = await self._get_live_targets(symbol)
            if not targets:
                return None
        except Exception as e:
            logger.exception(f"Error getting live training data: {e}")
            return None
        else:
            return {
                "features": features,
                "targets": targets,
                "metadata": {"symbol": symbol},
            }

    async def _get_live_targets(self, symbol: str) -> list[float] | None:
        """Get live targets from historical performance."""
        try:
            history = get_trade_history(limit=10)
            if asyncio.iscoroutine(history):
                history = await history

            if not isinstance(history, list):
                return None

            targets: list[float] = []
            for trade in history:
                if not isinstance(trade, dict):
                    continue
                trade_symbol = trade.get("symbol")
                if trade_symbol != symbol:
                    continue
                profit = trade.get("profit")
                if profit is not None:
                    with contextlib.suppress(ValueError, TypeError):
                        targets.append(float(profit))
        except Exception as e:
            logger.exception(f"Error getting live targets: {e}")
            return None
        else:
            return targets if targets else None

    async def run_once(self) -> dict[str, Any]:
        """Run the integration process once."""
        try:
            # Collect data and process sentiment
            sentiment_data = await self._collect_social_data()

            # Integrate sentiment with AI training pipeline
            await self._integrate_sentiment()
        except Exception as e:
            logger.exception(f"Error running integration: {e}")
            return {}
        else:
            return sentiment_data if sentiment_data else {}


async def main():
    """Main entry point."""
    try:
        # Create integrator
        integrator = SocialSentimentIntegrator()

        # Parse command-line arguments
        parser = argparse.ArgumentParser(description="Social sentiment integration")
        parser.add_argument(
            "--run-once",
            action="store_true",
            help="Run once and exit",
        )
        parser.add_argument("--daemon", action="store_true", help="Run as daemon")
        args = parser.parse_args()

        if args.run_once:
            # Run once
            logger.info("Running social sentiment integration once")
            sentiment_data = await integrator.run_once()

            # Save sentiment data to file
            if sentiment_data:
                sentiment_path = Path("sentiment_data.json")
                with sentiment_path.open("w") as f:
                    json.dump(sentiment_data, f, indent=2)

            logger.info("Social sentiment integration complete")

        elif args.daemon:
            # Run as daemon
            logger.info("Starting social sentiment integration daemon")
            await integrator.start()

            try:
                # Keep running until interrupted
                while True:
                    await asyncio.sleep(1)
            except KeyboardInterrupt:
                logger.info("Stopping social sentiment integration daemon")
                await integrator.stop()

        else:
            # Run interactively
            logger.info("Starting social sentiment integration")
            await integrator.start()

            try:
                # Keep running until interrupted
                while True:
                    command = input("Enter command (q to quit): ")
                    if command.lower() == "q":
                        break
            except KeyboardInterrupt:
                pass

            logger.info("Stopping social sentiment integration")
            await integrator.stop()

    except Exception as e:
        logger.exception(f"Error in main: {e}")


if __name__ == "__main__":
    asyncio.run(main())
