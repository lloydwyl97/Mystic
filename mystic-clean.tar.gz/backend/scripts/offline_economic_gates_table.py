#!/usr/bin/env python3
"""
Structural G1-G4 table using engine-identical formulas (no Redis, no FastAPI/backend imports).

Use on dev hosts without full deps. For live Redis-backed rows, run from production venv:
  ECON_GATES_USE_REDIS=1 REDIS_URL=redis://... python3 backend/scripts/offline_economic_gates_table.py
"""

from __future__ import annotations

import json
import math
import os
import sys

# --- Universe + profiles (mirror portfolio_engine / trading_universe) ---
TRADING_SYMBOLS = [
    "BTCUSDT",
    "ETHUSDT",
    "ADAUSDT",
    "SOLUSDT",
    "DOGEUSDT",
    "XRPUSDT",
    "BCHUSDT",
    "LTCUSDT",
    "AVAXUSDT",
    "LINKUSDT",
]

COIN_PROFILES: dict[str, dict[str, float]] = {
    "BTC/USDT": {"tp": 0.0205, "sl": 0.0100, "max_hold_min": 120},
    "ETH/USDT": {"tp": 0.0195, "sl": 0.0090, "max_hold_min": 90},
    "SOL/USDT": {"tp": 0.0180, "sl": 0.0090, "max_hold_min": 60},
    "XRP/USDT": {"tp": 0.0175, "sl": 0.0085, "max_hold_min": 60},
    "ADA/USDT": {"tp": 0.0180, "sl": 0.0090, "max_hold_min": 60},
    "LTC/USDT": {"tp": 0.0195, "sl": 0.0090, "max_hold_min": 90},
    "BCH/USDT": {"tp": 0.0175, "sl": 0.0085, "max_hold_min": 60},
    "DOGE/USDT": {"tp": 0.0185, "sl": 0.0095, "max_hold_min": 75},
    "AVAX/USDT": {"tp": 0.0180, "sl": 0.0090, "max_hold_min": 75},
    "LINK/USDT": {"tp": 0.0175, "sl": 0.0085, "max_hold_min": 75},
}

MAJOR_COINS = {"BTC/USDT", "ETH/USDT", "LTC/USDT"}
MAJOR_COIN_SL_BOUNDS = {
    "BTC/USDT": (0.009, 0.018),
    "ETH/USDT": (0.0075, 0.015),
    "LTC/USDT": (0.007, 0.014),
}
MAJOR_COIN_ATR_SL_MULT = 1.8
ATR_MULTIPLIER = 1.5
MIN_STOP_PCT = 0.005
TAKER_FEE = 0.001
SLIPPAGE_PCT = 0.0005
SLEEVE_CORE_SYMBOLS = {"BTC/USDT", "ETH/USDT"}
SLEEVE_NO_CORE_BY_HOLD = {
    "DOGE/USDT",
    "XRP/USDT",
    "ADA/USDT",
    "AVAX/USDT",
    "LINK/USDT",
    "SOL/USDT",
}
SLEEVE_CORE_MIN_CONFIDENCE = float(os.getenv("SLEEVE_CORE_MIN_CONFIDENCE", "0.65"))
SLEEVE_CORE_HOLD_THRESHOLD_MIN = int(os.getenv("SLEEVE_CORE_HOLD_THRESHOLD_MIN", "75"))


def bus_to_ccxt(bus: str) -> str:
    u = bus.upper().replace("/", "")
    if u.endswith("USDT"):
        return f"{u[:-4]}/USDT"
    return bus


def get_profile(sym: str) -> dict[str, float]:
    return COIN_PROFILES.get(sym, {"tp": 0.018, "sl": 0.009, "max_hold_min": 60})


def assign_sleeve(sym: str, confidence: float) -> str:
    profile = get_profile(sym)
    max_hold = int(profile.get("max_hold_min", 60))
    is_core_symbol = sym in SLEEVE_CORE_SYMBOLS
    is_high_hold = max_hold >= SLEEVE_CORE_HOLD_THRESHOLD_MIN and sym not in SLEEVE_NO_CORE_BY_HOLD
    meets = confidence >= SLEEVE_CORE_MIN_CONFIDENCE
    if (is_core_symbol or is_high_hold) and meets:
        return "CORE"
    return "ACTIVE"


def compute_volatility_stop(symbol: str, atr: float, price: float) -> float:
    if price <= 0:
        return get_profile(symbol)["sl"]
    atr_pct = atr / price
    if atr_pct <= 0:
        return get_profile(symbol)["sl"]
    dynamic_sl = atr_pct * MAJOR_COIN_ATR_SL_MULT
    floor, ceiling = MAJOR_COIN_SL_BOUNDS.get(symbol, (0.007, 0.015))
    return max(floor, min(dynamic_sl, ceiling))


def bar_style_stop_pct(symbol: str, price: float, atr: float) -> tuple[float, float]:
    """Return (stop_price, actual_sl_pct) mirroring process_bar + majors."""
    prof = get_profile(symbol)
    slp = float(prof["sl"])
    if price <= 0 or atr <= 0:
        return price * (1 - slp), slp
    if symbol in MAJOR_COINS:
        dyn = compute_volatility_stop(symbol, atr, price)
        stop_dist = price * dyn
    else:
        atr_stop = atr * ATR_MULTIPLIER
        floor_stop = price * max(MIN_STOP_PCT, slp)
        stop_dist = max(atr_stop, floor_stop)
    sp = price - stop_dist
    act = stop_dist / price
    return sp, act


def run_scenario(
    *,
    label: str,
    price: float,
    atr_ratio: float,
    spread_pct_pts: float | None,
    confidence: float,
) -> list[dict[str, object]]:
    atr = price * atr_ratio
    profit_buf = float(os.getenv("PROFIT_EDGE_BUFFER_PCT", "0.001"))
    default_spread_frac = float(os.getenv("DEFAULT_SPREAD_PCT", "0.0015"))
    spread_frac = default_spread_frac
    if spread_pct_pts is not None and spread_pct_pts > 0 and math.isfinite(spread_pct_pts):
        spread_frac = max(spread_frac, spread_pct_pts / 100.0)
    slippage_rt = SLIPPAGE_PCT * 2
    required_edge = (2 * TAKER_FEE) + slippage_rt + spread_frac + profit_buf
    tp_margin = float(os.getenv("TP_VIABILITY_MARGIN_PCT", "0.002"))
    g2_thresh = required_edge + tp_margin
    erc = float(os.getenv("ESTIMATED_ROUNDTRIP_COST", "0.0055"))
    min_rr_core = float(os.getenv("MIN_REWARD_RISK_RATIO_CORE", "0.88"))
    min_rr_active = float(os.getenv("MIN_REWARD_RISK_RATIO_ACTIVE", "0.78"))
    default_exp = float(os.getenv("DEFAULT_EXPECTED_MOVE_PCT", "0.0040"))

    rows: list[dict[str, object]] = []
    for bus in TRADING_SYMBOLS:
        sym = bus_to_ccxt(bus)
        prof = get_profile(sym)
        tp = float(prof["tp"])
        slp = float(prof["sl"])
        slv = assign_sleeve(sym, confidence)
        atr_m = atr / price if price > 0 else 0.0
        exp = max(atr_m, tp)
        move_src = "atr" if atr_m >= tp else "tp_profile"
        if exp <= 0:
            exp = default_exp
            move_src = "default_fallback"
        g1 = exp > required_edge
        g2 = tp >= g2_thresh
        _, act_sl = bar_style_stop_pct(sym, price, atr)
        sl_risk = max(slp, act_sl)
        net_r = tp - erc
        net_x = sl_risk + erc
        rr = net_r / net_x if net_x > 0 else 0.0
        min_rr = min_rr_core if slv == "CORE" else min_rr_active
        g3 = rr >= min_rr
        noise_floor = atr_m * 0.7 if atr_m > 0 else float("inf")
        g4 = not (atr_m > 0 and act_sl < noise_floor)
        block = "NONE"
        if not g1:
            block = "G1"
        elif not g2:
            block = "G2"
        elif not g3:
            block = "G3"
        elif not g4:
            block = "G4"
        rows.append(
            {
                "scenario": label,
                "symbol": sym,
                "sleeve": slv,
                "tp_profile": tp,
                "sl_profile": slp,
                "spread_frac_used": spread_frac,
                "spread_pct_pts_admission": spread_pct_pts,
                "atr_over_price": atr_m,
                "expected_move": exp,
                "expected_move_source": move_src,
                "required_edge": required_edge,
                "G1_pass": g1,
                "G2_threshold": g2_thresh,
                "G2_pass": g2,
                "actual_sl_pct": act_sl,
                "G3_rr": rr,
                "G3_min_rr": min_rr,
                "G3_pass": g3,
                "G4_pass": g4,
                "first_blocker": block,
            }
        )
    return rows


def try_redis_overlay(price: float, confidence: float) -> list[dict[str, object]] | None:
    if os.getenv("ECON_GATES_USE_REDIS", "").lower() not in ("1", "true", "yes"):
        return None
    try:
        import redis  # type: ignore[import-untyped]
    except ImportError:
        print("ECON_GATES_USE_REDIS set but redis package not installed", file=sys.stderr)
        return None
    url = os.getenv("REDIS_URL") or os.getenv("REDIS_HOST")
    if not url:
        return None
    if not str(url).startswith("redis://"):
        host = os.getenv("REDIS_HOST", "127.0.0.1")
        port = os.getenv("REDIS_PORT", "6379")
        db = os.getenv("REDIS_DB", "0")
        url = f"redis://{host}:{port}/{db}"
    try:
        r = redis.Redis.from_url(url, decode_responses=True)
        r.ping()
    except Exception as e:
        print(f"Redis unavailable: {e}", file=sys.stderr)
        return None

    rows: list[dict[str, object]] = []
    for bus in TRADING_SYMBOLS:
        sym = bus_to_ccxt(bus)
        base = bus[:-4] if bus.upper().endswith("USDT") else bus
        px, atr_v, spread_pts = price, 0.0, None
        try:
            raw = r.get(f"market:{base}")
            if raw:
                m = json.loads(raw)
                px = float(m.get("price") or m.get("last") or px)
                atr_v = float(m.get("atr") or 0)
                if m.get("spread_pct") is not None:
                    spread_pts = float(m["spread_pct"])
        except Exception:
            pass
        if px <= 0:
            try:
                v = r.hget(f"price:{base}", "v")
                if v:
                    px = float(v)
            except Exception:
                pass
        try:
            spct = r.hget(f"ai_signal:{bus.upper()}", "spread_pct")
            ats = r.hget(f"ai_signal:{bus.upper()}", "atr")
            cfs = r.hget(f"ai_signal:{bus.upper()}", "confidence")
            if ats:
                atr_v = float(ats)
            if spct:
                spread_pts = float(spct)
            if cfs:
                confidence = float(cfs)
        except Exception:
            pass
        atr_ratio = (atr_v / px) if px > 0 and atr_v > 0 else float(os.getenv("ECON_GATES_FALLBACK_ATR_RATIO", "0.015"))
        one = run_scenario(
            label="live_redis_overlay",
            price=px if px > 0 else price,
            atr_ratio=atr_ratio,
            spread_pct_pts=spread_pts,
            confidence=confidence,
        )
        for row in one:
            if row["symbol"] == sym:
                rows.append(row)
                break
    return rows if rows else None


def main() -> int:
    conf = float(os.getenv("ECON_GATES_CONFIDENCE", "0.66"))
    price = float(os.getenv("ECON_GATES_REF_PRICE", "100.0"))

    scenarios = [
        ("high_vol_2pct_atr_default_spread", 0.02, None),
        ("high_vol_2pct_atr_admitted_spread_8bp", 0.02, 0.08),
        ("low_vol_min_bar_atr_default_spread", float(os.getenv("MIN_ATR_RATIO", "0.0001")), None),
    ]

    all_rows: list[dict[str, object]] = []
    for label, ar, sp in scenarios:
        all_rows.extend(run_scenario(label=label, price=price, atr_ratio=ar, spread_pct_pts=sp, confidence=conf))

    redis_rows = try_redis_overlay(price=price, confidence=conf)
    if redis_rows:
        all_rows = redis_rows

    print(json.dumps(all_rows, indent=2))

    counts: dict[str, int] = {}
    for row in all_rows:
        fb = str(row["first_blocker"])
        key = f"{row.get('scenario')}:{fb}"
        counts[key] = counts.get(key, 0) + 1
    print("\n# counts by scenario:first_blocker", file=sys.stderr)
    print(json.dumps(counts, indent=2), file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
