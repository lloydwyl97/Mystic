#!/usr/bin/env python3
"""
Pipeline Verification Report - 24h Summary
Analyzes MODEL -> GATES -> EXECUTION decision flow
"""

import json
import sqlite3
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any

from backend.database_schema import DATABASE_PATH


def generate_pipeline_report(hours_back: int = 24) -> dict[str, Any]:
    """Generate comprehensive pipeline verification report"""

    conn = sqlite3.connect(DATABASE_PATH)
    try:
        cursor = conn.cursor()

        # Calculate time window
        end_time = datetime.now(timezone.utc).timestamp()
        start_time = end_time - (hours_back * 3600)

        # Get all decisions in time window
        cursor.execute(
            """
            SELECT decision_id, symbol, model_class, model_probs_json,
                   gate_result, gate_reason, execution_result, execution_reason
            FROM pipeline_decisions
            WHERE timestamp >= ? AND timestamp <= ?
            ORDER BY timestamp DESC
        """,
            (start_time, end_time),
        )

        decisions = cursor.fetchall()
    finally:
        conn.close()

    if not decisions:
        return {"error": "No decisions found in time window", "hours_back": hours_back}

    # Check for broken integration
    model_count = len([d for d in decisions if d[2] is not None])  # model_class is not None
    gate_count = len([d for d in decisions if d[4] is not None])  # gate_result is not None
    execution_count = len([d for d in decisions if d[6] is not None])  # execution_result is not None

    if model_count > 0 and gate_count == 0:
        return {
            "status": "BROKEN_INTEGRATION",
            "error": "MODEL stage recording but GATES stage not recording",
            "model_count": model_count,
            "gate_count": gate_count,
            "execution_count": execution_count,
            "missing_consumers": ["portfolio_engine_integration.py", "ai_paper_autobuy_service.py", "ai_live_autobuy_service.py"],
        }

    # Parse decisions
    parsed_decisions = []
    for d in decisions:
        model_probs = json.loads(d[3]) if d[3] else {"sell": 0, "hold": 0, "buy": 0}
        parsed_decisions.append(
            {"decision_id": d[0], "symbol": d[1], "model_class": d[2], "model_probs": model_probs, "gate_result": d[4], "gate_reason": d[5], "execution_result": d[6], "execution_reason": d[7]}
        )

    # Calculate statistics
    report = {
        "report_generated_at": datetime.now(timezone.utc).isoformat(),
        "time_window": f"Last {hours_back} hours",
        "total_decisions": len(parsed_decisions),
        "model_distribution": _calculate_model_distribution(parsed_decisions),
        "gate_analysis": _calculate_gate_analysis(parsed_decisions),
        "execution_analysis": _calculate_execution_analysis(parsed_decisions),
        "top_rejection_reasons": _calculate_top_rejection_reasons(parsed_decisions),
        "sell_path_analysis": _calculate_sell_path_analysis(parsed_decisions),
        "pipeline_efficiency": _calculate_pipeline_efficiency(parsed_decisions),
    }

    return report


def _calculate_model_distribution(decisions: list[dict[str, Any]]) -> dict[str, Any]:
    """Calculate model prediction distribution"""
    model_counts = {"BUY": 0, "HOLD": 0, "SELL": 0}

    for d in decisions:
        model_class = d.get("model_class", "HOLD")
        model_counts[model_class] = model_counts.get(model_class, 0) + 1

    total = len(decisions)
    return {
        "BUY_pct": round((model_counts["BUY"] / total) * 100, 1) if total > 0 else 0,
        "HOLD_pct": round((model_counts["HOLD"] / total) * 100, 1) if total > 0 else 0,
        "SELL_pct": round((model_counts["SELL"] / total) * 100, 1) if total > 0 else 0,
        "counts": model_counts,
        "total": total,
    }


def _calculate_gate_analysis(decisions: list[dict[str, Any]]) -> dict[str, Any]:
    """Calculate gate pass/reject analysis"""
    gate_counts = {"PASS": 0, "REJECT": 0}
    gate_reasons = defaultdict(int)

    for d in decisions:
        gate_result = d.get("gate_result")
        if gate_result:
            gate_counts[gate_result] = gate_counts.get(gate_result, 0) + 1

            if gate_result == "REJECT" and d.get("gate_reason"):
                gate_reasons[d["gate_reason"]] += 1

    total_gated = sum(gate_counts.values())

    return {
        "PASS_pct": round((gate_counts["PASS"] / total_gated) * 100, 1) if total_gated > 0 else 0,
        "REJECT_pct": round((gate_counts["REJECT"] / total_gated) * 100, 1) if total_gated > 0 else 0,
        "rejection_reasons": dict(gate_reasons),
        "total_gated": total_gated,
    }


def _calculate_execution_analysis(decisions: list[dict[str, Any]]) -> dict[str, Any]:
    """Calculate execution results analysis"""
    execution_counts = defaultdict(int)

    for d in decisions:
        execution_result = d.get("execution_result")
        if execution_result:
            execution_counts[execution_result] += 1

    total_executed = sum(execution_counts.values())

    return {
        "EXECUTED_BUY": execution_counts.get("EXECUTED_BUY", 0),
        "EXECUTED_SELL": execution_counts.get("EXECUTED_SELL", 0),
        "NOT_EXECUTED": execution_counts.get("NOT_EXECUTED", 0),
        "EXECUTED_BUY_pct": round((execution_counts.get("EXECUTED_BUY", 0) / total_executed) * 100, 1) if total_executed > 0 else 0,
        "EXECUTED_SELL_pct": round((execution_counts.get("EXECUTED_SELL", 0) / total_executed) * 100, 1) if total_executed > 0 else 0,
        "NOT_EXECUTED_pct": round((execution_counts.get("NOT_EXECUTED", 0) / total_executed) * 100, 1) if total_executed > 0 else 0,
        "total": total_executed,
    }


def _calculate_top_rejection_reasons(decisions: list[dict[str, Any]]) -> list[tuple[str, int]]:
    """Calculate top 5 rejection reasons across gate and execution stages"""
    rejection_counts = defaultdict(int)

    for d in decisions:
        # Gate rejections
        if d.get("gate_result") == "REJECT" and d.get("gate_reason"):
            rejection_counts[f"GATE: {d['gate_reason']}"] += 1

        # Execution rejections
        if d.get("execution_result") == "NOT_EXECUTED" and d.get("execution_reason"):
            rejection_counts[f"EXEC: {d['execution_reason']}"] += 1

    # Sort by count, return top 5
    return sorted(rejection_counts.items(), key=lambda x: x[1], reverse=True)[:5]


def _calculate_sell_path_analysis(decisions: list[dict[str, Any]]) -> dict[str, Any]:
    """Specific SELL path analysis"""
    model_sell_count = 0
    gate_pass_sell_count = 0
    executed_sell_count = 0

    for d in decisions:
        if d.get("model_class") == "SELL":
            model_sell_count += 1

            if d.get("gate_result") == "PASS":
                gate_pass_sell_count += 1

                if d.get("execution_result") == "EXECUTED_SELL":
                    executed_sell_count += 1

    return {
        "model_sell_predictions": model_sell_count,
        "gate_pass_sells": gate_pass_sell_count,
        "executed_sells": executed_sell_count,
        "sell_gate_efficiency": round((gate_pass_sell_count / model_sell_count) * 100, 1) if model_sell_count > 0 else 0,
        "sell_execution_efficiency": round((executed_sell_count / gate_pass_sell_count) * 100, 1) if gate_pass_sell_count > 0 else 0,
        "sell_overall_efficiency": round((executed_sell_count / model_sell_count) * 100, 1) if model_sell_count > 0 else 0,
    }


def _calculate_pipeline_efficiency(decisions: list[dict[str, Any]]) -> dict[str, Any]:
    """Overall pipeline efficiency metrics"""
    total_model_predictions = len(decisions)
    gate_pass_count = sum(1 for d in decisions if d.get("gate_result") == "PASS")
    execution_count = sum(1 for d in decisions if d.get("execution_result") in ["EXECUTED_BUY", "EXECUTED_SELL"])

    return {
        "model_to_gate_efficiency": round((gate_pass_count / total_model_predictions) * 100, 1) if total_model_predictions > 0 else 0,
        "gate_to_execution_efficiency": round((execution_count / gate_pass_count) * 100, 1) if gate_pass_count > 0 else 0,
        "overall_efficiency": round((execution_count / total_model_predictions) * 100, 1) if total_model_predictions > 0 else 0,
    }


if __name__ == "__main__":
    import sys

    hours_back = float(sys.argv[1]) if len(sys.argv) > 1 else 24
    report = generate_pipeline_report(hours_back)
    print(json.dumps(report, indent=2))
