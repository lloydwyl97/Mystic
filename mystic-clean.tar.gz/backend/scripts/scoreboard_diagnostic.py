#!/usr/bin/env python3
"""Diagnostic: paper_trades BUY/SELL counts and audit alignment."""

import os
import sqlite3
import sys
from pathlib import Path

_root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_root))
db_path = os.getenv("DATABASE_PATH", str(_root / "mystic_trading.db"))


def main():
    resolved = db_path
    if not Path(resolved).exists():
        alt = Path("/home/mystic/mystic_trading.db")
        if alt.exists():
            resolved = str(alt)
    if not Path(resolved).exists():
        print(f"DB not found: {resolved}")
        return 1

    conn = sqlite3.connect(resolved)
    cur = conn.cursor()

    # paper_trades counts
    cur.execute("SELECT COUNT(*) FROM paper_trades WHERE UPPER(side)='BUY'")
    buy_count = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM paper_trades WHERE UPPER(side)='SELL'")
    sell_count = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM paper_trades WHERE UPPER(side)='BUY' AND COALESCE(remaining_position, 0) > 0")
    buy_open = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM paper_trades WHERE UPPER(side)='BUY' AND COALESCE(remaining_position, 0) = 0")
    buy_closed = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM paper_trades WHERE pnl IS NOT NULL")
    with_pnl = cur.fetchone()[0]

    # portfolio_engine_positions
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='portfolio_engine_positions'")
    has_pos = cur.fetchone() is not None
    pos_count = 0
    if has_pos:
        cur.execute("SELECT COUNT(*) FROM portfolio_engine_positions")
        pos_count = cur.fetchone()[0]

    # portfolio_engine_audit
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='portfolio_engine_audit'")
    has_audit = cur.fetchone() is not None
    audit_buy = audit_sell = audit_today = audit_sell_today = 0
    if has_audit:
        cur.execute("SELECT COUNT(*) FROM portfolio_engine_audit WHERE action='BUY'")
        audit_buy = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM portfolio_engine_audit WHERE action='SELL'")
        audit_sell = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM portfolio_engine_audit WHERE ts >= date('now', 'start of day')")
        audit_today = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM portfolio_engine_audit WHERE ts >= date('now', 'start of day') AND action='SELL'")
        audit_sell_today = cur.fetchone()[0]

    conn.close()

    print("=== PAPER_TRADES ===")
    print(f"  BUY rows:     {buy_count}")
    print(f"  SELL rows:    {sell_count}")
    print(f"  BUY open (remaining>0): {buy_open}")
    print(f"  BUY closed (remaining=0): {buy_closed}")
    print(f"  Rows with pnl (Total Trades): {with_pnl}")
    print()
    print("=== PORTFOLIO_ENGINE_POSITIONS ===")
    print(f"  Open positions: {pos_count}")
    print()
    print("=== PORTFOLIO_ENGINE_AUDIT ===")
    print(f"  Audit BUY rows:  {audit_buy}")
    print(f"  Audit SELL rows: {audit_sell}")
    if has_audit:
        print(f"  Audit today total: {audit_today}")
        print(f"  Audit today SELL:  {audit_sell_today}")
    print()
    print("=== CONSISTENCY ===")
    orphan = buy_count - sell_count - pos_count
    if orphan > 10:
        print(f"  ORPHANED BUYs (approx): {orphan} (buy - sell - open_pos)")
    else:
        print(f"  BUY-SELL delta: {buy_count - sell_count} (expected ~open positions)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
