"""
Seed Social Trading Data
Populates the database with sample traders, strategies, and activity
"""

import asyncio
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from backend.services.social_trading_manager import social_trading_manager


async def seed_social_data():
    """Seed social trading data with sample traders and performance"""
    print("Seeding Social Trading Data...")

    try:
        # Sample traders with realistic performance data
        sample_traders = [
            {
                "trader_id": "trader_001",
                "name": "CryptoMaster",
                "strategy": "Momentum Trading",
                "performance": {"pnl": 2547.50, "win_rate": 0.68, "total_trades": 156, "avg_return": 0.035},
                "followers": 342,
                "status": "active",
                "joined_at": "2024-09-15T10:30:00Z",
            },
            {
                "trader_id": "trader_002",
                "name": "AITradeBot",
                "strategy": "AI-Powered Swing",
                "performance": {"pnl": 1823.75, "win_rate": 0.72, "total_trades": 98, "avg_return": 0.042},
                "followers": 289,
                "status": "active",
                "joined_at": "2024-10-01T14:20:00Z",
            },
            {
                "trader_id": "trader_003",
                "name": "TrendFollower",
                "strategy": "Trend Analysis",
                "performance": {"pnl": 1456.20, "win_rate": 0.65, "total_trades": 203, "avg_return": 0.028},
                "followers": 178,
                "status": "active",
                "joined_at": "2024-08-20T09:15:00Z",
            },
            {
                "trader_id": "trader_004",
                "name": "ScalpKing",
                "strategy": "High-Frequency Scalping",
                "performance": {"pnl": 987.30, "win_rate": 0.61, "total_trades": 445, "avg_return": 0.015},
                "followers": 145,
                "status": "active",
                "joined_at": "2024-09-30T16:45:00Z",
            },
            {
                "trader_id": "trader_005",
                "name": "ValueInvestor",
                "strategy": "Long-term Value",
                "performance": {"pnl": 3210.40, "win_rate": 0.78, "total_trades": 67, "avg_return": 0.058},
                "followers": 521,
                "status": "active",
                "joined_at": "2024-07-10T11:00:00Z",
            },
            {
                "trader_id": "trader_006",
                "name": "BreakoutHunter",
                "strategy": "Breakout Trading",
                "performance": {"pnl": 756.90, "win_rate": 0.59, "total_trades": 134, "avg_return": 0.022},
                "followers": 89,
                "status": "active",
                "joined_at": "2024-10-15T13:30:00Z",
            },
            {
                "trader_id": "trader_007",
                "name": "RiskManager",
                "strategy": "Conservative Growth",
                "performance": {"pnl": 534.60, "win_rate": 0.81, "total_trades": 89, "avg_return": 0.019},
                "followers": 267,
                "status": "active",
                "joined_at": "2024-09-05T08:00:00Z",
            },
            {
                "trader_id": "trader_008",
                "name": "VolatilityPro",
                "strategy": "Volatility Arbitrage",
                "performance": {"pnl": 1678.25, "win_rate": 0.64, "total_trades": 178, "avg_return": 0.031},
                "followers": 201,
                "status": "active",
                "joined_at": "2024-08-12T15:20:00Z",
            },
            {
                "trader_id": "trader_009",
                "name": "MeanReversion",
                "strategy": "Mean Reversion",
                "performance": {"pnl": 1123.80, "win_rate": 0.70, "total_trades": 145, "avg_return": 0.026},
                "followers": 156,
                "status": "active",
                "joined_at": "2024-09-22T10:45:00Z",
            },
            {
                "trader_id": "trader_010",
                "name": "GridMaster",
                "strategy": "Grid Trading",
                "performance": {"pnl": 892.45, "win_rate": 0.66, "total_trades": 312, "avg_return": 0.012},
                "followers": 134,
                "status": "active",
                "joined_at": "2024-10-08T12:00:00Z",
            },
        ]

        # Add traders to the manager
        for trader in sample_traders:
            social_trading_manager.active_traders[trader["trader_id"]] = trader
            await social_trading_manager._save_to_redis(f"social_trader:{trader['trader_id']}", trader)
            print(f"  [OK] Added trader: {trader['name']} (PnL: ${trader['performance']['pnl']:.2f})")

        # Sample community signals
        sample_signals = [
            {
                "signal_id": "signal_001",
                "trader_id": "trader_001",
                "symbol": "BTCUSDT",
                "action": "BUY",
                "price": 35420.50,
                "confidence": 0.85,
                "reason": "Strong uptrend with high volume",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
            {
                "signal_id": "signal_002",
                "trader_id": "trader_005",
                "symbol": "ETHUSDT",
                "action": "BUY",
                "price": 1876.30,
                "confidence": 0.78,
                "reason": "Accumulation phase completed",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
            {
                "signal_id": "signal_003",
                "trader_id": "trader_002",
                "symbol": "ADAUSDT",
                "action": "BUY",
                "price": 0.5511,
                "confidence": 0.72,
                "reason": "AI prediction shows bullish pattern",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        ]

        # Add signals
        social_trading_manager.community_signals.extend(sample_signals)
        await social_trading_manager._save_to_redis("social_community_signals", social_trading_manager.community_signals)
        print(f"\n  [OK] Added {len(sample_signals)} community signals")

        # Update leaderboard cache
        social_trading_manager.performance_leaderboard = await social_trading_manager.get_leaderboard()
        print(f"  [OK] Updated leaderboard with {len(social_trading_manager.performance_leaderboard)} entries")

        print("\n[SUCCESS] Social Trading data seeded successfully!")
        print(f"   - {len(social_trading_manager.active_traders)} traders")
        print(f"   - {len(social_trading_manager.community_signals)} signals")
        print(f"   - {len(social_trading_manager.performance_leaderboard)} leaderboard entries")

    except Exception as e:
        print(f"\n[ERROR] Error seeding social trading data: {e}")
        traceback.print_exc()
        return False
    else:
        return True


async def main():
    """Main entry point"""
    success = await seed_social_data()
    return 0 if success else 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
