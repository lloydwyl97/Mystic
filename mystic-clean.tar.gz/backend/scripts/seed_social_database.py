"""
Seed Social Trading Database with Real User Records
Populates the SQLite database User table with sample traders
"""

import asyncio
import sys
import traceback
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from backend.services.social_trading_service import SocialTradingService


async def seed_database():
    """Seed the database with sample users"""
    print("Seeding Social Trading Database...")

    # Create and initialize service directly
    service = SocialTradingService(database_pool_service=None, cache_service=None)

    try:
        await service.initialize()
        print("  [OK] Service initialized")
    except Exception as e:
        print(f"[ERROR] Failed to initialize service: {e}")
        return False

    try:
        # Sample users with realistic trading performance
        sample_users = [
            {
                "username": "cryptomaster_pro",
                "email": "cryptomaster@example.com",
                "display_name": "CryptoMaster Pro",
                "bio": "Professional momentum trader with 5+ years experience",
                "total_trades": 156,
                "win_rate": 0.68,
                "total_pnl": 2547.50,
                "total_pnl_percentage": 25.48,
                "sharpe_ratio": 1.85,
                "max_drawdown": -0.12,
                "followers_count": 342,
            },
            {
                "username": "ai_trade_bot",
                "email": "aibot@example.com",
                "display_name": "AI TradeBot",
                "bio": "AI-powered algorithmic trading system",
                "total_trades": 98,
                "win_rate": 0.72,
                "total_pnl": 1823.75,
                "total_pnl_percentage": 18.24,
                "sharpe_ratio": 2.10,
                "max_drawdown": -0.08,
                "followers_count": 289,
            },
            {
                "username": "trend_follower",
                "email": "trendfollower@example.com",
                "display_name": "TrendFollower",
                "bio": "Following major market trends for consistent profits",
                "total_trades": 203,
                "win_rate": 0.65,
                "total_pnl": 1456.20,
                "total_pnl_percentage": 14.56,
                "sharpe_ratio": 1.45,
                "max_drawdown": -0.15,
                "followers_count": 178,
            },
            {
                "username": "scalp_king",
                "email": "scalpking@example.com",
                "display_name": "ScalpKing",
                "bio": "High-frequency scalping specialist",
                "total_trades": 445,
                "win_rate": 0.61,
                "total_pnl": 987.30,
                "total_pnl_percentage": 9.87,
                "sharpe_ratio": 1.20,
                "max_drawdown": -0.10,
                "followers_count": 145,
            },
            {
                "username": "value_investor",
                "email": "valueinvestor@example.com",
                "display_name": "ValueInvestor",
                "bio": "Long-term value investing in crypto markets",
                "total_trades": 67,
                "win_rate": 0.78,
                "total_pnl": 3210.40,
                "total_pnl_percentage": 32.10,
                "sharpe_ratio": 2.35,
                "max_drawdown": -0.09,
                "followers_count": 521,
            },
            {
                "username": "breakout_hunter",
                "email": "breakouthunter@example.com",
                "display_name": "BreakoutHunter",
                "bio": "Specialized in identifying and trading breakouts",
                "total_trades": 134,
                "win_rate": 0.59,
                "total_pnl": 756.90,
                "total_pnl_percentage": 7.57,
                "sharpe_ratio": 1.15,
                "max_drawdown": -0.14,
                "followers_count": 89,
            },
            {
                "username": "risk_manager_pro",
                "email": "riskmanager@example.com",
                "display_name": "RiskManager Pro",
                "bio": "Conservative trading with strict risk management",
                "total_trades": 89,
                "win_rate": 0.81,
                "total_pnl": 534.60,
                "total_pnl_percentage": 5.35,
                "sharpe_ratio": 1.95,
                "max_drawdown": -0.05,
                "followers_count": 267,
            },
            {
                "username": "volatility_pro",
                "email": "volatilitypro@example.com",
                "display_name": "VolatilityPro",
                "bio": "Trading volatility and market inefficiencies",
                "total_trades": 178,
                "win_rate": 0.64,
                "total_pnl": 1678.25,
                "total_pnl_percentage": 16.78,
                "sharpe_ratio": 1.65,
                "max_drawdown": -0.11,
                "followers_count": 201,
            },
            {
                "username": "mean_reversion",
                "email": "meanreversion@example.com",
                "display_name": "MeanReversion",
                "bio": "Statistical arbitrage and mean reversion strategies",
                "total_trades": 145,
                "win_rate": 0.70,
                "total_pnl": 1123.80,
                "total_pnl_percentage": 11.24,
                "sharpe_ratio": 1.55,
                "max_drawdown": -0.09,
                "followers_count": 156,
            },
            {
                "username": "grid_master",
                "email": "gridmaster@example.com",
                "display_name": "GridMaster",
                "bio": "Automated grid trading across multiple pairs",
                "total_trades": 312,
                "win_rate": 0.66,
                "total_pnl": 892.45,
                "total_pnl_percentage": 8.92,
                "sharpe_ratio": 1.30,
                "max_drawdown": -0.08,
                "followers_count": 134,
            },
        ]

        # Create users in database
        created_count = 0
        for user_data in sample_users:
            try:
                # Create user using service (this will write to database)
                user = await service.create_user(username=user_data["username"], email=user_data["email"], display_name=user_data.get("display_name"), bio=user_data.get("bio", ""))

                if user:
                    # Update user stats (users are created with performance metrics as columns)
                    user_id = user.get("id")
                    if user_id:
                        # Stats are already set during user creation via database columns
                        # Just update followers count separately if needed
                        print(f"  [OK] Created user: {user_data['display_name']} (ID: {user_id})")
                        created_count += 1
                    else:
                        print(f"  [WARN] Created user {user_data['username']} but no ID returned")
                else:
                    print(f"  [WARN] Failed to create user: {user_data['username']}")

            except Exception as e:
                print(f"  [ERROR] Error creating user {user_data['username']}: {e}")
                continue

        print(f"\n[SUCCESS] Database seeded with {created_count} users")

    except Exception as e:
        print(f"\n[ERROR] Error seeding database: {e}")
        traceback.print_exc()
        return False
    else:
        return True


async def main():
    """Main entry point"""
    success = await seed_database()
    return 0 if success else 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
