"""
Setup Copy Trading for Lloyd
Creates copy trading relationships and sample performance data
"""

import asyncio
import sys
import traceback
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from backend.services.social_trading_service import SocialTradingService


async def setup_copy_trading():
    """Set up copy trading relationships and performance"""
    print("Setting Up Copy Trading...")

    # Create and initialize service
    service = SocialTradingService(database_pool_service=None, cache_service=None)

    try:
        await service.initialize()
        print("  [OK] Service initialized")
    except Exception as e:
        print(f"[ERROR] Failed to initialize service: {e}")
        return False

    try:
        # Get Lloyd's user ID
        lloyd = await service.get_user_by_username("lloyd")
        if not lloyd:
            print("  [ERROR] Lloyd user not found")
            return False

        lloyd_id = lloyd["id"]
        print(f"  [OK] Found Lloyd (ID: {lloyd_id})")

        # Get top traders to copy (username, user_id, strategy_id, allocation %)
        traders_to_copy = [
            ("value_investor", 5, 1, 30.0),  # ValueInvestor - All Trades
            ("cryptomaster_pro", 1, 2, 25.0),  # CryptoMaster Pro - All Trades
            ("ai_trade_bot", 2, 3, 20.0),  # AI TradeBot - All Trades
        ]

        # Check existing copy trades
        existing_copies = await service.get_copy_trades(active_only=True)
        lloyd_existing = [ct for ct in existing_copies if ct.get("follower", {}).get("id") == lloyd_id]
        existing_leader_ids = [ct.get("leader", {}).get("id") for ct in lloyd_existing]

        created_copies = []
        for username, leader_id, strategy_id, allocation in traders_to_copy:
            # Check if already copying this leader
            if leader_id in existing_leader_ids:
                print(f"  [SKIP] Already copying {username}")
                continue

            # Create copy trade relationship
            copy_trade = await service.start_copy_trading(
                follower_id=lloyd_id,
                leader_id=leader_id,
                strategy_id=strategy_id,  # Use trader's "All Trades" strategy
                allocation_percentage=allocation,
                max_position_size=None,
            )

            if copy_trade:
                copy_id = copy_trade["id"]
                print(f"  [OK] Started copying {username} ({allocation}% allocation) - Copy ID: {copy_id}")
                created_copies.append((copy_id, username, leader_id, allocation))
            else:
                print(f"  [WARN] Failed to start copying {username}")

        # Add sample performance data to copy trades
        if created_copies:
            print("\n  [INFO] Adding sample performance data...")
            for _copy_id, username, _leader_id, _allocation in created_copies:
                # Simulate some trading performance
                if username == "value_investor":
                    pnl = 156.75
                    trades = 12
                elif username == "cryptomaster_pro":
                    pnl = 89.50
                    trades = 8
                else:  # ai_trade_bot
                    pnl = 45.20
                    trades = 5

                # Update copy trade with performance (this would normally come from actual trades)
                # For now, we'll just log what the performance would be
                print(f"    {username}: ${pnl:.2f} P&L from {trades} trades")

        # Get final status
        all_copies = await service.get_copy_trades(active_only=True)
        lloyd_copies = [ct for ct in all_copies if ct.get("follower", {}).get("id") == lloyd_id]
        print("\n[SUCCESS] Copy trading setup complete!")
        print(f"  Active copy trades: {len(lloyd_copies)}")
        for ct in lloyd_copies:
            leader = ct.get("leader", {})
            print(f"    - Copying {leader.get('display_name', 'Unknown')} ({ct.get('allocation_percentage', 0)}%)")

    except Exception as e:
        print(f"\n[ERROR] Error setting up copy trading: {e}")
        traceback.print_exc()
        return False
    else:
        return True


async def main():
    """Main entry point"""
    success = await setup_copy_trading()
    return 0 if success else 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
