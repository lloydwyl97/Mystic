#!/usr/bin/env python3
"""
P4.2: Periodic self-audit script (read-only).
Scans backend for structural drift; run monthly or after large changes.
Detects: hardcoded confidence, KEYS usage, bar-math without interval, missing constraint ensures.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path


def scan_file(path: Path) -> list[tuple[str, int, str]]:
    findings: list[tuple[str, int, str]] = []
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return findings

    lines = text.splitlines()
    for i, line in enumerate(lines, 1):
        # 1) Redis KEYS (should use SCAN)
        if re.search(r"\.keys\s*\(\s*[\"'].*[\"']\s*\)", line) and "redis" in text[: text.find(line)].lower():
            findings.append((str(path), i, "REDIS_KEYS: Prefer SCAN for key retrieval"))

        # 2) Bar math: current_bar + N or + CONST without * bar_interval
        if re.search(r"current_bar\s*\+\s*[A-Za-z_]+", line) and "*" not in line and "bar_interval" not in line:
            if "COOLDOWN" in line or "BARS" in line or "vol_spike" in line or "spread_blocked" in line:
                findings.append((str(path), i, "BAR_MATH: current_bar + N without * bar_interval_seconds"))

        # 3) Hardcoded confidence (common culprits)
        for pat in (r"\b0\.46\b", r"min_confidence_required\s*=\s*0\.\d+", r"MIN_CONFIDENCE\s*=\s*0\.\d+"):
            if re.search(pat, line) and "confidence" in line.lower():
                findings.append((str(path), i, "HARDCODED_CONFIDENCE: Prefer env or canonical constant"))

    # 4) Entry points that should call _entry_ensure_constraints (heuristic: execute_buy_fifo / execute_sell_fifo)
    if ("execute_buy_fifo" in text or "execute_sell_fifo" in text) and "_entry_ensure_constraints" not in text and "_ensure_symbol_constraints" not in text:
        findings.append((str(path), 0, "CONSTRAINT_ENSURE: Buy/sell path may lack _entry_ensure_constraints"))

    return findings


def main() -> int:
    backend = Path(__file__).resolve().parent.parent
    py_files = list(backend.rglob("*.py"))
    all_findings: list[tuple[str, int, str]] = []
    for p in py_files:
        if "venv" in str(p) or "__pycache__" in str(p) or ".venv" in str(p):
            continue
        all_findings.extend(scan_file(p))

    for path, line_no, msg in sorted(all_findings, key=lambda x: (x[0], x[1])):
        loc = f"{path}:{line_no}" if line_no else path
        print(f"{loc} | {msg}")

    print(f"\nTotal findings: {len(all_findings)}")
    return 1 if all_findings else 0


if __name__ == "__main__":
    sys.exit(main())
