#!/usr/bin/env python3
r"""
System-Wide Self-Check Script
Validates all critical invariants across the Mystic trading system

Usage (PowerShell):
    python backend\scripts\system_wide_self_check.py

Exit Codes:
    0 = All checks passed
    1 = One or more CRITICAL failures
    2 = Warnings present but no failures
"""

import asyncio
import logging
import os
import sqlite3
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

try:
    import redis.asyncio as redis
except ImportError:
    print("ERROR: redis package not installed. Run: pip install redis")
    sys.exit(1)


class Colors:
    """ANSI color codes for terminal output"""

    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    BLUE = "\033[94m"
    BOLD = "\033[1m"
    END = "\033[0m"

    @staticmethod
    def disable():
        """Disable colors for Windows compatibility"""
        Colors.GREEN = ""
        Colors.YELLOW = ""
        Colors.RED = ""
        Colors.BLUE = ""
        Colors.BOLD = ""
        Colors.END = ""


# Disable colors on Windows unless FORCE_COLOR=1
if sys.platform == "win32" and os.getenv("FORCE_COLOR") != "1":
    Colors.disable()


class CheckResult:
    """Result of a single check"""

    def __init__(self, invariant_id: str, name: str, passed: bool, message: str, is_warning: bool = False):
        self.invariant_id = invariant_id
        self.name = name
        self.passed = passed
        self.message = message
        self.is_warning = is_warning


class SystemSelfCheck:
    """System-wide self-check orchestrator"""

    def __init__(self):
        self.results: list[CheckResult] = []
        self.db_path = self._get_db_path()
        self.redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
        self.redis_client: redis.Redis | None = None

    def _get_db_path(self) -> str:
        """Get database path (absolute or from env)"""
        db_path = os.getenv("DATABASE_PATH", "mystic_trading.db")
        if not os.path.isabs(db_path):
            # Resolve relative to workspace root
            workspace_root = Path(__file__).parent.parent.parent
            db_path = str(workspace_root / db_path)
        return db_path

    async def run_all_checks(self) -> int:
        """
        Run all system checks.
        Returns: Exit code (0=pass, 1=fail, 2=warnings)
        """
        print(f"{Colors.BOLD}{'=' * 50}")
        print("MYSTIC TRADING SYSTEM SELF-CHECK")
        print(f"{'=' * 50}{Colors.END}\n")
        print(f"Date: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')} UTC")
        print(f"Database: {self.db_path}")
        print(f"Redis: {self.redis_url}\n")

        # Initialize Redis connection
        try:
            self.redis_client = redis.from_url(self.redis_url, decode_responses=True)
            await self.redis_client.ping()
        except Exception as e:
            print(f"{Colors.RED}✗ CRITICAL: Cannot connect to Redis: {e}{Colors.END}\n")
            return 1

        # Run all checks
        await self.check_ledger_conservation()
        await self.check_no_negative_cash()
        await self.check_no_negative_positions()
        await self.check_max_open_positions()
        await self.check_one_position_per_symbol()
        await self.check_total_risk_cap()
        await self.check_single_execution_authority()
        await self.check_paper_run_id_persists()
        await self.check_balances_match()
        await self.check_no_stale_positions()
        await self.check_market_data_freshness()
        await self.check_price_sanity()
        await self.check_redis_healthy()
        await self.check_live_position_tracking()
        await self.check_kill_switch_state()
        await self.check_all_trades_audited()
        await self.check_rejects_logged()
        await self.check_position_monitor_running()
        await self.check_coin_universe_metrics_integrity()

        # Close Redis
        if self.redis_client:
            await self.redis_client.aclose()

        # Print summary
        return self._print_summary()

    def _print_summary(self) -> int:
        """Print summary and return exit code"""
        print(f"\n{Colors.BOLD}{'=' * 50}")
        print("SUMMARY")
        print(f"{'=' * 50}{Colors.END}\n")

        total = len(self.results)
        passed = sum(1 for r in self.results if r.passed and not r.is_warning)
        warnings = sum(1 for r in self.results if r.is_warning)
        failed = sum(1 for r in self.results if not r.passed and not r.is_warning)

        print(f"Total checks: {total}")
        print(f"{Colors.GREEN}Passed: {passed}{Colors.END}")
        if warnings > 0:
            print(f"{Colors.YELLOW}Warnings: {warnings}{Colors.END}")
        if failed > 0:
            print(f"{Colors.RED}Failed: {failed}{Colors.END}")
        else:
            print(f"Failed: {failed}")

        print()

        if failed > 0:
            print(f"{Colors.RED}{Colors.BOLD}OVERALL STATUS: FAIL ✗{Colors.END}\n")
            print("CRITICAL FAILURES DETECTED - TRADING SHOULD BE PAUSED")
            return 1
        elif warnings > 0:
            print(f"{Colors.YELLOW}{Colors.BOLD}OVERALL STATUS: PASS WITH WARNINGS ⚠{Colors.END}\n")
            return 2
        else:
            print(f"{Colors.GREEN}{Colors.BOLD}OVERALL STATUS: PASS ✓{Colors.END}\n")
            return 0

    def _add_result(self, invariant_id: str, name: str, passed: bool, message: str, is_warning: bool = False):
        """Add check result and print"""
        result = CheckResult(invariant_id, name, passed, message, is_warning)
        self.results.append(result)

        if passed and not is_warning:
            symbol = f"{Colors.GREEN}✓{Colors.END}"
        elif is_warning:
            symbol = f"{Colors.YELLOW}⚠{Colors.END}"
        else:
            symbol = f"{Colors.RED}✗{Colors.END}"

        print(f"[{symbol}] {invariant_id}: {name}")
        if message:
            # Indent message
            for line in message.split("\n"):
                print(f"    {line}")
        print()

    def _query_db(self, query: str, params: tuple = ()) -> list[tuple]:
        """Execute SQL query and return results"""
        conn = sqlite3.connect(self.db_path)
        try:
            cursor = conn.cursor()
            cursor.execute(query, params)
            return cursor.fetchall()
        except sqlite3.OperationalError as e:
            if "no such table" in str(e):
                return []  # Table doesn't exist yet (fresh install)
            raise
        except Exception as e:
            print(f"{Colors.RED}Database query error: {e}{Colors.END}")
            raise
        finally:
            conn.close()

    # ========================================================================
    # CHECK IMPLEMENTATIONS
    # ========================================================================

    async def check_ledger_conservation(self):
        """INVARIANT-001: cash_balance + positions_value = total_equity"""
        try:
            result = self._query_db("""
                SELECT cash_balance, positions_value, total_equity
                FROM portfolio_engine_ledger
                WHERE id = 1
            """)

            if not result:
                self._add_result("INVARIANT-001", "Ledger conservation (cash + positions = equity)", True, "No ledger data yet (fresh start)", is_warning=True)
                return

            cash, positions, equity = result[0]
            computed = cash + positions
            diff = abs(computed - equity)

            if diff > 1.0:  # Tolerance: $1
                self._add_result(
                    "INVARIANT-001",
                    "Ledger conservation",
                    False,
                    f"cash=${cash:.2f}, positions=${positions:.2f}, equity=${equity:.2f}\nFAIL: cash + positions = ${computed:.2f}, but equity = ${equity:.2f}\ndiff=${diff:.2f} (tolerance ±$1.00)",
                )
            else:
                self._add_result("INVARIANT-001", "Ledger conservation", True, f"cash=${cash:.2f}, positions=${positions:.2f}, equity=${equity:.2f}\nPASS: diff=${diff:.2f} (tolerance ±$1.00)")
        except Exception as e:
            self._add_result("INVARIANT-001", "Ledger conservation", False, f"Error: {e}")

    async def check_no_negative_cash(self):
        """INVARIANT-002: cash_balance >= 0"""
        try:
            result = self._query_db("""
                SELECT cash_balance
                FROM portfolio_engine_ledger
                WHERE id = 1
            """)

            if not result:
                self._add_result("INVARIANT-002", "No negative cash balance", True, "No ledger data yet", is_warning=True)
                return

            cash = result[0][0]

            if cash < 0:
                self._add_result("INVARIANT-002", "No negative cash balance", False, f"FAIL: cash_balance=${cash:.2f} (negative!)")
            else:
                self._add_result("INVARIANT-002", "No negative cash balance", True, f"cash_balance=${cash:.2f}\nPASS: cash >= 0")
        except Exception as e:
            self._add_result("INVARIANT-002", "No negative cash balance", False, f"Error: {e}")

    async def check_no_negative_positions(self):
        """INVARIANT-003: All position quantities >= 0"""
        try:
            results = self._query_db("""
                SELECT symbol, quantity
                FROM portfolio_engine_positions
                WHERE quantity < 0
            """)

            total_positions = self._query_db("SELECT COUNT(*) FROM portfolio_engine_positions")[0][0]

            if results:
                negative_symbols = [f"{row[0]} (qty={row[1]})" for row in results]
                self._add_result("INVARIANT-003", "No negative positions", False, f"FAIL: Found {len(results)} negative positions:\n" + "\n".join(negative_symbols))
            else:
                self._add_result("INVARIANT-003", "No negative positions", True, f"Checked {total_positions} positions\nPASS: All quantities >= 0")
        except Exception as e:
            self._add_result("INVARIANT-003", "No negative positions", False, f"Error: {e}")

    async def check_max_open_positions(self):
        """INVARIANT-004: Open positions <= MAX_OPEN_POSITIONS (10)"""
        MAX_POSITIONS = 10
        try:
            result = self._query_db("SELECT COUNT(*) FROM portfolio_engine_positions")
            count = result[0][0] if result else 0

            if count > MAX_POSITIONS:
                self._add_result("INVARIANT-004", f"Max open positions ({MAX_POSITIONS} limit)", False, f"FAIL: {count} positions open (max {MAX_POSITIONS})")
            else:
                self._add_result("INVARIANT-004", f"Max open positions ({MAX_POSITIONS} limit)", True, f"Current: {count} open positions\nPASS: {count} <= {MAX_POSITIONS}")
        except Exception as e:
            self._add_result("INVARIANT-004", "Max open positions", False, f"Error: {e}")

    async def check_one_position_per_symbol(self):
        """INVARIANT-005: No duplicate symbols in open positions"""
        try:
            results = self._query_db("""
                SELECT symbol, COUNT(*) as cnt
                FROM portfolio_engine_positions
                GROUP BY symbol
                HAVING cnt > 1
            """)

            if results:
                duplicates = [f"{row[0]} ({row[1]}x)" for row in results]
                self._add_result("INVARIANT-005", "Max one position per symbol", False, "FAIL: Found duplicate symbols:\n" + "\n".join(duplicates))
            else:
                self._add_result("INVARIANT-005", "Max one position per symbol", True, "PASS: No duplicate symbols")
        except Exception as e:
            self._add_result("INVARIANT-005", "Max one position per symbol", False, f"Error: {e}")

    async def check_total_risk_cap(self):
        """INVARIANT-006: Total open risk <= 3% of equity"""
        MAX_RISK_PCT = 0.03
        try:
            # Get equity
            equity_result = self._query_db("SELECT total_equity FROM portfolio_engine_ledger WHERE id = 1")
            if not equity_result:
                self._add_result("INVARIANT-006", "Total open risk cap (3%)", True, "No ledger data yet", is_warning=True)
                return

            equity = equity_result[0][0]

            # Compute total risk
            positions = self._query_db("""
                SELECT symbol, quantity, entry_price, stop_price
                FROM portfolio_engine_positions
            """)

            total_risk = 0.0
            for _symbol, qty, entry, stop in positions:
                risk_per_share = abs(entry - stop)
                position_risk = risk_per_share * qty * entry
                total_risk += position_risk

            risk_pct = (total_risk / equity) * 100 if equity > 0 else 0.0

            if risk_pct > (MAX_RISK_PCT * 100):
                self._add_result(
                    "INVARIANT-006", "Total open risk cap (3%)", False, f"FAIL: Total risk: ${total_risk:.2f}, Equity: ${equity:.2f}, Risk%: {risk_pct:.2f}%\nExceeds {MAX_RISK_PCT * 100:.2f}% limit"
                )
            else:
                self._add_result(
                    "INVARIANT-006",
                    "Total open risk cap (3%)",
                    True,
                    f"Total risk: ${total_risk:.2f}, Equity: ${equity:.2f}, Risk%: {risk_pct:.2f}%\nPASS: {risk_pct:.2f}% <= {MAX_RISK_PCT * 100:.2f}%",
                )
        except Exception as e:
            self._add_result("INVARIANT-006", "Total open risk cap", False, f"Error: {e}")

    async def check_single_execution_authority(self):
        """INVARIANT-007: No duplicate trade_ids in audit log (same bar)"""
        try:
            # Check for duplicate trade_ids in same bar timestamp
            results = self._query_db("""
                SELECT trade_id, COUNT(*) as cnt
                FROM portfolio_engine_audit
                WHERE action = 'BUY'
                  AND trade_id IS NOT NULL
                GROUP BY trade_id
                HAVING cnt > 1
                LIMIT 5
            """)

            if results:
                duplicates = [f"{row[0]} ({row[1]}x)" for row in results]
                self._add_result("INVARIANT-007", "Single execution authority", False, "FAIL: Found duplicate trade_ids:\n" + "\n".join(duplicates))
            else:
                self._add_result("INVARIANT-007", "Single execution authority", True, "PASS: No duplicate trade_ids in audit log")
        except Exception as e:
            self._add_result("INVARIANT-007", "Single execution authority", False, f"Error: {e}")

    async def check_paper_run_id_persists(self):
        """INVARIANT-008: Paper run-id persists across restarts"""
        try:
            if not self.redis_client:
                self._add_result("INVARIANT-008", "Paper run-id persists", False, "Redis not connected")
                return

            run_id = await self.redis_client.get("paper_trading:paper_run_id")

            if run_id:
                self._add_result("INVARIANT-008", "Paper run-id persists", True, f"Current run-id: {run_id}\nPASS: run-id exists in Redis")
            else:
                self._add_result("INVARIANT-008", "Paper run-id persists", True, "No run-id in Redis yet (fresh start)", is_warning=True)
        except Exception as e:
            self._add_result("INVARIANT-008", "Paper run-id persists", False, f"Error: {e}")

    async def check_balances_match(self):
        """INVARIANT-009: Portfolio Engine cash vs Paper Service cash are consistent."""
        TOLERANCE = 50.0  # $50 tolerance — PE may hold positions the paper service tracks separately
        try:
            pe_result = self._query_db("SELECT cash_balance, total_equity FROM portfolio_engine_ledger WHERE id = 1")
            if not pe_result:
                self._add_result("INVARIANT-009", "Balances match", True, "No ledger data yet", is_warning=True)
                return

            pe_cash, pe_equity = pe_result[0]

            if not self.redis_client:
                self._add_result("INVARIANT-009", "Balances match", False, "Redis not connected")
                return

            ps_balance_str = await self.redis_client.get("paper_trading:cash_balance")

            if ps_balance_str:
                ps_cash = float(ps_balance_str)
                diff = abs(pe_cash - ps_cash)

                msg = f"PE cash=${pe_cash:.2f}, PE equity=${pe_equity:.2f}\nPaper Service cash=${ps_cash:.2f}\nCash diff=${diff:.2f} (tolerance ±${TOLERANCE:.0f})"

                if diff > TOLERANCE:
                    self._add_result("INVARIANT-009", "Balances match", False, f"{msg}\nFAIL: cash drift exceeds tolerance")
                else:
                    self._add_result("INVARIANT-009", "Balances match", True, f"{msg}\nPASS: Cash balances within tolerance")
            else:
                self._add_result("INVARIANT-009", "Balances match", True, f"Portfolio Engine: ${pe_equity:.2f}\nPaper Service: Not started yet", is_warning=True)
        except Exception as e:
            self._add_result("INVARIANT-009", "Balances match", False, f"Error: {e}")

    async def check_no_stale_positions(self):
        """INVARIANT-010: All positions updated within last hour"""
        try:
            results = self._query_db("""
                SELECT symbol, last_updated
                FROM portfolio_engine_positions
                WHERE last_updated < datetime('now', '-1 hour')
            """)

            if results:
                stale = [f"{row[0]} (last updated: {row[1]})" for row in results]
                self._add_result("INVARIANT-010", "No stale positions", False, f"WARNING: Found {len(results)} stale positions:\n" + "\n".join(stale), is_warning=True)
            else:
                self._add_result("INVARIANT-010", "No stale positions", True, "PASS: All positions updated within last hour")
        except Exception as e:
            self._add_result("INVARIANT-010", "No stale positions", False, f"Error: {e}")

    async def check_market_data_freshness(self):
        """INVARIANT-011: Market data freshness (max 30s age, retries once after short wait)."""
        MAX_AGE = 30.0
        try:
            if not self.redis_client:
                self._add_result("INVARIANT-011", "Market data freshness", False, "Redis not connected")
                return

            last_update_str = await self.redis_client.get("market_data:last_update")

            if last_update_str:
                last_update = float(last_update_str)
                age = time.time() - last_update

                if age > MAX_AGE:
                    # Retry once after a short wait (handles startup race)
                    await asyncio.sleep(5)
                    last_update_str = await self.redis_client.get("market_data:last_update")
                    if last_update_str:
                        last_update = float(last_update_str)
                        age = time.time() - last_update

                if age > MAX_AGE:
                    self._add_result("INVARIANT-011", "Market data freshness (max 30s age)", False, f"Last update: {age:.1f}s ago\nFAIL: age > {MAX_AGE:.1f}s (STALE DATA)")
                else:
                    self._add_result("INVARIANT-011", "Market data freshness", True, f"Last update: {age:.1f}s ago\nPASS: age <= {MAX_AGE:.1f}s")
            else:
                self._add_result("INVARIANT-011", "Market data freshness", True, "No market data timestamp yet (system just started)", is_warning=True)
        except Exception as e:
            self._add_result("INVARIANT-011", "Market data freshness", False, f"Error: {e}")

    async def check_price_sanity(self):
        """INVARIANT-012: Price sanity check — entry prices within 20% of last known market price."""
        MAX_DEVIATION = 0.20
        try:
            positions = self._query_db("SELECT symbol, entry_price FROM portfolio_engine_positions")
            if not positions:
                self._add_result("INVARIANT-012", "Price sanity check", True, "No open positions to verify\nPASS: Nothing to check")
                return

            if not self.redis_client:
                self._add_result("INVARIANT-012", "Price sanity check", False, "Redis not connected")
                return

            import json as _json

            violations: list[str] = []
            checked = 0
            for symbol, entry_price in positions:
                base = (symbol or "").replace("/USDT", "").replace("USDT", "").strip().upper()
                market_key = f"market:{base}"
                raw = await self.redis_client.get(market_key)
                if not raw:
                    continue
                try:
                    market_price = float(_json.loads(raw).get("price", 0))
                except (ValueError, TypeError, KeyError):
                    continue
                if market_price <= 0 or entry_price <= 0:
                    continue
                checked += 1
                deviation = abs(market_price - entry_price) / entry_price
                if deviation > MAX_DEVIATION:
                    violations.append(f"{symbol}: entry=${entry_price:.4f} market=${market_price:.4f} dev={deviation:.1%}")

            if violations:
                # ADVISORY: Normal market volatility can cause >20% deviation; do not pause trading
                self._add_result(
                    "INVARIANT-012",
                    "Price sanity check (advisory, max 20% deviation)",
                    True,
                    f"Checked {checked} positions\nADVISORY: {len(violations)} position(s) deviate >20% (normal volatility):\n" + "\n".join(violations),
                    is_warning=True,
                )
            else:
                self._add_result("INVARIANT-012", "Price sanity check", True, f"Checked {checked} position(s) against live market prices\nPASS: All within ±{MAX_DEVIATION:.0%} of market price")
        except Exception as e:
            self._add_result("INVARIANT-012", "Price sanity check", False, f"Error: {e}")

    async def check_redis_healthy(self):
        """INVARIANT-013: Redis connection healthy"""
        try:
            if not self.redis_client:
                self._add_result("INVARIANT-013", "Redis connection", False, "Redis not connected")
                return

            start = time.time()
            await self.redis_client.ping()
            latency = (time.time() - start) * 1000  # ms

            self._add_result("INVARIANT-013", "Redis connection healthy", True, f"PASS: Redis connection healthy (ping {latency:.1f}ms)")
        except Exception as e:
            self._add_result("INVARIANT-013", "Redis connection", False, f"FAIL: {e}")

    async def check_live_position_tracking(self):
        """INVARIANT-015: Live position tracking consistent"""
        try:
            if not self.redis_client:
                self._add_result("INVARIANT-015", "Live position tracking", False, "Redis not connected")
                return

            # Count live positions in Redis
            redis_keys = []
            async for k in self.redis_client.scan_iter(match="live_position:*", count=100):
                redis_keys.append(k)
            redis_count = len(redis_keys)

            # Check if live_positions table exists
            try:
                db_result = self._query_db("SELECT COUNT(*) FROM live_positions")
                db_count = db_result[0][0] if db_result else 0
            except sqlite3.OperationalError:
                db_count = 0  # Table doesn't exist yet

            if redis_count != db_count:
                self._add_result(
                    "INVARIANT-015",
                    "Live position tracking",
                    True,
                    f"Live positions in Redis: {redis_count}\nLive positions in DB: {db_count}\nWARNING: Mismatch detected (may need exchange sync)",
                    is_warning=True,
                )
            else:
                self._add_result("INVARIANT-015", "Live position tracking", True, f"Live positions in Redis: {redis_count}\nLive positions in DB: {db_count}\nPASS: Counts match")
        except Exception as e:
            self._add_result("INVARIANT-015", "Live position tracking", False, f"Error: {e}")

    async def check_kill_switch_state(self):
        """INVARIANT-016: Kill switch state"""
        try:
            if not self.redis_client:
                self._add_result("INVARIANT-016", "Kill switch", False, "Redis not connected")
                return

            kill_switch = await self.redis_client.get("kill_switch")

            if kill_switch == "1":
                self._add_result("INVARIANT-016", "Kill switch state", True, "kill_switch=1 (TRADING PAUSED)\nINFO: Kill switch is ON", is_warning=True)
            else:
                self._add_result("INVARIANT-016", "Kill switch state", True, "kill_switch=0 (trading enabled)\nPASS: Kill switch off, trading active")
        except Exception as e:
            self._add_result("INVARIANT-016", "Kill switch state", False, f"Error: {e}")

    async def check_all_trades_audited(self):
        """INVARIANT-017: All trades logged to audit table"""
        try:
            # Count trades in paper_trades
            trades_result = self._query_db("SELECT COUNT(*) FROM paper_trades")
            trades_count = trades_result[0][0] if trades_result else 0

            # Count trades in portfolio_engine_audit
            audit_result = self._query_db("""
                SELECT COUNT(*) FROM portfolio_engine_audit
                WHERE action IN ('BUY', 'SELL')
            """)
            audit_count = audit_result[0][0] if audit_result else 0

            # Allow some tolerance (audit may have extra entries for rejects)
            if audit_count < trades_count:
                self._add_result(
                    "INVARIANT-017",
                    "All trades logged to audit table",
                    False,
                    f"paper_trades count: {trades_count}\nportfolio_engine_audit count: {audit_count}\nFAIL: Missing {trades_count - audit_count} audit entries",
                )
            else:
                self._add_result(
                    "INVARIANT-017", "All trades logged to audit table", True, f"paper_trades count: {trades_count}\nportfolio_engine_audit count: {audit_count}\nPASS: All trades audited"
                )
        except Exception as e:
            self._add_result("INVARIANT-017", "All trades audited", False, f"Error: {e}")

    async def check_rejects_logged(self):
        """INVARIANT-018: All rejects logged. Uses direct DB call so OperationalError propagates (not swallowed by _query_db)."""
        log = logging.getLogger("system_wide_self_check")
        try:
            conn = sqlite3.connect(self.db_path)
            try:
                cur = conn.cursor()
                cur.execute("""
                    SELECT COUNT(*) FROM portfolio_engine_rejects
                    WHERE ts > datetime('now', '-1 day')
                """)
                row = cur.fetchone()
                count = row[0] if row and row[0] is not None else 0
            finally:
                conn.close()

            self._add_result("INVARIANT-018", "All rejects logged", True, f"Checked last 24 hours: {count} rejects logged\nPASS: Reject logging active")
        except sqlite3.OperationalError as ex:
            log.error("INVARIANT-018: DB OperationalError - portfolio_engine_rejects table missing or inaccessible: %s", ex)
            self._add_result(
                "INVARIANT-018",
                "All rejects logged",
                False,
                f"FAIL: DB error - portfolio_engine_rejects table missing or inaccessible: {ex}",
            )
        except Exception as ex:
            log.error("INVARIANT-018: Error checking rejects: %s", ex, exc_info=True)
            self._add_result("INVARIANT-018", "All rejects logged", False, f"FAIL: Error checking rejects: {ex}")

    async def check_position_monitor_running(self):
        """INVARIANT-020: Position monitor task running — verify backend process is alive."""
        import subprocess

        try:
            result = subprocess.run(
                ["pgrep", "-f", "uvicorn.*backend"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            pids = [p.strip() for p in result.stdout.strip().splitlines() if p.strip()]
            if pids:
                self._add_result(
                    "INVARIANT-020",
                    "Position monitor running",
                    True,
                    f"Backend process(es) detected: PID(s) {', '.join(pids)}\nPASS: Backend (and its position monitor task) is running",
                )
            else:
                self._add_result(
                    "INVARIANT-020",
                    "Position monitor running",
                    False,
                    "No uvicorn backend process found\nFAIL: Backend is not running — position monitor is offline",
                )
        except Exception as e:
            self._add_result("INVARIANT-020", "Position monitor running", False, f"Error checking process: {e}")

    async def check_coin_universe_metrics_integrity(self):
        """COIN UNIVERSE RULES: Metrics table integrity - no rogue symbols, only fixed universe."""
        try:
            from backend.config.trading_universe import TRADING_SYMBOLS
        except ImportError:
            self._add_result("COIN_UNIVERSE-001", "Metrics table integrity", True, "trading_universe not importable; skip", is_warning=True)
            return
        try:
            # coin_performance may not exist in fresh DB
            table_check = self._query_db("SELECT name FROM sqlite_master WHERE type='table' AND name='coin_performance'")
            if not table_check:
                self._add_result("COIN_UNIVERSE-001", "Metrics table integrity", True, "coin_performance table not yet created", is_warning=True)
                return
            rows = self._query_db("SELECT symbol FROM coin_performance")
            if not rows:
                self._add_result("COIN_UNIVERSE-001", "Metrics table integrity", True, f"coin_performance empty; fixed universe has {len(TRADING_SYMBOLS)} symbols\nPASS: No rogue symbols")
                return
            # Allowed: only bases from fixed universe (e.g. BTC, ETH, ...)
            allowed_bases = set()
            for s in TRADING_SYMBOLS:
                base = (s or "").replace("USDT", "").replace("/", "").strip()
                if base:
                    allowed_bases.add(base)
            rogue = []
            for (symbol,) in rows:
                base = (symbol or "").replace("USDT", "").replace("/", "").strip()
                if not base:
                    continue
                if base not in allowed_bases:
                    rogue.append(symbol)
            if rogue:
                self._add_result(
                    "COIN_UNIVERSE-001",
                    "Metrics table integrity (no rogue symbols)",
                    False,
                    f"FAIL: Rogue symbol leak in coin_performance: {rogue}\nFixed universe has {len(TRADING_SYMBOLS)} symbols.",
                )
            elif len(rows) > len(TRADING_SYMBOLS):
                self._add_result(
                    "COIN_UNIVERSE-001",
                    "Metrics table integrity (symbol count)",
                    False,
                    f"FAIL: coin_performance has {len(rows)} symbols, expected at most {len(TRADING_SYMBOLS)} (fixed universe).",
                )
            else:
                self._add_result(
                    "COIN_UNIVERSE-001",
                    "Metrics table integrity",
                    True,
                    f"coin_performance: {len(rows)} symbols, all in fixed universe ({len(TRADING_SYMBOLS)})\nPASS: No rogue symbols",
                )
        except Exception as e:
            self._add_result("COIN_UNIVERSE-001", "Metrics table integrity", False, f"Error: {e}")


async def main():
    """Main entry point"""
    checker = SystemSelfCheck()
    exit_code = await checker.run_all_checks()
    sys.exit(exit_code)


if __name__ == "__main__":
    # Run async main
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nSelf-check interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n{Colors.RED}FATAL ERROR: {e}{Colors.END}")
        sys.exit(1)
