"""
Update Social Trading User Stats
Populates performance metrics for existing users
"""

import asyncio
import sys
import traceback
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from backend.services.social_trading_service import SocialTradingService


async def update_stats():
    """Update user stats with sample performance data"""
    print("Updating Social Trading User Stats...")

    # Create and initialize service
    service = SocialTradingService(database_pool_service=None, cache_service=None)

    try:
        await service.initialize()
        print("  [OK] Service initialized")
    except Exception as e:
        print(f"[ERROR] Failed to initialize service: {e}")
        return False

    try:
        # User stats to update
        user_stats_map = {
            "cryptomaster_pro": {
                "total_trades": 156,
                "win_rate": 0.68,
                "total_pnl": 2547.50,
                "total_pnl_percentage": 25.48,
                "sharpe_ratio": 1.85,
                "max_drawdown": -0.12,
                "followers_count": 342,
            },
            "ai_trade_bot": {
                "total_trades": 98,
                "win_rate": 0.72,
                "total_pnl": 1823.75,
                "total_pnl_percentage": 18.24,
                "sharpe_ratio": 2.10,
                "max_drawdown": -0.08,
                "followers_count": 289,
            },
            "trend_follower": {
                "total_trades": 203,
                "win_rate": 0.65,
                "total_pnl": 1456.20,
                "total_pnl_percentage": 14.56,
                "sharpe_ratio": 1.45,
                "max_drawdown": -0.15,
                "followers_count": 178,
            },
            "scalp_king": {
                "total_trades": 445,
                "win_rate": 0.61,
                "total_pnl": 987.30,
                "total_pnl_percentage": 9.87,
                "sharpe_ratio": 1.20,
                "max_drawdown": -0.10,
                "followers_count": 145,
            },
            "value_investor": {
                "total_trades": 67,
                "win_rate": 0.78,
                "total_pnl": 3210.40,
                "total_pnl_percentage": 32.10,
                "sharpe_ratio": 2.35,
                "max_drawdown": -0.09,
                "followers_count": 521,
            },
            "breakout_hunter": {
                "total_trades": 134,
                "win_rate": 0.59,
                "total_pnl": 756.90,
                "total_pnl_percentage": 7.57,
                "sharpe_ratio": 1.15,
                "max_drawdown": -0.14,
                "followers_count": 89,
            },
            "risk_manager_pro": {
                "total_trades": 89,
                "win_rate": 0.81,
                "total_pnl": 534.60,
                "total_pnl_percentage": 5.35,
                "sharpe_ratio": 1.95,
                "max_drawdown": -0.05,
                "followers_count": 267,
            },
            "volatility_pro": {
                "total_trades": 178,
                "win_rate": 0.64,
                "total_pnl": 1678.25,
                "total_pnl_percentage": 16.78,
                "sharpe_ratio": 1.65,
                "max_drawdown": -0.11,
                "followers_count": 201,
            },
            "mean_reversion": {
                "total_trades": 145,
                "win_rate": 0.70,
                "total_pnl": 1123.80,
                "total_pnl_percentage": 11.24,
                "sharpe_ratio": 1.55,
                "max_drawdown": -0.09,
                "followers_count": 156,
            },
            "grid_master": {
                "total_trades": 312,
                "win_rate": 0.66,
                "total_pnl": 892.45,
                "total_pnl_percentage": 8.92,
                "sharpe_ratio": 1.30,
                "max_drawdown": -0.08,
                "followers_count": 134,
            },
        }

        updated_count = 0
        for username, stats in user_stats_map.items():
            try:
                # Get user by username
                user = await service.get_user_by_username(username)
                if not user:
                    print(f"  [WARN] User not found: {username}")
                    continue

                user_id = user.get("id")
                if not user_id:
                    print(f"  [WARN] No user ID for: {username}")
                    continue

                # Update stats
                success = await service.update_user_stats(user_id, stats)
                if success:
                    print(f"  [OK] Updated stats for: {username} (ID: {user_id})")
                    updated_count += 1
                else:
                    print(f"  [WARN] Failed to update stats for: {username}")

            except Exception as e:
                print(f"  [ERROR] Error updating {username}: {e}")
                continue

        print(f"\n[SUCCESS] Updated stats for {updated_count} users")

    except Exception as e:
        print(f"\n[ERROR] Error updating stats: {e}")
        traceback.print_exc()
        return False
    else:
        return True


async def main():
    """Main entry point"""
    success = await update_stats()
    return 0 if success else 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
