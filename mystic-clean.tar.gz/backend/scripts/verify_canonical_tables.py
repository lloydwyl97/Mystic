"""
Read-only canonical table verification (Phase 1 audit).
Prints DATABASE_PATH and row counts / latest timestamps for:
  trade_performance, paper_trades, portfolio_engine_ledger, portfolio_engine_positions.
No engine start. No Binance. No writes.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

# Use shared canonical path
from backend.database_schema import DATABASE_PATH


def main() -> None:
    path = Path(DATABASE_PATH).resolve()
    print("DATABASE_PATH (absolute):", path)
    conn = sqlite3.connect(path)
    try:
        cur = conn.cursor()
        for name, count_sql, max_ts_sql in [
            (
                "trade_performance",
                "SELECT COUNT(*) FROM trade_performance",
                "SELECT MAX(timestamp) FROM trade_performance",
            ),
            (
                "paper_trades",
                "SELECT COUNT(*) FROM paper_trades",
                "SELECT MAX(timestamp) FROM paper_trades",
            ),
            (
                "portfolio_engine_ledger",
                "SELECT COUNT(*) FROM portfolio_engine_ledger",
                "SELECT MAX(last_updated) FROM portfolio_engine_ledger",
            ),
            (
                "portfolio_engine_positions",
                "SELECT COUNT(*) FROM portfolio_engine_positions",
                "SELECT MAX(last_updated) FROM portfolio_engine_positions",
            ),
        ]:
            try:
                cur.execute(count_sql)
                n = cur.fetchone()[0]
                cur.execute(max_ts_sql)
                row = cur.fetchone()
                ts = row[0] if row else None
                print(f"{name}: count={n}, latest_ts={ts}")
            except sqlite3.OperationalError as e:
                print(f"{name}: table missing or error — {e}")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
