#!/usr/bin/env python3
"""
Verification Script for Restart Persistence
Tests that operational state persists correctly across restarts
"""

import asyncio
import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from backend.database_schema import execute_read, get_state, set_state

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def test_profit_siphon_persistence():
    """Test profit siphon state persistence"""
    logger.info("=== TESTING PROFIT SIPHON PERSISTENCE ===")

    try:
        # Set a test locked amount
        test_amount = 123.45
        test_data = {
            "total_locked": test_amount,
            "siphon_count": 5,
            "last_siphon": datetime.now(timezone.utc).isoformat(),
            "created_at": datetime.now(timezone.utc).isoformat(),
            "description": "Test locked profit reserve",
        }

        await set_state("locked_profit_reserve", test_data)
        logger.info(f"✓ Set locked_profit_reserve to ${test_amount}")

        # Verify it can be read back
        retrieved_data = await get_state("locked_profit_reserve")
        if retrieved_data and retrieved_data["total_locked"] == test_amount:
            logger.info(f"✓ Verified locked_profit_reserve: ${retrieved_data['total_locked']}")
            return True
        else:
            logger.error(f"✗ Failed to verify locked_profit_reserve: {retrieved_data}")
            return False

    except Exception as e:
        logger.exception(f"✗ Profit siphon test failed: {e}")
        return False


async def test_circuit_breaker_persistence():
    """Test circuit breaker state persistence"""
    logger.info("=== TESTING CIRCUIT BREAKER PERSISTENCE ===")

    try:
        # Set circuit breaker states
        circuit_data = {
            "daily_loss_freeze_active": True,
            "equity_circuit_breaker_active": False,
            "account_failsafe_active": True,
            "session_high_equity": 2750.00,
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }

        await set_state("risk:circuit_breakers", circuit_data)
        logger.info("✓ Set circuit breaker states (freeze=True, failsafe=True)")

        # Set trading paused state
        paused_data = {"trading_paused": True, "pause_reason": "circuit_breaker_active", "updated_at": datetime.now(timezone.utc).isoformat()}

        await set_state("risk:trading_paused", paused_data)
        logger.info("✓ Set trading_paused=True")

        # Verify states
        retrieved_circuit = await get_state("risk:circuit_breakers")
        retrieved_paused = await get_state("risk:trading_paused")

        if retrieved_circuit and retrieved_circuit["daily_loss_freeze_active"] and retrieved_paused and retrieved_paused["trading_paused"]:
            logger.info("✓ Verified circuit breaker and trading paused states")
            return True
        else:
            logger.error(f"✗ Failed to verify states: circuit={retrieved_circuit}, paused={retrieved_paused}")
            return False

    except Exception as e:
        logger.exception(f"✗ Circuit breaker test failed: {e}")
        return False


async def test_dedupe_markers():
    """Test dedupe marker persistence"""
    logger.info("=== TESTING DEDUPE MARKERS ===")

    try:
        # Set test decision markers
        test_symbols = ["BTCUSDT", "ETHUSDT", "ADAUSDT"]

        for i, symbol in enumerate(test_symbols):
            decision_id = f"test_decision_{i}_{int(datetime.now().timestamp())}"
            marker_data = {"decision_id": decision_id, "timestamp": datetime.now(timezone.utc).isoformat(), "symbol": symbol}

            await set_state(f"exec:last_decision:{symbol}", marker_data)
            logger.info(f"✓ Set dedupe marker for {symbol}: {decision_id}")

        # Verify markers exist
        marker_count = await execute_read("SELECT COUNT(*) as count FROM operational_state WHERE key LIKE 'exec:last_decision:%'", fetchone=True)

        if marker_count and marker_count[0] >= len(test_symbols):
            logger.info(f"✓ Verified {marker_count[0]} dedupe markers in database")
            return True
        else:
            logger.error(f"✗ Expected {len(test_symbols)} markers, found {marker_count[0] if marker_count else 0}")
            return False

    except Exception as e:
        logger.exception(f"✗ Dedupe marker test failed: {e}")
        return False


async def verify_database_state():
    """Verify all operational state in database"""
    logger.info("=== DATABASE STATE VERIFICATION ===")

    try:
        # Get all operational state keys
        rows = await execute_read("SELECT key, value_json FROM operational_state")

        state_summary = {}
        for row in rows:
            key = row[0]
            try:
                value = json.loads(row[1])
                if key == "locked_profit_reserve":
                    state_summary["profit_siphon"] = f"${value.get('total_locked', 0):.2f}"
                elif key == "risk:circuit_breakers":
                    state_summary["circuit_breakers"] = f"freeze={value.get('daily_loss_freeze_active')}"
                elif key == "risk:trading_paused":
                    state_summary["trading_paused"] = value.get("trading_paused")
                elif key.startswith("exec:last_decision:"):
                    symbol = key.split(":")[-1]
                    if "dedupe_markers" not in state_summary:
                        state_summary["dedupe_markers"] = []
                    state_summary["dedupe_markers"].append(symbol)
            except Exception:
                pass

        logger.info(f"✓ Database state summary: {state_summary}")
        return state_summary

    except Exception as e:
        logger.exception(f"✗ Database verification failed: {e}")
        return {}


async def main():
    """Run all verification tests"""
    logger.info("STARTING RESTART PERSISTENCE VERIFICATION")
    logger.info("=" * 60)

    results = {"profit_siphon": await test_profit_siphon_persistence(), "circuit_breakers": await test_circuit_breaker_persistence(), "dedupe_markers": await test_dedupe_markers()}

    logger.info("=" * 60)
    logger.info("VERIFICATION RESULTS:")

    all_passed = True
    for test_name, passed in results.items():
        status = "✓ PASS" if passed else "✗ FAIL"
        logger.info(f"  {test_name}: {status}")
        if not passed:
            all_passed = False

    # Show database state
    await verify_database_state()

    logger.info("=" * 60)
    if all_passed:
        logger.info("🎉 ALL TESTS PASSED - Restart persistence is working!")
        return 0
    else:
        logger.error("❌ SOME TESTS FAILED - Restart persistence needs fixes!")
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
