#!/usr/bin/env python3
"""
Local verification for strategy repair (no live trading).

Run from repo root: python3 -m backend.scripts.verify_strategy_repairs
"""

from __future__ import annotations

import os
import sys


def main() -> int:
    os.environ.setdefault("MIN_CONFIDENCE", "0.58")
    os.environ.setdefault("MIN_CONFIDENCE_OVERRIDE", "")

    from backend.config.signal_thresholds import MIN_CONFIDENCE_BUY, min_confidence_buy
    from backend.services.confidence_normalizer import ConfidenceNormalizer
    from backend.services.portfolio_engine import MIN_CONFIDENCE, BuyCandidate

    # 1) Unified buy floor
    assert MIN_CONFIDENCE == MIN_CONFIDENCE_BUY == min_confidence_buy(), f"engine {MIN_CONFIDENCE} != shared {MIN_CONFIDENCE_BUY}"

    # 2) Normalizer does not inflate weak probs to the buy floor
    low = ConfidenceNormalizer.normalize(0.25)
    assert low < MIN_CONFIDENCE_BUY, f"expected raw-ish low conf, got {low}"

    # 3) Volatility boost default off
    assert os.getenv("VOLATILITY_BOOST_ENABLED", "false").lower() != "true", "test assumes boost disabled by default"

    # 4) Coin priority multipliers (RULE path: decision_data has no ML buy_margin → legacy rank)
    base = 0.6 * 0.35 + 0.5 * 0.20 - 0.2 * 0.10 - 0.05 * 0.10  # coin_edge 0
    c = BuyCandidate(
        symbol="DOGE/USDT",
        confidence=0.6,
        trend_score=0.5,
        chop_score=0.2,
        coin_edge_score=0.0,
        volatility_penalty=0.05,
        spread_penalty=0.0,
        atr=1.0,
        current_price=100.0,
        decision_data={},
    )
    doge_score = c.composite_score
    c2 = BuyCandidate(
        symbol="SOL/USDT",
        confidence=0.6,
        trend_score=0.5,
        chop_score=0.2,
        coin_edge_score=0.0,
        volatility_penalty=0.05,
        spread_penalty=0.0,
        atr=1.0,
        current_price=100.0,
        decision_data={},
    )
    sol_score = c2.composite_score
    assert abs(sol_score - base) < 1e-9, f"SOL priority 1.0: expected {base}, got {sol_score}"
    assert abs(doge_score - base * 1.2) < 1e-9, f"DOGE priority 1.2: expected {base * 1.2}, got {doge_score}"

    print("verify_strategy_repairs: OK")
    print(f"  MIN_CONFIDENCE_BUY={MIN_CONFIDENCE_BUY}")
    print(f"  normalize(0.25)={low:.4f}")
    print(f"  composite DOGE={doge_score:.4f} SOL={sol_score:.4f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
