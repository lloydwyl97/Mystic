#!/usr/bin/env python3
"""
Advanced Multi-Channel Alert System
Email, SMS, Telegram, Discord notifications for trading system
"""

import asyncio
import json
import logging
import os
import smtplib
import time
from dataclasses import dataclass, field
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Any

import httpx

try:
    from twilio.rest import Client as TwilioClient
except ImportError:
    TwilioClient = None  # type: ignore[assignment]

# Direct imports for production
try:
    import pywebpush
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ec

    WEBPUSH_AVAILABLE = True
except ImportError:
    WEBPUSH_AVAILABLE = False
    pywebpush = None  # type: ignore[assignment]
    ec = None  # type: ignore[assignment]
    serialization = None  # type: ignore[assignment]
    default_backend = None  # type: ignore[assignment]

from backend.services.task_manager import task_manager

logger = logging.getLogger(__name__)


@dataclass
class AlertConfig:
    """Configuration for alert system."""

    enabled: bool = True
    min_severity: str = "warning"  # debug, info, warning, error, critical
    cooldown_seconds: int = 300  # Minimum time between same alerts
    max_alerts_per_hour: int = 10  # Rate limiting


@dataclass
class EmailConfig:
    """Configuration for email alerts."""

    enabled: bool = False
    smtp_server: str = ""
    smtp_port: int = 587
    username: str = ""
    password: str = ""
    from_email: str = ""
    to_emails: list[str] = field(default_factory=list)
    use_tls: bool = True


@dataclass
class SMSConfig:
    """Configuration for SMS alerts."""

    enabled: bool = False
    twilio_account_sid: str = ""
    twilio_auth_token: str = ""
    twilio_phone_number: str = ""
    to_phone_numbers: list[str] = field(default_factory=list)


@dataclass
class TelegramConfig:
    """Configuration for Telegram alerts."""

    enabled: bool = False
    bot_token: str = ""
    chat_ids: list[str] = field(default_factory=list)


@dataclass
class DiscordConfig:
    """Configuration for Discord alerts."""

    enabled: bool = False
    webhook_urls: list[str] = field(default_factory=list)


@dataclass
class AlertMessage:
    """Alert message data structure."""

    title: str
    message: str
    severity: str  # debug, info, warning, error, critical
    category: str  # system, trading, security, performance
    timestamp: float
    metadata: dict[str, Any] = field(default_factory=dict)


class AlertChannel:
    """Base class for alert channels"""

    def __init__(self, config: Any, alert_config: AlertConfig):
        self.config = config
        self.alert_config = alert_config
        self.last_sent: dict[str, float] = {}  # alert_key -> timestamp
        self.hourly_count = 0
        self.hour_start = time.time()

    async def send_alert(self, alert: AlertMessage) -> bool:
        """Send alert through this channel"""
        if not self._should_send_alert(alert):
            return False

        try:
            success = await self._send_implementation(alert)
            if success:
                self._record_sent_alert(alert)
        except Exception as e:
            logger.exception(f"Failed to send {self.__class__.__name__} alert: {e}")
            return False
        else:
            return success

    def _should_send_alert(self, alert: AlertMessage) -> bool:
        """Check if alert should be sent based on config"""
        if not self.config.enabled:
            return False

        # Check severity level
        severity_levels = {
            "debug": 0,
            "info": 1,
            "warning": 2,
            "error": 3,
            "critical": 4,
        }
        min_level = severity_levels.get(self.alert_config.min_severity, 1)
        alert_level = severity_levels.get(alert.severity, 1)

        if alert_level < min_level:
            return False

        # Check cooldown
        alert_key = f"{alert.category}:{alert.title}"
        if alert_key in self.last_sent:
            time_since_last = time.time() - self.last_sent[alert_key]
            if time_since_last < self.alert_config.cooldown_seconds:
                return False

        # Check hourly rate limit
        current_hour = int(time.time() / 3600)
        hour_start = current_hour * 3600

        if hour_start != self.hour_start:
            self.hourly_count = 0
            self.hour_start = hour_start

        return not self.hourly_count >= self.alert_config.max_alerts_per_hour

    def _record_sent_alert(self, alert: AlertMessage):
        """Record that an alert was sent"""
        alert_key = f"{alert.category}:{alert.title}"
        self.last_sent[alert_key] = time.time()
        self.hourly_count += 1

    async def _send_implementation(self, alert: AlertMessage) -> bool:
        """Implementation-specific send method. Override in subclasses."""
        logger.warning("Base AlertChannel._send_implementation called (override in subclass)")
        return False


class EmailChannel(AlertChannel):
    """Email alert channel"""

    async def _send_implementation(self, alert: AlertMessage) -> bool:
        """Send email alert."""
        if not self.config.to_emails:
            return False

        try:
            # Create message
            msg = MIMEMultipart()
            msg["From"] = self.config.from_email
            msg["To"] = ", ".join(self.config.to_emails)
            msg["Subject"] = f"[{alert.severity.upper()}] {alert.title}"

            # HTML body
            severity_color = self._get_severity_color(alert.severity)
            time_str = time.strftime(
                "%Y-%m-%d %H:%M:%S",
                time.localtime(alert.timestamp),
            )
            metadata_section = ""
            if alert.metadata:
                metadata_json = json.dumps(alert.metadata, indent=2)
                metadata_section = f"<h3>Metadata:</h3><pre>{metadata_json}</pre>"

            html_body = f"""
            <html>
            <body>
                <h2 style="color: {severity_color};">
                    {alert.title}
                </h2>
                <p><strong>Category:</strong> {alert.category}</p>
                <p><strong>Severity:</strong> {alert.severity.upper()}</p>
                <p><strong>Time:</strong> {time_str}</p>
                <div style="background-color: #f5f5f5; padding: 10px; "
                     "margin: 10px 0; border-left: 4px solid "
                     "{severity_color};">
                    <pre>{alert.message}</pre>
                </div>
                {metadata_section}
            </body>
            </html>
            """

            msg.attach(MIMEText(html_body, "html"))

            # Send email
            server = smtplib.SMTP(self.config.smtp_server, self.config.smtp_port)
            if self.config.use_tls:
                server.starttls()
            server.login(self.config.username, self.config.password)
            server.send_message(msg)
            server.quit()

            logger.info(f"Email alert sent to {len(self.config.to_emails)} recipients")
        except Exception as e:
            logger.exception(f"Email send error: {e}")
            return False
        else:
            return True

    def _get_severity_color(self, severity: str) -> str:
        """Get color for severity level."""
        colors = {
            "debug": "#808080",
            "info": "#0066cc",
            "warning": "#ff9900",
            "error": "#cc0000",
            "critical": "#990000",
        }
        return colors.get(severity, "#000000")


class SMSChannel(AlertChannel):
    """SMS alert channel using Twilio"""

    def __init__(self, config: SMSConfig, alert_config: AlertConfig):
        super().__init__(config, alert_config)
        self.twilio_client: TwilioClient | None = None
        if config.enabled and config.twilio_account_sid and config.twilio_auth_token and TwilioClient is not None:
            self.twilio_client = TwilioClient(config.twilio_account_sid, config.twilio_auth_token)

    async def _send_implementation(self, alert: AlertMessage) -> bool:
        """Send SMS alert."""
        if not self.twilio_client or not self.config.to_phone_numbers:
            return False

        try:
            message_body = f"{alert.title}\n{alert.message}\nSeverity: {alert.severity.upper()}"

            sent_count = 0
            for phone_number in self.config.to_phone_numbers:
                try:
                    self.twilio_client.messages.create(
                        body=message_body,
                        from_=self.config.twilio_phone_number,
                        to=phone_number,
                    )
                    sent_count += 1
                except Exception as e:
                    logger.exception(f"SMS send error to {phone_number}: {e}")

            logger.info(f"SMS alert sent to {sent_count}/{len(self.config.to_phone_numbers)} numbers")
        except Exception as e:
            logger.exception(f"SMS send error: {e}")
            return False
        else:
            return sent_count > 0


class TelegramChannel(AlertChannel):
    """Telegram alert channel"""

    async def _send_implementation(self, alert: AlertMessage) -> bool:
        """Send Telegram alert."""
        if not self.config.chat_ids or not self.config.bot_token:
            return False

        try:
            message_text = f"*{alert.title}*\n\n{alert.message}\n\n*Severity:* {alert.severity.upper()}\n*Category:* {alert.category}"

            sent_count = 0
            async with httpx.AsyncClient(timeout=10.0) as client:
                for chat_id in self.config.chat_ids:
                    try:
                        url = f"https://api.telegram.org/bot{self.config.bot_token}/sendMessage"
                        payload = {
                            "chat_id": chat_id,
                            "text": message_text,
                            "parse_mode": "Markdown",
                            "disable_web_page_preview": True,
                        }

                        response = await client.post(url, json=payload)
                        if response.status_code == 200:
                            sent_count += 1
                        else:
                            logger.error(f"Telegram send error to {chat_id}: {response.text}")

                    except Exception as e:
                        logger.exception(f"Telegram send error to {chat_id}: {e}")

            logger.info(f"Telegram alert sent to {sent_count}/{len(self.config.chat_ids)} chats")
        except Exception as e:
            logger.exception(f"Telegram send error: {e}")
            return False
        else:
            return sent_count > 0


class DiscordChannel(AlertChannel):
    """Discord alert channel using webhooks"""

    async def _send_implementation(self, alert: AlertMessage) -> bool:
        """Send Discord alert."""
        if not self.config.webhook_urls:
            return False

        try:
            # Create Discord embed
            embed = {
                "title": alert.title,
                "description": alert.message,
                "color": self._get_severity_color(alert.severity),
                "fields": [
                    {
                        "name": "Severity",
                        "value": alert.severity.upper(),
                        "inline": True,
                    },
                    {
                        "name": "Category",
                        "value": alert.category,
                        "inline": True,
                    },
                    {
                        "name": "Time",
                        "value": time.strftime(
                            "%Y-%m-%d %H:%M:%S",
                            time.localtime(alert.timestamp),
                        ),
                        "inline": False,
                    },
                ],
                "footer": {"text": "Mystic Trading Platform"},
            }

            if alert.metadata:
                metadata_json = json.dumps(alert.metadata, indent=2)[:1000]
                embed["fields"].append(
                    {
                        "name": "Details",
                        "value": f"```json\n{metadata_json}```",
                        "inline": False,
                    }
                )

            payload = {
                "embeds": [embed],
                "username": "Mystic Trading Alert",
            }

            sent_count = 0
            async with httpx.AsyncClient(timeout=10.0) as client:
                for webhook_url in self.config.webhook_urls:
                    try:
                        response = await client.post(webhook_url, json=payload)
                        if response.status_code in [200, 204]:
                            sent_count += 1
                        else:
                            logger.error(f"Discord webhook error: {response.text}")

                    except Exception as e:
                        logger.exception(f"Discord webhook send error: {e}")

            logger.info(f"Discord alert sent to {sent_count}/{len(self.config.webhook_urls)} webhooks")
        except Exception as e:
            logger.exception(f"Discord send error: {e}")
            return False
        else:
            return sent_count > 0

    def _get_severity_color(self, severity: str) -> int:
        """Get color for severity level."""
        colors = {
            "debug": 0x808080,  # Gray
            "info": 0x0066CC,  # Blue
            "warning": 0xFF9900,  # Orange
            "error": 0xCC0000,  # Red
            "critical": 0x990000,  # Dark Red
        }
        return colors.get(severity, 0x000000)


class AdvancedAlertSystem:
    """Advanced multi-channel alert system"""

    def __init__(self):
        self.alert_config = AlertConfig()
        self.channels: dict[str, AlertChannel] = {}
        self.alert_history: list[AlertMessage] = []
        self._running = False

    def configure_channel(self, channel_type: str, config: Any):
        """Configure an alert channel"""
        if channel_type == "email":
            self.channels["email"] = EmailChannel(config, self.alert_config)
        elif channel_type == "sms":
            self.channels["sms"] = SMSChannel(config, self.alert_config)
        elif channel_type == "telegram":
            self.channels["telegram"] = TelegramChannel(config, self.alert_config)
        elif channel_type == "discord":
            self.channels["discord"] = DiscordChannel(config, self.alert_config)

        logger.info(f"Configured {channel_type} alert channel")

    async def send_alert(
        self,
        title: str,
        message: str,
        severity: str = "info",
        category: str = "system",
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        """Send alert through all configured channels"""
        metadata_dict = metadata if metadata else {}
        alert = AlertMessage(
            title=title,
            message=message,
            severity=severity,
            category=category,
            timestamp=time.time(),
            metadata=metadata_dict,
        )

        # Store in history
        self.alert_history.append(alert)
        if len(self.alert_history) > 1000:  # Keep last 1000 alerts
            self.alert_history = self.alert_history[-1000:]

        # Send through all channels
        success_count = 0
        tasks = []

        for _channel_name, channel in self.channels.items():
            task = await task_manager.create_task(channel.send_alert(alert), name="advanced_alert_system:send_alert")
            tasks.append(task)

        if tasks:
            results = await asyncio.gather(*tasks, return_exceptions=True)
            success_count = sum(1 for result in results if result is True)

        logger.info(f"Alert '{title}' sent through {success_count}/{len(self.channels)} channels")
        return success_count > 0

    async def send_system_alert(
        self,
        title: str,
        message: str,
        severity: str = "warning",
        metadata: dict[str, Any] | None = None,
    ):
        """Send system-related alert"""
        await self.send_alert(title, message, severity, "system", metadata)

    async def send_trading_alert(
        self,
        title: str,
        message: str,
        severity: str = "info",
        metadata: dict[str, Any] | None = None,
    ):
        """Send trading-related alert"""
        await self.send_alert(title, message, severity, "trading", metadata)

    async def send_security_alert(
        self,
        title: str,
        message: str,
        severity: str = "error",
        metadata: dict[str, Any] | None = None,
    ):
        """Send security-related alert"""
        await self.send_alert(title, message, severity, "security", metadata)

    async def send_performance_alert(
        self,
        title: str,
        message: str,
        severity: str = "warning",
        metadata: dict[str, Any] | None = None,
    ):
        """Send performance-related alert"""
        await self.send_alert(title, message, severity, "performance", metadata)

    def get_alert_history(self, limit: int = 100) -> list[dict[str, Any]]:
        """Get recent alert history"""
        recent_alerts = self.alert_history[-limit:]
        return [
            {
                "title": alert.title,
                "message": alert.message,
                "severity": alert.severity,
                "category": alert.category,
                "timestamp": alert.timestamp,
                "metadata": alert.metadata,
            }
            for alert in recent_alerts
        ]

    def get_channel_status(self) -> dict[str, dict[str, Any]]:
        """Get status of all alert channels"""
        status = {}
        for name, channel in self.channels.items():
            last_sent_val = max(channel.last_sent.values()) if channel.last_sent else 0
            status[name] = {
                "enabled": channel.config.enabled,
                "alerts_sent_hour": channel.hourly_count,
                "last_sent": last_sent_val,
            }
        return status

    async def test_channels(self) -> dict[str, bool]:
        """Test all configured alert channels"""
        test_alert = AlertMessage(
            title="Test Alert",
            message=("This is a test alert to verify channel configuration."),
            severity="info",
            category="system",
            timestamp=time.time(),
        )

        results = {}
        for channel_name, channel in self.channels.items():
            try:
                success = await channel.send_alert(test_alert)
                results[channel_name] = success
                logger.info(f"Test alert sent successfully via {channel_name}: {success}")
            except Exception as e:
                logger.exception(f"Test alert failed for {channel_name}: {e}")
                results[channel_name] = False

        return results

    # Push Notification Methods
    def generate_vapid_keys(self) -> dict[str, str]:
        """Generate VAPID keys for push notifications"""
        if not WEBPUSH_AVAILABLE:
            msg = "Web push notifications not available - install cryptography and pywebpush"
            raise RuntimeError(msg)

        if ec is None or serialization is None:
            msg = "Cryptography library not available"
            raise RuntimeError(msg)

        # Generate ECDSA key pair
        private_key = ec.generate_private_key(ec.SECP256R1(), default_backend())
        public_key = private_key.public_key()

        # Serialize keys
        private_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )

        public_pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )

        # Convert to base64 for web use
        private_b64 = private_pem.decode("utf-8").replace("-----BEGIN PRIVATE KEY-----", "").replace("-----END PRIVATE KEY-----", "").replace("\n", "")
        public_b64 = public_pem.decode("utf-8").replace("-----BEGIN PUBLIC KEY-----", "").replace("-----END PUBLIC KEY-----", "").replace("\n", "")

        return {"private_key": private_b64, "public_key": public_b64}

    async def send_push_notification(
        self,
        subscription: dict[str, Any],
        title: str,
        body: str,
        data: dict[str, Any] | None = None,
    ) -> bool:
        """Send push notification to a specific subscription"""
        if not WEBPUSH_AVAILABLE:
            logger.warning("Web push notifications not available")
            return False

        if pywebpush is None:
            logger.warning("pywebpush library not available")
            return False

        try:
            vapid_private_key = os.getenv("VAPID_PRIVATE_KEY")
            if not vapid_private_key:
                logger.error("VAPID_PRIVATE_KEY not configured")
                return False

            data_dict = data if data else {}
            payload = {
                "title": title,
                "body": body,
                "icon": "/icons/icon-192.png",
                "badge": "/icons/icon-192.png",
                "data": data_dict,
                "requireInteraction": True,
            }

            pywebpush.webpush(
                subscription_info=subscription,
                data=json.dumps(payload),
                vapid_private_key=vapid_private_key,
                vapid_claims={"sub": "mailto:alerts@mystic-trading.com"},
            )

            logger.info(f"Push notification sent: {title}")
        except Exception as e:
            logger.exception(f"Failed to send push notification: {e}")
            return False
        else:
            return True

    async def broadcast_push_notification(
        self,
        title: str,
        _body: str,
        _severity: str = "info",
        _data: dict[str, Any] | None = None,
    ) -> int:
        """Send push notification to all subscribers"""
        if not WEBPUSH_AVAILABLE:
            logger.warning("Web push notifications not available")
            return 0

        # In a real implementation, you'd store subscriptions in a
        # database
        # For now, this is a placeholder for future implementation
        logger.info(f"Push notification broadcast: {title} (not implemented)")
        return 0


# Global alert system instance
advanced_alert_system = AdvancedAlertSystem()


# Convenience functions for quick alerts
async def alert_system_error(
    title: str,
    message: str,
    metadata: dict[str, Any] | None = None,
):
    """Send system error alert"""
    await advanced_alert_system.send_system_alert(title, message, "error", metadata)


async def alert_trading_signal(
    symbol: str,
    side: str,
    confidence: float,
    metadata: dict[str, Any] | None = None,
):
    """Send trading signal alert"""
    title = f"Trading Signal: {symbol}"
    message = f"Generated {side.upper()} signal with {confidence:.1f}% confidence"
    await advanced_alert_system.send_trading_alert(title, message, "info", metadata)


async def alert_high_cpu(cpu_percent: float):
    """Send high CPU usage alert"""
    title = "High CPU Usage"
    message = f"CPU usage is at {cpu_percent:.1f}%, which exceeds the threshold."
    await advanced_alert_system.send_performance_alert(title, message, "warning", {"cpu_percent": cpu_percent})


async def alert_circuit_breaker_open(service_name: str, failure_count: int):
    """Send circuit breaker open alert"""
    title = f"Circuit Breaker Opened: {service_name}"
    message = f"Service {service_name} circuit breaker has opened due to {failure_count} consecutive failures."
    await advanced_alert_system.send_system_alert(
        title,
        message,
        "error",
        {"service": service_name, "failures": failure_count},
    )


async def alert_security_event(event_type: str, details: str):
    """Send security event alert"""
    title = f"Security Event: {event_type}"
    await advanced_alert_system.send_security_alert(title, details, "error", {"event_type": event_type})
