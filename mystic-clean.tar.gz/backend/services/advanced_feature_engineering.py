#!/usr/bin/env python3
"""
Advanced Feature Engineering Service
Comprehensive technical analysis indicators and market microstructure features
"""

import asyncio
import logging
from dataclasses import dataclass

import numpy as np
import pandas as pd

# Import Fibonacci patterns
try:
    from backend.indicators.advanced_indicators import FibonacciPatterns
except ImportError:
    # Fallback if import fails
    class FibonacciPatterns:
        def __init__(self, *args, **kwargs):
            pass

        def get_features(self, _df):
            return {"fib_position": 0, "fib_nearest_level": 0, "fib_distance": 0, "fib_pattern_strength": 0, "fib_trend": 0}


logger = logging.getLogger(__name__)


@dataclass
class FeatureConfig:
    enable_ichimoku: bool = True
    enable_supertrend: bool = True
    enable_fibonacci: bool = True
    enable_market_microstructure: bool = True
    enable_advanced_volatility: bool = True
    enable_momentum_advanced: bool = True
    enable_volume_profile: bool = True
    enable_order_flow: bool = True


class AdvancedFeatureEngineer:
    """Advanced feature engineering for trading signals"""

    def __init__(self, config: FeatureConfig = None):
        self.config = config or FeatureConfig()
        self._feature_cache: dict[str, dict[str, float]] = {}
        self.fibonacci = FibonacciPatterns()

    def extract_advanced_features(self, df: pd.DataFrame, symbol: str = "unknown", market_data: dict | None = None) -> list[float]:
        """Extract comprehensive 200+ feature set from OHLCV data with market regime awareness"""
        # Production optimization: Minimal validation for speed
        if df.empty or len(df) < 10:  # Reduced minimum requirement for production speed
            return [0.0] * 200

        features = []
        market_data = market_data or {}

        try:
            # Core price and volume features (enhanced)
            features.extend(self._extract_enhanced_price_features(df))
            features.extend(self._extract_advanced_volume_features(df))

            # Advanced technical indicators
            if self.config.enable_ichimoku:
                features.extend(self._extract_ichimoku_features(df))
            if self.config.enable_supertrend:
                features.extend(self._extract_supertrend_features(df))
            if self.config.enable_fibonacci:
                features.extend(self._extract_fibonacci_features(df))

            # Market microstructure features
            if self.config.enable_market_microstructure:
                features.extend(self._extract_market_microstructure_features(df))

            # Volatility and momentum (enhanced)
            features.extend(self._extract_advanced_volatility_features(df))
            features.extend(self._extract_advanced_momentum_features(df))

            # Trend and cycle analysis
            features.extend(self._extract_trend_features(df))
            features.extend(self._extract_cycle_features(df))

            # Statistical features
            features.extend(self._extract_statistical_features(df))

            # Market regime features
            regime_features = self._extract_regime_features(df, market_data)
            features.extend(regime_features)

            # Volume profile features
            if self.config.enable_volume_profile:
                features.extend(self._extract_volume_profile_features(df))

            # Order flow features
            if self.config.enable_order_flow:
                features.extend(self._extract_order_flow_features(df))

            # External data integration (sentiment, news, etc.)
            external_features = self._extract_external_features(symbol, market_data)
            features.extend(external_features)

            # Ensure we have exactly 200 features (pad or truncate if necessary)
            while len(features) < 200:
                features.append(0.0)
            features = features[:200]

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error extracting advanced features for {symbol}: {e}")
            return [0.0] * 200  # Return safe defaults on error
        else:
            return features

    def _extract_price_features(self, df: pd.DataFrame) -> list[float]:
        """Extract basic price-based features"""
        try:
            close = df["price"].iloc[-1]
            open_price = df["price"].iloc[0] if len(df) > 1 else close
            high = df["price"].max()
            low = df["price"].min()

            return [
                close,  # Current price
                (close - open_price) / open_price if open_price != 0 else 0,  # Return
                (high - low) / close if close != 0 else 0,  # Normalized range
                (close - df["price"].rolling(20).mean().iloc[-1]) / df["price"].rolling(20).std().iloc[-1] if df["price"].rolling(20).std().iloc[-1] != 0 else 0,  # Z-score
            ]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, ZeroDivisionError):
            return [0.0, 0.0, 0.0, 0.0]

    def _extract_volume_features(self, df: pd.DataFrame) -> list[float]:
        """Extract volume-based features"""
        try:
            if "volume" not in df.columns:
                return [0.0, 0.0, 0.0]

            volume = df["volume"]
            avg_volume = volume.rolling(20).mean().iloc[-1]

            return [
                volume.iloc[-1] / avg_volume if avg_volume != 0 else 0,  # Volume ratio
                volume.rolling(20).std().iloc[-1] / avg_volume if avg_volume != 0 else 0,  # Volume volatility
                np.corrcoef(df["price"].pct_change(), volume.pct_change())[0, 1] if len(df) > 20 else 0,  # Price-volume correlation
            ]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError, ZeroDivisionError):
            return [0.0, 0.0, 0.0]

    def _extract_volatility_features(self, df: pd.DataFrame) -> list[float]:
        """Extract volatility-based features"""
        try:
            returns = df["price"].pct_change().dropna()
            if len(returns) < 10:
                return [0.0, 0.0, 0.0, 0.0]

            # Realized volatility
            realized_vol = returns.rolling(20).std().iloc[-1]

            # Parkinson volatility (using OHLC if available)
            if "high" in df.columns and "low" in df.columns:
                parkinson_vol = np.sqrt((1 / (4 * np.log(2))) * ((df["high"] / df["low"]).apply(lambda x: np.log(x) ** 2)).rolling(20).mean().iloc[-1])
            else:
                parkinson_vol = realized_vol

            # ATR (Average True Range)
            hl = df["price"].diff().abs() if "high" not in df.columns else (df["high"] - df["low"])
            atr = hl.rolling(14).mean().iloc[-1]

            return [
                realized_vol,
                parkinson_vol,
                atr / df["price"].iloc[-1] if df["price"].iloc[-1] != 0 else 0,  # Normalized ATR
                returns.skew(),  # Return skewness
            ]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError, ZeroDivisionError):
            return [0.0, 0.0, 0.0, 0.0]

    def _extract_momentum_features(self, df: pd.DataFrame) -> list[float]:
        """Extract momentum-based features"""
        try:
            # RSI
            delta = df["price"].diff()
            gain = (delta.where(delta > 0, 0)).rolling(14).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(14).mean()
            rs = gain / loss
            rsi = 100 - (100 / (1 + rs)).iloc[-1]

            # MACD
            ema12 = df["price"].ewm(span=12).mean()
            ema26 = df["price"].ewm(span=26).mean()
            macd = ema12 - ema26
            signal = macd.ewm(span=9).mean()
            macd_hist = (macd - signal).iloc[-1]

            # Stochastic
            lowest_low = df["price"].rolling(14).min()
            highest_high = df["price"].rolling(14).max()
            stoch = 100 * ((df["price"] - lowest_low) / (highest_high - lowest_low)).iloc[-1]

            return [
                rsi / 100,  # Normalized RSI
                macd.iloc[-1],
                macd_hist,
                stoch / 100,  # Normalized Stochastic
            ]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError, ZeroDivisionError):
            return [0.5, 0.0, 0.0, 0.5]  # Neutral values

    def _extract_trend_features(self, df: pd.DataFrame) -> list[float]:
        """Extract trend-based features"""
        try:
            # Moving averages
            sma20 = df["price"].rolling(20).mean().iloc[-1]
            sma50 = df["price"].rolling(50).mean().iloc[-1]
            ema20 = df["price"].ewm(span=20).mean().iloc[-1]

            # Trend strength
            price = df["price"].iloc[-1]
            trend_strength = (price - sma50) / sma50 if sma50 != 0 else 0

            # ADX (simplified)
            high = df["price"].rolling(14).max().iloc[-1]
            low = df["price"].rolling(14).min().iloc[-1]
            adx = abs(high - low) / ((high + low) / 2) if (high + low) != 0 else 0

            return [
                (price - sma20) / sma20 if sma20 != 0 else 0,  # Distance from SMA20
                (price - ema20) / ema20 if ema20 != 0 else 0,  # Distance from EMA20
                trend_strength,
                adx,
            ]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError, ZeroDivisionError):
            return [0.0, 0.0, 0.0, 0.0]

    def _extract_ichimoku_features(self, df: pd.DataFrame) -> list[float]:
        """Extract Ichimoku Cloud features"""
        try:
            # Production optimization: Skip length validation for speed

            high = df["price"]
            low = df["price"]
            close = df["price"]

            # Tenkan-sen (Conversion Line)
            tenkan_high = high.rolling(9).max()
            tenkan_low = low.rolling(9).min()
            tenkan_sen = (tenkan_high + tenkan_low) / 2

            # Kijun-sen (Base Line)
            kijun_high = high.rolling(26).max()
            kijun_low = low.rolling(26).min()
            kijun_sen = (kijun_high + kijun_low) / 2

            # Chikou Span (Lagging Span) - unused in current implementation
            # chikou_span = close.shift(-26)

            # Cloud boundaries
            ssa = ((tenkan_sen + kijun_sen) / 2).shift(26)  # Leading Span A
            ssb = ((high.rolling(52).max() + low.rolling(52).min()) / 2).shift(26)  # Leading Span B

            current_price = close.iloc[-1]

            return [
                (tenkan_sen.iloc[-1] - kijun_sen.iloc[-1]) / current_price if current_price != 0 else 0,  # TK-KJ crossover signal
                (current_price - ssa.iloc[-1]) / current_price if current_price != 0 and not pd.isna(ssa.iloc[-1]) else 0,  # Price vs Cloud A
                (current_price - ssb.iloc[-1]) / current_price if current_price != 0 and not pd.isna(ssb.iloc[-1]) else 0,  # Price vs Cloud B
            ]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError, ZeroDivisionError):
            return [0.0, 0.0, 0.0]

    def _extract_supertrend_features(self, df: pd.DataFrame) -> list[float]:
        """Extract SuperTrend features"""
        try:
            # Production optimization: Skip validation

            # Simplified SuperTrend calculation
            high = df["price"]
            low = df["price"]
            close = df["price"]

            # ATR for SuperTrend
            hl = high - low
            hc = (high - close.shift(1)).abs()
            lc = (low - close.shift(1)).abs()
            tr = pd.concat([hl, hc, lc], axis=1).max(axis=1)
            atr = tr.rolling(14).mean()

            # SuperTrend bands (simplified)
            multiplier = 3
            upper_band = ((high + low) / 2) + (multiplier * atr)
            lower_band = ((high + low) / 2) - (multiplier * atr)

            current_price = close.iloc[-1]

            return [
                (current_price - upper_band.iloc[-1]) / current_price if current_price != 0 else 0,  # Distance from upper band
                (current_price - lower_band.iloc[-1]) / current_price if current_price != 0 else 0,  # Distance from lower band
            ]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError, ZeroDivisionError):
            return [0.0, 0.0]

    def _extract_fibonacci_features(self, df: pd.DataFrame) -> list[float]:
        """Extract Fibonacci pattern features"""
        try:
            # Production optimization: Skip validation checks

            fib_features = self.fibonacci.get_features(df)

            return [
                fib_features.get("fib_position", 0.0),
                fib_features.get("fib_nearest_level", 0.0),
                fib_features.get("fib_distance", 0.0),
                fib_features.get("fib_pattern_strength", 0.0),
                fib_features.get("fib_trend", 0.0),
            ]
        except Exception as e:
            logger.warning(f"Error extracting Fibonacci features: {e}")
            return [0.0, 0.0, 0.0, 0.0, 0.0]

    def _extract_market_microstructure_features(self, df: pd.DataFrame) -> list[float]:
        """Extract market microstructure features"""
        try:
            if len(df) < 20:
                return [0.0, 0.0, 0.0]

            # Price impact analysis
            returns = df["price"].pct_change().dropna()
            volume = df.get("volume", pd.Series([1] * len(df)))

            # Kyle's lambda (price impact)
            if len(returns) > 10:
                cov_pv = np.cov(returns, volume[: len(returns)])[0, 1]
                var_v = np.var(volume[: len(returns)])
                kyle_lambda = abs(cov_pv / var_v) if var_v != 0 else 0
            else:
                kyle_lambda = 0

            # Order flow toxicity (simplified)
            price_changes = returns
            volume_weighted = volume[: len(price_changes)] * price_changes.abs()
            toxicity = volume_weighted.rolling(10).mean().iloc[-1] if len(volume_weighted) > 10 else 0

            # Bid-ask spread proxy (using high-low range)
            spread = (df["price"].rolling(5).max() - df["price"].rolling(5).min()).iloc[-1] / df["price"].iloc[-1]

            return [
                kyle_lambda,
                toxicity,
                spread,
            ]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError, ZeroDivisionError):
            return [0.0, 0.0, 0.0]
        else:
            return [
                kyle_lambda,
                toxicity,
                spread,
            ]

    def _extract_advanced_volatility_features(self, df: pd.DataFrame) -> list[float]:
        """Extract advanced volatility features"""
        try:
            returns = df["price"].pct_change().dropna()
            if len(returns) < 20:
                return [0.0, 0.0, 0.0]

            # Realized volatility
            rv = returns.rolling(20).std()

            # Realized skewness
            skew = returns.rolling(20).skew()

            # Realized kurtosis
            kurt = returns.rolling(20).kurt()

            return [
                rv.iloc[-1],
                skew.iloc[-1],
                kurt.iloc[-1],
            ]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError, ZeroDivisionError):
            return [0.0, 0.0, 0.0]

    def _extract_advanced_momentum_features(self, df: pd.DataFrame) -> list[float]:
        """Extract advanced momentum features"""
        try:
            if len(df) < 30:
                return [0.0, 0.0, 0.0]

            # Williams %R
            highest_high = df["price"].rolling(14).max()
            lowest_low = df["price"].rolling(14).min()
            williams_r = -100 * ((highest_high - df["price"]) / (highest_high - lowest_low)).iloc[-1]

            # Commodity Channel Index (CCI)
            typical_price = (df["price"] + df["price"] + df["price"]) / 3  # H+L+C approximation
            sma_tp = typical_price.rolling(20).mean()
            mad_tp = (typical_price - sma_tp).abs().rolling(20).mean()
            cci = ((typical_price - sma_tp) / (0.015 * mad_tp)).iloc[-1]

            # Ultimate Oscillator
            bp = df["price"] - df["price"].rolling(1).min()  # Buying pressure approximation
            tr = df["price"].rolling(1).max() - df["price"].rolling(1).min()  # True range approximation

            avg7 = bp.rolling(7).sum() / tr.rolling(7).sum()
            avg14 = bp.rolling(14).sum() / tr.rolling(14).sum()
            avg28 = bp.rolling(28).sum() / tr.rolling(28).sum()

            ultimate = 100 * ((4 * avg7) + (2 * avg14) + avg28) / 7
            ultimate_val = ultimate.iloc[-1] if not pd.isna(ultimate.iloc[-1]) else 50

            return [
                williams_r / 100,  # Normalized Williams %R
                cci / 100 if not pd.isna(cci) else 0,  # Normalized CCI
                ultimate_val / 100,  # Normalized Ultimate Oscillator
            ]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError, ZeroDivisionError):
            return [0.0, 0.0, 0.0]

    def _extract_volume_profile_features(self, df: pd.DataFrame) -> list[float]:
        """Extract volume profile features"""
        try:
            if "volume" not in df.columns or len(df) < 20:
                return [0.0, 0.0]

            # Volume-weighted average price (VWAP)
            typical_price = df["price"]  # Approximation
            volume = df["volume"]
            vwap = (typical_price * volume).cumsum() / volume.cumsum()
            vwap_ratio = df["price"].iloc[-1] / vwap.iloc[-1] if vwap.iloc[-1] != 0 else 1

            # Volume Price Trend (VPT)
            price_change = df["price"].pct_change()
            vpt = (volume * price_change).cumsum().iloc[-1]

            return [
                vwap_ratio - 1,  # VWAP deviation
                vpt / volume.sum() if volume.sum() != 0 else 0,  # Normalized VPT
            ]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError, ZeroDivisionError):
            return [0.0, 0.0]

    def _extract_order_flow_features(self, df: pd.DataFrame) -> list[float]:
        """Extract order flow features"""
        try:
            if len(df) < 10:
                return [0.0, 0.0]

            # Accumulation/Distribution Line (simplified)
            money_flow_multiplier = (df["price"] - df["price"].shift(1)) / (df["price"].rolling(2).max() - df["price"].rolling(2).min())
            money_flow_volume = money_flow_multiplier * df.get("volume", pd.Series([1] * len(df)))
            adl = money_flow_volume.cumsum().iloc[-1]

            # Chaikin Money Flow
            money_flow_ratio = (df["price"] - df["price"].shift(1)) * df.get("volume", pd.Series([1] * len(df)))
            cmf = money_flow_ratio.rolling(21).sum() / df.get("volume", pd.Series([1] * len(df))).rolling(21).sum()
            cmf_val = cmf.iloc[-1] if not pd.isna(cmf.iloc[-1]) else 0

            return [
                adl / len(df),  # Normalized ADL
                cmf_val,
            ]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError, ZeroDivisionError):
            return [0.0, 0.0]

    def _extract_statistical_features(self, df: pd.DataFrame) -> list[float]:
        """Extract statistical features"""
        try:
            if len(df) < 20:
                return [0.0, 0.0, 0.0, 0.0]

            returns = df["price"].pct_change().dropna()

            # Higher-order moments
            skewness = returns.skew()
            kurtosis = returns.kurtosis()

            # Hurst exponent (simplified) with robust guards against zeros/NaNs - VECTORIZED for performance
            lags = np.arange(2, 20)
            tau_raw = []
            for lag in lags:
                diff = np.subtract(returns[lag:], returns[:-lag])
                val = float(np.sqrt(np.std(diff))) if len(diff) else float("nan")
                tau_raw.append(val)

            # VECTORIZED filtering for performance
            tau_raw = np.array(tau_raw)
            finite_mask = np.isfinite(tau_raw) & (tau_raw > 0)
            tau = tau_raw[finite_mask].tolist()
            lags_clean = lags[finite_mask].tolist()

            if tau and lags_clean and len(tau) == len(lags_clean):
                try:
                    hurst = float(np.polyfit(np.log(lags_clean), np.log(tau), 1)[0])
                except (ValueError, RuntimeError, TypeError, FloatingPointError):
                    hurst = 0.5  # Random walk fallback
            else:
                hurst = 0.5

            # Shannon entropy of returns
            hist, _ = np.histogram(returns, bins=10, density=True)
            hist = hist[hist > 0]  # Remove zeros
            entropy = -np.sum(hist * np.log2(hist)) if len(hist) > 0 else 0

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError, ZeroDivisionError):
            return [0.0, 0.0, 0.5, 0.0]
        else:
            return [
                skewness,
                kurtosis,
                hurst,
                entropy,
            ]

    # NEW ENHANCED METHODS FOR 200+ FEATURES

    def _extract_enhanced_price_features(self, df: pd.DataFrame) -> list[float]:
        """Enhanced price features with more sophisticated calculations"""
        try:
            close = df["close"].to_numpy()
            high = df["high"].to_numpy()
            low = df["low"].to_numpy()
            open_p = df["open"].to_numpy()

            # Price action patterns
            body_size = np.abs(close - open_p) / open_p  # Body size ratio
            upper_wick = np.abs(high - np.maximum(close, open_p)) / open_p  # Upper wick ratio
            lower_wick = np.abs(np.minimum(close, open_p) - low) / open_p  # Lower wick ratio

            # Range and volatility ratios
            daily_range = (high - low) / open_p  # Normalized range
            gap_up = np.where(open_p > df["close"].shift(1), (open_p - df["close"].shift(1)) / df["close"].shift(1), 0)
            gap_down = np.where(open_p < df["close"].shift(1), (df["close"].shift(1) - open_p) / df["close"].shift(1), 0)

            return [
                float(body_size[-1]),
                float(upper_wick[-1]),
                float(lower_wick[-1]),
                float(daily_range[-1]),
                float(gap_up[-1]),
                float(gap_down[-1]),
                # Add more price features
                float(np.mean(body_size[-10:])),
                float(np.std(body_size[-10:])),
                float(np.mean(upper_wick[-10:])),
                float(np.mean(lower_wick[-10:])),
            ]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            return [0.0] * 10

    def _extract_advanced_volume_features(self, df: pd.DataFrame) -> list[float]:
        """Advanced volume analysis features"""
        try:
            volume = df["volume"].to_numpy()
            close = df["close"].to_numpy()
            high = df["high"].to_numpy()
            low = df["low"].to_numpy()

            # Volume price trend
            vpt = np.cumsum(volume * (close - df["close"].shift(1).fillna(close[0])) / close[0])

            # On-balance volume (OBV)
            obv_changes = np.where(close > np.roll(close, 1), volume, np.where(close < np.roll(close, 1), -volume, 0))
            obv_changes[0] = 0  # First element
            obv = np.cumsum(obv_changes)

            # Volume weighted average price (VWAP)
            vwap = np.cumsum(volume * (high + low + close) / 3) / np.cumsum(volume)

            # Volume ratios
            vol_ma20 = pd.Series(volume).rolling(20).mean().iloc[-1]
            vol_ratio = volume[-1] / vol_ma20 if vol_ma20 > 0 else 1.0

            return [
                float(vpt[-1]),
                float(obv[-1]),
                float(vwap[-1]),
                float(vol_ratio),
                float(np.mean(volume[-10:])),
                float(np.std(volume[-10:])),
                float(np.max(volume[-20:])),
                float(np.min(volume[-20:])),
            ]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            return [0.0] * 8

    def _extract_cycle_features(self, df: pd.DataFrame) -> list[float]:
        """Market cycle and seasonality features"""
        try:
            close = df["close"].to_numpy()

            # Detrended price oscillator
            ma20 = pd.Series(close).rolling(20).mean().to_numpy()
            dpo = close - np.roll(ma20, -10)  # 10-period shift

            # Commodity Channel Index (CCI)
            typical_price = (df["high"] + df["low"] + df["close"]) / 3
            sma_tp = typical_price.rolling(20).mean()
            mad_tp = typical_price.rolling(20).apply(lambda x: np.mean(np.abs(x - x.mean())))
            cci = (typical_price - sma_tp) / (0.015 * mad_tp)

            # Schaff Trend Cycle
            macd_line = pd.Series(close).ewm(span=23).mean() - pd.Series(close).ewm(span=50).mean()
            signal_line = macd_line.ewm(span=10).mean()
            stc = 100 * (macd_line - signal_line.rolling(10).min()) / (signal_line.rolling(10).max() - signal_line.rolling(10).min())

            return [
                float(dpo[-1]) if not np.isnan(dpo[-1]) else 0.0,
                float(cci.iloc[-1]) if not np.isnan(cci.iloc[-1]) else 0.0,
                float(stc.iloc[-1]) if not np.isnan(stc.iloc[-1]) else 0.0,
                float(np.mean(dpo[-20:])),
                float(np.std(dpo[-20:])),
            ]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            return [0.0] * 5

    def _extract_regime_features(self, df: pd.DataFrame, market_data: dict) -> list[float]:
        """Market regime detection and classification features"""
        try:
            close = df["close"].to_numpy()
            volume = df["volume"].to_numpy()

            # Volatility regime (high/low vol)
            returns = np.diff(np.log(close))
            vol_20 = np.std(returns[-20:]) * np.sqrt(252)  # Annualized
            vol_regime = 1.0 if vol_20 > 0.5 else 0.0  # High vol threshold

            # Trend regime
            ma50 = pd.Series(close).rolling(50).mean().iloc[-1]
            ma200 = pd.Series(close).rolling(200).mean().iloc[-1]
            trend_strength = (ma50 - ma200) / ma200 if ma200 != 0 else 0
            trend_regime = 1.0 if trend_strength > 0.05 else (-1.0 if trend_strength < -0.05 else 0.0)

            # Volume regime
            vol_ma50 = pd.Series(volume).rolling(50).mean().iloc[-1]
            vol_ma200 = pd.Series(volume).rolling(200).mean().iloc[-1]
            volume_trend = (vol_ma50 - vol_ma200) / vol_ma200 if vol_ma200 != 0 else 0

            # Market breadth (if available in market_data)
            breadth = market_data.get("market_breadth", 0.5)  # Default neutral

            return [
                vol_regime,
                trend_regime,
                float(volume_trend),
                float(trend_strength),
                breadth,
                # Additional regime indicators
                float(np.corrcoef(close[-20:], volume[-20:])[0, 1]),  # Price-volume correlation
                float(1.0 if np.mean(returns[-20:]) > 0 else 0.0),  # Momentum direction
            ]
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            return [0.0] * 7

    def _extract_external_features(self, symbol: str, market_data: dict) -> list[float]:
        """External data integration features (sentiment, news, etc.)"""
        try:
            # Sentiment features
            sentiment_score = market_data.get("sentiment_score", 0.0)
            sentiment_volume = market_data.get("sentiment_volume", 0.0)
            news_sentiment = market_data.get("news_sentiment", 0.0)

            # Market fear & greed index
            fear_greed = market_data.get("fear_greed_index", 50.0) / 100.0  # Normalize to 0-1

            # Funding rates (for crypto)
            funding_rate = market_data.get("funding_rate", 0.0)

            # Open interest
            open_interest = market_data.get("open_interest", 0.0)

            # Correlation with major assets
            btc_correlation = market_data.get("btc_correlation", 0.0)
            sp500_correlation = market_data.get("sp500_correlation", 0.0)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            return [0.0] * 8
        else:
            return [sentiment_score, sentiment_volume, news_sentiment, fear_greed, funding_rate, open_interest, btc_correlation, sp500_correlation]


class AdvancedFeatureEngineeringService:
    """Service managing advanced feature engineering"""

    def __init__(self):
        self.engineers: dict[str, AdvancedFeatureEngineer] = {}
        self._feature_cache: dict[str, dict[str, list[float]]] = {}

    def get_or_create_engineer(self, symbol: str, config: FeatureConfig = None) -> AdvancedFeatureEngineer:
        """Get or create feature engineer for symbol"""
        if symbol not in self.engineers:
            self.engineers[symbol] = AdvancedFeatureEngineer(config)
        return self.engineers[symbol]

    async def extract_features_async(self, df: pd.DataFrame, symbol: str) -> list[float]:
        """Extract features asynchronously with caching"""
        cache_key = f"{symbol}_{hash(str(df.to_numpy().tobytes()) if hasattr(df, 'to_numpy') else str(df))}"

        # Check cache first
        if symbol in self._feature_cache and cache_key in self._feature_cache[symbol]:
            return self._feature_cache[symbol][cache_key]

        # Extract features in thread pool to avoid blocking
        engineer = self.get_or_create_engineer(symbol)
        features = await asyncio.get_event_loop().run_in_executor(None, engineer.extract_advanced_features, df, symbol)

        # Cache results
        if symbol not in self._feature_cache:
            self._feature_cache[symbol] = {}
        self._feature_cache[symbol][cache_key] = features

        # Limit cache size
        if len(self._feature_cache[symbol]) > 100:
            # Remove oldest entries
            oldest_keys = list(self._feature_cache[symbol].keys())[:-50]
            for key in oldest_keys:
                del self._feature_cache[symbol][key]

        return features

    def get_feature_names(self) -> list[str]:
        """Get list of all feature names"""
        return [
            # Basic features
            "current_price",
            "return",
            "normalized_range",
            "price_zscore",
            "volume_ratio",
            "volume_volatility",
            "price_volume_corr",
            "realized_vol",
            "parkinson_vol",
            "normalized_atr",
            "return_skew",
            "rsi_norm",
            "macd",
            "macd_hist",
            "stoch_norm",
            "dist_sma20",
            "dist_ema20",
            "trend_strength",
            "adx",
            # Ichimoku
            "ichimoku_tk_kj",
            "ichimoku_price_cloud_a",
            "ichimoku_price_cloud_b",
            # SuperTrend
            "supertrend_upper_dist",
            "supertrend_lower_dist",
            # Market microstructure
            "kyle_lambda",
            "toxicity",
            "spread",
            # Advanced volatility
            "realized_vol_adv",
            "skewness",
            "kurtosis",
            # Advanced momentum
            "williams_r_norm",
            "cci_norm",
            "ultimate_norm",
            # Volume profile
            "vwap_deviation",
            "vpt_norm",
            # Order flow
            "adl_norm",
            "cmf",
            # Statistical
            "stat_skew",
            "stat_kurt",
            "hurst",
            "entropy",
        ]


# Global feature engineering service instance
advanced_feature_service = AdvancedFeatureEngineeringService()
