#!/usr/bin/env python3
"""
Advanced Order Management System
Bracket orders, Trailing stops, Iceberg orders, and complex order strategies
"""

import asyncio
import inspect
import logging
import time
from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import Any

from backend.services.canonical_cache import canonical_cache
from backend.services.market_data import MarketDataService
from backend.services.task_manager import task_manager

logger = logging.getLogger(__name__)


class OrderType(Enum):
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    STOP_LOSS = "STOP_LOSS"
    TAKE_PROFIT = "TAKE_PROFIT"
    TRAILING_STOP = "TRAILING_STOP"
    BRACKET = "BRACKET"
    ICEBERG = "ICEBERG"
    OCO = "OCO"  # One-Cancels-Other


class OrderStatus(Enum):
    PENDING = "PENDING"
    OPEN = "OPEN"
    PARTIAL = "PARTIAL"
    FILLED = "FILLED"
    CANCELLED = "CANCELLED"
    EXPIRED = "EXPIRED"
    FAILED = "FAILED"


class OrderSide(Enum):
    BUY = "BUY"
    SELL = "SELL"


@dataclass
class OrderComponent:
    """Individual order component in a complex order"""

    order_id: str
    symbol: str
    side: OrderSide
    quantity: Decimal
    price: Decimal | None = None
    order_type: OrderType = OrderType.LIMIT
    status: OrderStatus = OrderStatus.PENDING

    # For trailing stops
    trail_percentage: float | None = None
    trail_amount: Decimal | None = None
    activation_price: Decimal | None = None

    # Execution tracking
    filled_quantity: Decimal = Decimal("0")
    average_fill_price: Decimal | None = None
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)


@dataclass
class AdvancedOrder:
    """Complex order with multiple components and strategies"""

    master_order_id: str
    symbol: str
    strategy_type: OrderType
    status: OrderStatus = OrderStatus.PENDING

    # Components
    entry_order: OrderComponent | None = None
    stop_loss_order: OrderComponent | None = None
    take_profit_order: OrderComponent | None = None

    # For iceberg orders
    total_quantity: Decimal | None = None
    iceberg_chunks: list[OrderComponent] = field(default_factory=list)
    chunk_size: Decimal | None = None
    chunk_delay: float = 1.0  # seconds between chunks

    # For bracket orders
    bracket_type: str | None = None  # "ENTRY", "EXIT", "FULL"
    profit_target: Decimal | None = None
    stop_loss_percentage: float | None = None
    stop_loss_amount: Decimal | None = None

    # For OCO orders
    oco_orders: list[OrderComponent] = field(default_factory=list)

    # Metadata
    user_id: str | None = None
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    metadata: dict[str, Any] = field(default_factory=dict)


class AdvancedOrderManager:
    """Manages complex trading orders with advanced strategies"""

    def __init__(self):
        self.active_orders: dict[str, AdvancedOrder] = {}
        self.order_components: dict[str, OrderComponent] = {}
        self.price_monitoring_tasks: dict[str, asyncio.Task] = {}

        # Configuration
        self.max_iceberg_chunks = 50
        self.min_chunk_delay = 0.1
        self.max_chunk_delay = 60.0

        logger.info("Advanced Order Manager initialized")

    async def create_bracket_order(
        self,
        symbol: str,
        side: OrderSide,
        quantity: Decimal,
        entry_price: Decimal | None = None,
        profit_target: Decimal | None = None,
        stop_loss_percentage: float | None = None,
        stop_loss_amount: Decimal | None = None,
        user_id: str | None = None,
    ) -> str:
        """Create a bracket order with entry, profit target, and stop loss"""

        master_order_id = f"bracket_{int(time.time() * 1000000)}"

        # Create entry order
        entry_order = OrderComponent(
            order_id=f"{master_order_id}_entry",
            symbol=symbol,
            side=side,
            quantity=quantity,
            price=entry_price,
            order_type=OrderType.LIMIT if entry_price else OrderType.MARKET,
        )

        # Create take profit order (opposite side)
        tp_side = OrderSide.SELL if side == OrderSide.BUY else OrderSide.BUY
        take_profit_order = None
        if profit_target:
            take_profit_order = OrderComponent(
                order_id=f"{master_order_id}_tp",
                symbol=symbol,
                side=tp_side,
                quantity=quantity,
                price=profit_target,
                order_type=OrderType.LIMIT,
            )

        # Create stop loss order
        sl_side = tp_side  # Same as take profit
        stop_loss_price = None
        if stop_loss_percentage and entry_price:
            stop_loss_price = entry_price * Decimal(1 - stop_loss_percentage / 100) if side == OrderSide.BUY else entry_price * Decimal(1 + stop_loss_percentage / 100)
        elif stop_loss_amount and entry_price:
            stop_loss_price = entry_price - stop_loss_amount if side == OrderSide.BUY else entry_price + stop_loss_amount

        stop_loss_order = None
        if stop_loss_price:
            stop_loss_order = OrderComponent(
                order_id=f"{master_order_id}_sl",
                symbol=symbol,
                side=sl_side,
                quantity=quantity,
                price=stop_loss_price,
                order_type=OrderType.STOP_LOSS,
            )

        # Create the advanced order
        order = AdvancedOrder(
            master_order_id=master_order_id,
            symbol=symbol,
            strategy_type=OrderType.BRACKET,
            entry_order=entry_order,
            take_profit_order=take_profit_order,
            stop_loss_order=stop_loss_order,
            profit_target=profit_target,
            stop_loss_percentage=stop_loss_percentage,
            stop_loss_amount=stop_loss_amount,
            user_id=user_id,
        )

        # Store the order
        self.active_orders[master_order_id] = order
        self._register_components(order)

        # Start monitoring if needed
        if take_profit_order or stop_loss_order:
            await self._start_price_monitoring(order)

        logger.info(f"Created bracket order {master_order_id} for {symbol}")
        return master_order_id

    async def create_trailing_stop_order(
        self,
        symbol: str,
        side: OrderSide,
        quantity: Decimal,
        activation_price: Decimal | None = None,
        trail_percentage: float | None = None,
        trail_amount: Decimal | None = None,
        user_id: str | None = None,
    ) -> str:
        """Create a trailing stop order"""

        master_order_id = f"trailing_{int(time.time() * 1000000)}"

        order_component = OrderComponent(
            order_id=master_order_id,
            symbol=symbol,
            side=side,
            quantity=quantity,
            order_type=OrderType.TRAILING_STOP,
            trail_percentage=trail_percentage,
            trail_amount=trail_amount,
            activation_price=activation_price,
        )

        order = AdvancedOrder(
            master_order_id=master_order_id,
            symbol=symbol,
            strategy_type=OrderType.TRAILING_STOP,
            entry_order=order_component,
            user_id=user_id,
        )

        self.active_orders[master_order_id] = order
        self._register_components(order)
        await self._start_price_monitoring(order)

        logger.info(f"Created trailing stop order {master_order_id} for {symbol}")
        return master_order_id

    async def create_iceberg_order(
        self,
        symbol: str,
        side: OrderSide,
        total_quantity: Decimal,
        chunk_size: Decimal,
        chunk_delay: float = 1.0,
        price: Decimal | None = None,
        user_id: str | None = None,
    ) -> str:
        """Create an iceberg order that executes in chunks"""

        if chunk_size <= 0 or total_quantity <= 0:
            msg = "Chunk size and total quantity must be positive"
            raise ValueError(msg)

        if chunk_size > total_quantity:
            msg = "Chunk size cannot exceed total quantity"
            raise ValueError(msg)

        master_order_id = f"iceberg_{int(time.time() * 1000000)}"

        # Validate chunk delay
        chunk_delay = max(self.min_chunk_delay, min(chunk_delay, self.max_chunk_delay))

        # Calculate number of chunks
        num_chunks = int(total_quantity / chunk_size)
        remainder = total_quantity % chunk_size

        chunks = []
        for i in range(num_chunks):
            chunk_order = OrderComponent(
                order_id=f"{master_order_id}_chunk_{i}",
                symbol=symbol,
                side=side,
                quantity=chunk_size,
                price=price,
                order_type=OrderType.LIMIT if price else OrderType.MARKET,
            )
            chunks.append(chunk_order)

        # Add remainder chunk if needed
        if remainder > 0:
            remainder_chunk = OrderComponent(
                order_id=f"{master_order_id}_remainder",
                symbol=symbol,
                side=side,
                quantity=remainder,
                price=price,
                order_type=OrderType.LIMIT if price else OrderType.MARKET,
            )
            chunks.append(remainder_chunk)

        if len(chunks) > self.max_iceberg_chunks:
            msg = f"Too many chunks: {len(chunks)} > {self.max_iceberg_chunks}"
            raise ValueError(msg)

        order = AdvancedOrder(
            master_order_id=master_order_id,
            symbol=symbol,
            strategy_type=OrderType.ICEBERG,
            iceberg_chunks=chunks,
            total_quantity=total_quantity,
            chunk_size=chunk_size,
            chunk_delay=chunk_delay,
            user_id=user_id,
        )

        self.active_orders[master_order_id] = order
        self._register_components(order)

        logger.info(f"Created iceberg order {master_order_id} with {len(chunks)} chunks for {symbol}")
        return master_order_id

    async def create_oco_order(
        self,
        symbol: str,
        quantity: Decimal,
        order1_price: Decimal,
        order2_price: Decimal,
        user_id: str | None = None,
    ) -> str:
        """Create One-Cancels-Other (OCO) order"""

        master_order_id = f"oco_{int(time.time() * 1000000)}"

        # Determine sides based on prices (assuming current price context)
        # This is simplified - in real implementation, you'd get current price
        side1 = OrderSide.SELL if order1_price > order2_price else OrderSide.BUY
        side2 = OrderSide.BUY if order1_price > order2_price else OrderSide.SELL

        oco_orders = [
            OrderComponent(
                order_id=f"{master_order_id}_1",
                symbol=symbol,
                side=side1,
                quantity=quantity,
                price=order1_price,
                order_type=OrderType.LIMIT,
            ),
            OrderComponent(
                order_id=f"{master_order_id}_2",
                symbol=symbol,
                side=side2,
                quantity=quantity,
                price=order2_price,
                order_type=OrderType.LIMIT,
            ),
        ]

        order = AdvancedOrder(
            master_order_id=master_order_id,
            symbol=symbol,
            strategy_type=OrderType.OCO,
            oco_orders=oco_orders,
            user_id=user_id,
        )

        self.active_orders[master_order_id] = order
        self._register_components(order)

        logger.info(f"Created OCO order {master_order_id} for {symbol}")
        return master_order_id

    def _register_components(self, order: AdvancedOrder):
        """Register all components of an order"""
        components = []

        if order.entry_order:
            components.append(order.entry_order)
        if order.stop_loss_order:
            components.append(order.stop_loss_order)
        if order.take_profit_order:
            components.append(order.take_profit_order)

        components.extend(order.iceberg_chunks)
        components.extend(order.oco_orders)

        for component in components:
            self.order_components[component.order_id] = component

    async def execute_iceberg_order(self, master_order_id: str) -> bool:
        """Execute an iceberg order by placing chunks sequentially"""
        order = self.active_orders.get(master_order_id)
        if not order or order.strategy_type != OrderType.ICEBERG:
            return False

        logger.info(f"Executing iceberg order {master_order_id}")

        for i, chunk in enumerate(order.iceberg_chunks):
            if chunk.status != OrderStatus.PENDING:
                continue

            try:
                # Simulate order placement (replace with actual exchange API call)
                success = await self._place_order_component(chunk)
                if success:
                    chunk.status = OrderStatus.OPEN
                    logger.info(f"Executed iceberg chunk {i + 1}/{len(order.iceberg_chunks)} for {master_order_id}")

                    # Wait before next chunk
                    if i < len(order.iceberg_chunks) - 1:
                        await asyncio.sleep(order.chunk_delay)
                else:
                    logger.error(f"Failed to execute iceberg chunk {i + 1} for {master_order_id}")
                    return False

            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception(f"Error executing iceberg chunk {i + 1} for {master_order_id}: {e}")
                return False

        order.status = OrderStatus.FILLED
        logger.info(f"Iceberg order {master_order_id} fully executed")
        return True

    async def _start_price_monitoring(self, order: AdvancedOrder):
        """Start price monitoring for orders that need it"""
        if order.master_order_id in self.price_monitoring_tasks:
            return

        task = await task_manager.create_task(self._monitor_order_prices(order), name="advanced_order_manager:monitor_order_prices")
        self.price_monitoring_tasks[order.master_order_id] = task

    async def _monitor_order_prices(self, order: AdvancedOrder):
        """Monitor prices for trailing stops and conditional orders"""
        try:
            while order.status in [
                OrderStatus.PENDING,
                OrderStatus.OPEN,
                OrderStatus.PARTIAL,
            ]:
                await asyncio.sleep(1)  # Monitor every second

                # Get current price (mock - replace with actual price feed)
                current_price = await self._get_current_price(order.symbol)

                if order.strategy_type == OrderType.BRACKET:
                    await self._check_bracket_conditions(order, current_price)
                elif order.strategy_type == OrderType.TRAILING_STOP:
                    await self._update_trailing_stop(order, current_price)

        except asyncio.CancelledError:
            logger.info(f"Price monitoring cancelled for order {order.master_order_id}")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error monitoring prices for order {order.master_order_id}: {e}")

    async def _check_bracket_conditions(self, order: AdvancedOrder, current_price: Decimal):
        """Check if bracket order conditions are met"""
        # Check take profit
        if (
            order.take_profit_order
            and order.take_profit_order.status == OrderStatus.PENDING
            and (
                (order.entry_order.side == OrderSide.BUY and current_price >= order.take_profit_order.price)
                or (order.entry_order.side == OrderSide.SELL and current_price <= order.take_profit_order.price)
            )
        ):
            success = await self._place_order_component(order.take_profit_order)
            if success:
                order.take_profit_order.status = OrderStatus.FILLED
                order.status = OrderStatus.FILLED
                # Cancel stop loss
                if order.stop_loss_order:
                    await self._cancel_order_component(order.stop_loss_order)
                logger.info(f"Take profit triggered for bracket order {order.master_order_id}")

        # Check stop loss
        elif (
            order.stop_loss_order
            and order.stop_loss_order.status == OrderStatus.PENDING
            and (
                (order.entry_order.side == OrderSide.BUY and current_price <= order.stop_loss_order.price)
                or (order.entry_order.side == OrderSide.SELL and current_price >= order.stop_loss_order.price)
            )
        ):
            success = await self._place_order_component(order.stop_loss_order)
            if success:
                order.stop_loss_order.status = OrderStatus.FILLED
                order.status = OrderStatus.FILLED
                # Cancel take profit
                if order.take_profit_order:
                    await self._cancel_order_component(order.take_profit_order)
                logger.info(f"Stop loss triggered for bracket order {order.master_order_id}")

    async def _update_trailing_stop(self, order: AdvancedOrder, current_price: Decimal):
        """Update trailing stop levels"""
        component = order.entry_order
        if not component or component.order_type != OrderType.TRAILING_STOP:
            return

        # Initialize activation if not set
        if component.activation_price is None:
            if component.side == OrderSide.BUY:
                component.activation_price = current_price * Decimal("1.001")  # 0.1% above
            else:
                component.activation_price = current_price * Decimal("0.999")  # 0.1% below
            return

        # Check if activated
        activated = (component.side == OrderSide.BUY and current_price >= component.activation_price) or (component.side == OrderSide.SELL and current_price <= component.activation_price)

        if not activated:
            return

        # Update trailing stop price
        if component.trail_percentage:
            if component.side == OrderSide.BUY:
                # Trail below the highest price seen
                if not hasattr(component, "_highest_price"):
                    component._highest_price = current_price
                else:
                    component._highest_price = max(component._highest_price, current_price)

                new_stop = component._highest_price * Decimal(1 - component.trail_percentage / 100)
                if not component.price or new_stop > component.price:
                    component.price = new_stop
                    logger.debug(f"Updated trailing stop to {new_stop} for order {order.master_order_id}")

            else:  # SELL side
                # Trail above the lowest price seen
                if not hasattr(component, "_lowest_price"):
                    component._lowest_price = current_price
                else:
                    component._lowest_price = min(component._lowest_price, current_price)

                new_stop = component._lowest_price * Decimal(1 + component.trail_percentage / 100)
                if not component.price or new_stop < component.price:
                    component.price = new_stop
                    logger.debug(f"Updated trailing stop to {new_stop} for order {order.master_order_id}")

        elif component.trail_amount:
            # Fixed amount trailing
            if component.side == OrderSide.BUY:
                if not hasattr(component, "_highest_price"):
                    component._highest_price = current_price
                else:
                    component._highest_price = max(component._highest_price, current_price)

                component.price = component._highest_price - component.trail_amount
            else:
                if not hasattr(component, "_lowest_price"):
                    component._lowest_price = current_price
                else:
                    component._lowest_price = min(component._lowest_price, current_price)

                component.price = component._lowest_price + component.trail_amount

    async def cancel_order(self, master_order_id: str) -> bool:
        """Cancel an advanced order and all its components"""
        order = self.active_orders.get(master_order_id)
        if not order:
            return False

        logger.info(f"Cancelling advanced order {master_order_id}")

        # Cancel monitoring task
        if master_order_id in self.price_monitoring_tasks:
            self.price_monitoring_tasks[master_order_id].cancel()
            del self.price_monitoring_tasks[master_order_id]

        # Cancel all components
        components = self._get_order_components(order)
        for component in components:
            if component.status in [
                OrderStatus.PENDING,
                OrderStatus.OPEN,
                OrderStatus.PARTIAL,
            ]:
                await self._cancel_order_component(component)
                component.status = OrderStatus.CANCELLED

        order.status = OrderStatus.CANCELLED
        logger.info(f"Advanced order {master_order_id} cancelled")
        return True

    def _get_order_components(self, order: AdvancedOrder) -> list[OrderComponent]:
        """Get all components of an order"""
        components = []
        if order.entry_order:
            components.append(order.entry_order)
        if order.stop_loss_order:
            components.append(order.stop_loss_order)
        if order.take_profit_order:
            components.append(order.take_profit_order)
        components.extend(order.iceberg_chunks)
        components.extend(order.oco_orders)
        return components

    async def _place_order_component(self, component: OrderComponent) -> bool:
        """Place an individual order component (mock implementation)"""
        try:
            # This would integrate with your actual trading API
            logger.info(f"Placing order: {component.order_id} {component.side.value} {component.quantity} {component.symbol} @ {component.price}")
            # Simulate successful order placement
            component.status = OrderStatus.OPEN
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Failed to place order {component.order_id}: {e}")
            return False
        else:
            return True

    async def _cancel_order_component(self, component: OrderComponent) -> bool:
        """Cancel an individual order component (mock implementation)"""
        try:
            logger.info(f"Cancelling order: {component.order_id}")
            component.status = OrderStatus.CANCELLED
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Failed to cancel order {component.order_id}: {e}")
            return False
        else:
            return True

    async def _get_current_price(self, symbol: str) -> Decimal:
        """Get current price for a symbol from live market data"""
        try:
            # Get price from live market data service
            market_service = MarketDataService.shared()

            # Try to get price synchronously or asynchronously
            if inspect.iscoroutinefunction(market_service.get_price):
                price_data = await market_service.get_price(symbol)
            else:
                price_data = market_service.get_price(symbol)

            if price_data and "price" in price_data:
                return Decimal(str(price_data["price"]))

            # If market data service fails, try cache
            cached_price = await canonical_cache.get_price(symbol)

            if cached_price:
                return Decimal(str(cached_price))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error getting current price for {symbol}: {e}")
            raise  # Re-raise to fail properly instead of returning fake data

        # If all fails, raise error - no fake prices (outside try to avoid TRY301)
        msg = f"Unable to get live price for {symbol}"
        raise ValueError(msg)

    def get_order_status(self, master_order_id: str) -> dict[str, Any] | None:
        """Get the status of an advanced order"""
        order = self.active_orders.get(master_order_id)
        if not order:
            return None

        components_status = []
        for component in self._get_order_components(order):
            components_status.append(
                {
                    "order_id": component.order_id,
                    "status": component.status.value,
                    "filled_quantity": float(component.filled_quantity),
                    "average_fill_price": float(component.average_fill_price) if component.average_fill_price else None,
                }
            )

        return {
            "master_order_id": order.master_order_id,
            "symbol": order.symbol,
            "strategy_type": order.strategy_type.value,
            "status": order.status.value,
            "components": components_status,
            "created_at": order.created_at,
            "updated_at": order.updated_at,
        }

    def get_user_orders(self, user_id: str) -> list[dict[str, Any]]:
        """Get all orders for a user"""
        user_orders = []
        for order in self.active_orders.values():
            if order.user_id == user_id:
                status = self.get_order_status(order.master_order_id)
                if status:
                    user_orders.append(status)
        return user_orders

    async def cleanup_expired_orders(self):
        """Clean up expired orders and completed monitoring tasks"""
        current_time = time.time()
        expired_threshold = 24 * 60 * 60  # 24 hours

        # Clean up old completed orders
        to_remove = []
        for order_id, order in self.active_orders.items():
            if order.status in [OrderStatus.FILLED, OrderStatus.CANCELLED, OrderStatus.FAILED] and current_time - order.updated_at > expired_threshold:
                to_remove.append(order_id)

        for order_id in to_remove:
            del self.active_orders[order_id]
            logger.info(f"Cleaned up expired order {order_id}")

        # Clean up monitoring tasks for completed orders
        for order_id in list(self.price_monitoring_tasks.keys()):
            if order_id not in self.active_orders:
                if not self.price_monitoring_tasks[order_id].done():
                    self.price_monitoring_tasks[order_id].cancel()
                del self.price_monitoring_tasks[order_id]


# Global order manager instance
advanced_order_manager = AdvancedOrderManager()


# Convenience functions
async def create_bracket_order(*args, **kwargs) -> str:
    """Create a bracket order"""
    return await advanced_order_manager.create_bracket_order(*args, **kwargs)


async def create_trailing_stop_order(*args, **kwargs) -> str:
    """Create a trailing stop order"""
    return await advanced_order_manager.create_trailing_stop_order(*args, **kwargs)


async def create_iceberg_order(*args, **kwargs) -> str:
    """Create an iceberg order"""
    return await advanced_order_manager.create_iceberg_order(*args, **kwargs)


async def execute_iceberg_order(order_id: str) -> bool:
    """Execute an iceberg order"""
    return await advanced_order_manager.execute_iceberg_order(order_id)


def get_order_status(order_id: str) -> dict[str, Any] | None:
    """Get order status"""
    return advanced_order_manager.get_order_status(order_id)


async def cancel_order(order_id: str) -> bool:
    """Cancel an order"""
    return await advanced_order_manager.cancel_order(order_id)
