#!/usr/bin/env python3
"""
Advanced Order Service (single-file, live-data friendly)

Features:
- Market, Limit, Stop-Loss(LIMIT), Take-Profit(LIMIT), Trailing Stop, OCO
- No fake/random pricing. Uses an async price_provider you set, or Redis feed if available.
- OCO linking (fills one -> cancels the other)
- Trailing stop with live-moving anchor + trigger
- Optional Redis persistence (active orders & history)
- Explicit, predictable state machine

How to feed prices (pick one):
  1) Provide an async price provider (recommended):
        svc = AdvancedOrderService()
        svc.set_price_provider(lambda sym: my_exchange_last(sym))  # async function returning float
  2) Or publish prices to Redis hashes like: HSET price:BTCUSDT last 62000 ts <epoch>
     The service will read from:
        HGET price:{SYMBOL} "last"  (fallback to "price" or simple GET price:{SYMBOL})

Background loop (optional):
  await svc.run_price_watcher()   # polls provider for monitored symbols every `price_check_interval` seconds

Or push-driven:
  await svc.process_price_updates("BTCUSDT", 62050.0)  # call on your own ticks
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any

try:
    import redis.asyncio as redis  # type: ignore[import-not-found]
except (ImportError, ModuleNotFoundError, AttributeError):  # pragma: no cover
    redis = None  # type: ignore[assignment]
from backend.config.redis_config import get_shared_redis_async
from backend.services.task_manager import task_manager

logger = logging.getLogger(__name__)

# =========================
# Enums & Datamodel
# =========================


class OrderType(Enum):
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    STOP_LOSS = "STOP_LOSS"
    TAKE_PROFIT = "TAKE_PROFIT"
    STOP_LOSS_LIMIT = "STOP_LOSS_LIMIT"
    TAKE_PROFIT_LIMIT = "TAKE_PROFIT_LIMIT"
    TRAILING_STOP = "TRAILING_STOP"
    OCO = "OCO"  # meta type (we implement with two linked child orders)


class OrderStatus(Enum):
    PENDING = "PENDING"
    FILLED = "FILLED"
    CANCELLED = "CANCELLED"
    REJECTED = "REJECTED"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    EXPIRED = "EXPIRED"


@dataclass
class AdvancedOrder:
    order_id: str
    symbol: str  # "BTCUSDT" form (exchange-native)
    side: str  # "BUY" or "SELL"
    order_type: OrderType
    quantity: float
    price: float | None = None  # limit / target price (for TAKE_PROFIT)
    stop_price: float | None = None  # trigger price (for STOP_LOSS / trailing)
    limit_price: float | None = None  # when *_LIMIT variants used
    status: OrderStatus = OrderStatus.PENDING
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    filled_at: datetime | None = None
    filled_price: float | None = None
    filled_quantity: float = 0.0
    remaining_quantity: float = 0.0

    # Advanced params
    trailing_stop_percentage: float | None = None  # e.g., 0.02 for 2%
    trailing_stop_amount: float | None = None  # e.g., 100.0 USD
    time_in_force: str = "GTC"  # or "GTD"
    expire_time: datetime | None = None

    # OCO linkage
    oco_orders: list[str] = field(default_factory=list)
    parent_order_id: str | None = None

    # Internal trailing state (anchor/trigger)
    _trail_anchor: float | None = None
    _trail_trigger: float | None = None

    def __post_init__(self):
        if self.remaining_quantity == 0.0:
            self.remaining_quantity = self.quantity


# =========================
# Service
# =========================

PriceProvider = Callable[[str], Awaitable[float]]  # async def(symbol)->float


class AdvancedOrderService:
    """Manages advanced order types against a *live* price feed."""

    def __init__(
        self,
        redis_url: str | None = None,
        price_check_interval: float = 1.0,
        order_timeout_sec: int = 3600,
        max_retries: int = 3,
    ) -> None:
        # All Live Data, No Fallback/Hardcoded Data
        if not redis_url:
            redis_url = os.getenv("REDIS_URL")
            if not redis_url:
                redis_host = os.getenv("REDIS_HOST")
                if not redis_host:
                    msg = "REDIS_URL or REDIS_HOST environment variable is required - no fallback/hardcoded Redis URL"
                    raise RuntimeError(msg)
                redis_port = os.getenv("REDIS_PORT", "6379")
                redis_db = os.getenv("REDIS_DB", "0")
                redis_url = f"redis://{redis_host}:{redis_port}/{redis_db}"
        self._redis_url = redis_url
        self.redis_client: redis.Redis | None = None  # type: ignore[assignment]
        self.active_orders: dict[str, AdvancedOrder] = {}
        self.order_history: list[AdvancedOrder] = []
        self.price_monitors: dict[str, list[str]] = {}
        self._lock = asyncio.Lock()

        self.price_check_interval = float(price_check_interval)
        self.max_retries = int(max_retries)
        self.order_timeout = int(order_timeout_sec)

        # price provider
        self._price_provider: PriceProvider | None = None

        # watcher
        self._watcher_task: asyncio.Task | None = None

        logger.info("AdvancedOrderService initialized (single-file)")

    # ------------- Infra -------------
    def set_price_provider(self, provider: PriceProvider) -> None:
        """Provide async price source: async def provider(symbol)->float"""
        self._price_provider = provider

    async def _get_redis(self):
        if self.redis_client is None and redis is not None:
            try:
                self.redis_client = get_shared_redis_async()
            except Exception as e:  # pragma: no cover
                logger.warning(f"Redis unavailable: {e}")
                self.redis_client = None
        return self.redis_client

    async def _persist_order(self, order: AdvancedOrder) -> None:
        """Best-effort persistence to Redis."""
        r = await self._get_redis()
        if not r:
            return
        try:
            key = f"order:{order.order_id}"
            await r.set(key, json.dumps(self._serialize_order(order)))
            await r.sadd("orders:active", order.order_id)
        except Exception as e:  # pragma: no cover
            logger.debug(f"Persist order fail: {e}")

    async def _persist_history(self, order: AdvancedOrder) -> None:
        r = await self._get_redis()
        if not r:
            return
        try:
            await r.srem("orders:active", order.order_id)
            await r.lpush("orders:history", json.dumps(self._serialize_order(order)))
            await r.ltrim("orders:history", 0, 9999)
        except Exception as e:  # pragma: no cover
            logger.debug(f"Persist history fail: {e}")

    # ------------- Price -------------
    async def _get_current_price(self, symbol: str) -> float:
        """Live price only. No random/simulated data."""
        # Prefer user-supplied provider
        if self._price_provider is not None:
            price = float(await self._price_provider(symbol))
            if price <= 0:
                msg = f"Non-positive price from provider for {symbol}"
                raise RuntimeError(msg)
            return price

        # Fallback to Redis market feed
        r = await self._get_redis()
        if r:
            for key, field_name in [
                (f"price:{symbol}", "last"),
                (f"price:{symbol}", "price"),
            ]:
                try:
                    val = await r.hget(key, field_name)
                    if val is not None:
                        p = float(val)
                        if p > 0:
                            return p
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    pass
            # simple GET price:SYMBOL
            try:
                val = await r.get(f"price:{symbol}")
                if val:
                    p = float(val)
                    if p > 0:
                        return p
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pass

        # If we reach here, there is no valid live source:
        msg = f"Live price unavailable for {symbol}"
        raise RuntimeError(msg)

    # ------------- Public API: place orders -------------

    async def place_market_order(self, symbol: str, side: str, quantity: float) -> dict[str, Any]:
        oid = self._oid("mkt")
        order = AdvancedOrder(
            order_id=oid,
            symbol=symbol.upper(),
            side=side.upper(),
            order_type=OrderType.MARKET,
            quantity=float(quantity),
        )
        await self._save_and_fill_market(order)
        return self._ok("Market order placed", order_id=oid, status=order.status.value)

    async def place_limit_order(
        self,
        symbol: str,
        side: str,
        quantity: float,
        price: float,
        time_in_force: str = "GTC",
        expire_in_sec: int | None = None,
    ) -> dict[str, Any]:
        oid = self._oid("lmt")
        order = AdvancedOrder(
            order_id=oid,
            symbol=symbol.upper(),
            side=side.upper(),
            order_type=OrderType.LIMIT,
            quantity=float(quantity),
            price=float(price),
            time_in_force=time_in_force,
            expire_time=(datetime.now(timezone.utc) + timedelta(seconds=int(expire_in_sec))) if expire_in_sec else None,
        )
        await self._save_and_monitor(order)
        return self._ok("Limit order placed", order_id=oid, status=order.status.value)

    async def place_stop_loss_order(
        self,
        symbol: str,
        side: str,
        quantity: float,
        stop_price: float,
        limit_price: float | None = None,
        time_in_force: str = "GTC",
    ) -> dict[str, Any]:
        oid = self._oid("stp")
        otype = OrderType.STOP_LOSS_LIMIT if limit_price is not None else OrderType.STOP_LOSS
        order = AdvancedOrder(
            order_id=oid,
            symbol=symbol.upper(),
            side=side.upper(),
            order_type=otype,
            quantity=float(quantity),
            stop_price=float(stop_price),
            limit_price=float(limit_price) if limit_price is not None else None,
            time_in_force=time_in_force,
        )
        await self._save_and_monitor(order)
        return self._ok("Stop-loss order placed", order_id=oid, status=order.status.value)

    async def place_take_profit_order(
        self,
        symbol: str,
        side: str,
        quantity: float,
        target_price: float,
        limit_price: float | None = None,
        time_in_force: str = "GTC",
    ) -> dict[str, Any]:
        oid = self._oid("tp")
        otype = OrderType.TAKE_PROFIT_LIMIT if limit_price is not None else OrderType.TAKE_PROFIT
        order = AdvancedOrder(
            order_id=oid,
            symbol=symbol.upper(),
            side=side.upper(),
            order_type=otype,
            quantity=float(quantity),
            price=float(target_price),
            limit_price=float(limit_price) if limit_price is not None else None,
            time_in_force=time_in_force,
        )
        await self._save_and_monitor(order)
        return self._ok("Take-profit order placed", order_id=oid, status=order.status.value)

    async def place_trailing_stop_order(
        self,
        symbol: str,
        side: str,
        quantity: float,
        trailing_percentage: float | None = None,
        trailing_amount: float | None = None,
        time_in_force: str = "GTC",
    ) -> dict[str, Any]:
        if trailing_percentage is None and trailing_amount is None:
            return self._err("Either trailing_percentage or trailing_amount must be specified")

        # Snapshot current to seed anchor & trigger
        current = await self._get_current_price(symbol.upper())
        oid = self._oid("trl")
        order = AdvancedOrder(
            order_id=oid,
            symbol=symbol.upper(),
            side=side.upper(),
            order_type=OrderType.TRAILING_STOP,
            quantity=float(quantity),
            trailing_stop_percentage=trailing_percentage,
            trailing_stop_amount=trailing_amount,
            time_in_force=time_in_force,
        )

        # initialize anchor/trigger
        self._reset_trailing_anchor(order, current)

        await self._save_and_monitor(order)
        return self._ok("Trailing stop order placed", order_id=oid, status=order.status.value)

    async def place_oco_order(
        self,
        symbol: str,
        side: str,
        quantity: float,
        stop_price: float,
        limit_price: float,
        time_in_force: str = "GTC",
    ) -> dict[str, Any]:
        # Create two linked children
        stop_id = self._oid("oco_stp")
        tp_id = self._oid("oco_tp")
        side = side.upper()
        symbol = symbol.upper()

        stop = AdvancedOrder(
            order_id=stop_id,
            symbol=symbol,
            side=side,
            order_type=OrderType.STOP_LOSS,
            quantity=float(quantity),
            stop_price=float(stop_price),
            parent_order_id="oco",
            oco_orders=[tp_id],
            time_in_force=time_in_force,
        )
        tp = AdvancedOrder(
            order_id=tp_id,
            symbol=symbol,
            side=side,
            order_type=OrderType.TAKE_PROFIT,
            quantity=float(quantity),
            price=float(limit_price),
            parent_order_id="oco",
            oco_orders=[stop_id],
            time_in_force=time_in_force,
        )

        async with self._lock:
            self.active_orders[stop_id] = stop
            self.active_orders[tp_id] = tp
            self._monitor_symbol(symbol, stop_id)
            self._monitor_symbol(symbol, tp_id)

        await self._persist_order(stop)
        await self._persist_order(tp)
        return {
            "success": True,
            "message": "OCO order placed",
            "status": "PENDING",
            "stop_order_id": stop_id,
            "profit_order_id": tp_id,
        }

    # ------------- Processing / Monitoring -------------

    async def process_price_updates(self, symbol: str, current_price: float) -> None:
        """Handle a live price tick for `symbol`."""
        async with self._lock:
            order_ids = list(self.price_monitors.get(symbol.upper(), []))
        for oid in order_ids:
            order = self.active_orders.get(oid)
            if not order or order.status is not OrderStatus.PENDING:
                continue
            # expiry check
            if order.expire_time and datetime.now(timezone.utc) >= order.expire_time:
                await self._expire_order(order)
                continue
            # trailing update (if applicable)
            if order.order_type is OrderType.TRAILING_STOP:
                self._update_trailing(order, current_price)

            # trigger eval
            if self._should_trigger(order, current_price):
                await self._execute_order(order, current_price)

    async def run_price_watcher(self) -> None:
        """
        Optional convenience watcher:
        Polls symbols via price_provider on an interval and drives processing.
        Requires set_price_provider(...) first.
        """
        if self._price_provider is None:
            msg = "Price provider not set"
            raise RuntimeError(msg)

        async def _loop():
            while True:
                try:
                    async with self._lock:
                        symbols = list(self.price_monitors.keys())
                    for s in symbols:
                        try:
                            px = float(await self._price_provider(s))
                            if px > 0:
                                await self.process_price_updates(s, px)
                        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                            logger.debug(f"Watcher price fetch failed for {s}: {e}")
                    await asyncio.sleep(self.price_check_interval)
                except asyncio.CancelledError:
                    break
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                    logger.exception(f"Watcher loop error: {e}")
                    await asyncio.sleep(self.price_check_interval)

        # run one watcher instance
        if self._watcher_task and not self._watcher_task.done():
            return
        self._watcher_task = await task_manager.create_task(_loop(), name="advanced_order_service:price_watcher")

    async def stop_price_watcher(self) -> None:
        t = self._watcher_task
        if t:
            t.cancel()
            with contextlib.suppress(Exception):  # type: ignore[misc]
                await t
        self._watcher_task = None

    # ------------- Query / Cancel -------------

    async def cancel_order(self, order_id: str) -> dict[str, Any]:
        async with self._lock:
            order = self.active_orders.get(order_id)
            if not order:
                return self._err("Order not found")
            if order.status is not OrderStatus.PENDING:
                return self._err("Order cannot be cancelled")
            order.status = OrderStatus.CANCELLED
            self._unmonitor_symbol(order.symbol, order_id)
            await self._persist_history(order)
        return self._ok("Order cancelled", order_id=order_id, status=order.status.value)

    async def get_orders(self, status: OrderStatus | None = None) -> list[dict[str, Any]]:
        async with self._lock:
            orders = [o for o in self.active_orders.values() if status is None or o.status is status]
            return [self._serialize_order(o) for o in orders]

    async def get_order_status(self, order_id: str) -> dict[str, Any]:
        async with self._lock:
            o = self.active_orders.get(order_id)
            if not o:
                return self._err("Order not found")
            return {
                "success": True,
                "order_id": order_id,
                "status": o.status.value,
                "filled_quantity": o.filled_quantity,
                "remaining_quantity": o.remaining_quantity,
                "filled_price": o.filled_price,
                "created_at": o.created_at.isoformat(),
                "filled_at": o.filled_at.isoformat() if o.filled_at else None,
            }

    # ------------- Internals -------------

    async def _save_and_fill_market(self, order: AdvancedOrder) -> None:
        async with self._lock:
            self.active_orders[order.order_id] = order
        # fill immediately at *live* price
        try:
            px = await self._get_current_price(order.symbol)
            await self._fill(order, px)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Market fill failed: {e}")
            order.status = OrderStatus.REJECTED
        await self._persist_order(order)
        if order.status is not OrderStatus.PENDING:
            await self._persist_history(order)

    async def _save_and_monitor(self, order: AdvancedOrder) -> None:
        async with self._lock:
            self.active_orders[order.order_id] = order
            self._monitor_symbol(order.symbol, order.order_id)
        await self._persist_order(order)

    def _monitor_symbol(self, symbol: str, order_id: str) -> None:
        arr = self.price_monitors.setdefault(symbol.upper(), [])
        if order_id not in arr:
            arr.append(order_id)

    def _unmonitor_symbol(self, symbol: str, order_id: str) -> None:
        arr = self.price_monitors.get(symbol.upper())
        if not arr:
            return
        if order_id in arr:
            arr.remove(order_id)
        if not arr:
            self.price_monitors.pop(symbol.upper(), None)

    async def _expire_order(self, order: AdvancedOrder) -> None:
        order.status = OrderStatus.EXPIRED
        self._unmonitor_symbol(order.symbol, order.order_id)
        await self._persist_history(order)

    def _should_trigger(self, order: AdvancedOrder, px: float) -> bool:
        side = order.side.upper()
        if order.order_type is OrderType.LIMIT:
            # Fill when price crosses limit in favorable direction
            return (side == "BUY" and px <= float(order.price)) or (side == "SELL" and px >= float(order.price))
        if order.order_type is OrderType.STOP_LOSS:
            # Trigger when price crosses stop in adverse direction
            return (side == "BUY" and px >= float(order.stop_price)) or (side == "SELL" and px <= float(order.stop_price))
        if order.order_type is OrderType.TAKE_PROFIT:
            # Trigger when price hits profit target
            return (side == "SELL" and px >= float(order.price)) or (side == "BUY" and px <= float(order.price))
        if order.order_type is OrderType.STOP_LOSS_LIMIT:
            return (side == "BUY" and px >= float(order.stop_price)) or (side == "SELL" and px <= float(order.stop_price))
        if order.order_type is OrderType.TAKE_PROFIT_LIMIT:
            return (side == "SELL" and px >= float(order.price)) or (side == "BUY" and px <= float(order.price))
        if order.order_type is OrderType.TRAILING_STOP:
            # Trigger when price crosses the dynamic trigger in adverse direction
            if order._trail_trigger is None:
                return False
            if side == "SELL":  # protect long: trigger when px <= trigger
                return px <= float(order._trail_trigger)
            # BUY (protect short): trigger when px >= trigger
            return px >= float(order._trail_trigger)
        return False

    async def _execute_order(self, order: AdvancedOrder, px: float) -> None:
        """
        For *_LIMIT triggers, we convert to a limit-fill decision:
          - If SELL and px >= limit_price -> fill @ px
          - If BUY and px <= limit_price  -> fill @ px
          - Else keep pending (not-crossed).
        """
        side = order.side.upper()

        # Convert *_LIMIT types into fill condition
        if order.order_type in (OrderType.STOP_LOSS_LIMIT, OrderType.TAKE_PROFIT_LIMIT):
            lp = float(order.limit_price or 0.0)
            if lp <= 0:
                # Defensive fallback - treat like market if limit missing (shouldn't happen)
                await self._fill(order, px)
            elif (side == "SELL" and px >= lp) or (side == "BUY" and px <= lp):
                await self._fill(order, px)
            else:
                # not yet fillable, leave pending
                return
        else:
            await self._fill(order, px)

        # handle OCO linkage (cancel sibling)
        if order.oco_orders:
            async with self._lock:
                for sib in order.oco_orders:
                    o = self.active_orders.get(sib)
                    if o and o.status is OrderStatus.PENDING:
                        o.status = OrderStatus.CANCELLED
                        self._unmonitor_symbol(o.symbol, o.order_id)
                        task = await task_manager.create_task(self._persist_history(o), name="advanced_order_service:persist_history")  # fire-and-forget
                        # Store task reference if class has task tracking
                        if hasattr(self, "_tasks"):
                            self._tasks.append(task)
                        elif not hasattr(self, "_tasks"):
                            self._tasks: list[asyncio.Task[Any]] = []
                            self._tasks.append(task)

        # stop monitoring this one
        self._unmonitor_symbol(order.symbol, order.order_id)
        await self._persist_history(order)

    async def _fill(self, order: AdvancedOrder, px: float) -> None:
        order.status = OrderStatus.FILLED
        order.filled_at = datetime.now(timezone.utc)
        order.filled_price = float(px)
        order.filled_quantity = order.quantity
        order.remaining_quantity = 0.0
        logger.info(f"Filled {order.order_type.value}: {order.symbol} {order.side} {order.quantity} @ {px:.8f}")

    def _reset_trailing_anchor(self, order: AdvancedOrder, current: float) -> None:
        """Initialize anchor and trigger based on side and trail config."""
        order._trail_anchor = float(current)
        if order.trailing_stop_percentage is not None:
            pct = float(order.trailing_stop_percentage)
            if order.side.upper() == "SELL":  # protect long -> trigger below anchor
                order._trail_trigger = order._trail_anchor * (1 - pct)
            else:  # BUY -> trigger above anchor
                order._trail_trigger = order._trail_anchor * (1 + pct)
        elif order.trailing_stop_amount is not None:
            amt = float(order.trailing_stop_amount)
            if order.side.upper() == "SELL":
                order._trail_trigger = order._trail_anchor - amt
            else:
                order._trail_trigger = order._trail_anchor + amt

    def _update_trailing(self, order: AdvancedOrder, current: float) -> None:
        """Move anchor (and trigger) only in favorable direction."""
        if order._trail_anchor is None:
            self._reset_trailing_anchor(order, current)
            return

        cur = float(current)
        side = order.side.upper()

        if side == "SELL":
            # Favorable = rising price: move anchor up; trigger follows
            if cur > order._trail_anchor:
                order._trail_anchor = cur
                if order.trailing_stop_percentage is not None:
                    pct = float(order.trailing_stop_percentage)
                    order._trail_trigger = order._trail_anchor * (1 - pct)
                elif order.trailing_stop_amount is not None:
                    amt = float(order.trailing_stop_amount)
                    order._trail_trigger = order._trail_anchor - amt
        # BUY: Favorable = falling price: move anchor down; trigger follows
        elif cur < order._trail_anchor:
            order._trail_anchor = cur
            if order.trailing_stop_percentage is not None:
                pct = float(order.trailing_stop_percentage)
                order._trail_trigger = order._trail_anchor * (1 + pct)
            elif order.trailing_stop_amount is not None:
                amt = float(order.trailing_stop_amount)
                order._trail_trigger = order._trail_anchor + amt

    # ------------- Helpers -------------

    def _oid(self, prefix: str) -> str:
        # millisecond timestamp to avoid collisions
        return f"{prefix}_{int(datetime.now(timezone.utc).timestamp() * 1000)}"

    def _serialize_order(self, o: AdvancedOrder) -> dict[str, Any]:
        return {
            "order_id": o.order_id,
            "symbol": o.symbol,
            "side": o.side,
            "order_type": o.order_type.value,
            "quantity": o.quantity,
            "price": o.price,
            "stop_price": o.stop_price,
            "limit_price": o.limit_price,
            "status": o.status.value,
            "created_at": o.created_at.isoformat(),
            "filled_at": o.filled_at.isoformat() if o.filled_at else None,
            "filled_price": o.filled_price,
            "filled_quantity": o.filled_quantity,
            "remaining_quantity": o.remaining_quantity,
            "trailing_stop_percentage": o.trailing_stop_percentage,
            "trailing_stop_amount": o.trailing_stop_amount,
            "time_in_force": o.time_in_force,
            "expire_time": o.expire_time.isoformat() if o.expire_time else None,
            "oco_orders": o.oco_orders,
            "parent_order_id": o.parent_order_id,
            "trail_anchor": o._trail_anchor,
            "trail_trigger": o._trail_trigger,
        }

    def _ok(self, message: str, **extra: Any) -> dict[str, Any]:
        out = {"success": True, "message": message}
        out.update(extra)
        return out

    def _err(self, message: str, **extra: Any) -> dict[str, Any]:
        out = {"success": False, "error": message}
        out.update(extra)
        return out
