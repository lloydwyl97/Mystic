"""
Advanced Risk Management Service with Kelly Criterion
Optimized for $1/minute profit goal with dynamic position sizing
"""

import logging
import math
import sqlite3
from datetime import datetime, timezone
from typing import Any

import numpy as np
import pandas as pd

from backend.database_schema import DATABASE_PATH

logger = logging.getLogger(__name__)


def _load_portfolio_value_from_ledger() -> tuple[float, float]:
    """Read current portfolio value and peak from portfolio_engine_ledger (live data). Returns (portfolio_value, peak)."""
    try:
        conn = sqlite3.connect(DATABASE_PATH)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='portfolio_engine_ledger'")
            if not cursor.fetchone():
                return (0.0, 0.0)
            cursor.execute("SELECT total_equity, principal FROM portfolio_engine_ledger WHERE id=1")
            row = cursor.fetchone()
            if row and (row[0] is not None or row[1] is not None):
                val = float(row[0]) if row[0] is not None else float(row[1])
                if val < 0:
                    val = 0.0
                return (val, val)
        finally:
            conn.close()
    except Exception as e:
        logger.debug("Ledger read for risk manager failed: %s", e)
    return (0.0, 0.0)


# Risk management constants
MAX_POSITION_SIZE = 0.05  # 5% max position size
MIN_POSITION_SIZE = 0.001  # 0.1% min position size
KELLY_FRACTION_MAX = 0.25  # Max 25% of account per trade
KELLY_FRACTION_MIN = 0.01  # Min 1% of account per trade
DEFAULT_AVG_WIN = 0.01  # Default average win (1%)
DEFAULT_AVG_LOSS = 0.01  # Default average loss (1%)
LOW_VOLATILITY_THRESHOLD = 0.01  # Low volatility threshold for position sizing


class AdvancedRiskManager:
    """
    Advanced risk management with Kelly Criterion for optimal position sizing
    """

    def __init__(self) -> None:
        # Risk parameters
        self.max_portfolio_risk = 0.02  # 2% max portfolio risk per trade
        self.max_position_size = MAX_POSITION_SIZE  # 5% max position size
        self.min_position_size = MIN_POSITION_SIZE  # 0.1% min position size

        # Kelly Criterion parameters
        self.kelly_fraction_max = KELLY_FRACTION_MAX  # Max 25% of account per trade
        self.kelly_fraction_min = KELLY_FRACTION_MIN  # Min 1% of account per trade

        # Performance tracking
        self.trade_history: list[dict[str, Any]] = []
        self.performance_metrics = {
            "total_trades": 0,
            "winning_trades": 0,
            "losing_trades": 0,
            "total_profit": 0.0,
            "total_loss": 0.0,
            "win_rate": 0.0,
            "avg_win": 0.0,
            "avg_loss": 0.0,
            "profit_factor": 0.0,
            "sharpe_ratio": 0.0,
            "max_drawdown": 0.0,
            "current_drawdown": 0.0,
        }

        # Portfolio state (from canonical ledger; no hardcoded default)
        self.portfolio_value, self.peak_portfolio_value = _load_portfolio_value_from_ledger()
        self.current_positions: dict[str, dict[str, Any]] = {}

        # Risk limits
        self.daily_loss_limit = 0.05  # 5% daily loss limit
        self.weekly_loss_limit = 0.15  # 15% weekly loss limit
        self.max_concurrent_positions = 10

        # Volatility tracking
        self.volatility_window = 20
        self.symbol_volatility: dict[str, float] = {}

    async def calculate_optimal_position_size(
        self,
        symbol: str,
        signal_confidence: float,
        account_balance: float,
        current_price: float,
        stop_loss_price: float | None = None,
    ) -> dict[str, Any]:
        """
        Calculate optimal position size using Kelly Criterion and risk management
        """
        try:
            # Get historical performance for this symbol
            symbol_performance = await self._get_symbol_performance(symbol)

            # Calculate Kelly Criterion
            kelly_size = self._calculate_kelly_criterion(symbol_performance, signal_confidence, account_balance)

            # Apply risk management constraints
            risk_adjusted_size = self._apply_risk_constraints(kelly_size, account_balance, symbol, current_price, stop_loss_price)

            # Calculate position metrics
            position_value = risk_adjusted_size * account_balance
            shares = position_value / current_price if current_price > 0 else 0

            return {
                "position_size": risk_adjusted_size,
                "position_value": position_value,
                "shares": shares,
                "kelly_size": kelly_size,
                "risk_adjusted": True,
                "confidence": signal_confidence,
                "symbol": symbol,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error calculating position size for {symbol}: {e}")
            return {
                "position_size": self.min_position_size,
                "position_value": self.min_position_size * account_balance,
                "shares": (self.min_position_size * account_balance) / current_price if current_price > 0 else 0,
                "kelly_size": 0.0,
                "risk_adjusted": False,
                "confidence": signal_confidence,
                "symbol": symbol,
                "error": str(e),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

    def _calculate_kelly_criterion(self, performance: dict[str, Any], confidence: float, _account_balance: float) -> float:
        """
        Calculate Kelly Criterion for optimal position sizing
        """
        try:
            win_rate = performance.get("win_rate", 0.5)
            avg_win = performance.get("avg_win", DEFAULT_AVG_WIN)
            avg_loss = performance.get("avg_loss", DEFAULT_AVG_LOSS)

            if avg_loss == 0:
                return self.kelly_fraction_min

            # Kelly formula: f = (bp - q) / b
            # where b = avg_win/avg_loss, p = win_rate, q = 1 - win_rate
            b = avg_win / avg_loss
            p = win_rate
            q = 1 - win_rate

            kelly_fraction = (b * p - q) / b

            # Apply confidence multiplier
            kelly_fraction *= confidence

            # Apply bounds
            return max(self.kelly_fraction_min, min(kelly_fraction, self.kelly_fraction_max))

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error calculating Kelly Criterion: {e}")
            return self.kelly_fraction_min

    def _apply_risk_constraints(
        self,
        kelly_size: float,
        _account_balance: float,
        symbol: str,
        current_price: float,
        stop_loss_price: float | None = None,
    ) -> float:
        """
        Apply risk management constraints to position size
        """
        try:
            # Start with Kelly size
            position_size = kelly_size

            # Constraint 1: Maximum position size
            position_size = min(position_size, self.max_position_size)

            # Constraint 2: Minimum position size
            position_size = max(position_size, self.min_position_size)

            # Constraint 3: Portfolio risk limit
            if stop_loss_price and current_price > 0:
                risk_per_share = abs(current_price - stop_loss_price) / current_price
                max_risk_size = self.max_portfolio_risk / risk_per_share
                position_size = min(position_size, max_risk_size)

            # Constraint 4: Volatility adjustment (only when we have a measured vol for this symbol)
            if symbol in self.symbol_volatility:
                volatility = self.symbol_volatility[symbol]
                if volatility > 0.05:  # High volatility
                    position_size *= 0.7  # Reduce position size
                elif volatility < LOW_VOLATILITY_THRESHOLD:  # Low volatility
                    position_size *= 1.2  # Increase position size

            # Constraint 5: Current drawdown adjustment
            if self.performance_metrics["current_drawdown"] > 0.02:  # 2% drawdown
                position_size *= 0.5  # Reduce position size by 50%

            # Constraint 6: Number of concurrent positions
            if len(self.current_positions) >= self.max_concurrent_positions:
                position_size *= 0.8  # Reduce position size
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error applying risk constraints: {e}")
            return self.min_position_size
        else:
            return position_size

    async def _get_symbol_performance(self, symbol: str) -> dict[str, Any]:
        """
        Get historical performance metrics for a symbol
        """
        try:
            # Filter trades for this symbol
            symbol_trades = [t for t in self.trade_history if t.get("symbol") == symbol]

            if not symbol_trades:
                # Return default performance if no trades
                return {
                    "win_rate": 0.5,
                    "avg_win": DEFAULT_AVG_WIN,
                    "avg_loss": DEFAULT_AVG_LOSS,
                    "total_trades": 0,
                    "profit_factor": 1.0,
                }

            # Calculate performance metrics
            winning_trades = [t for t in symbol_trades if t.get("pnl", 0) > 0]
            losing_trades = [t for t in symbol_trades if t.get("pnl", 0) < 0]

            win_rate = len(winning_trades) / len(symbol_trades) if symbol_trades else 0.5
            avg_win = np.mean([t["pnl"] for t in winning_trades]) if winning_trades else DEFAULT_AVG_WIN
            avg_loss = abs(np.mean([t["pnl"] for t in losing_trades])) if losing_trades else DEFAULT_AVG_LOSS

            total_profit = sum(t["pnl"] for t in winning_trades)
            total_loss = abs(sum(t["pnl"] for t in losing_trades))
            profit_factor = total_profit / total_loss if total_loss > 0 else 1.0

            return {
                "win_rate": win_rate,
                "avg_win": avg_win,
                "avg_loss": avg_loss,
                "total_trades": len(symbol_trades),
                "profit_factor": profit_factor,
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error getting symbol performance for {symbol}: {e}")
            return {
                "win_rate": 0.5,
                "avg_win": DEFAULT_AVG_WIN,
                "avg_loss": DEFAULT_AVG_LOSS,
                "total_trades": 0,
                "profit_factor": 1.0,
            }

    async def record_trade(
        self,
        symbol: str,
        side: str,
        quantity: float,
        price: float,
        pnl: float,
        timestamp: str | None = None,
    ) -> None:
        """
        Record a completed trade for performance tracking
        """
        try:
            trade_record = {
                "symbol": symbol,
                "side": side,
                "quantity": quantity,
                "price": price,
                "pnl": pnl,
                "timestamp": timestamp or datetime.now(timezone.utc).isoformat(),
            }

            self.trade_history.append(trade_record)

            # Update performance metrics
            await self._update_performance_metrics()

            # Update portfolio value
            self.portfolio_value += pnl
            self.peak_portfolio_value = max(self.peak_portfolio_value, self.portfolio_value)

            # Calculate current drawdown
            peak = self.peak_portfolio_value
            self.performance_metrics["current_drawdown"] = (peak - self.portfolio_value) / peak if peak > 0 else 0.0

            logger.info(f"Trade recorded: {symbol} {side} {quantity} @ {price}, PnL: {pnl:.2f}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error recording trade: {e}")

    async def _update_performance_metrics(self) -> None:
        """
        Update performance metrics based on trade history
        """
        try:
            if not self.trade_history:
                return

            # Calculate basic metrics
            total_trades = len(self.trade_history)
            winning_trades = [t for t in self.trade_history if t.get("pnl", 0) > 0]
            losing_trades = [t for t in self.trade_history if t.get("pnl", 0) < 0]

            win_rate = len(winning_trades) / total_trades if total_trades > 0 else 0
            avg_win = np.mean([t["pnl"] for t in winning_trades]) if winning_trades else 0
            avg_loss = abs(np.mean([t["pnl"] for t in losing_trades])) if losing_trades else 0

            total_profit = sum(t["pnl"] for t in winning_trades)
            total_loss = abs(sum(t["pnl"] for t in losing_trades))
            profit_factor = total_profit / total_loss if total_loss > 0 else 0

            # Calculate Sharpe ratio (simplified)
            returns = [t["pnl"] for t in self.trade_history]
            sharpe_ratio = (np.mean(returns) / np.std(returns) if np.std(returns) > 0 else 0) if len(returns) > 1 else 0

            # Update metrics
            self.performance_metrics.update(
                {
                    "total_trades": total_trades,
                    "winning_trades": len(winning_trades),
                    "losing_trades": len(losing_trades),
                    "total_profit": total_profit,
                    "total_loss": total_loss,
                    "win_rate": win_rate,
                    "avg_win": avg_win,
                    "avg_loss": avg_loss,
                    "profit_factor": profit_factor,
                    "sharpe_ratio": sharpe_ratio,
                    "max_drawdown": max(
                        self.performance_metrics["max_drawdown"],
                        self.performance_metrics["current_drawdown"],
                    ),
                },
            )

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error updating performance metrics: {e}")

    async def check_risk_limits(self) -> dict[str, Any]:
        """
        Check if current portfolio is within risk limits
        """
        try:
            # Check daily loss limit
            daily_pnl = sum(t["pnl"] for t in self.trade_history if datetime.fromisoformat(t["timestamp"]).date() == datetime.now(timezone.utc).date())
            daily_loss_pct = (-daily_pnl / self.portfolio_value) if (self.portfolio_value > 0 and daily_pnl < 0) else 0

            # Check weekly loss limit
            week_ago = datetime.now(timezone.utc) - pd.Timedelta(days=7)
            weekly_pnl = sum(t["pnl"] for t in self.trade_history if datetime.fromisoformat(t["timestamp"]) >= week_ago)
            weekly_loss_pct = (-weekly_pnl / self.portfolio_value) if (self.portfolio_value > 0 and weekly_pnl < 0) else 0

            # Check current drawdown
            current_drawdown_pct = self.performance_metrics["current_drawdown"]

            # Determine if limits are exceeded
            daily_limit_exceeded = daily_loss_pct > self.daily_loss_limit
            weekly_limit_exceeded = weekly_loss_pct > self.weekly_loss_limit
            drawdown_limit_exceeded = current_drawdown_pct > 0.1  # 10% drawdown limit

            return {
                "daily_loss_pct": daily_loss_pct,
                "weekly_loss_pct": weekly_loss_pct,
                "current_drawdown_pct": current_drawdown_pct,
                "daily_limit_exceeded": daily_limit_exceeded,
                "weekly_limit_exceeded": weekly_limit_exceeded,
                "drawdown_limit_exceeded": drawdown_limit_exceeded,
                "trading_allowed": not (daily_limit_exceeded or weekly_limit_exceeded or drawdown_limit_exceeded),
                "portfolio_value": self.portfolio_value,
                "peak_portfolio_value": self.peak_portfolio_value,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error checking risk limits: {e}")
            return {
                "error": str(e),
                "trading_allowed": False,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

    async def update_volatility(self, symbol: str, prices: list[float]) -> None:
        """
        Update volatility estimate for a symbol
        """
        try:
            if len(prices) < 2:
                return

            # Calculate rolling volatility
            returns = pd.Series(prices).pct_change().dropna()
            volatility = returns.std() * math.sqrt(252)  # Annualized volatility

            self.symbol_volatility[symbol] = volatility

            logger.debug(f"Updated volatility for {symbol}: {volatility:.4f}")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error updating volatility for {symbol}: {e}")

    async def get_risk_report(self) -> dict[str, Any]:
        """
        Get comprehensive risk management report
        """
        try:
            risk_limits = await self.check_risk_limits()

            return {
                "performance_metrics": self.performance_metrics,
                "risk_limits": risk_limits,
                "current_positions": len(self.current_positions),
                "symbol_volatility": self.symbol_volatility,
                "portfolio_value": self.portfolio_value,
                "peak_portfolio_value": self.peak_portfolio_value,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error generating risk report: {e}")
            return {
                "error": str(e),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }


# Global instance
advanced_risk_manager = AdvancedRiskManager()
