"""
Advanced Trading Service (single-file)

Purpose
-------
Production-safe orchestration for advanced trading strategies, with **no fake data**.
This module wires together:
  - Strategy lifecycle (start/stop/status)
  - Live market context (from cache/Redis or optional providers)
  - Optional signal + order-routing hooks (lazy imports to avoid cycles)
  - Risk telemetry (from Redis keys if present)
  - Robust logging + graceful degradation when a dependency is unavailable

It does **not** fabricate numbers. If live data is missing/unavailable, it returns a
clear degraded state or empty arrays.

Quick usage
-----------
    svc = AdvancedTradingService()
    await svc.refresh_trading_pairs()                 # hydrate from env/redis if possible
    status = await svc.get_strategy_status()
    sid_res = await svc.start_strategy("mean_reversion", "BTCUSDT", {"lookback": 50})
    await svc.stop_strategy(sid_res["strategy_id"])

Integrations (optional, lazy)
-----------------------------
- Price cache / Redis:
    REDIS_URL (default: redis://localhost:6379/0)
    - Current/last price read from: HGET price:{SYMBOL} last  (fall back: "price")
    - Optional hist list: LRANGE price_hist:{SYMBOL} -N -1  (floats, newest last)

- AI signal scorer (if available):
    from backend.modules.ai.ai_signals import signal_scorer
    - Uses: await signal_scorer.get_live_signals_for_dashboard() or .generate_live_signal()

- Order service (if available):
    from backend.services.advanced_order_service import AdvancedOrderService
    - Place with: await order_svc.place_market_order(...), etc.

Everything is lazy-imported inside methods, so you can drop this file into most codebases
without creating import cycles.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import time

# Optional imports - try at top level
try:
    from backend.modules.ai.ai_signals import signal_scorer  # type: ignore[import-not-found]
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    signal_scorer = None

from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from backend.services.task_manager import task_manager

try:
    import redis.asyncio as redis  # type: ignore[import-not-found]
except (ImportError, ModuleNotFoundError, AttributeError):  # pragma: no cover
    redis = None  # type: ignore[assignment]
from backend.config.redis_config import get_shared_redis_async

logger = logging.getLogger(__name__)

# ---------------------------
# Data models
# ---------------------------


@dataclass
class StrategyState:
    strategy_id: str
    name: str
    symbol: str  # canonical exchange symbol, e.g., "BTCUSDT"
    params: dict[str, Any] = field(default_factory=dict)
    status: str = "active"  # "active" | "stopped" | "degraded" | "error"
    started_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    last_eval_ts: float | None = None
    last_message: str | None = None
    metrics: dict[str, Any] = field(default_factory=dict)


# ---------------------------
# Service
# ---------------------------

PriceProvider = Callable[[str], Awaitable[float]]  # async def(symbol)->float


class AdvancedTradingService:
    def __init__(self) -> None:
        # All Live Data, No Fallback/Hardcoded Data
        redis_url = os.getenv("REDIS_URL")
        if not redis_url:
            redis_host = os.getenv("REDIS_HOST")
            if not redis_host:
                msg = "REDIS_URL or REDIS_HOST environment variable is required - no fallback/hardcoded Redis URL"
                raise RuntimeError(msg)
            redis_port = os.getenv("REDIS_PORT", "6379")
            redis_db = os.getenv("REDIS_DB", "0")
            redis_url = f"redis://{redis_host}:{redis_port}/{redis_db}"
        self._redis_url = redis_url
        self._r: redis.Redis | None = None  # type: ignore[assignment]
        self._price_provider: PriceProvider | None = None

        self.active_strategies: dict[str, StrategyState] = {}
        self._tasks: dict[str, asyncio.Task] = {}
        self.trading_pairs: list[str] = []
        self._lock = asyncio.Lock()

        logger.info("AdvancedTradingService initialized")

    # ---------------------------
    # Wiring / Providers
    # ---------------------------

    def set_price_provider(self, provider: PriceProvider) -> None:
        """Inject an async price source: async def provider(symbol)->float"""
        self._price_provider = provider

    async def _redis(self):
        if self._r is None and redis is not None:
            try:
                self._r = get_shared_redis_async()
            except Exception as e:  # pragma: no cover
                logger.warning(f"Redis unavailable: {e}")
                self._r = None
        return self._r

    # ---------------------------
    # Public API
    # ---------------------------

    async def get_strategy_status(self) -> dict[str, Any]:
        """Summarize strategy status + available trading pairs."""
        async with self._lock:
            items = [
                {
                    "strategy_id": s.strategy_id,
                    "name": s.name,
                    "symbol": s.symbol,
                    "status": s.status,
                    "started_at": s.started_at,
                    "last_eval_ts": s.last_eval_ts,
                    "last_message": s.last_message,
                    "metrics": s.metrics,
                }
                for s in self.active_strategies.values()
            ]
        return {
            "active_strategies": len(items),
            "strategies": items,
            "trading_pairs": self.trading_pairs,
            "status": "operational",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    async def refresh_trading_pairs(self) -> list[str]:
        """
        Populate trading pairs. Prefers:
          1) env TOP_SYMBOLS (comma list of "BTCUSDT,ETHUSDT,...")
          2) Redis keys price:* (if present)
        """
        pairs: list[str] = []
        env_syms = os.getenv("TOP_SYMBOLS")
        if env_syms:
            pairs = [s.strip().upper().replace("-USD", "USDT").replace("/", "") for s in env_syms.split(",") if s.strip()]
        if not pairs:
            r = await self._redis()
            if r:
                try:
                    # Caution: KEYS can be expensive; acceptable for small footprints.
                    keys = []
                    async for k in r.scan_iter(match="price:*", count=100):
                        keys.append(k)
                    for k in keys:
                        _, sym = k.split(":", 1)
                        pairs.append(sym.strip().upper().replace("-USD", "USDT").replace("/", ""))
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    pass

        # de-dupe & limit
        seen = set()
        out: list[str] = []
        for p in pairs:
            if p and p not in seen:
                seen.add(p)
                out.append(p)
        if out:
            self.trading_pairs = out
        return self.trading_pairs

    async def start_strategy(self, strategy_name: str, pair: str, params: dict[str, Any]) -> dict[str, Any]:
        """
        Start (or resume) a strategy runner.
        Live-only: if data sources are unavailable, status becomes 'degraded' and we do *not*
        fabricate anything — the runner keeps trying until sources become available.
        """
        try:
            symbol = self._to_canonical_symbol(pair)
            sid = f"{strategy_name}_{symbol}_{int(time.time() * 1000)}"
            state = StrategyState(
                strategy_id=sid,
                name=strategy_name,
                symbol=symbol,
                params=params,
                status="active",
            )

            async with self._lock:
                self.active_strategies[sid] = state
                # kick off background loop
                self._tasks[sid] = await task_manager.create_task(self._run_strategy_loop(state), name="advanced_trading:run_strategy_loop")

            logger.info(f"[OK] Started strategy: {strategy_name} on {symbol}")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Error starting strategy: {e}")
            return {"success": False, "error": str(e)}
        else:
            return {"success": True, "strategy_id": sid}

    async def stop_strategy(self, strategy_id: str) -> dict[str, Any]:
        """Stop a strategy and cancel its loop."""
        try:
            async with self._lock:
                st = self.active_strategies.get(strategy_id)
                if not st:
                    return {"success": False, "error": "Strategy not found"}
                st.status = "stopped"
                t = self._tasks.pop(strategy_id, None)
            if t:
                t.cancel()
                with contextlib.suppress(ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    await t
            logger.info(f"[OK] Stopped strategy: {strategy_id}")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Error stopping strategy: {e}")
            return {"success": False, "error": str(e)}
        else:
            return {"success": True}

    async def get_market_analysis(self, pair: str) -> dict[str, Any]:
        """
        Live-only market snapshot for a symbol.
        Uses (in order):
            - injected price_provider
            - Redis price:{SYMBOL} fields (last, change_24h) & optional price_hist:{SYMBOL}
        No fake data; if insufficient, returns 'degraded'.
        """
        try:
            symbol = self._to_canonical_symbol(pair)
            current = await self._get_price(symbol)
            if current is None:
                return {
                    "pair": symbol,
                    "status": "degraded",
                    "reason": "price_unavailable",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

            change_24h = await self._get_change_24h(symbol)
            trend = "bullish" if (change_24h is not None and change_24h > 0) else ("bearish" if (change_24h is not None and change_24h < 0) else "neutral")

            # Support/resistance from redis history if present
            support = resistance = None
            hist = await self._get_history(symbol, limit=200)
            if hist:
                try:
                    # very light-weight bounds
                    support = min(hist)
                    resistance = max(hist)
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    pass

            return {
                "pair": symbol,
                "current_price": current,
                "trend": trend,
                "change_24h_pct": change_24h,
                "support": support,
                "resistance": resistance,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "source": "live_cache",
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Error getting market analysis: {e}")
            return {"error": str(e), "status": "error"}

    async def get_risk_metrics(self) -> dict[str, Any]:
        """
        Live risk telemetry (no fabrication). Reads from Redis if present:
          - risk:pnl:today
          - risk:dd:today
          - risk:volatility (optional)
        Missing keys are treated as 0 / None, which is accurate when not tracked.
        """
        try:
            r = await self._redis()
            if not r:
                return {
                    "total_exposure": None,
                    "max_drawdown": None,
                    "sharpe_ratio": None,
                    "volatility": None,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "source": "degraded:no_redis",
                }

            # global risk scalars
            pnl_today = float(await r.get("risk:pnl:today") or 0.0)
            dd_today = float(await r.get("risk:dd:today") or 0.0)
            vol = await r.get("risk:volatility")
            volatility = float(vol) if vol is not None else None

            return {
                "pnl_today": round(pnl_today, 4),
                "drawdown_today": round(dd_today, 4),
                "volatility": volatility,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "source": "redis",
            }
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Error getting risk metrics: {e}")
            return {"error": str(e), "status": "error"}

    # ---------------------------
    # Strategy loop (live-only)
    # ---------------------------

    async def _run_strategy_loop(self, state: StrategyState) -> None:
        """
        Minimal strategy loop:
          - Pull a live price
          - (Optionally) fetch a live signal if available
          - (Optionally) place orders via order service if enabled in params
        If any live dependency is missing, we set 'degraded' and retry quietly.
        """
        interval = float(state.params.get("interval_sec", 5.0))
        place_orders = bool(state.params.get("place_orders", False))
        symbol = state.symbol

        order_svc = None
        if place_orders:
            order_svc = await self._maybe_get_order_service()

        while True:
            try:
                # Check stopped/paused
                if state.status == "stopped":
                    return

                # 1) Live price
                price = await self._get_price(symbol)
                if price is None:
                    await self._mark_degraded(state, "price_unavailable")
                    await asyncio.sleep(interval)
                    continue

                # 2) Optional live signal
                signal = await self._maybe_get_live_signal(symbol)
                state.metrics["last_price"] = price
                state.metrics["last_signal"] = signal
                state.last_eval_ts = time.time()
                state.status = "active"
                state.last_message = "ok"

                # 3) Optional basic execution (example: act only on high-confidence BUY/SELL)
                if place_orders and order_svc and signal:
                    action = str(signal.get("action", "")).lower()
                    from backend.services.confidence_normalizer import ConfidenceNormalizer

                    raw_conf = signal.get("confidence", 0) or 0
                    conf = ConfidenceNormalizer.normalize(float(raw_conf) if raw_conf is not None else 0.0)
                    min_conf = float(state.params.get("min_confidence", 0.8))
                    qty = float(state.params.get("quantity", 0.0) or 0.0)

                    if qty > 0 and conf >= min_conf and action in {"buy", "sell"}:
                        side = "BUY" if action == "buy" else "SELL"
                        try:
                            res = await order_svc.place_market_order(symbol, side, qty)
                            state.last_message = f"order:{res.get('status', 'unknown')}"
                        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as oe:
                            logger.warning(f"Order placement failed: {oe}")
                            state.last_message = "order_failed"

                await asyncio.sleep(interval)

            except asyncio.CancelledError:
                return
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                logger.exception(f"Strategy loop error ({state.strategy_id}): {e}")
                await self._mark_degraded(state, "loop_error")
                await asyncio.sleep(interval)

    async def _mark_degraded(self, state: StrategyState, reason: str) -> None:
        state.status = "degraded"
        state.last_message = reason
        state.last_eval_ts = time.time()

    # ---------------------------
    # Live data helpers
    # ---------------------------

    async def _get_price(self, symbol: str) -> float | None:
        # Prefer injected provider
        if self._price_provider is not None:
            try:
                p = float(await self._price_provider(symbol))
                if p > 0:
                    return p
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                pass

        # Redis cache
        r = await self._redis()
        if r:
            for field_name in ("last", "price"):
                try:
                    v = await r.hget(f"price:{symbol}", field_name)
                    if v is not None:
                        p = float(v)
                        if p > 0:
                            return p
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    continue
        return None

    async def _get_change_24h(self, symbol: str) -> float | None:
        r = await self._redis()
        if not r:
            return None
        try:
            v = await r.hget(f"price:{symbol}", "change_24h")
            return float(v) if v is not None else None
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            return None

    async def _get_history(self, symbol: str, limit: int = 200) -> list[float]:
        r = await self._redis()
        if not r:
            return []
        try:
            raw = await r.lrange(f"price_hist:{symbol}", -int(abs(limit)), -1)
            out: list[float] = []
            for s in raw or []:
                try:
                    out.append(float(s))
                except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                    continue
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            return []
        else:
            return out

    # ---------------------------
    # Optional integrations
    # ---------------------------

    async def _maybe_get_live_signal(self, symbol: str) -> dict[str, Any] | None:
        """
        Attempt to fetch a *live* signal without fabricating anything.
        Tries AI signal scorer first; if unavailable, returns None.
        """
        if signal_scorer is None:
            return None

        try:
            # Prefer dashboard batch getter if present
            if hasattr(signal_scorer, "get_live_signals_for_dashboard"):
                items = await signal_scorer.get_live_signals_for_dashboard()
                # expect list of dicts with 'symbol' / 'action' / 'confidence' etc.
                sym = symbol.replace("USDT", "/USDT")
                for it in items or []:
                    if str(it.get("symbol", "")).upper().replace("-USD", "/USDT") == sym:
                        return it
                return None
            # fallback: single signal
            if hasattr(signal_scorer, "generate_live_signal"):
                return await signal_scorer.generate_live_signal()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            pass
        return None

    async def _maybe_get_order_service(self):
        """
        Try to obtain an AdvancedOrderService instance if available.
        Expect either import path:
          - backend.services.advanced_order_service.AdvancedOrderService
          - advanced_order_service.AdvancedOrderService  (same-dir usage)
        """
        svc_cls = None
        for path in (
            "backend.services.advanced_order_service",
            "advanced_order_service",
        ):
            try:
                mod = __import__(path, fromlist=["AdvancedOrderService"])
                svc_cls = getattr(mod, "AdvancedOrderService", None)
                if svc_cls:
                    break
            except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                continue
        if not svc_cls:
            return None
        try:
            return svc_cls()  # new ephemeral service instance
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            raise RuntimeError("AdvancedOrderService instantiation failed (no fallback).") from e

    # ---------------------------
    # Utils
    # ---------------------------

    def _to_canonical_symbol(self, raw: str) -> str:
        s = (raw or "").strip().upper()
        if not s:
            return s
        if "/" in s:
            s = s.replace("/", "")
        if s.endswith("-USD"):
            s = s.replace("-USD", "USDT")
        return s


# Global instance
advanced_trading_service = AdvancedTradingService()
