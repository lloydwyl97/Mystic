"""
AI Attribution Store (single-file)

Purpose
-------
Persist and retrieve *live* AI attribution snapshots per symbol via Redis.
- No fake data: if a key isn't present or decoding fails, we return a minimal,
  honest shape.
- Safe decoding and input validation.
- Small, dependency-light, drop-in ready.

Env
---
REDIS_URL   (default: redis://localhost:6379/0)
AI_ATTR_TTL (default: 600 seconds)

API
---
save_attribution(symbol, inputs, weights, reason, ttl=None) -> None
load_attribution(symbol) -> dict[str, Any]
delete_attribution(symbol) -> bool
list_attribution_symbols(prefix: str = "ai:attr:") -> list[str]
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any

from redis import Redis

# ---------------------------------------------------------------------
# Config / Logger
# ---------------------------------------------------------------------

logger = logging.getLogger(__name__)
# All Live Data, No Fallback/Hardcoded Data
redis_url = os.getenv("REDIS_URL")
if not redis_url:
    redis_host = os.getenv("REDIS_HOST")
    if not redis_host:
        msg = "REDIS_URL or REDIS_HOST environment variable is required - no fallback/hardcoded Redis URL"
        raise RuntimeError(msg)
    redis_port = os.getenv("REDIS_PORT", "6379")
    redis_db = os.getenv("REDIS_DB", "0")
    redis_url = f"redis://{redis_host}:{redis_port}/{redis_db}"
_DEFAULT_URL = redis_url
_DEFAULT_TTL = int(os.getenv("AI_ATTR_TTL", "600"))

# Single, module-level client (sync; fast, simple, reliable for short ops)
# decode_responses=False to keep raw bytes; we handle decoding safely.
redis_client: Redis = Redis.from_url(_DEFAULT_URL, decode_responses=False)

# ---------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------


@dataclass
class AttributionUsed:
    inputs: dict[str, Any]
    weights: dict[str, float]
    reason: str


@dataclass
class AttributionRecord:
    used: AttributionUsed
    ts: str  # ISO8601 (UTC)


# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _key(symbol: str) -> str:
    # Normalize symbol (BTC/USDT, BTC-USD, btcusdt -> BTCUSDT)
    s = (symbol or "").strip().upper()
    if "/" in s:
        s = s.replace("/", "")
    if s.endswith("-USD"):
        s = s.replace("-USD", "USDT")
    return f"ai:attr:{s}"


def _to_text(raw: Any) -> str | None:
    if raw is None:
        return None
    if isinstance(raw, (bytes, bytearray)):
        try:
            return raw.decode("utf-8")
        except Exception:
            return None
    return str(raw)


# ---------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------


def save_attribution(
    symbol: str,
    inputs: dict[str, Any],
    weights: dict[str, float],
    reason: str,
    ttl: int | None = None,
) -> None:
    """
    Save an attribution snapshot for `symbol` with optional TTL.
    - Overwrites the previous snapshot for that symbol.
    - No fake data; stores exactly what you pass (sanity checks applied).
    """
    # Validate inputs outside try to avoid TRY301
    if not isinstance(inputs, dict):
        msg = "inputs must be a dict"
        raise TypeError(msg)
    if not isinstance(weights, dict):
        msg = "weights must be a dict"
        raise TypeError(msg)
    if not isinstance(reason, str):
        msg = "reason must be a str"
        raise TypeError(msg)

    try:
        record = AttributionRecord(
            used=AttributionUsed(inputs=inputs, weights=weights, reason=reason),
            ts=_iso_now(),
        )
        payload = json.dumps(asdict(record), separators=(",", ":"), ensure_ascii=False)
        ttl_val = int(ttl if ttl is not None else _DEFAULT_TTL)
        redis_client.set(_key(symbol), payload, ex=ttl_val)
    except Exception as e:
        # Fail closed but do not fabricate; log and continue.
        logger.exception(f"save_attribution error for {symbol}: {e!s}")


def load_attribution(symbol: str) -> dict[str, Any]:
    """
    Load the most recent attribution snapshot for `symbol`.
    Returns a minimal structure when data is missing or decoding fails:
        {"used": {}, "ts": "<utc-iso>"}
    """
    try:
        raw = redis_client.get(_key(symbol))
        text = _to_text(raw)
        if not text:
            return {"used": {}, "ts": _iso_now()}
        data = json.loads(text)
        if not isinstance(data, dict):
            return {"used": {}, "ts": _iso_now()}
        used = data.get("used")
        ts = data.get("ts") or _iso_now()
        if not isinstance(used, dict) or "inputs" not in used or "weights" not in used or "reason" not in used:
            return {"used": {}, "ts": ts}
    except Exception as e:
        logger.warning(f"load_attribution decode error for {symbol}: {e!s}")
        return {"used": {}, "ts": _iso_now()}
    else:
        return {"used": used, "ts": ts}


def delete_attribution(symbol: str) -> bool:
    """Delete the attribution snapshot for `symbol`.

    Returns True if a key was removed.
    """
    try:
        return bool(redis_client.delete(_key(symbol)))
    except Exception as e:
        logger.exception(f"delete_attribution error for {symbol}: {e!s}")
        return False


def list_attribution_symbols(prefix: str = "ai:attr:") -> list[str]:
    """
    List all symbols that currently have attribution snapshots.
    Note: KEYS is O(N); acceptable for small cardinality.
    Prefer SCAN for very large sets.
    """
    out: list[str] = []
    try:
        for k in redis_client.scan_iter(match=f"{prefix}*", count=100):
            name = _to_text(k) or ""
            if not name:
                continue
            # strip prefix
            sym = name[len(prefix) :]
            if sym:
                out.append(sym)
    except Exception as e:
        logger.exception(f"list_attribution_symbols error: {e!s}")
    return out
