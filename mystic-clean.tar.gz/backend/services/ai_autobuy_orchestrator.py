"""
#############################################################################
# ⚠️  LEGACY CODE - DO NOT USE  ⚠️
#
# This service has been REPLACED by:
#   - backend/services/portfolio_engine_integration.py
#
# See LEGACY_CODE_PROTECTION.md for details.
# DO NOT re-enable or import this service.
#############################################################################

AI AutoBuy Orchestrator Service (DEPRECATED)

Coordinates paper and live autobuy services based on AI learning accuracy.
Automatically transitions from paper trading to live trading based on trading performance criteria (150+ trades, 40%+ win rate, +0.30R expectancy, etc.).

Live Data Flow:
1. Monitors AI learning accuracy from live model manager
2. Manages paper/live autobuy service state
3. Executes automatic transition when trading performance meets go-live criteria
4. Provides rollback and manual control
"""

import asyncio
import contextlib
import logging
import os
from collections import deque
from datetime import datetime, timezone
from enum import Enum
from typing import Any

import redis.asyncio as redis

from backend.ai.auto_trade import disable_trading, enable_trading
from backend.config.redis_config import get_shared_redis_async
from backend.core.constants import (
    GO_LIVE_MAX_DRAWDOWN,
    GO_LIVE_MIN_EXPECTANCY,
    GO_LIVE_MIN_REALIZED_PNL,
    GO_LIVE_MIN_TRADES,
    GO_LIVE_MIN_WIN_RATE,
    MIN_AI_ACCURACY_FOR_LIVE_TRADING,
)
from backend.database_schema import DATABASE_PATH, execute_read
from backend.services.ai_live_autobuy_service import ai_live_autobuy_service
from backend.services.ai_paper_autobuy_service import AIPaperAutoBuyService
from backend.utils.cache_guard import CacheGuard
from backend.utils.redis_helpers import WRITER_ROLES, WriterLock, create_writer_payload

# Optional imports for accuracy checking
try:
    from backend.agents.ai_model_manager import get_ai_model_manager
except (ImportError, ModuleNotFoundError, AttributeError):
    get_ai_model_manager = None  # type: ignore[assignment]

try:
    from backend.services.ai_live_engine import ai_live_engine
except (ImportError, ModuleNotFoundError, AttributeError):
    ai_live_engine = None  # type: ignore[assignment]

try:
    from backend.services.task_manager import task_manager
except (ImportError, ModuleNotFoundError, AttributeError):
    task_manager = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


class OrchestratorState(str, Enum):
    """Orchestrator states for paper-to-live transition"""

    INITIALIZING = "initializing"
    PAPER_LEARNING = "paper_learning"
    TRANSITION_PENDING = "transition_pending"
    LIVE_ACTIVE = "live_active"
    LIVE_PAUSED = "live_paused"
    ROLLBACK_TO_PAPER = "rollback_to_paper"
    ERROR = "error"


class AIAutoBuyOrchestrator:
    """
    Orchestrates paper and live autobuy services based on AI learning progress.

    Manages automatic transition from paper trading to live trading when
    Trading performance meets go-live criteria (150+ trades, 40%+ win rate, etc.).
    """

    def __init__(self):
        redis_url = os.getenv("REDIS_URL")
        if not redis_url:
            msg = "REDIS_URL required"
            raise RuntimeError(msg)
        self.redis_url = redis_url
        self.redis: redis.Redis | None = None
        self.is_running = False

        # Trading performance thresholds (replacing AI accuracy gate)
        self.go_live_min_trades = GO_LIVE_MIN_TRADES
        self.go_live_min_win_rate = GO_LIVE_MIN_WIN_RATE
        self.go_live_min_expectancy = GO_LIVE_MIN_EXPECTANCY
        self.go_live_max_drawdown = GO_LIVE_MAX_DRAWDOWN
        self.go_live_min_realized_pnl = GO_LIVE_MIN_REALIZED_PNL

        # Keep AI accuracy threshold for individual trade validation and rollback logic
        self.accuracy_threshold = MIN_AI_ACCURACY_FOR_LIVE_TRADING

        # State management
        self.state = OrchestratorState.INITIALIZING
        self.current_accuracy = 0.0
        self.last_accuracy_check = None
        # MEMORY LEAK FIX: Bound transition_history to prevent unbounded growth in 24/7 operation
        # Keep only the most recent 500 transitions (more than enough for weeks of operation)
        self.transition_history: deque[dict[str, Any]] = deque(maxlen=500)

        # Configuration
        # PERMANENT FIX: Check every 2 minutes (120s) to keep decisions refreshed
        self.accuracy_check_interval = int(os.getenv("ORCHESTRATOR_CHECK_INTERVAL", "120"))  # 2 minutes (was 5)
        self.grace_period_seconds = int(os.getenv("ORCHESTRATOR_GRACE_PERIOD", "60"))  # 1 minute

        # Service references (set during initialization)
        self.paper_service = None
        self.paper_service_instance = None  # Keep instance alive
        self.live_service = None

        # Monitoring task
        self._monitor_task: asyncio.Task | None = None

        # Writer lock for decision routing (ai_decision:* keys)
        self.writer_lock: WriterLock | None = None

    async def initialize(self):
        """Initialize orchestrator and determine starting state"""
        # CRITICAL: Prevent initialization in EXTERNAL_SUPERVISOR_MODE when called from FastAPI
        external_mode = os.getenv("EXTERNAL_SUPERVISOR_MODE", "true").lower() == "true"
        if external_mode:
            # Check if we're running under uvicorn by looking at the process name or command line
            import sys

            is_uvicorn = any("uvicorn" in arg.lower() for arg in sys.argv) or "uvicorn" in sys.modules
            if is_uvicorn:
                logger.error("[ORCHESTRATOR] Initialize() called from FastAPI in EXTERNAL_SUPERVISOR_MODE - this should not happen")
                raise RuntimeError("Orchestrator initialization is disabled in EXTERNAL_SUPERVISOR_MODE when running under FastAPI")

        # Connect using shared Redis async client to avoid connection leaks
        self.redis = get_shared_redis_async()
        if self.redis is None:
            logger.error("Shared Redis client unavailable; orchestrator cannot start")
            return
        # CRITICAL FIX: Add timeout to Redis ping to prevent hanging
        try:
            await asyncio.wait_for(self.redis.ping(), timeout=5.0)
            logger.info("[OK] AI AutoBuy Orchestrator - Redis connected")
        except asyncio.TimeoutError:
            logger.exception("[ERROR] Redis ping timeout after 5s - orchestrator cannot start")
            return
        except Exception as e:
            logger.exception(f"[ERROR] Redis connection failed: {e}")
            raise

        # CRITICAL: Acquire writer lock for decision routing (ai_decision:* keys)
        self.writer_lock = WriterLock(WRITER_ROLES["DECISION_ROUTER"], self.redis)
        success = await self.writer_lock.acquire()
        if not success:
            logger.error("Failed to acquire decision router writer lock - another orchestrator is running")
            return False

        # Get service references - MUST succeed
        await self._get_service_references()
        if self.paper_service is None or self.live_service is None:
            msg = "Service references are None after _get_service_references()"
            raise RuntimeError(msg)

        # Always start in PAPER_LEARNING mode - go-live decision now based on trading performance
        # AI accuracy is still monitored for individual trade safety and rollback protection
        await self._check_ai_accuracy()  # Still check AI accuracy for monitoring/rollback purposes

        self.state = OrchestratorState.PAPER_LEARNING
        logger.info("[INIT] Starting in PAPER_LEARNING mode - go-live decision based on trading performance metrics")
        logger.info(f"[INIT] Trading performance thresholds: {self.go_live_min_trades} trades, {self.go_live_min_win_rate:.0%} win rate, {self.go_live_min_expectancy:.0%} expectancy")

        return True

    async def _get_service_references(self):
        """Get references to paper and live autobuy services"""
        # AIPaperAutoBuyService and ai_live_autobuy_service are imported at top of file
        if AIPaperAutoBuyService is None:
            msg = "AIPaperAutoBuyService import failed"
            raise RuntimeError(msg)
        if ai_live_autobuy_service is None:
            msg = "ai_live_autobuy_service import failed"
            raise RuntimeError(msg)

        self.paper_service = AIPaperAutoBuyService
        self.live_service = ai_live_autobuy_service
        logger.info("[OK] Orchestrator service references acquired")

    async def start(self):
        """Start the orchestrator and appropriate autobuy service"""
        if self.is_running:
            logger.debug("Orchestrator already running - using existing instance")
            return

        if self.state == OrchestratorState.INITIALIZING:
            msg = "Orchestrator state is INITIALIZING - initialize() must complete successfully first"
            raise RuntimeError(msg)

        if self.paper_service is None or self.live_service is None:
            msg = "Service references are None - initialize() must be called first"
            raise RuntimeError(msg)

        self.is_running = True

        try:
            # Start appropriate service based on current state
            if self.state == OrchestratorState.LIVE_ACTIVE:
                logger.info("[ORCHESTRATOR] Starting LIVE service...")
                await self._start_live_service()
            elif self.state == OrchestratorState.PAPER_LEARNING:
                logger.info("[ORCHESTRATOR] Starting PAPER service...")
                await self._start_paper_service()
                # CRITICAL: Verify paper service actually started
                if not self.paper_service_instance or not getattr(self.paper_service_instance, "is_running", False):
                    msg = "Paper service failed to start - is_running is False"
                    raise RuntimeError(msg)
                logger.info("[ORCHESTRATOR] Paper service verified running")
            else:
                logger.warning(f"Cannot start services in state {self.state} - defaulting to PAPER_LEARNING")
                self.state = OrchestratorState.PAPER_LEARNING
                # Don't hardcode accuracy - will be read from DB/Redis in monitoring loop
                logger.info("[ORCHESTRATOR] Starting PAPER service (fallback)...")
                await self._start_paper_service()
                # CRITICAL: Verify paper service actually started
                if not self.paper_service_instance or not getattr(self.paper_service_instance, "is_running", False):
                    msg = "Paper service failed to start (fallback) - is_running is False"
                    raise RuntimeError(msg)
                logger.info("[ORCHESTRATOR] Paper service verified running (fallback)")

            # If already in live mode, ensure trading is enabled immediately
            if self.state == OrchestratorState.LIVE_ACTIVE:
                await self._ensure_live_trading_enabled()

            # Start monitoring loop
            if task_manager is not None:
                self._monitor_task = await task_manager.create_task(self._monitoring_loop(), name="ai_autobuy_orchestrator:monitoring_loop")
            else:
                self._monitor_task = asyncio.create_task(self._monitoring_loop())

            logger.info(f"[OK] AI AutoBuy Orchestrator started in {self.state} state")

        except Exception as e:
            logger.exception(f"[ERROR] Failed to start orchestrator: {e}")
            self.is_running = False
            self.state = OrchestratorState.ERROR
            raise

    async def stop(self):
        """Stop the orchestrator and all services"""
        logger.info("Stopping AI AutoBuy Orchestrator")
        self.is_running = False

        # Cancel monitoring task
        if self._monitor_task and not self._monitor_task.done():
            self._monitor_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._monitor_task

        # Stop active services
        await self._stop_all_services()

        # Release writer lock
        if self.writer_lock:
            await self.writer_lock.release()
            self.writer_lock = None

        # Close Redis
        if self.redis:
            await self.redis.aclose()

        logger.info("[OK] AI AutoBuy Orchestrator stopped")

    async def _monitoring_loop(self):
        """Main monitoring loop - checks accuracy and manages transitions"""
        while self.is_running:
            try:
                # Check AI accuracy
                await self._check_ai_accuracy()

                # Handle state transitions
                if self.state == OrchestratorState.PAPER_LEARNING:
                    # Process AI signals and convert to decisions for paper trading
                    await self._process_paper_learning_signals()

                    # Check trading performance metrics for go-live decision
                    trading_metrics = await self._get_trading_performance_metrics()
                    if await self._should_go_live(trading_metrics):
                        await self._transition_to_live()

                elif self.state == OrchestratorState.LIVE_ACTIVE:
                    # Ensure trading is enabled if we're in live mode
                    await self._ensure_live_trading_enabled()

                    if await self._should_rollback_to_paper():
                        await self._rollback_to_paper()

                # Update status in Redis
                await self._update_status_in_redis()

                # Sleep until next check
                await asyncio.sleep(self.accuracy_check_interval)

            except Exception as e:
                logger.exception(f"Error in orchestrator monitoring loop: {e}")
                await asyncio.sleep(60)  # Wait 1 minute on error

    async def _check_ai_accuracy(self):
        """Check current AI accuracy with robust fallbacks to ensure real data is used"""
        try:
            # Get the current paper_run_id (current session)
            try:
                current_run_id = await self.redis.get("paper_trading:paper_run_id")
            except Exception:
                current_run_id = None

            # Strategy: Use session data if sufficient (>= 10 trades), otherwise use all-time
            # This ensures we always see real performance data, not defaults

            # Step 1: Try current session first
            if current_run_id:
                current_session = await execute_read(
                    """
                    SELECT
                        COUNT(*) as total,
                        SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) as wins
                    FROM paper_trades
                    WHERE UPPER(side) = 'SELL' AND pnl IS NOT NULL
                    AND paper_run_id = ?
                    """,
                    (current_run_id,),
                    fetchone=True,
                )
                total_current = current_session[0] if current_session else 0
                wins_current = current_session[1] if current_session else 0

                # If session has >= 10 trades, use it (statistically significant)
                if total_current >= 10:
                    self.current_accuracy = wins_current / total_current
                    self.last_accuracy_check = datetime.now(timezone.utc)
                    logger.info(f"AI accuracy from CURRENT session: {self.current_accuracy:.2%} ({wins_current}/{total_current} trades)")
                    return
                elif total_current > 0:
                    # Session has trades but < 10, log it but continue to all-time fallback
                    session_accuracy = wins_current / total_current
                    logger.debug(f"Current session has {total_current} trades ({session_accuracy:.2%}), using all-time for better accuracy")

            # Step 2: Use ALL-TIME accuracy (most reliable when session data is limited)
            all_time = await execute_read(
                """
                SELECT
                    COUNT(*) as total,
                    SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) as wins
                FROM paper_trades
                WHERE UPPER(side) = 'SELL' AND pnl IS NOT NULL
                """,
                fetchone=True,
            )
            total_all_time = all_time[0] if all_time else 0
            wins_all_time = all_time[1] if all_time else 0

            if total_all_time > 0:
                self.current_accuracy = wins_all_time / total_all_time
                self.last_accuracy_check = datetime.now(timezone.utc)
                logger.info(f"AI accuracy from ALL-TIME: {self.current_accuracy:.2%} ({wins_all_time}/{total_all_time} trades)")
                return

            # Step 3: Fallback to last 24h if all-time has no data
            recent = await execute_read(
                """
                SELECT
                    COUNT(*) as total,
                    SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) as wins
                FROM paper_trades
                WHERE UPPER(side) = 'SELL' AND pnl IS NOT NULL
                AND created_at > datetime('now', '-24 hours')
                """,
                fetchone=True,
            )
            total_recent = recent[0] if recent else 0
            wins_recent = recent[1] if recent else 0

            if total_recent > 0:
                self.current_accuracy = wins_recent / total_recent
                self.last_accuracy_check = datetime.now(timezone.utc)
                logger.info(f"AI accuracy from last 24h: {self.current_accuracy:.2%} ({wins_recent}/{total_recent} trades)")
                return

            # Step 4: Try to get from AI live engine
            if ai_live_engine is not None:
                try:
                    if hasattr(ai_live_engine, "state"):
                        accuracy = getattr(ai_live_engine.state, "accuracy", 0.0)
                        if accuracy > 0:
                            self.current_accuracy = float(accuracy)
                            self.last_accuracy_check = datetime.now(timezone.utc)
                            logger.info(f"AI accuracy from live engine: {self.current_accuracy:.2%}")
                            return
                except Exception as e:
                    logger.debug(f"Could not get accuracy from live engine: {e}")

            # Step 5: Try to get from Redis cache (fallback)
            try:
                if self.redis:
                    for key in ("ai_model_accuracy", "ai:model:accuracy"):
                        accuracy_data = await self.redis.get(key)
                        if accuracy_data:
                            self.current_accuracy = float(accuracy_data)
                            self.last_accuracy_check = datetime.now(timezone.utc)
                            logger.info(f"AI accuracy from Redis ({key}): {self.current_accuracy:.2%}")
                            return
            except Exception as e:
                logger.debug(f"Could not get accuracy from Redis: {e}")

            # Step 6: If no accuracy found, try Redis one more time as final fallback
            if self.current_accuracy == 0.0:
                # Final attempt: Read from Redis
                try:
                    if self.redis:
                        accuracy_data = await self.redis.get("ai_model_accuracy")
                        if accuracy_data:
                            self.current_accuracy = float(accuracy_data)
                            self.last_accuracy_check = datetime.now(timezone.utc)
                            logger.info(f"AI accuracy from Redis (final fallback): {self.current_accuracy:.2%}")
                            return
                except Exception as e:
                    logger.debug(f"Final Redis fallback failed: {e}")

                # Only if truly no data exists anywhere, keep at 0.0 (don't hardcode)
                logger.warning("No accuracy data found in DB or Redis - accuracy remains at 0.0 until trades complete")

        except Exception as e:
            logger.exception(f"Error checking AI accuracy: {e}")

    async def _transition_to_live(self):
        """Transition from paper trading to live trading"""
        try:
            logger.info(f"[TRANSITION] AI accuracy {self.current_accuracy:.2%} reached threshold {self.accuracy_threshold:.2%}")
            logger.info("[TRANSITION] Preparing to switch from PAPER to LIVE trading")

            self.state = OrchestratorState.TRANSITION_PENDING

            # Grace period for safety
            logger.info(f"[TRANSITION] Grace period: {self.grace_period_seconds}s")
            await asyncio.sleep(self.grace_period_seconds)

            # Stop paper service
            logger.info("[TRANSITION] Stopping paper autobuy service")
            await self._stop_paper_service()

            # Start live service
            logger.info("[TRANSITION] Starting live autobuy service")
            await self._start_live_service()

            # Update state
            self.state = OrchestratorState.LIVE_ACTIVE

            # Record transition with trading performance metrics
            trading_metrics = await self._get_trading_performance_metrics()
            transition_record = {
                "from_state": "PAPER_LEARNING",
                "to_state": "LIVE_ACTIVE",
                "ai_accuracy": self.current_accuracy,
                "trading_metrics": trading_metrics,
                "thresholds": {
                    "min_trades": self.go_live_min_trades,
                    "min_win_rate": self.go_live_min_win_rate,
                    "min_expectancy": self.go_live_min_expectancy,
                    "max_drawdown": self.go_live_max_drawdown,
                    "min_realized_pnl": self.go_live_min_realized_pnl,
                },
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            self.transition_history.append(transition_record)

            # Store in Redis
            if self.redis:
                await self.redis.lpush("orchestrator:transitions", str(transition_record))
                # MEMORY LEAK FIX: Trim transitions list to prevent Redis memory growth
                # Keep only the most recent 500 transitions (same as in-memory deque)
                await self.redis.ltrim("orchestrator:transitions", 0, 499)

            logger.info("[OK] Successfully transitioned to LIVE trading")

            # Notify (placeholder for notification system)
            await self._notify_transition(transition_record)

        except Exception as e:
            logger.exception(f"[ERROR] Failed to transition to live: {e}")
            self.state = OrchestratorState.ERROR
            raise

    async def _rollback_to_paper(self):
        """Rollback from live trading to paper trading"""
        try:
            logger.warning("[ROLLBACK] Initiating rollback to PAPER trading")

            self.state = OrchestratorState.ROLLBACK_TO_PAPER

            # Stop live service
            logger.info("[ROLLBACK] Stopping live autobuy service")
            await self._stop_live_service()

            # Start paper service
            logger.info("[ROLLBACK] Starting paper autobuy service")
            await self._start_paper_service()

            # Update state
            self.state = OrchestratorState.PAPER_LEARNING

            # Record rollback
            rollback_record = {
                "from_state": "LIVE_ACTIVE",
                "to_state": "PAPER_LEARNING",
                "accuracy": self.current_accuracy,
                "reason": "rollback_requested",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
            self.transition_history.append(rollback_record)

            # Store in Redis with trimming
            if self.redis:
                await self.redis.lpush("orchestrator:transitions", str(rollback_record))
                # MEMORY LEAK FIX: Trim transitions list to prevent Redis memory growth
                await self.redis.ltrim("orchestrator:transitions", 0, 499)

            logger.info("[OK] Successfully rolled back to PAPER trading")

        except Exception as e:
            logger.exception(f"[ERROR] Failed to rollback to paper: {e}")
            self.state = OrchestratorState.ERROR

    async def _ensure_live_trading_enabled(self):
        """Ensure live trading is enabled when in LIVE_ACTIVE state"""
        try:
            # Check if live service is running
            live_running = getattr(self.live_service, "_running", False) if self.live_service else False
            logger.info(f"[ORCHESTRATOR] Live service running: {live_running}")

            if not live_running and self.live_service:
                logger.info("[ORCHESTRATOR] Live service not running in LIVE_ACTIVE state, starting...")

                # Start the live service
                await self.live_service.start()

                # Also call the enable function for consistency
                try:
                    result = enable_trading()
                    if result.get("success"):
                        logger.info("[ORCHESTRATOR] enable_trading() also succeeded")
                    else:
                        logger.warning(f"[ORCHESTRATOR] enable_trading() failed: {result}")
                except Exception as e:
                    logger.warning(f"[ORCHESTRATOR] enable_trading() call failed: {e}")

                logger.info("[ORCHESTRATOR] Live trading enabled successfully")
            else:
                logger.debug("[ORCHESTRATOR] Trading already enabled")

        except Exception as e:
            logger.exception(f"[ORCHESTRATOR] Error enabling live trading: {e}")

    async def _should_rollback_to_paper(self) -> bool:
        """Check if live trading should rollback to paper"""
        try:
            # Check AI accuracy degradation (safety net)
            if self.current_accuracy < (self.accuracy_threshold - 0.10):  # 10% buffer below 45%
                logger.warning(f"AI accuracy {self.current_accuracy:.2%} dropped below rollback threshold ({self.accuracy_threshold - 0.10:.2%})")
                return True

            # Check trading performance degradation
            trading_metrics = await self._get_trading_performance_metrics()

            # Rollback if recent performance falls below maintenance thresholds
            maintenance_win_rate = self.go_live_min_win_rate * 0.8  # 80% of go-live threshold
            maintenance_expectancy = self.go_live_min_expectancy * 0.8

            lifetime = trading_metrics.get("lifetime", {})
            if (
                lifetime.get("win_rate", 0) < maintenance_win_rate or lifetime.get("expectancy", 0) < maintenance_expectancy or lifetime.get("max_drawdown", 0) < (self.go_live_max_drawdown * 1.5)
            ):  # 1.5x worse drawdown
                logger.warning("[ROLLBACK] Trading performance degraded below maintenance thresholds")
                return True
            else:
                return False

        except Exception as e:
            logger.exception(f"[ORCHESTRATOR] Error checking rollback conditions: {e}")
            # On error, err on the side of caution and rollback
            return True

    async def _get_trading_performance_metrics(self) -> dict[str, dict[str, float]]:
        """Get trading performance metrics directly from paper_trades table"""
        try:
            import sqlite3

            def _calculate_metrics():
                # BUG #44 FIX: Use context manager for connection cleanup
                with sqlite3.connect(DATABASE_PATH) as conn:
                    cursor = conn.cursor()

                    # Get lifetime metrics (all closed SELL trades in current paper run)
                    cursor.execute("""
                        SELECT COUNT(*) FROM paper_trades
                        WHERE UPPER(side) = 'SELL' AND remaining_position = 0 AND pnl IS NOT NULL
                    """)
                    total_trades = cursor.fetchone()[0] or 0

                    cursor.execute("""
                        SELECT COUNT(*) FROM paper_trades
                        WHERE UPPER(side) = 'SELL' AND remaining_position = 0 AND pnl > 0
                    """)
                    winning_trades = cursor.fetchone()[0] or 0

                    cursor.execute("""
                        SELECT SUM(pnl) FROM paper_trades
                        WHERE UPPER(side) = 'SELL' AND remaining_position = 0 AND pnl IS NOT NULL
                    """)
                    total_pnl = cursor.fetchone()[0] or 0.0

                    win_rate = winning_trades / total_trades if total_trades > 0 else 0.0

                    # Calculate expectancy (simplified)
                    expectancy = total_pnl / max(total_trades, 1)

                    lifetime_metrics = {
                        "total_trades": total_trades,
                        "win_rate": win_rate,  # Already a 0-1 fraction (winning/total)
                        "expectancy": expectancy,
                        "max_drawdown": 0.0,  # Simplified - could calculate properly
                        "realized_pnl": total_pnl,
                    }

                    # Get rolling window metrics (last 50 trades)
                    cursor.execute("""
                        SELECT pnl FROM paper_trades
                        WHERE UPPER(side) = 'SELL' AND remaining_position = 0 AND pnl IS NOT NULL
                        ORDER BY timestamp DESC
                        LIMIT 50
                    """)

                    rolling_trades = [row[0] for row in cursor.fetchall()]
                    rolling_total_trades = len(rolling_trades)
                    rolling_wins = len([p for p in rolling_trades if p > 0])
                    rolling_win_rate = (rolling_wins / rolling_total_trades) if rolling_total_trades > 0 else 0.0
                    rolling_pnl = sum(rolling_trades)

                    # Simple expectancy calculation for rolling window
                    rolling_avg_win = sum([p for p in rolling_trades if p > 0]) / max(rolling_wins, 1)
                    rolling_avg_loss = abs(sum([p for p in rolling_trades if p < 0])) / max(len([p for p in rolling_trades if p < 0]), 1)
                    rolling_expectancy = (rolling_avg_win * rolling_win_rate) - (rolling_avg_loss * (1 - rolling_win_rate))

                    rolling_50_metrics = {
                        "total_trades": rolling_total_trades,
                        "win_rate": rolling_win_rate,
                        "expectancy": rolling_expectancy,
                        "max_drawdown": 0.0,  # Simplified
                        "realized_pnl": rolling_pnl,
                    }

                    return {"lifetime": lifetime_metrics, "rolling_50": rolling_50_metrics}

            # Execute in thread pool
            import asyncio

            result = await asyncio.get_event_loop().run_in_executor(None, _calculate_metrics)
            logger.info(f"[ORCHESTRATOR] Paper trading metrics: lifetime={result['lifetime']}, rolling_50={result['rolling_50']}")

        except Exception as e:
            logger.exception(f"[ORCHESTRATOR] Failed to get trading performance metrics: {e}")
            return {"lifetime": self._get_default_metrics(), "rolling_50": self._get_default_metrics()}
        else:
            return result

    def _get_default_metrics(self) -> dict[str, float]:
        """Return default metrics when service unavailable"""
        return {
            "total_trades": 0,
            "win_rate": 0.0,
            "expectancy": 0.0,
            "max_drawdown": 0.0,
            "realized_pnl": 0.0,
        }

    async def _process_paper_learning_signals(self):
        """Process AI signals and convert to decisions for paper trading in learning mode"""
        try:
            # Get all AI signals (L1: use SCAN not KEYS)
            signal_keys = []
            async for k in self.redis.scan_iter(match="ai_signal:*", count=100):
                signal_keys.append(k)
            logger.debug(f"[PAPER_LEARNING] Found {len(signal_keys)} signals to process")

            processed_count = 0
            for key_bytes in signal_keys:
                try:
                    key = key_bytes.decode("utf-8") if isinstance(key_bytes, bytes) else str(key_bytes)

                    # Get signal data
                    signal_data = await self.redis.hgetall(key)
                    if not signal_data:
                        logger.debug(f"[PAPER_LEARNING] Empty signal data for {key}")
                        continue

                    # Extract symbol
                    symbol = key.replace("ai_signal:", "")

                    # Convert signal to decision format
                    decision_key = f"ai_decision:{symbol}"

                    # Decode signal fields
                    decision_data = {}
                    for field_bytes, value_bytes in signal_data.items():
                        field = field_bytes.decode("utf-8") if isinstance(field_bytes, bytes) else str(field_bytes)
                        value = value_bytes.decode("utf-8") if isinstance(value_bytes, bytes) else str(value_bytes)
                        decision_data[field] = value

                    # Skip HOLD signals - only propagate actionable BUY/SELL decisions.
                    # Propagating HOLDs would overwrite active decisions from ai_live_engine.
                    side = decision_data.get("side", "").lower()
                    if side not in ("buy", "sell"):
                        logger.debug("[PAPER_LEARNING] Skipping non-actionable signal for %s (side=%r)", symbol, side)
                        continue

                    # Skip fresh decisions to avoid overwriting active ai_live_engine writes
                    decision_ttl = await self.redis.ttl(decision_key)
                    if decision_ttl > 20:  # More than 20s remaining: treat as fresh
                        continue

                    # FIXED: Respect LIVE_MODE from .env instead of hardcoding "paper"
                    # If LIVE_MODE=true, use "live", otherwise use state-based mode
                    live_mode_env = os.getenv("LIVE_MODE", "false").lower() == "true"
                    trading_mode_env = os.getenv("TRADING_MODE", "paper").lower()

                    # Determine actual learning mode
                    actual_learning_mode = "live" if live_mode_env or trading_mode_env == "live" else "paper"

                    decision_data.update(
                        {
                            "processed_by_orchestrator": "true",
                            "learning_mode": actual_learning_mode,
                            "orchestrator_timestamp": str(datetime.now(timezone.utc).timestamp()),
                            "confidence_threshold": str(self.accuracy_threshold),
                            "current_accuracy": str(self.current_accuracy),
                        }
                    )

                    # Add writer metadata for single-writer enforcement
                    enhanced_decision_data = create_writer_payload(WRITER_ROLES["DECISION_ROUTER"], decision_data)
                    # Store as decision (atomic write to prevent race conditions)
                    await self.redis.hmset(decision_key, enhanced_decision_data)

                    # Use 30s TTL matching ai_live_autobuy_service to avoid stale overrides
                    await self.redis.expire(decision_key, 30)

                    # PERMANENT FIX: DO NOT delete signal - let it expire naturally
                    # This allows decisions to be refreshed automatically every loop
                    # Signal generator will refresh signals every 5 min anyway

                    processed_count += 1
                    logger.info(f"[PAPER_LEARNING] Converted signal to decision: {symbol}")

                except Exception as e:
                    logger.warning(f"[PAPER_LEARNING] Failed to process signal {key_bytes}: {e}")

            logger.info(f"[PAPER_LEARNING] Processed {processed_count} signals into decisions")

        except Exception as e:
            logger.exception(f"[PAPER_LEARNING] Error processing signals: {e}")

    async def _should_go_live(self, metrics: dict[str, dict[str, float]]) -> bool:
        """Check if trading performance meets go-live criteria using dual validation"""
        try:
            lifetime = metrics.get("lifetime", {})
            rolling_50 = metrics.get("rolling_50", {})

            # Dual validation: Lifetime sanity + Rolling window performance
            lifetime_checks = [
                lifetime.get("total_trades", 0) >= self.go_live_min_trades,  # >= 1 trade total
                lifetime.get("realized_pnl", 0) > self.go_live_min_realized_pnl,  # > $0 overall
            ]

            rolling_checks = [
                rolling_50.get("total_trades", 0) >= 1,  # At least 1 recent trade
                rolling_50.get("win_rate", 0) >= self.go_live_min_win_rate,  # >= 40% recent win rate
                rolling_50.get("expectancy", 0) >= self.go_live_min_expectancy,  # >= 0.40 recent expectancy
                rolling_50.get("max_drawdown", 0) >= self.go_live_max_drawdown,  # >= -5% recent drawdown
            ]

            lifetime_ready = all(lifetime_checks)
            rolling_ready = all(rolling_checks)
            go_live_ready = lifetime_ready and rolling_ready

            if go_live_ready:
                logger.info("[GO-LIVE READY] Dual validation passed - system ready for live trading:")
                logger.info("  LIFETIME CHECKS:")
                logger.info(f"    • Total Trades: {lifetime.get('total_trades', 0)} >= {self.go_live_min_trades}")
                logger.info(f"    • Realized P&L: ${lifetime.get('realized_pnl', 0):.2f} > ${self.go_live_min_realized_pnl:.2f}")
                logger.info("  ROLLING WINDOW CHECKS (Last 50 trades):")
                logger.info(f"    • Recent Trades: {rolling_50.get('total_trades', 0)} >= 1")
                logger.info(".1f")
                logger.info(f"    • Expectancy: {rolling_50.get('expectancy', 0):.2f} >= {self.go_live_min_expectancy:.2f}")
                logger.info(f"    • Max Drawdown: {rolling_50.get('max_drawdown', 0):.1%} >= {self.go_live_max_drawdown:.1%}")
                return True
            elif lifetime_ready and not rolling_ready:
                logger.info("[GO-LIVE PENDING] Lifetime checks passed but rolling window checks failed")
                logger.debug(f"  Rolling trades: {rolling_50.get('total_trades', 0)}/1, Win rate: {rolling_50.get('win_rate', 0):.1%}/40%")
                return False
            else:
                logger.debug("[GO-LIVE PENDING] Trading performance criteria not met")
                return False

        except Exception as e:
            logger.exception(f"[ORCHESTRATOR] Error checking go-live criteria: {e}")
            return False

    async def _start_paper_service(self):
        """Start paper autobuy service"""
        if self.paper_service is None:
            msg = "paper_service is None - _get_service_references() must be called first"
            raise RuntimeError(msg)
        # Create and store instance to keep it alive
        self.paper_service_instance = self.paper_service()

        # CRITICAL FIX: Add timeout to prevent hanging on paper service start
        try:
            await asyncio.wait_for(self.paper_service_instance.start(), timeout=30.0)
        except asyncio.TimeoutError as e:
            logger.exception("[ERROR] Paper service start() timeout after 30s")
            raise RuntimeError() from e
        except Exception as e:
            logger.exception(f"[ERROR] Paper service start() failed: {e}")
            raise

        if not getattr(self.paper_service_instance, "is_running", False):
            msg = "Paper service start() did not set is_running=True"
            raise RuntimeError(msg)

        logger.info("[OK] Paper autobuy service started and instance kept alive")

    async def _stop_paper_service(self):
        """Stop paper autobuy service"""
        if self.paper_service_instance:
            try:
                await self.paper_service_instance.stop()
                self.paper_service_instance = None
                logger.info("[OK] Paper autobuy service stopped")
            except Exception as e:
                logger.exception(f"Failed to stop paper service: {e}")
        else:
            logger.info("[OK] Paper autobuy service already stopped")

    async def _start_live_service(self):
        """Start live autobuy service"""
        if self.live_service is None:
            logger.warning("[ORCHESTRATOR] Live service not available - cannot start")
            return
        try:
            # Bootstrap market_data:last_update key before starting live service (prevents race condition)
            try:
                cache_guard = await CacheGuard.create()
                await cache_guard.mark_market_update("boot")
                logger.info("[OK] Bootstrap: market_data:last_update key verified before live service start")
            except Exception as boot_err:
                # Don't block startup - live service will fail-closed if key stays missing
                logger.warning(f"[WARN] Bootstrap market_data:last_update failed: {boot_err}")

            if not getattr(self.live_service, "_running", False):
                await self.live_service.start()
                logger.info("[OK] Live autobuy service started")

                # Also enable trading in the auto_trade system
                enable_result = enable_trading()
                if enable_result["success"]:
                    logger.info("[OK] Live trading enabled in auto_trade system")
                else:
                    logger.warning(f"[WARN] Failed to enable live trading: {enable_result}")

        except Exception as e:
            logger.exception(f"Failed to start live service: {e}")
            # CRITICAL FIX: Don't re-raise - allow orchestrator to continue

    async def _stop_live_service(self):
        """Stop live autobuy service"""
        if self.live_service:
            try:
                if getattr(self.live_service, "_running", False):
                    await self.live_service.stop()
                    logger.info("[OK] Live autobuy service stopped")

                    # Also disable trading in the auto_trade system
                    disable_result = disable_trading()
                    if disable_result["success"]:
                        logger.info("[OK] Live trading disabled in auto_trade system")
                    else:
                        logger.warning(f"[WARN] Failed to disable live trading: {disable_result}")

            except Exception as e:
                logger.exception(f"Failed to stop live service: {e}")

    async def _stop_all_services(self):
        """Stop both paper and live services"""
        await self._stop_paper_service()
        await self._stop_live_service()

    async def _update_status_in_redis(self):
        """Update orchestrator status in Redis for monitoring"""
        try:
            if self.redis:
                status = {
                    "state": self.state.value,
                    "current_accuracy": self.current_accuracy,
                    "accuracy_threshold": self.accuracy_threshold,
                    "go_live_thresholds": {
                        "min_trades": self.go_live_min_trades,
                        "min_win_rate": self.go_live_min_win_rate,
                        "min_expectancy": self.go_live_min_expectancy,
                        "max_drawdown": self.go_live_max_drawdown,
                        "min_realized_pnl": self.go_live_min_realized_pnl,
                    },
                    "last_accuracy_check": self.last_accuracy_check.isoformat() if self.last_accuracy_check else None,
                    "is_running": self.is_running,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
                await self.redis.setex(
                    "orchestrator:status",
                    self.accuracy_check_interval + 60,  # TTL slightly longer than check interval
                    str(status),
                )
        except Exception as e:
            logger.debug(f"Could not update status in Redis: {e}")

    async def _notify_transition(self, transition_record: dict[str, Any]):
        """Notify about state transitions. Logs; notification channels can be wired here."""
        logger.info(f"[NOTIFICATION] Transition: {transition_record}")

    async def get_status(self) -> dict[str, Any]:
        """Get current orchestrator status"""
        return {
            "service": "ai_autobuy_orchestrator",
            "state": self.state.value,
            "is_running": self.is_running,
            "current_accuracy": self.current_accuracy,
            "accuracy_threshold": self.accuracy_threshold,
            "last_accuracy_check": self.last_accuracy_check.isoformat() if self.last_accuracy_check else None,
            "accuracy_check_interval": self.accuracy_check_interval,
            "grace_period_seconds": self.grace_period_seconds,
            "transition_count": len(self.transition_history),
            "last_transition": self.transition_history[-1] if self.transition_history else None,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    async def force_transition_to_live(self) -> dict[str, Any]:
        """Manually force transition to live trading"""
        if self.state != OrchestratorState.PAPER_LEARNING:
            return {"success": False, "error": f"Cannot transition from state {self.state}"}

        logger.info("[MANUAL] Forcing transition to LIVE trading")
        await self._transition_to_live()

        return {"success": True, "state": self.state.value}

    async def force_rollback_to_paper(self) -> dict[str, Any]:
        """Manually force rollback to paper trading"""
        if self.state != OrchestratorState.LIVE_ACTIVE:
            return {"success": False, "error": f"Cannot rollback from state {self.state}"}

        logger.info("[MANUAL] Forcing rollback to PAPER trading")
        await self._rollback_to_paper()

        return {"success": True, "state": self.state.value}


# Global orchestrator instance with PERSISTENT STATE
_orchestrator_persistent_state = {"instance": None, "last_known_state": "INITIALIZING", "was_running": False, "has_services": False, "last_init_time": None}


def get_orchestrator() -> AIAutoBuyOrchestrator:
    """Get or create global orchestrator instance with ROBUST state preservation"""
    current_time = datetime.now(timezone.utc)

    # If no instance exists, create one
    if _orchestrator_persistent_state["instance"] is None:
        logger.info("[ORCHESTRATOR] Creating new orchestrator instance")
        _orchestrator_persistent_state["instance"] = AIAutoBuyOrchestrator()
        _orchestrator_persistent_state["last_init_time"] = current_time
        return _orchestrator_persistent_state["instance"]

    orchestrator = _orchestrator_persistent_state["instance"]

    # CRITICAL FIX: Detect and prevent state corruption/reset
    current_state = orchestrator.state.name if hasattr(orchestrator, "state") else "UNKNOWN"

    # If state changed unexpectedly to INITIALIZING, try to recover
    if current_state == "INITIALIZING" and _orchestrator_persistent_state["last_known_state"] != "INITIALIZING" and _orchestrator_persistent_state["has_services"]:
        logger.warning(f"[ORCHESTRATOR] State corruption detected! Was {_orchestrator_persistent_state['last_known_state']}, now {current_state}")

        # Attempt recovery if we had services before
        if _orchestrator_persistent_state["was_running"] and hasattr(orchestrator, "paper_service") and orchestrator.paper_service is not None:
            logger.info("[ORCHESTRATOR] Recovery attempt: Restoring PAPER_LEARNING state")
            orchestrator.state = OrchestratorState.PAPER_LEARNING
            orchestrator.is_running = True
            current_state = "PAPER_LEARNING"
            logger.info("[ORCHESTRATOR] State recovered successfully")

        else:
            logger.warning("[ORCHESTRATOR] Cannot recover - services lost")

    # Update persistent state tracking
    _orchestrator_persistent_state["last_known_state"] = current_state
    _orchestrator_persistent_state["was_running"] = getattr(orchestrator, "is_running", False)
    _orchestrator_persistent_state["has_services"] = hasattr(orchestrator, "paper_service") and orchestrator.paper_service is not None

    return orchestrator


# Orchestrator will be started by create_app function
