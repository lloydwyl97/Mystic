"""
AI Database Manager (single-file)
Handles database initialization, table creation, and session management for AI components.
"""

from __future__ import annotations

import logging
import os
from collections.abc import Iterable, Sequence
from contextlib import contextmanager
from pathlib import Path

from sqlalchemy import create_engine, event, text
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from backend.ai.ai_live_models_store import Base as DefaultBase  # type: ignore[import-not-found]

# Lazy import for optional dynamic base (fallback if DefaultBase unavailable)
try:
    from backend.ai.ai_live_models_store import Base as _DynamicDefaultBase  # type: ignore[import-not-found]
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    _DynamicDefaultBase = None  # type: ignore[assignment, misc]

logger = logging.getLogger(__name__)

# Type alias for session maker (SQLAlchemy 1.4/2.x compatible)
SessionMaker = sessionmaker


def _default_base_dir() -> Path:
    """Resolve a stable base directory even when packaged/relocated."""
    try:
        here = Path(__file__).resolve().parent
    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
        here = Path.cwd()
    return here.parent  # mirror original: parent of current file


def _coerce_models(seq_or_base) -> Sequence:
    """
    Accept either:
      - a declarative Base (with .metadata)
      - an iterable of declarative Bases
    Return a sequence of bases.
    """
    if seq_or_base is None:
        return ()
    # Single base with .metadata
    if hasattr(seq_or_base, "metadata"):
        return (seq_or_base,)
    # Iterable of bases
    try:
        return tuple(b for b in seq_or_base if hasattr(b, "metadata"))
    except TypeError:
        return ()


class AIDBManager:
    """Manages AI database initialization and connections."""

    def __init__(
        self,
        db_url: str | None = None,
        base_dir: Path | None = None,
        filename: str = "ai_live.db",
    ) -> None:
        """
        Args:
            db_url: Optional explicit database URL. If not set:
                    - ENV AI_DB_URL is used if present
                    - otherwise a local SQLite file at <base_dir>/data/ai/ai_live.db
            base_dir: Base directory for relative SQLite paths
            filename: SQLite filename (ignored if db_url provided and not SQLite)
        """
        self.base_dir = base_dir or _default_base_dir()
        self.db_dir = self.base_dir / "data" / "ai"
        self.db_path = self.db_dir / filename

        # Resolve URL precedence
        env_url = os.getenv("AI_DB_URL")
        self.db_url = db_url or env_url or f"sqlite:///{self.db_path}"

        self.engine: Engine | None = None
        self.Session: SessionMaker | None = None

        # Ensure directories exist for SQLite paths
        if self.db_url.startswith("sqlite:///"):
            self.db_dir.mkdir(parents=True, exist_ok=True)

    def initialize(self, echo: bool = False, future: bool = True) -> bool:
        """Initialize engine and sessionmaker."""
        try:
            self.engine = create_engine(self.db_url, echo=echo, future=future)

            # SQLite pragmas for reliability
            if self.db_url.startswith("sqlite:///"):

                @event.listens_for(self.engine, "connect")
                def _set_sqlite_pragma(dbapi_connection, _):
                    try:
                        # WAL for better concurrency
                        dbapi_connection.execute("PRAGMA journal_mode=WAL;")
                        # Safer writes
                        dbapi_connection.execute("PRAGMA synchronous=NORMAL;")
                        # Foreign keys enforcement
                        dbapi_connection.execute("PRAGMA foreign_keys=ON;")
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
                        pass

            self.Session = sessionmaker(
                bind=self.engine,
                autoflush=False,
                autocommit=False,
                expire_on_commit=False,
            )
            logger.info(f"[OK] AI database initialized at URL: {self.db_url}")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Failed to initialize AI database: {e}")
            self.engine = None
            self.Session = None
            return False
        else:
            return True

    def get_session(self) -> Session:
        """Create a new Session. Requires initialize() first."""
        if not self.Session:
            msg = "Database not initialized. Call initialize() first."
            raise RuntimeError(msg)
        return self.Session()

    @contextmanager
    def session_scope(self) -> Session:
        """Context-manager for transactional scope."""
        session = self.get_session()
        try:
            yield session
            session.commit()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            session.rollback()
            raise
        finally:
            session.close()

    def ping(self) -> bool:
        """Basic health check for the engine/connection."""
        if not self.engine:
            return False
        try:
            with self.engine.connect() as conn:
                conn.execute(text("SELECT 1"))
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError):
            return False
        else:
            return True

    def create_tables(self, base_or_bases: object | Iterable[object] | None = None) -> bool:
        """
        Create all tables.

        Usage options:
          1) Pass your declarative Base: create_tables(Base)
          2) Pass an iterable of Bases: create_tables([Base1, Base2])
          3) Pass nothing to auto-import 'backend.ai.ai_live_models_store:Base' if available.

        Returns:
            True on success, False otherwise.
        """
        # Validate engine initialization outside try to avoid TRY301
        if not self.engine:
            msg = "Database not initialized. Call initialize() first."
            raise RuntimeError(msg)

        try:
            bases = _coerce_models(base_or_bases)

            if not bases:
                # Lazy import default Base if present (try services first)
                if DefaultBase is not None:
                    bases = (DefaultBase,)
                else:
                    try:
                        bases = () if _DynamicDefaultBase is None else (_DynamicDefaultBase,)
                    except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
                        logger.warning(
                            "No declarative Base available for table creation (skipping). Error: %s",
                            e,
                        )
                        # Consider tables created successfully when no Base is present
                        return True

            for base in bases:
                base.metadata.create_all(self.engine)

            logger.info("[OK] AI database tables created successfully")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"[ERROR] Failed to create database tables: {e}")
            return False
        else:
            return True

    @property
    def is_initialized(self) -> bool:
        """True if engine and sessionmaker are ready."""
        return bool(self.engine and self.Session)


# Global instance for convenience
ai_db_manager = AIDBManager()
