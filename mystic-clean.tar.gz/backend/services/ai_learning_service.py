"""
AI Learning Service
==================

Service for managing AI learning processes, model training,
and continuous learning improvements.
"""

import asyncio
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from backend.modules.ai.ai_learning import AILearner
from backend.modules.ai.enhanced_ai_trainer import get_enhanced_trainer
from backend.services.task_manager import task_manager

logger = logging.getLogger(__name__)

# AI learning timing constants
AI_LEARNING_CHECK_INTERVAL = 300.0  # 5 minutes between training opportunity checks
AI_LEARNING_ERROR_RECOVERY_DELAY = 60.0  # 1 minute delay after errors


class AILearningService:
    """Service for managing AI learning processes"""

    def __init__(self, _cache: Any = None) -> None:
        self.enhanced_trainer = get_enhanced_trainer()
        self.ai_learner = AILearner()
        # Do not instantiate a separate training pipeline here; the backend app factory
        # manages the lifecycle of the cache-based training pipeline to avoid duplication
        self.training_pipeline = None
        self.learning_data_path = Path("data/ai_learning_data.json")
        self.is_learning_active = False
        self.learning_stats = {
            "total_training_sessions": 0,
            "successful_trainings": 0,
            "failed_trainings": 0,
            "last_training": None,
            "sklearn_version": "1.7.1",
        }

        logger.info("AI Learning Service initialized with enhanced training pipeline")

        # Initialize strategy performance tracking with defaults
        self.strategy_performance = self._get_default_strategy_performance()

        # Note: Data loading will happen lazily when get_strategy_performance is called
        # This avoids async issues in __init__

    async def process_trade_feedback(self, strategy_id: str, trade_data: dict[str, Any]) -> None:
        """Process trade feedback from paper trading and update strategy metrics"""
        if strategy_id not in self.strategy_performance:
            logger.warning(f"Unknown strategy {strategy_id}, skipping feedback processing")
            return

        try:
            strategy = self.strategy_performance[strategy_id]

            # Update trade counts and P&L
            strategy["total_trades"] += 1
            pnl = trade_data.get("pnl", 0.0)
            strategy["total_pnl"] += pnl

            if pnl > 0:
                strategy["winning_trades"] += 1
            else:
                strategy["losing_trades"] += 1

            # Calculate win rate
            if strategy["total_trades"] > 0:
                strategy["win_rate"] = (strategy["winning_trades"] / strategy["total_trades"]) * 100.0

            # Calculate Sharpe ratio (simplified)
            if strategy["total_trades"] > 1:
                avg_return = strategy["total_pnl"] / strategy["total_trades"]
                # Simplified Sharpe - in production would use more sophisticated calculation
                strategy["sharpe_ratio"] = avg_return / max(0.01, abs(avg_return) * 0.1)  # Avoid division by zero

            strategy["last_updated"] = datetime.now(timezone.utc).isoformat()

            # Persist updated strategy data
            await self._update_strategy_data(strategy_id, strategy)

            logger.info(f"Updated strategy {strategy_id}: {strategy['total_trades']} trades, {strategy['win_rate']:.1f}% win rate, ${strategy['total_pnl']:.2f} P&L")

        except Exception as e:
            logger.exception(f"Failed to process trade feedback for strategy {strategy_id}: {e}")

    async def get_strategy_performance(self, strategy_id: str | None = None) -> dict[str, Any]:
        """Get strategy performance data for API endpoints"""
        # Load any persisted data first
        try:
            existing_data = await self._load_learning_data()
            if existing_data.get("strategy_performance"):
                logger.debug("Merging persisted strategy performance data")
                # Merge persisted data with current in-memory data
                for strategy_id_key, persisted_strategy in existing_data["strategy_performance"].items():
                    if strategy_id_key in self.strategy_performance:
                        self.strategy_performance[strategy_id_key].update(persisted_strategy)
                    else:
                        self.strategy_performance[strategy_id_key] = persisted_strategy
        except Exception as e:
            logger.warning(f"Could not load persisted strategy data: {e}")

        if strategy_id:
            return self.strategy_performance.get(strategy_id, {})

        return {"strategies": list(self.strategy_performance.values()), "timestamp": datetime.now(timezone.utc).isoformat(), "source": "ai_learning_service"}

    async def _update_strategy_data(self, strategy_id: str, strategy_data: dict[str, Any]) -> None:
        """Persist strategy performance data"""
        try:
            # Load existing data
            data = await self._load_learning_data()

            # Update strategy performance
            if "strategy_performance" not in data:
                data["strategy_performance"] = {}

            data["strategy_performance"][strategy_id] = strategy_data

            # Save updated data
            await self._save_learning_data(data)

        except Exception as e:
            logger.exception(f"Failed to persist strategy data for {strategy_id}: {e}")

    async def start_learning(self) -> dict[str, Any]:
        """Start the AI learning process"""
        try:
            if self.is_learning_active:
                return {
                    "success": False,
                    "message": "Learning already active",
                    "status": "already_running",
                }

            self.is_learning_active = True
            logger.info("Starting AI learning process")

            # Start background learning task
            task = await task_manager.create_task(self._learning_loop(), name="ai_learning_service:learning_loop")
            # Store task reference if class has task tracking
            if hasattr(self, "_tasks"):
                self._tasks.append(task)
            elif not hasattr(self, "_tasks"):
                self._tasks: list[asyncio.Task[Any]] = []
                self._tasks.append(task)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Failed to start AI learning: {e}")
            return {"success": False, "error": str(e), "status": "failed"}
        else:
            return {
                "success": True,
                "message": "AI learning started successfully",
                "status": "started",
                "sklearn_version": "1.7.1",
            }

    async def stop_learning(self) -> dict[str, Any]:
        """Stop the AI learning process"""
        try:
            self.is_learning_active = False
            if hasattr(self, "_tasks"):
                for task in self._tasks:
                    if not task.done():
                        task.cancel()
                self._tasks.clear()
            logger.info("STOP: AI learning process stopped")
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Failed to stop AI learning: {e}")
            return {"success": False, "error": str(e), "status": "failed"}
        else:
            return {
                "success": True,
                "message": "AI learning stopped successfully",
                "status": "stopped",
            }

    async def train_model_for_symbol(self, symbol: str, training_data: dict[str, Any]) -> dict[str, Any]:
        """Train a model for a specific symbol"""
        try:
            logger.info(f"Training model for {symbol}")

            # Use enhanced trainer for better performance
            result = await self.enhanced_trainer.train_ensemble_model(symbol, training_data)

            if result["success"]:
                self.learning_stats["successful_trainings"] += 1
                self.learning_stats["last_training"] = datetime.now(timezone.utc).isoformat()

                # Update learning data
                await self._update_learning_data(symbol, result)

                logger.info(f"Model training completed for {symbol}")
            else:
                self.learning_stats["failed_trainings"] += 1
                logger.error(f"Model training failed for {symbol}")

            self.learning_stats["total_training_sessions"] += 1
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Training failed for {symbol}: {e}")
            self.learning_stats["failed_trainings"] += 1
            return {
                "success": False,
                "symbol": symbol,
                "error": str(e),
                "sklearn_version": "1.7.1",
            }
        else:
            return result

    async def get_comprehensive_stats(self) -> dict[str, Any]:
        """Get comprehensive AI learning statistics"""
        try:
            stats = {
                "learning_service": self.learning_stats,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "is_learning_active": self.is_learning_active,
            }

            # Add training pipeline stats if available
            if self.training_pipeline:
                pipeline_stats = {
                    "models_count": len(self.training_pipeline.models),
                    "models": {},
                }

                for model_name, model in self.training_pipeline.models.items():
                    pipeline_stats["models"][model_name] = {
                        "accuracy": model.accuracy,
                        "is_trained": model.is_trained,
                        "trained_at": model.trained_at,
                        "model_type": model.model_type,
                        "metadata": model.metadata,
                    }

                stats["training_pipeline"] = pipeline_stats

            # Add enhanced trainer stats
            if hasattr(self.enhanced_trainer, "get_stats"):
                stats["enhanced_trainer"] = self.enhanced_trainer.get_stats()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error getting comprehensive stats: {e}")
            return {
                "error": str(e),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        else:
            return stats

    async def get_learning_status(self) -> dict[str, Any]:
        """Get current learning status"""
        try:
            # Load learning data
            learning_data = await self._load_learning_data()

            # Get performance summary
            performance_summary = self.enhanced_trainer.get_performance_summary()

            return {
                "learning_active": self.is_learning_active,
                "learning_stats": self.learning_stats,
                "performance_summary": performance_summary,
                "learning_data": learning_data,
                "sklearn_version": "1.7.1",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Failed to get learning status: {e}")
            return {"error": str(e), "sklearn_version": "1.7.1"}

    async def _learning_loop(self):
        """Main learning loop"""
        while self.is_learning_active:
            try:
                # Check for new training opportunities
                await self._check_training_opportunities()

                # Wait before next training opportunity check
                await asyncio.sleep(AI_LEARNING_CHECK_INTERVAL)

            except Exception as e:
                logger.exception(f"Error in learning loop: {e}")
                # Error recovery delay before retry
                await asyncio.sleep(AI_LEARNING_ERROR_RECOVERY_DELAY)

    async def _check_training_opportunities(self):
        """Check for new training opportunities"""
        try:
            # This would check for new market data, user feedback, etc.
            # For now, we'll just log that we're checking
            logger.debug("Checking for training opportunities")

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Error checking training opportunities: {e}")

    async def _update_learning_data(self, symbol: str, training_result: dict[str, Any]):
        """Update learning data with new training results"""
        try:
            learning_data = await self._load_learning_data()

            # Update learning metrics
            learning_data["learning_metrics"]["total_data_points"] += training_result.get("training_data_size", 0)
            learning_data["learning_metrics"]["active_strategies"] += 1

            # Update model performance
            if "performance" in training_result:
                perf = training_result["performance"]
                learning_data["model_performance"][f"{symbol}_model"] = {
                    "accuracy": perf.get("accuracy", 0.0),
                    "status": "trained",
                    "last_trained": training_result.get("training_time", datetime.now(timezone.utc).isoformat()),
                    "training_data_points": training_result.get("training_data_size", 0),
                    "model_name": training_result.get("best_model", "unknown"),
                }

            # Save updated data
            await self._save_learning_data(learning_data)

        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Failed to update learning data: {e}")

    async def _load_learning_data(self) -> dict[str, Any]:
        """Load learning data from file"""
        try:
            if self.learning_data_path.exists():

                def _read():
                    with self.learning_data_path.open() as f:
                        return json.load(f)

                return await asyncio.to_thread(_read)
            else:
                return self._get_default_learning_data()
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Failed to load learning data: {e}")
            return self._get_default_learning_data()

    async def _save_learning_data(self, data: dict[str, Any]):
        """Save learning data to file"""
        try:

            def _write():
                with self.learning_data_path.open("w") as f:
                    json.dump(data, f, indent=2)

            await asyncio.to_thread(_write)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError, RuntimeError) as e:
            logger.exception(f"Failed to save learning data: {e}")

    def _get_default_strategy_performance(self) -> dict[str, Any]:
        """Get default strategy performance data"""
        return {
            "momentum_v1": {
                "strategy_id": "momentum_v1",
                "name": "Momentum Strategy",
                "total_trades": 0,
                "winning_trades": 0,
                "losing_trades": 0,
                "total_pnl": 0.0,
                "win_rate": 0.0,
                "sharpe_ratio": 0.0,
                "last_updated": None,
            },
            "mean_reversion_v1": {
                "strategy_id": "mean_reversion_v1",
                "name": "Mean Reversion Strategy",
                "total_trades": 0,
                "winning_trades": 0,
                "losing_trades": 0,
                "total_pnl": 0.0,
                "win_rate": 0.0,
                "sharpe_ratio": 0.0,
                "last_updated": None,
            },
        }

    def _get_default_learning_data(self) -> dict[str, Any]:
        """Get default learning data structure"""
        return {
            "learning_metrics": {
                "total_data_points": 0,
                "patterns_discovered": 0,
                "accuracy_improvement": 0.0,
                "active_strategies": 0,
                "learning_progress": 0.0,
                "queue_size": 0,
            },
            "training_status": {
                "active": False,
                "status": "READY_FOR_TRAINING",
                "current_epoch": 0,
                "total_epochs": 0,
                "loss": 0.0,
                "val_loss": 0.0,
            },
            "model_performance": {},
            "ai_trading_simulation": {
                "total_trades": 0,
                "winning_trades": 0,
                "losing_trades": 0,
                "total_pnl": 0.0,
                "average_win_rate": 0.0,
                "sharpe_ratio": 0.0,
                "max_drawdown": 0.0,
            },
            "latest_learning_trades": [],
        }


# AI learning service state - using dict to avoid global keyword
_ai_learning_service_state: dict[str, AILearningService | None] = {"instance": None}


def get_ai_learning_service() -> AILearningService:
    """Get global AI learning service instance"""
    if _ai_learning_service_state["instance"] is None:
        _ai_learning_service_state["instance"] = AILearningService()
    return _ai_learning_service_state["instance"]
