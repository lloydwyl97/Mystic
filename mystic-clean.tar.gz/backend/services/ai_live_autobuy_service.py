"""
AI Live AutoBuy Service (Binance.US)

- EXECUTIONLESS: Monitors live positions and exchange connectivity. All trading execution goes through PortfolioEngineIntegration.
- Sizes orders conservatively with env + optional micro-account manager overlays
- Enforces live safety gates: kill switches, circuit breakers, cooldowns, cache freshness, risk caps
- Executes market BUY orders via BinanceUSLiveClient (ccxt-like) when TRADING_ENABLED=true
- Exposes get_status() for UI and ops endpoints

Environment (optional):
  TRADING_ENABLED=true|false
  MAX_ORDER_NOTIONAL_USD=250
  POSITION_SIZE_PCT=0.001
  REDIS_URL=redis://localhost:6379/0
  GLOBAL_COOLDOWN_SEC=10
  SYMBOL_COOLDOWN_SEC=20
  DECISION_T_HIGH_DEFAULT=0.62
  META_LABEL_GATE_DEFAULT=0.50
  MAX_DAILY_DRAWDOWN_USD=0    (0 disables)
  LOCK_TTL_SEC=30
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import redis.asyncio as redis

from backend.modules.ai.persistent_cache import get_persistent_cache
from backend.services.task_manager import task_manager

from .binanceus_live_client import BinanceUSLiveClient  # expects ccxt-like interface

# Import from single source of truth
try:
    from backend.config.trading_universe import TRADING_SYMBOLS
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError) as e:
    msg = f"Failed to import trading_universe: {e}"
    raise RuntimeError(msg) from e

# Optional imports - try at top level
try:
    from backend.services.advanced_risk_management import advanced_risk_manager
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    advanced_risk_manager = None

try:
    from backend.services.cache_only_reader import get_cache_reader
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    get_cache_reader = None

try:
    from backend.agents.ai_model_manager import get_ai_model_manager
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    get_ai_model_manager = None

try:
    from backend.core.constants import (
        MIN_AI_ACCURACY_FOR_LIVE_TRADING,
    )
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    MIN_AI_ACCURACY_FOR_LIVE_TRADING = None

try:
    from backend.micro_account_manager import get_micro_account_manager  # Lazy initialization
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    get_micro_account_manager = None  # type: ignore[assignment, misc]

try:
    from backend.services.redis_service import get_redis_service
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    get_redis_service = None

try:
    from backend.services.capital_growth_strategy import capital_growth_strategy
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    capital_growth_strategy = None

try:
    from backend.services.capital_allocation_engine import CapitalAllocationEngine
except (ImportError, ModuleNotFoundError, AttributeError, ValueError, TypeError, RuntimeError):
    CapitalAllocationEngine = None

log = logging.getLogger(__name__)


# ------------------------------------------------------------
# Helpers
# ------------------------------------------------------------


def _to_ccxt(sym: str) -> str:
    """BTCUSDT / BTC_USDT / BTC-USDT / BTC USDT -> BTC/USDT"""
    s = sym.strip().upper().replace("-", "/").replace("_", "/").replace(" ", "/")
    if "/" not in s:
        if s.endswith("USDT"):
            return s[:-4] + "/USDT"
        return s + "/USDT"
    base, quote = s.split("/", 1)
    return f"{base}/{quote}"


def _ymd() -> str:
    return time.strftime("%Y%m%d", time.gmtime())


@dataclass
class LastExec:
    ts: float
    symbol: str
    amount: float
    px: float
    order_id: str | None = None
    dry_run: bool = False
    err: str | None = None


@dataclass
class ServiceStats:
    running: bool = False
    enabled: bool = True
    loop_errors: int = 0
    last_loop_ts: float | None = None
    last_exec: dict[str, LastExec] = field(default_factory=dict)  # key by BINANCE_PAIR
    skipped: dict[str, int] = field(default_factory=dict)  # reason -> count
    executions: deque[LastExec] = field(default_factory=lambda: deque(maxlen=2000))
    start_time: float = field(default_factory=time.time)


class AILiveAutoBuyService:
    def __init__(self) -> None:
        # LIVE MODE ENABLED by default; flip via env if you want paper
        self.enabled = os.getenv("TRADING_ENABLED", "true").lower() == "true"

        # Sizing - MAXIMIZED for $1/minute goal (aggressive optimization)
        self.max_notional = float(os.getenv("MAX_ORDER_NOTIONAL_USD", "5000"))  # MAXIMIZED for higher volume
        self.size_pct = float(os.getenv("POSITION_SIZE_PCT", "0.015"))  # MAXIMIZED for more aggressive trading

        # Confidence-based sizing - Performance Update (Task 1): Raised thresholds for quality
        self.confidence_sizing_enabled = os.getenv("CONFIDENCE_SIZING_ENABLED", "true").lower() == "true"
        self.min_confidence = float(os.getenv("MIN_CONFIDENCE", "0.72"))
        self.max_confidence_multiplier = float(os.getenv("MAX_CONFIDENCE_MULTIPLIER", "10.0"))
        self.confidence_thresholds = {
            "low": 0.65,
            "medium": 0.72,
            "high": 0.80,
            "very_high": 0.88,
        }

        # Cooldowns / safety
        self.global_cd_sec = int(os.getenv("GLOBAL_COOLDOWN_SEC", "2"))
        self.symbol_cd_sec = int(os.getenv("SYMBOL_COOLDOWN_SEC", "5"))
        self.lock_ttl = int(os.getenv("LOCK_TTL_SEC", "15"))
        self.t_high_default = float(os.getenv("DECISION_T_HIGH_DEFAULT", "0.70") or 0.70)  # Raised from 0.62 to 0.70
        self.meta_gate_default = float(os.getenv("META_LABEL_GATE_DEFAULT", "0.50") or 0.50)  # Standard threshold
        self.max_daily_dd_usd = float(os.getenv("MAX_DAILY_DRAWDOWN_USD", "0") or 0.0)  # 0 disables

        # Re-entry cooldowns (Performance Update - Task 4)
        self.re_entry_cooldown_profit = int(os.getenv("RE_ENTRY_COOLDOWN_PROFIT", "300"))  # 5 min after profitable close
        self.re_entry_cooldown_loss = int(os.getenv("RE_ENTRY_COOLDOWN_LOSS", "1800"))  # 30 min after loss
        self.last_close_times: dict[str, float] = {}  # symbol -> timestamp of last close
        self.last_close_results: dict[str, bool] = {}  # symbol -> True if profit, False if loss

        self._running = False
        self._task: asyncio.Task | None = None

        # Exchange client (Binance.US)
        self.client = BinanceUSLiveClient()

        # Generate symbol map dynamically from TRADING_SYMBOLS (live data)
        # Fixed top-10 universe (use ccxt symbols with slash)
        self.SYMBOL_MAP = {}
        for symbol in TRADING_SYMBOLS:
            if symbol.endswith("USDT"):
                base = symbol[:-4]
                self.SYMBOL_MAP[symbol] = f"{base}/USDT"
        self.BINANCE_US_10 = list(self.SYMBOL_MAP.keys())

        # Shared cache + Redis
        self.cache = get_persistent_cache()
        self.redis: redis.Redis | None = None
        # All Live Data, No Fallback/Hardcoded Data
        redis_url = os.getenv("REDIS_URL")
        if not redis_url:
            log.warning("REDIS_URL environment variable not set - Redis functionality will be disabled")
            self.redis_url = None
            self.redis_available = False
            self._stats = ServiceStats(running=False, enabled=self.enabled)
            self.risk_manager = advanced_risk_manager
            return
        else:
            self.redis_url = redis_url
            self.redis_available = True

        # book-keeping
        self._stats = ServiceStats(running=False, enabled=self.enabled)

        # Initialize advanced risk manager
        if advanced_risk_manager is None:
            msg = "advanced_risk_manager is not available"
            raise RuntimeError(msg)

        self.risk_manager = advanced_risk_manager

    # ------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------

    async def start(self):
        if self._running:
            return
        self._running = True
        self._stats.running = True
        self._stats.enabled = self.enabled
        self._stats.start_time = time.time()
        self._stats.loop_errors = 0
        self._stats.last_loop_ts = None
        # single Redis client for the service
        if self.redis_available:
            self.redis = get_redis_service()
        else:
            log.warning("Redis not available - running in degraded mode")
            self.redis = None

        # Load markets with timeout and retry
        try:
            log.info("Loading Binance US markets...")
            await asyncio.wait_for(self.client.load_markets(), timeout=30.0)
            log.info("Binance US markets loaded successfully")
        except asyncio.TimeoutError:
            log.warning("Binance US market loading timed out after 30s - service will start anyway")
        except Exception as e:
            log.warning(f"Failed to load markets on startup: {e} - service will start anyway")

        # BUG-009 Fix: Sync positions from exchange on startup with timeout
        # This rebuilds position tracking if Redis was flushed or service restarted
        try:
            log.info("Syncing positions from Binance US exchange...")
            await asyncio.wait_for(self._sync_positions_from_exchange(), timeout=60.0)
            log.info("Position sync completed")
        except asyncio.TimeoutError:
            log.warning("Position sync timed out after 60s - starting without exchange sync")
        except Exception as e:
            log.warning(f"Failed to sync positions from exchange: {e} - starting without exchange sync")

        self._task = await task_manager.create_task(self._loop(), name="ai_live_autobuy_service:loop")
        log.info("AI Live AutoBuy Service started successfully (exchange connectivity issues are non-fatal)")

    async def stop(self):
        self._running = False
        self._stats.running = False
        if self._task:
            self._task.cancel()
        if self.redis:
            with contextlib.suppress(Exception):
                await self.redis.aclose()

    async def _sync_positions_from_exchange(self):
        """
        BUG-009 Fix: Sync position tracking from exchange on startup.

        This ensures that if Redis is flushed or service restarts, position
        tracking is rebuilt from exchange balances to prevent duplicate buys.
        """
        if not self.redis:
            log.warning("Redis not available for position sync")
            return

        r: redis.Redis = self.redis  # type: ignore[assignment]

        try:
            # Fetch balances from exchange with retry logic and timeout
            balances = await self._fetch_balance_with_retry(max_retries=3, timeout=15.0)

            synced_count = 0
            for symbol_data in self.BINANCE_US_10:
                # Extract base symbol from pair (e.g., "BTCUSDT" → "BTC")
                binance_pair = symbol_data.get("binance_pair", "") if isinstance(symbol_data, dict) else str(symbol_data)

                if not binance_pair.endswith("USDT"):
                    continue

                base_symbol = binance_pair[:-4]  # Remove "USDT"

                # Check if we have a non-zero balance for this symbol
                balance = balances.get("total", {}).get(base_symbol, 0)

                if balance > 0:
                    # We have a position - restore tracking
                    position_key = f"live_position:{binance_pair}"

                    # Check if already tracked
                    existing = await r.get(position_key)
                    if existing:
                        log.debug(f"POSITION_SYNC: {binance_pair} already tracked")
                        continue

                    # Restore position tracking (without entry price/time since we don't have it)
                    await r.set(
                        position_key,
                        json.dumps(
                            {
                                "order_id": "SYNCED_FROM_EXCHANGE",
                                "symbol": binance_pair,
                                "amount": float(balance),
                                "entry_price": 0.0,  # Unknown from exchange
                                "entry_time": time.time(),
                                "synced": True,
                            }
                        ),
                    )

                    synced_count += 1
                    log.info(f"POSITION_SYNC: Restored tracking for {binance_pair} (balance: {balance})")

            # Update position count
            if synced_count > 0:
                position_count_key = "live_position_count"
                await r.set(position_count_key, str(synced_count))
                log.info(f"POSITION_SYNC: Restored {synced_count} position(s) from exchange")
            else:
                log.info("POSITION_SYNC: No positions to restore")

        except Exception as e:
            log.exception(f"Error syncing positions from exchange: {e}")
            log.info("POSITION_SYNC: Skipping exchange sync - will rely on Redis/database state")

    async def _fetch_balance_with_retry(self, max_retries: int = 2, timeout: float = 10.0) -> dict[str, Any]:
        """
        Fetch balance from exchange with retry logic and timeout - USES CACHE FIRST.

        RATE LIMIT FIX: This method now tries cached balance first (30s TTL) before API calls.
        Reduces balance API weight from ~200/min to ~20/min (90% reduction).

        Args:
            max_retries: Maximum number of retry attempts (reduced from 3 to 2)
            timeout: Timeout in seconds for each attempt (reduced from 15s to 10s)

        Returns:
            Balance dictionary from exchange

        Raises:
            Exception: If all retries fail
        """
        import asyncio

        from ccxt.base.errors import NetworkError, RequestTimeout

        # RATE LIMIT FIX: Try cached balance first (saves 10 weight per call)
        try:
            from backend.services.live_trading_service import trading_service

            balance_result = await trading_service.get_account_balance()
            if balance_result.get("status") == "success":
                balances = balance_result.get("balances", {})
                from backend.config.trading_universe import EXCHANGE_ID

                if EXCHANGE_ID in balances:
                    log.debug("Using cached balance (saved 10 API weight)")
                    return {"free": balances[EXCHANGE_ID].get("free", {}), "used": balances[EXCHANGE_ID].get("used", {}), "total": balances[EXCHANGE_ID].get("total", {})}
        except Exception as e:
            log.debug(f"Cached balance unavailable, using direct API: {e}")

        for attempt in range(max_retries):
            try:
                # Add timeout to prevent hanging
                balance = await asyncio.wait_for(self.client.fetch_balance(), timeout=timeout)
                log.info(f"Successfully fetched balance from exchange (attempt {attempt + 1}/{max_retries})")
                return balance

            except asyncio.TimeoutError:
                log.warning(f"Binance US API timeout on attempt {attempt + 1}/{max_retries} (waited {timeout}s)")
                if attempt < max_retries - 1:
                    wait_time = 3 * (2**attempt)  # Longer backoff: 3s, 6s
                    log.info(f"Retrying in {wait_time}s...")
                    await asyncio.sleep(wait_time)
                else:
                    log.exception("All retry attempts exhausted - Binance US API unavailable")
                    raise

            except (RequestTimeout, NetworkError) as e:
                log.warning(f"Binance US network error on attempt {attempt + 1}/{max_retries}: {e}")
                if attempt < max_retries - 1:
                    wait_time = 3 * (2**attempt)
                    log.info(f"Retrying in {wait_time}s...")
                    await asyncio.sleep(wait_time)
                else:
                    log.exception("All retry attempts exhausted - Binance US API unavailable")
                    raise

            except Exception as e:
                # If rate limited (418/429), wait much longer
                if "418" in str(e) or "429" in str(e) or "rate" in str(e).lower():
                    log.exception(f"RATE LIMIT HIT: {e} - backing off for 30s")
                    await asyncio.sleep(30)
                else:
                    log.exception(f"Unexpected error fetching balance: {e}")
                raise

    # ------------------------------------------------------------
    # Public status for UI
    # ------------------------------------------------------------

    def get_status(self) -> dict[str, Any]:
        """Lightweight status snapshot consumed by UI endpoints."""
        last_exec = {
            k: {
                "ts": v.ts,
                "symbol": v.symbol,
                "amount": round(v.amount, 8),
                "px": round(v.px, 8),
                "order_id": v.order_id,
                "dry_run": v.dry_run,
                "err": v.err,
            }
            for k, v in self._stats.last_exec.items()
        }
        return {
            "enabled": self.enabled,
            "running": self._stats.running,
            "loop_errors": self._stats.loop_errors,
            "last_loop_ts": self._stats.last_loop_ts,
            "skips": self._stats.skipped,
            "last_exec": last_exec,
            "universe": self.BINANCE_US_10,
            "limits": {
                "max_notional": self.max_notional,
                "size_pct": self.size_pct,
                "global_cooldown_sec": self.global_cd_sec,
                "symbol_cooldown_sec": self.symbol_cd_sec,
            },
        }

    async def get_statistics(self) -> dict[str, Any]:
        """Get autobuy statistics for dashboard"""
        try:
            executions = list(self._stats.executions)
            total_orders = len(executions)
            successful_orders = sum(1 for ex in executions if not ex.err)
            now_ts = time.time()
            recent_cutoff = now_ts - 86400  # 24h
            daily_orders = sum(1 for ex in executions if ex.ts >= recent_cutoff)
            daily_volume = sum(ex.amount * ex.px for ex in executions if ex.ts >= recent_cutoff)
            total_volume = sum(ex.amount * ex.px for ex in executions)
            last_order_ts = executions[-1].ts if executions else 0.0
            uptime_hours = (now_ts - self._stats.start_time) / 3600 if self._stats.start_time else 0.0

            return {
                "total_orders": total_orders,
                "successful_orders": successful_orders,
                "failed_orders": total_orders - successful_orders,
                "success_rate": (successful_orders / max(1, total_orders)) * 100,
                "total_volume_usd": total_volume,
                "average_order_size": total_volume / max(1, total_orders),
                "daily_volume": daily_volume,
                "daily_orders": daily_orders,
                "last_order_time": last_order_ts,
                "uptime_hours": uptime_hours,
                "active_symbols": len({ex.symbol for ex in executions}),
                "enabled_symbols": len(self.BINANCE_US_10),
                "skipped_orders": dict(self._stats.skipped),
                "timestamp": now_ts,
            }
        except Exception as e:
            log.exception(f"Error getting statistics: {e}")
            return {"error": str(e), "timestamp": time.time()}

    async def get_performance_metrics(self) -> dict[str, Any]:
        """Get performance metrics for dashboard"""
        try:
            executions = list(self._stats.executions)
            total_orders = len(executions)
            successful_orders = sum(1 for ex in executions if not ex.err)
            failed_orders = total_orders - successful_orders
            success_rate = (successful_orders / max(1, total_orders)) * 100

            return {
                "success_rate": success_rate,
                "total_trades": total_orders,
                "profitable_trades": successful_orders,
                "losing_trades": failed_orders,
                "win_rate": success_rate,
                "total_pnl": 0.0,  # Realized P&L tracking handled elsewhere
                "daily_pnl": 0.0,
                "profit_factor": 1.0,
                "sharpe_ratio": 0.0,
                "max_drawdown": 0.0,
                "average_trade_duration": 0.0,
                "best_trade": 0.0,
                "worst_trade": 0.0,
                "timestamp": time.time(),
            }
        except Exception as e:
            log.exception(f"Error getting performance metrics: {e}")
            return {"error": str(e), "timestamp": time.time()}

    async def get_trades(self, limit: int = 50) -> dict[str, Any]:
        """Get recent autobuy trades"""
        try:
            history = list(self._stats.executions)
            selected = history[-limit:] if limit else history
            trades = []
            for exec_data in reversed(selected):
                trades.append(
                    {
                        "trade_id": exec_data.order_id or f"autobuy-{exec_data.symbol.replace('/', '')}-{int(exec_data.ts)}",
                        "symbol": exec_data.symbol.replace("/", ""),
                        "symbol_display": exec_data.symbol,
                        "side": "BUY",
                        "quantity": exec_data.amount,
                        "price": exec_data.px,
                        "amount_usd": exec_data.amount * exec_data.px,
                        "timestamp": exec_data.ts,
                        "status": "FILLED" if not exec_data.err else "FAILED",
                        "exchange": "Binance US",
                        "order_type": "MARKET",
                        "dry_run": exec_data.dry_run,
                        "error": exec_data.err,
                    }
                )

            return {
                "trades": trades,
                "count": len(trades),
                "total_volume": sum(t.get("amount_usd", 0.0) for t in trades),
                "successful_trades": sum(1 for t in trades if t.get("status") == "FILLED"),
                "failed_trades": sum(1 for t in trades if t.get("status") == "FAILED"),
                "timestamp": time.time(),
            }
        except Exception as e:
            log.exception(f"Error getting trades: {e}")
            return {"trades": [], "count": 0, "error": str(e), "timestamp": time.time()}

    async def get_signals(self, limit: int = 50) -> dict[str, Any]:
        """Get recent autobuy signals"""
        try:
            signals = []

            # Generate live signals based on current market conditions
            if self.cache:
                try:
                    if get_cache_reader is None:
                        log.warning("get_cache_reader is not available")
                        return {"signals": [], "count": 0, "timestamp": time.time()}

                    reader = get_cache_reader()
                    prices_data = await reader.get_prices(TRADING_SYMBOLS)
                    price_map = prices_data.get("prices", {}) if isinstance(prices_data, dict) else {}

                    for entry_symbol in TRADING_SYMBOLS:
                        display_key = entry_symbol.replace("USDT", "-USD")
                        pdata = price_map.get(display_key)
                        if not pdata:
                            continue
                        price_val = float(pdata.get("price", 0) or 0)
                        if price_val <= 0:
                            continue

                        # Generate dynamic signal based on market conditions
                        change_24h = float(pdata.get("change_24h", 0) or 0)
                        volume_24h = float(pdata.get("volume_24h", 0) or 0)

                        # Base confidence on market momentum and volume
                        base_confidence = 0.5
                        if change_24h > 0:
                            base_confidence += min(0.3, abs(change_24h) / 100)  # Positive momentum
                        if volume_24h > 1000000:  # High volume
                            base_confidence += 0.1

                        confidence = min(0.95, max(0.1, base_confidence))
                        signal_type = "buy" if change_24h > -5 else "hold"  # Don't buy if down >5%

                        # Dynamic stop loss and take profit based on volatility
                        volatility_factor = min(0.1, abs(change_24h) / 100)
                        stop_loss = price_val * (0.97 - volatility_factor)  # 3-7% stop loss
                        take_profit = price_val * (1.03 + volatility_factor)  # 3-7% take profit
                        expected_return = min(10.0, max(1.0, (take_profit - price_val) / price_val * 100))

                        risk_level = "HIGH" if confidence > 0.8 else "MEDIUM" if confidence > 0.6 else "LOW"

                        signals.append(
                            {
                                "signal_id": f"ai-live-{display_key.lower().replace('/', '-')}-{int(time.time())}",
                                "symbol": display_key,
                                "action": signal_type.upper(),
                                "type": signal_type.upper(),
                                "signal_type": signal_type,
                                "confidence": round(confidence, 2),
                                "price": round(price_val, 6),
                                "price_target": round(price_val, 6),
                                "stop_loss": round(stop_loss, 6),
                                "take_profit": round(take_profit, 6),
                                "risk_level": risk_level,
                                "time_horizon": "1-4h",
                                "expected_return": f"{expected_return:.1f}%",
                                "strategy": "ai_momentum",
                                "exchange": "Binance US",
                                "generated": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                            },
                        )

                        if len(signals) >= limit:
                            break

                except Exception as e:
                    log.warning(f"Error generating signals: {e}")

            return {
                "signals": signals[:limit],
                "count": len(signals),
                "active_signals": len([s for s in signals if s.get("confidence", 0) > 0.6]),
                "high_confidence_signals": len([s for s in signals if s.get("confidence", 0) > 0.8]),
                "timestamp": time.time(),
            }
        except Exception as e:
            log.exception(f"Error getting signals: {e}")
            return {
                "signals": [],
                "count": 0,
                "error": str(e),
                "timestamp": time.time(),
            }

    # ------------------------------------------------------------
    # Core loop
    # ------------------------------------------------------------

    async def _loop(self):
        while self._running:
            try:
                await self._process_signals_once()
                self._stats.last_loop_ts = time.time()
            except asyncio.CancelledError:
                break
            except Exception as e:
                self._stats.loop_errors += 1
                log.exception("AI live autobuy loop error: %s", e)
            await asyncio.sleep(60)  # INCREASED: Reduce API calls from every 5s to every 60s

    async def _process_signals_once(self):
        """
        Process signals across the Binance-US-10 symbols once.

        BUG-006 Fix: All safety gates are fail-closed. If infrastructure is unavailable,
        trading is paused to protect capital.
        """
        if not self.redis_available or not self.redis:
            log.warning("Redis not available - skipping signal processing")
            return

        r: redis.Redis = self.redis  # type: ignore[assignment]

        # CRITICAL: Redis health check (BUG-006 Fix: FAIL-CLOSED)
        # If Redis is unavailable, all safety gates fail-closed and trading stops
        try:
            await r.ping()
        except Exception as e:
            log.critical(f"FAIL_CLOSED: Redis ping failed, pausing all trading: {e}")
            self._inc_skip("redis_unavailable")
            return

        # BUG-007 Fix: Global stale market data gate (FAIL-CLOSED)
        # Check if market data is stale or missing - but allow reasonable update intervals
        try:
            last_update_str = await r.get("market_data:last_update")
            if not last_update_str:
                # Key is missing - check if we have recent price data to reconstruct timestamp
                # This handles case where key expired but prices still exist
                try:
                    from backend.utils.cache_guard import CacheGuard

                    cg = await CacheGuard.create()
                    # Check if we have any recent prices
                    recent_prices_found = 0
                    latest_ts = 0
                    for symbol in ["BTCUSDT", "ETHUSDT", "ADAUSDT", "SOLUSDT", "DOGEUSDT"]:
                        ts_str = await r.hget(f"price:{symbol}", "ts")
                        if ts_str:
                            ts = int(ts_str)
                            latest_ts = max(latest_ts, ts)
                            recent_prices_found += 1

                    # If we have recent prices (< 60s old), recreate the key
                    if recent_prices_found >= 3 and latest_ts > 0:
                        current_age = time.time() - latest_ts
                        if current_age < 60.0:
                            # Recreate the key from most recent price timestamp
                            await cg.mark_market_update("recovery_from_prices")
                            log.info(f"Recovered market_data:last_update from price timestamps (age: {current_age:.1f}s)")
                        else:
                            # Prices are too old, genuine stale data
                            log.critical(f"FAIL_CLOSED: market_data:last_update missing and prices are stale ({current_age:.1f}s old)")
                            self._inc_skip("stale_market_data")
                            return
                    else:
                        # No recent prices - genuine problem
                        log.critical("FAIL_CLOSED: market_data:last_update missing and no recent prices found")
                        self._inc_skip("stale_market_data")
                        return
                except Exception as recovery_err:
                    # Recovery failed - treat as missing
                    log.critical(f"FAIL_CLOSED: market_data:last_update missing and recovery failed: {recovery_err}")
                    self._inc_skip("stale_market_data")
                    return

            # If we got here, key was recreated or existed
            last_update_str = await r.get("market_data:last_update")
            if not last_update_str:
                # Still missing after recovery attempt
                log.critical("FAIL_CLOSED: market_data:last_update still missing after recovery attempt")
                self._inc_skip("stale_market_data")
                return

            last_update = float(last_update_str)
            data_age = time.time() - last_update

            # Use 60 second threshold - WebSocket updates may come every 30-40s which is acceptable
            # Only pause if data is truly stale (>60s) indicating WebSocket is disconnected
            if data_age > 60.0:  # 60 second threshold (was 10s - too strict for slow WebSocket updates)
                log.critical(f"FAIL_CLOSED: Market data is stale ({data_age:.1f}s old), pausing all trading")
                self._inc_skip("stale_market_data")
                return
        except Exception as e:
            # FAIL-CLOSED: If we can't check market data freshness, pause trading
            log.critical(f"FAIL_CLOSED: Cannot check market data freshness, pausing all trading: {e}")
            self._inc_skip("market_data_check_error")
            return

        # Global kill switch or circuit?
        if await self._kill_switch_on(r):
            self._inc_skip("kill_switch")
            return
        if await self._circuit_open(r):
            self._inc_skip("circuit_open")
            return
        if not await self._global_cooldown_ok(r):
            self._inc_skip("global_cooldown")
            return
        if not await self._risk_ok(r):
            self._inc_skip("risk_gate")
            return

        for binance_pair in self.BINANCE_US_10:
            try:
                await self._process_symbol(r, binance_pair)
            except Exception as e:
                log.exception("Error processing signal for %s: %s", binance_pair, e)
                continue

    # ------------------------------------------------------------
    # Per-symbol processing
    # ------------------------------------------------------------

    async def _process_symbol(self, r: redis.Redis, binance_pair: str) -> None:
        """
        LIVE-SPECIFIC RESPONSIBILITIES ONLY

        This service is now EXECUTIONLESS. It handles:
        - Position monitoring and sync with exchange
        - Risk gate enforcement
        - Live-specific state management

        It does NOT consume ai_decision:* keys or execute trades.
        All execution goes through PortfolioEngineIntegration.
        """
        sym_ccxt = self.SYMBOL_MAP.get(binance_pair)
        if not sym_ccxt:
            log.debug(f"Unknown symbol {binance_pair}, skipping live monitoring")
            return

        try:
            # LIVE RESPONSIBILITY 1: Position sync with exchange
            # Ensure our Redis position tracking matches exchange reality
            await self._sync_position_with_exchange(r, binance_pair, sym_ccxt)

            # LIVE RESPONSIBILITY 2: Risk gate monitoring
            # Monitor live positions for risk violations
            await self._monitor_live_position_risk(r, binance_pair, sym_ccxt)

            # RATE LIMIT FIX: Remove per-symbol connectivity checks
            # These were causing 10 API calls per monitoring cycle (10 symbols x 1 weight = 10 weight)
            # Exchange connectivity is already verified by market data service via WebSocket
            # If there's an actual connectivity issue, it will be caught when placing orders

        except Exception as e:
            log.debug(f"Live monitoring error for {binance_pair}: {e}")
            # Don't raise - continue monitoring other symbols

    async def _sync_position_with_exchange(self, r: redis.Redis, binance_pair: str, sym_ccxt: str) -> None:
        """Sync Redis position tracking with actual exchange positions - with cached balance"""
        try:
            # Check if we have a position recorded in Redis
            position_key = f"live_position:{binance_pair}"
            existing_position = await r.get(position_key)

            # RATE LIMIT FIX: Use cached balance from live_trading_service (30s cache)
            # Instead of direct API call (weight=10 each time)
            # This reduces balance calls from ~10/min to ~2/min (80% reduction)
            from backend.services.live_trading_service import trading_service

            balance_result = await trading_service.get_account_balance()
            if balance_result.get("status") != "success":
                log.debug(f"Could not fetch balance for {binance_pair}: {balance_result.get('message')}")
                return

            balances = balance_result.get("balances", {})
            from backend.config.trading_universe import EXCHANGE_ID

            exchange_balance = balances.get(EXCHANGE_ID, {})

            _base, _quote = sym_ccxt.split("/")
            base_free = float(exchange_balance.get("free", {}).get(_base, 0) or 0)
            base_used = float(exchange_balance.get("used", {}).get(_base, 0) or 0)
            base_total = float(exchange_balance.get("total", {}).get(_base, 0) or (base_free + base_used))
            min_base_threshold = float(os.getenv("MIN_POSITION_BASE", "0.00001"))

            if base_total > min_base_threshold:  # We have a meaningful position on exchange
                if not existing_position:
                    # Exchange has position but Redis doesn't - sync it
                    log.info(f"POSITION_SYNC: {binance_pair} found on exchange but not in Redis, syncing (base_total={base_total:.8f})")
                    # Get current price for entry price estimation
                    try:
                        ticker = await self.client.fetch_ticker(sym_ccxt)
                        current_price = float(ticker.get("last", 0))
                    except Exception:
                        current_price = 0.0

                    await r.set(
                        position_key,
                        json.dumps(
                            {
                                "order_id": "EXCHANGE_SYNC",
                                "symbol": binance_pair,
                                "amount": base_free,
                                "entry_price": current_price,
                                "entry_time": time.time(),
                                "synced": True,
                            }
                        ),
                    )
                    # Update position count
                    await r.incr("live_position_count")
            elif existing_position and base_total > 0:
                # Exchange shows dust below threshold; keep Redis position to avoid false desync
                log.debug(f"POSITION_DUST: {binance_pair} base_total={base_total:.8f} below threshold {min_base_threshold:.8f}; keeping Redis position")
            elif existing_position:
                # Redis has position but exchange doesn't - position was closed externally
                log.warning(f"POSITION_DESYNC: {binance_pair} in Redis but not on exchange, removing (base_total={base_total:.8f})")
                await r.delete(position_key)
                await r.decr("live_position_count")

        except Exception as e:
            log.debug(f"Position sync failed for {binance_pair}: {e}")

    async def _monitor_live_position_risk(self, r: redis.Redis, binance_pair: str, sym_ccxt: str) -> None:
        """Monitor live positions for risk violations"""
        try:
            position_key = f"live_position:{binance_pair}"
            position_data = await r.get(position_key)
            if not position_data:
                return

            position = json.loads(position_data)
            entry_price = position.get("entry_price", 0)
            amount = position.get("amount", 0)

            if entry_price <= 0 or amount <= 0:
                return

            # Get current price
            try:
                ticker = await self.client.fetch_ticker(sym_ccxt)
                current_price = float(ticker.get("last", 0))
                if current_price <= 0:
                    return
            except Exception:
                return

            # Check for excessive losses (stop loss monitoring)
            loss_pct = (entry_price - current_price) / entry_price
            stop_loss_threshold = float(os.getenv("LIVE_STOP_LOSS_PCT", "0.05"))  # 5% default

            if loss_pct >= stop_loss_threshold:
                log.warning(f"LIVE_STOP_LOSS_TRIGGER: {binance_pair} loss {loss_pct:.1%} >= {stop_loss_threshold:.1%}")
                # Note: We log but don't execute sells - that's handled by portfolio engine
                # This is just monitoring for risk visibility

        except Exception as e:
            log.debug(f"Risk monitoring failed for {binance_pair}: {e}")

    async def _verify_exchange_connectivity(self, sym_ccxt: str) -> None:
        """Verify we can still communicate with the exchange"""
        try:
            # Simple connectivity test - fetch ticker
            await self.client.fetch_ticker(sym_ccxt)
        except Exception as e:
            log.warning(f"Exchange connectivity issue for {sym_ccxt}: {e}")
            # Don't raise - just log the issue

    # ------------------------------------------------------------
    # Sizing & market meta (used by PortfolioEngineIntegration for live execution)
    # ------------------------------------------------------------

    async def _quantize_amount(self, ccxt_symbol: str, raw_amount: float) -> float:
        """Respect exchange precision / min amount if markets are loaded."""
        try:
            markets = getattr(self.client, "markets", None)
            if not markets:
                return float(f"{raw_amount:.8f}")
            m = markets.get(ccxt_symbol)
            if not m:
                return float(f"{raw_amount:.8f}")

            # precision
            pr = (m.get("precision") or {}).get("amount")
            q = round(raw_amount, pr) if isinstance(pr, int) and pr >= 0 else float(f"{raw_amount:.8f}")

            # enforce min amount
            limits = m.get("limits") or {}
            amt_min = (limits.get("amount") or {}).get("min")
            if isinstance(amt_min, (int, float)) and amt_min:
                q = max(q, float(amt_min))

            return float(q)
        except Exception:
            return float(f"{raw_amount:.8f}")

    # ------------------------------------------------------------
    # Safety gates
    # ------------------------------------------------------------

    async def _kill_switch_on(self, r: redis.Redis) -> bool:
        """
        Check if global kill switch is on (BUG-006 Fix: FAIL-CLOSED).

        CRITICAL: On Redis error, trading MUST be paused (fail-closed).
        Returns True if kill switch is on OR if Redis is unavailable.
        """
        try:
            return (await r.get("kill_switch")) == "1"
        except Exception as e:
            # FAIL-CLOSED: If we can't check the kill switch, assume it's on
            log.critical(f"FAIL_CLOSED: Cannot check kill_switch (Redis error), pausing trading: {e}")
            return True  # FAIL-CLOSED: Pause trading on infrastructure error

    async def _symbol_killed(self, r: redis.Redis, ccxt_symbol: str) -> bool:
        """
        Check if symbol-specific kill switch is on (BUG-006 Fix: FAIL-CLOSED).

        CRITICAL: On Redis error, symbol must be paused (fail-closed).
        Returns True if symbol kill switch is on OR if Redis is unavailable.
        """
        try:
            return (await r.get(f"kill:{ccxt_symbol}")) == "1"
        except Exception as e:
            # FAIL-CLOSED: If we can't check symbol kill switch, assume it's on
            log.critical(f"FAIL_CLOSED: Cannot check kill:{ccxt_symbol} (Redis error), pausing symbol: {e}")
            return True  # FAIL-CLOSED: Pause symbol trading on infrastructure error

    async def _circuit_open(self, r: redis.Redis) -> bool:
        """
        Check if circuit breaker is open (BUG-006 Fix: FAIL-CLOSED).

        CRITICAL: On Redis error, circuit must be considered open (fail-closed).
        Returns True if circuit breaker is open OR if Redis is unavailable.
        """
        try:
            return (await r.get("bwl:circuit_open")) == "1"
        except Exception as e:
            # FAIL-CLOSED: If we can't check circuit breaker, assume it's open
            log.critical(f"FAIL_CLOSED: Cannot check circuit breaker (Redis error), pausing trading: {e}")
            return True  # FAIL-CLOSED: Pause trading on infrastructure error

    async def _risk_ok(self, _r: redis.Redis) -> bool:
        """
        Check if risk limits allow trading (BUG-006 Fix: FAIL-CLOSED).

        CRITICAL: On risk manager error, trading MUST be paused (fail-closed).
        Returns True only if risk manager explicitly allows trading.
        """
        try:
            # Check advanced risk limits
            risk_status = await self.risk_manager.check_risk_limits()

            if not risk_status.get("trading_allowed", True):
                self._inc_skip("risk_limits_exceeded")
                return False

            # Check daily drawdown limit
            if self.max_daily_dd_usd > 0:
                daily_loss_pct = risk_status.get("daily_loss_pct")
                if daily_loss_pct > 0.05:  # 5% daily loss limit
                    self._inc_skip("daily_dd")
                    return False

            # Check portfolio heat
            current_drawdown_pct = risk_status.get("current_drawdown_pct")
            if current_drawdown_pct > 0.10:  # 10% drawdown limit
                self._inc_skip("portfolio_heat")
                return False

            return True
        except Exception as e:
            # FAIL-CLOSED: If risk check fails, DO NOT allow trade
            log.critical(f"FAIL_CLOSED: Risk check failed (error), pausing trading: {e}")
            self._inc_skip("risk_check_error")
            return False  # FAIL-CLOSED: Pause trading on risk manager error

    async def _global_cooldown_ok(self, r: redis.Redis) -> bool:
        """
        Check if global cooldown allows trading (BUG-006 Fix: FAIL-CLOSED).

        CRITICAL: On Redis error, cooldown must be considered active (fail-closed).
        Returns True only if cooldown check succeeds AND cooldown has expired.
        """
        try:
            key = "cd:last_global"
            last = await r.get(key)
            now = time.time()
            return not (last and now - float(last) < self.global_cd_sec)
        except Exception as e:
            # FAIL-CLOSED: If we can't check cooldown, assume it's active
            log.critical(f"FAIL_CLOSED: Cannot check global cooldown (Redis error), pausing trading: {e}")
            return False  # FAIL-CLOSED: Pause trading on infrastructure error

    async def _symbol_cooldown_ok(self, r: redis.Redis, bus_symbol: str, ccxt_symbol: str) -> bool:
        """
        Check if symbol cooldown allows trading (BUG-006 Fix: FAIL-CLOSED).

        CRITICAL: On Redis error, cooldown must be considered active (fail-closed).
        Returns True only if cooldown check succeeds AND cooldown has expired.
        """
        now = time.time()
        try:
            # check both forms
            last1 = await r.get(f"cd:last_symbol:{bus_symbol}")
            last2 = await r.get(f"cd:last_symbol:{ccxt_symbol}")
            last = float(last1 or last2 or 0)
            return (now - last) >= self.symbol_cd_sec
        except Exception as e:
            # FAIL-CLOSED: If we can't check symbol cooldown, assume it's active
            log.critical(f"FAIL_CLOSED: Cannot check cooldown for {ccxt_symbol} (Redis error), pausing symbol: {e}")
            return False  # FAIL-CLOSED: Pause symbol trading on infrastructure error

    async def _mark_cooldowns(self, r: redis.Redis, bus_symbol: str, ccxt_symbol: str) -> None:
        now = time.time()
        with contextlib.suppress(Exception):
            await r.set("cd:last_global", f"{now}", ex=max(self.global_cd_sec * 2, 120))
        try:
            await r.set(
                f"cd:last_symbol:{bus_symbol}",
                f"{now}",
                ex=max(self.symbol_cd_sec * 2, 300),
            )
            await r.set(
                f"cd:last_symbol:{ccxt_symbol}",
                f"{now}",
                ex=max(self.symbol_cd_sec * 2, 300),
            )
        except Exception:
            pass
        with contextlib.suppress(Exception):
            await r.incr(f"cd:daily_count:{_ymd()}")

    async def _acquire_lock(self, r: redis.Redis, key: str, ttl: int) -> bool:
        """Simple NX lock with TTL to avoid duplicate executions."""
        try:
            return bool(await r.set(key, "1", nx=True, ex=ttl))
        except Exception:
            log.warning("FAIL_CLOSED: lock acquisition failed for %s (Redis error) — skipping execution", key)
            return False  # fail-closed: do not execute if lock state is unknown

    async def _threshold_high(self, r: redis.Redis, ccxt_symbol: str) -> float:
        try:
            ov = await r.get(f"override:t_high:{ccxt_symbol}")
            return float(ov) if ov is not None else self.t_high_default
        except Exception:
            return self.t_high_default

    async def _meta_gate(self, r: redis.Redis, ccxt_symbol: str) -> float:
        try:
            ov = await r.get(f"override:t_gate:{ccxt_symbol}")
            return float(ov) if ov is not None else self.meta_gate_default
        except Exception:
            return self.meta_gate_default

    def _extract_confidence(self, sig: dict[str, Any]) -> float | None:
        """Try several likely fields for a probability/confidence value."""
        confidence = None
        for k in ("confidence", "prob", "p", "score"):
            v = sig.get(k)
            try:
                if v is None:
                    continue
                confidence = float(v)
                break
            except Exception:
                continue

        if confidence is None:
            return None

        try:
            from backend.services.confidence_normalizer import ConfidenceNormalizer

            confidence = ConfidenceNormalizer.normalize(confidence)
            log.info(f"Normalized confidence: {confidence}")
        except Exception:
            pass

        return confidence

    def _extract_meta_ok(self, sig: dict[str, Any]) -> bool | None:
        """Meta label acceptance if present; None means 'no opinion'."""
        v = sig.get("meta_ok")
        if v is None:
            return None
        if isinstance(v, str):
            v = v.strip().lower()
            if v in ("1", "true", "yes", "y"):
                return True
            if v in ("0", "false", "no", "n"):
                return False
            return None
        if isinstance(v, (int, float)):
            return bool(v)
        if isinstance(v, bool):
            return v
        return None

    # ------------------------------------------------------------
    # Auditing
    # ------------------------------------------------------------

    async def _audit_execution(
        self,
        r: redis.Redis,
        bus_symbol: str,
        ccxt_symbol: str,
        amount: float,
        px: float,
        order_id: str | None,
        dry_run: bool,
        err: str | None = None,
    ) -> None:
        try:
            evt = {
                "ts": time.time(),
                "symbol_bus": bus_symbol,
                "symbol": ccxt_symbol,
                "amount": float(amount),
                "px": float(px),
                "order_id": order_id,
                "dry_run": bool(dry_run),
                "err": err,
            }
            await r.lpush("exec:aiautobuy", json.dumps(evt))
            await r.ltrim("exec:aiautobuy", 0, 999)
        except Exception:
            pass

    # ------------------------------------------------------------
    # Stats helpers
    # ------------------------------------------------------------

    def _inc_skip(self, reason: str) -> None:
        self._stats.skipped[reason] = self._stats.skipped.get(reason, 0) + 1

    def _calculate_confidence_multiplier(self, confidence: float) -> float:
        """Calculate position size multiplier based on AI confidence"""
        if confidence < self.min_confidence:
            return 0.0  # Below minimum confidence: signal caller to skip this trade

        # Linear scaling from 1.0x to max_confidence_multiplier
        # Confidence range: min_confidence to 1.0
        confidence_range = 1.0 - self.min_confidence
        confidence_ratio = (confidence - self.min_confidence) / confidence_range

        # Scale from 1.0 to max_confidence_multiplier
        multiplier = 1.0 + (confidence_ratio * (self.max_confidence_multiplier - 1.0))

        # Ensure multiplier is within bounds
        return max(0.1, min(multiplier, self.max_confidence_multiplier))

    async def get_status_detailed(self) -> dict[str, Any]:
        """Get autobuy system status (detailed version)"""
        try:
            executions = list(self._stats.executions)
            total_orders = len(executions)
            successful_orders = sum(1 for ex in executions if not ex.err)
            failed_orders = total_orders - successful_orders
            last_order_ts = executions[-1].ts if executions else None
            last_order_iso = datetime.fromtimestamp(last_order_ts, tz=timezone.utc).isoformat() if last_order_ts else None

            return {
                "status": "active" if (self._running and self.enabled) else "disabled",
                "trading_enabled": self.enabled,
                "total_orders": total_orders,
                "successful_orders": successful_orders,
                "failed_orders": failed_orders,
                "skipped_orders": sum(self._stats.skipped.values()),
                "skipped_breakdown": dict(self._stats.skipped),
                "last_order_time": last_order_iso,
                "uptime_seconds": time.time() - self._stats.start_time if self._stats.start_time else 0.0,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except Exception as e:
            log.exception(f"Error getting autobuy status: {e}")
            return {
                "status": "error",
                "error": str(e),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

    async def get_configuration(self) -> dict[str, Any]:
        """Get autobuy configuration"""
        try:
            return {
                "trading_enabled": self.enabled,
                "max_order_notional_usd": self.max_notional,
                "position_size_pct": self.size_pct,
                "global_cooldown_sec": self.global_cd_sec,
                "symbol_cooldown_sec": self.symbol_cd_sec,
                "decision_t_high_default": self.t_high_default,
                "meta_label_gate_default": self.meta_gate_default,
                "max_daily_drawdown_usd": self.max_daily_dd_usd,
                "lock_ttl_sec": self.lock_ttl,
                "confidence_sizing_enabled": self.confidence_sizing_enabled,
                "min_confidence": self.min_confidence,
                "max_confidence_multiplier": self.max_confidence_multiplier,
                "symbol_universe": list(self.BINANCE_US_10),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except Exception as e:
            log.exception(f"Error getting autobuy configuration: {e}")
            return {
                "error": str(e),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

    async def get_trades_history(self, limit: int = 50) -> dict[str, Any]:
        """Get autobuy trade history (detailed)"""
        if not self.redis:
            return {"trades": [], "count": 0, "timestamp": datetime.now(timezone.utc).isoformat()}
        try:
            r = self.redis
            trade_data = await r.lrange("exec:aiautobuy", 0, limit - 1)

            trades = []
            for trade_json in trade_data:
                try:
                    trade = json.loads(trade_json)
                    trades.append(trade)
                except Exception:
                    continue

            return {
                "trades": trades,
                "count": len(trades),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except Exception as e:
            log.exception(f"Error getting autobuy trades: {e}")
            return {
                "error": str(e),
                "trades": [],
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }

    async def get_signals_history(self, limit: int = 50) -> dict[str, Any]:
        """Get autobuy AI signals (historical)"""
        if not self.redis:
            return {"signals": [], "count": 0, "timestamp": datetime.now(timezone.utc).isoformat()}
        try:
            r = self.redis
            signal_data = await r.lrange("ai_signals", 0, limit - 1)

            signals = []
            for signal_json in signal_data:
                try:
                    signal = json.loads(signal_json)
                    signals.append(signal)
                except Exception:
                    continue

            return {
                "signals": signals,
                "count": len(signals),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        except Exception as e:
            log.exception(f"Error getting autobuy signals: {e}")
            return {
                "error": str(e),
                "signals": [],
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }


# Global instance - lazy initialized to avoid startup conflicts
_ai_live_autobuy_service_instance = None


def get_ai_live_autobuy_service() -> AILiveAutoBuyService:
    """Get or initialize the autobuy service (lazy loading)."""
    global _ai_live_autobuy_service_instance
    if _ai_live_autobuy_service_instance is None:
        _ai_live_autobuy_service_instance = AILiveAutoBuyService()
    return _ai_live_autobuy_service_instance


# For backward compatibility - will use lazy loading
ai_live_autobuy_service = None  # Will be filled on first use


# For UI integration expecting autobuy_service.get_status()
class _Adapter:
    @staticmethod
    def get_status() -> dict[str, Any]:
        svc = get_ai_live_autobuy_service()
        return svc.get_status()

    @staticmethod
    async def get_statistics() -> dict[str, Any]:
        svc = get_ai_live_autobuy_service()
        return await svc.get_statistics()

    @staticmethod
    async def get_performance_metrics() -> dict[str, Any]:
        svc = get_ai_live_autobuy_service()
        return await svc.get_performance_metrics()

    @staticmethod
    async def get_trades(limit: int = 50) -> dict[str, Any]:
        svc = get_ai_live_autobuy_service()
        return await svc.get_trades(limit)

    @staticmethod
    async def get_signals(limit: int = 50) -> dict[str, Any]:
        svc = get_ai_live_autobuy_service()
        return await svc.get_signals(limit)


# Backwards-compatible export name used by UI routes
autobuy_service = _Adapter()
